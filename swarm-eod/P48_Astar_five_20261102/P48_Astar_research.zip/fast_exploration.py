"""Sensor-only coordinated frontier planning and holonomic navigation.

Integration: import ExplorationMotionMixin and put it before the existing
CoveragePlacementDrone in the final controller's base list. Its constructor
replaces MapMemory without changing packet or placement interfaces.
"""

from __future__ import annotations

import heapq
from swarm_rescue.solutions.astar_grid import astar_grid, record_astar
import math

import cv2
import numpy as np
from swarm_rescue.solutions.sensor_feedback import feedback_velocity

from swarm_rescue.solutions.greedy_mapping import MapMemory, wrap_angle


class CoordinatedMapMemory(MapMemory):
    """Fine wall clearance, persistent frontiers, reserved team viewpoints."""

    CLEARANCE = 19.0

    def __init__(self, width, height, identifier=0, team_size=5):
        super().__init__(width, height)
        self.identifier = int(identifier)
        self.team_size = max(1, int(team_size))
        self.origin = None
        self.step = 0
        self.reservations = []
        self.exploration_goal = None
        self.last_exploration_goal_step = -1000
        self.failed_goals = []

    def clearance(self):
        # Apply the robot footprint at fine resolution. Inflating the coarse
        # occupied cells by another 3x3 cells unnecessarily seals narrow doors.
        occupied = (self.hits >= 2).astype(np.uint8)
        if not occupied.any():
            return np.full(self.shape, max(self.width, self.height), dtype=np.float32)
        occupied = cv2.dilate(occupied, np.ones((3, 3), np.uint8))
        distance = cv2.distanceTransform(1 - occupied, cv2.DIST_L2, 5) * self.FINE
        rows = ((np.arange(self.shape[0]) + .5) * self.CELL / self.FINE).astype(int)
        cols = ((np.arange(self.shape[1]) + .5) * self.CELL / self.FINE).astype(int)
        rows = np.minimum(rows, self.hit_shape[0] - 1)
        cols = np.minimum(cols, self.hit_shape[1] - 1)
        return distance[np.ix_(rows, cols)]

    def blocked(self):
        return self.clearance() < self.CLEARANCE

    @staticmethod
    def _line_cells(start, end):
        count = max(abs(end[0] - start[0]), abs(end[1] - start[1])) * 2 + 1
        points = np.rint(np.linspace(start, end, max(2, count))).astype(int)
        return points[:, 0], points[:, 1]

    def _visible(self, start, end, walkable):
        rr, cc = self._line_cells(start, end)
        return bool(np.all(walkable[rr, cc]))

    def reject_goal(self, position, ttl=220):
        if self.exploration_goal is not None:
            self.failed_goals.append((self.step + ttl, np.asarray(self.exploration_goal).copy()))
        self.exploration_goal = None

    def route(self, position, identifier=0, peers=(), destination=None, utility=None):
        start = self.world_to_cell(position)
        clearance = self.clearance()
        blocked = clearance < self.CLEARANCE
        # Sparse ray interiors can leave one-cell holes, even in broad free
        # corridors. Closing fills these small holes but does not expand the
        # map into unknown space. Clearance independently keeps walls closed.
        free = cv2.morphologyEx(self.free.astype(np.uint8), cv2.MORPH_CLOSE,
                                np.ones((3, 3), np.uint8)).astype(bool) | self.free
        walkable = free & ~blocked
        walkable[start] = True
        # The same directed eight-neighbour graph and heap tie ordering,
        # encoded with scalar indices to avoid NumPy indexing in the hot loop.
        height,width=self.shape
        adjacency=[[] for _ in range(height*width)]
        penalties=[.30*max(0.,(40.-float(v))/40.) for v in clearance.ravel()]
        for dr,dc in ((-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)):
            r0,r1=max(0,-dr),min(height,height-dr)
            c0,c1=max(0,-dc),min(width,width-dc)
            valid=walkable[r0:r1,c0:c1]&walkable[r0+dr:r1+dr,c0+dc:c1+dc]
            if dr and dc:valid &= walkable[r0+dr:r1+dr,c0:c1]&walkable[r0:r1,c0+dc:c1+dc]
            rr0,cc0=np.nonzero(valid);origins=(rr0+r0)*width+cc0+c0
            weight=math.sqrt(2) if dr and dc else 1.
            for source in origins.tolist():
                target=source+dr*width+dc
                adjacency[source].append((target,weight*(1.+penalties[target])))
        source=int(start[0])*width+int(start[1]);costs=[math.inf]*(height*width)
        costs[source]=0.;parents={};queue=[(0.,source)]
        while queue:
            distance,node=heapq.heappop(queue)
            if distance>costs[node]:continue
            for neighbor,weight in adjacency[node]:
                proposal=distance+weight
                if proposal<costs[neighbor]:
                    costs[neighbor]=proposal;parents[neighbor]=node
                    heapq.heappush(queue,(proposal,neighbor))
        cost=np.asarray(costs).reshape(self.shape)
        parent={divmod(child,width):divmod(previous,width) for child,previous in parents.items()}

        reachable = np.isfinite(cost)
        rr, cc = np.indices(self.shape)
        if utility is not None:
            score = np.full(self.shape, -np.inf)
            values = np.asarray(utility, float)
            score[reachable] = values[reachable] / (1.0 + .04 * cost[reachable])
        elif destination is not None:
            desired = self.world_to_cell(destination)
            score = -((rr - desired[0]) ** 2 + (cc - desired[1]) ** 2) - .025 * cost
        else:
            unknown = (~self.free & ~blocked).astype(np.float32)
            # Active-perception utility: approximate the new unknown area a
            # frontier can expose within the 300 px public lidar horizon.
            # The separable box filter is a cheap square-footprint proxy;
            # restricting choices to reachable frontiers keeps it sensor-only.
            information_window = max(13, int(round((2.0 * 240.0) / self.CELL)) | 1)
            gain = cv2.boxFilter(unknown, -1, (information_window, information_window),
                                 normalize=False, borderType=cv2.BORDER_CONSTANT)
            nearby = cv2.dilate(unknown.astype(np.uint8), np.ones((3, 3), np.uint8)) > 0
            frontier = reachable & nearby
            # A useful frontier must be far enough to produce a new viewpoint.
            far = (rr - start[0]) ** 2 + (cc - start[1]) ** 2 >= 5
            if (frontier & far).any():
                frontier &= far
            if frontier.any():
                reachable &= frontier
            # Less short-sighted than gain/(4+distance). The sensor sees a broad
            # area, so paying a moderate travel cost prevents 16px oscillation.
            score = gain / (12.0 + cost) - .015 * self.visits
            origin = self.world_to_cell(self.origin if self.origin is not None else position)
            angle = np.arctan2(origin[0] - rr, cc - origin[1])
            preference = 2 * math.pi * self.identifier / self.team_size
            score *= 1.0 + .28 * np.cos(angle - preference)
            reservations = list(self.reservations)
            if not reservations:
                reservations = [(0, p, None, -1) for p in peers if p is not None]
            for age, goal, peer_pos, peer_id in reservations:
                if goal is None or age > 400:
                    continue
                gr, gc = self.world_to_cell(goal)
                squared = (rr - gr) ** 2 + (cc - gc) ** 2
                # Keep the last known assignment after the radio link breaks.
                # Lower identifiers have priority when all choose simultaneously.
                strength = .86 if peer_id < self.identifier else .58
                strength *= max(.25, 1.0 - age / 550.0)
                score *= 1.0 - strength * np.exp(-squared / 65.0)
                if peer_id < self.identifier and age < 80:
                    score[squared < 9] = -np.inf
                if peer_pos is not None:
                    pr, pc = self.world_to_cell(peer_pos)
                    score *= 1.0 - .35 * np.exp(-((rr-pr)**2+(cc-pc)**2) / 36.0)
            self.failed_goals = [(until, point) for until, point in self.failed_goals if until > self.step]
            for _, point in self.failed_goals:
                fr, fc = self.world_to_cell(point)
                score[(rr-fr)**2 + (cc-fc)**2 <= 9] = -np.inf
        score[~reachable] = -np.inf
        if utility is None and destination is None:
            score[start] = -np.inf
        if not np.isfinite(score).any():
            return [], None
        goal = tuple(int(v) for v in np.unravel_index(np.argmax(score), self.shape))
        if utility is None and destination is None:
            if self.exploration_goal is not None:
                previous = self.world_to_cell(self.exploration_goal)
                # Do not switch frontiers because a slightly better one appears.
                # Stop holding when reached, unreachable, or its gain disappears.
                if (np.linalg.norm(np.asarray(position) - self.exploration_goal) > 30 and
                    np.isfinite(score[previous]) and score[previous] >= .72 * score[goal] and
                    self.step - self.last_exploration_goal_step < 180):
                    goal = previous
            if self.exploration_goal is None or self.world_to_cell(self.exploration_goal) != goal:
                self.last_exploration_goal_step = self.step
            self.exploration_goal = self.cell_to_world(goal)
        # Endpoint selection above is unchanged. Whole-map distances still
        # compare every exploration/utility candidate; A* builds the actual
        # execution route to that already chosen endpoint on the same graph.
        astar_cost, parent, astar_stats = astar_grid(walkable, start, goal,
            penalties=np.asarray(penalties).reshape(self.shape))
        record_astar(self, astar_stats, 'coordinated')
        if not np.isfinite(astar_cost[goal]):
            raise RuntimeError('Selected reachable endpoint missing from identical A* graph')
        cells = [goal]
        while cells[-1] != start:
            cells.append(parent[cells[-1]])
        cells.reverse()
        # String-pull through observed, footprint-safe cells. Keep intermediate
        # corners where line of sight is blocked so obstacles are never skipped.
        smooth = [start]
        index = 0
        while index < len(cells) - 1:
            next_index = index + 1
            for lookahead in range(index + 2, len(cells)):
                if not self._visible(cells[index], cells[lookahead], walkable):
                    break
                next_index = lookahead
            smooth.append(cells[next_index])
            index = next_index
        return [self.cell_to_world(c) for c in smooth[1:]], self.cell_to_world(goal)


def holonomic_drive(drone, distances, angles, semantic=()):
    """Translate in any direction, with velocity damping and braking horizon."""
    command = drone._empty_command()
    position = np.asarray(drone.pose, float)
    distances = np.asarray(distances, float).copy()
    angles = np.asarray(angles, float)
    zone = MapMemory.semantic_mask(distances, angles, semantic, ("DISPOSAL_CENTER", "BOMB"))
    distances[zone] = 300.0
    finite = np.isfinite(distances) & (distances > 0)
    if not finite.any():
        return command
    if not hasattr(drone, '_motion_previous_pose'):
        drone._motion_previous_pose = position.copy()
        drone._motion_velocity = np.zeros(2)
    displacement = position - drone._motion_previous_pose
    drone._motion_previous_pose = position.copy()
    if np.linalg.norm(displacement) < 35:
        drone._motion_velocity = .55 * drone._motion_velocity + .45 * displacement
    velocity = feedback_velocity(drone, drone._motion_velocity)
    heading = drone.heading
    absolute_angles = heading + angles
    ray_vectors = np.column_stack((np.cos(absolute_angles), np.sin(absolute_angles)))

    step = int(drone.elapsed_timestep)
    if step < drone.escape_until:
        choices = np.linspace(-math.pi, math.pi, 24, endpoint=False)
        scores = []
        for relative in choices:
            sector = finite & (np.abs((angles-relative+math.pi) % (2*math.pi)-math.pi) < .28)
            scores.append(float(np.percentile(distances[sector], 20)) if sector.any() else 0)
        target_direction = heading + choices[int(np.argmax(scores))]
        target = position + 80 * np.array([math.cos(target_direction), math.sin(target_direction)])
    elif drone.waypoints:
        while len(drone.waypoints) > 1 and np.linalg.norm(drone.waypoints[0] - position) < 22:
            drone.waypoints.pop(0)
        target = np.asarray(drone.waypoints[0], float)
    else:
        choices = np.linspace(-math.pi, math.pi, 24, endpoint=False)
        scores = []
        for relative in choices:
            sector = finite & (np.abs((angles-relative+math.pi) % (2*math.pi)-math.pi) < .24)
            clear = float(np.percentile(distances[sector], 20)) if sector.any() else 0
            absolute = heading + relative
            ahead = position + min(120, clear) * np.array([math.cos(absolute), math.sin(absolute)])
            cell = drone.memory.world_to_cell(ahead)
            origin = drone.memory.origin if getattr(drone.memory, 'origin', None) is not None else position
            preferred = 2 * math.pi * int(drone.identifier or 0) / max(1, getattr(drone, 'team_size', 5))
            radial = math.atan2(ahead[1]-origin[1], ahead[0]-origin[0])
            scores.append(min(clear, 180) - 4 * drone.memory.visits[cell] + 25 * math.cos(radial-preferred))
        absolute = heading + choices[int(np.argmax(scores))]
        target = position + 100 * np.array([math.cos(absolute), math.sin(absolute)])

    delta = target - position
    target_distance = float(np.linalg.norm(delta))
    direction = delta / max(target_distance, 1e-6)
    projection = ray_vectors @ direction
    # The velocity controller needs room to brake against inertia. The narrow
    # collision tube rejects rays off to the side of the travel direction.
    along = distances * projection
    sideways = distances * np.sqrt(np.maximum(0, 1-projection**2))
    in_tube = finite & (projection > 0) & (sideways < 23)
    corridor = float(np.min(along[in_tube])) if in_tube.any() else 300.0
    speed = min(8.0, math.sqrt(max(0.0, .85 * (corridor-26.0))))
    # Slow down for a nearby navigation corner or a placement goal. A final
    # frontier need not be hit exactly because sensor data updates along motion.
    placement_goal = getattr(drone, 'placement_goal', None)
    if (step >= drone.escape_until and placement_goal is not None and
        np.linalg.norm(position - placement_goal) < getattr(drone, 'placement_arrival_radius', 20) and
        getattr(drone, '_placement_allowed', lambda *_: True)(step, semantic)):
        speed = 0.0
    else:
        speed = min(speed, max(.6, math.sqrt(max(0, .65 * (target_distance - 8)))))
    desired_velocity = direction * speed
    # Close obstacles repel in world coordinates, independently of drone yaw.
    close = finite & (distances < 34)
    if close.any():
        repulsion = np.sum(ray_vectors[close] * ((34-distances[close]) / 10)[:, None], axis=0)
        desired_velocity -= .20 * repulsion
    acceleration = .48 * (desired_velocity - .95 * velocity)
    norm = float(np.linalg.norm(acceleration))
    acceleration /= max(1.0, norm)
    c, s = math.cos(heading), math.sin(heading)
    command['forward'] = float(c * acceleration[0] + s * acceleration[1])
    command['lateral'] = float(-s * acceleration[0] + c * acceleration[1])
    # Full 360 degree lidar means yaw is not required to translate or map.
    command['rotation'] = 0.0
    return command


class ExplorationMotionMixin:
    """Drop-in coordinator; placement and submission rules stay inherited."""

    def __init__(self, identifier=None, misc_data=None, **kwargs):
        super().__init__(identifier=identifier, misc_data=misc_data, **kwargs)
        self.memory = CoordinatedMapMemory(*self.size_area, identifier=int(identifier or 0),
                                           team_size=getattr(self, 'team_size', 5))
        self.exploration_records = {}

    def define_message_for_all(self):
        message = super().define_message_for_all()
        records = dict(self.exploration_records)
        records[int(self.identifier or 0)] = (int(self.elapsed_timestep),
            None if self.pose is None else self.pose.copy(),
            None if self.goal is None else np.asarray(self.goal).copy())
        message['exploration_records'] = records
        return message

    def _messages(self):
        super()._messages()
        step = int(self.elapsed_timestep)
        for _, message in self.communicator.received_messages:
            if not isinstance(message, dict) or message.get('kind') != 'greedy-map-v1':
                continue
            for peer, record in message.get('exploration_records', {}).items():
                if not isinstance(record, (tuple, list)) or len(record) != 3:
                    continue
                ts, position, goal = record
                peer = int(peer)
                if peer == int(self.identifier or 0) or int(ts) <= self.exploration_records.get(peer, (-1,))[0]:
                    continue
                valid = all(point is None or (np.asarray(point).shape == (2,) and
                            np.isfinite(np.asarray(point, float)).all()) for point in (position, goal))
                if valid:
                    self.exploration_records[peer] = (int(ts), position, goal)
        self.memory.step = step
        if self.rally is not None:
            self.memory.origin = self.rally.copy()
        self.memory.reservations = [(step-ts, goal, position, peer)
                                   for peer, (ts, position, goal) in self.exploration_records.items()
                                   if step-ts < 400]
        # Stuck recovery also suppresses the same unreachable frontier.
        if self.stuck_steps >= 30:
            self.memory.reject_goal(self.pose)

    def _drive(self, distances, angles, semantic=()):
        return holonomic_drive(self, distances, angles, semantic)
