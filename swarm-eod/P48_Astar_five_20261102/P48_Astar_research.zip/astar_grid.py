"""Exact A* for the existing directed eight-neighbour navigation graph."""
import heapq
import math
import time
import numpy as np


def astar_grid(walkable, start, goal, penalties=None, diagonal=math.sqrt(2.0)):
    """Return distance array, parent cells, and search-only diagnostics.

    Destination-dependent nonnegative clearance costs are unchanged. Octile
    distance ignores these extra penalties and is an admissible consistent h.
    When goal is unreachable the queue exhausts: the old fallback receives a
    complete reachable distance field, rather than an invented direct path.
    """
    began = time.perf_counter()
    allowed = np.asarray(walkable, dtype=bool)
    height, width = allowed.shape
    sr, sc = (int(v) for v in start)
    gr, gc = (int(v) for v in goal)
    if not (0 <= sr < height and 0 <= sc < width and 0 <= gr < height and 0 <= gc < width):
        raise ValueError('A* endpoints outside graph')
    if not (1.0 <= diagonal <= 2.0):
        raise ValueError('octile diagonal outside consistent metric range')
    weights = np.zeros(allowed.shape, dtype=float) if penalties is None else np.asarray(penalties, dtype=float)
    if weights.shape != allowed.shape or not np.isfinite(weights).all() or np.any(weights < 0):
        raise ValueError('A* requires finite nonnegative existing clearance penalties')
    def heuristic(row, col):
        dr, dc = abs(row - gr), abs(col - gc)
        return max(dr, dc) + (diagonal - 1.0) * min(dr, dc)
    costs = np.full(allowed.shape, np.inf)
    costs[sr, sc] = 0.0
    parents = {}
    queue = [(heuristic(sr, sc), 0.0, sr * width + sc)]
    expanded = 0
    while queue:
        _, distance, node = heapq.heappop(queue)
        row, col = divmod(node, width)
        if distance > costs[row, col]:
            continue
        expanded += 1
        if (row, col) == (gr, gc):
            break
        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1)):
            nr, nc = row + dr, col + dc
            if not (0 <= nr < height and 0 <= nc < width) or not allowed[nr, nc]:
                continue
            if dr and dc and (not allowed[row + dr, col] or not allowed[row, col + dc]):
                continue
            edge = (diagonal if dr and dc else 1.0) * (1.0 + weights[nr, nc])
            trial = distance + edge
            if trial < costs[nr, nc]:
                costs[nr, nc] = trial
                parents[(nr, nc)] = (row, col)
                heapq.heappush(queue, (trial + heuristic(nr, nc), trial, nr * width + nc))
    return costs, parents, dict(expanded=expanded, reached=bool(np.isfinite(costs[gr, gc])), seconds=time.perf_counter() - began)


def record_astar(memory, stats, layer):
    """Own-instance counters only. These never enter a control decision."""
    root = getattr(memory, '_memory', memory)
    totals = getattr(root, 'astar_statistics', None)
    if totals is None:
        totals = dict(calls=0, expanded=0, seconds=0.0, coordinated_calls=0, geometry_calls=0, unreachable=0)
        root.astar_statistics = totals
    totals['calls'] += 1
    totals['expanded'] += int(stats['expanded'])
    totals['seconds'] += float(stats['seconds'])
    totals[layer + '_calls'] += 1
    totals['unreachable'] += int(not stats['reached'])
