from swarm_rescue.solutions.corner_cluster import corner_cluster_layout
"""Compatibility entry for the active route-column coverage planner."""
import math
import numpy as np
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
from swarm_rescue.solutions.farthest_wall_cover import owner_travel_budget
from swarm_rescue.solutions.team_coverage import observed_wall_values,path_costs,plan_team_coverage as _greedy_plan

from swarm_rescue.solutions.trust_region_cover import refine_trust_region

def _prefix_budget_context(memory,agents,drops,radius,travel_budget,prefixes):
    """Account a received reserved prefix on the same nominal suffix graph."""
    prepared=GeometryPlanningMemory(memory)
    _,solids=observed_wall_values(prepared,radius,return_solids=True)
    walkable=prepared.free & ~prepared.blocked() & ~solids
    budgets={int(k):owner_travel_budget(travel_budget,k) for k in agents}
    if any(math.isnan(b) or b<0 for b in budgets.values()):
        raise ValueError('invalid reserved-prefix budget')
    fields={};records=[]
    for key,(start,count) in agents.items():
        owner=int(key)
        if int(count)<=0 or owner not in prefixes:
            continue
        position,target=(np.asarray(p,float) for p in prefixes[owner])
        valid=(position.shape==(2,) and target.shape==(2,) and
               np.isfinite(position).all() and np.isfinite(target).all() and
               np.asarray(start).shape==(2,) and
               np.array_equal(np.asarray(start,float),target))
        distance=math.inf
        if valid:
            source=tuple(int(v) for v in prepared.world_to_cell(position))
            goal=tuple(int(v) for v in prepared.world_to_cell(target))
            valid=all(0<=r<prepared.shape[0] and 0<=c<prepared.shape[1]
                      and walkable[r,c] for r,c in [source,goal])
            if valid:
                if source not in fields:
                    fields[source]=path_costs(prepared,walkable,source)
                distance=float(fields[source][goal])
        reachable=math.isfinite(distance) and distance>=0
        before=budgets[owner]
        budgets[owner]=max(0.,before-distance) if reachable else 0.
        records.append({'owner':owner,'prefix_distance':distance if reachable else None,
                        'reachable':reachable,'before':before,'suffix_budget':budgets[owner]})
    memory.reserved_prefix_budget_diagnostics={'owners':records,'fields':len(fields)}
    logs=getattr(memory,'_reserved_prefix_budget_logs',0)
    if any(not r['reachable'] or r['prefix_distance']>0 for r in records) and logs<8:
        print('[reserved-prefix-budget]',int(getattr(memory,'identifier',0)),
              int(getattr(memory,'step',0)),{'owners':records,'fields':len(fields)},flush=True)
        memory._reserved_prefix_budget_logs=logs+1
    return prepared,budgets


def plan_team_coverage_lns(memory, agents, drops, radius, travel_budget=None, quality_tolerance=0.92, forbidden_points=(), forbidden_mask=None, search_seed=None, deadline_pressure=0.0, reserved_prefixes=None):
    prepared=None
    if reserved_prefixes:
        prepared,travel_budget=_prefix_budget_context(memory,agents,drops,radius,travel_budget,reserved_prefixes)
    base=_greedy_plan(memory, agents, drops, radius, travel_budget=travel_budget, quality_tolerance=quality_tolerance, forbidden_points=forbidden_points, forbidden_mask=forbidden_mask, deadline_pressure=deadline_pressure,_prepared=prepared)
    refined=refine_trust_region(memory,agents,drops,radius,base,travel_budget=travel_budget,forbidden_points=forbidden_points,forbidden_mask=forbidden_mask,_prepared=prepared)
    return corner_cluster_layout(memory,agents,drops,radius,refined,travel_budget,forbidden_points,forbidden_mask,_prepared=prepared)
