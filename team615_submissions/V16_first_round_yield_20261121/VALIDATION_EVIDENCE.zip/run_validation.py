from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parent
host='quanliangwen@10.112.162.60'
remote=(root/'REMOTE_STAGE.txt').read_text().strip()
subprocess.run(['ssh','-o','BatchMode=yes',host,'mkdir '+remote],check=True)
for name in ['team615_red_v16.zip','BUILD.json','WORKSPACE_BINDING_FIRST.json','run_release_validation.py','probe_release.py']:
    subprocess.run(['scp','-q','-o','BatchMode=yes',str(root/name),host+':'+remote+'/'],check=True)
print('Running release probes only; no controller frames or full matches.',flush=True)
result=subprocess.run(['ssh','-o','BatchMode=yes',host,
    'PYTHONDONTWRITEBYTECODE=1 /home/junhao/quan/parallel_test_solver/match/.venv/bin/python -B '+
    remote+'/run_release_validation.py'],capture_output=True)
(root/'REMOTE_COORDINATOR.log').write_bytes(result.stdout+b'\n'+result.stderr)
print(result.stdout.decode(errors='replace'),flush=True)
print(result.stderr.decode(errors='replace'),flush=True)
collected=subprocess.run(['scp','-q','-o','BatchMode=yes',host+':'+remote+'/*.json',str(root)],capture_output=True)
logs=subprocess.run(['scp','-q','-o','BatchMode=yes',host+':'+remote+'/*.log',str(root)],capture_output=True)
assert collected.returncode==0,collected.stderr
if logs.returncode:print(logs.stderr.decode(errors='replace'),flush=True)
print('Validation exit:',result.returncode,flush=True)
sys.exit(result.returncode)
