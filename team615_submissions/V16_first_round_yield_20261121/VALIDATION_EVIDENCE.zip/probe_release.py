"""Fresh probes of the exact release archive, in the three established SDK stacks."""
from pathlib import Path
from hashlib import sha256
import importlib.abc
import importlib.metadata as md
import json
import sys
import subprocess

release=Path(__file__).resolve().parent
label=sys.argv[1]
host=Path("/home/junhao/quan/parallel_test_solver/match")
sdk=release/"actual_zip_workspace"
shared=host/".venv/lib/python3.11/site-packages"
isolated=host/"solver_study/framework_screen_20261016/best87_independent_20261025/P48_v09_release_validation_20261102"
numeric=shared if label=="native_main" else isolated/f"env_{label}/lib/python3.11/site-packages"
assert sys.executable==str(host/".venv/bin/python") and numeric.is_dir()
assert not any(name in sys.modules for name in ("numpy","pandas","cv2"))
sys.path[:]=[str(numeric),str(sdk/"src")]+[p for p in sys.path if "site-packages" not in p]+(
    [str(shared)] if shared!=numeric else [])

class NoGurobi(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split(".",1)[0]=="gurobipy":
            raise ImportError("Gurobi blocked for R574 release validation")
sys.meta_path.insert(0,NoGurobi())

import cv2
import elkai
import numpy as np
import numpy.random.mtrand as mtrand
import pandas as pd
import scipy
from scipy.ndimage import label as components
from scipy.optimize import Bounds, milp
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import dijkstra
import yaml
from swarm_rescue.launcher import Launcher
from swarm_rescue.maps.map_08 import Map08
from swarm_rescue.simulation.elements.sensor_disablers import ZoneType
from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
from swarm_rescue.simulation.reporting.team_info import TeamInfo
from swarm_rescue.simulation.reporting.evaluation import EvalConfig
from swarm_rescue.simulation.reporting.team_mode import TeamMode
from swarm_rescue.simulation.utils import constants as C
from swarm_rescue.solutions.my_drone_eval import drone_class_for_mode
from swarm_rescue.solutions.red_hooks import RedHooks

build=json.loads((release/"BUILD.json").read_bytes())
binding=json.loads((release/"WORKSPACE_BINDING_FIRST.json").read_bytes())
payload=build["payload_files_sha256"]
source=sdk/"src/swarm_rescue/solutions"
assert sha256((release/"team615_red_v16.zip").read_bytes()).hexdigest()==build["submission_zip_sha256"]
for name,wanted in payload.items():
    p=sdk/"req.txt" if name=="req.txt" else source/name
    assert sha256(p.read_bytes()).hexdigest()==wanted
for name,wanted in binding["sdk_files"].items():
    if name!="req.txt":
        assert sha256((sdk/name).read_bytes()).hexdigest()==wanted,(name,label)

assert np.isfinite(mtrand.RandomState(615).normal(size=128)).all()
assert np.isfinite(np.random.default_rng(615).normal(size=128)).all()
assert pd.DataFrame({"value":[1.,2.,3.]}).value.sum()==6.
sample=np.eye(4,dtype=np.uint8)
assert cv2.countNonZero(cv2.bitwise_and(sample,sample))==4
assert components(np.eye(3))[1]==3
assert dijkstra(csr_matrix(np.array([[0,2],[2,0]])),indices=0)[1]==2
tiny=milp(c=np.array([1.]),integrality=np.array([1]),bounds=Bounds([.2],[2.]))
assert tiny.success and tiny.x[0]==1.
tour=elkai.DistanceMatrix([[0,3,4,5],[3,0,3,4],[4,3,0,3],[5,4,3,0]]).solve_tsp(runs=1)
assert set(tour)==set(range(4))

team=yaml.safe_load((source/"team_info.yml").read_bytes())
assert type(team["team_number"]) is int and team["team_number"]==615
assert type(TeamInfo().team_number) is int and TeamInfo().team_number==615
assert drone_class_for_mode("place") is RedHooks
from types import SimpleNamespace
from swarm_rescue.solutions.second_drop_site import SecondDropSite
assert np.allclose(SecondDropSite._velocity_from_odometry(SimpleNamespace(heading=np.pi/2), (4., 0., 0.)), (0., 4.))
assert (C.MAX_RANGE_LIDAR_SENSOR,C.MAX_RANGE_SEMANTIC_SENSOR,C.RANGE_COMMUNICATION,C.DRONE_INITIAL_HEALTH)==(230,130,180,25)
zones=(ZoneType.NO_GPS_ZONE,ZoneType.NO_COM_ZONE)
arena=Map08(drone_type=RedHooks,zones_config=zones,number_drones=5)
try:
    config=EvalConfig(map_name="Map08",zones_config=zones,number_drones=5,initial_bombs_per_drone=2,nb_rounds=1)
    Launcher._configure_map_for_team(SimpleNamespace(_resolve_bombs_file=lambda c:None),arena,config,TeamMode.PLACE)
    drones=arena.drones
    assert len(drones)==len({id(d.memory.hits) for d in drones})==len({id(d.placement) for d in drones})==5
    assert all(type(d) is RedHooks and d.drone_health==25 and d.carried_bombs_count()==2 for d in drones)
    assert (arena.max_timestep_limit,arena.max_walltime_limit)==(5400,180)
    assert (sum(type(e).__name__=="NoGpsZone" for e in arena.playground.elements),
            sum(type(e).__name__=="NoComZone" for e in arena.playground.elements))==(2,0)
finally:
    arena.playground.cleanup()
    arena.playground.close_window()

assert "gurobipy" not in sys.modules
for name,module in tuple(sys.modules.items()):
    if name.startswith("swarm_rescue.") and getattr(module,"__file__",None):
        path=Path(module.__file__).resolve()
        assert path.is_relative_to((sdk/"src").resolve()),(name,str(path))
        if name.startswith("swarm_rescue.solutions."):
            assert sha256(path.read_bytes()).hexdigest()==payload[path.name]
paths={n:m.__file__ for n,m in (("numpy",np),("numpy.random.mtrand",mtrand),("pandas",pd),("cv2",cv2),("scipy",scipy),("elkai",elkai))}
assert all(Path(paths[n]).resolve().is_relative_to(numeric.resolve()) for n in ("numpy","numpy.random.mtrand","pandas","cv2"))
assert all(any(Path(paths[n]).resolve().is_relative_to(q.resolve()) for q in (numeric,shared)) for n in ("scipy","elkai"))
dist={n:md.version(n) for n in ("numpy","pandas","opencv-contrib-python","scipy","elkai")}
expected={
    "native_main":("1.26.4","3.0.6"),"numpy1":("1.26.4","2.2.3"),"numpy2":("2.2.6","2.2.3")}
assert (dist["numpy"],dist["pandas"])==expected[label]
assert dist["opencv-contrib-python"]=="4.11.0.86" and dist["elkai"]=="2.0.1"

dry_path=release/f"INSTALL_DRY_RUN_{label}.json"
bootstrap=[str(numeric)]+[p for p in sys.path if "site-packages" not in p and p!=str(sdk/"src")]
for item in (shared,isolated/"env_numpy1/lib/python3.11/site-packages"):
    if str(item) not in bootstrap:
        bootstrap.append(str(item))
arguments=["pip","install","--dry-run","--no-index","--disable-pip-version-check","--report",
           str(dry_path),"-r",str(sdk/"req.txt")]
code=f"import sys,runpy;sys.path[:]={bootstrap!r};sys.argv={arguments!r};runpy.run_module('pip',run_name='__main__')"
dry=subprocess.run([sys.executable,"-I","-S","-c",code],capture_output=True,text=True,timeout=75)
(release/f"INSTALL_DRY_RUN_{label}.log").write_text(dry.stdout+"\n"+dry.stderr,encoding="utf-8")
assert dry.returncode==0,dry.stdout+dry.stderr
assert json.loads(dry_path.read_bytes()).get("install",[])==[]
results=dict(status="PASS",label=label,submission_zip_sha256=build["submission_zip_sha256"],
             payload_files_sha256=payload,distribution_versions=dist,critical_module_paths=paths,
             declared_numeric_root=str(numeric),python=sys.version,executable=sys.executable,
             team_number=615,real_numeric_operations=True,scipy_and_elkai_operations=True,
             sdk_launcher_and_stats_import=True,red_entry=True,independent_sdk_drones=5,
             odometry_helper_probe=True,no_gurobi=True,installation_dry_run=dict(status="PASS",install=[]),
             reused_environments_read_only=True,SDK_frames=0,native_rounds=0)
(release/f"ABI_{label}.json").write_text(json.dumps(results,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(label,dist,flush=True)

