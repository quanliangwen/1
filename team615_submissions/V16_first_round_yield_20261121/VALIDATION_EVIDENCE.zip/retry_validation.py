from pathlib import Path
import subprocess
import sys

r=Path(__file__).resolve().parent
h='quanliangwen@10.112.162.60'
remote=(r/'REMOTE_STAGE.txt').read_text().strip()
subprocess.run(['scp','-q','-o','BatchMode=yes',str(r/'run_release_validation.py'),h+':'+remote+'/'],check=True)
result=subprocess.run(['ssh','-o','BatchMode=yes',h,
    'PYTHONDONTWRITEBYTECODE=1 /home/junhao/quan/parallel_test_solver/match/.venv/bin/python -B '+remote+'/run_release_validation.py'],capture_output=True)
(r/'REMOTE_COORDINATOR_RETRY.log').write_bytes(result.stdout+b'\n'+result.stderr)
print(result.stdout.decode(errors='replace'),flush=True)
print(result.stderr.decode(errors='replace'),flush=True)
for glob in ['*.json','*.log']:
    subprocess.run(['scp','-q','-o','BatchMode=yes',h+':'+remote+'/'+glob,str(r)],check=True)
sys.exit(result.returncode)
