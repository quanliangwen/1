from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile, ZIP_DEFLATED
from copy import deepcopy
import json
import shutil
import subprocess
from check_submission_zip import inspect_package, PROFILE, EXPECTED_SHA

r=Path(__file__).resolve().parent
def load(path):return json.loads(path.read_bytes())
def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
build=load(r/'BUILD.json')
assert load(r/'STATUS.json')['status']=='ABI_AND_OFFICIAL_STATIC_PASS'
assert sha256((r/'team615_red_v16.zip').read_bytes()).hexdigest()==EXPECTED_SHA
history=dict(submission_zip_sha256=EXPECTED_SHA,new_runs_for_release=0,maps={})
for name,folder,analysis in [
    ('Map06',Path('E:/codex/team615_first_round_yield_map06_20261121'),'ANALYSIS.json'),
    ('Map08',Path('E:/codex/team615_first_round_yield_maps_20261121'),'ANALYSIS.json'),
    ('Map09',Path('E:/codex/team615_first_round_yield_maps_20261121'),'ANALYSIS.json')]:
    assert load(folder/'BUILD.json')['candidate_zip_sha256']==EXPECTED_SHA
    table=load(folder/analysis)
    arm=(table if name=='Map06' else table[name])['arms']['candidate']
    score_path=folder/name/'received/OFFICIAL_SCORE.json'
    score=load(score_path)
    assert abs(score['partial']-arm['partial_score_out_of_80'])<1e-10
    assert score['steps']==arm['submission_step'] and score['placed']==arm['placed']==10
    history['maps'][name]=dict(seed=615,placed=arm['placed'],score_out_of_80=arm['partial_score_out_of_80'],
        map_score=arm['map_score'],submission_step=arm['submission_step'],selected_drone=arm['selected_submission']['drone'],
        exploration_percent=arm['exploration_percent'],total_health_lost=arm['total_health_lost'],
        elapsed_walltime_seconds=arm['elapsed_walltime_seconds'],
        official_score_sha256=sha256(score_path.read_bytes()).hexdigest(),
        published_report=('https://github.com/quanliangwen/1/tree/8f6ef6427aa54e372b58462d42d1bf496856621a/team615_red_v15/first_round_yield_map06_20261121'
                          if name=='Map06' else 'https://github.com/quanliangwen/1/tree/cb079a122091ddee1f14e5bba4327260e91e82b3/team615_red_v15/first_round_yield_maps_20261121'))
save(r/'EXISTING_TEST_RESULTS.json',history)
proof=dict(status='PASS',dependency_profile=PROFILE,submission_zip_sha256=EXPECTED_SHA,
    payload_files_sha256=build['payload_files_sha256'],team_number=615,
    abi_runs={key:load(r/f'ABI_{key}.json') for key in ('numpy1','numpy2','native_main')},
    official_static_check=load(r/'OFFICIAL_STATIC_CHECK.json'),existing_three_map_history=history,
    official_container_verified=False,new_full_matches=0,
    release_scope='Byte-identical promotion of the tested first-round 30-step yield candidate; filename only.',
    validation_boundary='Three existing numerical stacks reused read-only. SDK constructors only, zero controller/physics frames. No official container or website test.',
    coordinator_retry='First attempt failed before probes because shared lock was opened writable. Retry acquired the same inode exclusively read-only; private scheduler registry was not accessed, and no scheduler/match invoked.',
    shared_guard_unchanged_sha256=sha256(Path('E:/codex/swarm-submission-guard/check_submission_zip.py').read_bytes()).hexdigest())
save(r/'RELEASE_ABI_RECEIPT.json',proof)
subprocess.run(['python','-B',str(r/'check_submission_zip.py'),str(r/'team615_red_v16.zip'),
    '--dependency-profile',PROFILE,'--abi-receipt',str(r/'RELEASE_ABI_RECEIPT.json'),
    '--output',str(r/'RELEASE_CHECK.json')],check=True,capture_output=True)
assert load(r/'RELEASE_CHECK.json')['status']=='PASS'
negative=[]
def reject(label,change=None,missing=False,zip_path=None):
    trial=deepcopy(proof)
    if change:change(trial)
    path=r/'NEGATIVE_RECEIPT.json'
    save(path,trial)
    try:inspect_package(zip_path or r/'team615_red_v16.zip',None if missing else path)
    except (ValueError,FileNotFoundError) as error:negative.append(dict(case=label,status='PASS_REJECTED',reason=str(error)))
    else:raise AssertionError('Must reject '+label)
reject('missing receipt',missing=True)
reject('wrong archive binding',lambda p:p.update(submission_zip_sha256='0'*64))
reject('wrong payload',lambda p:p['payload_files_sha256'].update({'group_exchange.py':'0'*64}))
reject('missing NumPy2 stack',lambda p:p['abi_runs'].pop('numpy2'))
reject('failed numeric operation',lambda p:p['abi_runs']['numpy1'].update(real_numeric_operations=False))
reject('dependency replacement',lambda p:p['abi_runs']['numpy2']['installation_dry_run'].update(install=[{'name':'numpy'}]))
reject('only four constructors',lambda p:p['abi_runs']['native_main'].update(independent_sdk_drones=4))
reject('official static failure',lambda p:p['official_static_check'].update(status='FAIL'))
negative_dir=r/'negative_case'
negative_dir.mkdir(exist_ok=True)
altered=negative_dir/'team615_red_v16.zip'
altered.write_bytes((r/'team615_red_v16.zip').read_bytes()+b'altered')
reject('changed archive bytes',zip_path=altered)
save(r/'NEGATIVE_CHECKS.json',dict(status='PASS',cases=negative))
delivery=r/'delivery'
delivery.mkdir(exist_ok=True)
for name in ['team615_red_v16.zip','RELEASE_ABI_RECEIPT.json','RELEASE_CHECK.json','EXISTING_TEST_RESULTS.json']:
    shutil.copyfile(r/name,delivery/name)
save(delivery/'SOURCE_MANIFEST.json',build)
readme='''# team615 红队比赛提交版 V16

推荐上传文件：`team615_red_v16.zip`。请下载这个 ZIP 原文件，再上传比赛平台；不要上传整个 GitHub 仓库的 Source code ZIP、证据包或分析报告，也不必自行解压重新压缩。

这是用户选定的“首轮30步让行候选”的正式命名提交包，完整 ZIP 与种子615的 Map06、Map08、Map09实测候选逐字节一致。只改变外部文件名，不修改算法、依赖或 ZIP 内部字节，不包含随后提出的确认重连方案。

SHA256：`e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791`

根目录56个文件，含54个Python源码，以及`team_info.yml`、`req.txt`。整数队号615，入口`my_drone_eval.py`中的`drone_class_for_mode("place")`返回`RedHooks`。不含SDK、地图、日志、虚拟环境、二进制库或测试脚本。

保留首轮30步让行、0.003近分优先新图、6步提交时间槽、Map09缓存更新、个人原图保护、投放确认及步数/墙钟双兜底。导航与地图拟合保持实测版本原样。

## 已有实测结果（不是本次新跑）

| 地图 | 种子 | 红队小计/80 | 地图分 | 交图者/步数 | 实投 |
|---|---:|---:|---:|---|---:|
| Map06 | 615 | 53.913950 | 89.156880 | 0号/5082，墙钟兜底 | 10 |
| Map08 | 615 | 52.641344 | 77.189215 | 1号/3452，正常交图 | 10 |
| Map09 | 615 | 43.098186 | 66.030348 | 0号/4774，墙钟兜底 | 10 |

Map06、Map09缺队伍末弹清零确认而使用墙钟兜底的行为仍保留。历史分数不是官网新测成绩，也不是全地图或多种子的收益保证。详细已有证据链接见`EXISTING_TEST_RESULTS.json`。

## 本次发布检查

从最终ZIP新解包，三组完整数值组合重新检查通过：NumPy1.26.4/Pandas2.2.3、NumPy2.2.6/Pandas2.2.3、NumPy1.26.4/Pandas3.0.6；均配OpenCV contrib4.11.0.86、SciPy1.17.1、elkai2.0.1。实际mtrand/随机数、Pandas、OpenCV、SciPy、elkai运算、SDK Launcher/Stats、红队入口、整数队号和五机独立构造通过；安装预演没有要求替换依赖，未安装或修改既有环境。

这些环境为只读复用后本次重新执行检查，不是新装环境或官网容器。官方内容检查仅使用同SHA的`team615_semifinal.zip`内部审计别名；最终供用户上传的文件名仍为`team615_red_v16.zip`。最终V16专用发布检查及9个拒绝错误包/回执的反例通过，共享旧版检查器未改。

本次只做包装与发布检查，0个控制/物理帧，0场新比赛。没有上传比赛官网、没有官网容器验证。相关回执绑定本ZIP及每个成员的SHA256；改变任何内部文件后都需重新检查。

`VALIDATION_EVIDENCE.zip`只用于审计，不是比赛提交包。
'''
(delivery/'README.md').write_text(readme,encoding='utf8')
with ZipFile(delivery/'VALIDATION_EVIDENCE.zip','w',compression=ZIP_DEFLATED) as archive:
    for name in ['BUILD.json','WORKSPACE_BINDING_FIRST.json','prepare_release.py','run_validation.py',
                 'retry_validation.py','run_release_validation.py','probe_release.py','check_submission_zip.py',
                 'finalize_release.py','REMOTE_COORDINATOR.log','REMOTE_COORDINATOR_RETRY.log',
                 'NEGATIVE_CHECKS.json','STATUS.json','OFFICIAL_STATIC_CHECK.json','OFFICIAL_STATIC_FIRST.log']:
        archive.write(r/name,name)
    for key in ('numpy1','numpy2','native_main'):
        for name in [f'ABI_{key}.json',f'PROBE_{key}.log',f'INSTALL_DRY_RUN_{key}.json',f'INSTALL_DRY_RUN_{key}.log']:
            archive.write(r/name,name)
manifest={p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(delivery.iterdir()) if p.is_file() and p.name not in ('CHECKSUMS_SHA256.json','SHA256SUMS.txt')}
save(delivery/'CHECKSUMS_SHA256.json',manifest)
(delivery/'SHA256SUMS.txt').write_text(''.join(h+'  '+n+'\n' for n,h in manifest.items()),encoding='utf8')
print(json.dumps(dict(status='PASS',submission_zip_sha256=EXPECTED_SHA,release_checks=len(load(r/'RELEASE_CHECK.json')['checks']),negative_cases=len(negative),files=len(list(delivery.iterdir()))),indent=2))
