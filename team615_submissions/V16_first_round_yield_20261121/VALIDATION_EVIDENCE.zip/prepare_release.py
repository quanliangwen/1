from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import ast
import json
import subprocess

root = Path(__file__).resolve().parent
source = Path('E:/codex/team615_first_round_yield_20261121')
host = 'quanliangwen@10.112.162.60'
server_root = '/home/junhao/quan/parallel_test_solver/match'
study = server_root + '/solver_study/framework_screen_20261016/best87_independent_20261025'
remote = study + '/team615_red_v16_first30_release_20261121'
previous = study + '/R574_team615_red_v15_release_20261116_retry_final'
sealed = study + '/P407_P398_semifinal_three_maps_20261110'
expected = 'e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791'

def run(args):
    return subprocess.run(args, check=True, capture_output=True)

instructions = run(['ssh','-o','BatchMode=yes',host,
    'for p in /home/AGENTS.md /home/junhao/AGENTS.md /home/junhao/quan/AGENTS.md '
    '/home/junhao/quan/parallel_test_solver/AGENTS.md ' + server_root + '/AGENTS.md ' +
    server_root + '/solver_study/AGENTS.md ' + server_root + '/solver_study/framework_screen_20261016/AGENTS.md ' +
    study + '/AGENTS.md; do if test -f "$p"; then printf "\\n%s\\n" "$p"; cat "$p"; fi; done; cat ' +
    server_root + '/run_server.sh'])
(root/'SERVER_INSTRUCTIONS.txt').write_bytes(instructions.stdout)
print(instructions.stdout.decode(errors='replace'))

raw = (source/'candidate_snapshot.zip').read_bytes()
assert sha256(raw).hexdigest() == expected
package = root/'team615_red_v16.zip'
assert not package.exists() or package.read_bytes() == raw
package.write_bytes(raw)
with ZipFile(package) as archive:
    assert archive.testzip() is None
    names = archive.namelist()
    assert len(names) == len(set(names)) == 56
    assert all('/' not in n and '\\' not in n for n in names)
    hashes = {n:sha256(archive.read(n)).hexdigest() for n in names}
    assert hashes == json.loads((source/'BUILD.json').read_bytes())['candidate_files']
    for name in names:
        assert (source/'candidate'/name).read_bytes() == archive.read(name)
        if name.endswith('.py'):
            ast.parse(archive.read(name), filename=name)
for path in [Path('E:/codex/team615_first_round_yield_maps_20261121/BUILD.json'),
             Path('E:/codex/team615_first_round_yield_map06_20261121/BUILD.json')]:
    assert json.loads(path.read_bytes())['candidate_zip_sha256'] == expected
for filename in ['run_release_validation.py','probe_release.py']:
    text = run(['ssh','-o','BatchMode=yes',host,'cat '+previous+'/'+filename]).stdout.decode('utf8')
    text = text.replace('team615_red_v15.zip','team615_red_v16.zip')
    (root/filename).write_text(text,encoding='utf8')
binding_raw = run(['ssh','-o','BatchMode=yes',host,'cat '+sealed+'/WORKSPACE_BINDING_FIRST.json']).stdout
assert sha256(binding_raw).hexdigest() == '8a6310cdfccb0bc3c76ee4f4b6d1ab69bd6634f881f3268fb78b6302d8d77585'
(root/'WORKSPACE_BINDING_FIRST.json').write_bytes(binding_raw)
build = dict(version='V16',candidate='first-round 30-step yield',submission_zip_sha256=expected,
             payload_files_sha256=hashes,sdk_commit='6557940dc18549ffc7a945db887da5b05b7ed2f1',
             sdk_binding_sha256=sha256(binding_raw).hexdigest(),algorithm_or_dependencies_changed=False,
             whole_archive_byte_identical_to_three_tested_candidate=True,
             source_path=str(source/'candidate_snapshot.zip'),new_full_matches=0,
             github_destination='https://github.com/quanliangwen/1')
(root/'BUILD.json').write_text(json.dumps(build,indent=2)+'\n',encoding='utf8')
(root/'REMOTE_STAGE.txt').write_text(remote+'\n',encoding='utf8')
print(json.dumps(dict(zip=str(package),sha256=expected,members=56,python_sources=sum(n.endswith('.py') for n in names)),indent=2))
