from pathlib import Path
import subprocess
import sys

r=Path(__file__).resolve().parent
h='quanliangwen@10.112.162.60'
remote=(r/'REMOTE_STAGE.txt').read_text().strip()
subprocess.run(['ssh','-o','BatchMode=yes',h,'mkdir '+remote],check=True)
for name in ['team615_red_v17.zip','baseline_v16.zip','BUILD.json','WORKSPACE_BINDING_FIRST.json',
             'run_release_validation.py','probe_release.py','counterexamples.py','counterexample_driver.py',
             'OFFICIAL_TIMESTAMP_FIXTURES.json']:
    subprocess.run(['scp','-q','-o','BatchMode=yes',str(r/name),h+':'+remote+'/'],check=True)
result=subprocess.run(['ssh','-o','BatchMode=yes',h,
    'PYTHONDONTWRITEBYTECODE=1 /home/junhao/quan/parallel_test_solver/match/.venv/bin/python -B '+
    remote+'/counterexample_driver.py'],capture_output=True)
(r/'COUNTEREXAMPLE_DRIVER.log').write_bytes(result.stdout+b'\n'+result.stderr)
for name in ['counterexamples.log','counterexamples.json']:
    subprocess.run(['scp','-q','-o','BatchMode=yes',h+':'+remote+'/'+name,str(r/name)],check=False)
print(result.stdout.decode(errors='replace'),flush=True)
print(result.stderr.decode(errors='replace'),flush=True)
if result.returncode:
    print((r/'counterexamples.log').read_text(encoding='utf8')[-4500:],flush=True)
sys.exit(result.returncode)
