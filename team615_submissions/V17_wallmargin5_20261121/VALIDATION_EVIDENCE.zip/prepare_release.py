from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
from io import BytesIO
import ast
import difflib
import json
import shutil
import struct

r=Path(__file__).resolve().parent
parent=Path('E:/codex/team615_red_v16_first30_release_20261121')
old=parent/'delivery/team615_red_v16.zip'
old_sha='e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791'
assert sha256(old.read_bytes()).hexdigest()==old_sha
new=r/'team615_red_v17.zip'
assert not new.exists(),'Never overwrite an existing release archive'
shutil.copyfile(old,r/'baseline_v16.zip')
with ZipFile(old) as before,ZipFile(new,'w') as after:
    for info in before.infolist():
        data=before.read(info.filename)
        if info.filename=='deadline_submission.py':
            needle=b'    MIN_WALL_MARGIN = 1.5'
            assert data.count(needle)==1
            data=data.replace(needle,b'    MIN_WALL_MARGIN = 5.0')
        after.writestr(info,data)
with ZipFile(old) as before,ZipFile(new) as after:
    names=before.namelist()
    assert names==after.namelist() and after.testzip() is None and len(names)==56
    changed=[n for n in names if before.read(n)!=after.read(n)]
    assert changed==['deadline_submission.py']
    assert after.read(changed[0]).replace(b'    MIN_WALL_MARGIN = 5.0',b'    MIN_WALL_MARGIN = 1.5')==before.read(changed[0])
    old_ast=ast.parse(before.read(changed[0]));new_ast=ast.parse(after.read(changed[0]))
    def replace_margin(tree):
        found=[]
        for node in ast.walk(tree):
            if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='MIN_WALL_MARGIN' for t in node.targets):
                found.append(node.value.value);node.value=ast.Constant(value=1.5)
        return found,ast.dump(tree)
    a,aa=replace_margin(old_ast);b,bb=replace_margin(new_ast)
    assert a==[1.5] and b==[5.0] and aa==bb
    patch=''.join(difflib.unified_diff(before.read(changed[0]).decode().splitlines(True),
        after.read(changed[0]).decode().splitlines(True),fromfile='a/deadline_submission.py',tofile='b/deadline_submission.py'))
    (r/'V16_to_V17.patch').write_text(patch,encoding='utf8')
    files={n:sha256(after.read(n)).hexdigest() for n in names}
    original={n:sha256(before.read(n)).hexdigest() for n in names}
    for n in names:
        if n.endswith('.py'):ast.parse(after.read(n),filename=n)
digest=sha256(new.read_bytes()).hexdigest()
binding=(parent/'WORKSPACE_BINDING_FIRST.json').read_bytes()
assert sha256(binding).hexdigest()=='8a6310cdfccb0bc3c76ee4f4b6d1ab69bd6634f881f3268fb78b6302d8d77585'
(r/'WORKSPACE_BINDING_FIRST.json').write_bytes(binding)
build=dict(version='V17',submission_zip_sha256=digest,payload_files_sha256=files,
    source_parent_zip_sha256=old_sha,source_parent_commit='63ef52c4e56b37c3104ce060853b79ceab5ff133',
    parent_payload_files_sha256=original,changed_existing_files=changed,unchanged_files=55,
    source_delta=dict(file='deadline_submission.py',symbol='DeadlineSubmission.MIN_WALL_MARGIN',old=1.5,new=5.0),
    all_other_AST_identical=True,dependencies_unchanged=True,
    sdk_commit='6557940dc18549ffc7a945db887da5b05b7ed2f1',sdk_binding_sha256=sha256(binding).hexdigest(),
    new_full_matches=0,github_destination='https://github.com/quanliangwen/1')
(r/'BUILD.json').write_text(json.dumps(build,indent=2)+'\n',encoding='utf8')
for name in ['probe_release.py','run_release_validation.py']:
    text=(parent/name).read_text(encoding='utf8').replace('team615_red_v16.zip','team615_red_v17.zip')
    (r/name).write_text(text,encoding='utf8')
remote=(parent/'REMOTE_STAGE.txt').read_text().strip().replace('team615_red_v16_first30_release_20261121','team615_red_v17_wallmargin5_release_20261121')
(r/'REMOTE_STAGE.txt').write_text(remote+'\n',encoding='utf8')
evaluation=Path('E:/10.12-10.26算法对抗赛/evaluation_result.zip')
assert sha256(evaluation.read_bytes()).hexdigest()=='fc207f6dfb7c851370c9c76fab28de5baa9b924bce9affdab7e8ebc66d3cb6d9'
traces={}
with ZipFile(evaluation) as archive:
    for name in archive.namelist():
        if not name.endswith('run.npz'):continue
        inner=ZipFile(BytesIO(archive.read(name)))
        raw=inner.read('timestamps.npy')
        major=raw[6];offset=10 if major==1 else 12
        length=struct.unpack('<H' if major==1 else '<I',raw[8:offset])[0]
        header=ast.literal_eval(raw[offset:offset+length].decode('latin1').strip())
        assert header['descr']=='<f8' and not header['fortran_order']
        body=raw[offset+length:]
        times=list(struct.unpack('<'+str(len(body)//8)+'d',body))
        assert len(times)==header['shape'][0] and times[-1]==180.0
        traces[name]=times
fixtures=dict(source_archive_sha256=sha256(evaluation.read_bytes()).hexdigest(),
    scope='Offline threshold checks on existing V15 timestamp sequences, not V17 trajectories or scores.',traces=traces)
(r/'OFFICIAL_TIMESTAMP_FIXTURES.json').write_text(json.dumps(fixtures,indent=2)+'\n',encoding='utf8')
old_tests=Path('E:/codex/team615_first_round_yield_20261121/counterexamples.py').read_text(encoding='utf8')
for name in ['MAP08_SAVED_TABLES.json','MAP08_BID_CONTEXT.json']:
    shutil.copyfile(Path('E:/codex/team615_first_round_yield_20261121')/name,r/name)
marker="result=dict(status='PASS',scenario_groups=len(RESULTS),scenarios=RESULTS,"
assert old_tests.count(marker)==1
new_tests=(r/'long_frame_cases.py').read_text(encoding='utf8')
combined=old_tests.replace(marker,new_tests+'\n'+marker)
combined=combined.replace("loaded_red_hooks=sys.modules[RedHooks.__module__].__file__,",
    "loaded_red_hooks=sys.modules[RedHooks.__module__].__file__,long_frame_evidence=LONG_FRAME_EVIDENCE,")
(r/'counterexamples.py').write_text(combined,encoding='utf8')
print(json.dumps(dict(status='BUILT',sha256=digest,changed=changed,unchanged=55),indent=2))
