# Appended to the existing 107-group real-controller synthetic-sensor suite.
# No sleeps, arena creation, physics, SDK frames, or complete matches.
from zipfile import ZipFile
from types import ModuleType

baseline_path=Path(__file__).resolve().parent/'baseline_v16.zip'
assert sha256(baseline_path.read_bytes()).hexdigest()=='e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791'
baseline_module=ModuleType('_release_v16_deadline_reference')
sys.modules[baseline_module.__name__]=baseline_module
with ZipFile(baseline_path) as baseline_zip:
    exec(compile(baseline_zip.read('deadline_submission.py'),'baseline_v16.zip/deadline_submission.py','exec'),baseline_module.__dict__)
V16Deadline=baseline_module.DeadlineSubmission
LONG_FRAME_EVIDENCE={}

def new_margin_only():
    assert V16Deadline.MIN_WALL_MARGIN==1.5 and DeadlineSubmission.MIN_WALL_MARGIN==5.0
    assert DeadlineSubmission.FALLBACK_STEPS==V16Deadline.FALLBACK_STEPS==4
    assert DeadlineSubmission.WALL_OVERHEAD==V16Deadline.WALL_OVERHEAD==.5
    assert DeadlineSubmission.BACKUP_INTERVAL==V16Deadline.BACKUP_INTERVAL==360
check('L01_only_minimum_margin_changed_dynamic_and_step_rules_preserved',new_margin_only)

def exact_boundary():
    for elapsed,expected in [(174.999999,None),(175.,'walltime'),(175.000001,'walltime'),(178.5,'walltime')]:
        assert DeadlineSubmission().fallback_reason(4700,5400,elapsed,180.)==expected
    assert DeadlineSubmission().fallback_reason(4700,5400,234.999999,240.) is None
    assert DeadlineSubmission().fallback_reason(4700,5400,235.,240.)=='walltime'
check('L02_5_second_exact_boundary_for_180_and_240_limits',exact_boundary)

def before_boundary_same_as_v16():
    for step,elapsed in [(1000,30.),(3240,100.),(4400,160.),(4700,174.99)]:
        assert DeadlineSubmission().fallback_reason(step,5400,elapsed,180.)==V16Deadline().fallback_reason(step,5400,elapsed,180.)
check('L03_untriggered_path_matches_V16_before_new_margin',before_boundary_same_as_v16)

def official_spikes_cross_old_margin():
    rows=[]
    for gap in (1.7054996490478516,1.728989601135254,1.801851749420166):
        prior=V16Deadline();candidate=DeadlineSubmission()
        for index in range(51):
            t=177.99+index*.01
            step=4700+index
            old_reason=prior.fallback_reason(step,5400,t,180.)
            new_reason=candidate.fallback_reason(step,5400,t,180.)
        assert old_reason is None and new_reason=='walltime'
        # A no-submission frame at 178.49 lasting this long crosses 180.
        assert t+gap>180.0
        rows.append(dict(before_frame=t,long_frame_seconds=gap,V16_reason=old_reason,V17_reason=new_reason,
                         hypothetical_finish_without_submission=t+gap))
    LONG_FRAME_EVIDENCE['late_frame_counterexamples']=rows
check('L04_recorded_1_7_to_1_8_second_spikes_can_skip_old_margin_new_guard_fires',official_spikes_cross_old_margin)

def starts_before_long_frame_and_close():
    d=Flight();d.elapsed_timestep=4700;d.elapsed_walltime=175.
    d.previous_inventory=1;d.pending_drop=(1,np.zeros(2),4699)
    d.inventory_records[3]=(2804,1)
    with patch.object(LBBDRescue,'control',side_effect=AssertionError('heavy work must not start')):
        command=RedHooks.control(d)
    assert d.sent and d.red_submission_step==4700 and command['place_bomb']==0
    assert d.map_calls==0 and d.deadline_submission_event['fallback']=='walltime'
    assert d.deadline_submission_event['local_inventory']==1
    assert not d.deadline_submission_event['team_confirmed']
    # Explicit synthetic budget, not measured runtime or a whole-match promise.
    assert 175.+1.801851749420166+1.5<180.
    LONG_FRAME_EVIDENCE['synthetic_budget']=dict(trigger=175.,next_work=1.801851749420166,
        closing_work=1.5,total=175.+1.801851749420166+1.5)
check('L05_real_control_submits_before_heavy_work_even_with_pending_or_missing_stock',starts_before_long_frame_and_close)

def all_identifiers_bypass_normal_waits():
    for owner in range(5):
        d=Flight(owner);d.elapsed_walltime=175.;d.elapsed_timestep=3448
        d.grid.pose_fixed=False;d.pose=None;d.previous_inventory=1
        d.inventory_records[3]=(2500,1)
        d._prefer_own_submission=lambda *a:(_ for _ in ()).throw(AssertionError('must not bid'))
        d.group_exchange.yield_first_round=lambda *a:(_ for _ in ()).throw(AssertionError('must not wait 30'))
        d.group_exchange.in_submission_slot=lambda *a:(_ for _ in ()).throw(AssertionError('must not wait slot'))
        with patch.object(LBBDRescue,'control',side_effect=AssertionError('must not enter navigation')):
            RedHooks.control(d)
        assert len(d.sent)==1 and d.red_submission_step==3448
check('L06_all_five_IDs_cached_map_submit_without_GPS_slots_grace_or_stock_wait',all_identifiers_bypass_normal_waits)

def preferred_cache_no_render():
    d=Flight();d.elapsed_walltime=175.;d.elapsed_timestep=4700
    image=np.eye(32,dtype=np.uint8);d.deadline_submission.image=image
    d.deadline_submission.cache=('preferred',4600);d.deadline_versions={1:4600}
    d._submission_image=lambda *a:(_ for _ in ()).throw(AssertionError('no new fit at cutoff'))
    control(d)
    assert np.array_equal(d.sent[0][1],image) and d.submitted_cache==('preferred',4600)
    assert d.final_submission_versions=={1:4600} and d.base_calls==0
check('L07_prepared_best_cache_preserved_no_terminal_refit',preferred_cache_no_render)

def backup_cache_no_render():
    d=Flight();d.elapsed_walltime=175.;d.elapsed_timestep=4700
    saved=d.deadline_submission.backup_image.copy()
    d._submission_image=lambda *a:(_ for _ in ()).throw(AssertionError('no new fit for backup'))
    control(d)
    assert np.array_equal(d.sent[0][1],saved) and d.deadline_submission_event['backup_step']==2000
check('L08_backup_image_used_if_final_cache_missing',backup_cache_no_render)

def no_cache_existing_fallback():
    d=Flight();d.elapsed_walltime=175.;d.elapsed_timestep=4700
    d.deadline_submission.backup_image=None
    control(d)
    assert len(d.sent)==1 and d.map_calls==1 and d.base_calls==0
check('L09_no_cache_existing_on_demand_fallback_unchanged',no_cache_existing_fallback)

def repeated_control_no_duplicate_submission():
    d=Flight();d.elapsed_walltime=175.;d.elapsed_timestep=4700
    control(d)
    for i in range(1,4):
        d.elapsed_timestep+=1;d.elapsed_walltime+=.5
        control(d)
    assert len(d.sent)==1 and d.base_calls==0
check('L10_submitted_state_stops_duplicate_submissions',repeated_control_no_duplicate_submission)

def step_deadline_preserved():
    assert DeadlineSubmission().fallback_reason(5395,5400,100.,180.) is None
    assert DeadlineSubmission().fallback_reason(5396,5400,100.,180.)=='timestep'
    d=Flight();d.elapsed_walltime=100.;d.elapsed_timestep=5396
    control(d)
    assert d.deadline_submission_event['fallback']=='timestep' and d.sent
check('L11_last_four_steps_hard_fallback_unchanged',step_deadline_preserved)

def larger_dynamic_margin_still_wins():
    deadline=DeadlineSubmission();deadline.recent_step_seconds=2.
    assert deadline.fallback_reason(4700,5400,171.5,180.)=='walltime'
    assert deadline.fallback_reason(4700,5400,171.499,180.) is None
check('L12_existing_dynamic_margin_above_five_not_clamped_down',larger_dynamic_margin_still_wins)

def offline_existing_timestamp_checks():
    fixtures=json.loads((Path(__file__).resolve().parent/'OFFICIAL_TIMESTAMP_FIXTURES.json').read_bytes())
    results=[]
    for name,times in fixtures['traces'].items():
        first={}
        for label,klass in [('V16',V16Deadline),('V17',DeadlineSubmission)]:
            deadline=klass()
            for frame,elapsed in enumerate(times):
                reason=deadline.fallback_reason(frame+2,5400,elapsed,180.)
                if reason:
                    first[label]=dict(record_index=frame,elapsed=elapsed,reason=reason)
                    break
        assert first['V17']['reason']=='walltime'
        assert 175.<=first['V17']['elapsed']<176.
        assert first['V17']['elapsed']<first['V16']['elapsed']
        results.append(dict(source=name,first_threshold=first))
    assert len(results)==2
    LONG_FRAME_EVIDENCE['offline_V15_timestamps_only_not_new_V17_runs']=results
check('L13_two_existing_official_timestamp_sequences_cross_new_threshold_earlier',offline_existing_timestamp_checks)

def huge_frame_remains_a_boundary():
    deadline=DeadlineSubmission()
    assert deadline.fallback_reason(4700,5400,174.99,180.) is None
    assert 174.99+5.1>180.
    LONG_FRAME_EVIDENCE['limit']='A frame exceeding the remaining budget before the next check can still overrun; 5 seconds is not an unconditional preemption guarantee.'
check('L14_over_five_second_single_frame_limitation_is_explicit',huge_frame_remains_a_boundary)
