from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile, ZIP_DEFLATED
from copy import deepcopy
import json
import shutil
import subprocess
from check_submission_zip import inspect_package, PROFILE, EXPECTED_SHA

r=Path(__file__).resolve().parent
def load(path):return json.loads(path.read_bytes())
def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
build=load(r/'BUILD.json')
assert load(r/'STATUS.json')['status']=='ABI_AND_OFFICIAL_STATIC_PASS'
assert sha256((r/'team615_red_v17.zip').read_bytes()).hexdigest()==EXPECTED_SHA
counter=load(r/'counterexamples.json')
assert counter['status']=='PASS' and counter['scenario_groups']==121 and counter['archive_sha256']==EXPECTED_SHA
with ZipFile(r/'baseline_v16.zip') as old,ZipFile(r/'team615_red_v17.zip') as new:
    assert [n for n in old.namelist() if old.read(n)!=new.read(n)]==['deadline_submission.py']
    assert new.read('deadline_submission.py').replace(b'    MIN_WALL_MARGIN = 5.0',b'    MIN_WALL_MARGIN = 1.5')==old.read('deadline_submission.py')
proof=dict(status='PASS',dependency_profile=PROFILE,submission_zip_sha256=EXPECTED_SHA,
    payload_files_sha256=build['payload_files_sha256'],team_number=615,
    source_parent_zip_sha256=build['source_parent_zip_sha256'],source_delta=build['source_delta'],unchanged_files=55,
    abi_runs={key:load(r/f'ABI_{key}.json') for key in ('numpy1','numpy2','native_main')},
    official_static_check=load(r/'OFFICIAL_STATIC_CHECK.json'),counterexamples=counter,
    official_container_verified=False,new_full_matches=0,V17_map_scores=None,
    validation_boundary='Exact V17 ZIP freshly extracted. Three established numerical environments reused read-only. Synthetic controller counterexamples; SDK startup constructors only; no physical/control frames in a match and no new full match.',
    counterexample_first_attempt='Stopped before new cases because two inherited fixture files were not copied. Original error retained; after fixtures supplied, all 121 groups passed without changing the release ZIP.',
    shared_guard_unchanged_sha256=sha256(Path('E:/codex/swarm-submission-guard/check_submission_zip.py').read_bytes()).hexdigest())
save(r/'RELEASE_ABI_RECEIPT.json',proof)
subprocess.run(['python','-B',str(r/'check_submission_zip.py'),str(r/'team615_red_v17.zip'),
    '--dependency-profile',PROFILE,'--abi-receipt',str(r/'RELEASE_ABI_RECEIPT.json'),
    '--output',str(r/'RELEASE_CHECK.json')],check=True,capture_output=True)
assert load(r/'RELEASE_CHECK.json')['status']=='PASS'
negative=[]
def reject(label,change=None,missing=False,zip_path=None):
    trial=deepcopy(proof)
    if change:change(trial)
    path=r/'NEGATIVE_RECEIPT.json'
    save(path,trial)
    try:inspect_package(zip_path or r/'team615_red_v17.zip',None if missing else path)
    except (ValueError,FileNotFoundError) as error:negative.append(dict(case=label,status='PASS_REJECTED',reason=str(error)))
    else:raise AssertionError('Must reject '+label)
reject('missing receipt',missing=True)
reject('wrong archive binding',lambda p:p.update(submission_zip_sha256='0'*64))
reject('wrong payload',lambda p:p['payload_files_sha256'].update({'deadline_submission.py':'0'*64}))
reject('missing NumPy2 stack',lambda p:p['abi_runs'].pop('numpy2'))
reject('failed numeric operation',lambda p:p['abi_runs']['numpy1'].update(real_numeric_operations=False))
reject('dependency replacement',lambda p:p['abi_runs']['numpy2']['installation_dry_run'].update(install=[{'name':'numpy'}]))
reject('only four constructors',lambda p:p['abi_runs']['native_main'].update(independent_sdk_drones=4))
reject('official static failure',lambda p:p['official_static_check'].update(status='FAIL'))
reject('missing long-frame cases',lambda p:p['counterexamples'].update(scenario_groups=107))
reject('wrong counterexample archive',lambda p:p['counterexamples'].update(archive_sha256='0'*64))
reject('wrong baseline receipt',lambda p:p.update(source_parent_zip_sha256='0'*64))
reject('historical scores masquerading as V17 results',lambda p:p.update(V17_map_scores={'Map09':66.03}))
negative_dir=r/'negative_case'
negative_dir.mkdir(exist_ok=True)
altered=negative_dir/'team615_red_v17.zip'
altered.write_bytes((r/'team615_red_v17.zip').read_bytes()+b'altered')
reject('changed archive bytes',zip_path=altered)
save(r/'NEGATIVE_CHECKS.json',dict(status='PASS',cases=negative))
long_results=dict(status='PASS',submission_zip_sha256=EXPECTED_SHA,source_parent_zip_sha256=build['source_parent_zip_sha256'],
    inherited_groups=107,new_long_frame_groups=14,total_groups=121,physics_steps=0,full_matches=0,
    evidence=counter['long_frame_evidence'],V17_map_scores=None,
    first_attempt='Inherited fixtures missing; supplied before successful retry; production ZIP unchanged.')
save(r/'LONG_FRAME_RESULTS.json',long_results)
delivery=r/'delivery'
delivery.mkdir(exist_ok=True)
for name in ['team615_red_v17.zip','RELEASE_ABI_RECEIPT.json','RELEASE_CHECK.json','LONG_FRAME_RESULTS.json','V16_to_V17.patch']:
    shutil.copyfile(r/name,delivery/name)
shutil.copyfile(r/'counterexamples.json',delivery/'COUNTEREXAMPLES.json')
save(delivery/'SOURCE_MANIFEST.json',build)
readme=f'''# team615 红队比赛提交版 V17：最小墙钟预留5秒

推荐上传文件：`team615_red_v17.zip`。下载这个ZIP原文件后上传比赛平台；不要上传整个GitHub仓库的Source code ZIP、证据包或报告，不必重新压缩。

SHA256：`{EXPECTED_SHA}`

## 唯一修改

以已发布V16为基线，仅将`deadline_submission.py`内的`DeadlineSubmission.MIN_WALL_MARGIN`由`1.5`改为`5.0`。56个成员中只有这个文件改变，改回这一常量即可逐字节还原该文件；其余55个成员完全相同。队号615、队名、队员、依赖、首轮30步让行、0.003近分选新图、6步时间槽、个人原图、缓存、投放复核、导航、拟合、步数兜底和动态墙钟余量计算全部保留。

180秒时限下，正常短帧时约175秒进入墙钟强制交图；动态估计认为需要更多余量时，仍可更早触发。优先提交已有缓存，不等待全队末弹清零、普通交图窗口、首轮让行或竞价时槽。若本机仍有炸弹，硬兜底仍与V16一样只保住已完成投放和现有地图，不把未投弹记成已投。

## 反例验证

121组通过：107组继承回归、14组新增长帧反例。实际调用最终ZIP中的判据与RedHooks控制入口，使用合成传感器；禁止地图、Pymunk Space构造及物理步，物理尝试/步数/整场比赛均为0。

- 174.999999秒不触发；175.000000秒触发。240秒时限相应在235秒触发。
- 在178.49秒后接入官网已有1.7055、1.7290、1.8019秒间隔的反例，V16判据在该时刻不触发；V17判据触发，并在重计算之前提交缓存。
- 无GPS、无有效位置、队伍确认缺失、尚有本机库存或pending、首轮让行和非本机时槽，均不阻塞硬兜底；实际库存状态如实保留。
- 首选缓存/备用缓存、不重复提交、四步步数兜底、原动态余量大于5秒的情形通过。
- 两轮既有V15官网时间序列的离线判据检查如下。这只是相同时间序列上的阈值比较，不是V17的新轨迹、交图耗时或分数。

| 既有时间序列 | V16判据首次触发 | V17判据首次触发 |
|---|---:|---:|
| V15官网Map09第1轮 | 178.506759秒 | 175.000278秒 |
| V15官网Map09第2轮 | 178.467719秒 | 175.002997秒 |

首次执行因漏复制两份继承夹具中止；补齐后121组全部通过，生产ZIP没有再次修改。首次错误和成功重试原件保留在审计证据中。

5秒余量无法中断已经开始的任意长计算；若检查前的单帧、消息处理或收尾工作超过剩余预算，仍可能超限。反例明确保留这个边界，不承诺绝不超时。

## 发布检查与范围

从本ZIP新解包，三组合本次重新验证通过：NumPy1.26.4/Pandas2.2.3、NumPy2.2.6/Pandas2.2.3、NumPy1.26.4/Pandas3.0.6；均配OpenCV contrib4.11.0.86、SciPy1.17.1、elkai2.0.1。真实mtrand/随机数/Pandas/OpenCV/SciPy/elkai操作、SDK Launcher/Stats、整数队号、红队入口、五机独立构造以及无需替换依赖的安装预演通过。复用已有独立依赖环境作只读检查，没有安装或修改比赛服务器依赖。

最终V17专用发布检查及13个错误包/回执拒绝反例通过。共享旧检查器、V16提交包及其检查器保持原样。官方静态内容检查用同SHA的`team615_semifinal.zip`内部审计别名，无错误、无警告；最终比赛文件名是`team615_red_v17.zip`。

本次没有运行整场仿真，没有V17地图分数，不沿用V16成绩冒称V17实测。没有官网容器验证、没有上传比赛官网。

`VALIDATION_EVIDENCE.zip`仅用于审计，内含V16参考ZIP、V17改动清单、测试源码、夹具、原始日志及检查脚本；不是比赛提交包。发布回执及SHA清单绑定实际V17 ZIP和每个成员。
'''
(delivery/'README.md').write_text(readme,encoding='utf8')
with ZipFile(delivery/'VALIDATION_EVIDENCE.zip','w',compression=ZIP_DEFLATED) as archive:
    for name in ['baseline_v16.zip','BUILD.json','WORKSPACE_BINDING_FIRST.json','prepare_release.py',
        'long_frame_cases.py','counterexamples.py','counterexample_driver.py','run_counterexamples.py',
        'retry_counterexamples.py','run_release_validation.py','run_release_checks.py','probe_release.py',
        'prepare_guard.py','check_submission_zip.py','finalize_release.py','OFFICIAL_TIMESTAMP_FIXTURES.json',
        'MAP08_SAVED_TABLES.json','MAP08_BID_CONTEXT.json','COUNTEREXAMPLE_DRIVER.log','COUNTEREXAMPLE_DRIVER_RETRY.log',
        'counterexamples.log','counterexamples_retry.log','RELEASE_COORDINATOR.log','NEGATIVE_CHECKS.json',
        'STATUS.json','OFFICIAL_STATIC_CHECK.json','OFFICIAL_STATIC_FIRST.log']:
        archive.write(r/name,name)
    for key in ('numpy1','numpy2','native_main'):
        for name in [f'ABI_{key}.json',f'PROBE_{key}.log',f'INSTALL_DRY_RUN_{key}.json',f'INSTALL_DRY_RUN_{key}.log']:
            archive.write(r/name,name)
manifest={p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(delivery.iterdir()) if p.is_file() and p.name not in ('CHECKSUMS_SHA256.json','SHA256SUMS.txt')}
save(delivery/'CHECKSUMS_SHA256.json',manifest)
(delivery/'SHA256SUMS.txt').write_text(''.join(h+'  '+n+'\n' for n,h in manifest.items()),encoding='utf8')
print(json.dumps(dict(status='PASS',sha256=EXPECTED_SHA,release_checks=len(load(r/'RELEASE_CHECK.json')['checks']),negative_cases=len(negative),files=len(list(delivery.iterdir()))),indent=2))
