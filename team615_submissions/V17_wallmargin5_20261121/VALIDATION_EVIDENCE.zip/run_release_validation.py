"""Single coordinator for release-only checks. No SDK round is started."""
from pathlib import Path
from hashlib import sha256
import datetime,fcntl,json,os,shutil,subprocess,traceback,zipfile

d=Path(__file__).resolve().parent
root=Path("/home/junhao/quan/parallel_test_solver/match")
launcher=root/"run_server.sh"
python=root/".venv/bin/python"
sealed=root/"solver_study/framework_screen_20261016/best87_independent_20261025/P407_P398_semifinal_three_maps_20261110"

def save(name,data):
    name=Path(name)
    temp=name.with_suffix(".incoming")
    (d/temp).write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    (d/temp).replace(d/name)

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def status(phase,**fields):
    save("STATUS.json",dict(status=phase,time=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                            pid=os.getpid(),SDK_frames=0,native_rounds=0,**fields))

with (root/"solver_study/serial_evaluation.lock").open("r") as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    # This user can read and lock the shared inode, but cannot write it or read
    # the private match scheduler registry. No scheduler or match is invoked:
    # only the exact-archive dependency, constructor, and static release probes.
    status("VALIDATING_RELEASE")
    try:
        build=read(d/"BUILD.json")
        counterexamples=read(d/"counterexamples.json")
        assert counterexamples["status"]=="PASS" and counterexamples["scenario_groups"]==121
        assert counterexamples["archive_sha256"]==build["submission_zip_sha256"]
        assert all(counterexamples[key]==0 for key in ("physics_step_attempts","physics_steps","map_objects_created","full_matches"))
        sdk=read(d/"WORKSPACE_BINDING_FIRST.json")
        assert digest(d/"WORKSPACE_BINDING_FIRST.json")==build["sdk_binding_sha256"]==digest(sealed/"WORKSPACE_BINDING_FIRST.json")
        assert digest(sealed/"official_sdk.tar")==sdk["sdk_archive_sha256"]
        assert sdk["official_commit"]==build["sdk_commit"]
        bundle=d/"team615_red_v17.zip"
        assert digest(bundle)==build["submission_zip_sha256"]
        parent=sealed/"official_sdk"
        workspace=d/"actual_zip_workspace"
        def ignore(path,names):
            return {"__pycache__",".git"}|({"solutions"} if Path(path)==parent/"src/swarm_rescue" else set())
        shutil.copytree(parent,workspace,ignore=ignore)
        for name,checksum in sdk["sdk_files"].items():
            assert digest(workspace/name)==checksum
        source=workspace/"src/swarm_rescue/solutions"
        source.mkdir()
        with zipfile.ZipFile(bundle) as z:
            assert z.testzip() is None and set(z.namelist())==build["payload_files_sha256"].keys()
            for name,checksum in build["payload_files_sha256"].items():
                data=z.read(name)
                assert Path(name).name==name and sha256(data).hexdigest()==checksum
                (workspace/"req.txt" if name=="req.txt" else source/name).write_bytes(data)
        for label in ("native_main","numpy1","numpy2"):
            status("VERIFYING_STACK",label=label)
            with (d/f"PROBE_{label}.log").open("xb") as log:
                subprocess.run(["bash",str(launcher),"-I","-S","-B",str(d/"probe_release.py"),label],
                               stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
            assert read(d/f"ABI_{label}.json")["submission_zip_sha256"]==digest(bundle)
        alias=d/"team615_semifinal.zip"
        shutil.copyfile(bundle,alias)
        code=("import sys,json; from pathlib import Path;"
              f"sys.path.insert(0,{str(workspace/'src')!r});"
              "from swarm_rescue.submission_check import validate_submission;"
              f"r=validate_submission(Path({str(alias)!r}));"
              "print(json.dumps(dict(errors=r.errors,warnings=r.warnings)));raise SystemExit(bool(r.errors))")
        checked=subprocess.run([str(python),"-I","-B","-c",code],capture_output=True,text=True,timeout=75,cwd=d)
        (d/"OFFICIAL_STATIC_FIRST.log").write_text(checked.stdout+"\n"+checked.stderr,encoding="utf-8")
        assert checked.returncode==0,checked.stdout+checked.stderr
        findings=json.loads(checked.stdout)
        save("OFFICIAL_STATIC_CHECK.json",dict(status="PASS",alias_name=alias.name,
                submission_zip_sha256=digest(bundle),alias_sha256=digest(alias),sdk_commit=sdk["official_commit"],**findings))
        status("ABI_AND_OFFICIAL_STATIC_PASS")
    except BaseException:
        save("FIRST_ERROR.json",dict(traceback=traceback.format_exc()))
        status("FIRST_ERROR")
        raise


