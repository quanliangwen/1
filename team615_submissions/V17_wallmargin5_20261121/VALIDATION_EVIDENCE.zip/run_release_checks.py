from pathlib import Path
import json
import subprocess
import sys

r=Path(__file__).resolve().parent
h='quanliangwen@10.112.162.60'
remote=(r/'REMOTE_STAGE.txt').read_text().strip()
counter=json.loads((r/'counterexamples.json').read_bytes())
assert counter['status']=='PASS' and counter['scenario_groups']==121
subprocess.run(['scp','-q','-o','BatchMode=yes',str(r/'run_release_validation.py'),h+':'+remote+'/'],check=True)
result=subprocess.run(['ssh','-o','BatchMode=yes',h,
    'PYTHONDONTWRITEBYTECODE=1 /home/junhao/quan/parallel_test_solver/match/.venv/bin/python -B '+remote+'/run_release_validation.py'],capture_output=True)
(r/'RELEASE_COORDINATOR.log').write_bytes(result.stdout+b'\n'+result.stderr)
for glob in ['*.json','*.log']:
    subprocess.run(['scp','-q','-o','BatchMode=yes',h+':'+remote+'/'+glob,str(r)],check=True)
print(result.stdout.decode(errors='replace'),flush=True)
print(result.stderr.decode(errors='replace'),flush=True)
if result.returncode:
    for error in r.glob('FIRST_ERROR.json'):print(error.read_text(),flush=True)
sys.exit(result.returncode)
