"""V17-only release gate; the shared guard and all old profiles are unchanged."""
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import argparse
import ast
import datetime
import hashlib
import json
import re

EXPECTED_SHA='0aaed704f050073b664d4c0bece9f9ff6500e59edf55c78a7284036f01c167e7'
PROFILE='wallmargin5-sdk-v17'
STACKS={'numpy1':('1.26.4','2.2.3'),'numpy2':('2.2.6','2.2.3'),'native_main':('1.26.4','3.0.6')}

def inspect_package(path, receipt=None, static_only=False, dependency_profile=PROFILE):
    checks=[]
    def need(condition,name):
        if not condition:
            raise ValueError(name)
        checks.append(name)
    need(dependency_profile==PROFILE,'explicit_V17_profile')
    need(path.name=='team615_red_v17.zip','integer615_red_v17_filename')
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    need(digest==EXPECTED_SHA,'whole_ZIP_bound_to_frozen_V17_archive')
    with ZipFile(path) as archive:
        names=archive.namelist()
        need(archive.testzip() is None,'ZIP_CRC')
        need(len(names)==len(set(names))==56,'exact_56_unique_members')
        need(all('/' not in n and '\\' not in n and n not in ('.','..') for n in names),'flat_safe_root_layout')
        need({'my_drone_eval.py','team_info.yml','req.txt'}<=set(names),'SDK_required_root_files')
        need(all(n.endswith(('.py','.txt','.yml')) for n in names),'no_SDK_maps_results_binary_or_runtime')
        team=archive.read('team_info.yml').decode('utf8')
        need(len(re.findall(r'(?m)^team_number:',team))==1 and
             re.search(r'(?m)^team_number: 615\s*$',team) is not None,'YAML_integer615')
        need('AAA排雷大队' in team and '权亮闻、张铮宇、余嘉宁、杨颜翠' in team,'team_identity_unchanged')
        need(archive.read('req.txt').decode().split()==['numpy>=1.24.4','opencv-contrib-python>=4.10.0.84',
             'scipy>=1.10','elkai==2.0.1'],'exact_tested_dependency_declarations_no_changes')
        files={n:hashlib.sha256(archive.read(n)).hexdigest() for n in names}
        baseline=Path(__file__).resolve().parent/'baseline_v16.zip'
        need(hashlib.sha256(baseline.read_bytes()).hexdigest()=='e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791','frozen_V16_baseline_hash')
        with ZipFile(baseline) as reference:
            need(names==reference.namelist(),'same_56_members_as_V16')
            changed=[n for n in names if archive.read(n)!=reference.read(n)]
            need(changed==['deadline_submission.py'],'only_deadline_submission_changed')
            need(archive.read('deadline_submission.py').replace(b'    MIN_WALL_MARGIN = 5.0',b'    MIN_WALL_MARGIN = 1.5')==reference.read('deadline_submission.py'),'only_one_constant_1_5_to_5_0_all_other_bytes_unchanged')
        for name in names:
            if name.endswith('.py'):
                tree=ast.parse(archive.read(name),filename=name)
                for node in ast.walk(tree):
                    modules=([x.name for x in node.names] if isinstance(node,ast.Import) else
                             [node.module or ''] if isinstance(node,ast.ImportFrom) else [])
                    need(not any(n.split('.')[0]=='gurobipy' for n in modules),'no_Gurobi_import_'+name+'_'+str(getattr(node,'lineno',0))) if modules else None
        need(sum(n.endswith('.py') for n in names)==54,'54_Python_sources_compile')
    if not static_only:
        need(receipt is not None,'fresh_actual_ZIP_ABI_receipt_required')
        proof=json.loads(receipt.read_bytes())
        need(proof.get('status')=='PASS' and proof.get('dependency_profile')==PROFILE,'V17_receipt_PASS')
        need(proof.get('submission_zip_sha256')==digest and proof.get('payload_files_sha256')==files,'receipt_actual_archive_and_all_payload_bytes')
        need(type(proof.get('team_number')) is int and proof['team_number']==615,'SDK_runtime_integer615')
        runs=proof.get('abi_runs',{})
        need(set(runs)==set(STACKS),'three_complete_numeric_stacks')
        for key,(numpy,pandas) in STACKS.items():
            run=runs[key]
            versions=run.get('distribution_versions',{})
            need(run.get('status')=='PASS' and versions==dict(numpy=numpy,pandas=pandas,
                **{'opencv-contrib-python':'4.11.0.86','scipy':'1.17.1','elkai':'2.0.1'}),key+'_full_distribution_versions')
            need(run.get('submission_zip_sha256')==digest and run.get('payload_files_sha256')==files,key+'_exact_archive_and_extracted_sources')
            need(type(run.get('team_number')) is int and run['team_number']==615,key+'_SDK_team615')
            need(run.get('real_numeric_operations') is True and run.get('scipy_and_elkai_operations') is True,key+'_real_mtrand_random_Pandas_cv2_SciPy_elkai')
            need(run.get('sdk_launcher_and_stats_import') is True and run.get('red_entry') is True,key+'_SDK_Launcher_Stats_controller_factory')
            need(run.get('independent_sdk_drones')==5 and run.get('no_gurobi') is True,key+'_five_independent_constructors_without_Gurobi')
            paths=run.get('critical_module_paths',{})
            numeric=PurePosixPath(run.get('declared_numeric_root','/INVALID'))
            need(all(paths.get(n) and PurePosixPath(paths[n]).is_relative_to(numeric)
                     for n in ('numpy','numpy.random.mtrand','pandas','cv2')),key+'_recorded_paths_from_declared_numeric_stack')
            need(run.get('python') and run.get('executable')=='/home/junhao/quan/parallel_test_solver/match/.venv/bin/python',key+'_scientific_interpreter_recorded')
            need(run.get('reused_environments_read_only') is True,key+'_read_only_reuse_disclosed')
            plan=run.get('installation_dry_run',{})
            need(plan.get('status')=='PASS' and plan.get('install')==[],key+'_actual_req_install_preview_no_replacements')
            need(run.get('SDK_frames')==0 and run.get('native_rounds')==0,key+'_no_match_or_simulation_frames')
        official=proof.get('official_static_check',{})
        need(official.get('status')=='PASS' and official.get('submission_zip_sha256')==digest==official.get('alias_sha256')
             and official.get('errors')==[],'official_static_same_byte_semifinal_alias_PASS')
        counter=proof.get('counterexamples',{})
        need(counter.get('status')=='PASS' and counter.get('scenario_groups')==121,'107_inherited_plus_14_long_frame_groups_PASS')
        need(counter.get('archive_sha256')==digest,'counterexamples_bind_actual_V17_archive')
        need(all(counter.get(k)==0 for k in ('physics_step_attempts','physics_steps','map_objects_created','full_matches')),'counterexamples_no_physics_or_matches')
        need(proof.get('source_parent_zip_sha256')=='e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791','V16_parent_release_bound')
        need(proof.get('new_full_matches')==0 and proof.get('V17_map_scores') is None,'no_inherited_scores_claimed_as_new_V17_results')
        need(proof.get('official_container_verified') is False,'no_unsupported_official_container_claim')
    return dict(status='STATIC_ONLY_PASS_NOT_RELEASED' if static_only else 'PASS',
                utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),zip=str(path),sha256=digest,
                dependency_profile=PROFILE,checks=checks,official_container_verified=False,new_full_matches=0)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('zip',type=Path)
    parser.add_argument('--abi-receipt',type=Path)
    parser.add_argument('--dependency-profile',default=PROFILE,choices=[PROFILE])
    parser.add_argument('--static-only',action='store_true')
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    try:
        result=inspect_package(args.zip,args.abi_receipt,args.static_only,args.dependency_profile)
        code=0
    except Exception as error:
        result=dict(status='FAIL',error=str(error));code=1
    if args.output:
        args.output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    print(json.dumps(result,ensure_ascii=False))
    raise SystemExit(code)
