from pathlib import Path
import fcntl
import json
import os
import subprocess

r=Path(__file__).resolve().parent
host=Path('/home/junhao/quan/parallel_test_solver/match')
sdk=host/'solver_study/framework_screen_20261016/best87_independent_20261025/P407_P398_semifinal_three_maps_20261110/official_sdk'
with (host/'solver_study/serial_evaluation.lock').open('r') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    env=dict(os.environ,PYTHONPATH=str(sdk/'src'),PYGLET_HEADLESS='true',PYTHONDONTWRITEBYTECODE='1',
             OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    with (r/'counterexamples_retry.log').open('xb') as log:
        subprocess.run([str(host/'.venv/bin/python'),'-B',str(r/'counterexamples.py'),
            str(r/'team615_red_v17.zip'),'candidate','--output',str(r/'counterexamples.json')],
            cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=150)
    proof=json.loads((r/'counterexamples.json').read_bytes())
    assert proof['status']=='PASS' and proof['scenario_groups']==121
    assert all(proof[k]==0 for k in ['physics_step_attempts','physics_steps','map_objects_created','full_matches'])
    print(json.dumps(dict(status=proof['status'],scenario_groups=proof['scenario_groups'],
        long_frame_evidence=proof['long_frame_evidence'],archive_sha256=proof['archive_sha256']),indent=2))
