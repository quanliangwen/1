from pathlib import Path
import shutil
import subprocess
import sys

r=Path(__file__).resolve().parent
h='quanliangwen@10.112.162.60'
remote=(r/'REMOTE_STAGE.txt').read_text().strip()
for name in ['MAP08_SAVED_TABLES.json','MAP08_BID_CONTEXT.json']:
    shutil.copyfile(Path('E:/codex/team615_first_round_yield_20261121')/name,r/name)
for name in ['MAP08_SAVED_TABLES.json','MAP08_BID_CONTEXT.json','counterexample_driver.py']:
    subprocess.run(['scp','-q','-o','BatchMode=yes',str(r/name),h+':'+remote+'/'],check=True)
result=subprocess.run(['ssh','-o','BatchMode=yes',h,
    'PYTHONDONTWRITEBYTECODE=1 /home/junhao/quan/parallel_test_solver/match/.venv/bin/python -B '+remote+'/counterexample_driver.py'],capture_output=True)
(r/'COUNTEREXAMPLE_DRIVER_RETRY.log').write_bytes(result.stdout+b'\n'+result.stderr)
for name in ['counterexamples_retry.log','counterexamples.json']:
    subprocess.run(['scp','-q','-o','BatchMode=yes',h+':'+remote+'/'+name,str(r/name)],check=False)
print(result.stdout.decode(errors='replace'),flush=True)
print(result.stderr.decode(errors='replace'),flush=True)
if result.returncode:print((r/'counterexamples_retry.log').read_text(encoding='utf8')[-4500:],flush=True)
sys.exit(result.returncode)
