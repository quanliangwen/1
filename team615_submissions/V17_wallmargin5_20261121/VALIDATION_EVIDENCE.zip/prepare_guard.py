from pathlib import Path
import json

r=Path(__file__).resolve().parent
old=Path('E:/codex/team615_red_v16_first30_release_20261121/check_submission_zip.py')
build=json.loads((r/'BUILD.json').read_bytes())
guard=old.read_text(encoding='utf8')
guard=guard.replace('e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791',build['submission_zip_sha256'])
guard=guard.replace('V16','V17').replace('v16','v17').replace('first30-sdk-v17','wallmargin5-sdk-v17')
guard=guard.replace('whole_ZIP_identical_to_three_tested_first30_candidate','whole_ZIP_bound_to_frozen_V17_archive')
needle="        files={n:hashlib.sha256(archive.read(n)).hexdigest() for n in names}\n"
assert guard.count(needle)==1
guard=guard.replace(needle,needle+'''        baseline=Path(__file__).resolve().parent/'baseline_v16.zip'
        need(hashlib.sha256(baseline.read_bytes()).hexdigest()=='e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791','frozen_V16_baseline_hash')
        with ZipFile(baseline) as reference:
            need(names==reference.namelist(),'same_56_members_as_V16')
            changed=[n for n in names if archive.read(n)!=reference.read(n)]
            need(changed==['deadline_submission.py'],'only_deadline_submission_changed')
            need(archive.read('deadline_submission.py').replace(b'    MIN_WALL_MARGIN = 5.0',b'    MIN_WALL_MARGIN = 1.5')==reference.read('deadline_submission.py'),'only_one_constant_1_5_to_5_0_all_other_bytes_unchanged')
''')
start=guard.index("        history=proof.get('existing_three_map_history',{})")
end=guard.index("        need(proof.get('official_container_verified')",start)
guard=guard[:start]+'''        counter=proof.get('counterexamples',{})
        need(counter.get('status')=='PASS' and counter.get('scenario_groups')==121,'107_inherited_plus_14_long_frame_groups_PASS')
        need(counter.get('archive_sha256')==digest,'counterexamples_bind_actual_V17_archive')
        need(all(counter.get(k)==0 for k in ('physics_step_attempts','physics_steps','map_objects_created','full_matches')),'counterexamples_no_physics_or_matches')
        need(proof.get('source_parent_zip_sha256')=='e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791','V16_parent_release_bound')
        need(proof.get('new_full_matches')==0 and proof.get('V17_map_scores') is None,'no_inherited_scores_claimed_as_new_V17_results')
'''+guard[end:]
(r/'check_submission_zip.py').write_text(guard,encoding='utf8')
print('Prepared independent V17 release gate; shared guard and V16 gate unchanged.')
