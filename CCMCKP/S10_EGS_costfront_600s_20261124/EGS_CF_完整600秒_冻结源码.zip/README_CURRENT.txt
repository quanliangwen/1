本包源码为实际180次测试的冻结版本。source内旧README/命令help保留原字节用于来源核对，包含上版流程说明；当前时限与流程以包根目录DESIGN_AND_DIAGNOSIS.txt和PROTOCOL.json为准。
完整总时限600秒，最终只按LSS验收，不计算真实概率。严格进程终止保护由配套controller负责。单独调用C++时仍有协作阶段截止，但不能替代外部硬超时保护。
新候选显式参数：--search-flow ellipsoid_costfront --ellipsoid-gamma 2.4 --ellipsoid-slice 5 --seconds 600 --local-phases none。新S10对照为--search-flow frontier_mitm。
controller及PROTOCOL是本批冻结复现证据，已完成身份不得在原目录重跑或覆盖。新实验应新建独立根目录、注册身份与冻结协议。
