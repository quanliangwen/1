"""File-only checks/packaging. Does NOT import, compile, run or test the algorithm."""
from pathlib import Path
import difflib
import hashlib
import json
import shutil
import zipfile

R = Path(__file__).resolve().parent
B1 = Path('E:/codex/CCMCKP_BE_RO_B1_20261128')
B2 = Path('E:/codex/CCMCKP_BE_RO_B2_20261128')
D = R / 'delivery'
D.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
dump = lambda p, obj: p.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
base = {p.relative_to(B1/'source').as_posix(): sha(p) for p in (B1/'source').rglob('*') if p.is_file()}
current = {p.relative_to(R/'source').as_posix(): sha(p) for p in (R/'source').rglob('*') if p.is_file()}
changed = sorted(n for n in base if current.get(n) != base[n])
added = sorted(set(current) - set(base))
assert changed == ['CMakeLists.txt', 'be_ro_search.cpp'], changed
assert added == ['be_ro_linear.cpp', 'be_ro_linear.hpp', 'tests/be_ro_linear_test.cpp'], added
assert not set(base) - set(current)
assert sha(R/'USER_DESIGN.md') == sha(Path('D:/Gemini/CCMCKP_BE_RO_B1_v2_修复设计文档.md'))

def span(text, signature):
    i = text.index(signature)
    return text[i:text.index('\n}', i)+2]

old = (B1/'source/search.cpp').read_text(encoding='utf-8')
new = (R/'source/search.cpp').read_text(encoding='utf-8')
functions = {}
for sig in ('double Search::native_check(', 'Json Search::shortlist()', 'void Search::final_check()'):
    assert span(old, sig) == span(new, sig)
    functions[sig] = hashlib.sha256(span(new, sig).encode()).hexdigest()
inherited = json.loads((B1/'INHERITANCE.json').read_text())
assert functions == inherited['unchanged_native_functions']
for name, expected in inherited['unchanged_files'].items():
    assert current[name] == expected, name
assert current['main.cpp'] == base['main.cpp']
assert current['be_ro_witness.hpp'] == base['be_ro_witness.hpp']

# Verify LOCAL B2 frozen source bytes only. No SSH, process queries or writes.
p2 = B2/'evidence/full40/PROTOCOL.json'
assert sha(p2) == '441b94dacb03315d9aaa7f975247b5fb9b3893d5a2ac4848e9cda2b12090d84c'
bp = json.loads(p2.read_text())['source_and_binary_pins']
b2source = {}
for name, expected in bp.items():
    if name.startswith('../source/'):
        target = B2/name[3:]
        assert sha(target) == expected, 'B2 local frozen source differs: '+name
        b2source[name[3:]] = expected
dump(R/'SOURCE_MANIFEST_SHA256.json', {'scope': 'B1-v2 source tree, code only', 'files': current})
review = {
    'file_integrity_status': 'PASS',
    'scope': 'Static text, inheritance and SHA verification ONLY; no compiler or algorithm/test execution',
    'changed_existing_source_files': changed,
    'added_source_files': added,
    'unchanged_B1_source_file_count': len(base)-len(changed),
    'unchanged_prior_inheritance_file_count': len(inherited['unchanged_files']),
    'unchanged_native_functions': functions,
    'B1_witness_byte_identical': True,
    'original_main_LSS_full_clock_byte_identical': True,
    'local_B2_frozen_source_files_verified': len(b2source),
    'B2_protocol_sha256': sha(p2),
    'B2_actual_server_status_checked_this_task': False,
    'B2_or_server_modified': False,
    'compile_status': 'NOT_RUN',
    'tiny_integration_and_independent_reader_status': 'NOT_RUN',
    'benchmark_status': 'NOT_RUN',
    'performance_claim': None,
    'design_issues_documented': ['Finite lambda grid not globally exact', 'Resource radius not certified exact maximum', 'No guaranteed speed or failure elimination', 'Smoke qualitative gates need numerical pre-registration']
}
dump(R/'STATIC_REVIEW.json', review)
patch = []
for name in changed + added:
    before = (B1/'source'/name).read_text(encoding='utf-8').splitlines(keepends=True) if name in base else []
    after = (R/'source'/name).read_text(encoding='utf-8').splitlines(keepends=True)
    patch.extend(difflib.unified_diff(before, after, fromfile='a/source/'+name if name in base else '/dev/null', tofile='b/source/'+name))
(R/'SOURCE_DIFF.patch').write_text(''.join(patch), encoding='utf-8')

extra = ['README.md', 'CURRENT_STATUS.json', 'NEXT_VALIDATION_PLAN.json', 'USER_DESIGN.md',
         'SOURCE_MANIFEST_SHA256.json', 'STATIC_REVIEW.json', 'SOURCE_DIFF.patch',
         'linear_reader.py', 'be_reader.py', 'r05_fft_reader.py', 'B1_INHERITANCE.json', 'review_and_package.py']
archive = D/'BE_RO_Pure_B1_v2_源码_未运行.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted((R/'source').rglob('*')):
        if p.is_file():
            z.write(p, 'source/'+p.relative_to(R/'source').as_posix())
    for name in extra:
        z.write(R/name, name)
# Byte-for-byte archive verification; no Python modules or binaries executed.
with zipfile.ZipFile(archive) as z:
    for name, expected in current.items():
        assert hashlib.sha256(z.read('source/'+name)).hexdigest() == expected
    for name in extra:
        assert z.read(name) == (R/name).read_bytes()
for name in ['README.md', 'CURRENT_STATUS.json', 'NEXT_VALIDATION_PLAN.json', 'USER_DESIGN.md',
             'SOURCE_MANIFEST_SHA256.json', 'STATIC_REVIEW.json', 'SOURCE_DIFF.patch']:
    shutil.copy2(R/name, D/name)
qa = {'status': 'PASS', 'stage': 'ENGINEERING_COMPLETE', 'all_files_sha_verified': True,
      'publication_scope': 'CODE_PREPARED_UNTESTED_WAIT_FOR_B2; file integrity only',
      'compiled': False, 'algorithm_or_tests_run': False, 'server_deployed': False}
dump(R/'DELIVERY_LOCAL_VERIFIED.json', qa)
dump(D/'DELIVERY_QA.json', qa)
checks = {p.name: {'sha256': sha(p), 'bytes': p.stat().st_size} for p in sorted(D.iterdir()) if p.is_file() and p.name != 'CHECKSUMS_SHA256.json'}
dump(D/'CHECKSUMS_SHA256.json', checks)
print(json.dumps({'file_integrity': 'PASS', 'changed': changed, 'added': added,
                  'B2_frozen_local_files_unchanged': len(b2source), 'compiled_or_tested': False,
                  'zip_bytes': archive.stat().st_size, 'zip_sha256': sha(archive)}, ensure_ascii=False))
