"""Offline observed-point decomposition; no native call or formal optimizer. These observed solutions must NEVER enter a formal worker."""
import os
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import ast,io,json,zipfile,pickle,time,hashlib
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];HERE=Path(__file__).resolve().parent
inp=Path(r'E:\codex\CCMCKP_DRO_R04_20261101\github_staging_20261102\CCMCKP\B_CDF_DRO_MITM_R04_20261102\inputs_frozen.zip')
assert hashlib.sha256(inp.read_bytes()).hexdigest()=='e5ebd0a26ff4a3d6d8e66cd2c3e0a342d8268dcf831315bb9fe657d9b4fb88b7'
tree=ast.parse((ROOT/'sources/B/solver.py').read_text());functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('worst_cdf_hist','truncated_convolution')];ns={'np':np};exec(compile(ast.Module(body=functions,type_ignores=[]),'uploadedB_kernel','exec'),ns);conv=ns['truncated_convolution'];histogram=ns['worst_cdf_hist']
points=json.loads((HERE/'FIRST_STAGE_GEOMETRY_POINTS.json').read_text());results=[]
for point in points:
 with zipfile.ZipFile(inp) as z:
  base='benchmark/'+point['instance']+'/'
  costs=np.asarray(np.loadtxt(io.BytesIO(z.read(base+'cost.txt')))).reshape(-1);groups=pickle.loads(z.read(base+'node_to_factor.pkl'));groups=[groups[k] for k in sorted(groups,key=lambda x:int(x))] if isinstance(groups,dict) else groups
  samples=[np.asarray(np.loadtxt(io.BytesIO(z.read(base+str(j)+'_sample.txt')))) for j in range(len(costs))]
 hist=np.asarray([histogram(a[:-1],point['capacity'],4096,.00025) for a in samples]);ids=point['root']['selection'];pdf=np.r_[1.,np.zeros(4095)]
 for j in ids:pdf=conv(pdf,hist[j],4096)
 root={'selection':ids,'cost':point['root']['cost'],'count':1,'original_robust_CDF_full_float64':float(pdf.sum())}
 center=root['selection'];cap=root['cost'];m=len(center);B=4096;t=time.perf_counter();prefix=np.zeros((m+1,B));suffix=np.zeros((m+1,B));prefix[0,0]=suffix[m,0]=1
 for g in range(m):prefix[g+1]=conv(prefix[g],hist[center[g]],B)
 for g in reversed(range(m)):suffix[g]=conv(hist[center[g]],suffix[g+1],B)
 one=[]
 for g,items in enumerate(groups):
  complement=conv(prefix[g],suffix[g+1],B);cdf=np.cumsum(complement)[::-1]
  for j in items:
   cost=cap-costs[center[g]]+costs[j]
   if cost<cap-1e-8:one.append({'g':g,'j':j,'cost':float(cost),'p':float(np.clip(hist[j]@cdf,0.,1.))})
 one.sort(key=lambda x:(-x['p'],x['cost']));rank=None
 # Build mathematically exact TWO-coordinate score matrices using K rather than K^2 FFTs.
 # Only diagnostics of finite-score cost/risk compensation; never native feasibility claims.
 itemfft=np.fft.rfft(hist,2*B,axis=1);pair_rows=[];worst_error=0.;n_pairs=0
 for g in range(m-1):
  running=prefix[g].copy()
  for h in range(g+1,m):
   complement=conv(running,suffix[h+1],B);cdf=np.cumsum(complement)
   # d_i[t]=(h_i*F_complement)[B-1-t]
   correlate=np.maximum(0.,np.fft.irfft(itemfft[groups[g]]*np.fft.rfft(cdf,2*B),2*B,axis=1)[:,:B])[:,::-1]
   Q=np.clip(correlate@hist[groups[h]].T,0.,1.);C=cap-costs[center[g]]-costs[center[h]]+costs[groups[g]][:,None]+costs[groups[h]][None,:]
   mask=(C<cap-1e-8)&(Q>=root['original_robust_CDF_full_float64']-1e-12)
   for a,b in np.argwhere(mask):
    ja=groups[g][a];jb=groups[h][b]
    if ja==center[g] or jb==center[h]:continue
    pair_rows.append({'g':g,'h':h,'i':ja,'j':jb,'cost':float(C[a,b]),'p':float(Q[a,b]),'cost_changes':[float(costs[ja]-costs[center[g]]),float(costs[jb]-costs[center[h]])]})
   # Independent direct original convolution verifies first/last item entries of every pair.
   for a,b in ((0,0),(len(groups[g])-1,len(groups[h])-1)):
    direct=float(conv(conv(complement,hist[groups[g][a]],B),hist[groups[h][b]],B).sum());worst_error=max(worst_error,abs(direct-Q[a,b]))
   running=conv(running,hist[center[h]],B);n_pairs+=1
 pair_rows.sort(key=lambda x:(x['cost'],-x['p']));assert worst_error<=1e-10
 results.append({'case':point['case'],'root_originalCDF':root['original_robust_CDF_full_float64'],'root_cost':cap,'observed_runs':root['count'],'one_cheaper':len(one),'B_best_one_swap_probability_rank':rank,'top12_one_risk_rank':one[:12],'two_group_strict_cost_lower_and_CDF_not_lower_count':len(pair_rows),'best20_compensating_pairs':pair_rows[:20],'pair_matrices_verified':n_pairs,'max_direct_score_error':worst_error,'elapsed_local_seconds':time.perf_counter()-t})
 print(json.dumps(results[-1]),flush=True)
(HERE/'FIRST_STAGE_PAIR_GEOMETRY.json').write_text(json.dumps({'results':results,'native_calls':0,'formal_runs':0,'scope':'Recorded first-stage risk/cost geometry only. No recorded vectors enter a formal worker.'},indent=2))
