"""Verify downloaded/repository delivery bytes, source freeze, results member manifest, and Excel-vs-JSON. No optimization."""
import argparse,hashlib,json,zipfile,xml.etree.ElementTree as ET
from pathlib import Path

def digest(b):return hashlib.sha256(b).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('directory');a=ap.parse_args();r=Path(a.directory);manifest=json.loads((r/'FILE_MANIFEST.json').read_text(encoding='utf8'));checked=[]
 for rel,item in manifest.items():
  p=r/rel;assert p.is_file(),rel;b=p.read_bytes();assert digest(b)==item['sha256'] and len(b)==item['bytes'],rel;checked.append(rel)
 with zipfile.ZipFile(r/'source_frozen.zip') as z:
  f=json.loads(z.read('FREEZE.json'));assert digest(z.read('FREEZE.json'))=='4ec0fb3f3405038cde947a3bb43776d2bc6e6af139673ed4bd516dc9b76333b1'
  for rel,h in f['files'].items():assert digest(z.read(rel))==h,rel
 members=0
 if (r/'results_complete.zip').exists():
  with zipfile.ZipFile(r/'results_complete.zip') as z:
   m=json.loads(z.read('EXPORT_MANIFEST.json'))
   for rel,item in m['files'].items():
    b=z.read(rel);assert len(b)==item['bytes'] and digest(b)==item['sha256'],rel
   members=len(m['files']);d=json.loads(z.read('reports/statistics_snapshot.json'))
  if (r/'statistics.xlsx').exists():verify_excel(r/'statistics.xlsx',d)
 print(json.dumps({'passed':True,'delivery_files':len(checked),'frozen_source_members':len(f['files']),'verified_results_members':members,'no_new_evaluation':True}))

def verify_excel(path,d):
 ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
 with zipfile.ZipFile(path) as z:
  ss=[]
  if 'xl/sharedStrings.xml' in z.namelist():
   ss=[''.join(x.itertext()) for x in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si',ns)]
  wb=ET.fromstring(z.read('xl/workbook.xml'));rels=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'));targets={x.attrib['Id']:x.attrib['Target'] for x in rels};sheets={}
  for s in wb.find('s:sheets',ns):
   rel=s.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'];target=targets[rel].lstrip('/');sheets[s.attrib['name']]=target if target.startswith('xl/') else 'xl/'+target
  def readsheet(name):
   cells={}
   for c in ET.fromstring(z.read(sheets[name])).findall('.//s:sheetData/s:row/s:c',ns):
    v=c.find('s:v',ns);t=c.attrib.get('t');val=None
    if t=='inlineStr':val=''.join(c.find('s:is',ns).itertext())
    elif v is not None:val=ss[int(v.text)] if t=='s' else float(v.text) if t not in ('str','e') else v.text
    assert t!='e',(name,c.attrib['r'],val);cells[c.attrib['r']]=val
   return cells
  costs=readsheet('成本与有效率');raw=readsheet('逐次终末')
  for i,row in enumerate(d['summaries'],6):
   for col,key in [('G','valid'),('J','best'),('K','avg'),('L','std'),('M','CV')]:
    x=costs.get(col+str(i));y=row[key];assert (x is None and y is None) or (x is not None and y is not None and abs(x-y)<=max(1e-12,abs(y)*1e-12)),(col,i,x,y)
  for i,row in enumerate(d['terminal_records'],6):
   x=raw.get('G'+str(i));y=row['cost'];assert (x is None and y is None) or (x is not None and y is not None and abs(x-y)<=max(1e-12,abs(y)*1e-12)),(i,x,y)
if __name__=='__main__':main()
