"""Singleton R07 preflight + registered gated campaign, no prior solution input."""
import os,sys,time,subprocess,fcntl
from pathlib import Path
ROOT=Path(__file__).resolve().parent;os.chdir(ROOT)
from common import read,sha,atomic,check_freeze,process_table
ENV=dict(os.environ,OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
def main():
 lock=(ROOT/'advance.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);lock.seek(0);lock.truncate();lock.write(str(os.getpid()));lock.flush();os.fsync(lock.fileno());freeze=check_freeze()
 previous=read(ROOT/'REFERENCE_REGISTRY.json')['old_controller'];pt=process_table();row=pt.get(previous['pid']);assert not(row and row['start_ticks']==previous['start_ticks']);assert not any(previous['root'] in v['cmd'] and 'worker.py' in v['cmd'] for v in pt.values())
 assert read(Path(previous['root'])/'STATE.json')['status']=='pilot_failed_requires_diagnosis'
 assert all(read(Path(previous['root'])/'waves'/('R06_pilot_c%02d_a01'%idx)/'WAVE.json')['status'] in ('valid_complete','ordinary_failure_complete') for idx in read(ROOT/'PROTOCOL.json')['pilot_cases'])
 for name,result in [('mathematical_preflight.py','MATH_PREFLIGHT.json'),('functional_preflight.py','FUNCTIONAL_PREFLIGHT.json')]:
  if not (ROOT/result).exists():
   with (ROOT/(name+'.log')).open('x') as log:p=subprocess.run([sys.executable,'-B',str(ROOT/name)],env=ENV,stdout=log,stderr=subprocess.STDOUT)
   if p.returncode:raise RuntimeError('Preflight failed '+name)
  assert read(ROOT/result)['passed'] and read(ROOT/result)['freeze_sha']==freeze
 assert read(ROOT/'PAIR_COMPONENT_PREFLIGHT.json')['passed'];check_freeze()
 atomic(ROOT/'PREFLIGHT.json',{'passed':True,'freeze_sha':freeze,'math':sha(ROOT/'MATH_PREFLIGHT.json'),'functional':sha(ROOT/'FUNCTIONAL_PREFLIGHT.json'),'joint_real_native':sha(ROOT/'PAIR_COMPONENT_PREFLIGHT.json')})
 from audit_campaign import audit_wave
 reg=read(ROOT/'PROTOCOL.json');refs=read(ROOT/'REFERENCE_REGISTRY.json');counts={}
 for case in reg['cases']:
  rows=audit_wave(Path(refs['waves'][str(case['index'])]['directory']),case,'B');assert len(rows)==30 and all(r['valid'] for r in rows);counts[str(case['index'])]=30
 atomic(ROOT/'REUSED_B_AUDIT.json',{'passed':True,'freeze_sha':freeze,'counts':counts,'new_B_executions':0})
 from controller import Controller
 c=Controller();c.run()
if __name__=='__main__':
 try:main()
 except Exception as e:atomic(ROOT/'ADVANCE_FAILURE.json',{'error':repr(e),'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'goal_complete':False});raise
