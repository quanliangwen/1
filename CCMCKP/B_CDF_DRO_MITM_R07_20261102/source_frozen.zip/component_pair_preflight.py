"""Original-init/native positive joint exchange and RNG replay; synthetic only."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
import sys,time,json,signal
from common import ROOT,read,sha,atomic,check_freeze
from preflight_helpers import original_native_check,state_digest,previous_live

def main():
 signal.alarm(600);freeze=check_freeze();assert not previous_live();assert not (ROOT/'PAIR_COMPONENT_PREFLIGHT.json').exists()
 sys.path.insert(0,str(ROOT/'sources/R07'));import numpy as np
 from instance import load_instance
 from solver import Solver
 target=ROOT/'PAIR_COMPONENT_TESTS';target.mkdir(exist_ok=False);inst=load_instance(ROOT/'functional_fixtures/joint_trade_L500');started=time.monotonic();seed=832273
 s=Solver(inst,4.,seed,600,target/'joint.json.gz',started,'B_CDF_DRO_MITM');replay=Solver(inst,4.,seed,600,target/'replay_unused.json.gz',started,'B_CDF_DRO_MITM');replay.save=lambda *_:None
 original=s.native_check;baseline=original_native_check(np);transcript=[]
 def checked(ids,source,force=False):
  outer=state_digest(np.random.get_state());p=original(ids,source,force);q=baseline(replay,ids,source,force)
  assert p==q and state_digest(np.random.get_state())==outer and state_digest(s.native_rng.get_state())==state_digest(replay.native_rng.get_state()) and s.native_calls==replay.native_calls
  transcript.append({'selection':list(ids),'source':source,'force':force,'returned':p,'native_rng_sha':state_digest(s.native_rng.get_state())});return p
 s.native_check=checked
 for _,_,selection in s.propose(s.mu+3*s.sd,float(s.cost.max()*inst.m),theta=0.,pool=8,seconds=3):
  s.native_check(selection,'synthetic_joint_own_original_initialization',True)
  if s.best is not None:break
 assert s.best and abs(s.best['cost']-30.)<1e-8;initial=tuple(s.best['selection']);before=s.native_calls
 s.joint_cdf_pair_exchange(.00025)
 assert s.best['cost']==26. and s.best['probability']>=.99 and len([g for g,(a,b) in enumerate(zip(initial,s.best['selection'])) if a!=b])==2
 record=s.match_history[-1];assert record['engine']=='joint_CDF_pair_messages' and record['active'] and record['native_calls']==1 and s.native_calls-before==1
 assert len(record['attempts'])==1 and record['attempts'][0]['groups_changed']==[0,1] and record['attempts'][0]['original_full_CDF_score']>=.975
 # Actual chosen change trades an increased item cost against a larger decrease.
 deltas=[float(s.cost[s.best['selection'][g]]-s.cost[initial[g]]) for g in range(inst.m)];assert min(deltas)<0<max(deltas)
 count=s.native_calls;models=s.models;length=len(s.match_history);s.deadline=time.monotonic()-1.;s.joint_cdf_pair_exchange(.00025);assert s.native_calls==count and s.models==models and len(s.match_history)==length
 atomic(ROOT/'PAIR_COMPONENT_PREFLIGHT.json',{'passed':True,'freeze_sha':freeze,'synthetic_only':True,'formal_runs':0,'own_original_initializer_cost':30.,'original_native_accepted_joint_cost':26.,'native_return':s.best['probability'],'proposal_native_calls':record['native_calls'],'original_CDF_score':record['attempts'][0]['original_full_CDF_score'],'changed_group_costs':deltas,'RNG_original_transcript_replay_passed':True,'deadline_no_work':True,'elapsed':time.monotonic()-started,'transcript':transcript,'pair_stage':record});print('Real-native joint compensation + original RNG replay passed',flush=True)
if __name__=='__main__':main()
