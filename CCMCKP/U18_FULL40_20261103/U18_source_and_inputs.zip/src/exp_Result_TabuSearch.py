"""Command-line experiment entry for LSS-style DDTS.

Implementation notes in this fast-initialization revision:
* the per-run stopping rule is a 600-second wall-clock budget by default;
  the legacy outer-iteration count is no longer a stopping condition;
* empirical stochastic-dominance preprocessing removes within-class items that
  are no cheaper and no safer under the empirical distribution;
* large-instance DDTS candidate evaluation uses Delta Monte Carlo with exact
  violation-count early rejection under a fixed-M CRN experiment;
* ``quick_check_list`` is loaded from cache when available; a cache miss has a
  1-second build budget by default and is skipped on timeout.
* ``Statistic_factor`` is executed once per instance/lambda in this process and
  the resulting factor objects are reused for all Tmax values and runs.
* explicit stage logs show QuickCheck -> StatisticFactor -> CP -> TS iteration.
* in AMC mode, the evaluator's QuickCheck is additionally front-loaded into
  tabu 1-swap neighborhood screening via incremental one-class delta sums;
  the original AMC QuickCheck remains as a safety recheck for survivors.
* repeated runs can optionally be parallelized inside one instance via
  ``--run-workers``.  On Linux this uses ``fork`` so the instance-level
  QuickCheck and Statistic_factor data prepared by the parent are inherited by
  workers instead of being rebuilt for every repeated run.
* concurrent construction of the exact same QuickCheck cache entry is protected
  by a short-lived per-entry file lock.

Default search structure per run:
    empirical stochastic-dominance preprocessing
      -> fast feasibility-first initialization (10k pilot Delta-MC + repair + safe anchor)
      -> repeat full class scan + random perturbation until 600 s per run
      -> large-instance 1-swap checks use Delta Monte Carlo and exact early rejection.

The legacy ``--no-improve-limit`` option is still accepted for compatibility
but is not used by this LSS-style classwise mode.

Example:
    python3 src/exp_Result_TabuSearch.py \
        --instance APP_3_5_30_ --tmax 21 27 --runs 30 --run-workers 30 \
        --time-limit 600 --tabu-tenure 1 --lambda-value 5
"""

from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing as mp
import csv
from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import random
import re
import sys
import time
from statistics import mean, pstdev
from typing import Any

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.functions.func_reference_evaluation import (
    reference_advanced_exact_evaluation,
    reference_advanced_monte_carlo,
    factorization_list,
)
from src.functions.func_localsearch_cp_corrected import NoFeasibleInitialSolution
from src.functions.func_fast_initialization import Fast_Construct_Procedure
from src.functions.func_solution_factor_corrected import Statistic_factor, solution_cost
from src.functions.func_empirical_dominance import empirical_stochastic_dominance_preprocess
from src.functions.func_tabu_search import validate_multiple_choice_solution
from src.functions.func_tail_guided_search import Data_Driven_Tabu_Search
from src.functions.func_search_ablation import get_policy
from src.functions.func_lagrangian_guidance import learn_lagrangian_restart_guidance
from src.functions.func_elite_path_relinking import QualityDiversityElitePool, path_relink
from src.functions.func_importance_cmc import FixedBudgetImportanceCMCSampler


ALGORITHM_NAME = "Tail-Priority-LR-OperationTabu-QD-Elite-PR-10.4"
CODE_VERSION = "10.4-reference-tail-priority-v1"
PERTURBATION_POLICY = "nearby_pair"
USE_COST_RISK_INITIALIZATION = True
GLOBAL_RUN_TIME_LIMIT_SECONDS = 600.0

KNOWN_GUROBI_EXACT = {
    ("APP_3_5_30_", 21.0, 0.99): 9.034717299521294,
    ("APP_3_5_30_", 27.0, 0.99): 7.25001317010452,
}


QUICK_CHECK_CACHE_VERSION = 2
QUICK_CHECK_LIST_SIZE = 10
QUICK_CHECK_PERMUTATIONS = 50
DEFAULT_QUICK_CHECK_CACHE_DIR = REPO_ROOT / ".cache" / "ddts_reference_quick_check"

# Process-local caches.  The disk cache below additionally prevents duplicate
# QuickCheck construction across separately launched parallel Python processes.
_QUICK_CHECK_MEMORY_CACHE: dict[tuple, tuple[list[list[int]], dict]] = {}
_INSTANCE_RESOURCE_CACHE: dict[tuple, "PreparedInstanceResources"] = {}

# Parent-prepared instance resources inherited by forked run workers.
_RUN_POOL_PREPARED = None


def stage_log(stage: str, message: str):
    """Emit an immediately flushed, PID-tagged progress line.

    PID tagging is useful when the user launches several DDTS jobs in parallel.
    """
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{stamp}][PID {os.getpid()}][{stage}] {message}", flush=True)


def _stable_quick_check_seed(instance_name: str, m: int, L: int, p0: float) -> int:
    """Deterministic seed used only while constructing the shared QuickCheck list."""
    token = (
        f"ddts-qc-v{QUICK_CHECK_CACHE_VERSION}|{instance_name}|m={m}|L={L}|"
        f"p0={float(p0):.12g}|list={QUICK_CHECK_LIST_SIZE}|K={QUICK_CHECK_PERMUTATIONS}"
    )
    digest = hashlib.sha256(token.encode("utf-8")).digest()
    return int.from_bytes(digest[:4], byteorder="big", signed=False)


def _quick_check_cache_path(instance_dir: Path, m: int, L: int, p0: float, cache_dir: Path) -> Path:
    token = (
        f"v{QUICK_CHECK_CACHE_VERSION}|{instance_dir.name}|m={m}|L={L}|"
        f"p0={float(p0):.12g}|list={QUICK_CHECK_LIST_SIZE}|K={QUICK_CHECK_PERMUTATIONS}"
    )
    digest = hashlib.sha256(token.encode("utf-8")).hexdigest()[:16]
    safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", instance_dir.name)
    return cache_dir / f"{safe_name}_p{float(p0):.12g}_{digest}.json"


def _validate_quick_check_payload(payload: Any, instance_name: str, m: int, L: int, p0: float):
    if not isinstance(payload, dict):
        return None
    expected = {
        "cache_version": QUICK_CHECK_CACHE_VERSION,
        "instance": instance_name,
        "m": int(m),
        "L": int(L),
        "p0": float(p0),
        "list_size": QUICK_CHECK_LIST_SIZE,
        "K": QUICK_CHECK_PERMUTATIONS,
    }
    for key, value in expected.items():
        if key not in payload:
            return None
        if isinstance(value, float):
            if abs(float(payload[key]) - value) > 1e-12:
                return None
        elif payload[key] != value:
            return None

    rows = payload.get("quick_check_list")
    if not isinstance(rows, list):
        return None
    normalized = []
    for row in rows:
        if not isinstance(row, list) or len(row) != int(m):
            return None
        try:
            row_i = [int(v) for v in row]
        except (TypeError, ValueError):
            return None
        if any(v < 0 or v >= int(L) for v in row_i):
            return None
        normalized.append(row_i)
    return normalized


def _try_load_quick_check_cache(cache_path: Path, instance_name: str, m: int, L: int, p0: float):
    if not cache_path.is_file():
        return None
    try:
        with cache_path.open("r", encoding="utf-8") as f:
            payload = json.load(f)
    except (OSError, json.JSONDecodeError):
        return None
    return _validate_quick_check_payload(payload, instance_name, m, L, p0)


@contextmanager
def _exclusive_cache_lock(
    lock_path: Path,
    wait_log_interval: float = 30.0,
    timeout_seconds: Optional[float] = None,
):
    """Cross-process lock with an optional hard wait budget.

    QuickCheck is only an acceleration device.  A cache-lock wait must never
    block the algorithm indefinitely; on timeout the caller skips QuickCheck.
    """
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    wait_start = time.monotonic()

    def expired():
        return (
            timeout_seconds is not None
            and time.monotonic() - wait_start >= max(0.0, float(timeout_seconds))
        )

    try:
        import fcntl
    except ImportError:
        lock_dir = Path(str(lock_path) + ".d")
        last_log = 0.0
        while True:
            try:
                lock_dir.mkdir()
                break
            except FileExistsError:
                if expired():
                    raise TimeoutError("QuickCheck cache-lock timeout")
                now = time.monotonic()
                if now - last_log >= wait_log_interval:
                    stage_log("QuickCheck", f"waiting for cache lock: {lock_dir.name}")
                    last_log = now
                time.sleep(0.05)
        try:
            yield
        finally:
            try:
                lock_dir.rmdir()
            except OSError:
                pass
        return

    fd = os.open(str(lock_path), os.O_CREAT | os.O_RDWR, 0o644)
    last_log = 0.0
    try:
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if expired():
                    raise TimeoutError("QuickCheck cache-lock timeout")
                now = time.monotonic()
                if now - last_log >= wait_log_interval:
                    stage_log("QuickCheck", f"waiting for cache lock: {lock_path.name}")
                    last_log = now
                time.sleep(0.05)
        yield
    finally:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)


def load_or_build_quick_check(
    instance_dir: Path,
    m: int,
    L: int,
    p0: float,
    cache_dir: Optional[Path] = None,
    timeout_seconds: float = 1.0,
):
    """Load QuickCheck from cache or spend at most ``timeout_seconds`` building it.

    A cache hit is used immediately.  A cache miss is bounded, including lock
    waiting and the historically problematic random factorization loop.  If
    the budget expires, ``[]`` is returned and DDTS proceeds without this
    optional AMC accelerator.
    """
    if cache_dir is None:
        cache_dir = DEFAULT_QUICK_CHECK_CACHE_DIR
    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)
    timeout_seconds = max(0.0, float(timeout_seconds))

    memory_key = (
        str(instance_dir.resolve()), int(m), int(L), float(p0),
        QUICK_CHECK_LIST_SIZE, QUICK_CHECK_PERMUTATIONS, str(cache_dir.resolve()),
    )
    if memory_key in _QUICK_CHECK_MEMORY_CACHE:
        quick_check, metadata = _QUICK_CHECK_MEMORY_CACHE[memory_key]
        metadata = dict(metadata)
        metadata["memory_cache_hit"] = True
        return quick_check, metadata

    cache_path = _quick_check_cache_path(instance_dir, m, L, p0, cache_dir)
    quick_check = _try_load_quick_check_cache(cache_path, instance_dir.name, m, L, p0)
    if quick_check is not None:
        metadata = {
            "cache_hit": True, "memory_cache_hit": False,
            "cache_path": str(cache_path), "build_seconds": 0.0,
            "timed_out": False, "skipped": False,
        }
        _QUICK_CHECK_MEMORY_CACHE[memory_key] = (quick_check, dict(metadata))
        return quick_check, metadata

    budget_start = time.monotonic()
    deadline = budget_start + timeout_seconds
    lock_path = Path(str(cache_path) + ".lock")
    try:
        remaining_for_lock = max(0.0, deadline - time.monotonic())
        with _exclusive_cache_lock(lock_path, timeout_seconds=remaining_for_lock):
            quick_check = _try_load_quick_check_cache(
                cache_path, instance_dir.name, m, L, p0
            )
            if quick_check is not None:
                metadata = {
                    "cache_hit": True, "memory_cache_hit": False,
                    "cache_path": str(cache_path), "build_seconds": 0.0,
                    "timed_out": False, "skipped": False,
                }
                _QUICK_CHECK_MEMORY_CACHE[memory_key] = (quick_check, dict(metadata))
                return quick_check, metadata

            stable_seed = _stable_quick_check_seed(instance_dir.name, m, L, p0)
            stage_log(
                "QuickCheck",
                f"cache miss for {instance_dir.name}; bounded build "
                f"timeout={timeout_seconds:.3f}s (m={m}, L={L}, P0={p0:g})",
            )
            np_state = np.random.get_state()
            py_state = random.getstate()
            build_start = time.monotonic()
            try:
                np.random.seed(stable_seed)
                random.seed(stable_seed)
                quick_check = factorization_list(
                    int(L), int(m), float(p0),
                    QUICK_CHECK_LIST_SIZE, QUICK_CHECK_PERMUTATIONS,
                    deadline_monotonic=deadline,
                )
            finally:
                np.random.set_state(np_state)
                random.setstate(py_state)
            build_seconds = time.monotonic() - build_start
            quick_check = [[int(v) for v in row] for row in quick_check]

            payload = {
                "cache_version": QUICK_CHECK_CACHE_VERSION,
                "instance": instance_dir.name, "m": int(m), "L": int(L),
                "p0": float(p0), "list_size": QUICK_CHECK_LIST_SIZE,
                "K": QUICK_CHECK_PERMUTATIONS,
                "construction_seed": int(stable_seed),
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "quick_check_list": quick_check,
            }
            tmp_path = cache_path.with_name(cache_path.name + f".tmp.{os.getpid()}")
            try:
                with tmp_path.open("w", encoding="utf-8") as f:
                    json.dump(payload, f, ensure_ascii=False)
                os.replace(tmp_path, cache_path)
            finally:
                if tmp_path.exists():
                    try:
                        tmp_path.unlink()
                    except OSError:
                        pass

            metadata = {
                "cache_hit": False, "memory_cache_hit": False,
                "cache_path": str(cache_path), "build_seconds": float(build_seconds),
                "timed_out": False, "skipped": False,
            }
            _QUICK_CHECK_MEMORY_CACHE[memory_key] = (quick_check, dict(metadata))
            return quick_check, metadata
    except TimeoutError:
        elapsed = time.monotonic() - budget_start
        stage_log(
            "QuickCheck",
            f"{instance_dir.name}: timeout after {elapsed:.3f}s; skip QuickCheck and continue",
        )
        quick_check = []
        metadata = {
            "cache_hit": False, "memory_cache_hit": False,
            "cache_path": str(cache_path), "build_seconds": float(elapsed),
            "timed_out": True, "skipped": True,
        }
        _QUICK_CHECK_MEMORY_CACHE[memory_key] = (quick_check, dict(metadata))
        return quick_check, metadata


@dataclass
class PreparedInstanceResources:
    instance_dir: Path
    param: tuple[str, str, str]
    eval_func: Any
    evaluator_name: str
    data_folder: str
    quick_check: list[list[int]]
    quick_check_metadata: dict
    Aw: Any
    Au: Any
    Av: Any
    factors: Any
    statistic_factor_seconds: float
    dominance_preprocessing_seconds: float
    dominance_stats: dict


def prepare_instance_resources(
    instance_dir: Path,
    p0: float,
    lambda_value: float,
    quick_check_cache_dir: Optional[Path] = None,
    quick_check_timeout_seconds: float = 1.0,
) -> PreparedInstanceResources:
    """Prepare all instance-level data once and reuse it for every Tmax/run."""
    key = (str(instance_dir.resolve()), float(p0), float(lambda_value))
    cached = _INSTANCE_RESOURCE_CACHE.get(key)
    if cached is not None:
        stage_log("Prepare", f"{instance_dir.name}: in-memory instance resources reused")
        return cached

    param_list = parse_param(instance_dir)
    param = (str(param_list[0]), str(param_list[1]), str(param_list[2]))
    eval_func, evaluator_name = choose_evaluator(param)
    m, L = int(param[0]), int(param[2])

    stage_log("QuickCheck", f"{instance_dir.name}: prepare/start")
    qc_start = time.perf_counter()
    quick_check, quick_meta = load_or_build_quick_check(
        instance_dir,
        m,
        L,
        p0,
        cache_dir=quick_check_cache_dir,
        timeout_seconds=float(quick_check_timeout_seconds),
    )
    qc_total = time.perf_counter() - qc_start
    hit_kind = (
        "skipped-timeout" if quick_meta.get("timed_out") else
        ("memory-hit" if quick_meta.get("memory_cache_hit") else
         ("disk-hit" if quick_meta.get("cache_hit") else "built"))
    )
    stage_log(
        "QuickCheck",
        f"{instance_dir.name}: prepare/done mode={hit_kind} rows={len(quick_check)} "
        f"elapsed={qc_total:.3f}s cache={quick_meta.get('cache_path')}",
    )

    data_folder = repo_relative(instance_dir)
    stage_log(
        "StatisticFactor",
        f"{instance_dir.name}: read/start (one time for all Tmax/runs in this process)",
    )
    sf_start = time.perf_counter()
    Aw, Au, Av, factors = Statistic_factor(param, float(lambda_value), data_folder)
    sf_seconds = time.perf_counter() - sf_start
    stage_log(
        "StatisticFactor",
        f"{instance_dir.name}: read/done factors={len(factors)} elapsed={sf_seconds:.3f}s",
    )

    stage_log("Dominance", f"{instance_dir.name}: empirical stochastic-dominance preprocessing/start")
    dom_start = time.perf_counter()
    Aw, Au, Av, dom_stats_obj = empirical_stochastic_dominance_preprocess(
        Aw, Au, Av, factors
    )
    dom_seconds = time.perf_counter() - dom_start
    dom_stats = dom_stats_obj.to_dict()
    stage_log(
        "Dominance",
        f"{instance_dir.name}: done removed={dom_stats['removed_item_count']} "
        f"retained={dom_stats['retained_item_count']}/{dom_stats['original_item_count']} "
        f"elapsed={dom_seconds:.3f}s",
    )

    prepared = PreparedInstanceResources(
        instance_dir=instance_dir,
        param=param,
        eval_func=eval_func,
        evaluator_name=evaluator_name,
        data_folder=data_folder,
        quick_check=quick_check,
        quick_check_metadata=quick_meta,
        Aw=Aw,
        Au=Au,
        Av=Av,
        factors=factors,
        statistic_factor_seconds=float(sf_seconds),
        dominance_preprocessing_seconds=float(dom_seconds),
        dominance_stats=dom_stats,
    )
    _INSTANCE_RESOURCE_CACHE[key] = prepared
    return prepared


def resolve_instance_dir(instance: str) -> Path:
    p = Path(instance)
    candidates = []
    if p.is_absolute():
        candidates.append(p)
    else:
        candidates.extend(
            [
                REPO_ROOT / instance,
                REPO_ROOT / "benchmark" / instance,
                REPO_ROOT / "benchmark" / "benchmark" / instance,
            ]
        )

        normalized = instance.replace("Instance_app_", "APP_").replace("Instance_lab_", "LAB_")
        normalized = normalized.replace("Instance_APP_", "APP_").replace("Instance_LAB_", "LAB_")
        candidates.extend(
            [
                REPO_ROOT / "benchmark" / normalized,
                REPO_ROOT / "benchmark" / "benchmark" / normalized,
            ]
        )

    for c in candidates:
        if c.is_dir() and (c / "cost.txt").is_file() and (c / "node_to_factor.pkl").is_file():
            return c.resolve()
    raise FileNotFoundError(f"Cannot locate benchmark instance: {instance}")


def repo_relative(path: Path) -> str:
    return os.path.relpath(str(path), str(REPO_ROOT))


def parse_param(instance_dir: Path):
    numbers = re.findall(r"\d+", instance_dir.name)
    if len(numbers) < 3:
        raise ValueError(f"Cannot parse m, N, L from {instance_dir.name}")
    return numbers[:3]


def choose_evaluator(param):
    m, L = int(param[0]), int(param[2])
    if L ** m < 10 ** 7:
        return reference_advanced_exact_evaluation, "author_reference_exact"
    return reference_advanced_monte_carlo, "author_reference_advanced_monte_carlo"


def _make_mc_sampler(evaluation_function):
    # Exact author protocol uses fresh draws, so all fixed-stream samplers are disabled.
    return None


def known_gurobi(instance_name: str, tmax: float, p0: float):
    for (name, t, p), value in KNOWN_GUROBI_EXACT.items():
        if name == instance_name and abs(t - tmax) < 1e-12 and abs(p - p0) < 1e-12:
            return value
    return None


def write_csv(path: Path, fieldnames, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _hamming_distance(a, b):
    aa = np.asarray(a, dtype=int)
    bb = np.asarray(b, dtype=int)
    return int(np.count_nonzero(aa != bb))


def run_one(
    prepared: PreparedInstanceResources,
    tmax: float,
    p0: float,
    lambda_value: float,
    max_iter: int,
    no_improve_limit: int,
    tabu_tenure: int,
    mc_samples: int,
    seed: int,
    time_limit: Optional[float],
    eval_budget: Optional[int],
    output_dir: Path,
    gurobi_optimum: Optional[float],
    init_time_limit: float,
    init_pilot_samples: int,
    init_validation_samples: int,
    init_safe_reserve: float,
    grasp_rcl_size: int,
    restart_no_improve_cycles: int,
    ms_max_starts: int,
    lr_guidance_enabled: bool,
    lr_saa_samples: int,
    lr_guidance_time_limit: float,
    lr_max_iterations: int,
    lr_step_theta: float,
    lr_theta_decay: float,
    lr_theta_min: float,
    lr_stagnation_limit: int,
    lr_saa_seed_offset: int,
    pr_ablation: str = "lr-risk-pr",
    hit_targets: Optional[Sequence[float]] = None,
    verbose_search: bool = False,
):
    """Run one 10.3 LR-OperationTabu/QD-Elite/Path-Relinking replicate.

    The baseline LR-guided multi-start DDTS trajectory and Operation Tabu are
    retained.  Elite memory and path relinking are auxiliary intensification
    layers inside the same global run budget; feasibility remains controlled by
    the original evaluator.  All starts share the same Delta-MC CRN seed while
    their search RNG streams differ.
    """
    # 10.3 keeps one hard resource limit: the 600-second run deadline.
    # Phase transitions (initialization, LR learning, PR, restart) are driven by
    # algorithmic completion/stagnation conditions rather than fixed stage time shares.
    time_limit = GLOBAL_RUN_TIME_LIMIT_SECONDS
    eval_budget = None
    ms_max_starts = 0
    grasp_rcl_size = max(1, int(grasp_rcl_size))
    restart_no_improve_cycles = max(1, int(restart_no_improve_cycles))

    np.random.seed(int(seed))
    random.seed(int(seed))

    instance_dir = prepared.instance_dir
    param = prepared.param
    eval_func = prepared.eval_func
    evaluator_name = prepared.evaluator_name
    mc_sampler = _make_mc_sampler(eval_func)
    quick_check = prepared.quick_check
    Aw, Au, Av, factors = prepared.Aw, prepared.Au, prepared.Av, prepared.factors

    run_prefix = f"{instance_dir.name} Tmax={tmax:g} seed={seed}"
    wall_start = time.perf_counter()
    run_budget_start = time.monotonic()
    run_deadline = run_budget_start + time_limit
    from src.functions.rl_balanced import Learner
    rl_learner = Learner(seed)
    rl_best_events = []

    global_best_solution = None
    global_best_cost = float("inf")
    global_best_p = 0.0
    global_best_search_p = 0.0
    global_best_found_time = None
    global_best_gap = None

    total_eval_count = 0
    total_cycles = 0
    total_class_scans = 0
    total_tabu_moves = 0
    total_pair_exchanges = total_pair_evaluations = total_pair_proposals = 0
    total_tail_proposals = total_tail_rebuilds = total_tail_deferred = 0
    total_tail_seconds = 0.0
    total_perturbations = 0
    total_qc_skips = 0
    total_delta_evals = 0
    total_delta_early = 0
    total_delta_full = 0
    total_delta_samples = 0
    total_delta_init_seconds = 0.0
    total_init_runtime = 0.0
    total_init_repairs = 0
    total_init_validation_attempts = 0
    total_init_validation_samples_used = 0
    first_ttff = None
    init_authoritative_probability_cache = {}

    all_convergence = []
    search_ablation_activity = []
    all_moves = []
    all_perturbations = []
    start_rows = []
    start_initial_solutions = []
    # Diagnostics only: keep exact pairwise Hamming aggregates without storing
    # O(S^2) individual distances across many multi-start restarts.
    pairwise_hamming_count = 0
    pairwise_hamming_sum = 0.0
    pairwise_hamming_min = None
    pairwise_hamming_max = None
    start_id = 0
    final_stop_reason = "time_limit"

    # Lagrangian guidance is learned once per run after the first (unaltered)
    # 9.14 start has produced a feasible incumbent.  The learning time is part
    # of the same global wall-clock budget.  The learned ranking is used only
    # by LR-guided GRASP restarts; it never changes DDTS feasibility or moves.
    lr_guidance = None
    lr_learning_attempted = False
    lr_learning_rows = []
    lr_original_restart_count = 0
    lr_guided_restart_count = 0
    lr_original_improvement_count = 0
    lr_guided_improvement_count = 0
    lr_original_total_improvement = 0.0
    lr_guided_total_improvement = 0.0

    pr_ablation = str(pr_ablation).strip().lower()
    valid_pr_modes = {"baseline", "elite-pr", "lr-pr", "lr-risk-pr"}
    if pr_ablation not in valid_pr_modes:
        raise ValueError(f"unsupported pr_ablation={pr_ablation!r}; choose one of {sorted(valid_pr_modes)}")
    pr_enabled = pr_ablation != "baseline"
    pr_lr_guided = pr_ablation in {"lr-pr", "lr-risk-pr"}
    pr_risk_bridge = pr_ablation == "lr-risk-pr"
    elite_pool = QualityDiversityElitePool(int(param[0])) if pr_enabled else None
    elite_rows = []
    pr_rows = []
    pr_step_rows = []
    attempted_pr_pairs = set()
    pr_invocations = pr_completed = pr_new_best_count = 0
    pr_bridge_attempts = pr_bridge_successes = 0
    pr_total_path_length = pr_total_eval = pr_total_delta_samples = 0
    pr_total_runtime = pr_continuation_count = 0
    pr_continuation_improvement = 0.0

    while time.monotonic() < run_deadline:
        remaining_global = max(0.0, run_deadline - time.monotonic())
        if remaining_global <= 0.0:
            final_stop_reason = "time_limit"
            break
        # Learn SAA Lagrangian scenario prices once, immediately before the
        # first restart.  Start 0 therefore remains exactly the original 9.14
        # deterministic FastInit + DDTS trajectory.
        if (
            start_id > 0
            and bool(lr_guidance_enabled)
            and not lr_learning_attempted
            and global_best_solution is not None
        ):
            lr_learning_attempted = True
            remaining_global = max(0.0, run_deadline - time.monotonic())
            if remaining_global > 1e-6:
                stage_log(
                    "LR-Guide",
                    f"{run_prefix}: learning/start SAA={int(lr_saa_samples)} "
                    f"remaining_global={remaining_global:.3f}s UB={global_best_cost:.12g}",
                )
                # No fixed LR stage-time slice: stop on learner convergence/iteration
                # logic or the single global run deadline.
                lr_deadline = run_deadline
                try:
                    lr_guidance = learn_lagrangian_restart_guidance(
                        node_resort_w=Aw,
                        factor_id2obj=factors,
                        p0=float(p0),
                        tmax=float(tmax),
                        sample_size=int(lr_saa_samples),
                        base_seed=int(seed) + int(lr_saa_seed_offset),
                        upper_bound_cost=float(global_best_cost),
                        upper_bound_solution=np.asarray(global_best_solution, dtype=int).tolist(),
                        deadline_monotonic=lr_deadline,
                        max_iterations=int(lr_max_iterations),
                        theta=float(lr_step_theta),
                        theta_decay=float(lr_theta_decay),
                        theta_min=float(lr_theta_min),
                        stagnation_limit=int(lr_stagnation_limit),
                    )
                    lr_learning_rows = list(lr_guidance.iteration_log)
                    stage_log(
                        "LR-Guide",
                        f"{run_prefix}: learning/done iter={lr_guidance.iteration_count} "
                        f"runtime={lr_guidance.runtime_seconds:.3f}s "
                        f"best_dual={lr_guidance.best_dual_bound:.12g} "
                        f"lambda_nz={lr_guidance.lambda_nonzero_count}",
                    )
                except Exception as exc:
                    # Guidance is auxiliary only.  If it fails, preserve the
                    # original 9.14 search rather than failing the run.
                    lr_guidance = None
                    stage_log("LR-Guide", f"{run_prefix}: learning/failed fallback=original error={exc}")

        # Start 0 is the exact 9.8.1 deterministic seed.  Later restarts mix
        # original GRASP and LR-guided GRASP in a deterministic 50/50 pattern:
        # odd restart IDs use LR ranking, even restart IDs use original utility
        # ranking.  If LR learning is unavailable, all restarts fall back to
        # original GRASP.
        rcl_size_this_start = 1 if start_id == 0 else grasp_rcl_size
        if start_id == 0:
            restart_type = "initial"
            candidate_order = None
        elif lr_guidance is not None and (start_id % 2 == 1):
            restart_type = "lr_guided"
            candidate_order = lr_guidance.rankings_by_class
            lr_guided_restart_count += 1
        else:
            restart_type = "original"
            candidate_order = None
            lr_original_restart_count += 1
        randomized_seed = int(seed + 100003 * start_id + 17)
        global_before_start = float(global_best_cost)
        # No fixed initialization stage-time slice.
        init_deadline = run_deadline

        stage_log(
            "MS-Init",
            f"{run_prefix}: start={start_id} type={restart_type} rcl={rcl_size_this_start} "
            f"remaining={remaining_global:.3f}s",
        )
        try:
            cp, init_meta = Fast_Construct_Procedure(
                eval_func,
                Aw,
                Au,
                factors,
                p0,
                tmax,
                param,
                pilot_samples=int(init_pilot_samples),
                validation_samples=int(init_validation_samples),
                run_seed=int(seed),
                deadline_monotonic=init_deadline,
                safe_reserve_seconds=0.0,
                verbose=False,
                randomized_rcl_size=int(rcl_size_this_start),
                randomized_seed=int(randomized_seed),
                randomized_candidate_order=candidate_order,
                authoritative_mc_samples=int(mc_samples),
                authoritative_probability_cache=init_authoritative_probability_cache,
                mc_context_factory=mc_sampler,
                quick_check_list=quick_check,
                use_cost_risk_seed=USE_COST_RISK_INITIALIZATION,
            )
        except NoFeasibleInitialSolution as exc:
            # The original deterministic start is mandatory.  A failed later
            # randomized restart is simply skipped if global time remains.
            if start_id == 0:
                raise
            stage_log("MS-Init", f"{run_prefix}: start={start_id} skipped: {exc}")
            start_id += 1
            continue

        if start_id == 0 and mc_sampler is not None:
            stage_log("MC-Sampler", f"{run_prefix}: M={mc_samples} P0={p0} plan={mc_sampler.metadata()}")

        init_runtime = float(init_meta.get("runtime_seconds", 0.0))
        total_init_runtime += init_runtime
        total_init_repairs += int(init_meta.get("repair_count", 0))
        total_init_validation_attempts += int(init_meta.get("validation_attempt_count", 0))
        total_init_validation_samples_used += int(init_meta.get("validation_samples_used", 0))
        if first_ttff is None and init_meta.get("ttff_seconds") is not None:
            first_ttff = float(init_meta["ttff_seconds"])

        initial_solution = np.asarray(cp[0], dtype=int).copy()
        hamming_values = [_hamming_distance(initial_solution, prev) for prev in start_initial_solutions]
        min_hamming = min(hamming_values) if hamming_values else None
        mean_hamming = mean(hamming_values) if hamming_values else None
        if hamming_values:
            pairwise_hamming_count += len(hamming_values)
            pairwise_hamming_sum += float(sum(hamming_values))
            local_min = min(hamming_values)
            local_max = max(hamming_values)
            pairwise_hamming_min = local_min if pairwise_hamming_min is None else min(pairwise_hamming_min, local_min)
            pairwise_hamming_max = local_max if pairwise_hamming_max is None else max(pairwise_hamming_max, local_max)
        start_initial_solutions.append(initial_solution.copy())

        # The feasible initialized solution is known at this global wall time.
        init_known_global_time = float(time.monotonic() - run_budget_start)
        if float(cp[1]) < global_best_cost - 1e-12:
            global_best_solution = initial_solution.copy()
            global_best_cost = float(cp[1])
            global_best_p = float(cp[2])
            global_best_search_p = float(cp[2])
            global_best_found_time = init_known_global_time
            rl_best_events.append(dict(cost=global_best_cost, elapsed_seconds=init_known_global_time, source="initialization"))
            global_best_gap = (
                None if gurobi_optimum is None
                else (global_best_cost - float(gurobi_optimum)) / float(gurobi_optimum) * 100.0
            )

        remaining_global = max(0.0, run_deadline - time.monotonic())
        if remaining_global <= 0.0:
            final_stop_reason = "time_limit"
            break

        # Evaluation count is diagnostic only; it never stops a 9.21-fixed run.
        remaining_eval_budget = None

        search_seed = int(seed if start_id == 0 else seed + 100003 * start_id + 7919)
        np.random.seed(search_seed)
        random.seed(search_seed)
        search_global_offset = float(time.monotonic() - run_budget_start)

        def ts_progress(message: str):
            stage_log("TS", f"{run_prefix}: start={start_id} {message}")

        stage_log(
            "TS",
            f"{run_prefix}: start={start_id} search/start remaining={remaining_global:.3f}s "
            f"restart_after={restart_no_improve_cycles}cycles",
        )
        rl_learner.observe_global(global_best_cost)
        result = Data_Driven_Tabu_Search(
            eval_func,
            cp,
            Av,
            factors,
            p0,
            tmax,
            param,
            max_iter,
            mc_samples,
            quick_check,
            tabu_tenure=tabu_tenure,
            no_improve_limit=no_improve_limit,
            time_limit_seconds=remaining_global,
            evaluation_budget=remaining_eval_budget,
            gurobi_optimum=gurobi_optimum,
            progress_callback=ts_progress if verbose_search else None,
            run_seed=search_seed,
            crn_seed=int(seed),
            perturbation_learner=rl_learner,
            restart_no_improve_cycles=restart_no_improve_cycles,
            mc_context_factory=mc_sampler,
            perturbation_policy=PERTURBATION_POLICY,
            pair_exchange_pilot_samples=init_pilot_samples,
        )

        for event in getattr(result, "rl_best_events", []):
            if not rl_best_events or event["cost"] < rl_best_events[-1]["cost"] - 1e-12:
                rl_best_events.append(dict(cost=event["cost"], elapsed_seconds=search_global_offset + event["elapsed_seconds"], source="search"))
        search_ablation_activity.append(getattr(result, 'search_ablation_activity', {'evaluator_branch':'exact_legacy'}))
        total_eval_count += int(result.evaluation_count)
        total_cycles += int(result.completed_cycles)
        total_class_scans += int(result.total_class_scans)
        total_tail_proposals += int(getattr(result, "tail_proposal_count", 0))
        total_tail_rebuilds += int(getattr(result, "tail_proposal_rebuild_count", 0))
        total_tail_deferred += int(getattr(result, "tail_deferred_evaluation_count", 0))
        total_tail_seconds += float(getattr(result, "tail_proposal_seconds", 0))
        total_pair_exchanges += int(result.pair_exchange_count)
        total_pair_evaluations += int(result.pair_exchange_evaluation_count)
        total_pair_proposals += int(result.pair_exchange_proposal_count)
        total_tabu_moves += int(result.total_tabu_moves)
        total_perturbations += int(result.perturbation_count)
        total_qc_skips += int(result.amc_quickcheck_prefilter_skip_count)
        total_delta_evals += int(result.delta_mc_evaluation_count)
        total_delta_early += int(result.delta_mc_early_reject_count)
        total_delta_full += int(result.delta_mc_full_evaluation_count)
        total_delta_samples += int(result.delta_mc_samples_used)
        total_delta_init_seconds += float(result.delta_mc_initialization_seconds)

        candidate_global_time = search_global_offset + float(result.best_found_time_seconds)
        improved_run_global = result.cost < global_best_cost - 1e-12
        if improved_run_global:
            global_best_solution = np.asarray(result.solution, dtype=int).copy()
            global_best_cost = float(result.cost)
            global_best_p = float(result.probability)
            global_best_search_p = float(result.search_probability)
            global_best_found_time = float(candidate_global_time)
            global_best_gap = result.heuristic_gap_percent

        # 10.3 quality-diversity elite memory + event-triggered path relinking.
        # PR is an internal phase transition: no fixed PR time budget is allocated.
        # It is attempted only after the current DDTS phase reaches a natural
        # stagnation/neighborhood-exhaustion boundary and an untried elite guide exists.
        pr_invoked_this = False
        pr_continued_this = False
        pr_improvement_this = 0.0
        pr_start_best = float(global_best_cost)
        start_effective_best_cost = float(result.cost)
        start_effective_best_probability = float(result.probability)

        if pr_enabled and elite_pool is not None:
            elite_rows.append({
                "start_id": int(start_id),
                "global_elapsed_seconds": float(time.monotonic() - run_budget_start),
                **elite_pool.observe(result.solution, result.cost, result.probability,
                                      source="ddts_local_best",
                                      discovered_at=float(time.monotonic() - run_budget_start)),
            })
            pr_trigger = result.stop_reason in {"stagnation_restart", "no_admissible_neighbor"}
            guide_entry = elite_pool.guiding_entry(result.solution) if pr_trigger else None
            pair_key = None if guide_entry is None else (tuple(int(v) for v in result.solution), guide_entry.solution, pr_ablation)
            if (guide_entry is not None and pair_key not in attempted_pr_pairs
                    and time.monotonic() < run_deadline):
                attempted_pr_pairs.add(pair_key)
                pr_invoked_this = True
                pr_invocations += 1
                stage_log(
                    "PR",
                    f"{run_prefix}: start={start_id} begin mode={pr_ablation} "
                    f"distance={_hamming_distance(result.solution, guide_entry.solution)} "
                    f"elite_size={len(elite_pool.entries)}",
                )
                pr = path_relink(
                    eval_func, result.solution, result.cost, result.probability,
                    guide_entry.solution, Av, factors, p0, tmax, param, mc_samples, quick_check,
                    run_seed=int(seed), deadline_monotonic=run_deadline,
                    rankings_by_class=None if lr_guidance is None else lr_guidance.rankings_by_class,
                    lr_guided=bool(pr_lr_guided and lr_guidance is not None),
                    risk_bridge=bool(pr_risk_bridge),
                    mc_context_factory=mc_sampler,
                )
                pr_completed += int(pr.completed)
                pr_bridge_attempts += int(pr.bridge_attempts)
                pr_bridge_successes += int(pr.bridge_successes)
                pr_total_path_length += int(pr.path_length)
                pr_total_eval += int(pr.evaluation_count)
                pr_total_delta_samples += int(pr.delta_mc_samples_used)
                pr_total_runtime += float(pr.runtime_seconds)
                total_eval_count += int(pr.evaluation_count)
                total_delta_samples += int(pr.delta_mc_samples_used)
                for step in pr.step_rows:
                    pr_step_rows.append({"start_id": int(start_id), **step})

                pr_best_before = float(global_best_cost)
                if pr.best_intermediate_solution is not None:
                    elite_rows.append({
                        "start_id": int(start_id),
                        "global_elapsed_seconds": float(time.monotonic() - run_budget_start),
                        **elite_pool.observe(
                            pr.best_intermediate_solution, pr.best_intermediate_cost,
                            pr.best_intermediate_probability, source="pr_intermediate",
                            discovered_at=float(time.monotonic() - run_budget_start),
                        ),
                    })
                    if float(pr.best_intermediate_cost) < global_best_cost - 1e-12:
                        global_best_solution = np.asarray(pr.best_intermediate_solution, dtype=int).copy()
                        global_best_cost = float(pr.best_intermediate_cost)
                        global_best_p = float(pr.best_intermediate_probability)
                        global_best_search_p = float(pr.best_intermediate_probability)
                        global_best_found_time = float(time.monotonic() - run_budget_start)
                        global_best_gap = (
                            None if gurobi_optimum is None else
                            (global_best_cost - float(gurobi_optimum)) / float(gurobi_optimum) * 100.0
                        )
                        pr_new_best_count += 1
                    if float(pr.best_intermediate_cost) < start_effective_best_cost - 1e-12:
                        start_effective_best_cost = float(pr.best_intermediate_cost)
                        start_effective_best_probability = float(pr.best_intermediate_probability)

                    # Selective local search: continue DDTS from exactly one path
                    # intermediate (the best feasible one), never from every path state.
                    remaining_after_pr = max(0.0, run_deadline - time.monotonic())
                    if remaining_after_pr > 1e-6:
                        pr_continued_this = True
                        pr_continuation_count += 1
                        continuation_seed = int(search_seed + 15485863)
                        np.random.seed(continuation_seed)
                        random.seed(continuation_seed)
                        cp_pr = [
                            [int(v) for v in pr.best_intermediate_solution],
                            float(pr.best_intermediate_cost),
                            float(pr.best_intermediate_probability),
                            0,
                        ]
                        cont = Data_Driven_Tabu_Search(
                            eval_func, cp_pr, Av, factors, p0, tmax, param, max_iter,
                            mc_samples, quick_check, tabu_tenure=tabu_tenure,
                            no_improve_limit=no_improve_limit,
                            time_limit_seconds=remaining_after_pr, evaluation_budget=None,
                            gurobi_optimum=gurobi_optimum, progress_callback=ts_progress if verbose_search else None,
                            run_seed=continuation_seed, crn_seed=int(seed),
                            restart_no_improve_cycles=restart_no_improve_cycles,
                            mc_context_factory=mc_sampler,
                            perturbation_policy=PERTURBATION_POLICY,
                            pair_exchange_pilot_samples=init_pilot_samples,
                        )
                        search_ablation_activity.append(getattr(cont, 'search_ablation_activity', {'evaluator_branch':'exact_legacy'}))
                        total_eval_count += int(cont.evaluation_count)
                        total_cycles += int(cont.completed_cycles)
                        total_class_scans += int(cont.total_class_scans)
                        total_tail_proposals += int(getattr(cont, "tail_proposal_count", 0))
                        total_tail_rebuilds += int(getattr(cont, "tail_proposal_rebuild_count", 0))
                        total_tail_deferred += int(getattr(cont, "tail_deferred_evaluation_count", 0))
                        total_tail_seconds += float(getattr(cont, "tail_proposal_seconds", 0))
                        total_pair_exchanges += int(cont.pair_exchange_count)
                        total_pair_evaluations += int(cont.pair_exchange_evaluation_count)
                        total_pair_proposals += int(cont.pair_exchange_proposal_count)
                        total_tabu_moves += int(cont.total_tabu_moves)
                        total_perturbations += int(cont.perturbation_count)
                        total_qc_skips += int(cont.amc_quickcheck_prefilter_skip_count)
                        total_delta_evals += int(cont.delta_mc_evaluation_count)
                        total_delta_early += int(cont.delta_mc_early_reject_count)
                        total_delta_full += int(cont.delta_mc_full_evaluation_count)
                        total_delta_samples += int(cont.delta_mc_samples_used)
                        total_delta_init_seconds += float(cont.delta_mc_initialization_seconds)
                        for row in cont.convergence_log:
                            rr = dict(row); rr["start_id"] = int(start_id); rr["phase"] = "post_pr_ddts"
                            all_convergence.append(rr)
                        for row in cont.tabu_move_log:
                            rr = dict(row); rr["start_id"] = int(start_id); rr["phase"] = "post_pr_ddts"
                            all_moves.append(rr)
                        for row in cont.perturbation_log:
                            rr = dict(row); rr["start_id"] = int(start_id); rr["phase"] = "post_pr_ddts"
                            all_perturbations.append(rr)
                        elite_rows.append({
                            "start_id": int(start_id),
                            "global_elapsed_seconds": float(time.monotonic() - run_budget_start),
                            **elite_pool.observe(cont.solution, cont.cost, cont.probability,
                                                source="post_pr_ddts",
                                                discovered_at=float(time.monotonic() - run_budget_start)),
                        })
                        if float(cont.cost) < float(pr.best_intermediate_cost) - 1e-12:
                            pr_continuation_improvement += float(pr.best_intermediate_cost - cont.cost)
                        if float(cont.cost) < start_effective_best_cost - 1e-12:
                            start_effective_best_cost = float(cont.cost)
                            start_effective_best_probability = float(cont.probability)
                        if float(cont.cost) < global_best_cost - 1e-12:
                            global_best_solution = np.asarray(cont.solution, dtype=int).copy()
                            global_best_cost = float(cont.cost)
                            global_best_p = float(cont.probability)
                            global_best_search_p = float(cont.search_probability)
                            global_best_found_time = float(time.monotonic() - run_budget_start)
                            global_best_gap = cont.heuristic_gap_percent
                            pr_new_best_count += 1

                pr_improvement_this = max(0.0, pr_best_before - float(global_best_cost))
                pr_rows.append({
                    "start_id": int(start_id),
                    "mode": pr_ablation,
                    "lr_guided": bool(pr_lr_guided and lr_guidance is not None),
                    "risk_bridge_enabled": bool(pr_risk_bridge),
                    "elite_pool_size": len(elite_pool.entries),
                    "guiding_distance": int(pr.guiding_distance),
                    "path_length": int(pr.path_length),
                    "accepted_single_moves": int(pr.accepted_single_moves),
                    "bridge_attempts": int(pr.bridge_attempts),
                    "bridge_successes": int(pr.bridge_successes),
                    "lr_first_choice_hits": int(pr.lr_first_choice_hits),
                    "lr_ranked_moves_considered": int(pr.lr_ranked_moves_considered),
                    "completed": bool(pr.completed),
                    "stop_reason": str(pr.stop_reason),
                    "evaluation_count": int(pr.evaluation_count),
                    "delta_mc_samples_used": int(pr.delta_mc_samples_used),
                    "runtime_seconds": float(pr.runtime_seconds),
                    "best_intermediate_cost": pr.best_intermediate_cost,
                    "best_intermediate_probability": pr.best_intermediate_probability,
                    "continued_ddts": bool(pr_continued_this),
                    "global_best_improvement": float(pr_improvement_this),
                })
                stage_log(
                    "PR",
                    f"{run_prefix}: start={start_id} done path={pr.path_length} "
                    f"bridge={pr.bridge_successes}/{pr.bridge_attempts} "
                    f"improve={pr_improvement_this:.12g} stop={pr.stop_reason}",
                )

        # Attribute the net global-best decrease achieved during this complete
        # restart (initializer + DDTS + optional PR + selective continuation) to its restart channel.
        restart_improvement = 0.0
        if start_id > 0 and np.isfinite(global_before_start) and global_best_cost < global_before_start - 1e-12:
            restart_improvement = float(global_before_start - global_best_cost)
            if restart_type == "lr_guided":
                lr_guided_improvement_count += 1
                lr_guided_total_improvement += restart_improvement
            elif restart_type == "original":
                lr_original_improvement_count += 1
                lr_original_total_improvement += restart_improvement

        for row in result.convergence_log:
            rr = dict(row)
            rr["start_id"] = int(start_id)
            all_convergence.append(rr)
        for row in result.tabu_move_log:
            rr = dict(row)
            rr["start_id"] = int(start_id)
            all_moves.append(rr)
        for row in result.perturbation_log:
            rr = dict(row)
            rr["start_id"] = int(start_id)
            all_perturbations.append(rr)

        start_rows.append(
            {
                "start_id": int(start_id),
                "restart_type": str(restart_type),
                "lr_guided": bool(restart_type == "lr_guided"),
                "rcl_size": int(rcl_size_this_start),
                "randomized_seed": int(randomized_seed),
                "search_seed": int(search_seed),
                "initial_cost": float(cp[1]),
                "initial_probability": float(cp[2]),
                "initialization_source": init_meta.get("source"),
                "initialization_runtime_seconds": init_runtime,
                "min_hamming_to_previous_starts": min_hamming,
                "mean_hamming_to_previous_starts": mean_hamming,
                "best_cost": float(start_effective_best_cost),
                "best_probability": float(start_effective_best_probability),
                "local_time_to_best_seconds": float(result.best_found_time_seconds),
                "global_time_candidate_seconds": float(candidate_global_time),
                "improved_run_global_best": bool(global_best_cost < global_before_start - 1e-12 if start_id > 0 else improved_run_global),
                "restart_global_best_improvement": float(restart_improvement),
                "completed_cycles": int(result.completed_cycles),
                "evaluation_count": int(result.evaluation_count),
                "stop_reason": result.stop_reason,
                "pr_invoked": bool(pr_invoked_this),
                "pr_continued_ddts": bool(pr_continued_this),
                "pr_global_best_improvement": float(pr_improvement_this),
            }
        )

        stage_log(
            "TS",
            f"{run_prefix}: start={start_id} done cost={result.cost:.12g} "
            f"cycles={result.completed_cycles} stop={result.stop_reason} "
            f"run_best={global_best_cost:.12g}",
        )

        start_id += 1
        if result.stop_reason == "time_limit" or time.monotonic() >= run_deadline:
            final_stop_reason = "time_limit"
            break
        # ``stagnation_restart`` is an internal phase transition, not a run
        # termination condition.  The outer loop therefore continues until the
        # single 600-second global deadline is reached.

    total_runtime = float(time.perf_counter() - wall_start)
    if global_best_solution is None:
        raise NoFeasibleInitialSolution("MS-DDTS failed to obtain any feasible start")

    run_id = f"{instance_dir.name}_T{tmax:g}_p{p0:g}_seed{seed}"
    run_dir = output_dir / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    valid, reason = validate_multiple_choice_solution(global_best_solution, Av)
    if not valid:
        raise AssertionError(reason)
    validation_cost = solution_cost(global_best_solution, factors)
    if abs(validation_cost - global_best_cost) > 1e-9:
        raise AssertionError("Final objective validation failed")

    payload = {
        "algorithm": ALGORITHM_NAME,
        "search_ablation_policy": get_policy(),
        "search_ablation_activity": search_ablation_activity,
        "rl_activity": rl_learner.snapshot(),
        "rl_window_trace": rl_learner.trace,
        "rl_best_event_trace": rl_best_events,
        "code_version": CODE_VERSION,
        "instance": instance_dir.name,
        "instance_path": str(instance_dir),
        "m": int(param[0]),
        "N": int(param[1]),
        "L": int(param[2]),
        "Tmax": float(tmax),
        "P0": float(p0),
        "lambda": float(lambda_value),
        "solution": [int(v) for v in global_best_solution],
        "cost": float(global_best_cost),
        "probability": float(global_best_p),
        "search_probability": float(global_best_search_p),
        "certified_feasible": bool(global_best_p + 1e-12 >= p0),
        "heuristic_gap_percent": global_best_gap,
        "best_found_time_seconds": float(global_best_found_time or 0.0),
        "total_runtime_seconds": total_runtime,
        "runtime_seconds": total_runtime,
        "stop_reason": final_stop_reason,
        "completed_cycles": int(total_cycles),
        "iterations": int(total_cycles),
        "total_class_scans": int(total_class_scans),
        "total_tabu_moves": int(total_tabu_moves),
        "perturbation_count": int(total_perturbations),
        "evaluation_count": int(total_eval_count),
        "amc_quickcheck_prefilter_skip_count": int(total_qc_skips),
        "delta_mc_enabled": bool(not getattr(eval_func, "reference_protocol", False)),
        "delta_mc_evaluation_count": int(total_delta_evals),
        "delta_mc_early_reject_count": int(total_delta_early),
        "delta_mc_full_evaluation_count": int(total_delta_full),
        "delta_mc_samples_used": int(total_delta_samples),
        "delta_mc_initialization_seconds": float(total_delta_init_seconds),
        "multi_start_count": int(len(start_rows)),
        "restart_count": int(max(0, len(start_rows) - 1)),
        "grasp_rcl_size": int(grasp_rcl_size),
        "restart_no_improve_cycles": int(restart_no_improve_cycles),
        "ms_max_starts": int(ms_max_starts),
        "initial_hamming_pair_count": int(pairwise_hamming_count),
        "initial_hamming_mean": (float(pairwise_hamming_sum) / pairwise_hamming_count) if pairwise_hamming_count else None,
        "initial_hamming_min": pairwise_hamming_min,
        "initial_hamming_max": pairwise_hamming_max,
        "same_crn_across_starts": False,
        "initialization_authoritative_full_m_validation": True,
        "initialization_authoritative_cache_size": len(init_authoritative_probability_cache),
        "first_start_preserves_9_8_1_initialization": bool(not getattr(eval_func, "reference_mc", False)),
        "max_iter": int(max_iter),
        "max_iter_used": False,
        "max_iter_semantics": "legacy_compatibility_only_global_time_and_restart_rule_used",
        "time_limit_seconds": float(time_limit),
        "search_mode": "lr_operation_tabu_quality_diversity_elite_path_relinking",
        "lr_guidance_enabled": bool(lr_guidance_enabled),
        "lr_guidance_learned": bool(lr_guidance is not None),
        "lr_saa_samples": int(lr_saa_samples),
        "lr_guidance_time_limit_seconds": float(lr_guidance_time_limit),
        "lr_guidance_fixed_stage_time_used": False,
        "lr_max_iterations": int(lr_max_iterations),
        "lr_restart_mix": "deterministic_alternating_50_50",
        "lr_original_restart_count": int(lr_original_restart_count),
        "lr_guided_restart_count": int(lr_guided_restart_count),
        "lr_original_improvement_count": int(lr_original_improvement_count),
        "lr_guided_improvement_count": int(lr_guided_improvement_count),
        "lr_original_total_improvement": float(lr_original_total_improvement),
        "lr_guided_total_improvement": float(lr_guided_total_improvement),
        "lr_guidance_summary": None if lr_guidance is None else lr_guidance.summary_dict(),
        "lr_guidance_only_affects_restart_rcl": bool(not pr_lr_guided),
        "original_model_and_full_m_validation_unchanged": bool(mc_sampler is None),
        "original_model_unchanged": True,
        "full_m_budget_unchanged": True,
        "sampling_plan": None,
        "evaluation_protocol": "author_archive_exact_protocol",
        "probability_cache_enabled": False,
        "fresh_mc_draws_each_evaluation": bool(getattr(eval_func, "reference_mc", False)),
        "mc_success_event": "sum_samples < Tmax",
        "mc_index_range": "[0, len(samples)-2]",
        "initialization_policy": "cost_risk_seed_then_reference_validated_repair" if getattr(eval_func, "reference_mc", False) else "utility_seed",
        "proposal_moments_only": True,
        "candidate_schedule": "tail_priority_single_compensating_pair_deferred_single" if getattr(eval_func, "reference_mc", False) else "legacy_classwise",
        "single_candidate_discard_rule": "none_only_tabu_and_objective_admissibility" if get_policy()["mc_deferred_singles"] or not get_policy()["mc_pilot_priority"] else "deferred_singles_omitted_in_search_ablation",
        "pair_proposal_risk_budget": "1-P0_not_current_violation_rate",
        "tail_proposal_count": total_tail_proposals,
        "tail_proposal_rebuild_count": total_tail_rebuilds,
        "tail_deferred_evaluation_count": total_tail_deferred,
        "tail_proposal_seconds": total_tail_seconds,
        "perturbation_policy": PERTURBATION_POLICY,
        "pair_exchange_count": int(total_pair_exchanges),
        "pair_exchange_evaluation_count": int(total_pair_evaluations),
        "pair_exchange_proposal_count": int(total_pair_proposals),
        "pair_exchange_pilot_role": "proposal_only_full_author_evaluator_for_acceptance",
        "no_improve_limit": int(no_improve_limit),
        "no_improve_limit_used": False,
        "tabu_tenure": int(tabu_tenure),
        "mc_sample_size": int(mc_samples),
        "seed": int(seed),
        "probability_evaluator": evaluator_name,
        "quick_check_cache_path": prepared.quick_check_metadata.get("cache_path"),
        "quick_check_cache_hit": bool(prepared.quick_check_metadata.get("cache_hit")),
        "quick_check_memory_cache_hit": bool(prepared.quick_check_metadata.get("memory_cache_hit")),
        "quick_check_build_seconds": float(prepared.quick_check_metadata.get("build_seconds", 0.0)),
        "quick_check_timed_out": bool(prepared.quick_check_metadata.get("timed_out", False)),
        "quick_check_skipped": bool(prepared.quick_check_metadata.get("skipped", False)),
        "statistic_factor_seconds": float(prepared.statistic_factor_seconds),
        "dominance_preprocessing_seconds": float(prepared.dominance_preprocessing_seconds),
        "empirical_dominance_original_item_count": int(prepared.dominance_stats["original_item_count"]),
        "empirical_dominance_retained_item_count": int(prepared.dominance_stats["retained_item_count"]),
        "empirical_dominance_removed_item_count": int(prepared.dominance_stats["removed_item_count"]),
        "empirical_dominance_removed_by_class": prepared.dominance_stats["removed_by_class"],
        "instance_preprocessing_shared_across_runs": True,
        "initialization_runtime_seconds": float(total_init_runtime),
        "cp_runtime_seconds": float(total_init_runtime),
        "ttff_seconds": first_ttff,
        "initialization_repair_count": int(total_init_repairs),
        "initialization_validation_attempt_count": int(total_init_validation_attempts),
        "initialization_validation_samples_used": int(total_init_validation_samples_used),
        "initialization_in_total_time_budget": True,
        "initialization_fixed_stage_time_used": False,
        "pr_ablation": pr_ablation,
        "elite_memory_enabled": bool(pr_enabled),
        "elite_capacity": None if elite_pool is None else int(elite_pool.capacity),
        "elite_final_size": 0 if elite_pool is None else int(len(elite_pool.entries)),
        "pr_invocation_count": int(pr_invocations),
        "pr_completed_count": int(pr_completed),
        "pr_new_best_count": int(pr_new_best_count),
        "pr_bridge_attempt_count": int(pr_bridge_attempts),
        "pr_bridge_success_count": int(pr_bridge_successes),
        "pr_total_path_length": int(pr_total_path_length),
        "pr_evaluation_count": int(pr_total_eval),
        "pr_delta_mc_samples_used": int(pr_total_delta_samples),
        "pr_runtime_seconds": float(pr_total_runtime),
        "pr_continuation_count": int(pr_continuation_count),
        "pr_continuation_total_improvement": float(pr_continuation_improvement),
        "hit_targets": [float(v) for v in (hit_targets or [])],
        "hit_target_flags": {str(float(v)): bool(global_best_cost <= float(v) + 1e-12) for v in (hit_targets or [])},
        "gurobi_optimum": gurobi_optimum,
    }

    with (run_dir / "result.json").open("w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

    write_csv(
        run_dir / "multistart.csv",
        [
            "start_id", "restart_type", "lr_guided", "rcl_size", "randomized_seed", "search_seed",
            "initial_cost", "initial_probability", "initialization_source",
            "initialization_runtime_seconds", "min_hamming_to_previous_starts",
            "mean_hamming_to_previous_starts", "best_cost", "best_probability",
            "local_time_to_best_seconds", "global_time_candidate_seconds",
            "improved_run_global_best", "restart_global_best_improvement",
            "completed_cycles", "evaluation_count", "stop_reason",
            "pr_invoked", "pr_continued_ddts", "pr_global_best_improvement",
        ],
        start_rows,
    )
    if lr_learning_rows:
        write_csv(
            run_dir / "lagrangian_guidance.csv",
            [
                "iteration", "elapsed_seconds", "dual_value", "best_dual_bound",
                "lagrangian_solution_cost", "step_size", "theta",
                "subgradient_norm", "lambda_min", "lambda_max", "lambda_mean",
                "lambda_nonzero_count",
            ],
            lr_learning_rows,
        )

    write_csv(
        run_dir / "convergence.csv",
        [
            "start_id", "cycle", "scan_position", "class_id", "total_class_scans",
            "total_tabu_moves", "event", "evaluation_count", "current_cost",
            "current_probability", "best_cost", "best_probability", "phase",
        ],
        all_convergence,
    )
    write_csv(
        run_dir / "tabu_moves.csv",
        [
            "start_id", "cycle", "scan_position", "total_class_scans",
            "total_tabu_moves", "class_id", "old_factor", "new_factor",
            "old_cost", "new_cost", "new_probability", "was_tabu",
            "aspiration_by_objective", "tabu_until_iteration",
            "improved_global_best", "phase",
        ],
        all_moves,
    )
    write_csv(
        run_dir / "perturbations.csv",
        [
            "start_id", "cycle", "success", "class_id", "old_factor",
            "new_factor", "old_cost", "new_cost", "new_probability",
            "tabu_until_iteration", "improved_global_best", "phase",
        ],
        all_perturbations,
    )
    if elite_rows:
        write_csv(run_dir / "elite_memory.csv", [
            "start_id", "global_elapsed_seconds", "action", "source", "candidate_cost",
            "pool_size", "capacity", "best_cost", "mean_cost", "min_pairwise_hamming",
            "mean_nearest_hamming", "observation_count", "accept_count", "duplicate_reject_count",
        ], elite_rows)
    if pr_rows:
        write_csv(run_dir / "path_relinking.csv", [
            "start_id", "mode", "lr_guided", "risk_bridge_enabled", "elite_pool_size",
            "guiding_distance", "path_length", "accepted_single_moves", "bridge_attempts",
            "bridge_successes", "lr_first_choice_hits", "lr_ranked_moves_considered",
            "completed", "stop_reason", "evaluation_count", "delta_mc_samples_used",
            "runtime_seconds", "best_intermediate_cost", "best_intermediate_probability",
            "continued_ddts", "global_best_improvement",
        ], pr_rows)
    if pr_step_rows:
        # Union of ordinary-move and bridge columns, kept sparse by design.
        step_fields = [
            "start_id", "path_step", "candidate_kind", "class_id", "bridge_class_id",
            "old_factor", "new_factor", "bridge_old_factor", "bridge_new_factor",
            "delta_cost", "delta_mean_risk", "delta_max_risk", "old_lr_rank", "new_lr_rank",
            "lr_rank_delta", "anchor_delta_mean_risk", "bridge_delta_mean_risk",
            "anchor_new_lr_rank", "bridge_new_lr_rank", "candidate_cost",
            "candidate_probability", "evaluation_source", "feasible", "accepted", "order_index",
        ]
        write_csv(run_dir / "path_relinking_steps.csv", step_fields, pr_step_rows)
    return payload


def _parallel_run_task(task: dict):
    """Execute one repeated run in a forked worker process.

    The heavy instance resources are prepared once in the parent and inherited
    through Linux ``fork``.  Only small scalar/run-specific arguments are sent
    through the process-pool task queue.
    """
    prepared = _RUN_POOL_PREPARED
    if prepared is None:
        raise RuntimeError(
            "Parallel run worker has no prepared instance resources. "
            "This mode requires a Linux/POSIX fork start method."
        )

    seed = int(task["seed"])
    tmax = float(task["tmax"])
    try:
        row = run_one(
            prepared,
            tmax,
            float(task["p0"]),
            float(task["lambda_value"]),
            int(task["max_iter"]),
            int(task["no_improve_limit"]),
            int(task["tabu_tenure"]),
            int(task["mc_samples"]),
            seed,
            task["time_limit"],
            task["eval_budget"],
            Path(task["output_dir"]),
            task["gurobi_optimum"],
            float(task["init_time_limit"]),
            int(task["init_pilot_samples"]),
            int(task["init_validation_samples"]),
            float(task["init_safe_reserve"]),
            int(task["grasp_rcl_size"]),
            int(task["restart_no_improve_cycles"]),
            int(task["ms_max_starts"]),
            bool(task["lr_guidance_enabled"]),
            int(task["lr_saa_samples"]),
            float(task["lr_guidance_time_limit"]),
            int(task["lr_max_iterations"]),
            float(task["lr_step_theta"]),
            float(task["lr_theta_decay"]),
            float(task["lr_theta_min"]),
            int(task["lr_stagnation_limit"]),
            int(task["lr_saa_seed_offset"]),
            str(task.get("pr_ablation", "lr-risk-pr")),
            task.get("hit_targets"),
            bool(task.get("verbose_search", False)),
        )
    except NoFeasibleInitialSolution as exc:
        meta = dict(getattr(exc, "metadata", {}) or {})
        row = {
            "algorithm": ALGORITHM_NAME,
            "instance": prepared.instance_dir.name,
            "Tmax": tmax,
            "P0": float(task["p0"]),
            "seed": seed,
            "certified_feasible": False,
            "cost": None,
            "probability": 0.0,
            "evaluation_count": int(meta.get("validation_attempt_count", 0)),
            "total_runtime_seconds": float(meta.get("runtime_seconds", 0.0)),
            "heuristic_gap_percent": None,
            "stop_reason": f"initialization_failed: {exc}",
            "initialization_runtime_seconds": float(meta.get("runtime_seconds", 0.0)),
            "ttff_seconds": meta.get("ttff_seconds"),
            "initialization_source": meta.get("source", "failed"),
            "initialization_repair_count": int(meta.get("repair_count", 0)),
            "initialization_pilot_move_evaluation_count": int(meta.get("pilot_move_evaluation_count", 0)),
            "initialization_validation_attempt_count": int(meta.get("validation_attempt_count", 0)),
            "initialization_validation_samples_used": int(meta.get("validation_samples_used", 0)),
            "initialization_failure_reason": meta.get("failure_reason", str(exc)),
            "initialization_safe_anchor_used": bool(meta.get("safe_anchor_used", False)),
        }
    return int(task["run_index"]), row


def _make_run_task(args, *, run_index: int, seed: int, tmax: float, output_dir: Path, ref):
    return {
        "run_index": int(run_index),
        "seed": int(seed),
        "tmax": float(tmax),
        "p0": float(args.p0),
        "lambda_value": float(args.lambda_value),
        "max_iter": int(args.max_iter),
        "no_improve_limit": int(args.no_improve_limit),
        "tabu_tenure": int(args.tabu_tenure),
        "mc_samples": int(args.mc_samples),
        "time_limit": float(args.time_limit),
        "eval_budget": args.eval_budget,
        "output_dir": str(output_dir),
        "gurobi_optimum": ref,
        "init_time_limit": float(args.init_time_limit),
        "init_pilot_samples": int(args.init_pilot_samples),
        "init_validation_samples": int(args.init_validation_samples),
        "init_safe_reserve": float(args.init_safe_reserve),
        "grasp_rcl_size": int(args.grasp_rcl_size),
        "restart_no_improve_cycles": int(args.restart_no_improve_cycles),
        "ms_max_starts": int(args.ms_max_starts),
        "lr_guidance_enabled": not bool(args.disable_lr_guidance),
        "lr_saa_samples": int(args.lr_saa_samples),
        "lr_guidance_time_limit": float(args.lr_guidance_time_limit),
        "lr_max_iterations": int(args.lr_max_iterations),
        "lr_step_theta": float(args.lr_step_theta),
        "lr_theta_decay": float(args.lr_theta_decay),
        "lr_theta_min": float(args.lr_theta_min),
        "lr_stagnation_limit": int(args.lr_stagnation_limit),
        "lr_saa_seed_offset": int(args.lr_saa_seed_offset),
        "pr_ablation": str(args.pr_ablation),
        "hit_targets": [float(v) for v in (args.hit_targets or [])],
        "verbose_search": bool(args.verbose_search),
    }


def _print_run_summary(instance_name: str, tmax: float, r: int, seed: int, row: dict):
    print(
        f"DDTS {instance_name} Tmax={tmax:g} run={r} seed={seed}: "
        f"cost={row.get('cost')} p={row.get('probability')} "
        f"feasible={row.get('certified_feasible')} "
        f"iterations={row.get('completed_cycles')} class_scans={row.get('total_class_scans')} "
        f"moves={row.get('total_tabu_moves')} eval={row.get('evaluation_count')} "
        f"starts={row.get('multi_start_count')} restarts={row.get('restart_count')} "
        f"tbest={row.get('best_found_time_seconds')}",
        flush=True,
    )


def summarize(rows):
    feasible = [r for r in rows if r["certified_feasible"]]
    summary = {
        "runs": len(rows),
        "feasible_runs": len(feasible),
        "feasibility_rate": len(feasible) / len(rows) if rows else 0.0,
    }
    if feasible:
        costs = [float(r["cost"]) for r in feasible]
        best_cost = min(costs)
        best_tol = max(1e-9, abs(best_cost) * 1e-10)
        best_rows = [r for r in feasible if abs(float(r["cost"]) - best_cost) <= best_tol]
        best_times = [
            float(r["best_found_time_seconds"])
            for r in best_rows
            if r.get("best_found_time_seconds") is not None
        ]
        runtimes = [float(r["total_runtime_seconds"]) for r in feasible]
        evals = [float(r["evaluation_count"]) for r in feasible]
        moves = [float(r.get("total_tabu_moves", 0)) for r in feasible]
        class_scans = [float(r.get("total_class_scans", 0)) for r in feasible]
        cycles = [float(r.get("completed_cycles", 0)) for r in feasible]
        perturbations = [float(r.get("perturbation_count", 0)) for r in feasible]
        qc_skips = [float(r.get("amc_quickcheck_prefilter_skip_count", 0)) for r in feasible]
        delta_evals = [float(r.get("delta_mc_evaluation_count", 0)) for r in feasible]
        delta_early = [float(r.get("delta_mc_early_reject_count", 0)) for r in feasible]
        delta_full = [float(r.get("delta_mc_full_evaluation_count", 0)) for r in feasible]
        delta_samples = [float(r.get("delta_mc_samples_used", 0)) for r in feasible]
        ttff = [float(r["ttff_seconds"]) for r in feasible if r.get("ttff_seconds") is not None]
        init_repairs = [float(r.get("initialization_repair_count", 0)) for r in feasible]
        init_runtimes = [float(r.get("initialization_runtime_seconds", 0.0)) for r in feasible]
        starts = [float(r.get("multi_start_count", 1)) for r in feasible]
        restarts = [float(r.get("restart_count", 0)) for r in feasible]
        lr_orig_restarts = [float(r.get("lr_original_restart_count", 0)) for r in feasible]
        lr_guided_restarts = [float(r.get("lr_guided_restart_count", 0)) for r in feasible]
        lr_orig_improve_count = [float(r.get("lr_original_improvement_count", 0)) for r in feasible]
        lr_guided_improve_count = [float(r.get("lr_guided_improvement_count", 0)) for r in feasible]
        lr_orig_total_improve = [float(r.get("lr_original_total_improvement", 0.0)) for r in feasible]
        lr_guided_total_improve = [float(r.get("lr_guided_total_improvement", 0.0)) for r in feasible]
        pr_calls = [float(r.get("pr_invocation_count", 0)) for r in feasible]
        pr_new_best = [float(r.get("pr_new_best_count", 0)) for r in feasible]
        pr_bridge_attempts = [float(r.get("pr_bridge_attempt_count", 0)) for r in feasible]
        pr_bridge_success = [float(r.get("pr_bridge_success_count", 0)) for r in feasible]
        pr_path_length = [float(r.get("pr_total_path_length", 0)) for r in feasible]
        pr_runtime = [float(r.get("pr_runtime_seconds", 0.0)) for r in feasible]
        pr_eval = [float(r.get("pr_evaluation_count", 0)) for r in feasible]
        pr_cont_improve = [float(r.get("pr_continuation_total_improvement", 0.0)) for r in feasible]
        elite_final = [float(r.get("elite_final_size", 0)) for r in feasible]
        hamming = [float(r["initial_hamming_mean"]) for r in feasible if r.get("initial_hamming_mean") is not None]
        gaps = [r["heuristic_gap_percent"] for r in feasible if r["heuristic_gap_percent"] is not None]
        avg_tbest = mean(best_times) if best_times else None
        summary.update(
            {
                "best": best_cost,
                "average": mean(costs),
                "std": pstdev(costs) if len(costs) > 1 else 0.0,
                # ``time`` is the paper-facing statistic requested by the user:
                # average global wall-clock time among runs that reach the
                # overall best objective value for this instance/Tmax.
                "time": avg_tbest,
                "best_reached_runs": len(best_rows),
                "average_time_to_best_seconds": avg_tbest,
                "std_time_to_best_seconds": pstdev(best_times) if len(best_times) > 1 else (0.0 if best_times else None),
                "min_time_to_best_seconds": min(best_times) if best_times else None,
                "average_runtime_seconds": mean(runtimes),
                "average_evaluation_count": mean(evals),
                "average_tabu_moves": mean(moves),
                "average_class_scans": mean(class_scans),
                "average_completed_cycles": mean(cycles),
                "average_perturbations": mean(perturbations),
                "average_multi_start_count": mean(starts),
                "average_restart_count": mean(restarts),
                "average_lr_original_restart_count": mean(lr_orig_restarts),
                "average_lr_guided_restart_count": mean(lr_guided_restarts),
                "average_lr_original_improvement_count": mean(lr_orig_improve_count),
                "average_lr_guided_improvement_count": mean(lr_guided_improve_count),
                "average_lr_original_total_improvement": mean(lr_orig_total_improve),
                "average_lr_guided_total_improvement": mean(lr_guided_total_improve),
                "average_pr_invocation_count": mean(pr_calls),
                "average_pr_new_best_count": mean(pr_new_best),
                "average_pr_bridge_attempt_count": mean(pr_bridge_attempts),
                "average_pr_bridge_success_count": mean(pr_bridge_success),
                "average_pr_total_path_length": mean(pr_path_length),
                "average_pr_runtime_seconds": mean(pr_runtime),
                "average_pr_evaluation_count": mean(pr_eval),
                "average_pr_continuation_total_improvement": mean(pr_cont_improve),
                "average_elite_final_size": mean(elite_final),
                "average_initial_hamming_mean": mean(hamming) if hamming else None,
                "average_amc_quickcheck_prefilter_skip_count": mean(qc_skips),
                "average_delta_mc_evaluation_count": mean(delta_evals),
                "average_delta_mc_early_reject_count": mean(delta_early),
                "average_delta_mc_full_evaluation_count": mean(delta_full),
                "average_delta_mc_samples_used": mean(delta_samples),
                "average_ttff_seconds": mean(ttff) if ttff else None,
                "average_initialization_repair_count": mean(init_repairs),
                "average_initialization_runtime_seconds": mean(init_runtimes),
                "best_gap_percent": min(gaps) if gaps else None,
                "average_gap_percent": mean(gaps) if gaps else None,
            }
        )
    else:
        summary.update(
            {
                "best": None,
                "average": None,
                "std": None,
                "time": None,
                "best_reached_runs": 0,
                "average_time_to_best_seconds": None,
                "std_time_to_best_seconds": None,
                "min_time_to_best_seconds": None,
                "average_runtime_seconds": None,
                "average_evaluation_count": None,
                "average_tabu_moves": None,
                "average_class_scans": None,
                "average_completed_cycles": None,
                "average_perturbations": None,
                "average_multi_start_count": None,
                "average_restart_count": None,
                "average_lr_original_restart_count": None,
                "average_lr_guided_restart_count": None,
                "average_lr_original_improvement_count": None,
                "average_lr_guided_improvement_count": None,
                "average_lr_original_total_improvement": None,
                "average_lr_guided_total_improvement": None,
                "average_pr_invocation_count": None,
                "average_pr_new_best_count": None,
                "average_pr_bridge_attempt_count": None,
                "average_pr_bridge_success_count": None,
                "average_pr_total_path_length": None,
                "average_pr_runtime_seconds": None,
                "average_pr_evaluation_count": None,
                "average_pr_continuation_total_improvement": None,
                "average_elite_final_size": None,
                "average_initial_hamming_mean": None,
                "average_amc_quickcheck_prefilter_skip_count": None,
                "average_delta_mc_evaluation_count": None,
                "average_delta_mc_early_reject_count": None,
                "average_delta_mc_full_evaluation_count": None,
                "average_delta_mc_samples_used": None,
                "average_ttff_seconds": None,
                "average_initialization_repair_count": None,
                "average_initialization_runtime_seconds": None,
                "best_gap_percent": None,
                "average_gap_percent": None,
            }
        )
    return summary


def main():
    parser = argparse.ArgumentParser(description="Run 10.3 LR-OperationTabu + quality-diversity elite path relinking for CCMCKP")
    parser.add_argument("--instance", required=True, help="e.g. APP_3_5_30_ or benchmark/APP_3_5_30_")
    parser.add_argument("--tmax", type=float, nargs="+", required=True)
    parser.add_argument("--p0", type=float, default=0.99)
    parser.add_argument("--lambda-value", type=float, default=5.0)
    parser.add_argument(
        "--max-iter",
        type=int,
        default=30,
        help="legacy compatibility option; ignored because the stopping rule is --time-limit",
    )
    parser.add_argument(
        "--no-improve-limit",
        type=int,
        default=20,
        help="legacy compatibility option; unused in LSS-style classwise mode",
    )
    parser.add_argument("--tabu-tenure", type=int, default=1)
    parser.add_argument("--mc-samples", type=int, default=1_000_000)
    parser.add_argument("--runs", type=int, default=1)
    parser.add_argument(
        "--run-workers",
        type=int,
        default=1,
        help=(
            "number of repeated runs to execute concurrently for each Tmax; "
            "1 keeps serial behavior, 30 runs all 30 repeats concurrently (Linux/POSIX fork)"
        ),
    )
    parser.add_argument("--seed", type=int, default=832273, help="base seed; run r uses seed+r")
    parser.add_argument("--time-limit", type=float, default=600.0, help="fixed global wall-clock budget per run; only 600 is accepted")
    parser.add_argument("--quick-check-timeout", type=float, default=1.0, help="max seconds for a QuickCheck cache miss; timeout skips QuickCheck")
    parser.add_argument("--init-time-limit", type=float, default=5.0, help="compatibility option; 10.3 does not allocate a fixed initialization stage time")
    parser.add_argument("--init-pilot-samples", type=int, default=10_000, help="pilot Delta-MC samples for violation-driven repair")
    parser.add_argument("--init-validation-samples", type=int, default=100_000, help="higher-precision independent MC samples used to confirm an initial solution")
    parser.add_argument("--init-safe-reserve", type=float, default=1.0, help="compatibility option; 10.3 does not reserve a fixed initialization stage time")
    parser.add_argument("--grasp-rcl-size", type=int, default=3, help="top-k utility RCL size for randomized restart starts; first start remains deterministic 9.8.1")
    parser.add_argument("--restart-no-improve-cycles", type=int, default=5, help="restart after this many complete cycles without improving the current start best")
    parser.add_argument("--ms-max-starts", type=int, default=0, help="legacy compatibility option; must be 0 because starts are limited only by the 600s global budget")
    parser.add_argument("--disable-lr-guidance", action="store_true", help="disable Lagrangian guidance and recover original 9.14 restart behavior")
    parser.add_argument("--lr-saa-samples", type=int, default=5000, help="fixed SAA sample count used only to learn restart guidance")
    parser.add_argument("--lr-guidance-time-limit", type=float, default=10.0, help="compatibility option; 10.3 does not allocate a fixed LR stage time")
    parser.add_argument("--lr-max-iterations", type=int, default=2000, help="maximum Lagrangian guidance iterations")
    parser.add_argument("--lr-step-theta", type=float, default=1.5)
    parser.add_argument("--lr-theta-decay", type=float, default=0.5)
    parser.add_argument("--lr-theta-min", type=float, default=0.05)
    parser.add_argument("--lr-stagnation-limit", type=int, default=50)
    parser.add_argument("--lr-saa-seed-offset", type=int, default=104729)
    parser.add_argument("--pr-ablation", choices=["baseline", "elite-pr", "lr-pr", "lr-risk-pr"], default="lr-risk-pr",
                        help="ablation: baseline LR-OperationTabu; +elite ordinary PR; +LR-guided PR; +LR/risk bridge PR")
    parser.add_argument("--hit-targets", type=float, nargs="*", default=None,
                        help="optional reporting-only objective thresholds; does not affect search")
    parser.add_argument("--verbose-search", action="store_true",
                        help="emit per-cycle/class DDTS traces to stdout; default keeps formal batch logs compact")
    parser.add_argument("--version", action="version", version="LR-OperationTabu-QD-Elite-PR 10.3")
    parser.add_argument("--eval-budget", type=int, default=None, help="legacy compatibility option; disabled because evaluation count must not terminate a run")
    parser.add_argument("--gurobi-optimum", type=float, default=None, help="override exact reference; intended for one Tmax")
    parser.add_argument("--output-dir", default="result/LR_OP_QD_ELITE_PR_10_3_lr-risk-pr")
    parser.add_argument("--search-ablation-policy", default=None, help="JSON search controls; no probability/evaluation parameter overrides")
    args = parser.parse_args()
    if args.search_ablation_policy:
        os.environ["CCMCKP_SEARCH_ABLATION_POLICY"] = str(Path(args.search_ablation_policy).resolve())
        policy = get_policy()
        args.pr_ablation = policy["pr_mode"]
        args.disable_lr_guidance = not policy["lr_guidance"]
    if abs(float(args.time_limit) - GLOBAL_RUN_TIME_LIMIT_SECONDS) > 1e-12:
        raise ValueError("10.3 uses the unified 600-second global run budget; --time-limit must be 600")
    if int(args.ms_max_starts) != 0:
        raise ValueError("--ms-max-starts is disabled in 10.3; use 0 so the unified run budget/search-state rules control the run")
    if args.eval_budget is not None:
        raise ValueError("--eval-budget is disabled in 10.3; evaluation count cannot terminate a run")
    if args.lr_saa_samples <= 0:
        raise ValueError("--lr-saa-samples must be positive")
    if args.lr_guidance_time_limit < 0:
        raise ValueError("--lr-guidance-time-limit must be nonnegative")
    if args.lr_max_iterations <= 0:
        raise ValueError("--lr-max-iterations must be positive")
    if not (0.0 < args.lr_step_theta <= 2.0):
        raise ValueError("--lr-step-theta should lie in (0, 2]")
    if not (0.0 < args.lr_theta_decay <= 1.0):
        raise ValueError("--lr-theta-decay must lie in (0, 1]")
    if args.lr_theta_min <= 0:
        raise ValueError("--lr-theta-min must be positive")

    instance_dir = resolve_instance_dir(args.instance)
    output_dir = Path(args.output_dir)
    if not output_dir.is_absolute():
        output_dir = REPO_ROOT / output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    # IMPORTANT: instance-level preprocessing is intentionally outside both
    # the Tmax loop and the repeated-run loop.  It therefore happens once per
    # process invocation and is reused by every run.  External parallel jobs
    # are not disabled or converted to serial execution.
    prepared = prepare_instance_resources(
        instance_dir,
        float(args.p0),
        float(args.lambda_value),
        quick_check_timeout_seconds=float(args.quick_check_timeout),
    )

    overall = []
    for tmax in args.tmax:
        ref = args.gurobi_optimum
        if ref is None:
            ref = known_gurobi(instance_dir.name, float(tmax), float(args.p0))

        rows = []
        run_workers = max(1, min(int(args.run_workers), int(args.runs)))

        # Make parent-prepared resources available to the serial helper and,
        # when forked, to all child run workers via copy-on-write inheritance.
        global _RUN_POOL_PREPARED
        _RUN_POOL_PREPARED = prepared

        if run_workers == 1:
            for r in range(args.runs):
                seed = args.seed + r
                _, row = _parallel_run_task(
                    _make_run_task(
                        args,
                        run_index=r,
                        seed=seed,
                        tmax=float(tmax),
                        output_dir=output_dir,
                        ref=ref,
                    )
                )
                rows.append(row)
                _print_run_summary(instance_dir.name, float(tmax), r, seed, row)
        else:
            # The parent prepares QuickCheck + Statistic_factor exactly once.
            # Linux forked children inherit these read-mostly objects via
            # copy-on-write, avoiding 30 independent Statistic_factor reads.
            if "fork" not in mp.get_all_start_methods():
                raise RuntimeError(
                    "--run-workers > 1 currently requires Linux/POSIX 'fork'. "
                    "Use --run-workers 1 on platforms without fork."
                )

            stage_log(
                "ParallelRuns",
                f"{instance_dir.name} Tmax={float(tmax):g}: start "
                f"runs={args.runs} workers={run_workers}",
            )
            t_batch = time.perf_counter()
            indexed_rows = {}
            ctx = mp.get_context("fork")
            with ProcessPoolExecutor(max_workers=run_workers, mp_context=ctx) as executor:
                future_map = {}
                for r in range(args.runs):
                    seed = args.seed + r
                    task = _make_run_task(
                        args,
                        run_index=r,
                        seed=seed,
                        tmax=float(tmax),
                        output_dir=output_dir,
                        ref=ref,
                    )
                    future = executor.submit(_parallel_run_task, task)
                    future_map[future] = (r, seed)

                for future in as_completed(future_map):
                    r, seed = future_map[future]
                    try:
                        run_index, row = future.result()
                    except Exception as exc:
                        stage_log(
                            "ParallelRuns",
                            f"FAILED instance={instance_dir.name} Tmax={float(tmax):g} "
                            f"P0={float(args.p0):g} run_index={r} seed={seed} "
                            f"pr_ablation={args.pr_ablation}: {type(exc).__name__}: {exc}",
                        )
                        raise
                    indexed_rows[run_index] = row
                    _print_run_summary(instance_dir.name, float(tmax), r, seed, row)

            rows = [indexed_rows[r] for r in range(args.runs)]
            stage_log(
                "ParallelRuns",
                f"{instance_dir.name} Tmax={float(tmax):g}: done "
                f"runs={args.runs} workers={run_workers} "
                f"wall={time.perf_counter() - t_batch:.3f}s",
            )

        summary = summarize(rows)
        for target in (args.hit_targets or []):
            key = ("hit_le_" + ("%.12g" % float(target)).replace("-", "m").replace(".", "p"))
            summary[key + "_count"] = sum(
                1 for r in rows if r.get("certified_feasible") and r.get("cost") is not None
                and float(r["cost"]) <= float(target) + 1e-12
            )
            summary[key + "_rate"] = summary[key + "_count"] / len(rows) if rows else 0.0
        summary.update(
            {
                "algorithm": ALGORITHM_NAME,
                "instance": instance_dir.name,
                "Tmax": float(tmax),
                "P0": float(args.p0),
                "gurobi_optimum": ref,
                "tabu_tenure": int(args.tabu_tenure),
                "no_improve_limit": int(args.no_improve_limit),
                "no_improve_limit_used": False,
                "max_iter": int(args.max_iter),
                "max_iter_used": False,
                "max_iter_semantics": "legacy_compatibility_only_global_time_and_restart_rule_used",
                "time_limit_seconds": float(args.time_limit),
                "search_mode": "lr_operation_tabu_quality_diversity_elite_path_relinking",
                "code_version": CODE_VERSION,
                "lr_guidance_enabled": not bool(args.disable_lr_guidance),
                "lr_saa_samples": int(args.lr_saa_samples),
                "lr_guidance_time_limit_seconds": float(args.lr_guidance_time_limit),
                "lr_guidance_fixed_stage_time_used": False,
                "lr_max_iterations": int(args.lr_max_iterations),
                "lr_restart_mix": "deterministic_alternating_50_50",
                "grasp_rcl_size": int(args.grasp_rcl_size),
                "restart_no_improve_cycles": int(args.restart_no_improve_cycles),
                "ms_max_starts": int(args.ms_max_starts),
                "empirical_dominance_removed_item_count": int(prepared.dominance_stats["removed_item_count"]),
                "empirical_dominance_retained_item_count": int(prepared.dominance_stats["retained_item_count"]),
                "run_workers": int(max(1, min(int(args.run_workers), int(args.runs)))),
                "quick_check_timeout_seconds": float(args.quick_check_timeout),
                "quick_check_timed_out": bool(prepared.quick_check_metadata.get("timed_out", False)),
                "quick_check_skipped": bool(prepared.quick_check_metadata.get("skipped", False)),
                "init_time_limit_seconds": float(args.init_time_limit),
                "initialization_fixed_stage_time_used": False,
                "init_pilot_samples": int(args.init_pilot_samples),
                "init_validation_samples": int(args.init_validation_samples),
            }
        )
        overall.append(summary)

        stem = f"summary_{instance_dir.name}_T{tmax:g}_p{args.p0:g}"
        with (output_dir / f"{stem}.json").open("w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)

    fields = [
        "algorithm", "code_version", "instance", "Tmax", "P0",
        "runs", "run_workers", "feasible_runs", "feasibility_rate",
        "best", "average", "std", "time", "best_reached_runs",
        "average_time_to_best_seconds", "std_time_to_best_seconds",
        "min_time_to_best_seconds", "best_gap_percent", "average_gap_percent",
        "average_runtime_seconds", "average_evaluation_count",
        "average_tabu_moves", "average_class_scans", "average_completed_cycles",
        "average_perturbations", "average_multi_start_count",
        "average_restart_count", "average_lr_original_restart_count",
        "average_lr_guided_restart_count", "average_lr_original_improvement_count",
        "average_lr_guided_improvement_count", "average_lr_original_total_improvement",
        "average_lr_guided_total_improvement", "average_pr_invocation_count",
        "average_pr_new_best_count", "average_pr_bridge_attempt_count",
        "average_pr_bridge_success_count", "average_pr_total_path_length",
        "average_pr_runtime_seconds", "average_pr_evaluation_count",
        "average_pr_continuation_total_improvement", "average_elite_final_size",
        "average_initial_hamming_mean",
        "average_amc_quickcheck_prefilter_skip_count",
        "average_delta_mc_evaluation_count", "average_delta_mc_early_reject_count",
        "average_delta_mc_full_evaluation_count", "average_delta_mc_samples_used",
        "average_ttff_seconds", "average_initialization_repair_count",
        "average_initialization_runtime_seconds", "gurobi_optimum",
        "tabu_tenure", "no_improve_limit", "no_improve_limit_used",
        "max_iter", "max_iter_used", "max_iter_semantics",
        "time_limit_seconds", "grasp_rcl_size", "restart_no_improve_cycles",
        "ms_max_starts", "quick_check_timeout_seconds", "quick_check_timed_out",
        "quick_check_skipped", "init_time_limit_seconds", "init_pilot_samples",
        "init_validation_samples", "empirical_dominance_removed_item_count",
        "empirical_dominance_retained_item_count", "search_mode",
        "lr_guidance_enabled", "lr_saa_samples", "lr_guidance_time_limit_seconds",
        "lr_max_iterations", "lr_restart_mix", "pr_ablation",
        "lr_guidance_fixed_stage_time_used", "initialization_fixed_stage_time_used",
    ]
    # Reporting-only hit-target columns are added dynamically when requested.
    for target in (args.hit_targets or []):
        key = ("hit_le_" + ("%.12g" % float(target)).replace("-", "m").replace(".", "p"))
        fields.extend([key + "_count", key + "_rate"])
    write_csv(output_dir / "ddts_summary.csv", fields, overall)


if __name__ == "__main__":
    main()
