"""Corrected Factor class for DDALS_fixed and DDTS.

This module intentionally leaves the author's original ``src/utils/factor.py``
unchanged.  The only behavioral correction here is that Monte Carlo resampling
can draw every stored sample, including the last one.
"""

import numpy as np

max_K = 10


class Factor:
    def __init__(self, factor_id, cost, value, sample_filepath, big_sample_filepath=None):
        self.id = factor_id
        self.cost = cost
        self.value = value
        self.sample_filepath = sample_filepath
        self.samples = np.loadtxt(sample_filepath)
        self.big_sample_filepath = big_sample_filepath

        self._sample_min = None
        self._sample_max = None
        self._sample_mean = None
        self._sample_var = None
        self._sample_std = None
        self._big_samples = None
        self._moments_min = None
        self._moments_origin = None

        self.weight = None
        self.utility = None
        self.increment = None
        self._sorted_desc = None

    def resample_once(self):
        return self.resample_multi(1)

    def resample_multi(self, sample_number):
        # Bug fix: numpy randint excludes the upper bound.  Therefore the upper
        # bound must be len(samples), not len(samples)-1, otherwise the last
        # historical sample is never drawn.
        _idx = np.random.randint(0, len(self.samples), int(sample_number))
        return self.samples[_idx]

    def resample_big_multi(self, sample_number):
        data = self.big_samples
        _idx = np.random.randint(0, len(data), int(sample_number))
        return data[_idx]

    @property
    def sample_min(self):
        if self._sample_min is None:
            self._sample_min = np.min(self.samples)
        return self._sample_min

    @property
    def sample_max(self):
        if self._sample_max is None:
            self._sample_max = np.max(self.samples)
        return self._sample_max

    @property
    def sample_mean(self):
        if self._sample_mean is None:
            self._sample_mean = np.mean(self.samples)
        return self._sample_mean

    @property
    def sample_var(self):
        if self._sample_var is None:
            self._sample_var = np.var(self.samples)
        return self._sample_var

    @property
    def sample_std(self):
        if self._sample_std is None:
            self._sample_std = np.std(self.samples, ddof=1)
        return self._sample_std

    @property
    def big_samples(self):
        if self._big_samples is None:
            if self.big_sample_filepath is None:
                raise ValueError("big_sample_filepath is not configured")
            self._big_samples = np.loadtxt(self.big_sample_filepath)
        return self._big_samples

    def n_moment_min(self, K):
        sample_size = len(self.samples)
        _aux_matrix = np.ones((2, sample_size))
        moments_list = np.ones(K + 1)
        for k in range(1, K + 1):
            _cur_idx = k % 2
            _prev_idx = 1 - _cur_idx
            _aux_matrix[_cur_idx] = (self.samples - self.sample_min) * _aux_matrix[_prev_idx]
            moments_list[k] = np.mean(_aux_matrix[_cur_idx])
        return moments_list

    def n_moment_of_origin(self, K):
        sample_size = len(self.samples)
        _aux_matrix = np.ones((2, sample_size))
        moments_list = np.ones(K + 1)
        for k in range(1, K + 1):
            _cur_idx = k % 2
            _prev_idx = 1 - _cur_idx
            _aux_matrix[_cur_idx] = self.samples * _aux_matrix[_prev_idx]
            moments_list[k] = np.mean(_aux_matrix[_cur_idx])
        return moments_list

    @property
    def moments_min(self):
        if self._moments_min is None:
            self._moments_min = self.n_moment_min(max_K)
        return self._moments_min

    @property
    def moments_origin(self):
        if self._moments_origin is None:
            self._moments_origin = self.n_moment_of_origin(max_K)
        return self._moments_origin

    def set_weight(self, weight):
        self.weight = weight

    def set_utility(self, utility):
        self.utility = utility

    def set_increment(self, increment):
        self.increment = increment

    def get_index_sample(self, _l):
        if self._sorted_desc is None:
            self._sorted_desc = np.sort(self.samples)[::-1]
        return self._sorted_desc[int(_l)]
