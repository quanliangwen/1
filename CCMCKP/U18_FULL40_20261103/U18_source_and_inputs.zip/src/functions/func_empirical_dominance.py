"""Empirical stochastic-dominance preprocessing for CCMCKP.

For two items a and b in the same class, a empirically dominates b when

    cost(a) <= cost(b)

and their equally weighted empirical distributions satisfy first-order
stochastic dominance.  With the same sample count L, this is equivalent to
componentwise dominance of the ascending empirical quantiles:

    sort(samples_a)[r] <= sort(samples_b)[r] for every r.

At least one inequality must be strict.  Exact duplicates are tie-broken by
factor id so that one representative is retained.

Under the empirical independent-distribution model used by the benchmark,
replacing b by a cannot increase cost and cannot decrease the probability that
the total random weight is <= Tmax.  Hence dominated items can be removed from
all within-class candidate lists before CP and DDTS are run.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np


@dataclass
class EmpiricalDominanceStats:
    original_item_count: int
    retained_item_count: int
    removed_item_count: int
    removed_by_class: Dict[int, List[int]]
    retained_by_class: Dict[int, List[int]]

    def to_dict(self):
        return asdict(self)


def _empirically_dominates(a, b, sorted_samples, tol: float) -> bool:
    """Return True if factor a empirically dominates factor b."""
    if float(a.cost) > float(b.cost) + tol:
        return False

    qa = sorted_samples[int(a.id)]
    qb = sorted_samples[int(b.id)]
    if qa.shape != qb.shape:
        raise ValueError("Empirical dominance requires equal sample counts within a class")
    if not np.all(qa <= qb + tol):
        return False

    strict_cost = float(a.cost) < float(b.cost) - tol
    strict_samples = bool(np.any(qa < qb - tol))
    if strict_cost or strict_samples:
        return True

    # Exact duplicate in both cost and empirical distribution: keep the lower id.
    return int(a.id) < int(b.id)


def empirical_stochastic_dominance_preprocess(
    node_resort_weight: Dict[int, Sequence[int]],
    node_resort_utility: Dict[int, Sequence[int]],
    node_resort_value: Dict[int, Sequence[int]],
    factor_id2obj: Sequence,
    tol: float = 1e-12,
):
    """Remove empirically dominated items and preserve each list's order.

    Returns
    -------
    filtered_weight, filtered_utility, filtered_value, stats
    """
    class_ids = sorted(int(k) for k in node_resort_value.keys())
    sorted_samples = {}
    removed_by_class: Dict[int, List[int]] = {}
    retained_by_class: Dict[int, List[int]] = {}

    for class_id in class_ids:
        ids = [int(fid) for fid in node_resort_value[class_id]]
        for fid in ids:
            if fid not in sorted_samples:
                sorted_samples[fid] = np.sort(np.asarray(factor_id2obj[fid].samples, dtype=float))

        dominated = set()
        for b_id in ids:
            b = factor_id2obj[b_id]
            for a_id in ids:
                if a_id == b_id:
                    continue
                a = factor_id2obj[a_id]
                if _empirically_dominates(a, b, sorted_samples, tol):
                    dominated.add(b_id)
                    break

        retained = [fid for fid in ids if fid not in dominated]
        if not retained:
            # Defensive fallback; the strict/tie-break rule should make this impossible.
            retained = [min(ids)]
            dominated = set(ids) - set(retained)

        removed_by_class[class_id] = sorted(int(v) for v in dominated)
        retained_by_class[class_id] = list(retained)

    survivor_sets = {cid: set(retained_by_class[cid]) for cid in class_ids}

    def filtered(source):
        return {
            cid: [int(fid) for fid in source[cid] if int(fid) in survivor_sets[cid]]
            for cid in class_ids
        }

    fw = filtered(node_resort_weight)
    fu = filtered(node_resort_utility)
    fv = filtered(node_resort_value)

    original_count = sum(len(node_resort_value[cid]) for cid in class_ids)
    retained_count = sum(len(fv[cid]) for cid in class_ids)
    stats = EmpiricalDominanceStats(
        original_item_count=int(original_count),
        retained_item_count=int(retained_count),
        removed_item_count=int(original_count - retained_count),
        removed_by_class=removed_by_class,
        retained_by_class=retained_by_class,
    )
    return fw, fu, fv, stats
