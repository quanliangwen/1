"""Search-only ablation controls. No evaluation or sampling changes."""
import json
import os

DEFAULT_POLICY = {
    'mc_pair_exchange': True,
    'mc_deferred_singles': True,
    'reactive_scope': 'exact_only',
    'mc_perturbation_order': 'nearby',
    'mc_pilot_priority': True,
    'pr_mode': 'lr-risk-pr',
    'lr_guidance': True,
}

def get_policy():
    policy = dict(DEFAULT_POLICY)
    filename = os.environ.get('CCMCKP_SEARCH_ABLATION_POLICY')
    if filename:
        with open(filename, encoding='utf-8') as stream:
            supplied = json.load(stream)
        unknown = set(supplied) - set(policy)
        if unknown:
            raise ValueError('Unknown ablation controls: ' + str(sorted(unknown)))
        policy.update(supplied)
    for key in ['mc_pair_exchange', 'mc_deferred_singles', 'mc_pilot_priority', 'lr_guidance']:
        if type(policy[key]) is not bool:
            raise ValueError(key + ' must be boolean')
    if policy['reactive_scope'] not in ['exact_only', 'all']:
        raise ValueError('reactive_scope must be exact_only or all')
    if policy['mc_perturbation_order'] not in ['nearby', 'random']:
        raise ValueError('Unknown perturbation ordering')
    if policy['pr_mode'] not in ['baseline', 'elite-pr', 'lr-pr', 'lr-risk-pr']:
        raise ValueError('Unknown path relinking configuration')
    return policy

class ReactiveCycleMemory:
    """Same outer-cycle adaptation as 1005's exact-evaluator branch.

    Reaction changes search memory only. It consumes no RNG draws.
    """
    def __init__(self, solution, base_tenure, enabled):
        self.base = int(base_tenure)
        self.tenure = self.base
        self.maximum_tenure = self.base
        self.enabled = bool(enabled)
        self.seen = {tuple(int(v) for v in solution): 0}
        self.cycle_free = 0
        self.repeats = 0
        self.updates = 0

    def observe(self, solution, cycle):
        config = tuple(int(v) for v in solution)
        previous = self.seen.get(config)
        before = self.tenure
        if previous is not None:
            self.repeats += 1
            if self.enabled:
                length = max(1, int(cycle) - int(previous))
                self.tenure = max(self.base, self.tenure, length + 1)
                self.cycle_free = 0
        elif self.enabled:
            self.cycle_free += 1
            if self.cycle_free >= self.tenure:
                self.tenure = max(self.base, self.tenure - 1)
                self.cycle_free = 0
        self.seen[config] = int(cycle)
        self.maximum_tenure = max(self.maximum_tenure, self.tenure)
        self.updates += int(before != self.tenure)
        return self.tenure
