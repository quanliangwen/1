"""Quality-diversity elite memory and LR/risk-guided path relinking for CCMCKP.

The module is deliberately auxiliary: it never changes the CCMCKP objective,
chance-constraint threshold, or final acceptance rule.  Lagrangian information
orders moves only.  Every committed path state is certified by the same exact or
fixed-M evaluator used by DDTS.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
import math
import time
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from src.functions.func_solution_factor_corrected import Solution_Evaluation, solution_cost
from src.functions.func_delta_mc import DeltaMonteCarloContext


def hamming(a: Sequence[int], b: Sequence[int]) -> int:
    return sum(int(x) != int(y) for x, y in zip(a, b))


@dataclass
class EliteEntry:
    solution: Tuple[int, ...]
    cost: float
    probability: float
    source: str
    discovered_at: float


class QualityDiversityElitePool:
    """Run-local Pareto-style quality/diversity archive.

    Capacity is ceil(sqrt(m)).  Exact duplicate assignments are rejected.
    When over capacity, entries are non-dominated sorted by (cost low,
    nearest-neighbour Hamming distance high); fronts are filled in order and
    the final partial front is ordered by lower cost then larger diversity.
    No APP/LAB or scale-specific parameter is used.
    """

    def __init__(self, class_count: int):
        self.m = int(class_count)
        self.capacity = max(2, int(math.ceil(math.sqrt(max(1, self.m)))))
        self.entries: List[EliteEntry] = []
        self.observation_count = 0
        self.accept_count = 0
        self.duplicate_reject_count = 0

    @staticmethod
    def _diversities(entries: Sequence[EliteEntry]) -> List[int]:
        if len(entries) <= 1:
            return [10**9] * len(entries)
        out = []
        for i, e in enumerate(entries):
            out.append(min(hamming(e.solution, f.solution) for j, f in enumerate(entries) if i != j))
        return out

    @staticmethod
    def _fronts(entries: Sequence[EliteEntry], diversities: Sequence[int]) -> List[List[int]]:
        remaining = set(range(len(entries)))
        fronts: List[List[int]] = []
        tol = 1e-12
        while remaining:
            front = []
            for i in sorted(remaining):
                dominated = False
                for j in remaining:
                    if i == j:
                        continue
                    cost_better = entries[j].cost <= entries[i].cost + tol
                    div_better = diversities[j] >= diversities[i]
                    strict = entries[j].cost < entries[i].cost - tol or diversities[j] > diversities[i]
                    if cost_better and div_better and strict:
                        dominated = True
                        break
                if not dominated:
                    front.append(i)
            if not front:  # defensive fallback
                front = sorted(remaining)
            fronts.append(front)
            remaining.difference_update(front)
        return fronts

    def observe(self, solution: Sequence[int], cost: float, probability: float,
                source: str, discovered_at: float) -> dict:
        self.observation_count += 1
        sol = tuple(int(v) for v in solution)
        before = list(self.entries)
        if any(e.solution == sol for e in self.entries):
            self.duplicate_reject_count += 1
            return self.stats_row(action="duplicate_reject", candidate_cost=float(cost), source=source)

        candidate = EliteEntry(sol, float(cost), float(probability), str(source), float(discovered_at))
        work = self.entries + [candidate]
        div = self._diversities(work)
        fronts = self._fronts(work, div)
        selected: List[int] = []
        for front in fronts:
            ranked = sorted(front, key=lambda i: (work[i].cost, -div[i], work[i].solution))
            take = self.capacity - len(selected)
            if take <= 0:
                break
            selected.extend(ranked[:take])
            if len(selected) >= self.capacity:
                break
        self.entries = [work[i] for i in selected]
        accepted = any(e.solution == sol for e in self.entries)
        if accepted:
            self.accept_count += 1
        action = "accepted" if accepted else "quality_diversity_reject"
        return self.stats_row(action=action, candidate_cost=float(cost), source=source)

    def guiding_entry(self, initiating: Sequence[int]) -> Optional[EliteEntry]:
        init = tuple(int(v) for v in initiating)
        choices = [(hamming(init, e.solution), e.cost, e) for e in self.entries if e.solution != init]
        if not choices:
            return None
        # Pool is already quality-filtered; maximize structural distance and use
        # objective quality as the deterministic tie-breaker.
        choices.sort(key=lambda x: (-x[0], x[1], x[2].solution))
        return choices[0][2]

    def stats_row(self, *, action: str, candidate_cost: Optional[float] = None,
                  source: Optional[str] = None) -> dict:
        div = self._diversities(self.entries)
        finite_div = [d for d in div if d < 10**9]
        return {
            "action": str(action),
            "source": source,
            "candidate_cost": candidate_cost,
            "pool_size": len(self.entries),
            "capacity": self.capacity,
            "best_cost": min((e.cost for e in self.entries), default=None),
            "mean_cost": (sum(e.cost for e in self.entries) / len(self.entries)) if self.entries else None,
            "min_pairwise_hamming": min(finite_div) if finite_div else None,
            "mean_nearest_hamming": (sum(finite_div) / len(finite_div)) if finite_div else None,
            "observation_count": self.observation_count,
            "accept_count": self.accept_count,
            "duplicate_reject_count": self.duplicate_reject_count,
        }


@dataclass
class PathRelinkingResult:
    invoked: bool
    completed: bool
    stop_reason: str
    initiating_solution: List[int]
    guiding_solution: Optional[List[int]]
    guiding_distance: int
    path_length: int
    accepted_single_moves: int
    bridge_attempts: int
    bridge_successes: int
    lr_first_choice_hits: int
    lr_ranked_moves_considered: int
    evaluation_count: int
    delta_mc_samples_used: int
    runtime_seconds: float
    best_intermediate_solution: Optional[List[int]]
    best_intermediate_cost: Optional[float]
    best_intermediate_probability: Optional[float]
    final_solution: List[int]
    final_cost: float
    final_probability: float
    step_rows: List[dict]

    def to_dict(self):
        return asdict(self)


def _lr_positions(rankings_by_class: Optional[Dict[int, Sequence[int]]], class_id: int):
    if not rankings_by_class or int(class_id) not in rankings_by_class:
        return {}
    return {int(fid): pos for pos, fid in enumerate(rankings_by_class[int(class_id)])}


def _move_features(current: Sequence[int], guide: Sequence[int], cid: int, factors,
                   rankings_by_class=None):
    old = int(current[cid]); new = int(guide[cid])
    old_obj, new_obj = factors[old], factors[new]
    pos = _lr_positions(rankings_by_class, cid)
    old_rank = int(pos.get(old, 10**9)); new_rank = int(pos.get(new, 10**9))
    return {
        "class_id": int(cid), "old_factor": old, "new_factor": new,
        "delta_cost": float(new_obj.cost - old_obj.cost),
        "delta_mean_risk": float(new_obj.sample_mean - old_obj.sample_mean),
        "delta_max_risk": float(new_obj.sample_max - old_obj.sample_max),
        "old_lr_rank": old_rank, "new_lr_rank": new_rank,
        "lr_rank_delta": int(new_rank - old_rank) if old_rank < 10**9 and new_rank < 10**9 else 10**9,
    }


def _order_features(features: List[dict], lr_guided: bool):
    if lr_guided:
        # No weighted surrogate: multipliers are represented by their induced LR
        # ranking.  Objective and risk are deterministic tie-breakers only.
        return sorted(features, key=lambda r: (
            r["new_lr_rank"], r["lr_rank_delta"], r["delta_cost"],
            r["delta_mean_risk"], r["class_id"],
        ))
    return sorted(features, key=lambda r: (
        r["delta_cost"], r["delta_mean_risk"], r["class_id"],
    ))


def path_relink(
    EvaluationFunction,
    initiating_solution: Sequence[int], initiating_cost: float, initiating_probability: float,
    guiding_solution: Sequence[int], node_items: Dict[int, Sequence[int]], factor_id2obj: Sequence,
    ConfidenceLevel: float, T_max: float, param, MonteCarloTimes: int, QuickCheckList,
    *, run_seed: int, deadline_monotonic: float,
    rankings_by_class: Optional[Dict[int, Sequence[int]]] = None,
    lr_guided: bool = False, risk_bridge: bool = False,
    mc_context_factory=None,
) -> PathRelinkingResult:
    """Relink one feasible solution toward another feasible elite solution.

    PR may traverse worse objective values but never commits a probability-
    infeasible state.  A risk bridge is a restricted pair of *guiding* moves,
    not an unrestricted 2-swap neighborhood.
    """
    started = time.monotonic()
    tol = 1e-12
    current = np.asarray(initiating_solution, dtype=int).copy()
    guide = np.asarray(guiding_solution, dtype=int)
    m = len(current)
    current_cost = float(initiating_cost)
    current_p = float(initiating_probability)
    initial = current.copy()
    guiding_distance = hamming(current, guide)
    if guiding_distance == 0:
        return PathRelinkingResult(True, True, "identical_elites", current.tolist(), guide.tolist(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.0, None, None, None, current.tolist(), current_cost, current_p, [])

    evaluator_name = getattr(EvaluationFunction, "__name__", "")
    delta = None
    delta_samples = 0
    if evaluator_name == "advanced_monte_carlo":
        delta = (DeltaMonteCarloContext if mc_context_factory is None else mc_context_factory)(current, factor_id2obj, m, int(MonteCarloTimes),
                                       float(ConfidenceLevel), float(T_max), int(run_seed),
                                       should_stop=lambda: time.monotonic() >= deadline_monotonic)
        if not delta.initialized:
            return PathRelinkingResult(True, False, "time_limit", initial.tolist(), guide.tolist(), guiding_distance, 0, 0, 0, 0, 0, 0, 0, 0, 0.0, None, None, None, current.tolist(), current_cost, current_p, [])

    eval_count = 0
    path_length = single_accepts = bridge_attempts = bridge_successes = 0
    lr_first_hits = lr_considered = 0
    steps: List[dict] = []
    intermediates: List[Tuple[float, float, List[int]]] = []
    stop_reason = "path_complete"

    def timed_out():
        return time.monotonic() >= float(deadline_monotonic)

    def evaluate_changes(changes: Dict[int, int]):
        nonlocal eval_count, delta_samples
        candidate_cost = float(current_cost + sum(
            float(factor_id2obj[int(new)].cost) - float(factor_id2obj[int(current[cid])].cost)
            for cid, new in changes.items()
        ))
        if getattr(EvaluationFunction, "reference_protocol", False):
            candidate = current.copy()
            for cid, new in changes.items():
                candidate[int(cid)] = int(new)
            p = Solution_Evaluation(EvaluationFunction, candidate, T_max, factor_id2obj,
                                    ConfidenceLevel, param, MonteCarloTimes, QuickCheckList)
            eval_count += 1
            return candidate_cost, float(p), "author_reference_evaluation", bool(float(p)+tol >= ConfidenceLevel), None

        min_sum = 0.0; max_sum = 0.0
        for cid in range(m):
            fid = int(changes.get(cid, current[cid]))
            obj = factor_id2obj[fid]
            min_sum += float(obj.sample_min); max_sum += float(obj.sample_max)
        if min_sum > float(T_max) + tol:
            return candidate_cost, 0.0, "min_bound", False, None
        if max_sum <= float(T_max) + tol:
            return candidate_cost, 1.0, "max_bound", True, None
        if delta is not None:
            move_list = [(int(cid), int(current[cid]), int(new)) for cid, new in sorted(changes.items())]
            out = delta.evaluate_multi_swap(move_list, should_stop=timed_out)
            if out.stopped:
                return candidate_cost, None, "time_limit", False, None
            eval_count += 1
            delta_samples += int(out.samples_used)
            p = float(out.probability)
            feasible = bool(p + tol >= ConfidenceLevel)
            # Bridge trials reuse work_sums and _last_candidate. Retain the
            # single candidate's full buffer before those trials can overwrite it.
            candidate_sums = delta.work_sums.copy() if feasible and out.completed_full_sample else None
            return candidate_cost, p, "delta_mc", feasible, candidate_sums
        candidate = current.copy()
        for cid, new in changes.items():
            candidate[int(cid)] = int(new)
        p = Solution_Evaluation(EvaluationFunction, candidate, T_max, factor_id2obj,
                                ConfidenceLevel, param, MonteCarloTimes, QuickCheckList)
        eval_count += 1
        return candidate_cost, float(p), "original_evaluator", bool(float(p) + tol >= ConfidenceLevel), None

    def commit(changes: Dict[int, int], cost: float, p: float, source: str, candidate_sums=None):
        nonlocal current_cost, current_p
        if delta is not None:
            move_list = [(int(cid), int(current[cid]), int(new)) for cid, new in sorted(changes.items())]
            # Bounds may certify a move without producing a buffer. Rebuild
            # privately with the same CRN; a timeout leaves all current state intact.
            if candidate_sums is None:
                candidate_sums = delta.build_multi_candidate_sums(move_list, should_stop=timed_out)
                if candidate_sums is None:
                    return False
            if not delta.commit_multi_candidate_buffer(move_list, candidate_sums):
                raise RuntimeError(
                    "PR candidate commit failed: source=%s changes=%r cost=%r p=%r seed=%r"
                    % (source, changes, cost, p, run_seed)
                )
        for cid, new in changes.items():
            current[int(cid)] = int(new)
        current_cost = float(solution_cost(current, factor_id2obj))
        current_p = float(p)
        intermediates.append((current_cost, current_p, current.tolist()))
        return True

    while not np.array_equal(current, guide):
        if timed_out():
            stop_reason = "time_limit"; break
        diffs = [cid for cid in range(m) if int(current[cid]) != int(guide[cid])]
        features = [_move_features(current, guide, cid, factor_id2obj, rankings_by_class) for cid in diffs]
        ordered = _order_features(features, lr_guided)
        feasible_choice = None
        infeasible_improving = []
        for rank_index, feat in enumerate(ordered):
            if timed_out():
                stop_reason = "time_limit"; break
            lr_considered += int(lr_guided)
            cid = int(feat["class_id"])
            cost, p, source, feasible, candidate_sums = evaluate_changes({cid: int(guide[cid])})
            if p is None:
                stop_reason = "time_limit"; break
            steps.append({**feat, "path_step": path_length + 1, "candidate_kind": "single",
                          "candidate_cost": cost, "candidate_probability": p,
                          "evaluation_source": source, "feasible": feasible,
                          "accepted": False, "order_index": rank_index})
            if feasible:
                feasible_choice = (cid, cost, p, source, len(steps)-1, feat, candidate_sums)
                if lr_guided and rank_index == 0:
                    lr_first_hits += 1
                break
            if feat["delta_cost"] < -tol:
                infeasible_improving.append(feat)
        if stop_reason == "time_limit":
            break
        # If the first feasible single move is already cost-improving, take it.
        # Otherwise, an infeasible cost-improving guiding move gets one restricted
        # compensation opportunity before we commit a worsening single move.
        if feasible_choice is not None and (
            (not risk_bridge) or (not infeasible_improving) or feasible_choice[5]["delta_cost"] < -tol
        ):
            cid, cost, p, source, row_idx, _feat, candidate_sums = feasible_choice
            if not commit({cid: int(guide[cid])}, cost, p, source, candidate_sums):
                stop_reason = "time_limit"; break
            steps[row_idx]["accepted"] = True
            path_length += 1; single_accepts += 1
            continue

        if risk_bridge and infeasible_improving:
            # Restrict both anchor and compensation counts by the same scale-free
            # sqrt rule; never enumerate the full pair neighborhood.
            q = max(1, int(math.ceil(math.sqrt(max(1, len(diffs))))))
            bridged = False
            for anchor in _order_features(infeasible_improving, lr_guided)[:q]:
                i = int(anchor["class_id"])
                compensation = []
                for j in diffs:
                    if j == i:
                        continue
                    feat_j = _move_features(current, guide, j, factor_id2obj, rankings_by_class)
                    # A compensation candidate should buy back empirical mean risk;
                    # LR rank and cost only break ties.
                    compensation.append(feat_j)
                compensation.sort(key=lambda r: (
                    r["delta_mean_risk"], r["new_lr_rank"] if lr_guided else 0,
                    r["delta_cost"], r["class_id"],
                ))
                for comp in compensation[:q]:
                    if timed_out():
                        stop_reason = "time_limit"; break
                    j = int(comp["class_id"])
                    bridge_attempts += 1
                    cost, p, source, feasible, candidate_sums = evaluate_changes({i: int(guide[i]), j: int(guide[j])})
                    row = {
                        "path_step": path_length + 1, "candidate_kind": "risk_bridge",
                        "class_id": i, "bridge_class_id": j,
                        "old_factor": int(current[i]), "new_factor": int(guide[i]),
                        "bridge_old_factor": int(current[j]), "bridge_new_factor": int(guide[j]),
                        "delta_cost": float(cost - current_cost),
                        "anchor_delta_mean_risk": anchor["delta_mean_risk"],
                        "bridge_delta_mean_risk": comp["delta_mean_risk"],
                        "anchor_new_lr_rank": anchor["new_lr_rank"],
                        "bridge_new_lr_rank": comp["new_lr_rank"],
                        "candidate_cost": cost, "candidate_probability": p,
                        "evaluation_source": source, "feasible": feasible, "accepted": False,
                    }
                    steps.append(row)
                    if feasible:
                        if not commit({i: int(guide[i]), j: int(guide[j])}, cost, p, source, candidate_sums):
                            stop_reason = "time_limit"; break
                        steps[-1]["accepted"] = True
                        path_length += 2; bridge_successes += 1; bridged = True
                        break
                if bridged or stop_reason == "time_limit":
                    break
            if stop_reason == "time_limit":
                break
            if bridged:
                continue

        if feasible_choice is not None:
            cid, cost, p, source, row_idx, _feat, candidate_sums = feasible_choice
            if not commit({cid: int(guide[cid])}, cost, p, source, candidate_sums):
                stop_reason = "time_limit"; break
            steps[row_idx]["accepted"] = True
            path_length += 1; single_accepts += 1
            continue

        stop_reason = "no_feasible_guiding_move"
        break

    completed = bool(np.array_equal(current, guide))
    if completed:
        stop_reason = "path_complete"
    best_intermediate = min(intermediates, key=lambda x: (x[0], x[2])) if intermediates else None
    return PathRelinkingResult(
        invoked=True, completed=completed, stop_reason=stop_reason,
        initiating_solution=initial.tolist(), guiding_solution=guide.tolist(),
        guiding_distance=int(guiding_distance), path_length=int(path_length),
        accepted_single_moves=int(single_accepts), bridge_attempts=int(bridge_attempts),
        bridge_successes=int(bridge_successes), lr_first_choice_hits=int(lr_first_hits),
        lr_ranked_moves_considered=int(lr_considered), evaluation_count=int(eval_count),
        delta_mc_samples_used=int(delta_samples), runtime_seconds=float(time.monotonic()-started),
        best_intermediate_solution=None if best_intermediate is None else best_intermediate[2],
        best_intermediate_cost=None if best_intermediate is None else float(best_intermediate[0]),
        best_intermediate_probability=None if best_intermediate is None else float(best_intermediate[1]),
        final_solution=current.tolist(), final_cost=float(current_cost), final_probability=float(current_p),
        step_rows=steps,
    )
