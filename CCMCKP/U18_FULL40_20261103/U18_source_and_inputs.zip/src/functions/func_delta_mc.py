"""Delta Monte Carlo evaluator for one-class CCMCKP moves.

The evaluator uses common random numbers (CRN) across alternatives of the same
class.  For each Monte Carlo replication r and class i, a deterministic sample
index is generated from a run-specific and class-specific seed.  If the current
solution is changed only in class i from item a to item b, the sampled total is
updated by

    Z_b[r] = Z_current[r] - X_a[r] + X_b[r].

Thus candidate evaluation is O(M) rather than rebuilding all m class samples,
which is O(m M).

Candidates are processed in chunks.  Let Vmax be the largest number of
violations compatible with the fixed-M Monte Carlo rule p_hat >= CL.  As soon as
observed violations exceed Vmax, the final M-sample result can no longer become
feasible, so evaluation stops immediately.  This is an exact early rejection
with respect to the predetermined M-sample CRN experiment; it is not a
confidence-interval approximation.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional, Sequence

import numpy as np


@dataclass
class DeltaMCEvaluation:
    probability: Optional[float]
    samples_used: int
    violation_count: int
    early_rejected: bool
    stopped: bool
    completed_full_sample: bool
    candidate_buffer_ready: bool


class DeltaMonteCarloContext:
    def __init__(
        self,
        solution: Sequence[int],
        factor_id2obj: Sequence,
        class_count: int,
        sample_size: int,
        confidence_level: float,
        tmax: float,
        base_seed: int,
        chunk_size: int = 50_000,
        should_stop: Optional[Callable[[], bool]] = None,
    ):
        self.factor_id2obj = factor_id2obj
        self.class_count = int(class_count)
        self.sample_size = int(sample_size)
        self.confidence_level = float(confidence_level)
        self.tmax = float(tmax)
        self.base_seed = int(base_seed)
        self.chunk_size = max(1, min(int(chunk_size), self.sample_size))
        self.max_violations = int(
            self.sample_size
            - int(np.ceil(self.confidence_level * self.sample_size - 1e-12))
        )
        self.current_solution = np.asarray(solution, dtype=int).copy()
        self.current_sums = np.zeros(self.sample_size, dtype=float)
        self.work_sums = np.empty(self.sample_size, dtype=float)
        self._last_candidate = None
        self.initialized = self._build_current_sums(should_stop)

    def _rng_for_class(self, class_id: int):
        # SeedSequence keeps streams deterministic and independent by class.
        ss = np.random.SeedSequence([self.base_seed, int(class_id), 0xD311A])
        return np.random.default_rng(ss)

    def _chunk_ranges(self):
        for start in range(0, self.sample_size, self.chunk_size):
            end = min(self.sample_size, start + self.chunk_size)
            yield start, end

    def _build_current_sums(self, should_stop=None) -> bool:
        self.current_sums.fill(0.0)
        for class_id in range(self.class_count):
            fid = int(self.current_solution[class_id])
            samples = np.asarray(self.factor_id2obj[fid].samples, dtype=float)
            rng = self._rng_for_class(class_id)
            for start, end in self._chunk_ranges():
                if should_stop is not None and should_stop():
                    return False
                idx = rng.integers(0, len(samples), size=end - start)
                self.current_sums[start:end] += samples[idx]
        return True

    def evaluate_1swap(
        self,
        class_id: int,
        old_factor: int,
        new_factor: int,
        should_stop: Optional[Callable[[], bool]] = None,
    ) -> DeltaMCEvaluation:
        if not self.initialized:
            return DeltaMCEvaluation(None, 0, 0, False, True, False, False)
        class_id = int(class_id)
        old_factor = int(old_factor)
        new_factor = int(new_factor)
        if int(self.current_solution[class_id]) != old_factor:
            raise ValueError("Delta MC current solution is out of sync with DDTS state")

        old_samples = np.asarray(self.factor_id2obj[old_factor].samples, dtype=float)
        new_samples = np.asarray(self.factor_id2obj[new_factor].samples, dtype=float)
        if len(old_samples) != len(new_samples):
            raise ValueError("Delta MC requires equal empirical sample counts within a class")

        rng = self._rng_for_class(class_id)
        violations = 0
        used = 0
        self._last_candidate = None

        for start, end in self._chunk_ranges():
            if should_stop is not None and should_stop():
                return DeltaMCEvaluation(None, used, violations, False, True, False, False)

            idx = rng.integers(0, len(old_samples), size=end - start)
            candidate_chunk = (
                self.current_sums[start:end]
                - old_samples[idx]
                + new_samples[idx]
            )
            self.work_sums[start:end] = candidate_chunk
            violations += int(np.count_nonzero(candidate_chunk > self.tmax))
            used = end

            if violations > self.max_violations:
                return DeltaMCEvaluation(
                    probability=0.0,
                    samples_used=int(used),
                    violation_count=int(violations),
                    early_rejected=True,
                    stopped=False,
                    completed_full_sample=False,
                    candidate_buffer_ready=False,
                )

        probability = 1.0 - float(violations) / float(self.sample_size)
        feasible = probability + 1e-15 >= self.confidence_level
        if feasible:
            self._last_candidate = (class_id, old_factor, new_factor)
        return DeltaMCEvaluation(
            probability=float(probability),
            samples_used=int(self.sample_size),
            violation_count=int(violations),
            early_rejected=False,
            stopped=False,
            completed_full_sample=True,
            candidate_buffer_ready=bool(feasible),
        )


    def evaluate_multi_swap(
        self,
        moves,
        should_stop: Optional[Callable[[], bool]] = None,
    ) -> DeltaMCEvaluation:
        """Evaluate a small simultaneous multi-class replacement under the same CRN.

        ``moves`` is an iterable of ``(class_id, old_factor, new_factor)``.
        This is used by path relinking's restricted risk-compensation bridge.
        It preserves the exact fixed-M feasibility rule and early rejection.
        """
        if not self.initialized:
            return DeltaMCEvaluation(None, 0, 0, False, True, False, False)
        norm = []
        seen = set()
        for class_id, old_factor, new_factor in moves:
            class_id = int(class_id); old_factor = int(old_factor); new_factor = int(new_factor)
            if class_id in seen:
                raise ValueError("duplicate class in multi-swap")
            seen.add(class_id)
            if int(self.current_solution[class_id]) != old_factor:
                raise ValueError("Delta MC current solution is out of sync with multi-swap state")
            norm.append((class_id, old_factor, new_factor))
        norm.sort()
        if not norm:
            violations = int(np.count_nonzero(self.current_sums > self.tmax))
            probability = 1.0 - float(violations) / float(self.sample_size)
            return DeltaMCEvaluation(probability, self.sample_size, violations, False, False, True, True)

        violations = 0
        used = 0
        self._last_candidate = None
        rngs = {class_id: self._rng_for_class(class_id) for class_id, _, _ in norm}
        for start, end in self._chunk_ranges():
            if should_stop is not None and should_stop():
                return DeltaMCEvaluation(None, used, violations, False, True, False, False)
            candidate_chunk = self.current_sums[start:end].copy()
            for class_id, old_factor, new_factor in norm:
                old_samples = np.asarray(self.factor_id2obj[old_factor].samples, dtype=float)
                new_samples = np.asarray(self.factor_id2obj[new_factor].samples, dtype=float)
                if len(old_samples) != len(new_samples):
                    raise ValueError("Delta MC requires equal empirical sample counts within a class")
                idx = rngs[class_id].integers(0, len(old_samples), size=end-start)
                candidate_chunk += new_samples[idx] - old_samples[idx]
            self.work_sums[start:end] = candidate_chunk
            violations += int(np.count_nonzero(candidate_chunk > self.tmax))
            used = end
            if violations > self.max_violations:
                return DeltaMCEvaluation(0.0, int(used), int(violations), True, False, False, False)
        probability = 1.0 - float(violations) / float(self.sample_size)
        feasible = probability + 1e-15 >= self.confidence_level
        if feasible:
            self._last_candidate = ("multi", tuple(norm))
        return DeltaMCEvaluation(float(probability), self.sample_size, int(violations), False, False, True, bool(feasible))

    def commit_last_multi_candidate(self, moves) -> bool:
        norm = tuple(sorted((int(c), int(o), int(n)) for c,o,n in moves))
        if self._last_candidate != ("multi", norm):
            return False
        self.current_sums, self.work_sums = self.work_sums, self.current_sums
        for class_id, old_factor, new_factor in norm:
            if int(self.current_solution[class_id]) != old_factor:
                raise ValueError("Delta MC current solution changed before multi-swap commit")
            self.current_solution[class_id] = new_factor
        self._last_candidate = None
        return True

    def build_multi_candidate_sums(
        self, moves, should_stop: Optional[Callable[[], bool]] = None
    ) -> Optional[np.ndarray]:
        """Reconstruct a candidate using the same CRN, without changing current state.

        A deadline interruption discards the private buffer. All replacements
        are based on the original current solution, including two-class bridges.
        """
        if not self.initialized:
            return None
        norm = tuple(sorted((int(c), int(o), int(n)) for c, o, n in moves))
        seen = set()
        samples_by_class = {}
        for class_id, old_factor, new_factor in norm:
            if class_id in seen:
                raise ValueError("duplicate class in multi-swap")
            seen.add(class_id)
            if int(self.current_solution[class_id]) != old_factor:
                raise ValueError("Delta MC current solution is out of sync with multi-swap state")
            old_samples = np.asarray(self.factor_id2obj[old_factor].samples, dtype=float)
            new_samples = np.asarray(self.factor_id2obj[new_factor].samples, dtype=float)
            if len(old_samples) != len(new_samples):
                raise ValueError("Delta MC requires equal empirical sample counts within a class")
            samples_by_class[class_id] = (old_samples, new_samples)
        candidate_sums = self.current_sums.copy()
        for class_id, old_factor, new_factor in norm:
            old_samples, new_samples = samples_by_class[class_id]
            rng = self._rng_for_class(class_id)
            for start, end in self._chunk_ranges():
                if should_stop is not None and should_stop():
                    return None
                idx = rng.integers(0, len(old_samples), size=end-start)
                candidate_sums[start:end] += new_samples[idx] - old_samples[idx]
        return candidate_sums

    def commit_multi_candidate_buffer(self, moves, candidate_sums) -> bool:
        """Commit an explicitly retained full candidate, independent of scratch state."""
        if not self.initialized:
            return False
        norm = tuple(sorted((int(c), int(o), int(n)) for c, o, n in moves))
        if len({c for c, _, _ in norm}) != len(norm):
            raise ValueError("duplicate class in multi-swap")
        # Validate every class before publishing any part of the new state.
        candidate_solution = self.current_solution.copy()
        for class_id, old_factor, new_factor in norm:
            if int(self.current_solution[class_id]) != old_factor:
                raise ValueError("Delta MC current solution changed before multi-swap commit")
            candidate_solution[class_id] = new_factor
        candidate_sums = np.asarray(candidate_sums, dtype=float)
        if candidate_sums.shape != self.current_sums.shape:
            raise ValueError("Delta MC candidate buffer has an invalid shape")
        committed_sums = candidate_sums.copy()
        self.current_sums = committed_sums
        self.current_solution = candidate_solution
        self._last_candidate = None
        return True

    def apply_multi_swap_without_prior_full_evaluation(
        self, moves, should_stop: Optional[Callable[[], bool]] = None
    ) -> bool:
        # Bound-certified moves still require a complete, matching CRN buffer.
        moves = tuple(moves)
        candidate_sums = self.build_multi_candidate_sums(moves, should_stop)
        if candidate_sums is None:
            return False
        return self.commit_multi_candidate_buffer(moves, candidate_sums)

    def commit_last_candidate(self, class_id: int, old_factor: int, new_factor: int) -> bool:
        key = (int(class_id), int(old_factor), int(new_factor))
        if self._last_candidate != key:
            return False
        self.current_sums, self.work_sums = self.work_sums, self.current_sums
        self.current_solution[int(class_id)] = int(new_factor)
        self._last_candidate = None
        return True

    def apply_1swap_without_prior_full_evaluation(
        self,
        class_id: int,
        old_factor: int,
        new_factor: int,
        should_stop: Optional[Callable[[], bool]] = None,
    ) -> bool:
        """Update the maintained current-sum vector after a bound-certified move."""
        if not self.initialized:
            return False
        class_id = int(class_id)
        old_factor = int(old_factor)
        new_factor = int(new_factor)
        if int(self.current_solution[class_id]) != old_factor:
            raise ValueError("Delta MC current solution is out of sync with DDTS state")

        old_samples = np.asarray(self.factor_id2obj[old_factor].samples, dtype=float)
        new_samples = np.asarray(self.factor_id2obj[new_factor].samples, dtype=float)
        rng = self._rng_for_class(class_id)
        for start, end in self._chunk_ranges():
            if should_stop is not None and should_stop():
                return False
            idx = rng.integers(0, len(old_samples), size=end - start)
            self.current_sums[start:end] += new_samples[idx] - old_samples[idx]
        self.current_solution[class_id] = new_factor
        self._last_candidate = None
        return True
