"""Fast feasibility-first initializer for time-limited DDTS.

The initializer keeps the DDALS constructive-procedure starting rule (the
highest-utility item in every class) but removes repeated full probability
calls from the critical path.

Workflow
--------
1. Build the original CP utility seed.
2. Evaluate it on a small class-wise common-random-number pilot experiment.
3. If necessary, repair it with one-class moves that reduce pilot violations:
   * first prefer moves with non-positive cost increase;
   * otherwise maximize violation reduction per unit cost increase.
4. A pilot-feasible candidate must pass a higher-precision confirmation before
   it can become the DDTS incumbent.
5. If the repair budget is nearly exhausted, fall back to the original CP
   minimum-surrogate-weight anchor and confirm it as well.

For large instances the confirmation is an independent Monte Carlo experiment
(relative to the pilot experiment).  For exact-mode small instances the exact
empirical evaluator is used instead, which is stronger than a Monte Carlo
confirmation for the empirical benchmark model.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import time
from typing import Callable, Dict, Optional, Sequence

import numpy as np
from src.functions.func_cost_risk_seed import cost_risk_initial_proposal

from src.functions.func_localsearch_cp_corrected import NoFeasibleInitialSolution
from src.functions.func_solution_factor_corrected import Solution_Initialization, solution_cost


@dataclass
class IndependentValidationResult:
    probability: Optional[float]
    samples_used: int
    violation_count: int
    completed: bool
    early_rejected: bool
    timed_out: bool
    mode: str


@dataclass
class FastInitializationMetadata:
    source: str
    success: bool
    ttff_seconds: Optional[float]
    runtime_seconds: float
    repair_count: int
    pilot_move_evaluation_count: int
    validation_attempt_count: int
    validation_samples_used: int
    pilot_samples: int
    validation_samples: int
    initial_pilot_probability: Optional[float]
    final_pilot_probability: Optional[float]
    final_validation_probability: Optional[float]
    safe_anchor_used: bool
    failure_reason: Optional[str]

    def to_dict(self):
        return asdict(self)


class PilotDeltaContext:
    """Fixed-size pilot CRN experiment for fast violation-driven repair."""

    def __init__(
        self,
        solution: Sequence[int],
        factor_id2obj: Sequence,
        class_count: int,
        sample_size: int,
        tmax: float,
        base_seed: int,
        should_stop: Optional[Callable[[], bool]] = None,
        reference_protocol: bool = False,
    ):
        self.reference_protocol = bool(reference_protocol)
        self.factor_id2obj = factor_id2obj
        self.class_count = int(class_count)
        self.sample_size = int(sample_size)
        self.tmax = float(tmax)
        self.base_seed = int(base_seed)
        self.current_solution = np.asarray(solution, dtype=int).copy()
        self.indices_by_class: Dict[int, np.ndarray] = {}
        self.sample_cache: Dict[tuple[int, int], np.ndarray] = {}
        self.current_sums = np.zeros(self.sample_size, dtype=float)

        for class_id in range(self.class_count):
            if should_stop is not None and should_stop():
                raise TimeoutError("pilot_delta_context_timeout")
            fid = int(self.current_solution[class_id])
            samples = np.asarray(self.factor_id2obj[fid].samples, dtype=float)
            rng = np.random.default_rng(
                np.random.SeedSequence([self.base_seed, int(class_id), 0x1A17])
            )
            idx = rng.integers(0, len(samples)-int(self.reference_protocol), size=self.sample_size, dtype=np.int64)
            self.indices_by_class[class_id] = idx
            self.current_sums += self._sampled_values(class_id, fid)

    def _sampled_values(self, class_id: int, factor_id: int) -> np.ndarray:
        key = (int(class_id), int(factor_id))
        cached = self.sample_cache.get(key)
        if cached is not None:
            return cached
        samples = np.asarray(self.factor_id2obj[int(factor_id)].samples, dtype=float)
        values = samples[self.indices_by_class[int(class_id)]]
        self.sample_cache[key] = values
        return values

    def violation_count(self) -> int:
        return int(np.count_nonzero(self.current_sums >= self.tmax if self.reference_protocol else self.current_sums > self.tmax))

    def probability(self) -> float:
        return 1.0 - float(self.violation_count()) / float(self.sample_size)

    def candidate_violation_count(self, class_id: int, old_factor: int, new_factor: int) -> int:
        old_values = self._sampled_values(class_id, old_factor)
        new_values = self._sampled_values(class_id, new_factor)
        candidate_sums = self.current_sums - old_values + new_values
        return int(np.count_nonzero(candidate_sums >= self.tmax if self.reference_protocol else candidate_sums > self.tmax))

    def apply_move(self, class_id: int, old_factor: int, new_factor: int) -> None:
        class_id = int(class_id)
        old_factor = int(old_factor)
        new_factor = int(new_factor)
        if int(self.current_solution[class_id]) != old_factor:
            raise ValueError("pilot Delta context is out of sync with initializer solution")
        self.current_sums += (
            self._sampled_values(class_id, new_factor)
            - self._sampled_values(class_id, old_factor)
        )
        self.current_solution[class_id] = new_factor

    def reset_solution(self, solution: Sequence[int], should_stop: Optional[Callable[[], bool]] = None) -> None:
        self.current_solution = np.asarray(solution, dtype=int).copy()
        self.current_sums.fill(0.0)
        for class_id in range(self.class_count):
            if should_stop is not None and should_stop():
                raise TimeoutError("pilot_safe_anchor_timeout")
            self.current_sums += self._sampled_values(class_id, int(self.current_solution[class_id]))


def _independent_mc_validate(
    solution: Sequence[int],
    factor_id2obj: Sequence,
    class_count: int,
    sample_size: int,
    confidence_level: float,
    tmax: float,
    base_seed: int,
    deadline_monotonic: Optional[float],
    chunk_size: int = 50_000,
) -> IndependentValidationResult:
    """Confirm one solution on a fresh Monte Carlo stream.

    This stream is independent of the pilot stream.  Exact violation-count early
    rejection is used only to save time when feasibility is already impossible
    for the predetermined sample size.
    """
    sample_size = int(sample_size)
    if sample_size <= 0:
        raise ValueError("validation sample size must be positive")
    class_count = int(class_count)
    chunk_size = max(1, min(int(chunk_size), sample_size))
    max_violations = sample_size - int(np.ceil(float(confidence_level) * sample_size - 1e-12))
    violations = 0
    used = 0

    # Process complete chunks across all classes to avoid storing an m x M matrix.
    rng_by_class = []
    for class_id in range(class_count):
        rng_by_class.append(
            np.random.default_rng(
                np.random.SeedSequence([int(base_seed), int(class_id), 0x51A7])
            )
        )

    for start in range(0, sample_size, chunk_size):
        if deadline_monotonic is not None and time.monotonic() >= deadline_monotonic:
            return IndependentValidationResult(None, used, violations, False, False, True, "independent_mc")
        end = min(sample_size, start + chunk_size)
        totals = np.zeros(end - start, dtype=float)
        for class_id in range(class_count):
            if deadline_monotonic is not None and time.monotonic() >= deadline_monotonic:
                return IndependentValidationResult(None, used, violations, False, False, True, "independent_mc")
            fid = int(solution[class_id])
            samples = np.asarray(factor_id2obj[fid].samples, dtype=float)
            idx = rng_by_class[class_id].integers(0, len(samples), size=end - start)
            totals += samples[idx]
        violations += int(np.count_nonzero(totals > float(tmax)))
        used = end
        if violations > max_violations:
            return IndependentValidationResult(
                0.0,
                used,
                violations,
                False,
                True,
                False,
                "independent_mc",
            )

    probability = 1.0 - float(violations) / float(sample_size)
    return IndependentValidationResult(
        float(probability), sample_size, violations, True, False, False, "independent_mc"
    )


def _fixed_crn_validate(
    solution, factor_id2obj, class_count, sample_size, confidence_level,
    tmax, base_seed, deadline_monotonic, chunk_size=50_000, mc_context_factory=None,
) -> IndependentValidationResult:
    """Use the identical fixed-M experiment and class streams as Delta MC.

    Pilot and independent confirmation can screen candidates, but only this
    authoritative check may certify an initializer for a fixed-M search.
    """
    sample_size = int(sample_size)
    if sample_size <= 0:
        raise ValueError("authoritative sample size must be positive")
    if mc_context_factory is not None:
        should_stop = lambda: deadline_monotonic is not None and time.monotonic() >= deadline_monotonic
        context = mc_context_factory(solution, factor_id2obj, class_count, sample_size,
                                     confidence_level, tmax, base_seed, should_stop=should_stop)
        out = context.evaluate_current(should_stop=should_stop)
        return IndependentValidationResult(out.probability, out.samples_used, out.violation_count,
                                           out.completed_full_sample, out.early_rejected,
                                           out.stopped, "fixed_m_defensive_is_cmc")
    chunk_size = max(1, min(int(chunk_size), sample_size))
    maximum = sample_size - int(np.ceil(float(confidence_level)*sample_size-1e-12))
    rngs = [np.random.default_rng(np.random.SeedSequence([int(base_seed), cid, 0xD311A]))
            for cid in range(int(class_count))]
    samples = [np.asarray(factor_id2obj[int(fid)].samples, dtype=float) for fid in solution]
    violations = used = 0
    for start in range(0, sample_size, chunk_size):
        end = min(sample_size, start+chunk_size)
        totals = np.zeros(end-start, dtype=float)
        for cid in range(int(class_count)):
            if deadline_monotonic is not None and time.monotonic() >= deadline_monotonic:
                return IndependentValidationResult(None, used, violations, False, False, True, "fixed_m_crn")
            indices = rngs[cid].integers(0, len(samples[cid]), size=end-start)
            totals += samples[cid][indices]
        violations += int(np.count_nonzero(totals > float(tmax)))
        used = end
        if violations > maximum:
            return IndependentValidationResult(0.0, used, violations, False, True, False, "fixed_m_crn")
    probability = 1.0-float(violations)/sample_size
    return IndependentValidationResult(probability, used, violations, True, False, False, "fixed_m_crn")


def Fast_Construct_Procedure(
    Eval_func,
    node_resort_w,
    node_resort_u,
    factor_id2obj,
    threshold_p,
    T_max,
    param,
    pilot_samples: int = 10_000,
    validation_samples: int = 100_000,
    run_seed: int = 0,
    deadline_monotonic: Optional[float] = None,
    safe_reserve_seconds: float = 1.0,
    verbose: bool = False,
    randomized_rcl_size: int = 1,
    randomized_seed: Optional[int] = None,
    randomized_candidate_order: Optional[dict] = None,
    authoritative_mc_samples: Optional[int] = None,
    authoritative_probability_cache: Optional[dict] = None,
    mc_context_factory=None,
    quick_check_list=None,
    use_cost_risk_seed=False,
):
    """Return ``(cp_tuple, metadata)`` for DDTS initialization.

    ``cp_tuple`` keeps the historical DDALS/DDTS positional contract:
    ``(solution, cost, probability, evaluation_count, trace)``.
    """
    start = time.monotonic()
    m = int(param[0])
    pilot_samples = int(pilot_samples)
    validation_samples = int(validation_samples)
    safe_reserve_seconds = max(0.0, float(safe_reserve_seconds))
    if pilot_samples <= 0 or validation_samples <= pilot_samples:
        raise ValueError("require 0 < pilot_samples < validation_samples")

    def timed_out() -> bool:
        return deadline_monotonic is not None and time.monotonic() >= deadline_monotonic

    def fail(reason: str, *, repair_count=0, pilot_move_evals=0, validation_attempts=0,
             validation_samples_used=0, initial_p=None, final_p=None, validation_p=None,
             safe_anchor_used=False):
        metadata = FastInitializationMetadata(
            source="failed",
            success=False,
            ttff_seconds=None,
            runtime_seconds=float(time.monotonic() - start),
            repair_count=int(repair_count),
            pilot_move_evaluation_count=int(pilot_move_evals),
            validation_attempt_count=int(validation_attempts),
            validation_samples_used=int(validation_samples_used),
            pilot_samples=pilot_samples,
            validation_samples=validation_samples,
            initial_pilot_probability=initial_p,
            final_pilot_probability=final_p,
            final_validation_probability=validation_p,
            safe_anchor_used=bool(safe_anchor_used),
            failure_reason=str(reason),
        ).to_dict()
        raise NoFeasibleInitialSolution(str(reason), metadata=metadata)

    if timed_out():
        fail("initialization_deadline_reached_before_start")

    # GRASP-style randomized greedy start.  rcl_size=1 exactly reproduces
    # the original DDALS/DDTS highest-utility starting solution.  For later
    # multi-start restarts, one item is sampled uniformly from the top-k
    # utility candidates of each class.  Only this construction choice is
    # randomized; pilot/validation CRN streams still use ``run_seed``.
    randomized_rcl_size = max(1, int(randomized_rcl_size))
    initial_source = "utility_seed"
    if randomized_rcl_size == 1:
        if use_cost_risk_seed and getattr(Eval_func, "reference_mc", False):
            current = cost_risk_initial_proposal(node_resort_u, factor_id2obj, T_max, threshold_p)
            initial_source = "cost_risk_seed"
        else:
            current = Solution_Initialization(node_resort_u, param, 0)
    else:
        init_rng = np.random.default_rng(
            int(run_seed) if randomized_seed is None else int(randomized_seed)
        )
        current = np.zeros(m, dtype=int)
        for class_id in range(m):
            if randomized_candidate_order is not None and class_id in randomized_candidate_order:
                ranked = [int(v) for v in randomized_candidate_order[class_id]]
            else:
                ranked = list(node_resort_u[class_id])
            if not ranked:
                fail("empty_randomized_rcl_class_%d" % int(class_id))
            k = min(randomized_rcl_size, len(ranked))
            current[class_id] = int(ranked[int(init_rng.integers(0, k))])
    current_cost = solution_cost(current, factor_id2obj)
    trace = []

    try:
        pilot = PilotDeltaContext(
            current,
            factor_id2obj,
            m,
            pilot_samples,
            T_max,
            int(run_seed) + 0x12000,
            should_stop=timed_out,
            reference_protocol=bool(getattr(Eval_func, "reference_protocol", False)),
        )
    except TimeoutError:
        fail("pilot_construction_timeout")

    current_violations = pilot.violation_count()
    allowed_pilot_violations = pilot_samples - int(
        np.ceil(float(threshold_p) * pilot_samples - 1e-12)
    )
    initial_pilot_p = pilot.probability()
    trace.append([float(current_cost), float(initial_pilot_p), np.copy(current), 1])

    repair_count = 0
    pilot_move_evals = 0
    validation_attempts = 0
    validation_samples_used = 0
    final_validation_p = None

    # Reserve a small tail of the initialization budget for the safe anchor.
    repair_deadline = None
    if deadline_monotonic is not None:
        repair_deadline = max(start, float(deadline_monotonic) - safe_reserve_seconds)

    def repair_phase_timed_out() -> bool:
        return repair_deadline is not None and time.monotonic() >= repair_deadline

    def confirm(solution, attempt_index: int):
        nonlocal validation_samples_used
        if timed_out():
            return IndependentValidationResult(None, 0, 0, False, False, True, "timeout")

        if getattr(Eval_func, "reference_protocol", False):
            factor_list = [factor_id2obj[int(fid)] for fid in solution]
            full_m = int(authoritative_mc_samples or validation_samples)
            p = float(Eval_func(factor_list, T_max, full_m, threshold_p, param, [] if quick_check_list is None else quick_check_list))
            used = int(getattr(Eval_func, "last_samples_used", 0))
            validation_samples_used += used
            return IndependentValidationResult(p, used, int(round(used*(1.0-p))),
                                               True, p < threshold_p, False, "author_reference_evaluation")

        # In exact-mode small instances use the exact empirical probability as
        # the authoritative confirmation; this is stronger than MC for the
        # benchmark empirical-distribution model.
        if getattr(Eval_func, "__name__", "") != "advanced_monte_carlo":
            factor_list = [factor_id2obj[int(fid)] for fid in solution]
            p = float(Eval_func(factor_list, T_max, validation_samples, threshold_p, param, []))
            return IndependentValidationResult(p, 0, 0, True, False, False, "exact_empirical")

        out = _independent_mc_validate(
            solution,
            factor_id2obj,
            m,
            validation_samples,
            threshold_p,
            T_max,
            int(run_seed) + 0x530000 + int(attempt_index) * 1009,
            deadline_monotonic,
        )
        validation_samples_used += int(out.samples_used)
        if (authoritative_mc_samples is None or not out.completed or out.probability is None
                or out.probability + 1e-15 < threshold_p):
            return out
        # The run-local cache is valid only for the same full-M stream, threshold
        # and assignment. It cannot import an incumbent from a different run.
        key = (int(run_seed), int(authoritative_mc_samples), float(T_max),
               float(threshold_p), tuple(int(fid) for fid in solution))
        cached = None if authoritative_probability_cache is None else authoritative_probability_cache.get(key)
        if cached is not None:
            return IndependentValidationResult(cached.probability, 0, cached.violation_count,
                                               cached.completed, cached.early_rejected, False, "fixed_m_crn_cached")
        authoritative = _fixed_crn_validate(
            solution, factor_id2obj, m, authoritative_mc_samples, threshold_p,
            T_max, run_seed, deadline_monotonic, mc_context_factory=mc_context_factory,
        )
        validation_samples_used += int(authoritative.samples_used)
        if authoritative_probability_cache is not None and not authoritative.timed_out:
            authoritative_probability_cache[key] = authoritative
        return authoritative

    def maybe_accept(source: str):
        nonlocal validation_attempts, final_validation_p
        if current_violations > allowed_pilot_violations:
            return None
        validation_attempts += 1
        checked = confirm(current, validation_attempts)
        if checked.timed_out:
            return "timeout"
        final_validation_p = checked.probability
        if checked.completed and checked.probability is not None and checked.probability + 1e-15 >= threshold_p:
            elapsed = float(time.monotonic() - start)
            metadata = FastInitializationMetadata(
                source=source,
                success=True,
                ttff_seconds=elapsed,
                runtime_seconds=elapsed,
                repair_count=int(repair_count),
                pilot_move_evaluation_count=int(pilot_move_evals),
                validation_attempt_count=int(validation_attempts),
                validation_samples_used=int(validation_samples_used),
                pilot_samples=pilot_samples,
                validation_samples=validation_samples,
                initial_pilot_probability=float(initial_pilot_p),
                final_pilot_probability=float(pilot.probability()),
                final_validation_probability=float(checked.probability),
                safe_anchor_used=(source == "safe_anchor"),
                failure_reason=None,
            ).to_dict()
            eval_count = int(validation_attempts)
            cp = (
                np.copy(current),
                float(current_cost),
                float(checked.probability),
                int(eval_count),
                trace,
            )
            return cp, metadata
        return None

    accepted = maybe_accept(initial_source)
    if isinstance(accepted, tuple):
        return accepted

    # If the pilot says feasible but the independent confirmation rejects it,
    # keep reducing pilot violations instead of entering DDTS with an uncertain
    # incumbent.
    tol = 1e-12
    while not repair_phase_timed_out() and not timed_out():
        best_move = None
        best_key = None

        for class_id in range(m):
            if repair_phase_timed_out() or timed_out():
                break
            old_factor = int(current[class_id])
            old_obj = factor_id2obj[old_factor]
            for new_factor in node_resort_w[class_id]:
                if repair_phase_timed_out() or timed_out():
                    break
                new_factor = int(new_factor)
                if new_factor == old_factor:
                    continue
                pilot_move_evals += 1
                cand_violations = pilot.candidate_violation_count(class_id, old_factor, new_factor)
                delta_v = int(current_violations - cand_violations)
                if delta_v <= 0:
                    continue
                new_obj = factor_id2obj[new_factor]
                delta_cost = float(new_obj.cost - old_obj.cost)
                candidate_cost = float(current_cost + delta_cost)

                if delta_cost <= tol:
                    # Highest priority: reduce violations without increasing cost.
                    key = (0, -delta_v, candidate_cost, class_id, new_factor)
                else:
                    ratio = float(delta_v) / float(delta_cost)
                    key = (1, -ratio, -delta_v, delta_cost, candidate_cost, class_id, new_factor)

                if best_key is None or key < best_key:
                    best_key = key
                    best_move = (
                        int(class_id), int(old_factor), int(new_factor),
                        int(cand_violations), float(candidate_cost), float(delta_cost), int(delta_v),
                    )

        if best_move is None:
            break

        class_id, old_factor, new_factor, cand_violations, candidate_cost, delta_cost, delta_v = best_move
        pilot.apply_move(class_id, old_factor, new_factor)
        current[class_id] = new_factor
        current_cost = candidate_cost
        current_violations = cand_violations
        repair_count += 1
        trace.append([float(current_cost), float(pilot.probability()), np.copy(current), 1 + pilot_move_evals])

        if verbose:
            print(
                "FastInit repair",
                repair_count,
                "class", class_id,
                "move", old_factor, "->", new_factor,
                "delta_v", delta_v,
                "delta_cost", delta_cost,
                "pilot_p", pilot.probability(),
            )

        accepted = maybe_accept("violation_driven_repair")
        if isinstance(accepted, tuple):
            return accepted
        if accepted == "timeout":
            break

    # Safe anchor: same fallback concept as the original CP, namely the minimum
    # surrogate weight item retained in every class.
    safe_anchor = Solution_Initialization(node_resort_w, param, -1)
    safe_anchor_used = True
    try:
        pilot.reset_solution(safe_anchor, should_stop=timed_out)
    except TimeoutError:
        fail(
            "initialization_timeout_before_safe_anchor_confirmation",
            repair_count=repair_count,
            pilot_move_evals=pilot_move_evals,
            validation_attempts=validation_attempts,
            validation_samples_used=validation_samples_used,
            initial_p=initial_pilot_p,
            final_p=pilot.probability() if pilot.current_sums.size else None,
            validation_p=final_validation_p,
            safe_anchor_used=True,
        )

    current = np.copy(safe_anchor)
    current_cost = solution_cost(current, factor_id2obj)
    current_violations = pilot.violation_count()
    trace.append([float(current_cost), float(pilot.probability()), np.copy(current), 1 + pilot_move_evals])

    if timed_out():
        fail(
            "initialization_timeout_at_safe_anchor",
            repair_count=repair_count,
            pilot_move_evals=pilot_move_evals,
            validation_attempts=validation_attempts,
            validation_samples_used=validation_samples_used,
            initial_p=initial_pilot_p,
            final_p=pilot.probability(),
            validation_p=final_validation_p,
            safe_anchor_used=True,
        )

    # The safe anchor is confirmed only if it first passes the pilot rule.
    if current_violations <= allowed_pilot_violations:
        validation_attempts += 1
        checked = confirm(current, validation_attempts)
        final_validation_p = checked.probability
        if checked.completed and checked.probability is not None and checked.probability + 1e-15 >= threshold_p:
            elapsed = float(time.monotonic() - start)
            metadata = FastInitializationMetadata(
                source="safe_anchor",
                success=True,
                ttff_seconds=elapsed,
                runtime_seconds=elapsed,
                repair_count=int(repair_count),
                pilot_move_evaluation_count=int(pilot_move_evals),
                validation_attempt_count=int(validation_attempts),
                validation_samples_used=int(validation_samples_used),
                pilot_samples=pilot_samples,
                validation_samples=validation_samples,
                initial_pilot_probability=float(initial_pilot_p),
                final_pilot_probability=float(pilot.probability()),
                final_validation_probability=float(checked.probability),
                safe_anchor_used=True,
                failure_reason=None,
            ).to_dict()
            eval_count = int(validation_attempts)
            cp = (np.copy(current), float(current_cost), float(checked.probability), int(eval_count), trace)
            return cp, metadata

        reason = "safe_anchor_validation_timeout" if checked.timed_out else "safe_anchor_failed_high_precision_validation"
    else:
        reason = "safe_anchor_failed_pilot_feasibility"

    fail(
        reason,
        repair_count=repair_count,
        pilot_move_evals=pilot_move_evals,
        validation_attempts=validation_attempts,
        validation_samples_used=validation_samples_used,
        initial_p=initial_pilot_p,
        final_p=pilot.probability(),
        validation_p=final_validation_p,
        safe_anchor_used=safe_anchor_used,
    )
