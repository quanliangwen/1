"""Corrected surrogate-based constructive procedure.

The author's original file is preserved.  This version uses the corrected
probability evaluator and fixes the confirmed fallback stale-probability issue.
It also stops immediately when the initial utility-based solution is already
probability-feasible, which is the intended CP behavior described in the paper.

DDTS-v1 repair: if the CP fallback solution is still probability-infeasible,
a single layer of same-class 1-swap neighbors is evaluated.  If at least one
of those neighbors is probability-feasible, the minimum-cost feasible neighbor
is returned as the initial solution.  This repair is invoked only after the
original CP path and fallback have both failed; it does not alter the DDTS
main search.
"""

import numpy as np

from src.functions.func_solution_factor_corrected import (
    Solution_Evaluation,
    Solution_Initialization,
    solution_cost,
)


class NoFeasibleInitialSolution(RuntimeError):
    """Raised when initialization cannot obtain a confirmed feasible solution.

    ``metadata`` is optional and lets DDTS experiment drivers persist the
    initialization failure reason/timing without changing older callers.
    """

    def __init__(self, message, metadata=None):
        super().__init__(message)
        self.metadata = dict(metadata or {})


def _one_swap_feasibility_repair(
    Eval_func,
    base_solution,
    node_resort_w,
    fi,
    threshold_p,
    T_max,
    param,
    MC_sample_size,
    quick_check_list,
    eval_times,
    trace,
    verbose=False,
):
    """Try one same-class replacement around an infeasible CP fallback.

    Every candidate differs from ``base_solution`` in exactly one class, so the
    multiple-choice constraint remains satisfied.  All candidates are checked
    by the same probability evaluator used by CP/DDTS.  Among feasible
    candidates, the minimum-cost one is returned.  If no feasible 1-swap
    neighbor exists, ``None`` is returned.
    """
    base_solution = np.asarray(base_solution, dtype=int)
    best_solution = None
    best_cost = None
    best_p = None
    tol = 1e-12

    node_num = int(param[0])
    for node_id in range(node_num):
        old_factor = int(base_solution[node_id])
        for new_factor in node_resort_w[node_id]:
            new_factor = int(new_factor)
            if new_factor == old_factor:
                continue

            candidate = np.copy(base_solution)
            candidate[node_id] = new_factor
            candidate_p = Solution_Evaluation(
                Eval_func,
                candidate,
                T_max,
                fi,
                threshold_p,
                param,
                MC_sample_size,
                quick_check_list,
            )
            eval_times += 1
            candidate_c = solution_cost(candidate, fi)
            trace.append([candidate_c, candidate_p, np.copy(candidate), eval_times])

            if verbose:
                print("CP repair candidate:", candidate_c, candidate_p, candidate)

            if candidate_p + tol < threshold_p:
                continue

            if (
                best_solution is None
                or candidate_c < best_cost - tol
                or (
                    abs(candidate_c - best_cost) <= tol
                    and tuple(int(v) for v in candidate)
                    < tuple(int(v) for v in best_solution)
                )
            ):
                best_solution = np.copy(candidate)
                best_cost = float(candidate_c)
                best_p = float(candidate_p)

    if best_solution is None:
        return None, None, None, eval_times, trace

    return best_solution, best_cost, best_p, eval_times, trace


def Construct_Procedure(
    Eval_func,
    node_resort_w,
    node_resort_u,
    fi,
    threshold_p,
    T_max,
    param,
    MC_sample_size,
    quick_check_list,
    verbose=False,
):
    eval_times = 0
    current = Solution_Initialization(node_resort_u, param, 0)
    available = np.copy(current)

    p = Solution_Evaluation(
        Eval_func, current, T_max, fi, threshold_p, param, MC_sample_size, quick_check_list
    )
    eval_times += 1
    trace = [[solution_cost(current, fi), p, np.copy(current), eval_times]]

    if p >= threshold_p:
        return np.copy(current), solution_cost(current, fi), p, eval_times, trace

    stopping_condition = -np.ones(len(available), dtype=int)

    while True:
        factor_list = [fi[int(factor_id)] for factor_id in current]
        solution_weight = [factor.weight for factor in factor_list]
        for i in range(len(available)):
            if available[i] == -1:
                solution_weight[i] = -float("inf")

        select_node = int(np.argsort(solution_weight)[-1])
        select_factor = int(current[select_node])
        weight_order = node_resort_w[select_node]
        pos = weight_order.index(select_factor)

        if pos < len(weight_order) - 1:
            current[select_node] = weight_order[pos + 1]
            p = Solution_Evaluation(
                Eval_func, current, T_max, fi, threshold_p, param, MC_sample_size, quick_check_list
            )
            eval_times += 1
            c = solution_cost(current, fi)
            trace.append([c, p, np.copy(current), eval_times])
            if verbose:
                print("CP current:", c, p, current)
            if p >= threshold_p:
                return np.copy(current), c, p, eval_times, trace
        else:
            available[select_node] = -1
            if (available == stopping_condition).all():
                # Confirmed bug fix: after changing to the fallback solution,
                # re-evaluate that exact solution instead of carrying stale p.
                fallback = Solution_Initialization(node_resort_w, param, -1)
                fallback_p = Solution_Evaluation(
                    Eval_func,
                    fallback,
                    T_max,
                    fi,
                    threshold_p,
                    param,
                    MC_sample_size,
                    quick_check_list,
                )
                eval_times += 1
                fallback_c = solution_cost(fallback, fi)
                trace.append([fallback_c, fallback_p, np.copy(fallback), eval_times])
                if fallback_p >= threshold_p:
                    return np.copy(fallback), fallback_c, fallback_p, eval_times, trace

                # Minimal DDTS-v1 initialization repair: only when both the CP
                # path and its fallback are infeasible, inspect one layer of
                # same-class 1-swap neighbors around the fallback.  The DDTS
                # main search remains unchanged.
                repaired_solution, repaired_cost, repaired_p, eval_times, trace = _one_swap_feasibility_repair(
                    Eval_func,
                    fallback,
                    node_resort_w,
                    fi,
                    threshold_p,
                    T_max,
                    param,
                    MC_sample_size,
                    quick_check_list,
                    eval_times,
                    trace,
                    verbose=verbose,
                )
                if repaired_solution is not None:
                    return (
                        np.copy(repaired_solution),
                        float(repaired_cost),
                        float(repaired_p),
                        int(eval_times),
                        trace,
                    )

                raise NoFeasibleInitialSolution(
                    "Constructive Procedure and one-swap feasibility repair could not obtain "
                    "a probability-feasible initial solution."
                )
