"""Fixed-budget defensive importance sampling with empirical conditioning.

M is the number of Monte Carlo scenarios, unchanged from the plain evaluator.
For each scenario one empirical class is integrated exactly. The remaining
classes use a deterministic equal allocation between their original joint law
and an exponentially tilted product law. Balance-heuristic likelihood weights
restore the original probability and are bounded by two for even M.
"""
from dataclasses import dataclass
import math
import numpy as np

from src.functions.func_delta_mc import DeltaMonteCarloContext, DeltaMCEvaluation


@dataclass(frozen=True)
class ImportanceCMCPlan:
    theta: float
    conditional_class: int
    reference_solution: tuple

    @classmethod
    def from_reference(cls, solution, factors, tmax):
        values = [np.sort(np.asarray(factors[int(fid)].samples, dtype=float)) for fid in solution]
        if not values or any(not len(v) or not np.all(np.isfinite(v)) for v in values):
            raise ValueError("importance CMC requires finite nonempty empirical samples")
        conditional = max(range(len(values)), key=lambda i: (float(np.var(values[i])), -i))
        def mean(theta):
            total = 0.0
            for v in values:
                weights = np.exp(theta * (v - v[-1]))
                total += float(np.dot(weights, v) / np.sum(weights))
            return total
        theta = 0.0
        if mean(0.0) < float(tmax) < sum(float(v[-1]) for v in values):
            lo, hi = 0.0, 1.0
            while mean(hi) < float(tmax):
                hi *= 2.0
                if not math.isfinite(hi):
                    raise ValueError("could not construct finite exponential tilt")
            # A numerical root solve, not an instance-specific search parameter.
            for _ in range(64):
                mid = (lo + hi) * 0.5
                if mean(mid) < float(tmax):
                    lo = mid
                else:
                    hi = mid
            theta = (lo + hi) * 0.5
        return cls(float(theta), int(conditional), tuple(int(fid) for fid in solution))


class FixedBudgetImportanceCMCSampler:
    """Freeze one proposal from the first pilot-screened assignment per run.

    Proposal construction does not inspect authoritative MC outcomes. All
    initialization, DDTS and PR contexts in this run reuse the identical plan.
    """
    def __init__(self, plan=None):
        self.plan = plan
        self.factor_cache = {}

    def __call__(self, solution, factor_id2obj, class_count, sample_size,
                 confidence_level, tmax, base_seed, chunk_size=50_000, should_stop=None):
        if self.plan is None:
            self.plan = ImportanceCMCPlan.from_reference(solution, factor_id2obj, tmax)
        return ImportanceConditionalMonteCarloContext(
            solution, factor_id2obj, class_count, sample_size, confidence_level,
            tmax, base_seed, chunk_size, should_stop, self.plan, self.factor_cache)

    def metadata(self):
        return {"method": "defensive_importance_conditional_mc",
                "theta": None if self.plan is None else self.plan.theta,
                "conditional_class": None if self.plan is None else self.plan.conditional_class,
                "reference_solution": None if self.plan is None else list(self.plan.reference_solution),
                "proposal_frozen_before_authoritative_evaluation": True,
                "allocation": "equal_original_and_tilted_scenarios"}


class ImportanceConditionalMonteCarloContext(DeltaMonteCarloContext):
    def __init__(self, solution, factors, class_count, sample_size, confidence,
                 tmax, seed, chunk_size, should_stop, plan, factor_cache):
        self.plan = plan
        self.factor_cache = factor_cache
        self.nominal_count = (int(sample_size) + 1) // 2
        self.alpha = self.nominal_count / float(sample_size)
        self.max_weighted_violations = float(sample_size) * (1.0 - float(confidence))
        super().__init__(solution, factors, class_count, sample_size, confidence,
                         tmax, seed, chunk_size, should_stop)

    def _factor_info(self, fid):
        fid = int(fid)
        info = self.factor_cache.get(fid)
        if info is None:
            values = np.sort(np.asarray(self.factor_id2obj[fid].samples, dtype=float))
            if not len(values) or not np.all(np.isfinite(values)):
                raise ValueError("importance CMC requires finite nonempty empirical samples")
            x = self.plan.theta * values
            maximum = float(x[-1])
            weights = np.exp(x - maximum)
            normalizer = float(np.sum(weights))
            log_mgf = maximum + math.log(normalizer / len(values))
            cdf = np.cumsum(weights / normalizer)
            cdf[-1] = 1.0
            info = (values, cdf, log_mgf)
            self.factor_cache[fid] = info
        return info

    def _sampled_values(self, fid, uniform, start):
        values, cdf, _ = self._factor_info(fid)
        nominal = max(0, min(len(uniform), self.nominal_count - start))
        sampled = np.empty(len(uniform), dtype=float)
        if nominal:
            ids = np.minimum((uniform[:nominal] * len(values)).astype(np.int64), len(values)-1)
            sampled[:nominal] = values[ids]
        if nominal < len(uniform):
            ids = np.searchsorted(cdf, uniform[nominal:], side="right")
            sampled[nominal:] = values[ids]
        return sampled

    def _build_current_sums(self, should_stop=None):
        self.current_sums.fill(0.0)
        for cid in range(self.class_count):
            if cid == self.plan.conditional_class:
                continue
            rng = self._rng_for_class(cid)
            for start, end in self._chunk_ranges():
                if should_stop is not None and should_stop():
                    return False
                self.current_sums[start:end] += self._sampled_values(
                    int(self.current_solution[cid]), rng.random(end-start), start)
        return True

    def _normalized_moves(self, moves):
        norm = tuple(sorted((int(c), int(o), int(n)) for c, o, n in moves))
        if len({c for c, _, _ in norm}) != len(norm):
            raise ValueError("duplicate class in multi-swap")
        for cid, old, new in norm:
            if not 0 <= cid < self.class_count:
                raise ValueError("invalid class in multi-swap")
            if int(self.current_solution[cid]) != old:
                raise ValueError("importance CMC current solution is out of sync")
            self._factor_info(new)
        return norm

    def _candidate_solution(self, norm):
        candidate = self.current_solution.copy()
        for cid, old, new in norm:
            candidate[cid] = new
        return candidate

    def _weighted_failures(self, sums, solution):
        values, _, _ = self._factor_info(int(solution[self.plan.conditional_class]))
        conditional_failures = (len(values) - np.searchsorted(values, self.tmax-sums, side="right")) / float(len(values))
        log_norm = sum(self._factor_info(int(solution[cid]))[2] for cid in range(self.class_count)
                       if cid != self.plan.conditional_class)
        log_ratio = self.plan.theta * sums - log_norm
        if self.alpha == 1.0:
            likelihood = np.ones(len(sums))
        else:
            denominator = np.logaddexp(math.log(self.alpha), math.log1p(-self.alpha)+log_ratio)
            likelihood = np.exp(-denominator)
        return conditional_failures * likelihood

    def evaluate_current(self, should_stop=None):
        return self.evaluate_multi_swap([], should_stop)

    def evaluate_multi_swap(self, moves, should_stop=None):
        if not self.initialized:
            return DeltaMCEvaluation(None, 0, 0.0, False, True, False, False)
        norm = self._normalized_moves(moves)
        candidate = self._candidate_solution(norm)
        rngs = {cid: self._rng_for_class(cid) for cid, _, _ in norm
                if cid != self.plan.conditional_class}
        violations, used = 0.0, 0
        self._last_candidate = None
        for start, end in self._chunk_ranges():
            if should_stop is not None and should_stop():
                return DeltaMCEvaluation(None, used, violations, False, True, False, False)
            chunk = self.current_sums[start:end].copy()
            for cid, old, new in norm:
                if cid == self.plan.conditional_class:
                    continue
                uniform = rngs[cid].random(end-start)
                chunk += self._sampled_values(new, uniform, start) - self._sampled_values(old, uniform, start)
            self.work_sums[start:end] = chunk
            violations += float(np.sum(self._weighted_failures(chunk, candidate), dtype=np.float64))
            used = end
            # Nonnegative summands make this rejection exact for the full-M
            # weighted experiment. No confidence bound or threshold relaxation.
            if violations > self.max_weighted_violations + self.sample_size*1e-15:
                return DeltaMCEvaluation(0.0, used, violations, True, False, False, False)
        p = 1.0 - violations / self.sample_size
        feasible = p + 1e-15 >= self.confidence_level
        if feasible:
            self._last_candidate = ("multi", norm)
        return DeltaMCEvaluation(p, self.sample_size, violations, False, False, True, feasible)

    def evaluate_1swap(self, class_id, old_factor, new_factor, should_stop=None):
        out = self.evaluate_multi_swap([(class_id, old_factor, new_factor)], should_stop)
        if out.candidate_buffer_ready:
            self._last_candidate = (int(class_id), int(old_factor), int(new_factor))
        return out

    def build_multi_candidate_sums(self, moves, should_stop=None):
        if not self.initialized:
            return None
        norm = self._normalized_moves(moves)
        candidate = self.current_sums.copy()
        for cid, old, new in norm:
            if cid == self.plan.conditional_class:
                continue
            rng = self._rng_for_class(cid)
            for start, end in self._chunk_ranges():
                if should_stop is not None and should_stop():
                    return None
                uniform = rng.random(end-start)
                candidate[start:end] += self._sampled_values(new, uniform, start) - self._sampled_values(old, uniform, start)
        return candidate

    def apply_1swap_without_prior_full_evaluation(self, class_id, old_factor, new_factor, should_stop=None):
        return self.apply_multi_swap_without_prior_full_evaluation(
            [(class_id, old_factor, new_factor)], should_stop)
