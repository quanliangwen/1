"""Budget-matched search-only control using the original author LSS/Degrade.

Shared initialization/preprocessing belong to the common experiment driver.
Only the outer stopping condition is adapted to its common time budget.
No FSS, SFE, tabu restriction, or pilot candidate schedule is added here.
"""
import ast,heapq,random,time
from pathlib import Path
import numpy as np
from random import choice
from src.functions.func_solution_factor_corrected import Solution_Evaluation,solution_cost
from src.functions.func_tabu_search import DDTSResult,_gap_percent

RAW=Path(__file__).with_name('func_lss_degrade_author.py')
NAMES={'Local_Swap_Search','Degrade_','FeasibleSolutionList'}
def load_author_operators(evaluation):
    tree=ast.parse(RAW.read_text())
    tree.body=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in NAMES]
    assert {node.name for node in tree.body}==NAMES
    scope=dict(np=np,random=random,choice=choice,heapq=heapq,
               Solution_Evaluation=evaluation,solution_cost=solution_cost)
    exec(compile(tree,str(RAW),'exec'),scope)
    return scope

class SearchBudgetReached(Exception):pass

def Data_Driven_Tabu_Search(EvaluationFunction,S_cp,node_items,factor_id2obj,ConfidenceLevel,
    T_max,param,MaxIter,MonteCarloTimes,QuickCheckList,tabu_tenure=1,no_improve_limit=20,
    time_limit_seconds=600,evaluation_budget=None,gurobi_optimum=None,progress_callback=None,
    run_seed=0,crn_seed=None,restart_no_improve_cycles=None,mc_context_factory=None,
    perturbation_policy='random',pair_exchange_pilot_samples=10000):
    started=time.perf_counter();current=np.asarray(S_cp[0],dtype=int).copy()
    best=current.copy();best_cost=float(S_cp[1]);best_p=float(S_cp[2]);best_time=0.
    evaluations=int(S_cp[3]);t=0;scans=0;perturbations=0;accepted=0;convergence=[]
    def exhausted():
        return ((time_limit_seconds is not None and time.perf_counter()-started>=time_limit_seconds)
            or (evaluation_budget is not None and evaluations>=evaluation_budget))
    def evaluate(fn,solution,tmax,factors,p0,parameters,M,qc):
        nonlocal best,best_cost,best_p,best_time,evaluations,accepted
        if exhausted():raise SearchBudgetReached()
        p=float(Solution_Evaluation(fn,solution,tmax,factors,p0,parameters,M,qc));evaluations+=1
        cost=solution_cost(solution,factors)
        if p>=p0 and cost<best_cost-1e-12:
            best=np.asarray(solution,dtype=int).copy();best_cost=cost;best_p=p
            best_time=time.perf_counter()-started;accepted+=1
            convergence.append(dict(cycle=t,scan_position=None,class_id=None,total_class_scans=scans,
                total_tabu_moves=accepted,event='author_lss_degrade_new_best',evaluation_count=evaluations,
                current_cost=cost,current_probability=p,best_cost=cost,best_probability=p))
        return p
    operators=load_author_operators(evaluate)
    tem=[];record=np.ones(2+int(param[0]));cost_queue=[];p_queue=[];p=best_p
    try:
        while not exhausted():
            scans+=len(node_items)
            _,p,current,_=operators['Local_Swap_Search'](EvaluationFunction,current,p,node_items,
                factor_id2obj,ConfidenceLevel,T_max,param,MonteCarloTimes,QuickCheckList,
                evaluations,tem,record,cost_queue,p_queue)
            _,p,current,_=operators['Degrade_'](EvaluationFunction,current,p,node_items,
                factor_id2obj,ConfidenceLevel,T_max,param,MonteCarloTimes,[],list(current),QuickCheckList,record)
            perturbations+=1;t+=1
    except SearchBudgetReached:pass
    return DDTSResult(solution=best.tolist(),cost=best_cost,probability=best_p,search_probability=best_p,
        certified_feasible=best_p>=ConfidenceLevel,iterations=t,completed_cycles=t,total_class_scans=scans,
        total_tabu_moves=accepted,perturbation_count=perturbations,no_improve_limit=no_improve_limit,
        evaluation_count=evaluations,amc_quickcheck_prefilter_skip_count=0,delta_mc_enabled=False,
        delta_mc_evaluation_count=0,delta_mc_early_reject_count=0,delta_mc_full_evaluation_count=0,
        delta_mc_samples_used=0,delta_mc_initialization_seconds=0.,stop_reason='time_limit',
        runtime_seconds=time.perf_counter()-started,heuristic_gap_percent=_gap_percent(best_cost,gurobi_optimum),
        search_mode='author_lss_degrade_common_initialization_time_budget',convergence_log=convergence,
        tabu_move_log=[],perturbation_log=[],best_found_time_seconds=best_time)
