"""Reference evaluation protocol copied from the user-supplied author archive.

The author's estimator module is kept byte-for-byte in func_reference_author.
Adapters retain the original random resampling range even when the optimizer
uses cached factor statistics. Every MC evaluation consumes fresh global RNG
draws. No CRN, importance weighting, CMC, or probability cache is used.
"""
import numpy as np
import multiprocessing as mp
import time
from src.functions import func_reference_author as author

class ReferenceFactorView:
    def __init__(self, factor):
        self.factor=factor
        self.samples=factor.samples
        self.samples_used=0

    def get_index_sample(self,index):
        return self.factor.get_index_sample(index)

    def resample_multi(self,sample_number):
        self.samples_used=int(sample_number)
        indices=np.random.randint(0,len(self.samples)-1,sample_number)
        return self.samples[indices]

def reference_advanced_monte_carlo(factor_list,T_max,MC_sample_size,CL,param,quick_check_list):
    views=[ReferenceFactorView(f) for f in factor_list]
    p=author.advanced_monte_carlo(views,T_max,MC_sample_size,CL,param,quick_check_list)
    reference_advanced_monte_carlo.last_samples_used=views[0].samples_used if views else 0
    return p

def reference_advanced_exact_evaluation(factor_list,T_max,MC_sample_size,CL,param,quick_check_list):
    views=[ReferenceFactorView(f) for f in factor_list]
    return author.advanced_exact_evaluation(views,T_max,MC_sample_size,CL,param,quick_check_list)

reference_advanced_monte_carlo.reference_protocol=True
reference_advanced_monte_carlo.reference_mc=True
reference_advanced_monte_carlo.last_samples_used=0
reference_advanced_exact_evaluation.reference_protocol=True
reference_advanced_exact_evaluation.reference_mc=False
def _build_quickcheck(queue,L,m,P0,list_size,K):
    try:
        queue.put(('ok',author.factorization_list(L,m,P0,list_size,K)))
    except Exception as error:
        queue.put(('error',repr(error)))

def factorization_list(L,m,P0,list_size,K,deadline_monotonic=None):
    if deadline_monotonic is None:
        return author.factorization_list(L,m,P0,list_size,K)
    context=mp.get_context('fork')
    queue=context.Queue()
    process=context.Process(target=_build_quickcheck,args=(queue,L,m,P0,list_size,K))
    process.start()
    try:
        timeout=max(0.0,deadline_monotonic-time.monotonic())
        try:
            state,value=queue.get(timeout=timeout)
        except Exception as error:
            raise TimeoutError('author QuickCheck generation exceeded existing time allowance') from error
        if state!='ok':raise RuntimeError(value)
        return value
    finally:
        if process.is_alive():process.terminate()
        process.join()
        queue.close()
