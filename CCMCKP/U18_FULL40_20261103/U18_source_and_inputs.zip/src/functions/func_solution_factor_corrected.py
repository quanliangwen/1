"""Corrected solution/factor helpers shared by DDALS_fixed and DDTS."""

import numpy as np

from src.utils import my_file
from src.utils.factor_corrected import Factor


def Statistic_factor(param, _lambda, data_folder):
    node_num, factor_num = int(param[0]), int(param[1])
    factor_num_sum = node_num * factor_num
    node_id_list = list(range(node_num))
    factor_id_list = list(range(factor_num_sum))

    node_to_factor_id = my_file.load_pkl_in_repo(data_folder, "node_to_factor.pkl")
    cost_list = np.loadtxt(my_file.real_path_of(data_folder, "cost.txt"))
    max_cost = np.max(cost_list)

    factor_id2obj = []
    for factor_id in factor_id_list:
        sample_path = my_file.real_path_of(data_folder, f"{factor_id}_sample.txt")
        big_sample_path = my_file.real_path_of(data_folder, f"{factor_id}_big_sample.txt")
        cost = float(cost_list[factor_id])
        value = float(max_cost - cost)
        factor_id2obj.append(Factor(factor_id, cost, value, sample_path, big_sample_path))

    node_to_factors = {node_id: [] for node_id in node_id_list}
    for node_id in node_id_list:
        for factor_id in node_to_factor_id[node_id]:
            node_to_factors[node_id].append(factor_id2obj[factor_id])

    node_resort_utility = {node_id: [] for node_id in node_id_list}
    node_resort_weight = {node_id: [] for node_id in node_id_list}
    node_resort_value = {node_id: [] for node_id in node_id_list}

    for node_id in node_id_list:
        cur_factors = node_to_factors[node_id]
        means = [f.sample_mean for f in cur_factors]
        stds = [f.sample_std * _lambda for f in cur_factors]
        values = [f.value for f in cur_factors]
        weights = [means[i] + stds[i] for i in range(len(cur_factors))]
        utilities = [values[i] / weights[i] if weights[i] != 0 else float("inf") for i in range(len(cur_factors))]

        for i, f in enumerate(cur_factors):
            f.set_weight(weights[i])
            f.set_utility(utilities[i])

        for idx in np.argsort(weights)[::-1]:
            node_resort_weight[node_id].append(cur_factors[idx].id)
        for idx in np.argsort(utilities)[::-1]:
            node_resort_utility[node_id].append(cur_factors[idx].id)
        for idx in np.argsort(values)[::-1]:
            node_resort_value[node_id].append(cur_factors[idx].id)

    return node_resort_weight, node_resort_utility, node_resort_value, factor_id2obj


def Solution_Initialization(node_resort, param, order):
    node_num = int(param[0])
    init_solution = np.zeros(node_num, dtype=int)
    for node_id in range(node_num):
        init_solution[node_id] = node_resort[node_id][order]
    return init_solution


def Solution_Evaluation(eval_func, Solution, T_max, factor_id2obj, CL, param, MC_sample_size, quick_check_list):
    factor_list = [factor_id2obj[int(factor_id)] for factor_id in Solution]
    return float(eval_func(factor_list, T_max, MC_sample_size, CL, param, quick_check_list))


def solution_cost(solution, factor_id2obj):
    return float(sum(factor_id2obj[int(factor_id)].cost for factor_id in solution))
