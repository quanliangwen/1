"""LSS-style Data-Driven Tabu Search for CCMCKP.

This revision intentionally makes the tabu-search structure as close as possible
to the DDALS Local Swap Search (LSS) loop while retaining short-term tabu
memory and the current corrected data-driven probability evaluator.

Search structure
----------------
    empirical stochastic-dominance preprocessing (performed before CP)
      -> CP
      -> repeat until the per-run time limit is reached (default 600 s):
           1. visit every retained class candidate set exactly once in random order;
           2. for the current class, consider only cost-improving 1-swap moves;
           3. among admissible moves, choose the lowest-cost probability-feasible
              replacement (best improvement for this class);
           4. move immediately to the next class, whether or not a replacement
              was accepted;
           5. after all classes have been scanned, perform one random feasible
              one-class perturbation, analogous to DDALS Degrade.
      -> return the best solution found within the time budget.

Important semantics
-------------------
* One outer iteration = one complete scan of all classes + one random
  perturbation.
* The number of outer iterations is no longer a stopping condition. Search
  continues until the per-run time limit is reached (default 600 s at CLI).
* Each class can accept at most one tabu-search replacement in one outer
  iteration.
* Only improving class moves are accepted during the class scan.  A random
  perturbation is allowed to worsen the current objective, providing the escape
  mechanism just as Degrade does in DDALS.
* Tabu memory stores reverse assignments ``(class, removed item)``.  Because a
  class is visited only once per outer iteration, tabu tenure is measured in
  OUTER ITERATIONS in this LSS-style version.  With ``tabu_tenure=1``, a removed
  item cannot normally be re-selected when that class is visited in the next
  outer iteration.  Aspiration allows a tabu assignment only if it improves the
  global best objective.
* The old ``no_improve_limit`` argument is accepted only for command-line/backward
  compatibility.  It is NOT used by this classwise scan mode.
* AMC QuickCheck front filtering is retained. A 1-swap candidate is screened
  by an incremental QuickCheck delta before Monte Carlo is called.
* Large-instance 1-swap probability evaluation uses Delta Monte Carlo with
  common random numbers. Candidate sums are updated from the current sampled
  total in O(M), and infeasible candidates stop exactly when the cumulative
  number of violations exceeds the fixed-M admissible limit.
* Empirical stochastic-dominance preprocessing is applied outside this routine
  before CP and DDTS, so dominated within-class items never enter the search.

No 2-swap neighborhood, reactive tenure, penalty search, or statistical
confidence-interval approximation is introduced.
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from src.functions.func_solution_factor_corrected import Solution_Evaluation, solution_cost
from src.functions.func_delta_mc import DeltaMonteCarloContext
from src.functions.func_pair_exchange import rank_nonworsening_two_class_exchanges


@dataclass
class DDTSResult:
    solution: List[int]
    cost: float
    probability: float
    search_probability: float
    certified_feasible: bool
    iterations: int
    completed_cycles: int
    total_class_scans: int
    total_tabu_moves: int
    perturbation_count: int
    no_improve_limit: int
    evaluation_count: int
    amc_quickcheck_prefilter_skip_count: int
    delta_mc_enabled: bool
    delta_mc_evaluation_count: int
    delta_mc_early_reject_count: int
    delta_mc_full_evaluation_count: int
    delta_mc_samples_used: int
    delta_mc_initialization_seconds: float
    stop_reason: str
    runtime_seconds: float
    heuristic_gap_percent: Optional[float]
    search_mode: str
    convergence_log: List[dict]
    tabu_move_log: List[dict]
    perturbation_log: List[dict]
    best_found_time_seconds: float
    pair_exchange_count: int = 0
    pair_exchange_evaluation_count: int = 0
    pair_exchange_proposal_count: int = 0

    def to_dict(self):
        return asdict(self)


def validate_multiple_choice_solution(
    solution: Sequence[int],
    node_items: Dict[int, Sequence[int]],
) -> Tuple[bool, str]:
    if len(solution) != len(node_items):
        return False, f"solution length {len(solution)} != class count {len(node_items)}"
    for i, factor_id in enumerate(solution):
        if int(factor_id) not in set(int(v) for v in node_items[i]):
            return False, f"factor {factor_id} does not belong to class {i}"
    return True, "ok"


def _gap_percent(heuristic_cost: float, gurobi_optimum: Optional[float]) -> Optional[float]:
    if gurobi_optimum is None:
        return None
    gurobi_optimum = float(gurobi_optimum)
    if abs(gurobi_optimum) < 1e-15:
        return None
    gap = (float(heuristic_cost) - gurobi_optimum) / gurobi_optimum * 100.0
    return 0.0 if abs(gap) < 1e-10 else gap


def Data_Driven_Tabu_Search(
    EvaluationFunction,
    S_cp,
    node_items,
    factor_id2obj,
    ConfidenceLevel,
    T_max,
    param,
    MaxIter,
    MonteCarloTimes,
    QuickCheckList,
    tabu_tenure: int = 1,
    no_improve_limit: int = 20,
    time_limit_seconds: Optional[float] = 600.0,
    evaluation_budget: Optional[int] = None,
    gurobi_optimum: Optional[float] = None,
    progress_callback=None,
    run_seed: int = 0,
    crn_seed: Optional[int] = None,
    restart_no_improve_cycles: Optional[int] = None,
    mc_context_factory=None,
    perturbation_policy="random",
    pair_exchange_pilot_samples=10000,
    perturbation_learner=None,
):
    """Run time-limited LSS-style classwise DDTS.

    ``MaxIter`` is retained only for API compatibility and is not a stopping
    condition. Each completed iteration scans every class exactly once and then
    performs one random feasible one-class perturbation. ``no_improve_limit`` is
    also retained only for backward compatibility.
    """
    if int(tabu_tenure) < 1:
        raise ValueError("tabu_tenure must be >= 1")
    if time_limit_seconds is None or float(time_limit_seconds) < 0:
        raise ValueError("time_limit_seconds must be nonnegative")

    start = time.perf_counter()
    rl_best_events=[]
    tol = 1e-12
    tabu_tenure = int(tabu_tenure)
    no_improve_limit = int(no_improve_limit)
    search_mode = "time_limited_lss_style_classwise_best_improvement_delta_mc"
    if restart_no_improve_cycles is not None and int(restart_no_improve_cycles) <= 0:
        restart_no_improve_cycles = None
    elif restart_no_improve_cycles is not None:
        restart_no_improve_cycles = int(restart_no_improve_cycles)

    def progress(message: str):
        if progress_callback is not None:
            progress_callback(str(message))

    current = np.asarray(S_cp[0], dtype=int).copy()
    current_cost = float(S_cp[1])
    current_p = float(S_cp[2])
    eval_count = int(S_cp[3])

    valid, reason = validate_multiple_choice_solution(current, node_items)
    if not valid:
        raise ValueError(f"Invalid CP solution: {reason}")
    recomputed_cost = solution_cost(current, factor_id2obj)
    if abs(recomputed_cost - current_cost) > 1e-9:
        raise ValueError("CP objective is inconsistent with the selected items")
    if current_p + tol < ConfidenceLevel:
        raise ValueError("DDTS requires a probability-feasible initial solution")

    best = current.copy()
    best_cost = current_cost
    best_p = current_p
    best_found_time_seconds = 0.0

    current_min_sum = float(sum(factor_id2obj[int(fid)].sample_min for fid in current))
    current_max_sum = float(sum(factor_id2obj[int(fid)].sample_max for fid in current))

    # ------------------------------------------------------------------
    # AMC QuickCheck front filter.
    # ------------------------------------------------------------------
    evaluator_name = getattr(EvaluationFunction, "__name__", "")
    amc_quickcheck_prefilter_enabled = evaluator_name == "advanced_monte_carlo"
    amc_quickcheck_prefilter_skip_count = 0
    amc_screen_rows: Tuple[Tuple[int, ...], ...] = tuple()
    amc_screen_contrib: Dict[Tuple[int, int], np.ndarray] = {}

    if amc_quickcheck_prefilter_enabled:
        L, m = int(param[2]), int(param[0])
        _prob = 1.0 - float(ConfidenceLevel)
        data_l = math.ceil(round(L ** m * _prob) ** (1.0 / m))
        data_l = max(0, min(L - 1, int(data_l)))

        rows = [tuple([data_l] * m)]
        for row in QuickCheckList:
            if len(row) != m:
                continue
            rows.append(tuple(int(v) for v in row))
        amc_screen_rows = tuple(rows)

        for class_id in range(m):
            for factor_id in node_items[class_id]:
                fid = int(factor_id)
                obj = factor_id2obj[fid]
                amc_screen_contrib[(class_id, fid)] = np.asarray(
                    [obj.get_index_sample(row[class_id]) for row in amc_screen_rows],
                    dtype=float,
                )

    def amc_screen_sums(solution):
        if not amc_quickcheck_prefilter_enabled:
            return None
        sums = np.zeros(len(amc_screen_rows), dtype=float)
        for class_id in range(int(param[0])):
            fid = int(solution[class_id])
            sums += amc_screen_contrib[(class_id, fid)]
        return sums

    def amc_quickcheck_reject_1swap(base_sums, class_id, old_factor, new_factor):
        if base_sums is None:
            return False
        candidate_sums = (
            base_sums
            - amc_screen_contrib[(int(class_id), int(old_factor))]
            + amc_screen_contrib[(int(class_id), int(new_factor))]
        )
        return bool(np.any(candidate_sums > float(T_max)))

    progress(
        f"initialize current_cost={current_cost:.12g} p={current_p:.8f} "
        f"time_limit={float(time_limit_seconds):.3f}s tabu_tenure={tabu_tenure} "
        f"mode={search_mode} amc_qc_prefilter={amc_quickcheck_prefilter_enabled}"
    )

    # Tabu expiry is measured in OUTER ITERATIONS in this classwise mode.
    tabu_until_iteration: Dict[Tuple[int, int], int] = {}
    # Reactive tabu: grow effective tenure after an exact repeated assignment;
    # relax it after tenure-length cycle-free intervals. CLI tenure is unchanged base.
    visited_configuration_cycle = {tuple(int(v) for v in current): 0}
    effective_tabu_tenure = int(tabu_tenure)
    cycle_free_iterations = 0

    convergence_log = [
        {
            "cycle": 0,
            "scan_position": 0,
            "class_id": None,
            "total_class_scans": 0,
            "total_tabu_moves": 0,
            "event": "cp_initial",
            "evaluation_count": int(eval_count),
            "current_cost": current_cost,
            "current_probability": current_p,
            "best_cost": best_cost,
            "best_probability": best_p,
        }
    ]
    tabu_move_log: List[dict] = []
    perturbation_log: List[dict] = []

    completed_cycles = 0
    total_class_scans = 0
    total_tabu_moves = 0
    perturbation_count = 0
    pair_exchange_count = pair_exchange_evaluation_count = pair_exchange_proposal_count = 0
    stop_reason = "time_limit"
    hard_stop = False

    def time_exhausted():
        return (
            time_limit_seconds is not None
            and time.perf_counter() - start >= float(time_limit_seconds)
        )

    def budget_exhausted():
        return evaluation_budget is not None and eval_count >= int(evaluation_budget)

    # Delta Monte Carlo is used only for the large-instance AMC branch.  It
    # maintains one fixed-M CRN sample-total vector for the current solution.
    delta_mc_enabled = bool(amc_quickcheck_prefilter_enabled)
    delta_mc_evaluation_count = 0
    delta_mc_early_reject_count = 0
    delta_mc_full_evaluation_count = 0
    delta_mc_samples_used = 0
    delta_mc_initialization_seconds = 0.0
    delta_mc = None
    if delta_mc_enabled and not time_exhausted():
        delta_start = time.perf_counter()
        delta_mc = (DeltaMonteCarloContext if mc_context_factory is None else mc_context_factory)(
            current,
            factor_id2obj,
            int(param[0]),
            int(MonteCarloTimes),
            float(ConfidenceLevel),
            float(T_max),
            int(run_seed if crn_seed is None else crn_seed),
            should_stop=time_exhausted,
        )
        delta_mc_initialization_seconds = time.perf_counter() - delta_start
        if not delta_mc.initialized:
            stop_reason = "time_limit"
            hard_stop = True
        progress(
            f"delta_mc init enabled={delta_mc_enabled} initialized={getattr(delta_mc, 'initialized', False)} "
            f"M={int(MonteCarloTimes)} elapsed={delta_mc_initialization_seconds:.3f}s"
        )

    def build_candidate(solution, class_id, new_factor):
        candidate = np.asarray(solution, dtype=int).copy()
        candidate[int(class_id)] = int(new_factor)
        return candidate

    def evaluate_probability_from_bounds(
        candidate,
        candidate_min_sum,
        candidate_max_sum,
        class_id=None,
        old_factor=None,
        new_factor=None,
    ):
        """Evaluate one candidate after deterministic min/max screening.

        Large-instance AMC candidates use Delta Monte Carlo after the existing
        deterministic and QuickCheck screens. Small exact instances retain the
        corrected exact evaluator.
        """
        nonlocal eval_count, stop_reason
        nonlocal delta_mc_evaluation_count, delta_mc_early_reject_count
        nonlocal delta_mc_full_evaluation_count, delta_mc_samples_used

        if time_exhausted():
            stop_reason = "time_limit"
            return None, True, "stopped"
        if budget_exhausted():
            stop_reason = "evaluation_budget"
            return None, True, "stopped"

        if getattr(EvaluationFunction, "reference_protocol", False):
            p = Solution_Evaluation(EvaluationFunction, candidate, T_max, factor_id2obj,
                                    ConfidenceLevel, param, MonteCarloTimes, QuickCheckList)
            eval_count += 1
            return float(p), False, "author_reference_evaluation"

        if float(candidate_min_sum) > float(T_max):
            return 0.0, False, "min_bound"
        if float(candidate_max_sum) <= float(T_max):
            return 1.0, False, "max_bound"

        if delta_mc_enabled:
            if delta_mc is None or not delta_mc.initialized:
                stop_reason = "time_limit"
                return None, True, "stopped"
            if class_id is None or old_factor is None or new_factor is None:
                raise ValueError("Delta MC requires 1-swap metadata")
            out = delta_mc.evaluate_1swap(
                int(class_id),
                int(old_factor),
                int(new_factor),
                should_stop=time_exhausted,
            )
            if out.stopped:
                stop_reason = "time_limit"
                return None, True, "stopped"
            eval_count += 1
            delta_mc_evaluation_count += 1
            delta_mc_samples_used += int(out.samples_used)
            if out.early_rejected:
                delta_mc_early_reject_count += 1
            if out.completed_full_sample:
                delta_mc_full_evaluation_count += 1
            return float(out.probability), False, (
                "delta_mc_early_reject" if out.early_rejected else "delta_mc_full"
            )

        candidate_p = Solution_Evaluation(
            EvaluationFunction,
            candidate,
            T_max,
            factor_id2obj,
            ConfidenceLevel,
            param,
            MonteCarloTimes,
            QuickCheckList,
        )
        eval_count += 1
        return float(candidate_p), False, "original_evaluator"

    def sync_delta_after_accepted_move(class_id, old_factor, new_factor, eval_source):
        """Keep the Delta-MC current sample-total vector synchronized."""
        nonlocal stop_reason
        if not delta_mc_enabled:
            return False
        if eval_source == "delta_mc_full":
            committed = delta_mc.commit_last_candidate(class_id, old_factor, new_factor)
            if not committed:
                raise RuntimeError("Delta MC feasible-candidate buffer was not available for commit")
            return False

        # Bound-certified moves did not build a full candidate buffer. Update the
        # maintained current totals once using the same class CRN stream.
        ok = delta_mc.apply_1swap_without_prior_full_evaluation(
            class_id, old_factor, new_factor, should_stop=time_exhausted
        )
        if not ok:
            stop_reason = "time_limit"
            return True
        return False

    def front_quickcheck_reject(move):
        """Apply the moved-forward AMC QuickCheck without changing eval-count semantics."""
        nonlocal eval_count, stop_reason, amc_quickcheck_prefilter_skip_count
        if not move.get("amc_quickcheck_reject", False):
            return False, False

        if time_exhausted():
            stop_reason = "time_limit"
            return False, True
        if budget_exhausted():
            stop_reason = "evaluation_budget"
            return False, True
        if float(move["candidate_min_sum"]) > float(T_max):
            return False, False
        if float(move["candidate_max_sum"]) <= float(T_max):
            return False, False

        # This candidate would have entered advanced_monte_carlo and been
        # rejected by exactly the same QuickCheck in the previous code.
        eval_count += 1
        amc_quickcheck_prefilter_skip_count += 1
        return True, False

    def make_class_move_metadata(
        solution,
        solution_cost_value,
        min_sum_value,
        max_sum_value,
        cycle_id,
        class_id,
    ):
        """Build improving 1-swap candidates for one class only."""
        old_factor = int(solution[class_id])
        old_obj = factor_id2obj[old_factor]
        base_amc_screen_sums = amc_screen_sums(solution)
        moves = []

        for new_factor in node_items[class_id]:
            new_factor = int(new_factor)
            if new_factor == old_factor:
                continue
            new_obj = factor_id2obj[new_factor]
            candidate_cost = float(solution_cost_value - old_obj.cost + new_obj.cost)

            # LSS-style scan: only objective-improving replacements are searched.
            if candidate_cost >= float(solution_cost_value) - tol:
                continue

            expiry = int(tabu_until_iteration.get((int(class_id), new_factor), 0))
            is_tabu = int(cycle_id) <= expiry
            aspiration = bool(is_tabu and candidate_cost < best_cost - tol)
            candidate_min_sum = float(min_sum_value - old_obj.sample_min + new_obj.sample_min)
            candidate_max_sum = float(max_sum_value - old_obj.sample_max + new_obj.sample_max)
            amc_qc_reject = amc_quickcheck_reject_1swap(
                base_amc_screen_sums,
                class_id,
                old_factor,
                new_factor,
            )
            moves.append(
                {
                    "cycle": int(cycle_id),
                    "class_id": int(class_id),
                    "old_factor": int(old_factor),
                    "new_factor": int(new_factor),
                    "cost": candidate_cost,
                    "candidate_min_sum": candidate_min_sum,
                    "candidate_max_sum": candidate_max_sum,
                    "amc_quickcheck_reject": bool(amc_qc_reject),
                    "tabu_expiry_iteration": expiry,
                    "was_tabu": bool(is_tabu),
                    "aspiration": aspiration,
                }
            )
        return moves

    def select_best_class_improvement(class_moves, solution):
        """Choose the lowest-cost admissible feasible improving move in one class."""
        # Tabu assignments are excluded unless aspiration-by-objective applies.
        candidates = [
            move for move in class_moves
            if (not move["was_tabu"]) or move["aspiration"]
        ]
        candidates.sort(key=lambda x: (x["cost"], x["new_factor"]))

        # Because candidates are sorted by cost, the first feasible candidate
        # is the best feasible improvement for this class.
        for move in candidates:
            qc_reject, limit_hit = front_quickcheck_reject(move)
            if limit_hit:
                return None, True
            if qc_reject:
                continue

            candidate = build_candidate(solution, move["class_id"], move["new_factor"])
            p, limit_hit, eval_source = evaluate_probability_from_bounds(
                candidate,
                move["candidate_min_sum"],
                move["candidate_max_sum"],
                move["class_id"],
                move["old_factor"],
                move["new_factor"],
            )
            if limit_hit:
                return None, True
            if p + tol < ConfidenceLevel:
                continue

            chosen = dict(move)
            chosen["candidate"] = candidate
            chosen["probability"] = float(p)
            chosen["evaluation_source"] = eval_source
            return chosen, False

        return None, False

    def random_perturbation(
        cycle_id,
        solution,
        solution_cost_value,
        solution_p,
        min_sum_value,
        max_sum_value,
    ):
        """DDALS-Degrade-like random feasible one-class perturbation.

        Class order is random and alternative-item order inside each selected
        class is random.  The first probability-feasible replacement is
        accepted.  If no feasible replacement exists in any class, the input
        solution is returned unchanged by the caller and the next outer
        iteration is still allowed to proceed, matching the no-op fallback of
        the original Degrade routine.
        """
        class_order = np.random.permutation(int(param[0])).tolist()

        for class_id in class_order:
            old_factor = int(solution[class_id])
            old_obj = factor_id2obj[old_factor]
            alternatives = [
                int(fid) for fid in node_items[class_id]
                if int(fid) != old_factor
            ]
            if not alternatives:
                continue
            alternatives = np.random.permutation(alternatives).tolist()
            if perturbation_policy in ("nearby", "nearby_pair"):
                # Preserve randomized tie order but try the least disruptive cost
                # change first. This changes proposal order, never the evaluator.
                alternatives.sort(key=lambda fid: abs(float(factor_id2obj[fid].cost)-float(old_obj.cost)))
            elif perturbation_policy != "random":
                raise ValueError("unknown perturbation policy: " + str(perturbation_policy))
            base_amc_screen_sums = amc_screen_sums(solution)

            for new_factor in alternatives:
                new_obj = factor_id2obj[int(new_factor)]
                candidate_cost = float(solution_cost_value - old_obj.cost + new_obj.cost)
                candidate_min_sum = float(min_sum_value - old_obj.sample_min + new_obj.sample_min)
                candidate_max_sum = float(max_sum_value - old_obj.sample_max + new_obj.sample_max)
                amc_qc_reject = amc_quickcheck_reject_1swap(
                    base_amc_screen_sums,
                    class_id,
                    old_factor,
                    new_factor,
                )
                move = {
                    "candidate_min_sum": candidate_min_sum,
                    "candidate_max_sum": candidate_max_sum,
                    "amc_quickcheck_reject": bool(amc_qc_reject),
                }
                qc_reject, limit_hit = front_quickcheck_reject(move)
                if limit_hit:
                    return None, True
                if qc_reject:
                    continue

                candidate = build_candidate(solution, class_id, new_factor)
                candidate_p, limit_hit, eval_source = evaluate_probability_from_bounds(
                    candidate,
                    candidate_min_sum,
                    candidate_max_sum,
                    class_id,
                    old_factor,
                    new_factor,
                )
                if limit_hit:
                    return None, True
                if candidate_p + tol < ConfidenceLevel:
                    continue

                return {
                    "cycle": int(cycle_id),
                    "class_id": int(class_id),
                    "old_factor": int(old_factor),
                    "new_factor": int(new_factor),
                    "candidate": candidate,
                    "cost": candidate_cost,
                    "probability": float(candidate_p),
                    "candidate_min_sum": candidate_min_sum,
                    "candidate_max_sum": candidate_max_sum,
                    "evaluation_source": eval_source,
                }, False

        return None, False

    # ==================================================================
    # OUTER SEARCH: each iteration = full class scan + random perturbation.
    # There is no outer-iteration cap; the time limit is the stopping rule.
    # ==================================================================
    cycle = 0
    cycles_without_best_improvement = 0
    while not hard_stop:
        if time_exhausted():
            stop_reason = "time_limit"
            break
        if budget_exhausted():
            stop_reason = "evaluation_budget"
            break

        cycle += 1
        progress(
            f"iteration={cycle} START elapsed={time.perf_counter() - start:.3f}s "
            f"current_cost={current_cost:.12g} best_cost={best_cost:.12g} eval={eval_count}"
        )

        # LSS uses a shuffled class order; keep the same high-level behavior.
        class_order = np.random.permutation(int(param[0])).tolist()
        iteration_moves = 0
        cycle_improved_best = False

        for scan_position, class_id in enumerate(class_order, start=1):
            if time_exhausted():
                stop_reason = "time_limit"
                hard_stop = True
                break
            if budget_exhausted():
                stop_reason = "evaluation_budget"
                hard_stop = True
                break

            total_class_scans += 1
            before_cost = float(current_cost)
            before_p = float(current_p)
            old_factor = int(current[class_id])

            progress(
                f"iteration={cycle} class={class_id} "
                f"scan={scan_position}/{int(param[0])} START "
                f"current_cost={current_cost:.12g} eval={eval_count}"
            )

            class_moves = make_class_move_metadata(
                current,
                current_cost,
                current_min_sum,
                current_max_sum,
                cycle,
                class_id,
            )
            chosen, limit_hit = select_best_class_improvement(class_moves, current)
            if limit_hit:
                hard_stop = True
                break

            if chosen is None:
                convergence_log.append(
                    {
                        "cycle": int(cycle),
                        "scan_position": int(scan_position),
                        "class_id": int(class_id),
                        "total_class_scans": int(total_class_scans),
                        "total_tabu_moves": int(total_tabu_moves),
                        "event": "class_scan_no_improvement",
                        "evaluation_count": int(eval_count),
                        "current_cost": current_cost,
                        "current_probability": current_p,
                        "best_cost": best_cost,
                        "best_probability": best_p,
                    }
                )
                progress(
                    f"iteration={cycle} class={class_id} "
                    f"scan={scan_position}/{int(param[0])} END no_improvement "
                    f"current_cost={current_cost:.12g} eval={eval_count}"
                )
                continue

            new_factor = int(chosen["new_factor"])
            removed_factor = int(chosen["old_factor"])

            current = chosen["candidate"].copy()
            current_cost = float(chosen["cost"])
            current_p = float(chosen["probability"])
            current_min_sum = float(chosen["candidate_min_sum"])
            current_max_sum = float(chosen["candidate_max_sum"])
            if sync_delta_after_accepted_move(
                class_id, removed_factor, new_factor, chosen.get("evaluation_source")
            ):
                hard_stop = True
                break
            total_tabu_moves += 1
            iteration_moves += 1

            # Reverse assignment is tabu for the next ``tabu_tenure`` outer
            # iterations.  tenure=1 => unavailable on this class's next visit.
            tabu_expiry = int(cycle + effective_tabu_tenure)
            tabu_until_iteration[(int(class_id), removed_factor)] = tabu_expiry

            improved_global_best = current_cost < best_cost - tol
            if improved_global_best:
                best = current.copy()
                best_cost = current_cost
                best_p = current_p
                best_found_time_seconds = float(time.perf_counter() - start)
                rl_best_events.append(dict(cost=best_cost, elapsed_seconds=best_found_time_seconds))
                if perturbation_learner is not None:perturbation_learner.observe_global(best_cost)
                cycle_improved_best = True

            tabu_move_log.append(
                {
                    "cycle": int(cycle),
                    "scan_position": int(scan_position),
                    "total_class_scans": int(total_class_scans),
                    "total_tabu_moves": int(total_tabu_moves),
                    "class_id": int(class_id),
                    "old_factor": int(removed_factor),
                    "new_factor": int(new_factor),
                    "old_cost": before_cost,
                    "new_cost": current_cost,
                    "new_probability": current_p,
                    "was_tabu": bool(chosen["was_tabu"]),
                    "aspiration_by_objective": bool(chosen["aspiration"]),
                    "tabu_until_iteration": int(tabu_expiry),
                    "improved_global_best": bool(improved_global_best),
                }
            )
            convergence_log.append(
                {
                    "cycle": int(cycle),
                    "scan_position": int(scan_position),
                    "class_id": int(class_id),
                    "total_class_scans": int(total_class_scans),
                    "total_tabu_moves": int(total_tabu_moves),
                    "event": "class_scan_move",
                    "evaluation_count": int(eval_count),
                    "current_cost": current_cost,
                    "current_probability": current_p,
                    "best_cost": best_cost,
                    "best_probability": best_p,
                }
            )
            progress(
                f"iteration={cycle} class={class_id} "
                f"scan={scan_position}/{int(param[0])} END "
                f"move={removed_factor}->{new_factor} cost={before_cost:.12g}->{current_cost:.12g} "
                f"best={best_cost:.12g} eval={eval_count} "
                f"qc_prefilter_skips={amc_quickcheck_prefilter_skip_count}"
            )

        if hard_stop:
            break

        if (perturbation_policy == "nearby_pair" and not iteration_moves
                and getattr(EvaluationFunction, "reference_mc", False)):
            pairs = rank_nonworsening_two_class_exchanges(
                current, node_items, factor_id2obj, T_max, pair_exchange_pilot_samples,
                int(run_seed)+cycle, time_exhausted)
            pair_exchange_proposal_count += len(pairs)
            for cost_delta, pilot_failures, changes in pairs:
                if time_exhausted():
                    stop_reason = "time_limit"; hard_stop = True; break
                candidate = current.copy()
                for cid, fid in changes:
                    candidate[cid] = fid
                candidate_cost = solution_cost(candidate, factor_id2obj)
                if candidate_cost >= current_cost - tol:
                    continue
                candidate_p = Solution_Evaluation(EvaluationFunction, candidate, T_max,
                    factor_id2obj, ConfidenceLevel, param, MonteCarloTimes, QuickCheckList)
                eval_count += 1
                pair_exchange_evaluation_count += 1
                if candidate_p + tol < ConfidenceLevel:
                    continue
                before_cost = current_cost
                for cid, fid in changes:
                    removed = int(current[cid])
                    tabu_until_iteration[(cid, removed)] = int(cycle+effective_tabu_tenure)
                current = candidate
                current_cost = float(candidate_cost); current_p = float(candidate_p)
                current_min_sum = float(sum(factor_id2obj[int(fid)].sample_min for fid in current))
                current_max_sum = float(sum(factor_id2obj[int(fid)].sample_max for fid in current))
                pair_exchange_count += 1
                improved = current_cost < best_cost - tol
                if improved:
                    best = current.copy(); best_cost = current_cost; best_p = current_p
                    best_found_time_seconds = time.perf_counter()-start
                    rl_best_events.append(dict(cost=best_cost, elapsed_seconds=best_found_time_seconds))
                    if perturbation_learner is not None:perturbation_learner.observe_global(best_cost)
                    cycle_improved_best = True
                convergence_log.append({"cycle":int(cycle), "scan_position":None,
                    "class_id":None, "total_class_scans":int(total_class_scans),
                    "total_tabu_moves":int(total_tabu_moves), "event":"two_class_exchange",
                    "evaluation_count":int(eval_count), "current_cost":current_cost,
                    "current_probability":current_p, "best_cost":best_cost,"best_probability":best_p})
                progress(f"iteration={cycle} TWO_CLASS_EXCHANGE cost={before_cost:.12g}->{current_cost:.12g}")
                break
            if hard_stop:
                break

        # --------------------------------------------------------------
        # RANDOM PERTURBATION: exactly once after all classes are scanned.
        # --------------------------------------------------------------
        progress(
            f"iteration={cycle} RANDOM_PERTURB_START "
            f"from_cost={current_cost:.12g} eval={eval_count}"
        )
        if perturbation_learner is not None:
            perturbation_learner.settle(current_cost)
            rl_state, rl_action=perturbation_learner.choose(cycles_without_best_improvement)
            perturbation_learner.begin(rl_state,rl_action,current_cost)
        else:
            rl_action=0
        if rl_action:
            from src.functions.rl_balanced import operator_proposals
            assert not delta_mc_enabled, 'Atomic option requires baseline reference protocol'
            perturbation=None;limit_hit=False
            for changes in operator_proposals(rl_action,current,node_items,factor_id2obj,
                    perturbation_learner.proposal_rng,time_exhausted,target_tmax=T_max):
                if time_exhausted() or budget_exhausted():limit_hit=True;break
                candidate=current.copy()
                for cid,fid in changes:candidate[cid]=fid
                candidate_p=Solution_Evaluation(EvaluationFunction,candidate,T_max,
                    factor_id2obj,ConfidenceLevel,param,MonteCarloTimes,QuickCheckList)
                eval_count+=1
                if candidate_p+tol<ConfidenceLevel:continue
                cid,fid=changes[0]
                perturbation=dict(candidate=candidate,cost=solution_cost(candidate,factor_id2obj),
                    probability=float(candidate_p),class_id=cid,old_factor=int(current[cid]),
                    new_factor=fid,changes=changes,
                    candidate_min_sum=float(sum(factor_id2obj[int(f)].sample_min for f in candidate)),
                    candidate_max_sum=float(sum(factor_id2obj[int(f)].sample_max for f in candidate)),
                    evaluation_source='rl_atomic_full_author')
                perturbation_learner.stats['atomic_accepts']+=1
                break
        else:
            perturbation, limit_hit = random_perturbation(
                cycle,
                current,
                current_cost,
                current_p,
                current_min_sum,
                current_max_sum,
            )
        if limit_hit:
            hard_stop = True
            break

        if perturbation is None:
            # Match the original Degrade fallback: keep the current feasible
            # solution and continue with the next outer iteration.
            perturbation_log.append(
                {
                    "cycle": int(cycle),
                    "success": False,
                    "class_id": None,
                    "old_factor": None,
                    "new_factor": None,
                    "old_cost": current_cost,
                    "new_cost": current_cost,
                    "new_probability": current_p,
                    "tabu_until_iteration": None,
                    "improved_global_best": False,
                }
            )
            convergence_log.append(
                {
                    "cycle": int(cycle),
                    "scan_position": int(param[0]),
                    "class_id": None,
                    "total_class_scans": int(total_class_scans),
                    "total_tabu_moves": int(total_tabu_moves),
                    "event": "random_perturbation_noop",
                    "evaluation_count": int(eval_count),
                    "current_cost": current_cost,
                    "current_probability": current_p,
                    "best_cost": best_cost,
                    "best_probability": best_p,
                }
            )
            progress(
                f"iteration={cycle} RANDOM_PERTURB_END no_feasible_replacement "
                f"keep_cost={current_cost:.12g} eval={eval_count}"
            )
        else:
            old_cost = float(current_cost)
            perturb_class = int(perturbation["class_id"])
            perturb_removed = int(perturbation["old_factor"])
            perturb_new = int(perturbation["new_factor"])

            for extra_cid,extra_fid in perturbation.get("changes", ())[1:]:
                tabu_until_iteration[(extra_cid,int(current[extra_cid]))]=int(cycle+effective_tabu_tenure)
            current = perturbation["candidate"].copy()
            current_cost = float(perturbation["cost"])
            current_p = float(perturbation["probability"])
            current_min_sum = float(perturbation["candidate_min_sum"])
            current_max_sum = float(perturbation["candidate_max_sum"])
            if sync_delta_after_accepted_move(
                perturb_class, perturb_removed, perturb_new, perturbation.get("evaluation_source")
            ):
                hard_stop = True
                break
            perturbation_count += 1

            # The assignment removed by perturbation is tabu when the same
            # class is revisited in the next iteration(s).
            perturb_tabu_expiry = int(cycle + effective_tabu_tenure)
            tabu_until_iteration[(perturb_class, perturb_removed)] = perturb_tabu_expiry

            improved_global_by_perturbation = current_cost < best_cost - tol
            if improved_global_by_perturbation:
                best = current.copy()
                best_cost = current_cost
                best_p = current_p
                best_found_time_seconds = float(time.perf_counter() - start)
                rl_best_events.append(dict(cost=best_cost, elapsed_seconds=best_found_time_seconds))
                if perturbation_learner is not None:perturbation_learner.observe_global(best_cost)
                cycle_improved_best = True

            perturbation_log.append(
                {
                    "cycle": int(cycle),
                    "success": True,
                    "class_id": perturb_class,
                    "old_factor": perturb_removed,
                    "new_factor": perturb_new,
                    "old_cost": old_cost,
                    "new_cost": current_cost,
                    "new_probability": current_p,
                    "tabu_until_iteration": int(perturb_tabu_expiry),
                    "improved_global_best": bool(improved_global_by_perturbation),
                }
            )
            convergence_log.append(
                {
                    "cycle": int(cycle),
                    "scan_position": int(param[0]),
                    "class_id": int(perturb_class),
                    "total_class_scans": int(total_class_scans),
                    "total_tabu_moves": int(total_tabu_moves),
                    "event": "random_perturbation",
                    "evaluation_count": int(eval_count),
                    "current_cost": current_cost,
                    "current_probability": current_p,
                    "best_cost": best_cost,
                    "best_probability": best_p,
                }
            )
            progress(
                f"iteration={cycle} RANDOM_PERTURB_END "
                f"class={perturb_class} {perturb_removed}->{perturb_new} "
                f"cost={old_cost:.12g}->{current_cost:.12g} best={best_cost:.12g} "
                f"eval={eval_count}"
            )

        configuration = tuple(int(v) for v in current)
        previous_visit = visited_configuration_cycle.get(configuration)
        if previous_visit is not None:
            cycle_length = max(1, int(cycle) - int(previous_visit))
            effective_tabu_tenure = max(
                int(tabu_tenure), int(effective_tabu_tenure), cycle_length + 1
            )
            cycle_free_iterations = 0
            progress(f"reactive_tabu_repeat cycle={cycle} cycle_length={cycle_length} effective_tenure={effective_tabu_tenure}")
        else:
            cycle_free_iterations += 1
            if cycle_free_iterations >= effective_tabu_tenure:
                effective_tabu_tenure = max(int(tabu_tenure), effective_tabu_tenure - 1)
                cycle_free_iterations = 0
        visited_configuration_cycle[configuration] = int(cycle)

        completed_cycles = cycle
        convergence_log.append(
            {
                "cycle": int(cycle),
                "scan_position": int(param[0]),
                "class_id": None,
                "total_class_scans": int(total_class_scans),
                "total_tabu_moves": int(total_tabu_moves),
                "event": "iteration_end",
                "evaluation_count": int(eval_count),
                "current_cost": current_cost,
                "current_probability": current_p,
                "best_cost": best_cost,
                "best_probability": best_p,
            }
        )
        progress(
            f"iteration={cycle} END class_scans={int(param[0])} "
            f"accepted_moves={iteration_moves} current_cost={current_cost:.12g} "
            f"best_cost={best_cost:.12g} eval={eval_count}"
        )

        if cycle_improved_best:
            cycles_without_best_improvement = 0
        else:
            cycles_without_best_improvement += 1
        if (
            restart_no_improve_cycles is not None
            and cycles_without_best_improvement >= restart_no_improve_cycles
        ):
            stop_reason = "stagnation_restart"
            progress(
                f"restart_trigger cycle={cycle} no_best_improve_cycles="
                f"{cycles_without_best_improvement}"
            )
            break

    # Respect the per-run hard time budget.  A time-limited run returns the
    # best probability recorded by the search oracle instead of launching a new
    # full Monte Carlo call after the deadline.  Exact/independent validation can
    # be performed offline on saved solutions if desired.
    if perturbation_learner is not None:
        if time_exhausted() or budget_exhausted():perturbation_learner.censor()
        else:perturbation_learner.censor()
    validation_p = best_p
    if time_exhausted():
        stop_reason = "time_limit"
    elif budget_exhausted():
        stop_reason = "evaluation_budget"

    valid, reason = validate_multiple_choice_solution(best, node_items)
    if not valid:
        raise AssertionError(reason)
    validation_cost = solution_cost(best, factor_id2obj)
    if abs(validation_cost - best_cost) > 1e-9:
        raise AssertionError("Final objective validation failed")

    certified_feasible = bool(validation_p + tol >= ConfidenceLevel)
    runtime = time.perf_counter() - start
    progress(
        f"result_finalize p={float(validation_p):.8f} feasible={certified_feasible} "
        f"eval={eval_count} runtime={runtime:.3f}s stop={stop_reason}"
    )

    result = DDTSResult(
        solution=[int(v) for v in best],
        cost=float(best_cost),
        probability=float(validation_p),
        search_probability=float(best_p),
        certified_feasible=certified_feasible,
        iterations=int(completed_cycles),
        completed_cycles=int(completed_cycles),
        total_class_scans=int(total_class_scans),
        total_tabu_moves=int(total_tabu_moves),
        perturbation_count=int(perturbation_count),
        pair_exchange_count=int(pair_exchange_count),
        pair_exchange_evaluation_count=int(pair_exchange_evaluation_count),
        pair_exchange_proposal_count=int(pair_exchange_proposal_count),
        no_improve_limit=int(no_improve_limit),
        evaluation_count=int(eval_count),
        amc_quickcheck_prefilter_skip_count=int(amc_quickcheck_prefilter_skip_count),
        delta_mc_enabled=bool(delta_mc_enabled),
        delta_mc_evaluation_count=int(delta_mc_evaluation_count),
        delta_mc_early_reject_count=int(delta_mc_early_reject_count),
        delta_mc_full_evaluation_count=int(delta_mc_full_evaluation_count),
        delta_mc_samples_used=int(delta_mc_samples_used),
        delta_mc_initialization_seconds=float(delta_mc_initialization_seconds),
        stop_reason=stop_reason,
        runtime_seconds=float(runtime),
        heuristic_gap_percent=_gap_percent(best_cost, gurobi_optimum),
        search_mode=search_mode,
        convergence_log=convergence_log,
        tabu_move_log=tabu_move_log,
        perturbation_log=perturbation_log,
        best_found_time_seconds=float(best_found_time_seconds),
    )

    result.rl_best_events=rl_best_events
    return result
