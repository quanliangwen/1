"""A moment-based initial proposal; only the author evaluator certifies it."""
import numpy as np
from scipy.special import ndtri

def cost_risk_initial_proposal(node_items,factors,tmax,p0):
    classes=sorted(node_items)
    ids=[np.asarray(node_items[c],dtype=int) for c in classes]
    costs=[np.asarray([factors[int(fid)].cost for fid in row],dtype=float) for row in ids]
    means=[np.asarray([np.mean(factors[int(fid)].samples[:-1]) for fid in row]) for row in ids]
    variances=[np.asarray([np.var(factors[int(fid)].samples[:-1]) for fid in row]) for row in ids]
    z=float(ndtri(float(p0)))
    def assignment(lam,weights):
        return tuple(int(np.argmin(costs[c]+lam*weights[c])) for c in range(len(classes)))
    def totals(choice):
        cost=sum(costs[c][i] for c,i in enumerate(choice))
        mean=sum(means[c][i] for c,i in enumerate(choice))
        variance=sum(variances[c][i] for c,i in enumerate(choice))
        return float(cost),float(mean),float(variance)
    current=tuple(int(np.argmin(c)) for c in costs)
    seen={};previous=set()
    for _ in range(sum(len(row) for row in ids)):
        if current in previous:break
        previous.add(current)
        _,_,variance=totals(current)
        sigma=float(np.sqrt(max(variance,np.finfo(float).tiny)))
        beta=z/(2.0*sigma)
        weights=[means[c]+beta*variances[c] for c in range(len(classes))]
        budget=float(tmax)-0.5*z*sigma
        def weight(choice):return sum(weights[c][i] for c,i in enumerate(choice))
        lo,hi=0.0,1.0
        low=assignment(lo,weights);high=assignment(hi,weights)
        while weight(high)>budget:
            previous_high=high;hi*=2.0;high=assignment(hi,weights)
            if high==previous_high and hi>1e12:break
        for _ in range(64):
            mid=(lo+hi)/2.0;choice=assignment(mid,weights)
            seen[choice]=totals(choice)
            if weight(choice)>budget:lo=mid;low=choice
            else:hi=mid;high=choice
        seen[low]=totals(low);seen[high]=totals(high)
        current=high
    def key(choice):
        cost,mean,var=seen[choice]
        violation=mean+z*np.sqrt(var)-float(tmax)
        return (violation>0,max(0,float(violation)),cost,choice)
    best=min(seen,key=key)
    return np.asarray([int(ids[c][i]) for c,i in enumerate(best)],dtype=int)
