"""Lagrangian guidance for GRASP restarts in MS-DDTS.

This module does NOT change the CCMCKP model or the DDTS acceptance rule.
It solves only a finite-SAA Lagrangian relaxation to learn scenario prices
(lambda_s), then ranks the retained items of every class by

    c_ij + sum_s lambda_s * w_ij^s.

The resulting ranks are used only to construct the randomized RCL of later
GRASP restarts.  Original GRASP restarts, DDTS, tabu memory, perturbation,
Delta-MC and authoritative probability validation remain unchanged.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Sequence
import math
import time

import numpy as np


def max_allowed_violations(sample_size: int, p0: float) -> int:
    return int(sample_size) - int(np.ceil(float(p0) * int(sample_size) - 1e-12))


@dataclass
class LagrangianGuidanceResult:
    rankings_by_class: Dict[int, List[int]]
    lambdas: np.ndarray
    runtime_seconds: float
    iteration_count: int
    best_dual_bound: float
    final_dual_value: float
    theta_final: float
    lambda_min: float
    lambda_max: float
    lambda_mean: float
    lambda_nonzero_count: int
    lambda_l1: float
    lambda_l2: float
    saa_sample_size: int
    saa_max_violations: int
    stop_reason: str
    iteration_log: List[dict]

    def summary_dict(self):
        d = asdict(self)
        d.pop("rankings_by_class", None)
        d.pop("lambdas", None)
        d.pop("iteration_log", None)
        return d


class _GuidanceSAAContext:
    def __init__(
        self,
        node_resort_w: Dict[int, Sequence[int]],
        factor_id2obj: Sequence,
        sample_size: int,
        p0: float,
        tmax: float,
        base_seed: int,
    ):
        self.class_ids = sorted(int(i) for i in node_resort_w)
        self.m = len(self.class_ids)
        self.sample_size = int(sample_size)
        self.p0 = float(p0)
        self.tmax = float(tmax)
        self.q = max_allowed_violations(self.sample_size, self.p0)
        self.factor_id2obj = factor_id2obj

        self.factor_ids_by_class: List[np.ndarray] = []
        self.costs_by_class: List[np.ndarray] = []
        self.weights_by_class: List[np.ndarray] = []
        upper = np.zeros(self.sample_size, dtype=float)

        # CRN within each class: all candidate items of one class are sampled
        # with exactly the same empirical sample indices.  The stream is fixed
        # for the entire guidance phase of this run.
        for class_id in self.class_ids:
            fids = np.asarray([int(v) for v in node_resort_w[class_id]], dtype=int)
            if fids.size == 0:
                raise ValueError(f"class {class_id} has no retained item")
            first_samples = np.asarray(factor_id2obj[int(fids[0])].samples, dtype=float)
            if first_samples.size == 0:
                raise ValueError(f"factor {int(fids[0])} has no empirical samples")
            rng = np.random.default_rng(
                np.random.SeedSequence([int(base_seed), int(class_id), 0x4C52])
            )
            idx = rng.integers(0, first_samples.size, size=self.sample_size, dtype=np.int64)
            rows = []
            for fid in fids:
                samples = np.asarray(factor_id2obj[int(fid)].samples, dtype=float)
                # Benchmark factors in one instance share sample length.  If a
                # custom instance does not, deterministically fold the CRN indices.
                local_idx = idx if samples.size == first_samples.size else (idx % samples.size)
                rows.append(samples[local_idx])
            W = np.vstack(rows).astype(float, copy=False)
            costs = np.asarray([float(factor_id2obj[int(fid)].cost) for fid in fids], dtype=float)
            self.factor_ids_by_class.append(fids)
            self.costs_by_class.append(costs)
            self.weights_by_class.append(W)
            upper += np.max(W, axis=0)

        # Tight nonnegative M_s over the retained item domain.
        self.big_m = np.maximum(0.0, upper - self.tmax)

    def solve(self, lambdas: np.ndarray):
        lam = np.asarray(lambdas, dtype=float)
        scenario_sums = np.zeros(self.sample_size, dtype=float)
        class_term = 0.0
        original_cost = 0.0
        solution = []

        for local_i in range(self.m):
            modified = self.costs_by_class[local_i] + self.weights_by_class[local_i] @ lam
            pos = int(np.argmin(modified))
            class_term += float(modified[pos])
            original_cost += float(self.costs_by_class[local_i][pos])
            scenario_sums += self.weights_by_class[local_i][pos]
            solution.append(int(self.factor_ids_by_class[local_i][pos]))

        z = np.zeros(self.sample_size, dtype=float)
        scores = lam * self.big_m
        if self.q > 0:
            order = np.argsort(-scores, kind="mergesort")
            chosen = order[: min(self.q, self.sample_size)]
            chosen = chosen[scores[chosen] > 0.0]
            z[chosen] = 1.0

        dual = float(class_term - self.tmax * np.sum(lam) - np.dot(scores, z))
        subgradient = scenario_sums - self.tmax - self.big_m * z
        return dual, subgradient, original_cost, solution

    def rankings(self, lambdas: np.ndarray) -> Dict[int, List[int]]:
        lam = np.asarray(lambdas, dtype=float)
        out: Dict[int, List[int]] = {}
        for local_i, class_id in enumerate(self.class_ids):
            modified = self.costs_by_class[local_i] + self.weights_by_class[local_i] @ lam
            # Stable sorting ensures deterministic tie handling.
            order = np.argsort(modified, kind="mergesort")
            out[int(class_id)] = [int(self.factor_ids_by_class[local_i][int(k)]) for k in order]
        return out


def learn_lagrangian_restart_guidance(
    node_resort_w: Dict[int, Sequence[int]],
    factor_id2obj: Sequence,
    p0: float,
    tmax: float,
    sample_size: int,
    base_seed: int,
    upper_bound_cost: Optional[float],
    upper_bound_solution: Optional[Sequence[int]],
    deadline_monotonic: Optional[float],
    max_iterations: int = 2000,
    theta: float = 1.5,
    theta_decay: float = 0.5,
    theta_min: float = 0.05,
    stagnation_limit: int = 50,
    lambda_init: float = 0.0,
    log_interval: int = 50,
) -> LagrangianGuidanceResult:
    """Learn multipliers and return per-class LR-ranked items.

    The finite-SAA relaxation is only a guidance model.  Its solution is never
    accepted as a CCMCKP incumbent.  Therefore no feasibility definition is
    changed by this routine.
    """
    started = time.monotonic()
    ctx = _GuidanceSAAContext(
        node_resort_w=node_resort_w,
        factor_id2obj=factor_id2obj,
        sample_size=int(sample_size),
        p0=float(p0),
        tmax=float(tmax),
        base_seed=int(base_seed),
    )
    lambdas = np.full(ctx.sample_size, max(0.0, float(lambda_init)), dtype=float)
    best_lambdas = lambdas.copy()
    # Polyak stepping is used only when the supplied incumbent is feasible
    # for THIS finite SAA model. A Full-M feasible incumbent need not be SAA
    # feasible because the optimization and validation samples differ.
    polyak_ub = None
    if upper_bound_cost is not None and upper_bound_solution is not None:
        try:
            sol = [int(v) for v in upper_bound_solution]
            if len(sol) == ctx.m:
                sums = np.zeros(ctx.sample_size, dtype=float)
                valid = True
                for local_i, fid in enumerate(sol):
                    fids = ctx.factor_ids_by_class[local_i]
                    pos_arr = np.flatnonzero(fids == int(fid))
                    if pos_arr.size == 0:
                        valid = False
                        break
                    sums += ctx.weights_by_class[local_i][int(pos_arr[0])]
                if valid and int(np.count_nonzero(sums > ctx.tmax + 1e-12)) <= int(ctx.q):
                    polyak_ub = float(upper_bound_cost)
        except Exception:
            polyak_ub = None

    best_dual = -float("inf")
    final_dual = -float("inf")
    theta_now = float(theta)
    no_dual_improve = 0
    records: List[dict] = []
    completed_iterations = 0
    stop_reason = "iteration_limit"
    max_iterations = max(1, int(max_iterations))
    log_interval = max(1, int(log_interval))

    for it in range(max_iterations):
        if deadline_monotonic is not None and time.monotonic() >= float(deadline_monotonic):
            stop_reason = "time_limit"
            break

        dual, g, original_cost, _ = ctx.solve(lambdas)
        completed_iterations += 1
        final_dual = float(dual)
        if dual > best_dual + 1e-10:
            best_dual = float(dual)
            best_lambdas = lambdas.copy()
            no_dual_improve = 0
        else:
            no_dual_improve += 1

        norm2 = float(np.dot(g, g))
        if norm2 <= 1e-20:
            step = 0.0
        else:
            ub = polyak_ub
            if ub is not None and np.isfinite(ub) and ub > dual + 1e-12:
                step = theta_now * (ub - dual) / norm2
            else:
                # Safe fallback when no valid Polyak target is available.
                step = theta_now / (math.sqrt(it + 1.0) * math.sqrt(norm2))
            lambdas = np.maximum(0.0, lambdas + step * g)

        if no_dual_improve >= max(1, int(stagnation_limit)):
            theta_now = max(float(theta_min), theta_now * float(theta_decay))
            no_dual_improve = 0

        if it == 0 or (it + 1) % log_interval == 0:
            records.append(
                {
                    "iteration": int(it + 1),
                    "elapsed_seconds": float(time.monotonic() - started),
                    "dual_value": float(dual),
                    "best_dual_bound": float(best_dual),
                    "lagrangian_solution_cost": float(original_cost),
                    "step_size": float(step),
                    "theta": float(theta_now),
                    "subgradient_norm": float(math.sqrt(norm2)),
                    "lambda_min": float(np.min(lambdas)),
                    "lambda_max": float(np.max(lambdas)),
                    "lambda_mean": float(np.mean(lambdas)),
                    "lambda_nonzero_count": int(np.count_nonzero(lambdas > 1e-15)),
                }
            )
    else:
        stop_reason = "iteration_limit"

    # Use the multiplier vector that attained the best dual value, rather than
    # the last subgradient iterate.  The last iterate can be worse/oscillatory
    # and is not the correct representative of the best learned LR guidance.
    lambdas = best_lambdas.copy()
    rankings = ctx.rankings(lambdas)
    return LagrangianGuidanceResult(
        rankings_by_class=rankings,
        lambdas=lambdas,
        runtime_seconds=float(time.monotonic() - started),
        iteration_count=int(completed_iterations),
        best_dual_bound=float(best_dual),
        final_dual_value=float(final_dual),
        theta_final=float(theta_now),
        lambda_min=float(np.min(lambdas)),
        lambda_max=float(np.max(lambdas)),
        lambda_mean=float(np.mean(lambdas)),
        lambda_nonzero_count=int(np.count_nonzero(lambdas > 1e-15)),
        lambda_l1=float(np.sum(np.abs(lambdas))),
        lambda_l2=float(np.linalg.norm(lambdas)),
        saa_sample_size=int(ctx.sample_size),
        saa_max_violations=int(ctx.q),
        stop_reason=str(stop_reason),
        iteration_log=records,
    )
