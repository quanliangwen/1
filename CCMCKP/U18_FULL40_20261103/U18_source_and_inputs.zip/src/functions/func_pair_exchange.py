"""Cost-saving two-class proposals with a shared, small proposal experiment.

Proposal probabilities never certify feasibility. The caller must invoke the
unchanged author evaluator at the full configured MC size for each acceptance.
"""
import numpy as np

def rank_nonworsening_two_class_exchanges(solution,node_items,factors,tmax,pilot_samples,seed,should_stop,confidence_level=None):
    solution=np.asarray(solution,dtype=int)
    total=np.zeros(int(pilot_samples),dtype=float)
    moves=[]
    for cid in sorted(node_items):
        if should_stop():return []
        current=int(solution[cid]);samples=np.asarray(factors[current].samples,dtype=float)
        rng=np.random.default_rng(np.random.SeedSequence([int(seed),int(cid),0x2A17]))
        indices=rng.integers(0,len(samples)-1,size=int(pilot_samples))
        old_values=samples[indices];total+=old_values
        for fid in node_items[cid]:
            fid=int(fid)
            if fid==current:continue
            values=np.asarray(factors[fid].samples,dtype=float)
            moves.append((int(cid),fid,float(factors[fid].cost)-float(factors[current].cost),values[indices]-old_values))
    current_failures=int(np.count_nonzero(total>=float(tmax)))
    allowed_failures=current_failures if confidence_level is None else int(pilot_samples)-int(np.ceil(float(confidence_level)*int(pilot_samples)-1e-12))
    candidates=[]
    for i,(c1,f1,d1,v1) in enumerate(moves):
        if should_stop():break
        for c2,f2,d2,v2 in moves[i+1:]:
            if c1==c2 or d1+d2>=-1e-12:continue
            failures=int(np.count_nonzero(total+v1+v2>=float(tmax)))
            if failures>allowed_failures:continue
            candidates.append((float(d1+d2),failures,((c1,f1),(c2,f2))))
    candidates.sort(key=lambda x:(x[0],x[1],x[2]))
    return candidates
