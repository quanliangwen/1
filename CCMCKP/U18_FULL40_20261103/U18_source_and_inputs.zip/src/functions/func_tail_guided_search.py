"""Tail-guided candidate scheduling, using the unchanged reference oracle.

Pilot samples schedule proposals only. No single-class candidate is discarded:
pilot-promising moves precede compensating pairs, followed by deferred singles.
Every accepted transition requires the original full-M author evaluation.
"""
import time
import numpy as np
from src.functions.func_search_ablation import get_policy, ReactiveCycleMemory
from src.functions.func_fast_initialization import PilotDeltaContext
from src.functions.func_solution_factor_corrected import Solution_Evaluation, solution_cost
from src.functions.func_pair_exchange import rank_nonworsening_two_class_exchanges
from src.functions.func_tabu_search import (
    Data_Driven_Tabu_Search as legacy_search, DDTSResult,
    validate_multiple_choice_solution, _gap_percent,
)

def ranked_single_moves(context,solution,node_items,factors,p0,tabu,cycle,best_cost,should_stop,pilot_priority=True):
    """Return a complete admissible N1, split by proposal risk, never certify."""
    promising=[];deferred=[];size=context.sample_size
    allowed=size-int(np.ceil(float(p0)*size-1e-12))
    cost=solution_cost(solution,factors)
    for cid in sorted(node_items):
        old=int(solution[cid])
        for fid in node_items[cid]:
            if should_stop():return promising,deferred
            fid=int(fid);delta=float(factors[fid].cost)-float(factors[old].cost)
            if fid==old or delta>=-1e-12:continue
            is_tabu=cycle<=tabu.get((cid,fid),0)
            if is_tabu and cost+delta>=best_cost-1e-12:continue
            failures=context.candidate_violation_count(cid,old,fid) if pilot_priority else 0
            item=(delta,failures,((cid,fid),))
            (promising if failures<=allowed else deferred).append(item)
    promising.sort(key=lambda item:(item[0],item[1],item[2]))
    deferred.sort(key=lambda item:(item[1],item[0],item[2]))
    return promising,deferred

def Data_Driven_Tabu_Search(
    EvaluationFunction,S_cp,node_items,factor_id2obj,ConfidenceLevel,T_max,param,
    MaxIter,MonteCarloTimes,QuickCheckList,tabu_tenure=1,no_improve_limit=20,
    time_limit_seconds=600.0,evaluation_budget=None,gurobi_optimum=None,
    progress_callback=None,run_seed=0,crn_seed=None,restart_no_improve_cycles=None,
    mc_context_factory=None,perturbation_policy='nearby_pair',pair_exchange_pilot_samples=10000,
    perturbation_learner=None,
):
    policy=get_policy()
    if not getattr(EvaluationFunction,'reference_mc',False):
        return legacy_search(EvaluationFunction,S_cp,node_items,factor_id2obj,ConfidenceLevel,
            T_max,param,MaxIter,MonteCarloTimes,QuickCheckList,tabu_tenure=tabu_tenure,
            no_improve_limit=no_improve_limit,time_limit_seconds=time_limit_seconds,
            evaluation_budget=evaluation_budget,gurobi_optimum=gurobi_optimum,
            progress_callback=progress_callback,run_seed=run_seed,crn_seed=crn_seed,
            restart_no_improve_cycles=restart_no_improve_cycles,mc_context_factory=mc_context_factory,
            perturbation_policy=perturbation_policy,pair_exchange_pilot_samples=pair_exchange_pilot_samples,
            perturbation_learner=perturbation_learner)
    started=time.perf_counter();tol=1e-12
    rl_best_events=[]
    current=np.asarray(S_cp[0],dtype=int).copy();current_cost=solution_cost(current,factor_id2obj)
    current_p=float(S_cp[2]);best=current.copy();best_cost=current_cost;best_p=current_p
    if current_p+tol<ConfidenceLevel:raise ValueError('Tail-guided search needs a reference-certified initial solution')
    valid,reason=validate_multiple_choice_solution(current,node_items)
    if not valid:raise ValueError(reason)
    if abs(current_cost-float(S_cp[1]))>1e-9:raise ValueError('Initial cost does not match selected items')
    if restart_no_improve_cycles is not None and int(restart_no_improve_cycles)<=0:restart_no_improve_cycles=None
    evaluations=int(S_cp[3]);singles=perturbations=pairs=pair_evals=pair_proposals=scans=0
    completed_cycles=cycle=stagnation=0;found_time=0.0;tabu={}
    proposal_moves=proposal_rebuilds=deferred_evals=0;proposal_seconds=0.0
    convergence=[];move_log=[];perturb_log=[];reason='time_limit'
    reaction=ReactiveCycleMemory(current,tabu_tenure,policy['reactive_scope']=='all')
    deferred_accepts=0
    def stopped():
        return ((time_limit_seconds is not None and time.perf_counter()-started>=time_limit_seconds)
            or (evaluation_budget is not None and evaluations>=evaluation_budget))
    try:
        context=PilotDeltaContext(current,factor_id2obj,int(param[0]),pair_exchange_pilot_samples,
            T_max,int(run_seed)+0x50700,should_stop=stopped,reference_protocol=True)
    except TimeoutError:context=None
    def record(event,class_id=None):
        convergence.append(dict(cycle=cycle,scan_position=None,class_id=class_id,total_class_scans=scans,
            total_tabu_moves=singles,event=event,evaluation_count=evaluations,current_cost=current_cost,
            current_probability=current_p,best_cost=best_cost,best_probability=best_p))
    record('cp_initial')
    def evaluate(changes):
        nonlocal evaluations
        if stopped():return None,None
        candidate=current.copy()
        for cid,fid in changes:candidate[cid]=fid
        p=Solution_Evaluation(EvaluationFunction,candidate,T_max,factor_id2obj,ConfidenceLevel,
            param,MonteCarloTimes,QuickCheckList)
        evaluations+=1
        return candidate,float(p)
    def commit(candidate,p,changes,event):
        nonlocal current,current_cost,current_p,best,best_cost,best_p,found_time
        before=current_cost;before_solution=current.copy()
        for cid,fid in changes:
            old=int(current[cid]);context.apply_move(cid,old,fid)
            tabu[(cid,old)]=cycle+int(reaction.tenure)
        current=candidate;current_cost=solution_cost(candidate,factor_id2obj);current_p=p
        improved=current_cost<best_cost-tol
        if improved:
            best=current.copy();best_cost=current_cost;best_p=p;found_time=time.perf_counter()-started
            rl_best_events.append(dict(cost=best_cost, elapsed_seconds=found_time))
            if perturbation_learner is not None:perturbation_learner.observe_global(best_cost)
        record(event,changes[0][0] if len(changes)==1 else None)
        row=dict(cycle=cycle,scan_position=None,total_class_scans=scans,total_tabu_moves=singles,
            class_id=changes[0][0],old_factor=int(before_solution[changes[0][0]]),new_factor=changes[0][1],
            old_cost=before,new_cost=current_cost,new_probability=p,was_tabu=False,
            aspiration_by_objective=improved,tabu_until_iteration=cycle+int(reaction.tenure),
            improved_global_best=improved)
        if event=='random_perturbation':
            perturb_log.append({k:row[k] for k in ['cycle','class_id','old_factor','new_factor',
                'old_cost','new_cost','new_probability','tabu_until_iteration','improved_global_best']})
            perturb_log[-1]['success']=True
        else:move_log.append(row)
        if progress_callback:progress_callback(f'{event} cycle={cycle} cost={before:.12g}->{current_cost:.12g}')

    # One cycle is a full intensification descent followed by one perturbation.
    while context is not None and not stopped():
        cycle+=1;previous_best=best_cost
        while not stopped():
            tick=time.perf_counter()
            promising,deferred=ranked_single_moves(context,current,node_items,factor_id2obj,
                ConfidenceLevel,tabu,cycle,best_cost,stopped,pilot_priority=policy['mc_pilot_priority'])
            proposal_seconds+=time.perf_counter()-tick;proposal_rebuilds+=1
            proposal_moves+=len(promising)+len(deferred);scans+=len(node_items)
            accepted=False
            for _,_,changes in promising:
                candidate,p=evaluate(changes)
                if candidate is None:break
                if p+tol<ConfidenceLevel:continue
                singles+=1;commit(candidate,p,changes,'tail_priority_single');accepted=True;break
            if stopped():break
            if accepted:continue

            if policy['mc_pair_exchange']:
                tick=time.perf_counter()
                candidates=rank_nonworsening_two_class_exchanges(current,node_items,factor_id2obj,
                    T_max,pair_exchange_pilot_samples,int(run_seed)+cycle,stopped,
                    confidence_level=ConfidenceLevel)
                proposal_seconds+=time.perf_counter()-tick;pair_proposals+=len(candidates)
                for _,_,changes in candidates:
                    if any(cycle<=tabu.get((cid,fid),0) for cid,fid in changes):
                        candidate_cost=current_cost+sum(float(factor_id2obj[fid].cost)-
                            float(factor_id2obj[int(current[cid])].cost) for cid,fid in changes)
                        if candidate_cost>=best_cost-tol:continue
                    candidate,p=evaluate(changes)
                    if candidate is None:break
                    pair_evals+=1
                    if p+tol<ConfidenceLevel:continue
                    pairs+=1;commit(candidate,p,changes,'two_class_exchange');accepted=True;break
                if stopped():break
                if accepted:continue

            # Retain candidates that the small proposal experiment predicted unsafe.
            # This fallback prevents pilot risk from becoming an acceptance rule.
            for _,_,changes in (deferred if policy['mc_deferred_singles'] else []):
                candidate,p=evaluate(changes)
                if candidate is None:break
                deferred_evals+=1
                if p+tol<ConfidenceLevel:continue
                singles+=1;deferred_accepts+=1;commit(candidate,p,changes,'deferred_single');accepted=True;break
            if stopped() or not accepted:break
        if stopped():break
        if perturbation_learner is not None:
            perturbation_learner.settle(current_cost)
            rl_state, rl_action = perturbation_learner.choose(stagnation)
            perturbation_learner.begin(rl_state, rl_action, current_cost)
        else:
            rl_action=0
        if rl_action:
            from src.functions.rl_balanced import operator_proposals
            moved=False
            for changes in operator_proposals(rl_action,current,node_items,factor_id2obj,
                    perturbation_learner.proposal_rng,stopped,target_tmax=T_max):
                candidate,p=evaluate(changes)
                if candidate is None:break
                if p+tol<ConfidenceLevel:continue
                perturbations+=1;commit(candidate,p,changes,'random_perturbation');moved=True
                perturbation_learner.stats['atomic_accepts']+=1
                break
        else:
            moved=False
            for cid in np.random.permutation(int(param[0])).tolist():
                old=int(current[cid]);alternatives=np.random.permutation([
                    int(fid) for fid in node_items[cid] if int(fid)!=old]).tolist()
                if policy['mc_perturbation_order']=='nearby':
                    alternatives.sort(key=lambda fid:abs(float(factor_id2obj[fid].cost)-float(factor_id2obj[old].cost)))
                for fid in alternatives:
                    candidate,p=evaluate(((cid,fid),))
                    if candidate is None:break
                    if p+tol<ConfidenceLevel:continue
                    perturbations+=1;commit(candidate,p,((cid,fid),),'random_perturbation');moved=True;break
                if moved or stopped():break
        if stopped():break
        reaction.observe(current,cycle)
        completed_cycles=cycle;record('iteration_end')
        stagnation=0 if best_cost<previous_best-tol else stagnation+1
        if restart_no_improve_cycles is not None and stagnation>=restart_no_improve_cycles:
            reason='stagnation_restart';break
    if perturbation_learner is not None:
        if stopped():perturbation_learner.censor()
        else:perturbation_learner.censor()
    if stopped():reason='evaluation_budget' if evaluation_budget is not None and evaluations>=evaluation_budget else 'time_limit'
    valid,validation_reason=validate_multiple_choice_solution(best,node_items)
    if not valid:raise AssertionError(validation_reason)
    result=DDTSResult(solution=best.tolist(),cost=best_cost,probability=best_p,search_probability=best_p,
        certified_feasible=best_p+tol>=ConfidenceLevel,iterations=completed_cycles,completed_cycles=completed_cycles,
        total_class_scans=scans,total_tabu_moves=singles,perturbation_count=perturbations,
        no_improve_limit=no_improve_limit,evaluation_count=evaluations,amc_quickcheck_prefilter_skip_count=0,
        delta_mc_enabled=False,delta_mc_evaluation_count=0,delta_mc_early_reject_count=0,
        delta_mc_full_evaluation_count=0,delta_mc_samples_used=0,delta_mc_initialization_seconds=0.0,
        stop_reason=reason,runtime_seconds=time.perf_counter()-started,heuristic_gap_percent=_gap_percent(best_cost,gurobi_optimum),
        search_mode='tail_priority_single_compensating_pair_deferred_single',convergence_log=convergence,
        tabu_move_log=move_log,perturbation_log=perturb_log,best_found_time_seconds=found_time,
        pair_exchange_count=pairs,pair_exchange_evaluation_count=pair_evals,pair_exchange_proposal_count=pair_proposals)
    result.tail_proposal_count=proposal_moves;result.tail_proposal_rebuild_count=proposal_rebuilds
    result.tail_deferred_evaluation_count=deferred_evals;result.tail_proposal_seconds=proposal_seconds
    result.search_ablation_activity=dict(evaluator_branch='reference_mc',reactive_enabled=reaction.enabled,reactive_repeats=reaction.repeats,reactive_updates=reaction.updates,reactive_max_tenure=reaction.maximum_tenure,deferred_single_accepts=deferred_accepts,pair_accepts=pairs,pair_evaluations=pair_evals,deferred_evaluations=deferred_evals)
    result.rl_best_events=rl_best_events
    return result
