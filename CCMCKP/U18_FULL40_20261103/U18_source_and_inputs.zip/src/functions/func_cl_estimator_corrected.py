"""Corrected probability evaluators used by DDALS_fixed and DDTS.

The author's original ``func_cl_estimator.py`` is kept intact for reproduction.
This module keeps the paper's evaluation framework:

* small instances: exact empirical evaluation;
* large instances: accelerated Monte Carlo / Monte Carlo.

Only confirmed implementation issues are corrected:

1. the exact heap evaluator no longer counts the first feasible boundary state
   as a violation;
2. the chance event follows the mathematical model: sum <= Tmax is feasible,
   hence only sum > Tmax is a violation;
3. Monte Carlo uses Factor.resample_multi from factor_corrected, which can draw
   the last historical sample.

No sequential Monte Carlo, confidence intervals, common random numbers, or new
candidate-screening mechanism is introduced in DDTS-v1.
"""

import heapq
import itertools
import math
import time
from random import choice

import numpy as np


def factorization_list(L, m, P0, list_size, K, timeout_seconds=None, deadline_monotonic=None):
    """Bounded AMC quick-check-list construction.

    The original construction repeatedly shuffles a factor list until every
    strand product is below ``L``.  For large ``m`` that inner loop can take an
    unbounded amount of time.  This revision keeps the same construction logic
    but checks a monotonic deadline inside every potentially long loop and
    raises ``TimeoutError`` when the caller's QuickCheck budget is exhausted.

    Existing callers that omit ``timeout_seconds``/``deadline_monotonic`` keep
    the historical behavior (apart from the pre-existing outer 1000-attempt cap).
    """

    if deadline_monotonic is None and timeout_seconds is not None:
        deadline_monotonic = time.monotonic() + max(0.0, float(timeout_seconds))

    def check_deadline():
        if deadline_monotonic is not None and time.monotonic() >= float(deadline_monotonic):
            raise TimeoutError("QuickCheck factorization_list timed out")

    def list_product(list_, size):
        result = 1
        for idx in range(size):
            result *= list_[idx]
        return result

    def factorization(n, m_=2, result_list=None, count_=0):
        if result_list is None:
            result_list = []
        upper = int(n ** 0.5) + 1
        for i in range(m_, upper):
            if (i & 1023) == 0:
                check_deadline()
            if n % i == 0 and i != 1:
                result_list.append(i)
                count_ = 1
                break
        if count_ == 0:
            result_list.append(n)
            return result_list
        check_deadline()
        return factorization(int(n // i), m_=i, result_list=result_list)

    def permuta_list(arglist, K_):
        length = len(arglist)
        if length == 1:
            return [[arglist[0]]]
        res_list = []
        for _ in range(K_):
            check_deadline()
            index_list = list(np.copy(arglist))
            res = []
            for _ in range(length):
                a = choice(index_list)
                res.append(a)
                index_list.remove(a)
            res_list.append(res)
        return res_list

    def divide_into_n_strand(list_temp, n):
        two_list = [[] for _ in range(n)]
        for i, e in enumerate(list_temp):
            two_list[i % n].append(e)
        return two_list

    check_deadline()
    L = int(L)
    m = int(m)
    if L >= 100:
        L_ = L // 100
        num_L = int(math.pow(L_, m))
        num_b = int(math.pow(10, m) / round(1 / (1 - P0)))
        num_ = int(math.pow(10, m))
        f_list = (
            factorization(num_L, result_list=[])
            + factorization(num_b, result_list=[])
            + factorization(num_, result_list=[])
        )
    else:
        L_ = L // 10
        num_L = int(math.pow(L_, m))
        num_b = int(math.pow(10, m) / round(1 / (1 - P0)))
        f_list = factorization(num_L, result_list=[]) + factorization(num_b, result_list=[])

    check_deadline()
    if max(f_list) > L:
        return []

    product_list = []
    iter_ = 0
    while len(product_list) < list_size and iter_ < 1000:
        check_deadline()
        iter_ += 1
        product_schedule = [L for _ in range(m)]
        while max(product_schedule) >= L:
            # Critical fix: this inner loop used to have no termination bound.
            check_deadline()
            np.random.shuffle(f_list)
            sliced_schedule = divide_into_n_strand(f_list, m)
            product_schedule = sorted([list_product(i, len(i)) - 1 for i in sliced_schedule])
        if product_schedule not in product_list:
            product_list.append(product_schedule)

    res1 = []
    for i in product_list:
        if i not in res1:
            res1.append(i)

    res2 = []
    for i in res1:
        check_deadline()
        for j in permuta_list(i, K):
            j = [int(v) for v in j]
            if j not in res2:
                res2.append(j)
    return res2


def _monte_carlo_evaluate(samples, T_max):
    """Empirical success probability using the model event sum <= Tmax."""
    samples = np.asarray(samples)
    return float(np.count_nonzero(samples <= T_max) / len(samples))


def monte_carlo_estimate(factor_list, T_max, MC_sample_size, CL, param, quick_check_list):
    del CL, param, quick_check_list
    sum_samples = np.zeros(int(MC_sample_size), dtype=float)
    for factor in factor_list:
        sum_samples += factor.resample_multi(int(MC_sample_size))
    return _monte_carlo_evaluate(sum_samples, T_max)


def advanced_monte_carlo(factor_list, T_max, MC_sample_size, CL, param, quick_check_list):
    """Author's AMC framework with only the <=/> boundary correction applied."""
    L, m = int(param[2]), int(param[0])
    _prob = 1 - CL
    sign = 0

    _data_l = math.ceil(round(L ** m * _prob) ** (1 / m))
    _data_l = max(0, min(L - 1, int(_data_l)))
    data_sum = np.sum([factor.get_index_sample(_data_l) for factor in factor_list])
    if data_sum > T_max:
        sign = 1

    for row in quick_check_list:
        if len(row) != m:
            continue
        data_sum = np.sum([factor_list[j].get_index_sample(row[j]) for j in range(m)])
        if data_sum > T_max:
            sign = 1

    if sign == 0:
        sum_samples = np.zeros(int(MC_sample_size), dtype=float)
        for factor in factor_list:
            sum_samples += factor.resample_multi(int(MC_sample_size))
        return _monte_carlo_evaluate(sum_samples, T_max)

    return 0.0


def _heap_exact_probability(factor_list, T_max, CL, param, early_stop_if_infeasible=True):
    """Count empirical violations with a max-heap over the Cartesian lattice.

    Samples for each selected item are ordered from largest to smallest.  The
    heap always exposes the largest unseen sample sum.  Therefore once the heap
    maximum is <= Tmax, all remaining combinations are feasible.

    If ``early_stop_if_infeasible`` is True, the routine returns 0.0 as soon as
    the number of proven violations exceeds the maximum compatible with CL.
    This preserves the original evaluator's fast infeasible classification.
    """
    L, m = int(param[2]), int(param[0])
    total = int(L ** m)
    required_feasible = int(math.ceil(float(CL) * total - 1e-12))
    max_violations = total - required_feasible

    heap = []
    seen = set()

    def push(index_tuple):
        index_tuple = tuple(int(v) for v in index_tuple)
        if index_tuple in seen:
            return
        if any(v < 0 or v >= L for v in index_tuple):
            return
        s = float(sum(factor_list[i].get_index_sample(index_tuple[i]) for i in range(m)))
        seen.add(index_tuple)
        heapq.heappush(heap, (-s, index_tuple))

    push((0,) * m)
    violation_count = 0

    while heap:
        neg_sum, idx = heapq.heappop(heap)
        sample_sum = -neg_sum

        # Off-by-one and model-boundary correction: inspect first.  The current
        # combination is feasible when sample_sum <= Tmax and must not be counted.
        if sample_sum <= T_max:
            break

        violation_count += 1
        if early_stop_if_infeasible and violation_count > max_violations:
            return 0.0

        for i in range(m):
            if idx[i] < L - 1:
                nxt = list(idx)
                nxt[i] += 1
                push(nxt)

    return 1.0 - (violation_count / total)


def exact_empirical_probability(factor_list, T_max, MC_sample_size, CL, param, quick_check_list):
    """Return the full exact empirical probability, including infeasible cases."""
    del MC_sample_size, quick_check_list
    return _heap_exact_probability(factor_list, T_max, CL, param, early_stop_if_infeasible=False)


def exact_evaluation(factor_list, T_max, MC_sample_size, CL, param, quick_check_list):
    del MC_sample_size, quick_check_list
    return _heap_exact_probability(factor_list, T_max, CL, param, early_stop_if_infeasible=True)


def advanced_exact_evaluation(factor_list, T_max, MC_sample_size, CL, param, quick_check_list):
    # DDTS-v1 keeps the exact branch simple and deterministic.  It uses the same
    # heap-ordering principle as the paper/code, with a strict seen set and the
    # corrected boundary/counting order.
    return exact_evaluation(factor_list, T_max, MC_sample_size, CL, param, quick_check_list)
