"""Run-local, duration-aware contextual Thompson operator selection.

Only completed perturbation + original descent windows update the model.
The Beta model describes a positive local basin gain. Magnitude and duration
are discounted empirical estimates: this is an adaptation, not the IJCAI
Bernoulli-cost algorithm and has no inherited regret guarantee.
"""
import json
import os
import time
import numpy as np


class Learner:
    def __init__(self, seed, config=None):
        if config is None:
            with open(os.environ['CCMCKP_RL_CONFIG'], encoding='utf-8') as f:
                config = json.load(f)
        self.config = dict(config)
        self.family = config['family']
        assert self.family in ('fixed', 'rl', 'uniform')
        self.rng = np.random.default_rng(np.random.SeedSequence([int(seed), 0xB411]))
        self.proposal_rng = np.random.default_rng(np.random.SeedSequence([int(seed), 0xB412]))
        self.alpha = np.ones((3, 2))
        self.beta = np.full((3, 2), 9.)
        self.gain = np.full((3, 2), .001)
        self.loss = np.zeros((3, 2))
        self.duration = np.ones((3, 2))
        self.counts = np.zeros((3, 2), dtype=int)
        self.pending = None
        self.events = []
        self.stats = dict(trials=0, settled=0, censored=0, updates=0,
                          feedback_decisions=0, nondefault=0, atomic_accepts=0,
                          positive=0, negative=0, model_changed_choices=0)
        self.trace = []

    def settle(self, cost, terminal=False, now=None):
        if self.pending is None:
            return
        state, action, before, tick = self.pending
        elapsed = max(.001, (time.perf_counter() if now is None else now) - tick)
        reward = (before - float(cost)) / max(abs(before), 1.)
        self.pending = None
        self.stats['settled'] += 1
        if self.family == 'rl':
            d = self.config.get('discount', .98)
            self.alpha[state] = 1 + d * (self.alpha[state] - 1)
            self.beta[state] = 9 + d * (self.beta[state] - 9)
            positive = reward > 1e-12
            self.alpha[state, action] += int(positive)
            self.beta[state, action] += int(not positive)
            rate = .2
            if positive:
                self.gain[state, action] += rate * (reward - self.gain[state, action])
            self.loss[state, action] += rate * (max(0., -reward) - self.loss[state, action])
            self.duration[state, action] += rate * (elapsed - self.duration[state, action])
            self.counts[state, action] += 1
            self.stats['updates'] += 1
            self.stats['positive'] += int(positive)
            self.stats['negative'] += int(reward < -1e-12)
        if len(self.trace) < 300:
            self.trace.append(dict(state=state, action=action, before=before,
                                   after=float(cost), reward=reward, seconds=elapsed,
                                   terminal=bool(terminal)))

    def choose(self, stagnation):
        state = min(2, max(0, int(stagnation)))
        if self.family == 'fixed':
            return state, 0
        if self.family == 'uniform':
            return state, int(self.rng.integers(2))
        if self.stats['updates']:
            self.stats['feedback_decisions'] += 1
        # At most one initial probe of each action in a state, then real data.
        unvisited = np.flatnonzero(self.counts[state] == 0)
        if len(unvisited):
            return state, int(unvisited[0])
        draws = self.rng.beta(self.alpha[state], self.beta[state])
        scores = (draws * self.gain[state] - self.loss[state]) / np.maximum(.001, self.duration[state])
        action = int(np.argmax(scores))
        # Audit how magnitude/duration estimates alter a probability-only choice.
        if action != int(np.argmax(draws)):
            self.stats['model_changed_choices'] += 1
        if self.rng.random() < self.config.get('epsilon', .03):
            action = int(self.rng.integers(2))
        return state, action

    def begin(self, state, action, cost, now=None):
        assert self.pending is None
        self.stats['trials'] += 1
        self.stats['nondefault'] += int(action != 0)
        self.pending = (state, action, float(cost), time.perf_counter() if now is None else now)

    def censor(self):
        if self.pending is not None:
            self.stats['censored'] += 1
            self.pending = None

    def snapshot(self):
        return dict(version='balanced-ts-v2', family=self.family, **self.stats)


def balanced_proposals(solution, node_items, factors, rng, stopped, max_proposals=48):
    """Atomic two-class cost compensation; moments rank proposals only.

    Each attempt changes two distinct classes. A random anchor alternative is
    paired with a different class's alternative that best compensates its cost.
    No candidate is accepted here. Caller uses the baseline full author oracle.
    """
    classes = [c for c in sorted(node_items) if len(node_items[c]) > 1]
    if len(classes) < 2:
        return []
    proposals = []
    seen = set()
    sample_size = 8192
    sampled = {}
    indices = {}
    total = np.zeros(sample_size)
    for c in sorted(node_items):
        if stopped():
            return []
        f = int(solution[c])
        values = np.asarray(factors[f].samples)
        indices[c] = rng.integers(0, len(values)-1, size=sample_size)
        sampled[c, f] = values[indices[c]]
        total += sampled[c, f]
    def values(c, f):
        if (c, f) not in sampled:
            sampled[c, f] = np.asarray(factors[f].samples)[indices[c]]
        return sampled[c, f]
    original_tail = float(np.quantile(total,.99))
    for _ in range(max_proposals * 3):
        if stopped() or len(proposals) >= max_proposals:
            break
        c1, c2 = map(int, rng.choice(classes, 2, replace=False))
        old1, old2 = int(solution[c1]), int(solution[c2])
        options1 = [int(f) for f in node_items[c1] if int(f) != old1]
        rng.shuffle(options1)
        options1.sort(key=lambda f:abs(float(factors[f].cost)-float(factors[old1].cost)))
        f1 = int(rng.choice(options1[:3]))
        d1 = float(factors[f1].cost) - float(factors[old1].cost)
        options2 = [int(f) for f in node_items[c2] if int(f) != old2]
        rng.shuffle(options2)
        options2.sort(key=lambda f: abs(d1 + float(factors[f].cost) - float(factors[old2].cost)))
        for f2 in options2[:2]:
            changes = tuple(sorted(((c1, f1), (c2, f2))))
            if changes in seen:
                continue
            seen.add(changes)
            delta = d1 + float(factors[f2].cost) - float(factors[old2].cost)
            mean_delta = sum(float(factors[f].sample_mean) - float(factors[int(solution[c])].sample_mean) for c, f in changes)
            scale = max(1., abs(float(factors[old1].cost)) + abs(float(factors[old2].cost)))
            # Prefer small cost displacement and lower mean load, with random ties.
            proposal_sums = total.copy()
            for c,f in changes:
                proposal_sums += values(c,f)-values(c,int(solution[c]))
            # Empirical tail rank only; exact/full-M acceptance stays in caller.
            # T_max is not needed: compare quantile displacement from current
            # feasible incumbent. Decrease of the .99 quantile is promising.
            tail_shift = float(np.quantile(proposal_sums,.99)-original_tail)
            score = (tail_shift > 0., max(0.,tail_shift), abs(delta)/scale,
                     max(0.,mean_delta), tail_shift)
            proposals.append((score, changes))
    proposals.sort(key=lambda p: p[0])
    return [changes for _, changes in proposals[:min(12,max_proposals)]]

# U02: append-only learner revision. The U01 implementation above is retained.
_LocalBasinLearner = Learner

class Learner(_LocalBasinLearner):
    """Run-global credit and a baseline-mixture posterior policy.

    This is inspired by conservative exploration, not a reproduction of a
    conservative-bandit confidence-budget algorithm. No baseline-performance
    guarantee is claimed. All learned models start neutral in every run.
    """
    def __init__(self, seed, config=None):
        super().__init__(seed, config)
        self.run_best = float('inf')
        self.pending_global = None
        self.nondefault_cap = float(self.config.get('nondefault_cap', .1))
        if not 0. <= self.nondefault_cap <= 1.:
            raise ValueError('nondefault_cap outside [0,1]')
        self.stats.update(global_positive_updates=0,posterior_decisions=0,
                          conservative_fallbacks=0)
        self.global_credit_sum=0.

    def observe_global(self, cost):
        self.run_best=min(self.run_best,float(cost))

    def begin(self, state, action, cost, now=None):
        super().begin(state,action,cost,now=now)
        self.pending_global=self.run_best if np.isfinite(self.run_best) else float(cost)

    def settle(self, cost, terminal=False, now=None):
        if self.pending is None:
            return
        state,action,before,tick=self.pending
        elapsed=max(.001,(time.perf_counter() if now is None else now)-tick)
        before_global=self.pending_global
        self.observe_global(cost)
        reward=max(0.,before_global-self.run_best)/max(abs(before_global),1.)
        self.pending=None;self.pending_global=None
        self.stats['settled']+=1
        if self.family=='rl':
            discount=self.config.get('discount',.98)
            self.alpha[state]=1+discount*(self.alpha[state]-1)
            self.beta[state]=9+discount*(self.beta[state]-9)
            positive=reward>1e-12
            self.alpha[state,action]+=int(positive)
            self.beta[state,action]+=int(not positive)
            if positive:self.gain[state,action]+=.2*(reward-self.gain[state,action])
            self.duration[state,action]+=.2*(elapsed-self.duration[state,action])
            self.counts[state,action]+=1
            self.stats['updates']+=1;self.stats['positive']+=int(positive)
            self.stats['global_positive_updates']+=int(positive)
            self.global_credit_sum+=reward
        if len(self.trace)<300:
            self.trace.append(dict(state=state,action=action,before=before,after=float(cost),
                reward=reward,before_global=before_global,after_global=self.run_best,
                seconds=elapsed,terminal=bool(terminal)))

    def censor(self):
        super().censor();self.pending_global=None

    def choose(self, stagnation):
        state=min(2,max(0,int(stagnation)))
        if self.family=='fixed':return state,0
        # Shared initialization protocol for RL and the fresh UNIFORM control.
        if self.stats['settled']<2:return state,0
        if self.stats['settled']==2 and self.stats['nondefault']==0:return state,1
        if self.family=='uniform':return state,int(self.rng.integers(2))
        self.stats['feedback_decisions']+=int(self.stats['updates']>0)
        self.stats['posterior_decisions']+=1
        draws=self.rng.beta(self.alpha[state],self.beta[state])
        scores=draws*self.gain[state]/np.maximum(.001,self.duration[state])
        action=int(np.argmax(scores))
        self.stats['model_changed_choices']+=int(action!=int(np.argmax(draws)))
        if self.rng.random()<self.config.get('epsilon',.03):action=int(self.rng.integers(2))
        # A mixture in the selection policy, never a feasibility/admission mask.
        # After the shared one-off probe, at least 90% baseline probability.
        if action==1 and self.rng.random()>=self.nondefault_cap:
            action=0;self.stats['conservative_fallbacks']+=1
        return state,action

    def snapshot(self):
        return dict(version='balanced-global-ts-v3',family=self.family,**self.stats,
                    observed_run_best=self.run_best,global_credit_sum=self.global_credit_sum,
                    nondefault_cap=self.nondefault_cap)
# U03: bounded, single-process beam repair of a sampled neighbourhood.
def balanced_proposals(solution,node_items,factors,rng,stopped,max_proposals=48,target_tmax=None):
    """Proposal-only sampled beam search on <=12 random classes.

    Original full-M evaluation and original transition/acceptance remain outside
    this helper. No optimizer library, threads, historical solutions or weights.
    """
    if target_tmax is None or stopped():return []
    flex=[c for c in sorted(node_items) if len(node_items[c])>1]
    if len(flex)<2:return []
    size=4096;k=min(12,len(flex));width=24
    cost=sum(float(factors[int(f)].cost) for f in solution);scale=max(1.,abs(cost));risk_scale=max(1.,abs(float(target_tmax)))
    all_candidates={};qindex=int(np.ceil(.99*size))-1
    for attempt in range(2):
        if stopped():return []
        selected=list(map(int,rng.choice(flex,k,replace=False)))
        sampled={};total=np.zeros(size,dtype=float)
        for c in sorted(node_items):
            if stopped():return []
            old=int(solution[c]);values=np.asarray(factors[old].samples,dtype=float)
            idx=rng.integers(0,len(values)-1,size=size)
            sampled[c,old]=values[idx];total+=sampled[c,old]
            if c in selected:
                for f in node_items[c]:sampled[c,int(f)]=np.asarray(factors[int(f)].samples,dtype=float)[idx]
        beam=[((),0.,total)]
        for c in selected:
            if stopped():return []
            old=int(solution[c]);expanded=[]
            for changes,delta,values in beam:
                for fid in node_items[c]:
                    fid=int(fid);new_delta=delta+float(factors[fid].cost)-float(factors[old].cost)
                    new_changes=changes+(((c,fid),) if fid!=old else ())
                    new_values=values+sampled[c,fid]-sampled[c,old]
                    expanded.append((new_changes,new_delta,new_values))
            if not expanded:break
            quantiles=np.array([np.partition(x[2],qindex)[qindex] for x in expanded])
            deltas=np.array([x[1] for x in expanded])/scale
            risks=(quantiles-float(target_tmax))/risk_scale
            keep=[];seen=set()
            # Four scalarizations preserve both cost-saving and risk-relief paths.
            for weight in [0.,1.,10.,100.]:
                for j in np.argsort(deltas+weight*risks,kind='stable')[:width//4]:
                    if int(j) not in seen:keep.append(int(j));seen.add(int(j))
            # Fill duplicate slots using the balanced score, with deterministic ties.
            for j in np.argsort(deltas+10.*risks,kind='stable'):
                if len(keep)>=width:break
                if int(j) not in seen:keep.append(int(j));seen.add(int(j))
            beam=[expanded[j] for j in keep]
        for changes,delta,values in beam:
            if len(changes)<2 or delta>.15*scale+1e-9:continue
            changes=tuple(sorted(changes));failures=int(np.count_nonzero(values>=float(target_tmax)))
            quantile=float(np.partition(values,qindex)[qindex])
            # Sampled feasibility is a rank feature, never an acceptance certificate.
            all_candidates[changes]=(failures,quantile,delta)
    if stopped() or not all_candidates:return []
    ordered=sorted(all_candidates,key=lambda ch:(all_candidates[ch][0]>40,all_candidates[ch][2] if all_candidates[ch][0]<=40 else all_candidates[ch][0],all_candidates[ch][1],ch))
    return ordered[:min(4,max_proposals)]

_GlobalAtomic2Learner=Learner
class Learner(_GlobalAtomic2Learner):
    def snapshot(self):
        out=super().snapshot();out['version']='global-beam-repair-ts-v7';return out
# Final U03 audit revision: count feedback only after the common mixture gate.
_BeamDraftLearner=Learner
class Learner(_BeamDraftLearner):
    def __init__(self,seed,config=None):
        super().__init__(seed,config);self.decision_trace=[]

    def choose(self,stagnation):
        state=min(2,max(0,int(stagnation)))
        if self.family=='fixed':return state,0
        if self.stats['settled']<2:return state,0
        if self.stats['settled']==2 and self.stats['nondefault']==0:return state,1
        if self.family=='uniform':return state,int(self.rng.integers(2))
        self.stats['feedback_decisions']+=int(self.stats['updates']>0)
        self.stats['posterior_decisions']+=1
        draws=self.rng.beta(self.alpha[state],self.beta[state])
        scores=draws*self.gain[state]/np.maximum(.001,self.duration[state])
        model_action=int(np.argmax(scores));neutral_action=int(np.argmax(draws))
        exploratory=self.rng.random()<self.config.get('epsilon',.03)
        if exploratory:
            action=int(self.rng.integers(2));counterfactual=action
        else:action=model_action;counterfactual=neutral_action
        # One shared draw permits a final-action counterfactual audit; it is
        # consumed for every posterior decision, independent of either action.
        gate=float(self.rng.random())
        if action==1 and gate>=self.nondefault_cap:
            action=0;self.stats['conservative_fallbacks']+=1
        if counterfactual==1 and gate>=self.nondefault_cap:counterfactual=0
        changed=action!=counterfactual
        self.stats['model_changed_choices']+=int(changed)
        self.decision_trace.append(dict(state=state,updates=self.stats['updates'],draws=draws.tolist(),scores=scores.tolist(),
            model_action=model_action,neutral_action=neutral_action,epsilon=bool(exploratory),mixture_draw=gate,
            final_action=action,neutral_final_action=counterfactual,feedback_changed_final_action=bool(changed)))
        return state,action

    def settle(self,cost,terminal=False,now=None):
        if self.pending is None:return
        state,action,before,tick=self.pending;before_global=self.pending_global
        moment=time.perf_counter() if now is None else now;size=len(self.trace)
        super().settle(cost,terminal=terminal,now=moment)
        # Preserve every completed window, including windows after the former
        # 300-record diagnostic limit. This changes no posterior update.
        if len(self.trace)==size:
            reward=max(0.,before_global-self.run_best)/max(abs(before_global),1.)
            self.trace.append(dict(state=state,action=action,before=before,after=float(cost),reward=reward,
                before_global=before_global,after_global=self.run_best,seconds=max(.001,moment-tick),terminal=bool(terminal)))

    def snapshot(self):
        out=super().snapshot();out.update(version='global-beam-repair-ts-v8',model_choice_count_is_after_mixture=True,
            complete_settled_trace=True,decision_trace=self.decision_trace,alpha=self.alpha.tolist(),beta=self.beta.tolist(),
            gain=self.gain.tolist(),duration=self.duration.tolist(),counts=self.counts.tolist());return out

# U04: same operator, credit and posterior rule; configured mixture cap=1.
_U03FinalLearner=Learner
class Learner(_U03FinalLearner):
    def snapshot(self):
        out=super().snapshot();out['version']='global-beam-unmixed-ts-v9';return out

# U05: one action posterior per run, pooled across stagnation observations.
# No state or learned value is shared across seeds or independent runs.
_U04FinalLearner=Learner
class Learner(_U04FinalLearner):
    def choose(self,stagnation):
        observed=min(2,max(0,int(stagnation)))
        size=len(self.decision_trace)
        state,action=super().choose(0)
        if len(self.decision_trace)>size:
            self.decision_trace[-1]['observed_stagnation_state']=observed
        return state,action

    def begin(self,state,action,cost,now=None):
        return super().begin(0,action,cost,now=now)

    def snapshot(self):
        out=super().snapshot()
        out.update(version='global-beam-pooled-ts-v10',model_state_count=1,
                   model_state_mapping='all_stagnation_states_to_zero_within_run')
        return out

# Isolated U06 draft: replace only beam retention, not the original problem.
def _pareto_crowding_keep(costs, risks, width):
    """NSGA-II-inspired rank/crowding truncation of proposal-only states.

    This is not a complete NSGA-II optimizer and supplies no acceptance test.
    """
    costs=np.asarray(costs,dtype=float);risks=np.asarray(risks,dtype=float)
    n=len(costs)
    if n<=width:return list(range(n))
    dominates=((costs[:,None]<=costs[None,:]) & (risks[:,None]<=risks[None,:]) &
               ((costs[:,None]<costs[None,:]) | (risks[:,None]<risks[None,:])))
    indegree=np.sum(dominates,axis=0).astype(int)
    assigned=np.zeros(n,dtype=bool);keep=[]
    while len(keep)<min(width,n):
        front=np.flatnonzero((indegree==0)&~assigned).tolist()
        if not front:break
        slots=width-len(keep)
        if len(front)>slots:
            distance=np.zeros(len(front),dtype=float)
            for objective in [costs,risks]:
                order=sorted(range(len(front)),key=lambda j:(objective[front[j]],front[j]))
                distance[order[0]]=distance[order[-1]]=np.inf
                span=objective[front[order[-1]]]-objective[front[order[0]]]
                if span>0.:
                    for j in range(1,len(order)-1):
                        distance[order[j]]+=(objective[front[order[j+1]]]-objective[front[order[j-1]]])/span
            selected=sorted(range(len(front)),key=lambda j:(-distance[j],costs[front[j]],risks[front[j]],front[j]))[:slots]
            keep.extend(front[j] for j in selected)
            break
        keep.extend(front)
        assigned[front]=True
        indegree-=np.sum(dominates[front],axis=0)
    return keep


def balanced_proposals(solution,node_items,factors,rng,stopped,max_proposals=48,target_tmax=None):
    """Same bounded sampled beam as U05, with rank/crowding retention only."""
    if target_tmax is None or stopped():return []
    flex=[c for c in sorted(node_items) if len(node_items[c])>1]
    if len(flex)<2:return []
    size=4096;k=min(12,len(flex));width=24
    cost=sum(float(factors[int(f)].cost) for f in solution);scale=max(1.,abs(cost));risk_scale=max(1.,abs(float(target_tmax)))
    all_candidates={};qindex=int(np.ceil(.99*size))-1
    for attempt in range(2):
        if stopped():return []
        selected=list(map(int,rng.choice(flex,k,replace=False)))
        sampled={};total=np.zeros(size,dtype=float)
        for c in sorted(node_items):
            if stopped():return []
            old=int(solution[c]);values=np.asarray(factors[old].samples,dtype=float)
            idx=rng.integers(0,len(values)-1,size=size)
            sampled[c,old]=values[idx];total+=sampled[c,old]
            if c in selected:
                for f in node_items[c]:sampled[c,int(f)]=np.asarray(factors[int(f)].samples,dtype=float)[idx]
        beam=[((),0.,total)]
        for c in selected:
            if stopped():return []
            old=int(solution[c]);expanded=[]
            for changes,delta,values in beam:
                for fid in node_items[c]:
                    fid=int(fid);new_delta=delta+float(factors[fid].cost)-float(factors[old].cost)
                    new_changes=changes+(((c,fid),) if fid!=old else ())
                    new_values=values+sampled[c,fid]-sampled[c,old]
                    expanded.append((new_changes,new_delta,new_values))
            if not expanded:break
            quantiles=np.array([np.partition(x[2],qindex)[qindex] for x in expanded])
            deltas=np.array([x[1] for x in expanded])/scale
            risks=(quantiles-float(target_tmax))/risk_scale
            keep=_pareto_crowding_keep(deltas,risks,width)
            beam=[expanded[j] for j in keep]
        for changes,delta,values in beam:
            if len(changes)<2 or delta>.15*scale+1e-9:continue
            changes=tuple(sorted(changes));failures=int(np.count_nonzero(values>=float(target_tmax)))
            quantile=float(np.partition(values,qindex)[qindex])
            all_candidates[changes]=(failures,quantile,delta)
    if stopped() or not all_candidates:return []
    ordered=sorted(all_candidates,key=lambda ch:(all_candidates[ch][0]>40,all_candidates[ch][2] if all_candidates[ch][0]<=40 else all_candidates[ch][0],all_candidates[ch][1],ch))
    return ordered[:min(4,max_proposals)]


_U05PooledLearner=Learner
class Learner(_U05PooledLearner):
    def snapshot(self):
        out=super().snapshot()
        out.update(version='pareto-beam-pooled-ts-v11',proposal_beam_retention='nondominated_rank_crowding')
        return out

# U07: preserve the full U06 pool/credit rule, with cumulative within-run evidence.
_U06FinalLearner=Learner
class Learner(_U06FinalLearner):
    def __init__(self,seed,config=None):
        cfg=dict(config or {});cfg.setdefault('discount',1.)
        if float(cfg['discount'])!=1.:
            raise ValueError('U07 requires cumulative within-run credit, discount=1')
        super().__init__(seed,cfg)

    def snapshot(self):
        out=super().snapshot()
        out.update(version='pareto-beam-cumulative-ts-v12',credit_discount=1.,credit_retention='cumulative_within_run')
        return out

# U08: preserve the original implicit environment-config entry protocol.
_U07FinalLearner=Learner
class Learner(_U07FinalLearner):
    def __init__(self,seed,config=None):
        self._config_loaded_from_environment=config is None
        if config is None:
            with open(os.environ['CCMCKP_RL_CONFIG'],encoding='utf-8') as f:
                config=json.load(f)
        super().__init__(seed,config)

    def snapshot(self):
        out=super().snapshot()
        out.update(version='pareto-beam-cumulative-env-ts-v13',
            entry_config_protocol='environment_file_when_none',
            config_loaded_from_environment=self._config_loaded_from_environment)
        return out

# U10: whole-run conditional gain and completed-window duration means.
_U08EstimatorLearner=Learner
class Learner(_U08EstimatorLearner):
    def __init__(self,seed,config=None):
        super().__init__(seed,config)
        self.gain_credit_sums=np.zeros((3,2),dtype=float)
        self.positive_credit_counts=np.zeros((3,2),dtype=int)
        self.completed_seconds_sums=np.zeros((3,2),dtype=float)

    def settle(self,cost,terminal=False,now=None):
        if self.pending is None:return
        updates=self.stats['updates']
        super().settle(cost,terminal=terminal,now=now)
        if self.family!='rl':return
        assert self.stats['updates']==updates+1
        w=self.trace[-1];state=int(w['state']);action=int(w['action'])
        self.completed_seconds_sums[state,action]+=w['seconds']
        self.duration[state,action]=self.completed_seconds_sums[state,action]/self.counts[state,action]
        if w['reward']>1e-12:
            self.gain_credit_sums[state,action]+=w['reward']
            self.positive_credit_counts[state,action]+=1
            self.gain[state,action]=self.gain_credit_sums[state,action]/self.positive_credit_counts[state,action]

    def snapshot(self):
        out=super().snapshot()
        out.update(version='pareto-beam-cumulative-means-ts-v15',
            initial_prior_alpha=1.,initial_prior_beta=9.,initial_prior_success_mean=.1,initial_prior_concentration=10.,
            prior_is_symmetric_static_and_fresh_per_run=True,
            gain_estimator='cumulative_positive_credit_mean',
            duration_estimator='cumulative_completed_window_mean',
            gain_credit_sums=self.gain_credit_sums.tolist(),
            positive_credit_counts=self.positive_credit_counts.tolist(),
            completed_seconds_sums=self.completed_seconds_sums.tolist())
        return out

# U11 draft: only choose the subset differently when there are >12 flexible classes.
# Private current-solution tail load is a proposal surrogate, never an acceptance oracle.
_U10UniformSubsetProposals=balanced_proposals

def _cost_tail_subset(solution,node_items,factors,sampled,total,rng,k):
    flex=[c for c in sorted(node_items) if len(node_items[c])>1]
    if len(flex)<=k:return list(map(int,rng.permutation(flex)))
    tail_count=max(1,int(np.ceil(.01*len(total))))
    tail=np.argpartition(total,len(total)-tail_count)[-tail_count:]
    tie={int(c):j for j,c in enumerate(rng.permutation(flex))}
    savings={};relief={}
    for c in flex:
        old=int(solution[c]);old_cost=float(factors[old].cost)
        savings[c]=max(0.,max(old_cost-float(factors[int(f)].cost) for f in node_items[c]))
        current=float(np.mean(sampled[c,old][tail]))
        relief[c]=max(0.,max(current-float(np.mean(sampled[c,int(f)][tail])) for f in node_items[c]))
    ranks=[sorted(flex,key=lambda c:(-savings[c],tie[c])),
           sorted(flex,key=lambda c:(-relief[c],tie[c]))]
    selected=[];positions=[0,0]
    for i in range(k//2):
        which=i%2
        while ranks[which][positions[which]] in selected:positions[which]+=1
        selected.append(ranks[which][positions[which]])
        positions[which]+=1
    remaining=[c for c in flex if c not in selected]
    selected.extend(map(int,rng.choice(remaining,k-len(selected),replace=False)))
    return list(map(int,rng.permutation(selected)))

def balanced_proposals(solution,node_items,factors,rng,stopped,max_proposals=48,target_tmax=None):
    """Same Pareto beam; only the large-instance category subset is guided."""
    flex=[c for c in sorted(node_items) if len(node_items[c])>1]
    if len(flex)<=12:
        return _U10UniformSubsetProposals(solution,node_items,factors,rng,stopped,
            max_proposals=max_proposals,target_tmax=target_tmax)
    if target_tmax is None or stopped():return []
    flex=[c for c in sorted(node_items) if len(node_items[c])>1]
    if len(flex)<2:return []
    size=4096;k=min(12,len(flex));width=24
    cost=sum(float(factors[int(f)].cost) for f in solution);scale=max(1.,abs(cost));risk_scale=max(1.,abs(float(target_tmax)))
    all_candidates={};qindex=int(np.ceil(.99*size))-1
    for attempt in range(2):
        if stopped():return []
        sampled={};total=np.zeros(size,dtype=float)
        for c in sorted(node_items):
            if stopped():return []
            old=int(solution[c]);values=np.asarray(factors[old].samples,dtype=float)
            idx=rng.integers(0,len(values)-1,size=size)
            sampled[c,old]=values[idx];total+=sampled[c,old]
            if c in flex:
                for f in node_items[c]:
                    if stopped():return []
                    sampled[c,int(f)]=np.asarray(factors[int(f)].samples,dtype=float)[idx]
        selected=_cost_tail_subset(solution,node_items,factors,sampled,total,rng,k)
        beam=[((),0.,total)]
        for c in selected:
            if stopped():return []
            old=int(solution[c]);expanded=[]
            for changes,delta,values in beam:
                for fid in node_items[c]:
                    fid=int(fid);new_delta=delta+float(factors[fid].cost)-float(factors[old].cost)
                    new_changes=changes+(((c,fid),) if fid!=old else ())
                    new_values=values+sampled[c,fid]-sampled[c,old]
                    expanded.append((new_changes,new_delta,new_values))
            if not expanded:break
            quantiles=np.array([np.partition(x[2],qindex)[qindex] for x in expanded])
            deltas=np.array([x[1] for x in expanded])/scale
            risks=(quantiles-float(target_tmax))/risk_scale
            keep=_pareto_crowding_keep(deltas,risks,width)
            beam=[expanded[j] for j in keep]
        for changes,delta,values in beam:
            if len(changes)<2 or delta>.15*scale+1e-9:continue
            changes=tuple(sorted(changes));failures=int(np.count_nonzero(values>=float(target_tmax)))
            quantile=float(np.partition(values,qindex)[qindex])
            all_candidates[changes]=(failures,quantile,delta)
    if stopped() or not all_candidates:return []
    ordered=sorted(all_candidates,key=lambda ch:(all_candidates[ch][0]>40,all_candidates[ch][2] if all_candidates[ch][0]<=40 else all_candidates[ch][0],all_candidates[ch][1],ch))
    return ordered[:min(4,max_proposals)]

_U10FinalLearner=Learner
class Learner(_U10FinalLearner):
    def snapshot(self):
        out=super().snapshot()
        out.update(version='tail-subset-cumulative-means-ts-v16',
            proposal_subset_rule='half_cost_tail_guided_half_private_uniform',
            proposal_guidance_when_flexible_classes_exceed=12,
            proposal_guided_fraction=.5,proposal_tail_scenarios=41,
            proposal_surrogate_is_original_acceptance=False)
        return out

# U12 isolated draft: bounded single-thread native-HiGHS SAA joint repair.
# The sample model only generates proposals. Original full-M acceptance is unchanged.
_U11FinalLearner=Learner

def _u12_native_highs():
    import pathlib,sys
    vendor=pathlib.Path(__file__).resolve().parents[2]/'vendor'
    if str(vendor) not in sys.path:sys.path.insert(0,str(vendor))
    import highspy
    if highspy.Highs().version()!='1.8.1':
        raise RuntimeError('U12 requires the pinned isolated highspy1.8.1')
    if vendor.resolve() not in pathlib.Path(highspy.__file__).resolve().parents:
        raise RuntimeError('U12 native binding must come from this source vendor')
    return highspy

def _u12_saa_repair(solution,node_items,factors,rng,stopped,target_tmax):
    if stopped():return []
    from scipy import sparse
    hs=_u12_native_highs()
    flex=[c for c in sorted(node_items) if len(node_items[c])>1]
    if len(flex)<3:return []
    sample_size=512;rank_size=4096;k=min(12,len(flex))
    current_cost=sum(float(factors[int(f)].cost) for f in solution)
    scale=max(1.,abs(current_cost));risk_scale=max(1.,abs(float(target_tmax)))
    candidates={}
    for attempt in range(2):
        if stopped():return []
        # Retain U11's private half cost/tail-guided subset rule. For <=12
        # flexible classes this is only a random permutation of every class.
        sampled={};total=np.zeros(rank_size,dtype=float)
        for c in sorted(node_items):
            if stopped():return []
            old=int(solution[c]);values=np.asarray(factors[old].samples,dtype=float)
            ids=rng.integers(0,len(values)-1,size=rank_size)
            sampled[c,old]=values[ids];total+=sampled[c,old]
            if c in flex:
                for fid in node_items[c]:
                    fid=int(fid);sampled[c,fid]=np.asarray(factors[fid].samples,dtype=float)[ids]
        selected=sorted(_cost_tail_subset(solution,node_items,factors,sampled,total,rng,k))
        # A separate 512-scenario draw builds the repair model.
        training={};outside=np.zeros(sample_size,dtype=float)
        for c in sorted(node_items):
            if stopped():return []
            old=int(solution[c]);values=np.asarray(factors[old].samples,dtype=float)
            ids=rng.integers(0,len(values)-1,size=sample_size)
            if c not in selected:outside+=values[ids]
            else:
                for fid in node_items[c]:
                    fid=int(fid);training[c,fid]=np.asarray(factors[fid].samples,dtype=float)[ids]
        columns=[(c,int(fid)) for c in selected for fid in node_items[c]]
        n=len(columns);nv=n+sample_size
        weights=np.column_stack([training[c,fid] for c,fid in columns])
        maximum=outside.copy()
        for c in selected:maximum+=np.max(np.column_stack([training[c,int(fid)] for fid in node_items[c]]),axis=1)
        margin=1e-8*risk_scale
        big_m=np.maximum(0.,maximum-float(target_tmax)+margin)
        group=np.zeros((k,nv),dtype=float)
        for row,c in enumerate(selected):
            for col,(cid,fid) in enumerate(columns):
                if cid==c:group[row,col]=1.
        unchanged=np.array([float(fid==int(solution[c])) for c,fid in columns]+[0.]*sample_size)
        local_cost=np.array([float(factors[fid].cost) for c,fid in columns]+[0.]*sample_size)
        violations=np.array([0.]*n+[1.]*sample_size)
        old_local=sum(float(factors[int(solution[c])].cost) for c in selected)
        scenarios=sparse.hstack([sparse.csr_matrix(weights/risk_scale),-sparse.diags(big_m/risk_scale)],format='csr')
        matrix=sparse.vstack([sparse.csr_matrix(group),scenarios,
            sparse.csr_matrix(unchanged[None,:]),sparse.csr_matrix(local_cost[None,:]/scale),
            sparse.csr_matrix(violations[None,:])],format='csr')
        lower=np.r_[np.ones(k),np.full(sample_size+3,-hs.kHighsInf)]
        upper=np.r_[np.ones(k),(float(target_tmax)-outside-margin)/risk_scale,
            k-3,(old_local+.15*scale)/scale,3.]
        if stopped():return []
        h=hs.Highs()
        def ok(status):
            if status!=hs.HighsStatus.kOk:raise RuntimeError('native repair model/options rejected: '+str(status))
        for name,value in [('output_flag',False),('threads',1),('parallel','off'),
                ('time_limit',.5),('mip_rel_gap',0.),('random_seed',int(rng.integers(1,2147483647)))]:
            ok(h.setOptionValue(name,value))
        if h.getOptionValue('threads')[1]!=1 or h.getOptionValue('parallel')[1]!='off':
            raise RuntimeError('native repair must use one thread')
        ids=np.arange(nv,dtype=np.int32)
        ok(h.addVars(nv,np.zeros(nv),np.ones(nv)))
        ok(h.changeColsCost(nv,ids,local_cost/scale))
        ok(h.changeColsIntegrality(nv,ids,np.ones(nv,dtype=np.uint8)))
        ok(h.addRows(matrix.shape[0],lower,upper,matrix.nnz,
            matrix.indptr.astype(np.int32),matrix.indices.astype(np.int32),matrix.data.astype(float)))
        if stopped():return []
        status=h.run()
        # A time-limited feasible incumbent is allowed; optimality is not needed.
        sol=h.getSolution()
        if not sol.value_valid:continue
        values=np.asarray(sol.col_value,dtype=float)
        if len(values)!=nv or not np.all(np.isfinite(values)):continue
        rounded=np.rint(values)
        if np.max(np.abs(values-rounded))>1e-6:continue
        ax=matrix.dot(rounded)
        if np.any(ax>upper+1e-6) or np.any(ax<lower-1e-6):continue
        chosen={c:fid for j,(c,fid) in enumerate(columns) if rounded[j]>.5}
        if len(chosen)!=k:continue
        changes=tuple((c,chosen[c]) for c in selected if chosen[c]!=int(solution[c]))
        if len(changes)<3:continue
        delta=sum(float(factors[fid].cost)-float(factors[int(solution[c])].cost) for c,fid in changes)
        if delta>.15*scale+1e-7:continue
        candidates[changes]=delta
    if stopped() or not candidates:return []
    # Fresh private held-out rank sample; never a feasibility certificate.
    sampled={};total=np.zeros(rank_size,dtype=float)
    for c in sorted(node_items):
        if stopped():return []
        old=int(solution[c]);values=np.asarray(factors[old].samples,dtype=float)
        ids=rng.integers(0,len(values)-1,size=rank_size)
        sampled[c,old]=values[ids];total+=sampled[c,old]
        needed={fid for changes in candidates for cid,fid in changes if cid==c}
        for fid in needed:sampled[c,fid]=np.asarray(factors[fid].samples,dtype=float)[ids]
    ranked=[]
    for changes,delta in candidates.items():
        proposal=total.copy()
        for c,fid in changes:proposal+=sampled[c,fid]-sampled[c,int(solution[c])]
        failures=int(np.count_nonzero(proposal>=float(target_tmax)))
        ranked.append(((failures>40,delta if failures<=40 else failures,failures,changes),changes))
    ranked.sort(key=lambda x:x[0])
    return [changes for key,changes in ranked]

def balanced_proposals(solution,node_items,factors,rng,stopped,max_proposals=48,target_tmax=None):
    if target_tmax is None or stopped() or max_proposals<=0:return []
    return _u12_saa_repair(solution,node_items,factors,rng,stopped,target_tmax)[:min(4,max_proposals)]

class Learner(_U11FinalLearner):
    def snapshot(self):
        out=super().snapshot()
        out.update(version='joint-saa3-cumulative-means-ts-v17',
            proposal_rule='native_highs_sample_repair',proposal_min_changed_classes=3,
            proposal_repair_scenarios=512,proposal_allowed_sample_failures=3,
            proposal_rank_scenarios=4096,proposal_repair_attempts=2,
            proposal_repair_time_limit_seconds=.5,proposal_native_threads=1,
            proposal_native_binding='highspy1.8.1_isolated_vendor',
            proposal_surrogate_is_original_acceptance=False)
        return out


# U12 final metadata: do not label the current repair as the inherited old beam.
_U12DraftLearner=Learner
class Learner(_U12DraftLearner):
    def snapshot(self):
        out=super().snapshot()
        out.update(version='joint-saa3-cumulative-means-ts-v18',
            proposal_beam_retention='not_used_native_saa3_repair')
        return out

# U13 isolated draft: separate a deliberate identity option from repair attempts.
_U12FinalLearner = Learner
class Learner(_U12FinalLearner):
    def __init__(self, seed, config=None):
        super().__init__(seed, config)
        self.alpha=np.ones((3,3));self.beta=np.full((3,3),9.)
        self.gain=np.full((3,3),.001);self.loss=np.zeros((3,3))
        self.duration=np.ones((3,3));self.counts=np.zeros((3,3),dtype=int)
        self.gain_credit_sums=np.zeros((3,3))
        self.positive_credit_counts=np.zeros((3,3),dtype=int)
        self.completed_seconds_sums=np.zeros((3,3))
        self.arm_trials=np.zeros(3,dtype=int)
        self.arm_settled=np.zeros(3,dtype=int)
        self.arm_censored=np.zeros(3,dtype=int)
        self.selection_trace=[];self.option_event_trace=[]

    def choose(self, stagnation):
        observed=min(2,max(0,int(stagnation)));state=0;decision=None
        if self.family=='fixed':kind='fixed';action=0
        elif self.stats['settled']<2:kind='baseline_warmup';action=0
        elif self.arm_trials[1]==0:kind='repair_probe';action=1
        elif self.arm_trials[2]==0:kind='identity_probe';action=2
        elif self.family=='uniform':kind='uniform';action=int(self.rng.integers(3))
        else:
            kind='posterior'
            self.stats['feedback_decisions']+=int(self.stats['updates']>0)
            self.stats['posterior_decisions']+=1
            draws=self.rng.beta(self.alpha[state],self.beta[state])
            scores=draws*self.gain[state]/np.maximum(.001,self.duration[state])
            model=int(np.argmax(scores));neutral=int(np.argmax(draws))
            explore=bool(self.rng.random()<self.config.get('epsilon',.03))
            if explore:action=int(self.rng.integers(3));counter=action
            else:action=model;counter=neutral
            gate=float(self.rng.random())
            if action!=0 and gate>=self.nondefault_cap:
                action=0;self.stats['conservative_fallbacks']+=1
            if counter!=0 and gate>=self.nondefault_cap:counter=0
            changed=action!=counter;self.stats['model_changed_choices']+=int(changed)
            decision=len(self.decision_trace)
            self.decision_trace.append(dict(state=state,observed_stagnation_state=observed,
                updates=self.stats['updates'],draws=draws.tolist(),scores=scores.tolist(),
                model_action=model,neutral_action=neutral,epsilon=explore,mixture_draw=gate,
                final_action=action,neutral_final_action=counter,feedback_changed_final_action=bool(changed)))
        selection=dict(state=state,observed_stagnation_state=observed,kind=kind,
            action=action,trials=self.stats['trials'],settled=self.stats['settled'],
            updates=self.stats['updates'],arm_trials_before=self.arm_trials.tolist(),decision_index=decision)
        self.selection_trace.append(selection)
        self.option_event_trace.append(dict(event='choose',selection_index=len(self.selection_trace)-1))
        return state,action

    def begin(self,state,action,cost,now=None):
        assert action in [0,1,2]
        super().begin(state,action,cost,now=now)
        self.arm_trials[action]+=1
        self.option_event_trace.append(dict(event='begin',action=int(action),
            selection_index=len(self.selection_trace)-1 if self.selection_trace else None,
            before=float(cost),before_global=float(self.pending_global)))

    def settle(self,cost,terminal=False,now=None):
        pending=self.pending
        super().settle(cost,terminal=terminal,now=now)
        if pending is not None:
            action=int(pending[1]);self.arm_settled[action]+=1
            self.option_event_trace.append(dict(event='settle',action=action,window_index=len(self.trace)-1))

    def censor(self):
        pending=self.pending
        super().censor()
        if pending is not None:
            action=int(pending[1]);self.arm_censored[action]+=1
            self.option_event_trace.append(dict(event='censor',action=action))

    def snapshot(self):
        out=super().snapshot()
        out.update(version='three-option-identity-global-means-ts-v19',action_count=3,
            action_labels=['original_single_nearby','native_saa3_repair','identity_keep_current'],
            shared_initialization='two_completed_baseline_then_one_attempt_each_repair_identity',
            identity_semantics='no_proposal_no_oracle_no_commit_then_original_descent_and_restart',
            identity_has_atomic_accepts=False,arm_trials=self.arm_trials.tolist(),
            arm_settled=self.arm_settled.tolist(),arm_censored=self.arm_censored.tolist(),
            selection_trace=self.selection_trace,option_event_trace=self.option_event_trace,
            full_choice_begin_settle_censor_trace=True)
        return out

def operator_proposals(action,solution,node_items,factors,rng,stopped,max_proposals=48,target_tmax=None):
    if action==2:
        return []
    if action!=1:
        raise ValueError('Only repair or identity enters the nondefault proposal branch')
    return balanced_proposals(solution,node_items,factors,rng,stopped,
        max_proposals=max_proposals,target_tmax=target_tmax)


# U14 isolated draft: reduce only the repair temporary-cost ceiling15% to3%.
_U13FinalLearner=Learner
def _u12_saa_repair(solution,node_items,factors,rng,stopped,target_tmax):
    if stopped():return []
    from scipy import sparse
    hs=_u12_native_highs()
    flex=[c for c in sorted(node_items) if len(node_items[c])>1]
    if len(flex)<3:return []
    sample_size=512;rank_size=4096;k=min(12,len(flex))
    current_cost=sum(float(factors[int(f)].cost) for f in solution)
    scale=max(1.,abs(current_cost));risk_scale=max(1.,abs(float(target_tmax)))
    candidates={}
    for attempt in range(2):
        if stopped():return []
        # Retain U11's private half cost/tail-guided subset rule. For <=12
        # flexible classes this is only a random permutation of every class.
        sampled={};total=np.zeros(rank_size,dtype=float)
        for c in sorted(node_items):
            if stopped():return []
            old=int(solution[c]);values=np.asarray(factors[old].samples,dtype=float)
            ids=rng.integers(0,len(values)-1,size=rank_size)
            sampled[c,old]=values[ids];total+=sampled[c,old]
            if c in flex:
                for fid in node_items[c]:
                    fid=int(fid);sampled[c,fid]=np.asarray(factors[fid].samples,dtype=float)[ids]
        selected=sorted(_cost_tail_subset(solution,node_items,factors,sampled,total,rng,k))
        # A separate 512-scenario draw builds the repair model.
        training={};outside=np.zeros(sample_size,dtype=float)
        for c in sorted(node_items):
            if stopped():return []
            old=int(solution[c]);values=np.asarray(factors[old].samples,dtype=float)
            ids=rng.integers(0,len(values)-1,size=sample_size)
            if c not in selected:outside+=values[ids]
            else:
                for fid in node_items[c]:
                    fid=int(fid);training[c,fid]=np.asarray(factors[fid].samples,dtype=float)[ids]
        columns=[(c,int(fid)) for c in selected for fid in node_items[c]]
        n=len(columns);nv=n+sample_size
        weights=np.column_stack([training[c,fid] for c,fid in columns])
        maximum=outside.copy()
        for c in selected:maximum+=np.max(np.column_stack([training[c,int(fid)] for fid in node_items[c]]),axis=1)
        margin=1e-8*risk_scale
        big_m=np.maximum(0.,maximum-float(target_tmax)+margin)
        group=np.zeros((k,nv),dtype=float)
        for row,c in enumerate(selected):
            for col,(cid,fid) in enumerate(columns):
                if cid==c:group[row,col]=1.
        unchanged=np.array([float(fid==int(solution[c])) for c,fid in columns]+[0.]*sample_size)
        local_cost=np.array([float(factors[fid].cost) for c,fid in columns]+[0.]*sample_size)
        violations=np.array([0.]*n+[1.]*sample_size)
        old_local=sum(float(factors[int(solution[c])].cost) for c in selected)
        scenarios=sparse.hstack([sparse.csr_matrix(weights/risk_scale),-sparse.diags(big_m/risk_scale)],format='csr')
        matrix=sparse.vstack([sparse.csr_matrix(group),scenarios,
            sparse.csr_matrix(unchanged[None,:]),sparse.csr_matrix(local_cost[None,:]/scale),
            sparse.csr_matrix(violations[None,:])],format='csr')
        lower=np.r_[np.ones(k),np.full(sample_size+3,-hs.kHighsInf)]
        upper=np.r_[np.ones(k),(float(target_tmax)-outside-margin)/risk_scale,
            k-3,(old_local+.03*scale)/scale,3.]
        if stopped():return []
        h=hs.Highs()
        def ok(status):
            if status!=hs.HighsStatus.kOk:raise RuntimeError('native repair model/options rejected: '+str(status))
        for name,value in [('output_flag',False),('threads',1),('parallel','off'),
                ('time_limit',.5),('mip_rel_gap',0.),('random_seed',int(rng.integers(1,2147483647)))]:
            ok(h.setOptionValue(name,value))
        if h.getOptionValue('threads')[1]!=1 or h.getOptionValue('parallel')[1]!='off':
            raise RuntimeError('native repair must use one thread')
        ids=np.arange(nv,dtype=np.int32)
        ok(h.addVars(nv,np.zeros(nv),np.ones(nv)))
        ok(h.changeColsCost(nv,ids,local_cost/scale))
        ok(h.changeColsIntegrality(nv,ids,np.ones(nv,dtype=np.uint8)))
        ok(h.addRows(matrix.shape[0],lower,upper,matrix.nnz,
            matrix.indptr.astype(np.int32),matrix.indices.astype(np.int32),matrix.data.astype(float)))
        if stopped():return []
        status=h.run()
        # A time-limited feasible incumbent is allowed; optimality is not needed.
        sol=h.getSolution()
        if not sol.value_valid:continue
        values=np.asarray(sol.col_value,dtype=float)
        if len(values)!=nv or not np.all(np.isfinite(values)):continue
        rounded=np.rint(values)
        if np.max(np.abs(values-rounded))>1e-6:continue
        ax=matrix.dot(rounded)
        if np.any(ax>upper+1e-6) or np.any(ax<lower-1e-6):continue
        chosen={c:fid for j,(c,fid) in enumerate(columns) if rounded[j]>.5}
        if len(chosen)!=k:continue
        changes=tuple((c,chosen[c]) for c in selected if chosen[c]!=int(solution[c]))
        if len(changes)<3:continue
        delta=sum(float(factors[fid].cost)-float(factors[int(solution[c])].cost) for c,fid in changes)
        if delta>.03*scale+1e-7:continue
        candidates[changes]=delta
    if stopped() or not candidates:return []
    # Fresh private held-out rank sample; never a feasibility certificate.
    sampled={};total=np.zeros(rank_size,dtype=float)
    for c in sorted(node_items):
        if stopped():return []
        old=int(solution[c]);values=np.asarray(factors[old].samples,dtype=float)
        ids=rng.integers(0,len(values)-1,size=rank_size)
        sampled[c,old]=values[ids];total+=sampled[c,old]
        needed={fid for changes in candidates for cid,fid in changes if cid==c}
        for fid in needed:sampled[c,fid]=np.asarray(factors[fid].samples,dtype=float)[ids]
    ranked=[]
    for changes,delta in candidates.items():
        proposal=total.copy()
        for c,fid in changes:proposal+=sampled[c,fid]-sampled[c,int(solution[c])]
        failures=int(np.count_nonzero(proposal>=float(target_tmax)))
        ranked.append(((failures>40,delta if failures<=40 else failures,failures,changes),changes))
    ranked.sort(key=lambda x:x[0])
    return [changes for key,changes in ranked]

class Learner(_U13FinalLearner):
    def snapshot(self):
        out=super().snapshot()
        out.update(version='three-option-low-displacement-global-means-ts-v20',
            proposal_temporary_cost_increase_fraction=.03,
            proposal_cost_cap_scale='max_one_absolute_current_cost')
        return out


# U15 isolated draft: zero-violation128-scenario model, no scenario binary indicators.
_U14FinalLearner=Learner
def _u12_saa_repair(solution,node_items,factors,rng,stopped,target_tmax):
    if stopped():return []
    from scipy import sparse
    hs=_u12_native_highs()
    flex=[c for c in sorted(node_items) if len(node_items[c])>1]
    if len(flex)<3:return []
    sample_size=128;rank_size=4096;k=min(12,len(flex))
    current_cost=sum(float(factors[int(f)].cost) for f in solution)
    scale=max(1.,abs(current_cost));risk_scale=max(1.,abs(float(target_tmax)))
    candidates={}
    for attempt in range(2):
        if stopped():return []
        # Retain U11's private half cost/tail-guided subset rule. For <=12
        # flexible classes this is only a random permutation of every class.
        sampled={};total=np.zeros(rank_size,dtype=float)
        for c in sorted(node_items):
            if stopped():return []
            old=int(solution[c]);values=np.asarray(factors[old].samples,dtype=float)
            ids=rng.integers(0,len(values)-1,size=rank_size)
            sampled[c,old]=values[ids];total+=sampled[c,old]
            if c in flex:
                for fid in node_items[c]:
                    fid=int(fid);sampled[c,fid]=np.asarray(factors[fid].samples,dtype=float)[ids]
        selected=sorted(_cost_tail_subset(solution,node_items,factors,sampled,total,rng,k))
        # A separate 128-scenario draw builds an all-scenarios-satisfied proposal model.
        training={};outside=np.zeros(sample_size,dtype=float)
        for c in sorted(node_items):
            if stopped():return []
            old=int(solution[c]);values=np.asarray(factors[old].samples,dtype=float)
            ids=rng.integers(0,len(values)-1,size=sample_size)
            if c not in selected:outside+=values[ids]
            else:
                for fid in node_items[c]:
                    fid=int(fid);training[c,fid]=np.asarray(factors[fid].samples,dtype=float)[ids]
        columns=[(c,int(fid)) for c in selected for fid in node_items[c]]
        n=len(columns);nv=n
        weights=np.column_stack([training[c,fid] for c,fid in columns])
        margin=1e-8*risk_scale
        group=np.zeros((k,nv),dtype=float)
        for row,c in enumerate(selected):
            for col,(cid,fid) in enumerate(columns):
                if cid==c:group[row,col]=1.
        unchanged=np.array([float(fid==int(solution[c])) for c,fid in columns])
        local_cost=np.array([float(factors[fid].cost) for c,fid in columns])
        old_local=sum(float(factors[int(solution[c])].cost) for c in selected)
        scenarios=sparse.csr_matrix(weights/risk_scale)
        matrix=sparse.vstack([sparse.csr_matrix(group),scenarios,
            sparse.csr_matrix(unchanged[None,:]),sparse.csr_matrix(local_cost[None,:]/scale)],format='csr')
        lower=np.r_[np.ones(k),np.full(sample_size+2,-hs.kHighsInf)]
        upper=np.r_[np.ones(k),(float(target_tmax)-outside-margin)/risk_scale,
            k-3,(old_local+.03*scale)/scale]
        if stopped():return []
        h=hs.Highs()
        def ok(status):
            if status!=hs.HighsStatus.kOk:raise RuntimeError('native repair model/options rejected: '+str(status))
        for name,value in [('output_flag',False),('threads',1),('parallel','off'),
                ('time_limit',.5),('mip_rel_gap',0.),('random_seed',int(rng.integers(1,2147483647)))]:
            ok(h.setOptionValue(name,value))
        if h.getOptionValue('threads')[1]!=1 or h.getOptionValue('parallel')[1]!='off':
            raise RuntimeError('native repair must use one thread')
        ids=np.arange(nv,dtype=np.int32)
        ok(h.addVars(nv,np.zeros(nv),np.ones(nv)))
        ok(h.changeColsCost(nv,ids,local_cost/scale))
        ok(h.changeColsIntegrality(nv,ids,np.ones(nv,dtype=np.uint8)))
        ok(h.addRows(matrix.shape[0],lower,upper,matrix.nnz,
            matrix.indptr.astype(np.int32),matrix.indices.astype(np.int32),matrix.data.astype(float)))
        if stopped():return []
        status=h.run()
        # A time-limited feasible incumbent is allowed; optimality is not needed.
        sol=h.getSolution()
        if not sol.value_valid:continue
        values=np.asarray(sol.col_value,dtype=float)
        if len(values)!=nv or not np.all(np.isfinite(values)):continue
        rounded=np.rint(values)
        if np.max(np.abs(values-rounded))>1e-6:continue
        ax=matrix.dot(rounded)
        if np.any(ax>upper+1e-6) or np.any(ax<lower-1e-6):continue
        chosen={c:fid for j,(c,fid) in enumerate(columns) if rounded[j]>.5}
        if len(chosen)!=k:continue
        changes=tuple((c,chosen[c]) for c in selected if chosen[c]!=int(solution[c]))
        if len(changes)<3:continue
        delta=sum(float(factors[fid].cost)-float(factors[int(solution[c])].cost) for c,fid in changes)
        if delta>.03*scale+1e-7:continue
        candidates[changes]=delta
    if stopped() or not candidates:return []
    # Fresh private held-out rank sample; never a feasibility certificate.
    sampled={};total=np.zeros(rank_size,dtype=float)
    for c in sorted(node_items):
        if stopped():return []
        old=int(solution[c]);values=np.asarray(factors[old].samples,dtype=float)
        ids=rng.integers(0,len(values)-1,size=rank_size)
        sampled[c,old]=values[ids];total+=sampled[c,old]
        needed={fid for changes in candidates for cid,fid in changes if cid==c}
        for fid in needed:sampled[c,fid]=np.asarray(factors[fid].samples,dtype=float)[ids]
    ranked=[]
    for changes,delta in candidates.items():
        proposal=total.copy()
        for c,fid in changes:proposal+=sampled[c,fid]-sampled[c,int(solution[c])]
        failures=int(np.count_nonzero(proposal>=float(target_tmax)))
        ranked.append(((failures>40,delta if failures<=40 else failures,failures,changes),changes))
    ranked.sort(key=lambda x:x[0])
    return [changes for key,changes in ranked]

class Learner(_U14FinalLearner):
    def snapshot(self):
        out=super().snapshot()
        out.update(version='three-option-scenario128-global-means-ts-v21',
            proposal_repair_scenarios=128,proposal_allowed_sample_failures=0,
            proposal_scenario_binary_indicators=0,
            proposal_sample_constraint='all128_scenarios_satisfied_not_original_certificate')
        return out


# U16: risk-first empiricalCVaR99 auxiliary proposal, never an acceptance evaluator.
_U15FinalLearner=Learner
def _u12_saa_repair(solution,node_items,factors,rng,stopped,target_tmax):
    if stopped():return []
    from scipy import sparse
    hs=_u12_native_highs()
    flex=[c for c in sorted(node_items) if len(node_items[c])>1]
    if len(flex)<3:return []
    sample_size=512;rank_size=4096;k=min(12,len(flex))
    current_cost=sum(float(factors[int(f)].cost) for f in solution)
    scale=max(1.,abs(current_cost));risk_scale=max(1.,abs(float(target_tmax)))
    candidates={}
    for attempt in range(2):
        if stopped():return []
        # Retain U11's private half cost/tail-guided subset rule. For <=12
        # flexible classes this is only a random permutation of every class.
        sampled={};total=np.zeros(rank_size,dtype=float)
        for c in sorted(node_items):
            if stopped():return []
            old=int(solution[c]);values=np.asarray(factors[old].samples,dtype=float)
            ids=rng.integers(0,len(values)-1,size=rank_size)
            sampled[c,old]=values[ids];total+=sampled[c,old]
            if c in flex:
                for fid in node_items[c]:
                    fid=int(fid);sampled[c,fid]=np.asarray(factors[fid].samples,dtype=float)[ids]
        selected=sorted(_cost_tail_subset(solution,node_items,factors,sampled,total,rng,k))
        # Independent training draws for empiricalCVaR99; only original oracle certifies chance feasibility.
        training={};outside=np.zeros(sample_size,dtype=float)
        for c in sorted(node_items):
            if stopped():return []
            old=int(solution[c]);values=np.asarray(factors[old].samples,dtype=float)
            ids=rng.integers(0,len(values)-1,size=sample_size)
            if c not in selected:outside+=values[ids]
            else:
                for fid in node_items[c]:
                    fid=int(fid);training[c,fid]=np.asarray(factors[fid].samples,dtype=float)[ids]
        columns=[(c,int(fid)) for c in selected for fid in node_items[c]]
        n=len(columns);nv=n+1+sample_size
        weights=np.column_stack([training[c,fid] for c,fid in columns])
        group=np.zeros((k,nv),dtype=float)
        for row,c in enumerate(selected):
            for col,(cid,fid) in enumerate(columns):
                if cid==c:group[row,col]=1.
        unchanged=np.array([float(fid==int(solution[c])) for c,fid in columns]+[0.]*(1+sample_size))
        local_cost=np.array([float(factors[fid].cost) for c,fid in columns]+[0.]*(1+sample_size))
        old_local=sum(float(factors[int(solution[c])].cost) for c in selected)
        scenarios=sparse.hstack([sparse.csr_matrix(weights/risk_scale),sparse.csr_matrix(-np.ones((sample_size,1))),-sparse.eye(sample_size)],format='csr')
        matrix=sparse.vstack([sparse.csr_matrix(group),scenarios,
            sparse.csr_matrix(unchanged[None,:]),sparse.csr_matrix(local_cost[None,:]/scale)],format='csr')
        lower=np.r_[np.ones(k),np.full(sample_size+2,-hs.kHighsInf)]
        upper=np.r_[np.ones(k),-outside/risk_scale,
            k-3,(old_local+.03*scale)/scale]
        if stopped():return []
        h=hs.Highs()
        def ok(status):
            if status!=hs.HighsStatus.kOk:raise RuntimeError('native repair model/options rejected: '+str(status))
        for name,value in [('output_flag',False),('threads',1),('parallel','off'),
                ('time_limit',.5),('mip_rel_gap',0.),('random_seed',int(rng.integers(1,2147483647)))]:
            ok(h.setOptionValue(name,value))
        if h.getOptionValue('threads')[1]!=1 or h.getOptionValue('parallel')[1]!='off':
            raise RuntimeError('native repair must use one thread')
        ids=np.arange(nv,dtype=np.int32)
        ok(h.addVars(nv,np.r_[np.zeros(n),-hs.kHighsInf,np.zeros(sample_size)],np.r_[np.ones(n),hs.kHighsInf,np.full(sample_size,hs.kHighsInf)]))
        objective=np.r_[1e-8*local_cost[:n]/scale,1.,np.full(sample_size,1./(.01*sample_size))]
        ok(h.changeColsCost(nv,ids,objective))
        ok(h.changeColsIntegrality(n,ids[:n],np.ones(n,dtype=np.uint8)))
        ok(h.addRows(matrix.shape[0],lower,upper,matrix.nnz,
            matrix.indptr.astype(np.int32),matrix.indices.astype(np.int32),matrix.data.astype(float)))
        if stopped():return []
        status=h.run()
        # A time-limited feasible incumbent is allowed; optimality is not needed.
        sol=h.getSolution()
        if not sol.value_valid:continue
        values=np.asarray(sol.col_value,dtype=float)
        if len(values)!=nv or not np.all(np.isfinite(values)):continue
        rounded=values.copy();rounded[:n]=np.rint(values[:n])
        if np.max(np.abs(values[:n]-rounded[:n]))>1e-6:continue
        ax=matrix.dot(rounded)
        if np.any(ax>upper+1e-6) or np.any(ax<lower-1e-6):continue
        chosen={c:fid for j,(c,fid) in enumerate(columns) if rounded[j]>.5}
        if len(chosen)!=k:continue
        changes=tuple((c,chosen[c]) for c in selected if chosen[c]!=int(solution[c]))
        if len(changes)<3:continue
        delta=sum(float(factors[fid].cost)-float(factors[int(solution[c])].cost) for c,fid in changes)
        if delta>.03*scale+1e-7:continue
        candidates[changes]=delta
    if stopped() or not candidates:return []
    # Fresh private held-out rank sample; never a feasibility certificate.
    sampled={};total=np.zeros(rank_size,dtype=float)
    for c in sorted(node_items):
        if stopped():return []
        old=int(solution[c]);values=np.asarray(factors[old].samples,dtype=float)
        ids=rng.integers(0,len(values)-1,size=rank_size)
        sampled[c,old]=values[ids];total+=sampled[c,old]
        needed={fid for changes in candidates for cid,fid in changes if cid==c}
        for fid in needed:sampled[c,fid]=np.asarray(factors[fid].samples,dtype=float)[ids]
    ranked=[]
    for changes,delta in candidates.items():
        proposal=total.copy()
        for c,fid in changes:proposal+=sampled[c,fid]-sampled[c,int(solution[c])]
        failures=int(np.count_nonzero(proposal>=float(target_tmax)))
        ranked.append(((failures>40,delta if failures<=40 else failures,failures,changes),changes))
    ranked.sort(key=lambda x:x[0])
    return [changes for key,changes in ranked]

class Learner(_U15FinalLearner):
    def snapshot(self):
        out=super().snapshot()
        out.update(version='three-option-cvar512-global-means-ts-v22',
            proposal_rule='native_highs_cvar99_risk_first',proposal_repair_scenarios=512,
            proposal_allowed_sample_failures=None,proposal_scenario_binary_indicators=0,
            proposal_sample_constraint='cost_and_min3_only_cvar_is_auxiliary_objective',
            proposal_cvar_level=.99,proposal_risk_objective='empirical_z_plus_mean_excess_over_one_minus_beta',
            proposal_cost_tiebreak_weight=1e-8,proposal_auxiliary_continuous_variables=513,
            proposal_scenario_rows='normalized_total_minus_z_minus_excess_le_zero')
        return out


# U17 isolated draft: exact-two bounded-cost CVaR diversification.
_U16FinalLearner=Learner
def _u12_saa_repair(solution,node_items,factors,rng,stopped,target_tmax):
    if stopped():return []
    from scipy import sparse
    hs=_u12_native_highs()
    flex=[c for c in sorted(node_items) if len(node_items[c])>1]
    if len(flex)<2:return []
    sample_size=512;rank_size=4096;k=min(12,len(flex))
    current_cost=sum(float(factors[int(f)].cost) for f in solution)
    scale=max(1.,abs(current_cost));risk_scale=max(1.,abs(float(target_tmax)))
    candidates={}
    for attempt in range(2):
        if stopped():return []
        # Retain U11's private half cost/tail-guided subset rule. For <=12
        # flexible classes this is only a random permutation of every class.
        sampled={};total=np.zeros(rank_size,dtype=float)
        for c in sorted(node_items):
            if stopped():return []
            old=int(solution[c]);values=np.asarray(factors[old].samples,dtype=float)
            ids=rng.integers(0,len(values)-1,size=rank_size)
            sampled[c,old]=values[ids];total+=sampled[c,old]
            if c in flex:
                for fid in node_items[c]:
                    fid=int(fid);sampled[c,fid]=np.asarray(factors[fid].samples,dtype=float)[ids]
        selected=sorted(_cost_tail_subset(solution,node_items,factors,sampled,total,rng,k))
        # Independent training draws for empiricalCVaR99; only original oracle certifies chance feasibility.
        training={};outside=np.zeros(sample_size,dtype=float)
        for c in sorted(node_items):
            if stopped():return []
            old=int(solution[c]);values=np.asarray(factors[old].samples,dtype=float)
            ids=rng.integers(0,len(values)-1,size=sample_size)
            if c not in selected:outside+=values[ids]
            else:
                for fid in node_items[c]:
                    fid=int(fid);training[c,fid]=np.asarray(factors[fid].samples,dtype=float)[ids]
        columns=[(c,int(fid)) for c in selected for fid in node_items[c]]
        n=len(columns);nv=n+1+sample_size
        weights=np.column_stack([training[c,fid] for c,fid in columns])
        group=np.zeros((k,nv),dtype=float)
        for row,c in enumerate(selected):
            for col,(cid,fid) in enumerate(columns):
                if cid==c:group[row,col]=1.
        unchanged=np.array([float(fid==int(solution[c])) for c,fid in columns]+[0.]*(1+sample_size))
        local_cost=np.array([float(factors[fid].cost) for c,fid in columns]+[0.]*(1+sample_size))
        old_local=sum(float(factors[int(solution[c])].cost) for c in selected)
        scenarios=sparse.hstack([sparse.csr_matrix(weights/risk_scale),sparse.csr_matrix(-np.ones((sample_size,1))),-sparse.eye(sample_size)],format='csr')
        matrix=sparse.vstack([sparse.csr_matrix(group),scenarios,
            sparse.csr_matrix(unchanged[None,:]),sparse.csr_matrix(local_cost[None,:]/scale)],format='csr')
        lower=np.r_[np.ones(k),np.full(sample_size+2,-hs.kHighsInf)]
        lower[k+sample_size]=k-2
        upper=np.r_[np.ones(k),-outside/risk_scale,
            k-2,(old_local+.03*scale)/scale]
        if stopped():return []
        h=hs.Highs()
        def ok(status):
            if status!=hs.HighsStatus.kOk:raise RuntimeError('native repair model/options rejected: '+str(status))
        for name,value in [('output_flag',False),('threads',1),('parallel','off'),
                ('time_limit',.5),('mip_rel_gap',0.),('random_seed',int(rng.integers(1,2147483647)))]:
            ok(h.setOptionValue(name,value))
        if h.getOptionValue('threads')[1]!=1 or h.getOptionValue('parallel')[1]!='off':
            raise RuntimeError('native repair must use one thread')
        ids=np.arange(nv,dtype=np.int32)
        ok(h.addVars(nv,np.r_[np.zeros(n),-hs.kHighsInf,np.zeros(sample_size)],np.r_[np.ones(n),hs.kHighsInf,np.full(sample_size,hs.kHighsInf)]))
        objective=np.r_[1e-8*local_cost[:n]/scale,1.,np.full(sample_size,1./(.01*sample_size))]
        ok(h.changeColsCost(nv,ids,objective))
        ok(h.changeColsIntegrality(n,ids[:n],np.ones(n,dtype=np.uint8)))
        ok(h.addRows(matrix.shape[0],lower,upper,matrix.nnz,
            matrix.indptr.astype(np.int32),matrix.indices.astype(np.int32),matrix.data.astype(float)))
        if stopped():return []
        status=h.run()
        # A time-limited feasible incumbent is allowed; optimality is not needed.
        sol=h.getSolution()
        if not sol.value_valid:continue
        values=np.asarray(sol.col_value,dtype=float)
        if len(values)!=nv or not np.all(np.isfinite(values)):continue
        rounded=values.copy();rounded[:n]=np.rint(values[:n])
        if np.max(np.abs(values[:n]-rounded[:n]))>1e-6:continue
        ax=matrix.dot(rounded)
        if np.any(ax>upper+1e-6) or np.any(ax<lower-1e-6):continue
        chosen={c:fid for j,(c,fid) in enumerate(columns) if rounded[j]>.5}
        if len(chosen)!=k:continue
        changes=tuple((c,chosen[c]) for c in selected if chosen[c]!=int(solution[c]))
        if len(changes)!=2:continue
        delta=sum(float(factors[fid].cost)-float(factors[int(solution[c])].cost) for c,fid in changes)
        if delta>.03*scale+1e-7:continue
        candidates[changes]=delta
    if stopped() or not candidates:return []
    # Fresh private held-out rank sample; never a feasibility certificate.
    sampled={};total=np.zeros(rank_size,dtype=float)
    for c in sorted(node_items):
        if stopped():return []
        old=int(solution[c]);values=np.asarray(factors[old].samples,dtype=float)
        ids=rng.integers(0,len(values)-1,size=rank_size)
        sampled[c,old]=values[ids];total+=sampled[c,old]
        needed={fid for changes in candidates for cid,fid in changes if cid==c}
        for fid in needed:sampled[c,fid]=np.asarray(factors[fid].samples,dtype=float)[ids]
    ranked=[]
    for changes,delta in candidates.items():
        proposal=total.copy()
        for c,fid in changes:proposal+=sampled[c,fid]-sampled[c,int(solution[c])]
        failures=int(np.count_nonzero(proposal>=float(target_tmax)))
        ranked.append(((failures>40,delta if failures<=40 else failures,failures,changes),changes))
    ranked.sort(key=lambda x:x[0])
    return [changes for key,changes in ranked]

class Learner(_U16FinalLearner):
    def snapshot(self):
        out=super().snapshot()
        out.update(version='three-option-cvar512-exact2-global-means-ts-v23',
            proposal_rule='native_highs_cvar99_exact_two',
            proposal_min_changed_classes=2,proposal_max_changed_classes=2,
            proposal_sample_constraint='cost_and_exact2_only_cvar_is_auxiliary_objective',
            action_labels=['original_single_nearby','native_cvar_exact2_repair','identity_keep_current'])
        return out


# U18: retain cumulative gain/time, use only recent completed-option successes
# for the Beta posterior. No new action, source initialization or RNG call.
_U17FinalLearner=Learner
class Learner(_U17FinalLearner):
    def __init__(self,seed,config=None):
        super().__init__(seed,config)
        self.success_window=[]
        self.success_window_counts=np.zeros((3,3),dtype=int)
        self.success_window_positive_counts=np.zeros((3,3),dtype=int)
        self.success_window_evictions=0

    def settle(self,cost,terminal=False,now=None):
        size=len(self.trace)
        super().settle(cost,terminal=terminal,now=now)
        if self.family!='rl' or len(self.trace)==size:return
        assert len(self.trace)==size+1
        w=self.trace[-1];action=int(w['action']);positive=int(w['reward']>1e-12)
        assert w['state']==0
        self.success_window.append((action,positive))
        self.success_window_counts[0,action]+=1
        self.success_window_positive_counts[0,action]+=positive
        if len(self.success_window)>256:
            old_action,old_positive=self.success_window.pop(0)
            self.success_window_counts[0,old_action]-=1
            self.success_window_positive_counts[0,old_action]-=old_positive
            self.success_window_evictions+=1
        self.alpha[:]=1.;self.beta[:]=9.
        self.alpha+=self.success_window_positive_counts
        self.beta+=self.success_window_counts-self.success_window_positive_counts

    def snapshot(self):
        out=super().snapshot()
        out.update(version='three-option-cvar2-success-window256-ts-v24',
            credit_retention='cumulative_credit_with_sliding_success_posterior',
            success_estimator='beta_last_256_completed_options',
            posterior_memory_clock='completed_options_global_within_run',
            posterior_window_size=256,
            success_window_entries=[list(x) for x in self.success_window],
            success_window_counts=self.success_window_counts.tolist(),
            success_window_positive_counts=self.success_window_positive_counts.tolist(),
            success_window_evictions=self.success_window_evictions,
            gain_and_duration_history='cumulative_within_run_not_windowed',
            posterior_expiration_does_not_reset_cumulative_counters=True)
        return out
