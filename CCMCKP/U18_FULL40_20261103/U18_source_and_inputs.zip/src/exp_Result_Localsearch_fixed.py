"""Command-line runner for DDALS_fixed.

The author's original exp_Result_Localsearch.py is preserved unchanged.
DDALS_fixed uses the same corrected probability evaluator and corrected Factor
resampling as DDTS-v1, while retaining the original DDALS search structure.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import random
import re
import sys
import time
from statistics import mean, pstdev

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.exp_Result_TabuSearch import resolve_instance_dir, repo_relative, choose_evaluator, known_gurobi
from src.functions.func_cl_estimator_corrected import factorization_list
from src.functions.func_localsearch_cp_corrected import Construct_Procedure, NoFeasibleInitialSolution
from src.functions.func_solution_factor_corrected import Statistic_factor, Solution_Evaluation, solution_cost
from src.functions.func_localsearch_fixed import Local_Search_DD


def parse_param(instance_dir):
    numbers = re.findall(r"\d+", instance_dir.name)
    return numbers[:3]


def gap_percent(cost, optimum):
    if optimum is None or abs(float(optimum)) < 1e-15:
        return None
    gap = (float(cost) - float(optimum)) / float(optimum) * 100.0
    return 0.0 if abs(gap) < 1e-10 else gap


def run_one(instance_dir, tmax, p0, lambda_value, max_iter, mc_samples, seed, gurobi_optimum):
    np.random.seed(seed)
    random.seed(seed)
    param = parse_param(instance_dir)
    eval_func, evaluator_name = choose_evaluator(param)
    quick_check = factorization_list(int(param[2]), int(param[0]), p0, 10, 50)
    Aw, Au, Av, factors = Statistic_factor(param, lambda_value, repo_relative(instance_dir))

    start = time.perf_counter()
    cp = Construct_Procedure(eval_func, Aw, Au, factors, p0, tmax, param, mc_samples, quick_check)
    out = Local_Search_DD(eval_func, cp, Av, factors, p0, tmax, param, max_iter, mc_samples, quick_check)
    runtime = time.perf_counter() - start

    # Variant 0 is the original DDALS minimum-cost output.
    solution0 = out[0]
    cost = float(solution0[0])
    search_p = float(solution0[1])
    solution = [int(v) for v in solution0[2]]
    validation_p = Solution_Evaluation(eval_func, solution, tmax, factors, p0, param, mc_samples, quick_check)
    eval_count = int(out[4]) + 1
    check_cost = solution_cost(solution, factors)
    if abs(check_cost - cost) > 1e-9:
        raise AssertionError("DDALS_fixed objective validation failed")

    return {
        "algorithm": "DDALS_fixed",
        "instance": instance_dir.name,
        "Tmax": float(tmax),
        "P0": float(p0),
        "seed": int(seed),
        "solution": solution,
        "cost": cost,
        "probability": float(validation_p),
        "search_probability": search_p,
        "certified_feasible": bool(validation_p + 1e-12 >= p0),
        "evaluation_count": eval_count,
        "runtime_seconds": float(runtime),
        "probability_evaluator": evaluator_name,
        "heuristic_gap_percent": gap_percent(cost, gurobi_optimum),
        "gurobi_optimum": gurobi_optimum,
    }


def main():
    ap = argparse.ArgumentParser(description="Run corrected DDALS baseline")
    ap.add_argument("--instance", required=True)
    ap.add_argument("--tmax", type=float, nargs="+", required=True)
    ap.add_argument("--p0", type=float, default=0.99)
    ap.add_argument("--lambda-value", type=float, default=5.0)
    ap.add_argument("--max-iter", type=int, default=30)
    ap.add_argument("--mc-samples", type=int, default=1_000_000)
    ap.add_argument("--runs", type=int, default=1)
    ap.add_argument("--seed", type=int, default=832273)
    ap.add_argument("--output-dir", default="result/DDALS_fixed")
    args = ap.parse_args()

    instance_dir = resolve_instance_dir(args.instance)
    outdir = Path(args.output_dir)
    if not outdir.is_absolute():
        outdir = REPO_ROOT / outdir
    outdir.mkdir(parents=True, exist_ok=True)

    summary_rows = []
    all_rows = []
    for tmax in args.tmax:
        ref = known_gurobi(instance_dir.name, float(tmax), float(args.p0))
        rows = []
        for r in range(args.runs):
            seed = args.seed + r
            try:
                row = run_one(
                    instance_dir, float(tmax), float(args.p0), float(args.lambda_value),
                    int(args.max_iter), int(args.mc_samples), int(seed), ref
                )
            except NoFeasibleInitialSolution as exc:
                row = {
                    "algorithm": "DDALS_fixed",
                    "instance": instance_dir.name,
                    "Tmax": float(tmax),
                    "P0": float(args.p0),
                    "seed": int(seed),
                    "solution": [],
                    "cost": None,
                    "probability": 0.0,
                    "search_probability": 0.0,
                    "certified_feasible": False,
                    "evaluation_count": 0,
                    "runtime_seconds": 0.0,
                    "probability_evaluator": None,
                    "heuristic_gap_percent": None,
                    "gurobi_optimum": ref,
                    "error": str(exc),
                }
            rows.append(row)
            all_rows.append(row)
            print(f"DDALS_fixed {instance_dir.name} Tmax={tmax:g} run={r}: cost={row['cost']} p={row['probability']}")

        feasible = [x for x in rows if x["certified_feasible"]]
        costs = [x["cost"] for x in feasible]
        gaps = [x["heuristic_gap_percent"] for x in feasible if x["heuristic_gap_percent"] is not None]
        summary_rows.append({
            "algorithm": "DDALS_fixed",
            "instance": instance_dir.name,
            "Tmax": float(tmax),
            "P0": float(args.p0),
            "runs": len(rows),
            "feasible_runs": len(feasible),
            "feasibility_rate": len(feasible)/len(rows) if rows else 0.0,
            "best": min(costs) if costs else None,
            "average": mean(costs) if costs else None,
            "std": pstdev(costs) if len(costs)>1 else (0.0 if costs else None),
            "best_gap_percent": min(gaps) if gaps else None,
            "average_gap_percent": mean(gaps) if gaps else None,
            "average_runtime_seconds": mean([x["runtime_seconds"] for x in feasible]) if feasible else None,
            "average_evaluation_count": mean([x["evaluation_count"] for x in feasible]) if feasible else None,
            "gurobi_optimum": ref,
            "max_iter": int(args.max_iter),
        })

    with (outdir / "ddals_fixed_runs.json").open("w", encoding="utf-8") as f:
        json.dump(all_rows, f, ensure_ascii=False, indent=2)
    with (outdir / "ddals_fixed_summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary_rows, f, ensure_ascii=False, indent=2)

    if summary_rows:
        with (outdir / "ddals_fixed_summary.csv").open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(summary_rows[0].keys()))
            w.writeheader(); w.writerows(summary_rows)


if __name__ == "__main__":
    main()
