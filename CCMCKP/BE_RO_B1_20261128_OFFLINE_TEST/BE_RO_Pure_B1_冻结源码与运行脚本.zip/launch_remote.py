from pathlib import Path
import json,subprocess,sys,os,time
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');F=B/'work/be_ro_b1_20261128/full40'
assert Path.cwd()==B and (F/'FROZEN.json').exists() and not (F/'LAUNCH_REQUEST.json').exists() and not (F/'LAUNCH.json').exists()
with (F/'controller.log').open('xb') as log:
 p=subprocess.Popen([sys.executable,str(F/'controller.py')],cwd=F,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,close_fds=True)
(F/'LAUNCH_REQUEST.json').write_text(json.dumps({'pid':p.pid,'time':time.time()}));time.sleep(1)
assert p.poll() is None,(F/'controller.log').read_text()
assert os.readlink('/proc/%d/fd/0'%p.pid)=='/dev/null' and os.getsid(p.pid)==p.pid
print(json.dumps({'status':'STARTED_OFFLINE','pid':p.pid,'session':os.getsid(p.pid),'stdin':'/dev/null','parent':int(next(x.split()[1] for x in Path('/proc/%d/status'%p.pid).read_text().splitlines() if x.startswith('PPid:'))),'registered_runs':1200,'max_workers':60,'server_root':str(F)}))
