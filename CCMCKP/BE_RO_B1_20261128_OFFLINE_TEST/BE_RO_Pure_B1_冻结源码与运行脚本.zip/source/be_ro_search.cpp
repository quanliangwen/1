#include "search.hpp"
#include "be_ro_solver.hpp"
#include "isolated_native.hpp"
namespace s10 {
Json Search::be_ro_run(){
 BEROWitness w(instance,options.capacity_text);BEROSolver solver(instance,w,options.seed);
 PolishFFT fft(instance.samples,instance.groups,options.capacity,8192,12);
 double epsilon=.0015,mipseconds=0,poolseconds=0,nativeseconds=0;
 std::set<Selection> tried;
 be_ro_log={{"model","BE_RO_Pure_B1"},{"beta","19/20"},{"K",5},{"tail_count",w.tail_count},{"samples_per_item",instance.sample_count},{"items",w.items},{"radius_is_probability_guarantee",false},{"radius_localization_is_heuristic",true},{"CDF_solution_probability_monotonicity_claim",false},{"external_MIPstarts",false},{"historical_solution_inputs",false},{"local_search_enabled",false},{"private_FFT_is_certificate",false},{"initialization","own BE-MISOCP model only; no external initial solution"},{"queries",Json::array()},{"candidates",Json::array()},{"native_calls",Json::array()},{"calibration",Json::array()},{"timing",{{"load_and_model",now()-started}}}};
 auto query=[&](mpq_class omega,double seconds,int count,bool feasibility,bool fine){
  check_budget();const double begin=now();if(begin>=deadline)throw BudgetExpired();
  double cut=INFINITY;if(fine&&pool.size()>=5){std::set<Selection>keys;for(const auto&q:pool)keys.insert(q.first);auto order=cost_order(keys);cut=pool.at(order[4]).cost-1e-6;}
  Json log;auto all=solver.solve(omega,seconds,count,feasibility,fine?tried:std::set<Selection>{},cut,log);
  mipseconds+=now()-begin;if(fine)poolseconds+=now()-begin;++models;log["start"]=begin-started;log["finish"]=now()-started;log["phase"]=fine?"critical_pool":feasibility?"resource_radius":"private_calibration";log["returned"]=Json::array();Groups good;
  for(const auto&s:all){auto proof=w.evaluate(s,omega);log["returned"].push_back(proof);if(proof["robust_feasible"].get<bool>())good.push_back(s);}
  be_ro_log["queries"].push_back(log);return std::make_pair(good,log.value("proven_infeasible",false));
 };
 auto kth=[&]()->double{if(pool.size()<5)return INFINITY;std::set<Selection>keys;for(const auto&q:pool)keys.insert(q.first);return pool.at(cost_order(keys)[4]).cost;};
 auto certify=[&](const Selection&s,const mpq_class&omega,const Json&proof,double score){
  if(tried.count(s)||pool.count(s))return;const double cutoff=kth()-1e-6;
  Json rec={{"selection",s},{"cost",instance.cost_of(s)},{"omega",omega.get_str()},{"witness",proof},{"private_probability",score},{"epsilon_before",epsilon},{"Kth_cost_before",std::isfinite(kth())?Json(kth()):Json(nullptr)},{"start",now()-started}};
  if(instance.cost_of(s)>=cutoff){rec["decision"]="dynamic_cost_cutoff";be_ro_log["candidates"].push_back(rec);return;}
  if(score<.99-epsilon){rec["decision"]="private_FFT_rejected";be_ro_log["candidates"].push_back(rec);return;}
  if(!proof["robust_feasible"].get<bool>())throw std::logic_error("Uncertified BE candidate");
  check_budget();const double begin=now();if(begin>=deadline)throw BudgetExpired();tried.insert(s);
  const double end=std::min(begin+90.,started+options.seconds-30.);
  const int oldcalls=oracle.calls;const double oldseconds=oracle.seconds;
  auto child=isolated_native(end,[&](){
   // Only this run's child: allow an already-started call to finish after 480s.
   deadline=started+options.seconds-30.;phase_deadline=end;last_save=now()+1e9;
   bool expired=false;double value=0;try{value=native_check(s,"BE_RO_Pure");}catch(const BudgetExpired&){expired=true;}
   Json z={{"expired",expired},{"value",value},{"calls_delta",oracle.calls-oldcalls},{"seconds_delta",oracle.seconds-oldseconds},{"state",pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown"}};
   if(pool.count(s))z["certificate"]=pool.at(s).certificate.json(s);else if(infeasible_proofs.count(s))z["certificate"]=infeasible_proofs.at(s).json(s);return z;
  });
  Json call={{"selection",s},{"cost",instance.cost_of(s)},{"start",begin-started},{"finish",now()-started},{"hard_timeout",child.timeout},{"elapsed",child.elapsed},{"state","unknown"},{"omega",omega.get_str()},{"private_probability",score},{"epsilon_before",epsilon},{"slice_deadline",end-started}};
  if(!child.timeout){auto&z=child.payload;call["state"]=z["state"];call["expired"]=z["expired"];oracle.calls+=z["calls_delta"].get<int>();oracle.seconds+=z["seconds_delta"].get<double>();
   if(z.contains("certificate")){auto c=z["certificate"];call["certificate"]=c;Certificate cert{mpz_class(c["lower_numerator"].get<std::string>()),mpz_class(c["upper_numerator"].get<std::string>()),mpz_class(c["denominator"].get<std::string>()),c["bins"].get<int>(),c["certificate_seconds"].get<double>()};
    if(z["state"]=="accepted"){accept(s,"BE_RO_Pure",cert);epsilon=std::max(epsilon,std::max(.001,.99-score));}
    else if(z["state"]=="infeasible"){infeasible_proofs.insert_or_assign(s,cert);decisions[s]=cert.probability();}
   }
  }
  nativeseconds+=now()-begin;call["epsilon_after"]=epsilon;be_ro_log["native_calls"].push_back(call);rec["decision"]=call["state"];rec["finish"]=now()-started;be_ro_log["candidates"].push_back(rec);
 };
 try{
  const mpq_class cap=w.cap(instance.groups);mpq_class lo=0,hi=cap;
  be_ro_log["omega_cap"]=cap.get_str();bool unknown=false;
  // Finite-time feasibility is three-valued. Unknown never moves a bound.
  for(int k=0;k<10&&hi>lo;++k){mpq_class mid=(lo+hi)/2;mid.canonicalize();auto q=query(mid,.5,1,true,false);
   if(!q.first.empty())lo=mid;else if(q.second)hi=mid;else{unknown=true;break;}}
  mpq_class maximum=lo;be_ro_log["omega_resource_lower"]=lo.get_str();be_ro_log["omega_resource_upper"]=hi.get_str();be_ro_log["resource_search_unknown"]=unknown;be_ro_log["omega_max_is_exact_claim"]=false;
  lo=0;hi=maximum;Selection prevlo,prevhi;
  while(hi>lo&&maximum>0&&(hi-lo)/maximum>mpq_class(1,100)){
   mpq_class mid=(lo+hi)/2;mid.canonicalize();auto found=query(mid,2.,1,false,false);
   if(found.first.empty())break;auto s=found.first.front();double p=fft.probability(s);
   be_ro_log["calibration"].push_back({{"omega",mid.get_str()},{"selection",s},{"private_probability",p},{"original_CDF_calls",0}});
   if(p>=.99){hi=mid;prevhi=s;}else{lo=mid;prevlo=s;}if(!prevlo.empty()&&prevlo==prevhi)break;
  }
  const mpq_class star=hi;mpq_class delta=std::max(mpq_class(hi-lo),mpq_class(star/50));delta.canonicalize();
  be_ro_log["omega_resource_used"]=maximum.get_str();be_ro_log["omega_star"]=star.get_str();be_ro_log["delta"]=delta.get_str();
  std::vector<mpq_class>points{star,std::max(mpq_class(0),mpq_class(star-delta)),std::min(maximum,mpq_class(star+delta))};
  be_ro_log["critical_points"]=Json::array();for(auto x:points){x.canonicalize();be_ro_log["critical_points"].push_back(x.get_str());}
  for(int round=0;round<4;++round){if(round==3&&pool.size()>=5)break;mpq_class omega=round<3?points[round]:star;
   auto found=query(omega,3.,25,false,true);
   for(const auto&s:found.first){check_budget();auto proof=w.evaluate(s,omega);double p=fft.probability(s);certify(s,omega,proof,p);}
  }
 }catch(const BudgetExpired&){be_ro_log["partial"]="global_new_call_deadline";}
 phase_records.push_back({{"phase","initialization"},{"own_raw_sample_initialization",true},{"best_before",nullptr},{"best_after",best?Json(best->cost):Json(nullptr)},{"elapsed",now()-started},{"candidates_added",pool.size()}});
 be_ro_log["epsilon_fft_final"]=epsilon;be_ro_log["timing"]["bero_bisect_misocp"]=mipseconds-poolseconds;be_ro_log["timing"]["bero_pool_misocp"]=poolseconds;be_ro_log["timing"]["bero_native_cdf"]=nativeseconds;be_ro_log["private_fft_seconds"]=fft.seconds;be_ro_log["stop_seconds"]=now()-started;model_seconds=mipseconds;
 return save("completed");
}
void Search::be_ro_save_fields(Json&data){
 if(options.search_flow!="be_ro_pure")return;
 be_ro_log["certified_pool"]=Json::array();for(const auto&q:pool)be_ro_log["certified_pool"].push_back(q.second.json());
 data["BE_RO_model"]=be_ro_log;data["config"]["LSS_reserve_seconds"]=120.;data["config"]["search_launch_deadline_seconds"]=480.;
 data["config"]["maximum_started_native_finish_seconds"]=570.;data["config"]["native_single_call_seconds"]=90.;
}
}
