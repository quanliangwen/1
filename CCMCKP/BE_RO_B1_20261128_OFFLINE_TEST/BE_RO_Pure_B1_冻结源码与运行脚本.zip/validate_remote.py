from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import subprocess,json,time,os,sys,copy,hashlib,pickle,itertools
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b1_20261128'
assert Path.cwd()==B and not (H/'full40').exists()
sys.path.insert(0,str(H));from be_reader import verify_be,moments,verify_proof
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Freeze boundaries: unchanged native functions and 28 inherited components.
inherit=read(H/'INHERITANCE.json')
for n,h in inherit['unchanged_files'].items():assert sha(H/'source'/n)==h,n
old=(B/'work/r07_adaptive_20261127/source/search.cpp').read_text();new=(H/'source/search.cpp').read_text()
for key in ['double Search::native_check','Json Search::shortlist','void Search::final_check']:
 def span(s):i=s.index(key);return s[i:s.index('\n}',i)+2]
 assert span(old)==span(new),key
small=H/'fixtures/LAB_2_2_30_';small.mkdir(exist_ok=True)
zero=H/'fixtures/LAB_2_2_ZERO30_';zero.mkdir(exist_ok=True)
src=H/'fixtures/LAB_2_2_500_'
for p in src.iterdir():
 if not p.is_file():continue
 if p.name.endswith('_sample.txt'):
  a=p.read_text().split();(small/p.name).write_text('\n'.join(a[k*len(a)//30] for k in range(30))+'\n');(zero/p.name).write_text('0.1\n'*30)
 else:(small/p.name).write_bytes(p.read_bytes());(zero/p.name).write_bytes(p.read_bytes())
def dataset(D):
 g=pickle.loads((D/'node_to_factor.pkl').read_bytes());groups=[g[k] for k in sorted(g)] if isinstance(g,dict) else g
 costs=[float(x) for x in (D/'cost.txt').read_text().split()];samples=[(D/('%d_sample.txt'%j)).read_text().split() for j in range(len(costs))];return groups,costs,samples
checks=[];witnesses=0;tamper=0
for name,cap in [('LAB_3_2_500_','.5'),('LAB_2_2_500_','1.25'),('LAB_2_2_30_','1.25'),('LAB_2_2_ZERO30_','1.25')]:
 D=H/'fixtures'/name;groups,costs,samples=dataset(D);params=moments(samples)
 p=subprocess.run([str(H/'build/be_ro_math_test'),str(D),cap],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=100)
 (H/('math_'+name+'.log')).write_bytes(p.stdout);assert p.returncode==0,p.stdout.decode(errors='replace')[-1500:]
 m=json.loads(p.stdout);assert m['status']=='PASS'
 for j,q in enumerate(m['items']):assert tuple(F(q[k]) for k in ['mu','variance','deviation'])==params[j]
 for t in m['tests']:
  for q in t['witnesses']:verify_proof(q,params,cap);witnesses+=1
 if name=='LAB_2_2_ZERO30_':checks.append({'fixture':name,'math_exhaustive':True});continue
 out=H/'integration'/name;assert not out.exists();start=time.monotonic()
 env=dict(os.environ,CCMCKP_LAUNCH_MONOTONIC=str(start),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
 p=subprocess.run([str(H/'build/ccmckp_s10'),'--instance',str(D),'--capacity',cap,'--seed','1289001','--seconds','600','--out',str(out),'--search-flow','be_ro_pure'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=100,env=env)
 wall=time.monotonic()-start;(H/('integration_'+name+'.log')).write_bytes(p.stdout);assert p.returncode==0,p.stdout.decode(errors='replace')[-1200:]
 raw=read(out/'S10_search.json');res=read(out/'RESULT.json');v=verify_be(raw,groups,costs,samples,cap,params)
 assert res['original_LSS_confidence']>=.99 and res['acceptance_evaluator']=='LSS' and res['lss_sample_index_max']==len(samples[0])-1 and wall<600
 def sparse(s,bins,up):
  poly={0:1}
  for j in s:
   counts=Counter()
   for a in samples[j]:
    f=F(a)*bins/F(cap);k=-((-f.numerator)//f.denominator) if up else f.numerator//f.denominator
    if k<bins:counts[k]+=1
   nxt={}
   for a,v in poly.items():
    for b,w in counts.items():
     if a+b<bins:nxt[a+b]=nxt.get(a+b,0)+v*w
   poly=nxt
  return sum(poly.values())
 for q in raw['BE_RO_model']['certified_pool']:
  c=q['certificate'];assert sparse(q['selection'],c['bins'],True)==int(c['lower_numerator']) and sparse(q['selection'],c['bins'],False)==int(c['upper_numerator'])
 for key,value in [('historical_solution_inputs',True),('external_MIPstarts',True),('local_search_enabled',True),('K',6),('beta','9/10')]:
  bad=copy.deepcopy(raw);bad['BE_RO_model'][key]=value
  try:verify_be(bad,groups,costs,samples,cap,params)
  except AssertionError:tamper+=1
  else:raise AssertionError('Reader accepted metadata tamper')
 q=copy.deepcopy(raw['BE_RO_model']['queries'][0]['returned'][0]);q['worst_upper']=str(F(q['worst_upper'])+1)
 try:verify_proof(q,params,cap)
 except AssertionError:tamper+=1
 else:raise AssertionError('Reader accepted wrong bound')
 checks.append({'fixture':name,'math_exhaustive':True,'whole_seconds':wall,'cost':res['cost'],'independent':v});print(json.dumps(checks[-1]),flush=True)
result={'status':'PASS','tiny_integrations':checks,'exact_KKT_checks':witnesses,'tamper_checks':tamper,'unchanged_native_functions':True,'unchanged_inherited_files':len(inherit['unchanged_files']),'no_extra_large_case_MC':True,'binary_sha256':sha(H/'build/ccmckp_s10')}
(H/'VALIDATION.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
