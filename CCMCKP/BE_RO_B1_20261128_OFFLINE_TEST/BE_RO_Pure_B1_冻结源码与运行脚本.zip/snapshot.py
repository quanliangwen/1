from pathlib import Path
import subprocess,json,hashlib,base64,sys
R=Path(__file__).resolve().parent;E=R/'evidence';E.mkdir(exist_ok=True)
p=subprocess.run([sys.executable,'-X','utf8','E:/codex/S10_EGS_OA_20261123/remote.py',str(R/'monitor_remote.py')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
assert p.returncode==0,p.stdout.decode(errors='replace')[-3000:]
x=json.loads(p.stdout)
for n,q in x.pop('files').items():
 b=base64.b64decode(q['base64']);assert hashlib.sha256(b).hexdigest()==q['sha256'];out=E/n;out.parent.mkdir(parents=True,exist_ok=True)
 if out.exists():assert out.read_bytes()==b,'Immutable collected file changed:'+n
 else:out.write_bytes(b)
(R/'LIVE_STATUS.json').write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:x[k] for k in ['controller_live','process','state','terminal','rc0','failures','controller_log_tail']},ensure_ascii=False))
if 'pilot_summary' in x['metadata']:print(json.dumps({k:v for k,v in x['metadata'].items() if k.startswith('pilot')},ensure_ascii=False))
