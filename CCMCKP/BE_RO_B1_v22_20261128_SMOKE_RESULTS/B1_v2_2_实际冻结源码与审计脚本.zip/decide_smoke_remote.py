from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,statistics
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b1_v22_20261128';F=H/'smoke'
assert Path.cwd()==B
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (F/'FINAL_AUDIT_PROCESS.json').exists(),'Independent audit is still running'
C=read(F/'COMPLETED.json');A=read(F/'FINAL_INDEPENDENT_AUDIT.json');P=read(F/'PROTOCOL.json');gate=P['pre_registered_quality_gate']
assert C['terminal']==35 and C['pending']==0 and read(F/'FINAL_AUDIT_PROCESS.json')['rc']==0
for n,h in P['source_and_binary_pins'].items():assert sha(F/n)==h,n
zero=[];groups=[];quality=True
for o in sorted((read(p) for p in (F/'outcomes').glob('*.json')),key=lambda x:(x['case_index'],x['rep'])):
 root=F/'runs'/o['identity']
 if (root/'S10_search.json').exists():
  raw=read(root/'S10_search.json')
  for qi,q in enumerate(raw['BE_RO_model']['queries']):
   if q.get('solver_status')==9 and q.get('solutions_retained')==0:zero.append({'identity':o['identity'],'query_index':qi})
for c in P['cases']:
 rr=[r for r in A['rows'] if r['case_index']==c['index']];vv=[r for r in rr if r['valid']];values=[r['cost'] for r in vv]
 best=min(values) if values else None;avg=statistics.mean(values) if len(vv)==5 else None
 best_limit=gate['best_cost_max'][str(c['index'])];avg_limit=gate['avg_cost_max'].get(str(c['index']))
 okay=len(vv)==5 and best<=best_limit and (avg_limit is None or avg<=avg_limit);quality=quality and okay
 hit=[r for r in vv if r['cost']==best]
 groups.append({'case_index':c['index'],'instance':c['instance'],'capacity':c['tmax'],'terminal':len(rr),'valid':len(vv),
 'best':best,'avg':avg,'sample_std':statistics.stdev(values) if len(vv)==5 else None,'worst':max(values) if values else None,
 'best_limit':best_limit,'avg_limit':avg_limit,'cost_gate_pass':okay,'best_hit_count':len(hit),
 'first_Best_mean':statistics.mean(r['first_found_seconds'] for r in hit) if len(vv)==5 and hit else None,
 'whole_mean':statistics.mean(r['process_wall_seconds'] for r in rr),'max_whole_seconds':max(r['process_wall_seconds'] for r in rr)})
passed=A['independent_valid']==35 and not A['global_errors'] and not zero and quality and max(r['process_wall_seconds'] for r in A['rows'])<=600
report={'utc':datetime.now(timezone.utc).isoformat(),'pass':passed,'can_launch_full40':passed,'terminal':35,'independent_valid':A['independent_valid'],
 'global_errors':A['global_errors'],'TIME_LIMIT_zero_solution_queries':zero,'groups':groups,'quality_gate':gate,
 'audit_sha256':sha(F/'FINAL_INDEPENDENT_AUDIT.json'),'protocol_sha256':sha(F/'PROTOCOL.json'),
 'source_frozen':True,'failed_repeats_rerun':False,'thresholds_changed_after_results':False}
p=F/'SMOKE_EXPANSION_DECISION.json'
if p.exists():
 old=read(p);assert {k:v for k,v in old.items() if k!='utc'}=={k:v for k,v in report.items() if k!='utc'};report=old
else:p.write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False))
