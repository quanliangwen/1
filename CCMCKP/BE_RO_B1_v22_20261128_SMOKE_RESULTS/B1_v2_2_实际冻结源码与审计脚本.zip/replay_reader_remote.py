from pathlib import Path
import json,hashlib,shutil,subprocess,os
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b1_v22_20261128';F=H/'reader_replay'
assert Path.cwd()==B and not F.exists()
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
F.mkdir();(F/'runs').mkdir();(F/'outcomes').mkdir()
support=['audit_reader.py','linear_reader.py','be_reader.py','native_reader.py','r05_fft_reader.py']
for n in support:shutil.copy2(H/n,F/n)
cases=[];pins={}
for i,d in enumerate(read(H/'VALIDATION.json')['tiny_integrations'],1):
 name=d['fixture'];root=H/'integration'/name;meta=read(root/'S10_search.run.json');raw=read(root/'S10_search.json')
 cases.append({'index':i,'instance':name,'tmax':raw['capacity'] if 'capacity' in raw else ('.5' if i==1 else '1.25')})
 identity='TEST_REPLAY_i%02d_r01'%i
 shutil.copytree(root,F/'runs'/identity)
 for n,h in meta['input_sha256'].items():pins['work/be_ro_b1_v22_20261128/fixtures/'+name+'/'+n]=h
 launch=read(H/('integration_'+name+'_launch.json'))
 out={'identity':identity,'case_index':i,'instance':name,'capacity':cases[-1]['tmax'],'rep':1,'seed':1289921,'arm':'TEST_REPLAY',
 'rc':launch['rc'],'process_wall_seconds':launch['whole_seconds'],'termination_reason':None,'wall_clock_source':'dedicated_wait_thread_from_before_Popen',
 'output_files':{p.relative_to(root).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size} for p in root.rglob('*') if p.is_file()}}
 (F/'outcomes'/(identity+'.json')).write_text(json.dumps(out))
P={'schema':'TEST_REPLAY_NOT_BENCHMARK','cases':cases,'arms':[{'name':'TEST_REPLAY'}],'repetitions':1,'total_runs':4,'seed_base':1289920,
 'input_prefix':'work/be_ro_b1_v22_20261128/fixtures','input_pins':pins,'source_and_binary_pins':{n:sha(F/n) for n in support}}
(F/'PROTOCOL.json').write_text(json.dumps(P));(F/'LAUNCH.json').write_text(json.dumps({'protocol_sha256':sha(F/'PROTOCOL.json')}))
(F/'COMPLETED.json').write_text(json.dumps({'phase':'completed','terminal':4,'pending':0}))
with (F/'AUDIT.log').open('wb') as log:p=subprocess.run(['python3',str(F/'audit_reader.py')],cwd=B,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0,(F/'AUDIT.log').read_text()[-2500:]
A=read(F/'FINAL_INDEPENDENT_AUDIT.json')
result={'status':'PASS' if A['independent_valid']==4 and not A['global_errors'] else 'FAIL','full_record_replays':4,
 'independent_valid':A['independent_valid'],'global_errors':A['global_errors'],'errors':[r['errors'] for r in A['rows']],
 'production_reader_sha256':sha(H/'audit_reader.py'),'reuses_completed_tiny_runs':True,'new_solver_or_MC_runs':0}
(H/'READER_VALIDATION.json').write_text(json.dumps(result,indent=2));print(json.dumps(result));assert result['status']=='PASS'
