from pathlib import Path
import json
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');F=B/'work/be_ro_b1_v22_20261128/smoke'
read=lambda p:json.loads(p.read_text());outs=sorted([read(p) for p in (F/'outcomes').glob('*.json')],key=lambda x:(x['case_index'],x['rep']));assert len(outs)==35
rows=[]
for o in outs:
 if o['case_index'] not in [18,36,38,39]:continue
 H=F/'runs'/o['identity'];raw=read(H/'S10_search.json');m=raw['BE_RO_model'];res=read(H/'RESULT.json');trace=read(H/'ORIGINAL_LSS_DECISION_TRACE.json')
 pool=sorted(m['certified_pool'],key=lambda q:q['cost']);target=pool[0];sel=target['selection']
 stages=[q for q in trace if q.get('selection')==sel]
 rows.append({'identity':o['identity'],'case':o['case_index'],'rep':o['rep'],'certified_min_cost':target['cost'],'output_cost':res['cost'],
 'target_in_shortlist':any(q['selection']==sel for q in raw['candidate_shortlist']),'target_LSS_trace':stages,'seed':o['seed']})
data=json.dumps({'scope':'read-only after all35 terminal; no solver or probability calls','rows':rows},indent=2)
p=F/'LSS_FALLBACK_DIAGNOSTICS.json'
if p.exists():assert p.read_text()==data
else:p.write_text(data)
print(data)
