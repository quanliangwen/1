from pathlib import Path
import json,hashlib,difflib,io,zipfile,base64
R=Path(__file__).resolve().parent;OLD=Path('E:/codex/CCMCKP_BE_RO_B1_v21_20261128')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old={p.relative_to(OLD/'source').as_posix():sha(p) for p in (OLD/'source').rglob('*') if p.is_file()}
new={p.relative_to(R/'source').as_posix():sha(p) for p in (R/'source').rglob('*') if p.is_file()}
changed=sorted(n for n in old if new.get(n)!=old[n]);assert changed==['be_ro_radius_grid.hpp','be_ro_search.cpp','tests/be_ro_radius_grid_test.cpp']
a=(OLD/'source/be_ro_search.cpp').read_text();b=(R/'source/be_ro_search.cpp').read_text();blocks={}
for name,start,end in [('resource_step1','  const double rbegin','  BERadiusGrid grid'),
 ('certification',' // No final LSS',' try{\n  const double rbegin'),('escalation','  mpq_class esc=star;',' }catch(const BudgetExpired&)')]:
 left=a[a.index(start):a.index(end,a.index(start))];right=b[b.index(start):b.index(end,b.index(start))]
 assert left==right,name;blocks[name]=hashlib.sha256(left.encode()).hexdigest()
assert (R/'audit_reader.py').read_bytes()==(OLD/'audit_reader.py').read_bytes()
review={'status':'PASS','changed_existing_source':changed,'unchanged_source_count':len(old)-len(changed),
 'unchanged_blocks':blocks,'unchanged_linear_witness_native_LSS_main':True,'production_audit_main_identical':True,
 'scope':'Static preservation; mathematical equivalence of finite grid and global probability optimum not claimed'}
(R/'STATIC_REVIEW.json').write_text(json.dumps(review,indent=2),encoding='utf-8')
(R/'SOURCE_MANIFEST_SHA256.json').write_text(json.dumps({'scope':'B1-v2.2 actual source','files':new},indent=2),encoding='utf-8')
patch=[]
for n in changed:patch.extend(difflib.unified_diff((OLD/'source'/n).read_text().splitlines(keepends=True),(R/'source'/n).read_text().splitlines(keepends=True),fromfile='a/source/'+n,tofile='b/source/'+n))
(R/'SOURCE_DIFF.patch').write_text(''.join(patch),encoding='utf-8')
P=json.loads((OLD/'FULL_PROTOCOL_TEMPLATE.json').read_text(encoding='utf-8'))
P.update(schema='BE_RO_B1_v22_top1_coarse_local_bisection_v1',arms=[{'name':'BE_RO_B1_V22','flow':'be_ro_pure','gamma':None}],
 seed_base=1286200,seeds=list(range(1286201,1286231)),scope='B1-v2.2 cold starts; source/inputs/results frozen, no LB',
 model='beta=.95,K=5;8coarse top1,6local bisections,.5s;4radius pools1s;10lambda unchanged',
 user_design_sha256=sha(R/'USER_DESIGN.md'),radius_grid={'coarse':8,'local_bisections':6,'bracket_cells':1,'final_width_denominator':512,'scan_seconds':.5,'pool_seconds':1},
 first_wave_gate='Technical integrity only after35-run quality gate; ordinary failures retained')
S=dict(P);S.update(cases=[c for c in P['cases'] if c['index'] in [8,18,28,35,36,38,39]],repetitions=5,total_runs=35,
 seed_base=1286100,seeds=list(range(1286101,1286106)),first_wave_runs=0,first_wave_reps=5,first40_included_in_registered1200=False)
S['pre_registered_quality_gate']={'all35_independently_valid':True,'global_errors_empty':True,'TIME_LIMIT_zero_solution_queries':0,
 'best_cost_max':{'8':11.18515,'18':142.27125,'28':16.42365,'35':194.40,'36':159.28105,'38':196.27715,'39':325.05},
 'avg_cost_max':{'8':11.18515,'18':142.32,'28':16.42365,'35':194.45,'36':159.35,'38':196.35},
 'threshold_basis':'User joint B1-v2.2/B2-v2 design section4.1; frozen prospectively; no changes to previous gates',
 'max_whole_seconds_per_run':600,'no_after_result_relaxation':True}
for n,q in [('FULL_PROTOCOL_TEMPLATE.json',P),('SMOKE_PROTOCOL_TEMPLATE.json',S)]:
 (R/n).write_text(json.dumps(q,ensure_ascii=False,indent=2),encoding='utf-8')
payload=io.BytesIO()
with zipfile.ZipFile(payload,'w',zipfile.ZIP_DEFLATED) as z:
 for p in (R/'source').rglob('*'):
  if p.is_file():z.write(p,'source/'+p.relative_to(R/'source').as_posix())
 for n in ['linear_reader.py','be_reader.py','native_reader.py','r05_fft_reader.py','audit_reader.py','controller.py','validate_remote.py','USER_DESIGN.md','SOURCE_MANIFEST_SHA256.json','STATIC_REVIEW.json','FULL_PROTOCOL_TEMPLATE.json','SMOKE_PROTOCOL_TEMPLATE.json']:z.write(R/n,n)
blob=base64.b64encode(payload.getvalue()).decode()
script='''from pathlib import Path
import json,hashlib,subprocess,zipfile,base64,io,shutil
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b1_v22_20261128';V=B/'work/be_ro_b1_v21_20261128'
assert Path.cwd()==B and not H.exists(),'No overwrite or implicit restart'
assert json.loads((V/'smoke/COMPLETED.json').read_text())['terminal']==35
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  args=(p/'cmdline').read_bytes().split(b'\\0')
  assert not any(any(str(root).encode() in arg for root in [V,H,B/'work/be_ro_b2_20261128']) and any(t in arg for t in [b'controller.py',b'ccmckp_s10',b'audit_reader.py']) for arg in args),'Existing related run'
 except OSError:pass
H.mkdir()
with zipfile.ZipFile(io.BytesIO(base64.b64decode(PAYLOAD))) as z:
 for n in z.namelist():
  p=(H/n).resolve();assert H.resolve() in p.parents;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
for n,h in json.loads((H/'SOURCE_MANIFEST_SHA256.json').read_text())['files'].items():assert hashlib.sha256((H/'source'/n).read_bytes()).hexdigest()==h
for n in ['be_ro_linear.cpp','be_ro_linear.hpp','be_ro_witness.hpp','tests/be_ro_linear_test.cpp']:assert (H/'source'/n).read_bytes()==(V/'source'/n).read_bytes()
shutil.copytree(V/'fixtures',H/'fixtures')
for p in V.glob('linear_math_*.log'):shutil.copy2(p,H/p.name)
commands=[['cmake','-S',str(H/'source'),'-B',str(H/'build'),'-DCMAKE_BUILD_TYPE=Release','-DS10_BUILD_BE_GRID_TESTS=ON','-DS10_GUROBI_INCLUDE='+str(B/'work/egs_oa_validation_20261123/validation_deps'),'-DS10_GUROBI_LIBRARY=/home/junhao/.local/lib/python3.8/site-packages/gurobipy/.libs/libgurobi110.so'],['cmake','--build',str(H/'build'),'--target','ccmckp_s10','be_ro_radius_grid_test','-j','4']]
for i,cmd in enumerate(commands):
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=500);(H/('build_%d.log'%i)).write_bytes(p.stdout)
 print(json.dumps({'step':i,'rc':p.returncode,'tail':p.stdout.decode(errors='replace')[-1800:]}),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
print(json.dumps({'status':'COMPILED','binary_sha256':hashlib.sha256((H/'build/ccmckp_s10').read_bytes()).hexdigest()}))
'''.replace('PAYLOAD',repr(blob))
(R/'prepare_build_remote.py').write_text(script,encoding='utf-8');print(json.dumps(review))
