from pathlib import Path
from fractions import Fraction
import json,hashlib,statistics,csv,shutil,tarfile,zipfile
R=Path(__file__).resolve().parent;E=R/'execution_evidence';X=R/'results_20261128';D=X/'delivery';D.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
A=read(E/'smoke/FINAL_INDEPENDENT_AUDIT.json');G=read(E/'smoke/SMOKE_EXPANSION_DECISION.json');P=read(E/'smoke/PROTOCOL.json');C=read(E/'smoke/COMPLETED.json');V=read(E/'VALIDATION.json');diag=read(E/'smoke/POSTRUN_DIAGNOSTICS.json')
fallback=read(E/'smoke/LSS_FALLBACK_DIAGNOSTICS.json')
f36=sorted([r for r in fallback['rows'] if r['case']==36],key=lambda r:r['rep'])
assert len(f36)==5 and all(r['target_in_shortlist'] and abs(r['certified_min_cost']-159.2809942030811)<1e-10 for r in f36)
assert all(abs(r['output_cost']-159.28099420308112)<1e-10 for r in f36[:3])
assert all(abs(r['output_cost']-159.5777060656604)<1e-10 for r in f36[3:])
assert any(q['stage']=='LSS_final_acceptance' and q['accepted'] is False and q['probability']==.989977 for q in f36[3]['target_LSS_trace'])
assert [q['probability'] for q in f36[4]['target_LSS_trace']]==[.989985,.989979]
assert A['terminal']==35 and not A['global_errors']
groups=G['groups'];passed=G['pass'];failed=[g['case_index'] for g in groups if not g['cost_gate_pass']]
oldpath=R.parent/'CCMCKP_BE_RO_B1_v21_20261128/execution_evidence/smoke/SMOKE_EXPANSION_DECISION.json'
old=read(oldpath);oldgroups={g['case_index']:g for g in old['groups']}
comparison=[]
for g in groups:
 og=oldgroups[g['case_index']]
 comparison.append({'case_index':g['case_index'],'v21_best':og['best'],'v22_best':g['best'],'v21_avg':og['avg'],'v22_avg':g['avg'],
  'v22_minus_v21_avg':g['avg']-og['avg'] if g['avg'] is not None and og['avg'] is not None else None,
  'v21_whole_mean':og['whole_mean'],'v22_whole_mean':g['whole_mean'],'v21_seed_first':1284101,'v22_seed_first':1286101,
  'same_data_and_acceptance':True,'same_run_or_paired_test':False})
state={'stage':'B1_V22_SMOKE_PASSED_WAIT_NEXT' if passed else 'B1_V22_SMOKE_QUALITY_FAILED_NO_FULL40_OR_B2V2',
 'compiled':True,'tiny_validation':'PASS','smoke_terminal':35,'smoke_independent_valid':A['independent_valid'],
 'smoke_gate_pass':passed,'full40_started':False,'B2_v2_started':False,'failed_quality_cases':failed,
 'no_after_result_gate_changes':True,'old_results_unchanged':True,'binary_sha256':V['binary_sha256'],
 'smoke_protocol_sha256':sha(E/'smoke/PROTOCOL.json')}
fmt=lambda x,n=6:'—' if x is None else f'{x:.{n}f}'
lines=['# B1-v2.2粗扫与六轮二分修复测试总结','',
f'已按联合设计先实现B1-v2.2。7个重点算例各5次，共35次完成，{A["independent_valid"]}/35独立有效，global_errors=[]。'+('全部冻结质量门槛通过，可按文档进入后续阶段。' if passed else f'**质量门槛未全部通过，未通过编号：{failed}。因此未启动1200次全量，也未启动以本阶段通过为前提的B2-v2。**'),'',
'## 本轮修改','',
'原始数据、盒-椭球模型、β=.95、K=5、线性λ-Huber求解、208-bit KKT见证、候选归档和认证、3轮兜底及原LSS验收保持。只修改Step2–3：','',
'1. 全局8点粗扫，每点10个λ单解、0.5秒；取所有合法返回解中成本最低的#1判断私人FFT可行性。不是从已经私人可行的向量中取最小。',
'2. 从合格粗点中选最低#1成本的r*（平手小r，全不合格选8），在它左侧一格固定做6轮二分；没有返回解或#1私人FFT≥.99时收hi，否则升lo。全部合法解仍归档。',
'3. Ω*=最终hi，围绕0.97/0.99/1/1.02四点做10解池、1秒，按文档裁剪/去重，保留盒角。', '',
'90个继承源码文件字节未变；资源Step1、认证段、兜底段SHA保持一致，见STATIC_REVIEW.json。代码版本字段B1-v2.2和新轨迹由独立Fraction读者核验。', '',
'“六轮二分”给出半径分辨率Ωmax/512，不证明概率单调、精确临界半径或全局最优。有限λ网格、半径网格及有限解池仍可能遗漏好向量。用户设计文档中的原型干跑成绩仅为输入背景，不能替代本次真实Gurobi测试。', '',
'## 技术验证与运行约束','',
f'25,320项新增几何检查、4个tiny端到端、76项篡改拒绝、11份整数CDF证书核算、4次生产独立审计回放均通过。旧920项行/KKT数学证据在相关源码同SHA下复用，没有重复未变数学测试或额外原生MC。', '',
f'新鲜seed1286101—1286105；并发上限60，实际峰值{C["max_active_observed"]}。完整耗时最大{max(r["process_wall_seconds"] for r in A["rows"]):.6f}秒，均≤600秒。批次历时{C["elapsed_seconds"]:.3f}秒；资源事件{C["resource_events"]}；TIME_LIMIT且SolCount=0的查询{len(G["TIME_LIMIT_zero_solution_queries"])}次。之后的只读独立审计不计入求解器耗时。', '',
'完整耗时包含加载、全部求解和评价、LSS、保存/fsync与退出。外部595秒守护，禁止截断报告为600秒、补跑失败或挑seed。全部起点由本run原始数据生成，没有历史解、外部MIPstart或跨重复输入。LSS≥.99是最终统一验收；私人FFT只服务候选搜索。', '',
'## 35次冒烟结果','',
'|编号|算例|T|有效|Best|5次Avg|样本Std|首次达Best均时(s)|命中次数|完整均时(s)|Best上限|Avg上限|门槛|',
'|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|']
for g in groups:
 lines.append(f'|{g["case_index"]}|{g["instance"].rstrip("_")}|{g["capacity"]:g}|{g["valid"]}/5|{fmt(g["best"])}|{fmt(g["avg"])}|{fmt(g["sample_std"])}|{fmt(g["first_Best_mean"])}|{g["best_hit_count"]}|{fmt(g["whole_mean"])}|{fmt(g["best_limit"],8)}|{fmt(g["avg_limit"],8)}|{"通过" if g["cost_gate_pass"] else "未通过"}|')
lines+=['','Std采用ddof=1。首次达Best均时只平均最终输出成本命中该例本批Best的运行，取该最终向量首次内部CDF认证时间，且随后通过原LSS；完整运行时间另列。5次统计仅为冒烟，不冒称正式30次结果或全局最优。39按文档仅设Best上限，没有添加Avg门槛。', '',
'## 与v2.1已有冒烟的描述性比较','',
'|编号|v2.1 Avg|v2.2 Avg|Avg差（新−旧）|v2.1完整均时(s)|v2.2完整均时(s)|',
'|---:|---:|---:|---:|---:|---:|']
for c in comparison:
 lines.append(f'|{c["case_index"]}|{fmt(c["v21_avg"])}|{fmt(c["v22_avg"])}|{fmt(c["v22_minus_v21_avg"])}|{fmt(c["v21_whole_mean"])}|{fmt(c["v22_whole_mean"])}|')
lines+=['',
'两批不同新鲜seed、各5次，没有混用输出，也不是配对显著性检验。该表只说明本批恢复情况，不据此宣布全40例或统计显著改善。旧门槛与旧结论保持。', '',
'本轮恢复较低成本候选后，仍需按原规则逐个执行CDF认证。特别是编号38，重复1有25次原CDF拒绝、5次接受，完整耗时约211秒。因此候选覆盖恢复不等于整个算法全面加速，应结合上表逐例成本和耗时评估。', '',
'## 半径轨迹与候选覆盖诊断','',
'以下仅为全部35次终末后的只读诊断，不向任何求解器输入旧解。每例列重复1；其余重复完整轨迹见POSTRUN_DIAGNOSTICS.json。', '',
'|编号|r*|最终hi|归档数量|达到Best门槛的归档向量数|这些向量的最终处理|旧B1-v2低成本认证向量是否在本次归档|',
'|---:|---:|---|---:|---:|---|---|']
for d in diag:
 if d['rep']!=1:continue
 prev=d.get('postrun_only_previous_candidate_comparison')
 lines.append(f'|{d["case_index"]}|{d["coarse_r_star"]}|{float(Fraction(d["omega_best"])):.8f}|{d["archive_count"]}|{d["under_best_limit_archive_count"]}|{json.dumps(d["under_best_limit_decisions"],ensure_ascii=False)}|{str(prev["new_archive_contains_same_vector"]) if prev else "无比较"}|')
lines+=['',
'若低成本历史向量在新归档缺失，这是候选覆盖差异；若存在但未通过私人FFT或原CDF，应按实际拒绝原因解释，不能赋予它有效成绩。历史向量只用于事后存在性比对，不是本次初始解，也没有为诊断另跑MC。', '',
'## 编号36：本次Avg未达标的直接原因','',
'本例5次都已自行生成成本159.2809942031的目标向量，通过内部认证并进入shortlist，故本次问题不同于v2.1的候选覆盖缺失。前3次保住目标向量；第4次最终LSS复核为0.989977，未通过.99；第5次初始/池中LSS为0.989985/0.989979，未进入后续目标接受。后两次合法回退到159.5777060657。', '',
'最终5次Avg为159.3996789481，高于159.35，样本波动来自保持原样的LSS筛选与回退链。该解释依据已记录的LSS轨迹，不是新增真实概率计算；没有修改LSS、复抽挑通过或将内部认证成本冒充最终成绩。更好的Best并不保证原LSS下的重复Avg改善。完整逐次证据见LSS_FALLBACK_DIAGNOSTICS.json。', '',
'## 阶段决定','',
('本阶段全部通过，具备继续B1-v2.2全40例各30次以及B2-v2独立代码/冒烟验证的前提；后续仍须相应冻结审计和资源核验。' if passed else '严格遵守文档“B1-v2.2冒烟全部通过后才全量及B2-v2”的顺序。本次代码和原LSS技术检查通过，但质量门槛没有全部恢复，因此保留全部结果，停止条件未满足的后续批次。不悄悄放宽阈值、重跑挑seed或将启动视作改善。'), '',
'## 证据','',
f'- 协议SHA256：`{sha(E/"smoke/PROTOCOL.json")}`。',
f'- 独立审计SHA256：`{sha(E/"smoke/FINAL_INDEPENDENT_AUDIT.json")}`。',
f'- 二进制SHA256：`{V["binary_sha256"]}`。',
f'- 审核文件SHA {A["files_sha_checked"]}项、KKT见证{A["KKT_witnesses_checked"]}项、整数CDF证书{A["native_integer_certificates_checked"]}份。',
'- 随附真实冻结源码、差异、35次统计CSV和明细、全部紧凑证据、冻结门槛和独立审计。旧版本代码、成绩、阈值没有回改。']
(D/'B1_v2_2_六轮二分修复与35次冒烟总结.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
with (D/'B1_v2_2_7例35次冒烟统计.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(groups[0]));w.writeheader();w.writerows(groups)
with (D/'B1_v21_vs_v22_描述性比较.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(comparison[0]));w.writeheader();w.writerows(comparison)
shutil.copy2(oldpath,D/'REFERENCE_v21_SMOKE_DECISION.json')
(D/'B1_v2_2_35次结果与审计明细.json').write_text(json.dumps({'groups':groups,'rows':A['rows'],'gate':G},ensure_ascii=False,indent=2),encoding='utf-8')
for n in ['PROTOCOL.json','FROZEN.json','COMPLETED.json','SMOKE_EXPANSION_DECISION.json','FINAL_INDEPENDENT_AUDIT.json','POSTRUN_DIAGNOSTICS.json','LSS_FALLBACK_DIAGNOSTICS.json']:shutil.copy2(E/'smoke'/n,D/n)
for n in ['VALIDATION.json','READER_VALIDATION.json','SOURCE_MANIFEST_SHA256.json','STATIC_REVIEW.json']:shutil.copy2(E/n,D/n)
for n in ['SOURCE_DIFF.patch','EXECUTION_NOTES.md','USER_DESIGN.md']:shutil.copy2(R/n,D/n)
for p in E.glob('*.tar.gz'):shutil.copy2(p,D/p.name)
sources=read(E/'SOURCE_MANIFEST_SHA256.json')['files']
with zipfile.ZipFile(D/'B1_v2_2_实际冻结源码与审计脚本.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in (R/'source').rglob('*'):
  if p.is_file():
   name=p.relative_to(R/'source').as_posix();assert sha(p)==sources[name];z.write(p,'source/'+name)
 for n in ['linear_reader.py','be_reader.py','native_reader.py','r05_fft_reader.py','audit_reader.py','controller.py','validate_remote.py']:
  if n in P['source_and_binary_pins']:assert sha(R/n)==P['source_and_binary_pins'][n]
  z.write(R/n,n)
 for n in ['prepare_v22.py','replay_reader_remote.py','freeze_smoke_remote.py','launch_smoke_remote.py','decide_smoke_remote.py','diagnose_smoke_remote.py','diagnose_lss_remote.py','collect_smoke_remote.py','download_smoke.py','package_results.py','EXECUTION_NOTES.md','USER_DESIGN.md','SOURCE_MANIFEST_SHA256.json','STATIC_REVIEW.json','SOURCE_DIFF.patch']:z.write(R/n,n)
actual={};manifest=None
full=next(p for p in D.glob('*.tar.gz') if '全部紧凑' in p.name)
with tarfile.open(full) as tar:
 for member in tar:
  data=tar.extractfile(member).read()
  if member.name=='SMOKE_ALL_FILES_SHA256.json':manifest=json.loads(data)
  else:
   assert member.name.startswith('smoke/');actual[member.name[6:]]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
assert manifest==actual
assert len(groups)==7 and sum(g['valid'] for g in groups)==A['independent_valid']
for g in groups:
 rr=[r for r in A['rows'] if r['case_index']==g['case_index'] and r['valid']]
 if len(rr)==5:assert statistics.mean(r['cost'] for r in rr)==g['avg'] and statistics.stdev(r['cost'] for r in rr)==g['sample_std']
qa={'status':'PASS','stage':'FORMAL_COMPLETE','publication_scope':'B1-v2.2 smoke results and source; later tests conditional on frozen gate',
 'all_files_sha_verified':True,'smoke_gate_pass':passed,'source_matches_freeze':True,'full_compact_files_SHA_verified':len(actual)}
(X/'DELIVERY_LOCAL_VERIFIED.json').write_text(json.dumps(qa,indent=2),encoding='utf-8');(D/'DELIVERY_QA.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
(R/'CURRENT_STATUS.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8');(D/'CURRENT_STATUS.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
checks={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in D.iterdir() if p.is_file() and p.name!='CHECKSUMS_SHA256.json'}
assert all(q['bytes']<95*2**20 for q in checks.values())
(D/'CHECKSUMS_SHA256.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
pub=(R/'publish_code.py').read_text(encoding='utf-8').replace("FOLDER='BE_RO_B1_v2_20261128_CODE_ONLY'","FOLDER='BE_RO_B1_v22_20261128_SMOKE_RESULTS'").replace('Prepare B1-v2 lambda-Huber source without compiling or running; wait for B2','Publish B1-v2.2 strict-top1 six-bisection repair,35-run smoke results and frozen source')
(X/'publish_results.py').write_text(pub,encoding='utf-8')
print(json.dumps({'status':'PACKAGED','smoke_gate_pass':passed,'independent_valid':A['independent_valid'],'groups':groups,'files':len(checks)},ensure_ascii=False))
