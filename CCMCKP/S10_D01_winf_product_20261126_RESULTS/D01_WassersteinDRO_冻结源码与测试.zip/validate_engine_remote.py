from pathlib import Path
import json,subprocess,os,time,hashlib
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/d01_winf_product_20261126';assert Path.cwd()==B and not (H/'formal/LAUNCH.json').exists()
report=json.loads((H/'VALIDATION.json').read_text());assert report['status']=='PASS'
for flow in ['block_insurance','block_winf_dro']:
 out=H/'integration_engine60'/flow;assert not out.exists()
 begin=time.monotonic();env=dict(os.environ,CCMCKP_LAUNCH_MONOTONIC=str(begin),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',BLIS_NUM_THREADS='1')
 p=subprocess.run([str(H/'build/ccmckp_s10'),'--instance',str(H/'fixtures/LAB_3_2_500_'),'--capacity','.5','--seed','990002','--seconds','60','--out',str(out),'--search-flow',flow],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env,timeout=60)
 row={'name':'active_engine_integration_'+flow,'rc':p.returncode,'whole_seconds':time.monotonic()-begin,'stdout':p.stdout.decode(errors='replace')[-1000:]}
 (H/('engine60_'+flow+'.log')).write_bytes(p.stdout);assert p.returncode==0,row
 raw=json.loads((out/'S10_search.json').read_text());x=json.loads((out/'RESULT.json').read_text())
 assert raw['block_history'] and any('pairs' in q for q in raw['block_history']),raw['block_history']
 assert x['cost']==3 and x['original_LSS_confidence']>=.99 and row['whole_seconds']<60
 assert (raw['DRO_model'] is not None)==(flow=='block_winf_dro')
 row.update(block_records=len(raw['block_history']),cost=x['cost'],LSS=x['original_LSS_confidence'],active_model_score_and_collection_exercised=True)
 report['checks'].append(row);print(json.dumps(row),flush=True)
assert hashlib.sha256((H/'build/ccmckp_s10').read_bytes()).hexdigest()==report['binary_sha256']
(H/'VALIDATION.json').write_text(json.dumps(report,indent=2));print(json.dumps({'status':'PASS','active_engine_tests':2,'all_new_math_checks':632,'binary_sha256':report['binary_sha256']}))
