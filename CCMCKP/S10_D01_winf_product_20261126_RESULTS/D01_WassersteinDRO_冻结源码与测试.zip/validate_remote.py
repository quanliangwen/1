from pathlib import Path
import json,hashlib,subprocess,os,time
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');assert Path.cwd()==B
H=B/'work/d01_winf_product_20261126';checks=[]
def run(name,cmd,limit):
 begin=time.monotonic();env=dict(os.environ,CCMCKP_LAUNCH_MONOTONIC=str(begin),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',BLIS_NUM_THREADS='1')
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env,timeout=limit)
 (H/(name+'.log')).write_bytes(p.stdout)
 row={'name':name,'rc':p.returncode,'whole_seconds':time.monotonic()-begin,'tail':p.stdout.decode(errors='replace')[-3500:]};checks.append(row);print(json.dumps(row),flush=True);assert p.returncode==0,row
 return row
try:
 run('winf_math_transport_and_exact_enumeration',[str(H/'build/winf_product_test'),str(H/'fixtures/winf')],60)
 for flow in ['block_insurance','block_winf_dro']:
  out=H/'integration'/flow
  row=run('integration_'+flow,[str(H/'build/ccmckp_s10'),'--instance',str(H/'fixtures/LAB_3_2_500_'),'--capacity','.5','--seed','990001','--seconds','30','--out',str(out),'--search-flow',flow],30)
  x=json.loads((out/'RESULT.json').read_text());raw=json.loads((out/'S10_search.json').read_text())
  assert x['cost']==3 and x['original_LSS_confidence']>=.99 and x['lss_sample_index_max']==499 and not x['real_probability_reporting']
  assert row['whole_seconds']<30 and x['clock_policy']=='launch_to_exit_total_wall'
  if flow=='block_winf_dro':
   assert raw['DRO_model']['transport_order']=='infinity' and raw['DRO_model']['transport_radius']==1
   assert any(int(r['units_1e12'])>0 for r in raw['DRO_model']['radii'])
   assert raw['certificate_scope']=='exact_worst_case_shifted_product_probability'
   assert raw['selected']['certificate']['accepted'] and not raw['DRO_model']['nominal_fallback_in_DRO_pool']
  else:assert raw['DRO_model'] is None
  row.update(cost=x['cost'],LSS=x['original_LSS_confidence'],model_certificate_scope=raw['certificate_scope'])
 unchanged=['evaluation.cpp','evaluation.hpp','rng.cpp','rng.hpp','report.cpp','report.hpp','model.cpp','model.hpp','mip.cpp','mip.hpp','fft.hpp','partition.hpp','block_mitm.hpp','block_bounds.hpp','block_schedule.hpp','convolution_tree.hpp']
 for name in unchanged:assert (H/'source'/name).read_bytes()==(B/'work/b01_block_mitm_20261126/source'/name).read_bytes(),name
 report={'status':'PASS','checks':checks,'unchanged_bytes':unchanged,'no_extra_native_probability_diagnostic':True,'reused_B01_deterministic_checks':3943,'binary_sha256':hashlib.sha256((H/'build/ccmckp_s10').read_bytes()).hexdigest(),'source_sha256':{p.relative_to(H/'source').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (H/'source').rglob('*') if p.is_file()}}
 (H/'VALIDATION.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
except BaseException as error:
 (H/('VALIDATION_FAILURE_%s.json'%len(list(H.glob('VALIDATION_FAILURE_*'))))).write_text(json.dumps({'error':repr(error),'checks':checks},indent=2));raise
