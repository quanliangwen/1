本包为实际执行180次的冻结DC2源码。当前协议和DESIGN_AND_DIAGNOSIS优先于保留旧流程的帮助文字。
两臂统一最终仅LSS>=.99，全样本0—499，不计算真实概率，不读取历史解。
完整600秒必须通过配套controller从Popen前到退出计时与595秒硬保护；单独调用C++的协作时限不能替代父级硬终止。
候选参数：--search-flow ellipsoid_dominance --ellipsoid-gamma 2.4 --ellipsoid-slice 5 --seconds 600 --local-phases none。S10为frontier_mitm。
所有已运行身份与失败原样保留；禁止在同目录覆盖重跑。
