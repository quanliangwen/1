from pathlib import Path
import json,subprocess,pickle,os,time,hashlib
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');assert Path.cwd()==B
H=B/'work/b01_block_mitm_20261126';F=H/'fixtures/block';F.mkdir(exist_ok=False)
rows=[['0','.25'],['.5','.75'],['0','.25'],['.5','.75'],['0','0'],['.25','.5'],['0','0'],['.25','.5'],['0','0'],['.25','.5']]
(F/'node_to_factor.pkl').write_bytes(pickle.dumps({g:[2*g,2*g+1] for g in range(5)},protocol=4))
(F/'cost.txt').write_text('\n'.join(['4','1']*5)+'\n')
for j,row in enumerate(rows):(F/(str(j)+'_sample.txt')).write_text('\n'.join(row)+'\n')
checks=[]
def run(name,cmd,limit):
 start=time.monotonic();env=dict(os.environ,CCMCKP_LAUNCH_MONOTONIC=str(start),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',BLIS_NUM_THREADS='1')
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env,timeout=limit)
 (H/(name+'.log')).write_bytes(p.stdout)
 r={'name':name,'rc':p.returncode,'whole_seconds':time.monotonic()-start,'tail':p.stdout.decode(errors='replace')[-2500:]};checks.append(r);print(json.dumps(r),flush=True);assert p.returncode==0
 return r
try:
 run('block_exhaustive_test',[str(H/'build/block_test'),str(F)],60)
 for flow in ['block_mitm','frontier_mitm_zero']:
  out=H/'integration'/flow
  r=run('integration_'+flow,[str(H/'build/ccmckp_s10'),'--instance',str(H/'fixtures/LAB_3_2_500_'),'--capacity','.5','--seed','970001','--seconds','30','--out',str(out),'--search-flow',flow],30)
  result=json.loads((out/'RESULT.json').read_text());completion=json.loads((out/'COMPLETION.json').read_text())
  assert result['cost']==3 and result['original_LSS_confidence']>=.99 and result['lss_sample_index_max']==499 and not result['real_probability_reporting']
  assert r['whole_seconds']<30 and completion['elapsed_before_completion_save']<29
  r.update(cost=result['cost'],LSS=result['original_LSS_confidence'],whole_clock=True)
 same=['evaluation.cpp','evaluation.hpp','rng.cpp','rng.hpp','report.cpp','report.hpp','model.cpp','model.hpp','mip.cpp','mip.hpp','fft.hpp','partition.hpp']
 for f in same:assert (H/'source'/f).read_bytes()==(B/'work/egs_corecuts_600s_20261124/source'/f).read_bytes(),f
 data={'status':'PASS','new_checks':checks,'unchanged_bytes':same,'no_new_true_probability':True,'not_performance_conclusion':True,'binary_sha256':hashlib.sha256((H/'build/ccmckp_s10').read_bytes()).hexdigest()}
 (H/'VALIDATION.json').write_text(json.dumps(data,indent=2));print(json.dumps(data),flush=True)
except BaseException as e:
 (H/('VALIDATION_FAILURE_%s.json'%len(list(H.glob('VALIDATION_FAILURE_*'))))).write_text(json.dumps({'error':repr(e),'checks':checks},indent=2));raise
