from pathlib import Path
import ast,json,hashlib
R=Path(__file__).resolve().parent;p=R/'build_full40_report.py';tree=ast.parse(p.read_text(encoding='utf-8'))
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['holm','pratt_exact']];assert len(nodes)==2
ns={};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(p),'exec'),ns)
checks=[([],1.),([0,0],1.),([1,2,3],.25),([0,1,2],.5),([0,0,1,1],.5),([0,1,-2],1.),([1]*40,2/2**40)]
for x,expected in checks:assert ns['pratt_exact'](x)==expected,(x,expected)
assert ns['holm']([.01,.03,.04])==[.03,.06,.06]
out={'status':'PASS','known_Pratt_and_Holm_checks':len(checks)+1,'function_AST_sha256':hashlib.sha256(ast.dump(ast.Module(body=nodes,type_ignores=[])).encode()).hexdigest(),'no_solver_LSS_or_probability_sampling':True}
(R/'REPORT_STATISTICS_CHECKS.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))
