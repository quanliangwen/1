from pathlib import Path
from collections import Counter
import json,hashlib,statistics,csv,zipfile,tarfile,sys
R=Path(__file__).resolve().parent;E=R/'evidence';D=R/'delivery';D.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
P=read(E/'full40/PROTOCOL.json');A=read(E/'full40/FINAL_INDEPENDENT_AUDIT.json');H=read(E/'FULL40_COMPLETION_HEALTH.json')
F=read(E/'formal/FINAL_INDEPENDENT_AUDIT.json');G=read(E/'formal/FULL40_ELIGIBILITY_DECISION.json');S=read(E/'smoke/SMOKE_FUNCTIONAL_DECISION.json');I=read(R/'ILS_REFERENCE.json')
assert A['terminal']==3600 and not A['global_errors'] and H['status']=='PASS' and G['L4_eligible']
review=read(E/'TIMING_EXCEPTION_RECORD_REVIEW.json');overruns=read(E/'STAGE_OVERRUN_DIAGNOSIS.json')
assert review['remaining_review_valid']==8 and not review['global_errors'] and not review['original_protocol_valid'] and review['original_final_audit_sha256']==H['audit_sha256']
reviewed={x['identity']:x for x in review['rows']};assert set(reviewed)=={x['identity'] for x in A['rows'] if not x['valid']}
lss_rows=[r if r['valid'] else reviewed[r['identity']] for r in A['rows']]
assert len(lss_rows)==3600 and all(r['valid'] and r['LSS']>=.99 and r['process_wall_seconds']<=600 for r in lss_rows)
for n,v in read(R/'COLLECTION_RECEIPT.json').items():assert sha(E/n)==v['sha256'],n
for n,h in P['source_and_binary_pins'].items():
 if n.startswith('../source/'):assert sha(R/'source'/n[10:])==h,n
names={'A_B01_ORIGINAL':'B01','B_D02_TRANSPORT':'D02','D_R06_QUALITY_DUAL':'R06','C_R04_BUDGET_FFT':'R04'}
arms=['A_B01_ORIGINAL','B_D02_TRANSPORT','D_R06_QUALITY_DUAL'];pairs=[(arms[2],arms[1]),(arms[2],arms[0]),(arms[1],arms[0])]
cases={c['index']:c for c in P['cases']};groups={(g['case_index'],g['arm']):g for g in A['groups']};fmt=lambda x,n=9:'空' if x is None else f'{x:.{n}f}'
pfmt=lambda x:'空' if x is None else format(x,'.7g')
label=lambda k:cases[k]['instance'].rstrip('_')+' / T'+format(cases[k]['tmax'],'g')
ils={(x['instance'],float(x['capacity'])):x for x in I['rows']}
def holm(values):
 out=[1.]*len(values);prior=0
 for rank,k in enumerate(sorted(range(len(values)),key=lambda k:values[k])):prior=max(prior,min(1.,(len(values)-rank)*values[k]));out[k]=prior
 return out
def pratt_exact(values):
 ranked=sorted((abs(v),i) for i,v in enumerate(values));weights={};at=0
 while at<len(ranked):
  end=at+1
  while end<len(ranked) and ranked[end][0]==ranked[at][0]:end+=1
  twice_rank=at+1+end
  for _,i in ranked[at:end]:
   if values[i]!=0:weights[i]=twice_rank
  at=end
 if not weights:return 1.
 target=sum(w for i,w in weights.items() if values[i]>0);total=sum(weights.values());dist={0:1}
 for w in weights.values():
  nxt=dict(dist)
  for k,n in dist.items():nxt[k+w]=nxt.get(k+w,0)+n
  dist=nxt
 obs=abs(2*target-total);return sum(n for k,n in dist.items() if abs(2*k-total)>=obs)/(2**len(weights))
effects=[]
for a,b in pairs:
 contrasts=[x for x in A['comparisons'] if x['candidate']==a and x['reference']==b];complete=[x for x in contrasts if x['complete30']]
 normalized=[x['avg_diff']/groups[(x['case_index'],b)]['official_avg'] for x in complete]
 ratio=[groups[(x['case_index'],a)]['whole_mean']/groups[(x['case_index'],b)]['whole_mean']-1 for x in complete]
 std=[groups[(x['case_index'],a)]['official_std']-groups[(x['case_index'],b)]['official_std'] for x in complete]
 effects.append({'candidate':a,'reference':b,'complete_cases':len(complete),'total_cases':40,'raw_mean_lower':sum(x['avg_diff']<0 for x in complete),'raw_mean_equal':sum(x['avg_diff']==0 for x in complete),'raw_mean_higher':sum(x['avg_diff']>0 for x in complete),'Holm120_significantly_lower':sum(x['avg_diff']<0 and x['cost_p_holm120']<.05 for x in complete),'Holm120_significantly_higher':sum(x['avg_diff']>0 and x['cost_p_holm120']<.05 for x in complete),'equal_case_mean_relative_cost_diff':statistics.mean(normalized) if normalized else None,'equal_case_mean_relative_time_diff':statistics.mean(ratio) if ratio else None,'std_lower':sum(x<0 for x in std),'std_equal':sum(x==0 for x in std),'std_higher':sum(x>0 for x in std),'secondary_Pratt_exact_p':pratt_exact(normalized)})
 effects[-1].update(time_lower=sum(x['whole_time_diff']<0 for x in complete),time_equal=sum(x['whole_time_diff']==0 for x in complete),time_higher=sum(x['whole_time_diff']>0 for x in complete),time_significantly_lower=sum(x['whole_time_diff']<0 and x['time_p_holm120']<.05 for x in complete),time_significantly_higher=sum(x['whole_time_diff']>0 and x['time_p_holm120']<.05 for x in complete),median_case_relative_time_diff=statistics.median(ratio) if ratio else None,total_worker_wall_ratio_minus1=(sum(groups[(x['case_index'],a)]['whole_mean'] for x in complete)/sum(groups[(x['case_index'],b)]['whole_mean'] for x in complete)-1) if complete else None)
for e,p in zip(effects,holm([e['secondary_Pratt_exact_p'] for e in effects])):e['secondary_Pratt_Holm3_p']=p
byarm={arm:{'valid_runs':sum(r['valid'] for r in A['rows'] if r['arm']==arm),'complete30_groups':sum(g['valid']==30 for (c,a),g in groups.items() if a==arm)} for arm in arms}
lgroups={}
for c in sorted(cases):
 for arm in arms:
  rr=[r for r in lss_rows if r['case_index']==c and r['arm']==arm];assert len(rr)==30
  lgroups[(c,arm)]={'case_index':c,'arm':arm,'LSS_accepted':30,'original_protocol_valid':groups[(c,arm)]['valid'],'best':min(r['cost'] for r in rr),'avg30':statistics.mean(r['cost'] for r in rr),'sample_std30':statistics.stdev(r['cost'] for r in rr),'scope':'LSS_and_global600_diagnostic_only_not_original_protocol_statistics'}
summary={'full40_groups':A['groups'],'primary_comparisons':A['comparisons'],'normalized_effects_and_secondary_tests':effects,'validity':byarm,'health':H,'formal360_gate':G,'ILS_rows':39,'ILS_repetitions_confirmed':30,'ILS_supplement':read(R/'ILS_SUPPLEMENT_20261127.json'),'ILS_paired_or_same_acceptance_verified':False,'metadata_notes':read(E/'FULL40_METADATA_NOTES.json'),'LSS_acceptance_and_global600_passed':3600,'original_protocol_conformance_passed':A['independent_valid'],'timing_exception_records':overruns,'supplemental_review_does_not_upgrade_original_validity':True}
summary['LSS_only_diagnostic_groups']=list(lgroups.values())
(D/'R06_全40例统计与检验.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
with (D/'R06_全40例3600次明细.csv').open('w',encoding='utf-8-sig',newline='') as f:
 keys=['identity','case_index','instance','arm','rep','seed','original_protocol_valid','cost','LSS','process_wall_seconds','termination_reason','errors','LSS_diagnostic_cost','LSS_diagnostic_probability','LSS_passed'];w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
 for r,lr in zip(A['rows'],lss_rows):
  row={k:r.get(k) for k in keys};row.update(original_protocol_valid=r['valid'],LSS_diagnostic_cost=lr['cost'],LSS_diagnostic_probability=lr['LSS'],LSS_passed=lr['LSS']>=.99);w.writerow(row)
with (D/'R06_全40例120组统计.csv').open('w',encoding='utf-8-sig',newline='') as f:
 keys=['case_index','instance','capacity','arm','valid','best','avg30','sample_std30','whole_mean_seconds','LSS30_diagnostic_best','LSS30_diagnostic_avg','LSS30_diagnostic_std'];w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
 for (c,arm),g in groups.items():
  d=lgroups[(c,arm)];w.writerow(dict(case_index=c,instance=cases[c]['instance'],capacity=cases[c]['tmax'],arm=arm,valid=g['valid'],best=g['best_diagnostic'],avg30=g['official_avg'],sample_std30=g['official_std'],whole_mean_seconds=g['whole_mean'],LSS30_diagnostic_best=d['best'],LSS30_diagnostic_avg=d['avg30'],LSS30_diagnostic_std=d['sample_std30']))
L=['# CCMCKP R06质量优先运行测试总结','',
 f'**本轮已完成15次独立先导、三大算例四版本360次正式对照，以及全40算例三版本3600次新鲜评测，共3975次运行。全40阶段3600份输出均通过原LSS且整次≤600秒；原冻结全链审计合规{A["independent_valid"]}/3600，另8条为内部阶段时间越界。global_errors=[]，所有本轮控制器及worker已退出。**','',
 '本报告区分“代码与审计通过”和“性能改善”，不把任务完成等同于全例全优、全局最优或同一DRO保证下的模型改进。','',
 f'**全量最明确的收益是加速，尚未实现整体Avg和波动全面改善。** 对D02有{effects[0]["complete_cases"]}个原协议完整算例：Avg {effects[0]["raw_mean_lower"]}优/{effects[0]["raw_mean_equal"]}平/{effects[0]["raw_mean_higher"]}劣，Holm120显著{effects[0]["Holm120_significantly_lower"]}优/{effects[0]["Holm120_significantly_higher"]}劣；等权相对Avg差为{100*effects[0]["equal_case_mean_relative_cost_diff"]:.5f}%（正数为更贵）。这39例均更快，但Std低/平/高为4/31/4。编号18的全部30次LSS诊断同样显示Avg与Std退化，不能因8条阶段不合规而隐藏这些结果。','',
 '## 1 执行顺序与统计口径','',
 '依据用户R06设计先完成3个tiny完整集成（含L30/L500）及30项读者篡改检查；随后三个大算例R06各5次（seed1065001–1065005），四项功能门槛全部通过。再做同批B01/D02/R04/R06各3例×30次（seed1060001–1060030），360/360独立有效，通过冻结扩展门槛后才启动本次全40阶段。',
 '全40阶段为B01/D02/R06，各40×30=1200次，总3600次。seed1061001–1061030，与先导和正式360均不重用；此前三大算例也在本批重新从原始数据生成解，没有借用此前候选。首600次是本批各组rep1–5，包含在3600次内；技术审核后续跑其余3000次，不是额外增加600次。',
 f'实际最高{H["max_workers_observed"]}并行，资源事件{H["resource_events"]}次，最长单次完整进程{H["max_actual_worker_wall_seconds"]:.6f}秒。完整时钟从Popen前到进程退出，含加载、建模、初始化、全部原CDF认证、LSS、输出及fsync，不截断为600。独立终末记录审计不再求解或重新抽概率，不计入单次算法预算。','',
 '|版本|求解流程|最终验收|','|---|---|---|',
 '|B01|原加速块搜索/MITM|原LSS≥0.99|',
 '|D02|原正W∞分布鲁棒模型＋运输不可行性割|原LSS≥0.99|',
 '|R06|计数尾部预算RO＋无量纲熵代理＋双通道局部MIP/回退梯队|原LSS≥0.99|','',
 '对照直接使用已冻结R04原二进制；R06为RO/熵代理引导的经验机会约束混合框架。D02与R06候选域及鲁棒保护范围不同，成本下降不能解释为同一个DRO不确定集合、同等保证下的求解提升。原shortlist、quick/MC/exact、LSS、严格资源事件及0至L−1抽样保持原代码；每个run自行生成起点，不读历史解、跨重复输出或外部MIP start。','',
 '## 2 全40阶段有效率与成本覆盖','', '|版本|原协议合规run|原协议完整30次算例|','|---|---:|---:|']
for arm in arms:L.append(f'|{names[arm]}|{byarm[arm]["valid_runs"]}/1200|{byarm[arm]["complete30_groups"]}/40|')
L+=['','只有30/30独立有效才给官方avg和样本std（ddof=1），否则为空；best只取实际有效输出的观察最小值，不是全局最优证明。失败不填罚成本，valid-only结果不冒充30次统计。完整均时描述该组全部30次尝试，包含失败耗时。','',
 '这里的“原协议合规”还检查了内部阶段分配，不等于最终LSS通过数。LAB_40_10_500、T63（编号18）的R06有8条超出阶段容忍限，该组官方avg/std保持空；全部30次原LSS统计在下节单列，未把阶段超限说成概率验收失败。','',
 '## 3 全40算例best、avg、std与完整耗时','',
 '|编号|算例|版本|有效|Best|Avg30|Std30|完整均时/s|','|---|---|---|---:|---:|---:|---:|---:|']
for c in sorted(cases):
 for arm in arms:
  g=groups[(c,arm)];L.append(f'|{c}|{label(c)}|{names[arm]}|{g["valid"]}/30|{fmt(g["best_diagnostic"])}|{fmt(g["official_avg"])}|{fmt(g["official_std"])}|{fmt(g["whole_mean"],3)}|')
L+=['','### 编号18的全部30次原LSS统计（诊断口径，非原协议官方统计）','',
 '这30份输出的最终LSS、成本、选择、来源、数学见证和整次600秒均复核通过；8条只是在内部阶段分配上不合规。下表完整保留全部30次，不删掉超阶段且成本较高的记录，也不用于补上原协议缺失的成本p值。','',
 '|版本|原LSS通过|原协议合规|Best30（LSS口径）|Avg30（LSS口径）|样本Std30（LSS口径）|完整均时/s|','|---|---:|---:|---:|---:|---:|---:|']
for arm in arms:
 rr=[r for r in lss_rows if r['case_index']==18 and r['arm']==arm];assert len(rr)==30
 L.append(f'|{names[arm]}|30/30|{groups[(18,arm)]["valid"]}/30|{min(r["cost"] for r in rr):.9f}|{statistics.mean(r["cost"] for r in rr):.9f}|{statistics.stdev(r["cost"] for r in rr):.9f}|{statistics.mean(r["process_wall_seconds"] for r in rr):.3f}|')
L+=['','## 4 配对成本、稳定性和速度结论','',
 '三个版本每例三对比较，共120项同seed成本均值符号翻转检验，Holm120校正；完整进程均时另建Holm120族，原协议审计合规率用配对精确McNemar、再单独Holm120。本批LSS输出接受率实际均为100%；合规率差异来自上述阶段时间，不是额外真实概率检验。活动差不超过18时枚举全部符号，否则使用冻结代码99,999组符号及加一校正。成本seed=20261207+10×case_index+例内对比序号；时间seed=20261208+10×case_index+全局对比序号（序号从0开始）。未完整30对的成本p占位1只保留校正位置，不是等效证据。','',
 '下表优/平/劣按未舍入均值的方向，显著性按Holm120。接近浮点精度的微差不解释为实际收益。等权相对差只用该对照双方完整30次的算例，分母为对照均值；不直接平均不同规模的原始成本，不把覆盖不足外推到40例。Std方向仅作描述，未追加事后方差检验。','',
 '|比较|完整算例|Avg优/平/劣|显著优/劣|等权相对成本差|等权相对均时差|Std低/平/高|','|---|---:|---|---|---:|---:|---|']
for e in effects:L.append(f'|{names[e["candidate"]]}−{names[e["reference"]]}|{e["complete_cases"]}/40|{e["raw_mean_lower"]}/{e["raw_mean_equal"]}/{e["raw_mean_higher"]}|{e["Holm120_significantly_lower"]}/{e["Holm120_significantly_higher"]}|{fmt(None if e["equal_case_mean_relative_cost_diff"] is None else 100*e["equal_case_mean_relative_cost_diff"],5)}%|{fmt(None if e["equal_case_mean_relative_time_diff"] is None else 100*e["equal_case_mean_relative_time_diff"],2)}%|{e["std_lower"]}/{e["std_equal"]}/{e["std_higher"]}|')
L+=['','基线若只用毫秒，固定建模开销会造成很大的逐例时间倍数。另列均时方向、比例中位数和总worker墙钟工作量比；后者不是混合并行批次的makespan或独占机器加速比。覆盖仍仅限双方完整30次的算例。','',
 '|比较|均时短/平/长|显著短/长|逐例时间比例中位差|总worker墙钟相对差|','|---|---|---|---:|---:|']
for e in effects:L.append(f'|{names[e["candidate"]]}−{names[e["reference"]]}|{e["time_lower"]}/{e["time_equal"]}/{e["time_higher"]}|{e["time_significantly_lower"]}/{e["time_significantly_higher"]}|{fmt(None if e["median_case_relative_time_diff"] is None else 100*e["median_case_relative_time_diff"],2)}%|{fmt(None if e["total_worker_wall_ratio_minus1"] is None else 100*e["total_worker_wall_ratio_minus1"],2)}%|')
L+=['','次要分析对完整算例的规范化均值差做Pratt符号秩检验（零差参加绝对值排序，非零秩作精确符号分布），三个版本对单独Holm3。每个原始实例有两个容量阈值，跨例差异可能相关；该次要检验仅作探索性补充，不能替代逐例Holm120、有效率与覆盖限制。','', '|比较|覆盖|Pratt原p|Holm3 p|','|---|---:|---:|---:|']
for e in effects:L.append(f'|{names[e["candidate"]]}−{names[e["reference"]]}|{e["complete_cases"]}/40|{pfmt(e["secondary_Pratt_exact_p"])}|{pfmt(e["secondary_Pratt_Holm3_p"])}|')
L+=['','### 逐例主要检验（R06−D02）','', '|编号|完整30对|Avg差|成本Holm120 p|完整均时差/s|时间Holm120 p|有效率Holm120 p|','|---|---|---:|---:|---:|---:|---:|']
for x in A['comparisons']:
 if x['candidate']==arms[2] and x['reference']==arms[1]:L.append(f'|{x["case_index"]}|{x["complete30"]}|{fmt(x["avg_diff"])}|{pfmt(x["cost_p_holm120"])}|{fmt(x["whole_time_diff"],3)}|{pfmt(x["time_p_holm120"])}|{pfmt(x["validity_p_holm120"])}|')
L+=['','全部120项未舍入差值、原p、校正p及有效率检验在R06_全40例统计与检验.json中保留。未显著不等于无用或等效；存在退化或失败时，不宣称全例全优。','',
 '需要优先关注的质量退化是LAB_10_20_500、T12（编号11，R06对D02 Avg +0.846635，Holm120 p=.055046，未达到显著），以及APP_40_10_500、T95（编号38，Avg +0.608597，Holm120 p=.0012，显著劣）。三大算例筛选通过没有覆盖到这些退化，不能仅凭先导三例宣称泛化成功。','',
 '## 5 ILS历史表的描述性比较','',
 '用户提供39条历史汇总，已明确每例重复30次，缺LAB_50_10_500、T75（编号20）。尚未提供原始seed、逐次LSS轨迹和ddof；Time标为“分析”，完整进程计时口径未知。因此不做ILS配对检验、完整速度倍数或总体有效性判断，也不因某个ILS best较低就断言其真实概率低于0.99。R06额外要求内部CDF证书；历史ILS候选生成域未知，即使最终都以LSS验收，也不能自动认为候选域相同。','',
 '|编号|ILS历史Best|ILS历史Avg|ILS历史Std|R06 Avg30|R06 Std30|','|---|---:|---:|---:|---:|---:|']
for c in sorted(cases):
 q=ils.get((cases[c]['instance'].rstrip('_'),float(cases[c]['tmax'])));g=groups[(c,arms[2])]
 L.append(f'|{c}|{q["best"] if q else "缺失"}|{q["avg"] if q else "缺失"}|{q["std"] if q else "缺失"}|{fmt(g["official_avg"])}|{fmt(g["official_std"])}|')
L+=['','三大算例扩展门槛前瞻采用了用户表中数值std阈值（.058465/.2322/.4096），仅为历史描述性阈值；其通过不证明相对ILS的稳定性显著改善，也没有据此把ILS记录判为无效。','',
 '## 6 R06实际执行及阶段诊断','',
 '尾部窗口min(L,max(3,ceil(L/20)))：500样本取25、30样本取3。L30的有效尾部比例为10%，不冒称严格5%尾部。ES主段180秒，9次定位、至多5个去重细化Γ点，每点15次新CDF认证；进入新点需剩余>10秒，MIP和认证另有8/6秒保护。complete点表示有限配额查询返回，不表示穷尽该Γ。',
 '熵段60秒；sigma为本run ES认证解各选项总体方差和的平方根，无认证时仅用自身最小均值向量算尺度。c=[2,1,.5,3]，t=clip(c/sigma,.001,50)，零sigma取50；192bit有向包络由208bit独立读者复核。有限网格不是总体0.99置信覆盖或最优倾斜点保证。',
 'Round0私人提议15秒/15次CDF，随后预算允许时至少2、至多3轮冲优MIP，改1–5组、每轮2秒/Pool15/至多10次CDF。回退通道合并1-opt和一次改1–3组、2秒/Pool25局部MIP；+0.6%带内、不同于best且私人评分不低于min(bestFFT,.99)才计入目标4个。有限池不保证列举所有邻域，局部风险线性化只是提议代理，不是原机会约束有效割。',
 '精炼私人提议45秒、原CDF150秒/100次。R06搜索480秒，原LSS590秒截止，595秒外部保护；对照仍为其冻结430秒搜索，公平预算是共同完整600秒。原CDF只作二元内部认证，私人8192-bin FFT作排序门控，未写公共概率缓存。最近格点离散化不保证数学无偏，有限区间不能宣称消除混叠，也没有普适真实概率误差界。','',
 '|编号|有效R06|母体内部均值|精炼后内部均值|最终减内部均差|5点完成数|局部MIP最少轮|梯队不足4个数|','|---|---:|---:|---:|---:|---:|---:|---:|']
diag=[]
for c in sorted(cases):
 rr=[r for r in A['rows'] if r['case_index']==c and r['arm']==arms[2] and r['valid']]
 if not rr:L.append(f'|{c}|0|空|空|空|空|空|空|');continue
 m=[r['R06_funnel'] for r in rr];mother=[x['mother_only_best_cost'] for x in m if x['mother_only_best_cost'] is not None]
 d={'case_index':c,'valid':len(rr),'mother_internal_mean':statistics.mean(mother) if mother else None,'raw_internal_mean':statistics.mean(r['raw_final_cost'] for r in rr),'mean_LSS_uplift':statistics.mean(r['final_cost_minus_raw_best'] for r in rr),'fine5':sum(x.get('fine_points_completed',0)==5 for x in m),'local_min':min(x.get('local_mckp_rounds_executed',0) for x in m),'fallback_under4':sum(x.get('channelB_certified_in_band_count',0)<4 for x in m),'entropy_refresh':sum(x['entropic_improved_best'] for x in m)};diag.append(d)
 L.append(f'|{c}|{len(rr)}|{fmt(d["mother_internal_mean"])}|{fmt(d["raw_internal_mean"])}|{fmt(d["mean_LSS_uplift"])}|{d["fine5"]}/{len(rr)}|{d["local_min"]}|{d["fallback_under4"]}/{len(rr)}|')
summary['R06_valid_run_stage_diagnostics']=diag
(D/'R06_全40例统计与检验.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
L+=['','母体/内部best是内部CDF认证里程碑，不是独立母体LSS终审成绩。内部差分不能证明局部精炼对最终avg/std的净因果贡献。内部best与最终std的变化应结合原LSS回退看；梯队不足4也不等于已证明不存在其他可行邻居。所有正负记录保留，没有新增真实概率抽样。','',
 '两项退化的日志机制不同：编号11的母体与精炼内部best均值均为47.870174553，最终LSS均值升至49.123167569，平均回退增量1.252993016，30/30梯队未满4，主要可见缺口是便宜回退覆盖。编号38的母体内部均值198.019249179，经精炼降至196.949989822，最终同值且Std为0、没有回退成本；相对D02的差距已经存在于内部最好候选，不能归因于LSS终审。这些是轨迹诊断，不是单因素消融因果结论。','',
 '## 7 三大算例360次前置正式结果','',
 '本节使用前置seed1060001–1060030，未混入全40新批次。360/360独立有效；R06对D02两例Avg持平，APP50降低.1619055385（Holm18 p=.01974），三例均更快；APP50 Std仍高于D02。数值扩展门槛全过才全40，不把三例结论外推成40例结论。','',
 '|编号|版本|Best|Avg30|Std30|完整均时/s|','|---|---|---:|---:|---:|---:|']
for g in F['groups']:L.append(f'|{g["case_index"]}|{names[g["arm"]]}|{fmt(g["best_diagnostic"])}|{fmt(g["official_avg"])}|{fmt(g["official_std"])}|{fmt(g["whole_mean"],3)}|')
L+=['','前置APP50在15并行先导均完成5点，但60并行正式首5次只完成3–4点，其中两次内部cost为322.633049614；原记录未补跑。说明功能先导通过不保证正式负载的阶段覆盖，180秒及剩余保护仍可能挤压后段Γ点。','',
 '## 8 内部阶段超时的复核与原因','',
 '8条均为编号18的R06：rep9、10、14、15、16、17、18、19。原审计要求ES结束≤181秒、母体结束≤241秒、精炼CDF累计≤150.5秒（对应180/240/150秒目标及原读者容忍量）。6条ES超过181秒，4条精炼CDF超过150.5秒，二者重叠2条，合计8条。整次均小于600秒，原LSS均≥.99。','',
 '|run|ES结束/s|母体结束/s|精炼CDF累计/s|整次/s|最终LSS|最终成本|','|---|---:|---:|---:|---:|---:|---:|']
for q in overruns['records']:
 t=q['timing'];L.append(f'|{q["identity"]}|{q["ES95_finished_seconds"]:.6f}|{q["mother_finished_seconds"]:.6f}|{t["polish_channelA_native_cdf"]+t["polish_channelB_native_cdf"]:.6f}|{q["whole_seconds"]:.6f}|{q["final_LSS"]:.6f}|{q["cost"]:.9f}|')
L+=['','日志显示部分单次整数CDF请求持续105–150秒后以unknown/expired返回。source/evaluation.cpp的整数卷积在GMP大整数乘法前后检查deadline，单次乘法内部不能即时打断，因此可能跨过阶段截止后才报告超时；这解释了内部阶段超限，不能归结为Gurobi无可行解或LSS概率不通过。595秒独立进程保护仍守住整次600秒。',
 '补充复核只在独立诊断进程中略去这三个局部时间断言，其余身份/源/成本/原LSS/完整600秒/RO与熵见证/准入/配额/时钟分解检查均通过。原冻结读者、协议、结果、3592合规结论和主检验均未改写，未补跑。该补充证明结果的验收与数学有效性，不能反向声称8条满足原阶段时间分配。下一版若修复阶段可中断控制，应另行冻结测试，不回改本轮。','',
 '## 9 可核验的元数据更正与限制','',
 '全40冻结模板沿用了几处旧说明标签，原件未改，已在FULL40_METADATA_NOTES.json中单独更正：sampling_index_range=[0,499]只描述L500，实际L30抽0..29、L500抽0..499；first_wave_is_part_of_registered360旧字段名应读作本批首600计入3600；other_contrasts旧文字“六对”实际为三对×40=120；原始读者pilot_first5_counted_in_formal30=False标签不准确，本批rep1–5确实包含在本批1–30里，之前15/360次均未复用。独立读者按实际样本数和全部身份检查，真实统计没有按这些旧文字运行。',
 '前置360协议sign_flip_seed=20261205是未被读者读取的遗留字段；其冻结代码实际采用成本20261207、时间20261208加编号/对比序号的公式。原协议和源码均保留，没有事后换种子或选p值；全40新协议已明确写入实际公式。',
 '所有新本地文件仅为E:/codex任务临时工作区；最终交付上传GitHub并独立回读校验。冻结28个继承组件及native_check/shortlist/final_check字节不变；独立读者不导入写者/求解器，复核输入SHA、身份、成本、原LSS、时钟、输出CDF、RO有理数见证、熵区间、私人FFT及局部行，并按时间顺序重建准入incumbent。',
 '新增全40读者只是把原500固定分母/索引扩展为实际L。用已有L30/L500 tiny输出记录和3原子分母反例检查，不重跑求解、LSS或大型MC。所有冻结算法、参数、输入和运行结果均保留，资源/预算/普通失败不补跑选seed。','',
 '## 10 交付与复现','',
 '同目录提供120组统计CSV、3600次CSV、未舍入JSON、各阶段协议/审计/判定、冻结源码ZIP、完整紧凑记录分片及SHA清单。按分片清单顺序合并并验证整包SHA，不能少片。商业Gurobi SDK/许可证及完整benchmark不随包分发；原测试输入均按各阶段input_pins固定。源码.tmp是未编译装配草稿，实际入口以CMakeLists.txt及.cpp/.hpp为准。',
 '对照源码见[R04冻结交付](https://github.com/quanliangwen/1/tree/6fd97b0692b1fcb14fec32f7fe917d57dc310150/CCMCKP/S10_R04_budget_FFT_20261127_RESULTS)。新复现实验必须使用新目录，禁止覆盖本批记录。',
 f'R06二进制SHA256：`{H["binary_sha256"]}`；全40协议SHA256：`{H["protocol_sha256"]}`；全40审计SHA256：`{H["audit_sha256"]}`。']
(D/'CCMCKP_R06_质量优先运行测试总结.md').write_text('\n'.join(L)+'\n',encoding='utf-8')
for n in ['USER_DESIGN.md','冻结前适配说明.md','FROZEN_PARAMETERS.json','ILS_REFERENCE.json','ILS_USER_REFERENCE.csv','ILS_SUPPLEMENT_20261127.json']:(D/n).write_bytes((R/n).read_bytes())
for stage,fn in [('smoke',['PROTOCOL.json','PILOT_INDEPENDENT_AUDIT.json','SMOKE_FUNCTIONAL_DECISION.json']),('formal',['PROTOCOL.json','FINAL_INDEPENDENT_AUDIT.json','FULL40_ELIGIBILITY_DECISION.json']),('full40',['PROTOCOL.json','FROZEN.json','PILOT_INDEPENDENT_AUDIT.json','PILOT_CONTINUATION_DECISION.json','FINAL_INDEPENDENT_AUDIT.json','FINAL_AUDIT_PROCESS.json'])]:
 for n in fn:(D/(stage+'_'+n)).write_bytes((E/stage/n).read_bytes())
for n in ['VALIDATION.json','FULL40_READER_VALIDATION.json','FULL40_METADATA_NOTES.json','FORMAL_COMPLETION_HEALTH.json','FULL40_COMPLETION_HEALTH.json']:(D/n).write_bytes((E/n).read_bytes())
for n in ['STAGE_OVERRUN_DIAGNOSIS.json','TIMING_EXCEPTION_RECORD_REVIEW.json']:(D/n).write_bytes((E/n).read_bytes())
for n in ['READ_ONLY_DIAGNOSTIC.log','TIMING_EXCEPTION_REVIEW.log']:(D/n).write_bytes((R/n).read_bytes())
(D/'REPORT_STATISTICS_CHECKS.json').write_bytes((R/'REPORT_STATISTICS_CHECKS.json').read_bytes())
extra=read(R/'EXTRA_VALIDATION_RECEIPT.json');tiny=R/'sync/R06_existing_tiny_validation.tar.gz';assert sha(tiny)==extra['sha256']
(D/'R06_已有tiny测试输入与记录.tar.gz').write_bytes(tiny.read_bytes())
(D/'EXTRA_VALIDATION_RECEIPT.json').write_bytes((R/'EXTRA_VALIDATION_RECEIPT.json').read_bytes())
with zipfile.ZipFile(D/'R06_冻结源码与验证.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in (R/'source').rglob('*'):
  if p.is_file():z.write(p,'source/'+p.relative_to(R/'source').as_posix())
 for stage in ['smoke','formal','full40']:
  for n in ['controller.py','audit_reader.py','adaptive_reader.py','interval_reader.py','r05_fft_reader.py','r06_reader.py','adaptive_r06_reader.py']:z.write(E/stage/n,stage+'/'+n)
 for n in ['validate_remote.py','validate_full40_reader_remote.py','FROZEN_PARAMETERS.json','冻结前适配说明.md','build_full40_report.py','review_timing_exceptions_remote.py','inspect_stage_overruns_remote.py','debug_terminal_reader_remote.py','check_report_statistics.py']:z.write(R/n,n)
with zipfile.ZipFile(D/'R06_冻结源码与验证.zip') as z:assert z.testzip() is None
archive=R/'R06_all_compact_evidence.tar.gz'
if '--reuse-evidence-archive' in sys.argv:
 old=read(D/'证据分片清单.json');assert archive.stat().st_size==old['joined_bytes'] and sha(archive)==old['joined_sha256']
else:
 with tarfile.open(archive,'w:gz') as tar:
  for p in E.rglob('*'):
   if p.is_file():tar.add(p,arcname=p.relative_to(E).as_posix())
parts=[]
with archive.open('rb') as f:
 for i in range(1,1000):
  data=f.read(48*2**20)
  if not data:break
  n=f'R06_全部紧凑记录.tar.gz.part{i:03d}';(D/n).write_bytes(data);parts.append({'name':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(D/'证据分片清单.json').write_text(json.dumps({'joined_name':'R06_全部紧凑记录.tar.gz','joined_sha256':sha(archive),'joined_bytes':archive.stat().st_size,'parts':parts},ensure_ascii=False,indent=2),encoding='utf-8')
(D/'合并证据分片.py').write_text("from pathlib import Path\nimport json,hashlib\nR=Path(__file__).resolve().parent\np=json.loads((R/'证据分片清单.json').read_text(encoding='utf-8'))\nout=R/p['joined_name']\nassert not out.exists()\nwith out.open('xb') as f:\n for q in p['parts']:\n  data=(R/q['name']).read_bytes();assert hashlib.sha256(data).hexdigest()==q['sha256'];f.write(data)\nassert hashlib.sha256(out.read_bytes()).hexdigest()==p['joined_sha256']\nprint(out)\n",encoding='utf-8')
checks={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in D.iterdir() if p.is_file() and p.name!='CHECKSUMS_SHA256.json'}
assert all(v['bytes']<95*2**20 for v in checks.values());(D/'CHECKSUMS_SHA256.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
(R/'DELIVERY_LOCAL_VERIFIED.json').write_text(json.dumps({'status':'PASS','stage':'FORMAL_COMPLETE','all_files_sha_verified':True,'terminal':3600,'independent_valid':A['independent_valid'],'full40_completed':True}),encoding='utf-8')
s=Path('E:/codex/S10_R05_dual_gated_20261127/publish_results.py').read_text().replace('S10_R05_dual_gated_20261127_RESULTS','S10_R06_quality_first_20261127_RESULTS').replace('Publish R05 gated dual surrogate smoke results and failed formal expansion decision','Publish R06 quality first full40 cold-start results and independent audits')
(R/'publish_results.py').write_text(s,encoding='utf-8')
print(json.dumps({'validity':byarm,'effects':effects,'delivery_files':len(checks),'evidence_bytes':archive.stat().st_size}))
