"""Read-only diagnostic of frozen terminal records; never invokes solver or LSS."""
from pathlib import Path
import sys,json
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/r06_quality_first_20261127';F=H/'full40';assert Path.cwd()==B
sys.path.insert(0,str(F));p=F/'audit_reader.py';s=p.read_text()
s=s[:s.index('allvalid=not errors and all(')]
s=s.replace('rows=[]\nfor ordinal,o in enumerate(',"rows=[]\noutcomes=[q for q in outcomes if q['case_index']==18 and q['arm']=='D_R06_QUALITY_DUAL' and q['rep'] in [8,9,10]]\nfor ordinal,o in enumerate(")
s=s.replace("except Exception as e:r['errors'].append(type(e).__name__+':'+str(e))","except Exception as e:\n  import traceback\n  traceback.print_exc()\n  r['errors'].append(type(e).__name__+':'+str(e))")
s+="\nprint(json.dumps({'diagnostic_rows':[{'identity':r['identity'],'valid':r['valid'],'errors':r['errors']} for r in rows],'source_and_input_errors':errors,'no_probability_sampling':True}))\n"
assert "DIAGNOSTIC" not in s
exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'_read_only_diagnostic'})
