from fractions import Fraction as F
import math
from adaptive_r06_reader import verify_adaptive_r06
from interval_reader import IntervalMath
from r05_fft_reader import r05_private_tools
_coeff={}
def verify_r06(raw,groups,costs,samples,capacity):
 m=raw['R06_model'];calls=raw['r06_native_calls'];hist=raw['r06_private_history'];assert raw['search_flow']=='quality_dual_gated'
 assert m['generator_LSS_calls']==0 and not m['historical_solution_inputs'] and m['private_cache_isolated'] and not m['private_FFT_is_certificate']
 assert not m['nearest_rounding_is_unbiased_claim'] and m['precision_damping']==12
 assert m['fallback_ratio']==.006 and m['ES95_finished_seconds']<=181 and m['mother_finished_seconds']<=241
 parent=dict(raw,search_flow='cvar_budget_calibrated',candidate_shortlist=m['ES95_pool'])
 budget=verify_adaptive_r06(parent,groups,costs,samples,capacity)
 select,cost,prob,marginal,near=r05_private_tools(groups,costs,samples,capacity)
 ref=m['sigma_reference_selection'];select(ref)
 variance=0.
 for j in ref:
  a=[F(v) for v in samples[j]];mu=sum(a,F())/len(a);variance+=float(sum((x*x for x in a),F())/len(a)-mu*mu)
 sigma=math.sqrt(max(0.,variance));near(sigma,m['sigma_ref_used']);tilts=[]
 for c,t,exact in zip([2,1,.5,3],m['entropic_t_values_used'],m['entropic_t_exact']):
  near(t,max(.001,min(50,c/sigma)) if sigma else 50);assert F.from_float(t)==F(exact);tilts.append(F(exact))
 em=raw['entropic_model'];assert F(em['eta_floor'])==F(3,5) and not em['historical_solution_inputs']
 cache=_coeff.setdefault((id(groups),str(capacity)),{});tabs={};interval=IntervalMath()
 for k,tab in enumerate(em['tables']):
  assert k<4 and tab['index']==k and F(tab['t'])==tilts[k]
  ck=(k,tilts[k])
  if ck not in cache:cache[ck]=[interval.weight([F(v) for v in a],tilts[k]) for a in samples]
  lower=[];upper=[]
  for j,item in enumerate(tab['items']):
   lo,hi=F(item['lower']),F(item['upper']);a,b=cache[ck][j];assert lo<=a<=b<=hi and hi-lo<F(1,10**35);lower.append(lo);upper.append(hi)
  tabs[k]=(lower,upper)
 ent={}
 for q in raw['entropic_proposals']:
  s=q['selection'];select(s);k=q['table_index'];eta=F(q['eta']);assert F(3,5)<=eta<=F(921,200) and F(q['t'])==tilts[k]
  lo,hi=tabs[k];rhs=F(str(capacity))-F(1,10**8)-eta/tilts[k]
  assert F(q['weight_sum_lower'])==sum((lo[j] for j in s),F()) and F(q['weight_sum_upper'])==sum((hi[j] for j in s),F())<=rhs==F(q['rhs_exact'])
  assert q['own_run_raw_samples'] and not q['empirical_0.99_sufficient_eta'];ent[tuple(s)]=q
 roots={tuple(q['selection']) for q in raw['adaptive_RO_proposals'] if q['robust_feasible'] and q['fixed_theta_feasible']}|set(ent)
 for x in hist:
  s=x['selection'];select(s);near(x['probability'],prob(s))
  if x['stage']=='entropic':assert tuple(s) in ent
  else:
   assert tuple(x['anchor']) in roots;dist=sum(a!=b for a,b in zip(s,x['anchor']));assert dist==x['distance']
   if x['stage'].endswith('_one'):assert dist==1
   elif x['stage'].endswith('_two'):assert dist==2
   else:assert 1<=dist<=(3 if x['stage'].startswith('B') else 5)
   roots.add(tuple(s))
 for task in raw['r06_local_MIP']:
  anchor=task['anchor'];p,values=marginal(anchor);near(p,task['anchor_probability']);near(task['rhs'],p-(.99 if task['kind']=='B' else .989))
  for j,r in enumerate(task['risk']):near(r,p-values[j])
  for s in task['returned']:
   d=sum(a!=b for a,b in zip(anchor,s));assert task['radius_min']<=d<=task['radius_max']
   assert cost(s)<=F(task['cost_upper_exact']) and (task['cost_lower'] is None or cost(s)>=F(task['cost_lower']))
   assert sum(task['risk'][j] for j in s)<=task['rhs']+1e-7
 incumbent=None;prior=None;A=B=0;seconds=0;known={}
 for q in calls:
  s=q['selection'];select(s);near(q['cost'],float(cost(s)))
  if incumbent is None:assert q['best_cost_before'] is None
  else:near(q['best_cost_before'],prior)
  stage=q['stage']
  if stage in ['mother_entropic_native_cdf','polish_channelA_native_cdf'] and incumbent is not None:assert cost(s)<=cost(incumbent)-F(1,1000000)
  if stage.startswith('polish_'):
   seconds+=q['elapsed'];near(q['private_probability'],prob(s))
   if stage=='polish_channelA_native_cdf':A+=1;assert q['private_probability']>=.9885
   else:B+=1;assert q['private_probability']>=.9898 and cost(incumbent)<=cost(s)<=cost(incumbent)*F(503,500)
  if q['state']=='accepted':
   c=q['certificate'];assert int(c['lower_numerator'])*100>=99*int(c['denominator']);known[tuple(s)]=c
   if incumbent is None or q['cost']<prior-1e-8:incumbent=s;prior=q['cost']
  elif q['state']=='infeasible':assert int(q['certificate']['upper_numerator'])*100<99*int(q['certificate']['denominator'])
 assert A+B<=100 and B<=15 and seconds<=150.5
 for q in m['certified_pool']:assert tuple(q['selection']) in known and q['certificate']==known[tuple(q['selection'])]
 for q in raw['candidate_shortlist']:assert tuple(q['selection']) in known and q['certificate']==known[tuple(q['selection'])]
 assert all(q.get('fresh_native_calls',0)<=15 for q in raw['adaptive_RO_queries'] if q['stage']=='fine')
 return dict(budget,entropic_proofs=len(ent),polish_history=len(hist),polish_mips=len(raw['r06_local_MIP']),polish_proposals=A+B)
def verify_r06_timing(t,wall):
 a=t['timing'];assert all(math.isfinite(x) and x>=-.001 for x in a.values());assert abs(sum(a.values())-t['elapsed_before_timing_save'])<.001 and abs(wall-sum(a.values()))<1
 assert a['polish_channelA_native_cdf']+a['polish_channelB_native_cdf']<=150.5
