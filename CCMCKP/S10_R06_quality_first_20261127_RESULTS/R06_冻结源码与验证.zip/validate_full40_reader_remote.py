"""Read existing tiny records only; no solver, LSS, probability sampling or replay."""
from pathlib import Path
from fractions import Fraction
from collections import Counter
import ast,json,hashlib,math,pickle
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/r06_quality_first_20261127';assert Path.cwd()==B
assert json.loads((H/'formal/FULL40_ELIGIBILITY_DECISION.json').read_text())['L4_eligible']
p=H/'audit_full40.py';tree=ast.parse(p.read_text());kept=[]
needed={'valid_selection','exact_rows','sample_count','prepare_radius','grid_row','integer_polynomial_count','selected_model_count'}
for q in tree.body:
 if isinstance(q,(ast.Import,ast.ImportFrom)) and (not isinstance(q,ast.ImportFrom) or q.module in ['pathlib','fractions','collections']):kept.append(q)
 elif isinstance(q,ast.FunctionDef) and q.name in needed:kept.append(q)
 elif isinstance(q,ast.ClassDef) and q.name in ['_MPZ','_Z']:kept.append(q)
 elif isinstance(q,ast.Assign):
  targets=[z.id for t in q.targets for z in ast.walk(t) if isinstance(z,ast.Name)]
  if targets and all(x in ['_lib','_ptr','_g'] for x in targets):kept.append(q)
 elif isinstance(q,ast.For):
  names=[z.id for z in ast.walk(q.target) if isinstance(z,ast.Name)]
  if names==['_name','_args']:kept.append(q)
ns={};exec(compile(ast.Module(body=kept,type_ignores=[]),str(p), 'exec'),ns)
checks=[]
for name,cap in [('LAB_3_2_500_',Fraction(1,2)),('LAB_2_2_500_',Fraction(5,4)),('LAB_2_2_30_',Fraction(5,4))]:
 root=H/'fixtures'/name;g=pickle.loads((root/'node_to_factor.pkl').read_bytes());groups=[g[k] for k in sorted(g)] if isinstance(g,dict) else g
 costs=[float(x) for x in (root/'cost.txt').read_text().split()];d={'path':root,'ordered':{},'groups':groups,'costs':costs}
 raw=json.loads((H/'integration'/name/'S10_search.json').read_text())
 count=0
 for q in raw['candidate_shortlist']:
  cert=q['certificate'];nu,de=ns['selected_model_count'](d,q['selection'],cert['bins'],cap,False)
  assert nu==int(cert['lower_numerator']) and de==int(cert['denominator']) and nu*100>=99*de
  assert de==ns['sample_count'](d)**len(groups);count+=1
 assert count>0;checks.append({'existing_fixture':name,'samples_per_item':ns['sample_count'](d),'independent_output_counts':count})
assert ns['integer_polynomial_count']([[0,0,1],[0,1,1]],1)==(2,9)
out={'status':'PASS','reader_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'existing_tiny_record_checks':checks,'new_three_atom_denominator_count':[2,9],'no_solver_or_LSS_rerun':True,'no_probability_sampling':True}
assert not (H/'FULL40_READER_VALIDATION.json').exists();(H/'FULL40_READER_VALIDATION.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
