from pathlib import Path
import json
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/r06_quality_first_20261127';F=H/'full40';assert Path.cwd()==B
a=json.loads((F/'FINAL_INDEPENDENT_AUDIT.json').read_text());out=[]
for r in a['rows']:
 if not r['errors']:continue
 p=F/'runs'/r['identity'];s=json.loads((p/'S10_search.json').read_text());m=s['R06_model'];result=json.loads((p/'RESULT.json').read_text())
 last=[x for x in s['r06_native_calls'] if x['stage']=='mother_es95_native_cdf'][-1:]
 out.append({'identity':r['identity'],'fallback_ratio':m['fallback_ratio'],'ES95_finished_seconds':m['ES95_finished_seconds'],'mother_finished_seconds':m['mother_finished_seconds'],'whole_seconds':r['process_wall_seconds'],'final_LSS':result['original_LSS_confidence'],'cost':result['cost'],'ES_last_call':last,'timing':m['timing']})
note={'scope':'original8_frozen_audit_exceptions','records':out,'original_audit_unchanged':True,'no_solver_LSS_or_probability_sampling':True}
(H/'STAGE_OVERRUN_DIAGNOSIS.json').write_text(json.dumps(note,indent=2));print(json.dumps(note))
