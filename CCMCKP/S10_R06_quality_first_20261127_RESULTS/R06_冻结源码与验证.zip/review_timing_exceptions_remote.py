"""Supplemental record review; original protocol validity is NOT upgraded."""
from pathlib import Path
import sys,types,json,hashlib
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/r06_quality_first_20261127';F=H/'full40';assert Path.cwd()==B
sys.path.insert(0,str(F));orig=json.loads((F/'FINAL_INDEPENDENT_AUDIT.json').read_text());bad={r['identity'] for r in orig['rows'] if r['errors']};assert len(bad)==8
p=F/'r06_reader.py';s=p.read_text()
edits={"assert m['fallback_ratio']==.006 and m['ES95_finished_seconds']<=181 and m['mother_finished_seconds']<=241":"assert m['fallback_ratio']==.006",'assert A+B<=100 and B<=15 and seconds<=150.5':'assert A+B<=100 and B<=15',"assert a['polish_channelA_native_cdf']+a['polish_channelB_native_cdf']<=150.5":"pass # only local stage elapsed cap omitted in supplemental review"}
for a,b in edits.items():assert a in s;s=s.replace(a,b)
module=types.ModuleType('r06_reader');module.__file__=str(p);sys.modules['r06_reader']=module;exec(compile(s,str(p),'exec'),module.__dict__)
q=F/'audit_reader.py';t=q.read_text();t=t[:t.index('allvalid=not errors and all(')]
t=t.replace('rows=[]\nfor ordinal,o in enumerate(',"rows=[]\noutcomes=[o for o in outcomes if o['identity'] in DIAGNOSTIC_IDENTITIES]\nfor ordinal,o in enumerate(")
t=t.replace("except Exception as e:r['errors'].append(type(e).__name__+':'+str(e))","except Exception as e:\n  import traceback\n  traceback.print_exc()\n  r['errors'].append(type(e).__name__+':'+str(e))")
ns={'__file__':str(q),'__name__':'_supplemental_record_review','DIAGNOSTIC_IDENTITIES':bad};exec(compile(t,str(q),'exec'),ns)
rows=ns['rows'];assert len(rows)==8
out={'scope':'supplemental_LSS_math_source_global600_review_of_original8_timing_exceptions','original_protocol_valid':False,'original_final_audit_sha256':hashlib.sha256((F/'FINAL_INDEPENDENT_AUDIT.json').read_bytes()).hexdigest(),'omitted_predicates_only':['ES95_finished_seconds<=181','mother_finished_seconds<=241','polish_native_seconds<=150.5'],'original_protocol_and_reader_files_unchanged':True,'no_solver_LSS_probability_rerun':True,'remaining_review_valid':sum(r['valid'] for r in rows),'global_errors':ns['errors'],'rows':rows}
assert not (H/'TIMING_EXCEPTION_RECORD_REVIEW.json').exists();(H/'TIMING_EXCEPTION_RECORD_REVIEW.json').write_text(json.dumps(out,indent=2));print(json.dumps({'supplemental_remaining_checks_valid':out['remaining_review_valid'],'global_errors':out['global_errors'],'row_errors':[(r['identity'],r['errors']) for r in rows if r['errors']],'original8_protocol_validity_not_changed':True}))
