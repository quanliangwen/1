"""Verify new completed records incrementally, then collect the server delivery."""
from pathlib import Path
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import tarfile
import time
import traceback

T = Path(__file__).resolve().parent
launch = json.loads((T/'LAUNCH.json').read_text())
HOST = 'junhao@10.112.162.60'
D = launch['folder']
R = launch['spool']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_state(name, value):
    path = T/name
    temporary = path.with_name(path.name+'.tmp')
    temporary.write_text(json.dumps(value,indent=2),encoding='utf8')
    os.replace(temporary,path)


def ssh(script,timeout=45):
    return subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15',HOST,'python3 -'],
                          input=script.encode(),capture_output=True,check=True,timeout=timeout).stdout


def status():
    script = 'R='+repr(R)+'\npid='+str(launch['pid'])+'\n'+r'''
from pathlib import Path
import json
R=Path(R)
x=json.load(open(R/'PROGRESS.json'));x.pop('active_tasks',None)
x['alive']=Path('/proc/'+str(pid)).exists()
x['postprocess_finished']=(R/'POSTPROCESS_FINISHED').exists()
x['error']=next((json.load(open(p)) for p in [R/'POSTPROCESS_ERROR.json',R/'DISPATCH_ERROR.json'] if p.exists()),None)
print(json.dumps(x))
'''
    return json.loads(ssh(script))


def unpack(data,target):
    target.mkdir(parents=True,exist_ok=True)
    root = target.resolve()
    with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
        for member in archive.getmembers():
            path = (root/member.name).resolve()
            if root not in path.parents or not (member.isfile() or member.isdir()):
                raise RuntimeError('Unexpected archive entry '+member.name)
            if member.isdir():
                path.mkdir(parents=True,exist_ok=True)
            else:
                path.parent.mkdir(parents=True,exist_ok=True)
                with archive.extractfile(member) as source,path.open('wb') as dest:
                    shutil.copyfileobj(source,dest)


def mirror():
    root = T/'verified_live_mirror'
    receipt = T/'MIRRORED_TRIALS.json'
    known = json.loads(receipt.read_text()) if receipt.exists() else []
    script = 'D='+repr(D)+'\nknown=set('+repr(known)+')\n'+r'''
from pathlib import Path
import json,sys,tarfile
D=Path(D)
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz') as archive:
 for folder in sorted(D.glob('runs/G_NONE/*/*')):
  key=folder.relative_to(D).as_posix()
  if key in known or not (folder/'TERMINAL.json').exists() or not (folder/'RESULT.json').exists():continue
  if not json.load(open(folder/'TERMINAL.json'))['completed']:continue
  for p in sorted(folder.rglob('*')):
   if p.is_file() and not p.is_symlink():archive.add(p,arcname=p.relative_to(D).as_posix(),recursive=False)
'''
    unpack(ssh(script,timeout=180),root)
    verified = set(known)
    for p in root.glob('runs/G_NONE/*/*/RESULT.json'):
        key = p.parent.relative_to(root).as_posix()
        if key in verified:
            continue
        r = json.loads(p.read_text())
        for e in r['evidence']:
            path = root/e['path']
            assert path.stat().st_size==e['bytes'] and sha(path)==e['sha256'],e['path']
        verified.add(key)
    write_state(receipt.name,sorted(verified))
    return len(verified)


def collect():
    stage = T/'collected'
    stage.mkdir(exist_ok=True)
    proc = subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15',HOST,
        'tar -czf - -C '+R+' delivery LAUNCH.json PROGRESS.json TERMINAL.json DISPATCH_ORDER.json dispatch.stdout.log'],
        capture_output=True,check=True,timeout=600)
    unpack(proc.stdout,stage)
    delivery = stage/'delivery'
    manifest = json.loads((delivery/'DELIVERY_MANIFEST.json').read_text())
    for row in manifest['files']:
        path = delivery/row['path']
        assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256'],row['path']
    audit = json.loads((delivery/'FINAL_AUDIT.json').read_text())
    assert audit['registered']==audit['completed']+audit['failed']==1200
    assert audit['backend']=='gurobi' and audit['both_local_phases_disabled']
    subprocess.run([sys.executable,'-X','utf8',str(T/'compare.py')],check=True)
    write_state('MONITOR_STATE.json',dict(state='results_verified',completed=audit['completed'],failed=audit['failed']))


def main():
    write_state('MONITOR_STATE.json',dict(state='monitoring',pid=os.getpid(),started=time.time()))
    last_mirror = 0
    while True:
        try:
            snapshot = status()
        except (subprocess.SubprocessError,ConnectionError) as error:
            print(json.dumps(dict(transient_transport_error=repr(error))),flush=True)
            time.sleep(30)
            continue
        write_state('LATEST_PROGRESS.json',snapshot)
        print(json.dumps(snapshot),flush=True)
        if snapshot['error']:
            raise RuntimeError(snapshot['error'])
        if snapshot['postprocess_finished']:
            collect()
            subprocess.run([sys.executable,'-X','utf8',str(T/'finish_delivery.py')],check=True)
            return
        if not snapshot['alive']:
            raise RuntimeError('Dispatcher stopped before producing its final audit')
        if time.time()-last_mirror>120:
            try:
                print(json.dumps(dict(verified_mirrored=mirror())),flush=True)
                last_mirror = time.time()
            except (subprocess.SubprocessError,ConnectionError) as error:
                print(json.dumps(dict(transient_transport_error=repr(error))),flush=True)
        time.sleep(30)


if __name__=='__main__':
    if '--once' in sys.argv:
        print(json.dumps(status()))
    else:
        try:
            main()
        except BaseException as error:
            write_state('MONITOR_STATE.json',dict(state='needs_attention',error=repr(error),traceback=traceback.format_exc()))
            raise
