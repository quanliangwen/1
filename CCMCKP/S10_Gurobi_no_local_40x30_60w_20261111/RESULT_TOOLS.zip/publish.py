"""Update only the named CCMCKP experiment folder and re-read the remote blobs."""
from pathlib import Path
import hashlib
import json
import subprocess

T = Path(__file__).resolve().parent
D = T/'delivery'
R = Path(r'E:\codex\CCMCKP_S2_active_01a1bf4a\delivery.git')
V = Path(r'E:\codex\CCMCKP_robust_continuous_20261110\verify.git')
FOLDER = 'S10_Gurobi_no_local_40x30_60w_20261111'
PREFIX = 'CCMCKP/'+FOLDER


def git(repo, *args, **options):
    return subprocess.check_output(['git','--git-dir',str(repo),*args],**options)


def tree(entries):
    return git(R,'mktree','-z','--missing',input=b'\0'.join(entries)+b'\0').decode().strip()


def set_child(base_tree, name, child):
    existing = [e for e in git(R,'ls-tree','-z',base_tree).split(b'\0') if e]
    kept = [e for e in existing if e.split(b'\t',1)[1].decode()!=name]
    return tree(kept+[f'040000 tree {child}\t{name}'.encode()])


def folder_tree(directory):
    entries = []
    for p in sorted(directory.iterdir()):
        if p.is_dir():
            entries.append(f'040000 tree {folder_tree(p)}\t{p.name}'.encode())
        else:
            blob = git(R,'hash-object','-w','--stdin',input=p.read_bytes()).decode().strip()
            entries.append(f'100644 blob {blob}\t{p.name}'.encode())
    return tree(entries)


def main():
    inventory = D/'CHECKSUMS_SHA256.json'
    files = {}
    for path in sorted(D.rglob('*')):
        if not path.is_file() or path==inventory:
            continue
        assert path.stat().st_size < 95*1024**2,path
        files[path.relative_to(D).as_posix()] = dict(bytes=path.stat().st_size,
            sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    inventory.write_text(json.dumps(files,indent=2))
    subtree = folder_tree(D)
    for _ in range(3):
        git(R,'fetch','--filter=blob:none','--depth=1','origin','main')
        parent = git(R,'rev-parse','FETCH_HEAD').decode().strip()
        existing = git(R,'ls-tree',parent+':CCMCKP',FOLDER)
        if existing:
            previous = git(R,'show',parent+':'+PREFIX+'/REGISTRATION.json')
            assert previous==(D/'REGISTRATION.json').read_bytes(),'Different registered experiment at this path'
        root = set_child(parent,'CCMCKP',set_child(parent+':CCMCKP',FOLDER,subtree))
        commit = git(R,'commit-tree',root,'-p',parent,'-m','Record full S10 Gurobi no-local benchmark').decode().strip()
        push = subprocess.run(['git','--git-dir',str(R),'push','origin',commit+':refs/heads/main'],capture_output=True,text=True)
        if push.returncode==0:
            break
    else:
        raise RuntimeError(push.stderr)

    git(V,'fetch','--filter=blob:none','--depth=1','origin',commit)
    remote = {}
    for entry in git(V,'ls-tree','-r','-z',commit+':'+PREFIX).split(b'\0'):
        if entry:
            header,name = entry.split(b'\t',1)
            remote[name.decode()] = header.split()[2].decode()
    assert set(remote)=={p.relative_to(D).as_posix() for p in D.rglob('*') if p.is_file()}
    blobs = list(dict.fromkeys(remote.values()))
    for i in range(0,len(blobs),200):
        git(V,'fetch','--no-tags','--no-write-fetch-head','origin',*blobs[i:i+200])
    for name,blob in remote.items():
        assert git(V,'cat-file','blob',blob)==(D/name).read_bytes(),name
    verified = dict(commit=commit,folder=PREFIX,files=len(remote),sha256_verified=True,
        url='https://github.com/quanliangwen/1/tree/'+commit+'/'+PREFIX)
    (T/'REMOTE_VERIFIED.json').write_text(json.dumps(verified,indent=2))
    print(json.dumps(verified),flush=True)


if __name__=='__main__':main()
