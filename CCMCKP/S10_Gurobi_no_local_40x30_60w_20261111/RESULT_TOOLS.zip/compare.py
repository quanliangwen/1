"""Join audited runs to the preceding S10 experiment by case and seed."""
from pathlib import Path
from statistics import mean
import json

T = Path(__file__).resolve().parent
D = T/'collected'/'delivery'
BASE = Path(r'E:\codex\CCMCKP_robust_continuous_20261110\artifact\formal\F003_S10_LSS_40x30_60w_20261110\delivery')


def load(directory, name):
    return json.loads((directory/name).read_text(encoding='utf8'))


def key(row):
    return row['case_index'], row['search_seed']


baseline_rows = load(BASE,'RUN_DETAILS.json')
old = {key(row):row for row in baseline_rows}
details = load(D,'RUN_DETAILS.json')
stats = load(D,'FINAL_STATISTICS.json')
assert len(old)==len(details)==1200 and set(old)=={key(row) for row in details}
old_stats = {row['index']:row for row in load(BASE,'FINAL_STATISTICS.json')}
for row in details:
    previous = old[key(row)]
    assert (row['instance'],row['capacity'])==(previous['instance'],previous['capacity'])
    row['baseline_cost'] = previous['cost']
    row['baseline_search_seconds'] = previous['S10_worker_search_seconds']
    if row['status']=='completed':
        row['paired_cost_difference'] = row['cost']-previous['cost']


def direction_counts(values):
    return dict(lower=sum(x < -1e-8 for x in values),tie=sum(abs(x)<=1e-8 for x in values),
                higher=sum(x > 1e-8 for x in values))


for row in stats:
    previous = old_stats[row['index']]
    row['baseline_avg'] = previous['Avg']
    row['baseline_best'] = previous['Best']
    row['baseline_search_seconds'] = previous['mean_S10_search_seconds']
    row['avg_difference'] = row['Avg']-previous['Avg'] if row['Avg'] is not None else None
    row['search_seconds_saved'] = (previous['mean_S10_search_seconds']-row['mean_S10_search_seconds']
                                   if row['mean_S10_search_seconds'] is not None else None)

valid = [r for r in details if r['status']=='completed']
complete_cases = [r for r in stats if r['avg_difference'] is not None]
summary = dict(baseline_commit='9173e70da7010cb26f327af4b356fee9774adbe7',matched_complete_runs=len(valid),
               compared_complete_cases=len(complete_cases),
               case_average_cost=direction_counts([r['avg_difference'] for r in complete_cases]),
               paired_run_cost=direction_counts([r['paired_cost_difference'] for r in valid]),
               mean_search_seconds=mean(r['S10_worker_search_seconds'] for r in valid),
               baseline_mean_search_seconds=mean(r['baseline_search_seconds'] for r in valid),
               large_case_mean_search_seconds=mean(r['S10_worker_search_seconds'] for r in valid if int(r['instance'].split('_')[1])>5),
               baseline_large_case_mean_search_seconds=mean(r['baseline_search_seconds'] for r in valid if int(r['instance'].split('_')[1])>5),
               cases=stats)
out = T/'comparison'
out.mkdir(exist_ok=True)
for name,value in [('RUN_DETAILS.json',details),('FINAL_STATISTICS.json',stats),('PAIRED_COMPARISON.json',summary)]:
    (out/name).write_text(json.dumps(value,indent=2),encoding='utf8')
(out/'FINAL_AUDIT.json').write_text((D/'FINAL_AUDIT.json').read_text(),encoding='utf8')
print(json.dumps({k:v for k,v in summary.items() if k!='cases'}))
