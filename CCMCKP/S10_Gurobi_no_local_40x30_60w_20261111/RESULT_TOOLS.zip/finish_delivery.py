"""Build the audited workbook and publish the final registered result bundle."""
from pathlib import Path
import json
import shutil
import subprocess
import sys

T = Path(__file__).resolve().parent
D = T/'delivery'
C = T/'collected'/'delivery'
X = T/'outputs'/'s10_gurobi_no_local_60'
NODE = Path(r'C:\Program Files\WindowsApps\OpenAI.CodexPrimaryRuntime.v26-1110-778-0_26.1110.778.0_x64__3k8sg7r9htsxt\dependencies\node\bin\node.exe')
MARKER = Path(r'C:\Users\Administrator\.codex\plugins\cache\openai-primary-runtime\spreadsheets\26.1110.11258\skills\spreadsheets\container_tools\mark_artifact_operation_started.mjs')


def main():
    status = json.loads((C/'FINAL_AUDIT.json').read_text())
    assert status['registered']==1200 and status['completed']+status['failed']==1200
    assert status['backend']=='gurobi' and status['both_local_phases_disabled']
    if not (T/'WORKBOOK_OPERATION_MARKED').exists():
        subprocess.run([str(NODE),str(MARKER),'--operation-kind','create','--expected-output-count','1','--output-format','xlsx'],cwd=T,check=True)
        (T/'WORKBOOK_OPERATION_MARKED').touch()
    subprocess.run([str(NODE),str(T/'build_workbook.mjs'),str(T/'comparison'),str(X)],cwd=T,check=True,timeout=600)
    shutil.copytree(C,D/'results',dirs_exist_ok=True)
    shutil.copyfile(T/'comparison'/'PAIRED_COMPARISON.json',D/'PAIRED_COMPARISON.json')
    for name in ['S10_Gurobi_no_local_40cases_30runs.xlsx','WORKBOOK_CHECK.json']:
        shutil.copyfile(X/name,D/name)
    (D/'BATCH_STATUS.json').write_text(json.dumps(dict(state='finished',workers=60,
        registered=1200,completed=status['completed'],failed=status['failed'],
        all40_have30_completed=status['all40_have30_completed']),indent=2))
    subprocess.run([sys.executable,'-X','utf8',str(T/'publish.py')],check=True,timeout=1800)
    remote = json.loads((T/'REMOTE_VERIFIED.json').read_text())
    (T/'MONITOR_STATE.json').write_text(json.dumps(dict(state='finished',completed=status['completed'],
        failed=status['failed'],**remote),indent=2))


if __name__=='__main__':main()
