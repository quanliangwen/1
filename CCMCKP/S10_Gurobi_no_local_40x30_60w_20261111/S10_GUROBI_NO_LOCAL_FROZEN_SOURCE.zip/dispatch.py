"""Run all 1200 registered trials through the tested Gurobi/no-local worker."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import threading
import time
import traceback

D = Path(__file__).resolve().parent
R = (D/'telemetry').resolve()
reg = json.loads((D/'REGISTRATION.json').read_text())
lock = threading.Lock()
active = {}
finished = []
stop = threading.Event()
started = time.time()


def atomic(path, value):
    temp = path.with_name(path.name+'.tmp')
    temp.write_text(json.dumps(value, indent=2))
    os.replace(temp, path)


def memory_available():
    return int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                    if line.startswith('MemAvailable:'))) * 1024


def free(path):
    info = os.statvfs(path)
    return info.f_bavail * info.f_frsize


def verify_sources_and_inputs():
    manifest = json.loads((D/'SOURCE_MANIFEST.json').read_text())
    for filename, expected in manifest.items():
        assert hashlib.sha256((D/filename).read_bytes()).hexdigest() == expected, filename
    inputs = json.loads((D/'BENCHMARK_MANIFEST.json').read_text())
    for instance, files in inputs.items():
        for filename, expected in files.items():
            path = Path(reg['benchmark_root'])/instance/filename
            assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, path


def progress():
    with lock:
        pending = list(active.values())
        done = list(finished)
    atomic(R/'PROGRESS.json', dict(time=time.time(), elapsed=time.time()-started,
           registered=1200, workers=60, active=len(pending),
           completed=sum(x['completed'] for x in done),
           failed=sum(not x['completed'] for x in done), terminal=len(done),
           memory_available_bytes=memory_available(), output_spool_free_bytes=free(R),
           active_tasks=pending))


def heartbeat():
    while not stop.wait(15):
        progress()


def run(case, rep):
    output = D/'runs'/'G_NONE'/f'case_{case:02}'/f'rep_{rep:02}'
    key = (case, rep)
    # 60 is the concurrent slot count. Defer new work during transient memory pressure.
    while memory_available()<12*1024**3 or free(R)<2*1024**3:
        time.sleep(3)
    began = time.monotonic()
    process = None
    try:
        output.mkdir(parents=True, exist_ok=False)
        with (output/'worker.stdout.log').open('x') as log:
            process = subprocess.Popen(['/usr/bin/python3','-u',str(D/'worker.py'),
                '--arm','G_NONE','--index',str(case),'--rep',str(rep)],cwd=D,stdout=log,
                stderr=subprocess.STDOUT,start_new_session=True)
            with lock:
                active[key]=dict(case=case,rep=rep,pid=process.pid)
            try:
                code = process.wait(timeout=3600)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
                code = 'watchdog_timeout'
        result = dict(case=case, rep=rep, exit_code=code,
                      completed=code==0 and (output/'RESULT.json').is_file())
    except Exception as error:
        result = dict(case=case,rep=rep,exit_code='dispatch_error',completed=False,error=repr(error))
    finally:
        if process is not None and process.poll() is None:
            os.killpg(process.pid,signal.SIGKILL)
            process.wait()
        with lock:
            active.pop(key,None)
    result['wall_seconds'] = time.monotonic()-began
    if output.is_dir():
        atomic(output/'TERMINAL.json',result)
    return result


def main():
    verify_sources_and_inputs()
    cases = [c['index'] for c in reg['cases']]
    tasks = []
    for rep in reg['repetitions']:
        pivot = (rep-1) % len(cases)
        tasks.extend((case,rep) for case in cases[pivot:]+cases[:pivot])
    assert len(tasks) == len(set(tasks)) == 1200
    atomic(R/'DISPATCH_ORDER.json',tasks)
    progress()
    monitor = threading.Thread(target=heartbeat,daemon=True)
    monitor.start()
    try:
        with ThreadPoolExecutor(max_workers=60) as pool:
            for future in as_completed([pool.submit(run,*t) for t in tasks]):
                result = future.result()
                with lock:
                    finished.append(result)
                print(json.dumps(result),flush=True)
    finally:
        stop.set()
        monitor.join()
    progress()
    atomic(R/'TERMINAL.json',finished)
    (R/'FINISHED').write_text('All 1200 trials terminal\n')
    subprocess.run([sys.executable,'-u',str(D/'finalize.py')],cwd=D,check=True)


if __name__ == '__main__':
    try:
        main()
    except BaseException as exc:
        atomic(R/'DISPATCH_ERROR.json',dict(error=repr(exc),traceback=traceback.format_exc()))
        raise
