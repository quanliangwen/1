"""Independent audit and packaging after all 1200 registered trials terminate."""
from pathlib import Path
import json,time,csv,io,hashlib,gzip,zipfile,statistics,traceback,os
D=Path(__file__).resolve().parent
R=(D/'telemetry').resolve()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2)
def main():
 while not (R/'FINISHED').exists():
  if (R/'POSTPROCESS_ERROR.json').exists():raise RuntimeError('Previous postprocess failure')
  time.sleep(30)
 reg=json.load(open(D/'REGISTRATION.json'));bm=json.load(open(D/'BENCHMARK_MANIFEST.json'));rsha=sha(D/'REGISTRATION.json')
 O=(D/'delivery').resolve();O.mkdir(exist_ok=False);(O/'archives').mkdir();C=O/'original_LSS_CSVs';C.mkdir()
 details=[];stats=[];audit_errors=[];failures=[];archives=[]
 for case in reg['cases']:
  index=case['index'];casefolder=D/'runs'/'G_NONE'/('case_%02d'%index);rs=[];combined={};headers={}
  for rep in range(1,31):
   F=casefolder/('rep_%02d'%rep)
   if not (F/'RESULT.json').exists():
    fail=json.load(open(F/'FAILED.json')) if (F/'FAILED.json').exists() else dict(error='No completed RESULT.json; inspect retained TERMINAL/stdout')
    failures.append(dict(index=index,rep=rep,evidence=fail));details.append(dict(case_index=index,instance=case['instance'],capacity=case['tmax'],rep=rep,search_seed=960000+rep,status='failed'));continue
   r=json.load(open(F/'RESULT.json'))
   assert r['case_index']==index and r['rep']==rep and r['search_seed']==960000+rep and r['registration_sha256']==rsha
   assert r['S10_source_sha256']==reg['S10_source_sha256'] and r['extra_real_probability_hard_filter'] is False
   assert r['original_LSS_output_tail_AST_sha256']==reg['original_LSS_output_tail_AST_sha256']
   for e in r['evidence']:assert sha(D/e['path'])==e['sha256'], 'Evidence changed '+e['path']
   meta=json.load(open(F/'S10_search.json.gz.run.json'))
   assert meta['backend']=='gurobi' and meta['local_phases']=='none'
   assert not any(p.get('enabled') for p in meta['phase_records'] if p['phase'].startswith('local_'))
   assert meta['seed']==960000+rep and meta['source_sha256']==reg['S10_source_sha256'] and meta['within_budget']
   for name,h in meta['input_sha256'].items():assert bm[case['instance']][name]==h, 'Registered input changed'
   assert not any(p.endswith('_dist.txt') for p in meta['opened_task_paths'])
   data=json.loads(gzip.decompress((F/'S10_search.json.gz').read_bytes()))
   assert tuple(r['selection']) in {tuple(p['selection']) for p in data['candidate_shortlist']}
   for csvpath in sorted((F/'result/Localsearch').glob('*.csv')):
    with csvpath.open(newline='') as f:
     reader=csv.reader(f);head=next(reader);rr=list(reader)
    if csvpath.name.endswith('_0.csv'):
     assert len(rr)==1 and int(rr[0][0])==rep-1
     row=dict(zip(head,rr[0]))
     assert float(row['Cost'])==r['cost'] and json.loads(row['Solution'])==r['selection']
     assert float(row['Confidence Level'])==r['original_LSS_confidence']
     assert float(row['Real Confidence Level'])==r['recorded_real_probability']
     assert float(row['Running Time'])==r['original_mainflow_search_seconds']
    headers[csvpath.name]=head;combined.setdefault(csvpath.name,[]).extend(rr)
   rs.append(r)
   details.append({k:r[k] for k in ['status','case_index','instance','capacity','rep','search_seed','cost','selection','original_LSS_confidence','recorded_real_probability','original_mainflow_search_seconds','S10_worker_search_seconds','wall_seconds_including_original_realP_reporting','S10_candidates']})
  for name,values in combined.items():
   with (C/name).open('x',newline='') as f:w=csv.writer(f);w.writerow(headers[name]);w.writerows(values)
  complete=len(rs)==30;costs=[r['cost'] for r in rs]
  stats.append(dict(index=index,instance=case['instance'],capacity=case['tmax'],registered_runs=30,completed_runs=len(rs),failed_runs=30-len(rs),
   Best=min(costs) if complete else None,Avg=statistics.mean(costs) if complete else None,Std=statistics.pstdev(costs) if complete else None,
   Time=statistics.mean(r['original_mainflow_search_seconds'] for r in rs) if complete else None,
   mean_S10_search_seconds=statistics.mean(r['S10_worker_search_seconds'] for r in rs) if complete else None,
   min_original_LSS_confidence=min(r['original_LSS_confidence'] for r in rs) if rs else None,
   min_recorded_real_probability=min(r['recorded_real_probability'] for r in rs) if rs else None,
   max_recorded_real_probability=max(r['recorded_real_probability'] for r in rs) if rs else None,
   Avg_minus_Best=statistics.mean(costs)-min(costs) if complete else None))
  # Archive each original trial exactly once; split case archives only if needed.
  files=sorted(p for rep in range(1,31) for p in (casefolder/('rep_%02d'%rep)).rglob('*') if p.is_file())
  def pack(items,label):
   p=O/'archives'/('CASE_%02d%s.zip'%(index,label))
   with zipfile.ZipFile(p,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for q in items:z.write(q,q.relative_to(D).as_posix())
   if p.stat().st_size>=90*1024**2:
    p.unlink();mid=len(items)//2
    if not mid:raise RuntimeError('Single file exceeds Git storage target')
    pack(items[:mid],label+'a');pack(items[mid:],label+'b');return
   with zipfile.ZipFile(p) as z:assert z.testzip() is None
   archives.append(dict(path=p.relative_to(O).as_posix(),bytes=p.stat().st_size,sha256=sha(p)))
  pack(files,'')
  print(json.dumps(dict(case=index,completed=len(rs),Best=stats[-1]['Best'],Avg=stats[-1]['Avg'])),flush=True)
 save(O/'FINAL_STATISTICS.json',stats);save(O/'RUN_DETAILS.json',details)
 with zipfile.ZipFile(O/'ORIGINAL_LSS_CSVS.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in sorted(C.iterdir()):z.write(p,p.name)
 infra=json.load(open(D/'RECOVERY_REGISTRATION.json')) if (D/'RECOVERY_REGISTRATION.json').exists() else None
 if infra:
  interrupted={(x['index'],x['rep']) for x in infra['interrupted_attempts']}
  for r in details:r['infrastructure_attempts']=2 if (r['case_index'],r['rep']) in interrupted else 1
  # Refresh details to retain the attempt history, never hide infrastructure retries.
  (O/'RUN_DETAILS.json').write_text(json.dumps(details,indent=2))
  import shutil
  for n in ['RECOVERY_REGISTRATION.json','INTERRUPTED_ATTEMPTS_MANIFEST.json','INFRASTRUCTURE_INTERRUPTED_ATTEMPTS.zip']:
   shutil.copyfile(D/n,O/n)
 summary=dict(registered=1200,completed=sum(s['completed_runs'] for s in stats),failed=len(failures),all40_have30_completed=all(s['completed_runs']==30 for s in stats),
  complete_case_count=sum(s['completed_runs']==30 for s in stats),statistics_from_original_variant0=True,
  real_probability_recorded_only=True,extra_real_probability_filter=False,backend='gurobi',both_local_phases_disabled=True,unchanged_original_S10_core_files=11,original_LSS_21_files_unchanged=True,
  matched_registered_S10_seeds_and_benchmark_inputs=True,original_per_run_CSV_and_result_SHA_verified=True,optimizer_reads_no_true_distribution_parameters=True,
  failure_policy='Failed registered repetitions retained; incomplete cases have no Best/Avg/Std/Time aggregate',failures=failures,
  infrastructure_interrupted_attempts=len(infra['interrupted_attempts']) if infra else 0,same_seed_infrastructure_retry_amendment=infra['amendment'] if infra else None,
  registration_sha256=rsha,finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),postprocessor_sha256=sha(D/'finalize.py'))
 for n,h in reg['S10_source_sha256'].items():assert sha(D/'S10_source'/n)==h
 for e in reg['original_LSS_sources']['files']:assert sha(D/'reference'/e['path'])==e['sha256']
 save(O/'FINAL_AUDIT.json',summary)
 files=[dict(path=p.relative_to(O).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(O.rglob('*')) if p.is_file()]
 save(O/'DELIVERY_MANIFEST.json',dict(files=files,excludes_self=True,archives=archives))
 (R/'POSTPROCESS_FINISHED').write_text('Independent audit, complete-case statistics and raw evidence packaging finished\n')
 print(json.dumps(summary),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException as ex:
  if not (R/'POSTPROCESS_ERROR.json').exists():save(R/'POSTPROCESS_ERROR.json',dict(time=time.time(),error=repr(ex),traceback=traceback.format_exc()))
  raise
