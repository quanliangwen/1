import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const R=path.dirname(fileURLToPath(import.meta.url));
const outputDir=path.join(R,'outputs','b1_v22_full40_20261128');
await fs.mkdir(outputDir,{recursive:true});
const S=JSON.parse(await fs.readFile(path.join(R,'statistics.json'),'utf8'));
if(S.rows.length!==1200||S.groups.length!==40||S.metrics.global_errors.length)throw Error('Incomplete or inconsistent final source');
const wb=Workbook.create(),s=wb.worksheets.add('40例汇总'),d=wb.worksheets.add('1200次明细');
const ink='#1F2937',navy='#17365D',gray='#F1F5F9',muted='#536171';
for(const [sh,lastcol,lastrow] of [[s,'L',47],[d,'M',1207]]){
 sh.showGridLines=false;
 sh.getRange(`A1:${lastcol}${lastrow}`).format.font={name:'Arial',size:10,color:ink};
 sh.getRange(`A1:${lastcol}${lastrow}`).format.verticalAlignment='center';
 sh.getRange(`A1:${lastcol}${lastrow}`).format.rowHeight=21;
 sh.getRange('A1').format.rowHeight=9;sh.getRange('A2').format.rowHeight=28;
 sh.getRange('A2').format.font={name:'Arial',size:14,bold:true,color:navy};
 sh.getRange(`A6:${lastcol}6`).format.borders={bottom:{style:'thin',color:'#CBD5E1'}};
 sh.getRange(`A7:${lastcol}7`).format={fill:navy,font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},horizontalAlignment:'center',verticalAlignment:'center',wrapText:true,rowHeight:48};
 sh.getRange(`A7:${lastcol}7`).format.borders={insideVertical:{style:'thin',color:'#FFFFFF'}};
 sh.freezePanes.freezeRows(7);sh.freezePanes.freezeColumns(2);
}
s.tabColor=navy;
s.getRange('A2').values=[['B1-v2.2 全40例测试结果']];
s.getRange('A3').values=[['运行数']];s.getRange('B3').formulas=[["=COUNTA('1200次明细'!A8:A1207)"]];
s.getRange('D3').values=[['有效']];s.getRange('E3').formulas=[["=SUM('1200次明细'!F8:F1207)"]];
s.getRange('G3').values=[['30次完整组']];s.getRange('H3').formulas=[['=COUNTIFS(D8:D47,30)']];
s.getRange('J3').values=[['完整最长(s)']];s.getRange('K3').formulas=[["=MAX('1200次明细'!I8:I1207)"]];
s.getRange('K3').setNumberFormat('0.000');
s.getRange('A4').values=[['达到Best均时：按未舍入成本判定命中，仅平均命中运行返回解的首次内部CDF认证时刻；H列为命中次数。']];
s.getRange('A5').values=[['Std采用ddof=1。J列为每次自身最终解的首次认证均时；K/L列为含加载、评价、LSS和保存的完整耗时，单位秒。']];
s.getRange('A4:L5').format.font={name:'Arial',size:10,color:muted,italic:true};
s.getRange('A7:L7').values=[['编号','算例','阈值T','有效次数\n/30','Best','Avg','样本Std\n(ddof=1)','命中Best\n次数','达到Best\n平均时间(s)','自身最终解首次\n达到均时(s)','完整平均\n耗时(s)','完整最长\n耗时(s)']];
s.getRange('A8:C47').values=S.groups.map(g=>[g.case_index,g.instance_label,g.capacity]);
s.getRange('D8:L47').formulas=S.groups.map((g,i)=>{
 const r=i+8,lo=8+30*i,hi=lo+29;
 const cost=`'1200次明细'!$G$${lo}:$G$${hi}`,first=`'1200次明细'!$H$${lo}:$H$${hi}`,whole=`'1200次明细'!$I$${lo}:$I$${hi}`,valid=`'1200次明细'!$F$${lo}:$F$${hi}`;
 return [`=COUNTIFS(${valid},1)`,`=IF(D${r}=30,MIN(${cost}),"n.a.")`,`=IF(D${r}=30,AVERAGE(${cost}),"n.a.")`,
  `=IF(D${r}=30,STDEV(${cost}),"n.a.")`,`=IF(D${r}=30,COUNTIFS(${cost},E${r}),"n.a.")`,
  `=IF(D${r}=30,SUMIFS(${first},${cost},E${r})/H${r},"n.a.")`,`=IF(D${r}=30,AVERAGE(${first}),"n.a.")`,
  `=AVERAGE(${whole})`,`=MAX(${whole})`];
});
d.getRange('A2').values=[['B1-v2.2 逐次运行记录']];
d.getRange('A3').values=[['来源：同目录 FINAL_INDEPENDENT_AUDIT.json 与冻结 PROTOCOL.json；每行一次登记运行，固定按编号及重复排序。']];
d.getRange('A4').values=[['协议SHA256：'+S.metrics.protocol_sha256]];
d.getRange('A5').values=[['独立审计SHA256：'+S.metrics.audit_sha256]];
d.getRange('A3:M5').format.font={name:'Arial',size:10,color:muted,italic:true};
d.getRange('A7:M7').values=[['编号','算例','阈值T','重复','seed','独立有效\n(1=是)','最终LSS\n接受成本','输出解首次\n认证时间(s)','完整运行\n时间(s)','最终LSS','内部最好\n认证成本','结果状态','运行身份']];
d.getRange('A8:M1207').values=S.rows.map(r=>[r.case_index,r.instance_label,r.capacity,r.rep,r.seed,r.valid,r.cost,r.first_found_seconds,r.whole_seconds,r.LSS,r.raw_best_cost,r.result_status,r.identity]);
for(let i=0;i<40;i++){
 if(i%2===1){s.getRange(`A${i+8}:L${i+8}`).format.fill=gray;d.getRange(`A${i*30+8}:M${i*30+37}`).format.fill=gray;}
 if(i>0)d.getRange(`A${i*30+8}:M${i*30+8}`).format.borders={top:{style:'thin',color:'#CBD5E1'}};
}
s.getRange('A28:L28').format.borders={top:{style:'medium',color:navy}};
for(const [sh,columns,last] of [[s,'L',47],[d,'M',1207]]){
 sh.getRange(`A8:${columns}${last}`).format.horizontalAlignment='right';
 sh.getRange(`A8:A${last}`).format.horizontalAlignment='center';sh.getRange(`B8:B${last}`).format.horizontalAlignment='left';
}
d.getRange('L8:M1207').format.horizontalAlignment='left';
s.getRange('A8:D47').setNumberFormat('0');s.getRange('E8:G47').setNumberFormat('0.000000');s.getRange('H8:H47').setNumberFormat('0');s.getRange('I8:L47').setNumberFormat('0.000');
d.getRange('A8:F1207').setNumberFormat('0');d.getRange('G8:G1207').setNumberFormat('0.000000');d.getRange('H8:I1207').setNumberFormat('0.000');d.getRange('J8:K1207').setNumberFormat('0.000000');
s.getRange('A:A').format.columnWidth=8;s.getRange('B:B').format.columnWidth=25;s.getRange('C:D').format.columnWidth=10;s.getRange('E:G').format.columnWidth=17;s.getRange('H:H').format.columnWidth=12;s.getRange('I:I').format.columnWidth=20;s.getRange('J:J').format.columnWidth=22;s.getRange('K:L').format.columnWidth=20;
d.getRange('A:A').format.columnWidth=8;d.getRange('B:B').format.columnWidth=25;d.getRange('C:D').format.columnWidth=10;d.getRange('E:E').format.columnWidth=14;d.getRange('F:F').format.columnWidth=12;d.getRange('G:K').format.columnWidth=20;d.getRange('L:L').format.columnWidth=24;d.getRange('M:M').format.columnWidth=37;
s.getRange('D8:D47').conditionalFormats.add('cellIs',{operator:'lessThan',formula:30,format:{fill:'#FEE2E2',font:{color:'#991B2B',bold:true}}});
d.getRange('F8:F1207').conditionalFormats.add('cellIs',{operator:'equal',formula:0,format:{fill:'#FEE2E2',font:{color:'#991B2B'}}});
// Exercise the requested definitions on temporary input edits, restoring every
// source value before the final calculation and export. No extra test sheet.
const recalculationChecks=[];
const fullIndex=S.groups.findIndex(g=>g.valid===30);
if(fullIndex>=0){
 const gr=fullIndex+8,dr=fullIndex*30+8,g=S.groups[fullIndex],v=d.getRange(`F${dr}`).values[0][0];
 d.getRange(`F${dr}`).values=[[0]];
 if(s.getRange(`D${gr}`).values[0][0]!==29||s.getRange(`F${gr}`).values[0][0]!=='n.a.')throw Error('Incomplete cohort guard did not recalculate');
 d.getRange(`F${dr}`).values=[[v]];recalculationChecks.push('30-to29 valid mean suppression');
 const c=d.getRange(`G${dr}`).values[0][0];d.getRange(`G${dr}`).values=[[c+1]];
 if(Math.abs(s.getRange(`F${gr}`).values[0][0]-(g.avg+1/30))>1e-8)throw Error('Average did not react to source edit');
 d.getRange(`G${dr}`).values=[[c]];recalculationChecks.push('source cost to Avg');
 const hitIndex=S.rows.findIndex(r=>r.case_index===g.case_index&&r.valid&&r.cost===g.best),hrow=hitIndex+8,t=S.rows[hitIndex].first_found_seconds;
 d.getRange(`H${hrow}`).values=[[t+1]];
 if(Math.abs(s.getRange(`I${gr}`).values[0][0]-(g.best_hit_first_mean_seconds+1/g.best_hit_count))>1e-8)throw Error('Conditional Best time did not react to hit');
 d.getRange(`H${hrow}`).values=[[t]];recalculationChecks.push('hit time to conditional time-to-Best');
}
const partialHitIndex=S.groups.findIndex(g=>g.valid===30&&g.best_hit_count<30);
if(partialHitIndex>=0){
 const g=S.groups[partialHitIndex],sr=partialHitIndex+8,ri=S.rows.findIndex(r=>r.case_index===g.case_index&&r.valid&&r.cost!==g.best),dr=ri+8,t=S.rows[ri].first_found_seconds;
 d.getRange(`H${dr}`).values=[[t+1]];
 if(Math.abs(s.getRange(`I${sr}`).values[0][0]-g.best_hit_first_mean_seconds)>1e-8||Math.abs(s.getRange(`J${sr}`).values[0][0]-(g.own_final_first_mean_seconds+1/30))>1e-8)throw Error('Non-hit time contaminated conditional time-to-Best');
 d.getRange(`H${dr}`).values=[[t]];recalculationChecks.push('non-hit time excluded from time-to-Best');
}
wb.recalculate();
let delta=0;
for(let i=0;i<40;i++){
 const g=S.groups[i],expected=[g.valid,g.best,g.avg,g.sample_std,g.best_hit_count,g.best_hit_first_mean_seconds,g.own_final_first_mean_seconds,g.whole_mean_seconds,g.whole_max_seconds];
 const actual=s.getRange(`D${i+8}:L${i+8}`).values[0];
 for(let j=0;j<expected.length;j++){
  if(expected[j]===null){if(actual[j]!=='n.a.')throw Error(`Expected unavailable ${i}/${j}`);}
  else {if(typeof actual[j]!=='number'||Math.abs(actual[j]-expected[j])>1e-8)throw Error(`Summary mismatch ${i}/${j}: ${actual[j]} vs ${expected[j]}`);delta=Math.max(delta,Math.abs(actual[j]-expected[j]));}
 }
}
await fs.writeFile(path.join(R,'WORKBOOK_INSPECT.ndjson'),(await wb.inspect({kind:'table',range:"'40例汇总'!D39:L47",include:'values,formulas',tableMaxRows:9,tableMaxCols:9,maxChars:4500})).ndjson);
const scan=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:30},maxChars:2000});
await fs.writeFile(path.join(R,'WORKBOOK_ERROR_SCAN.ndjson'),scan.ndjson);
for(const [sheetName,range,name] of [['40例汇总','A1:L17','summary_preview.png'],['40例汇总','D39:L47','large_cases_preview.png'],['1200次明细','A1:K15','detail_preview.png']]){
 const png=await wb.render({sheetName,range,scale:1.2,format:'png'});await fs.writeFile(path.join(R,name),new Uint8Array(await png.arrayBuffer()));
}
const xlsx=await SpreadsheetFile.exportXlsx(wb);const file=path.join(outputDir,'B1_v2_2_全40算例_1200次_结果汇总.xlsx');await xlsx.save(file);
await fs.writeFile(path.join(R,'WORKBOOK_QA.json'),JSON.stringify({status:'PASS',creator:'@oai/artifact-tool',sheets:2,raw_runs:1200,full30_cases:S.metrics.full30_cases,independently_valid:S.metrics.independent_valid,summary_formula_results_verified:360,max_delta:delta,recalculationChecks,workbook_path:file},null,2));
console.log(JSON.stringify({status:'EXPORTED',path:file,max_delta:delta,independently_valid:S.metrics.independent_valid}));
