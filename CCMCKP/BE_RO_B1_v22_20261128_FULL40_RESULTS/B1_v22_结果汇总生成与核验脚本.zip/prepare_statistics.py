from pathlib import Path
from datetime import datetime,timezone,timedelta
import json,statistics,hashlib,math
R=Path(__file__).resolve().parent;E=R/'evidence';D=R/'delivery';D.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
A=read(E/'FINAL_INDEPENDENT_AUDIT.json');P=read(E/'PROTOCOL.json');C=read(E/'COMPLETED.json')
assert A['terminal']==C['terminal']==1200 and not A['global_errors'] and len(A['rows'])==1200 and len(P['cases'])==40
rows=[];groups=[]
for c in P['cases']:
 part=[]
 for r in sorted((q for q in A['rows'] if q['case_index']==c['index']),key=lambda r:r['rep']):
  valid=r['valid'];x={'identity':r['identity'],'case_index':c['index'],'instance_label':c['instance'].rstrip('_'),'capacity':c['tmax'],
   'rep':r['rep'],'seed':r['seed'],'valid':int(valid),'cost':r.get('cost') if valid else None,
   'first_found_seconds':r.get('first_found_seconds') if valid else None,'whole_seconds':r['process_wall_seconds'],
   'LSS':r.get('LSS') if valid else None,'raw_best_cost':r.get('raw_best_cost') if valid else None,
   'result_status':'有效' if valid else ';'.join(r['errors'])}
  rows.append(x);part.append(x)
 assert len(part)==30 and {r['rep'] for r in part}==set(range(1,31))
 valid=[r for r in part if r['valid']];costs=[r['cost'] for r in valid];complete=len(valid)==30
 best=min(costs) if costs else None;hits=[r for r in valid if r['cost']==best]
 g={'case_index':c['index'],'instance_label':c['instance'].rstrip('_'),'capacity':c['tmax'],'terminal':30,'valid':len(valid),
  'best':best if complete else None,'avg':statistics.mean(costs) if complete else None,'sample_std':statistics.stdev(costs) if complete else None,
  'best_hit_count':len(hits) if complete else None,'best_hit_first_mean_seconds':statistics.mean(r['first_found_seconds'] for r in hits) if complete else None,
  'own_final_first_mean_seconds':statistics.mean(r['first_found_seconds'] for r in valid) if complete else None,
  'whole_mean_seconds':statistics.mean(r['whole_seconds'] for r in part),'whole_max_seconds':max(r['whole_seconds'] for r in part)}
 authoritative=next(q for q in A['groups'] if q['case_index']==c['index'])
 assert authoritative['valid']==g['valid'] and authoritative['official_best']==g['best'] and authoritative['official_avg']==g['avg']
 if complete:assert math.isclose(authoritative['official_std'],g['sample_std'],abs_tol=1e-12) and authoritative['best_hit_first_mean_seconds']==g['best_hit_first_mean_seconds']
 groups.append(g)
metrics={'terminal':1200,'independent_valid':sum(r['valid'] for r in rows),'failed':1200-sum(r['valid'] for r in rows),
 'full30_cases':sum(g['valid']==30 for g in groups),'whole_mean_all1200_seconds':statistics.mean(r['whole_seconds'] for r in rows),
 'whole_max_seconds':max(r['whole_seconds'] for r in rows),'max_active_observed':C['max_active_observed'],'resource_events':C['resource_events'],
 'protocol_sha256':sha(E/'PROTOCOL.json'),'audit_sha256':sha(E/'FINAL_INDEPENDENT_AUDIT.json'),
 'binary_sha256':P['source_and_binary_pins']['../bin/ccmckp_s10'],'global_errors':A['global_errors'],
 'files_sha_checked':A['files_sha_checked'],'KKT_witnesses_checked':A['KKT_witnesses_checked'],
 'native_integer_certificates_checked':A['native_integer_certificates_checked'],'audit_finished_beijing':datetime.fromisoformat(A['utc']).astimezone(timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M:%S'),
 'probability_resampling':False,'sample_std_ddof':1,'best_time_definition':'Only runs whose final accepted cost exactly equals case Best; mean first internal CDF certification time of their returned vectors, followed by unchanged final LSS acceptance.'}
assert len(rows)==1200 and len({r['identity'] for r in rows})==1200 and all(0<r['whole_seconds']<=600 for r in rows)
assert all(not r['valid'] or (0<=r['first_found_seconds']<=r['whole_seconds'] and .99<=r['LSS']<=1) for r in rows)
S={'metrics':metrics,'groups':groups,'rows':rows};(R/'statistics.json').write_text(json.dumps(S,ensure_ascii=False,indent=2),encoding='utf-8')
(D/'B1_v22_40例统计与1200次明细.json').write_text(json.dumps(S,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(metrics,ensure_ascii=False))
