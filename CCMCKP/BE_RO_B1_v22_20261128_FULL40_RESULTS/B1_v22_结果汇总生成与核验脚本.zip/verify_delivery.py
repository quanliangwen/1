from pathlib import Path
import json,hashlib,statistics,zipfile,xml.etree.ElementTree as ET,shutil
R=Path(__file__).resolve().parent;D=R/'delivery';E=R/'evidence'
read=lambda p:json.loads(p.read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
S=read(R/'statistics.json');m=S['metrics'];rows=S['rows'];groups=S['groups'];QA=read(R/'WORKBOOK_QA.json')
X=Path(QA['workbook_path']);assert len(rows)==1200 and len(groups)==40 and len({r['identity'] for r in rows})==1200
assert m['independent_valid']==sum(r['valid'] for r in rows) and not m['global_errors']
ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(X) as z:
 assert z.testzip() is None
 strings=[]
 if 'xl/sharedStrings.xml' in z.namelist():strings=[''.join(t.text or '' for t in s.findall('.//m:t',ns)) for s in ET.fromstring(z.read('xl/sharedStrings.xml'))]
 def cells(n):return {c.attrib['r']:c for c in ET.fromstring(z.read(n)).findall('.//m:sheetData/m:row/m:c',ns)}
 def value(c):
  if c is None:return None
  if c.attrib.get('t')=='s':return strings[int(c.find('m:v',ns).text)]
  if c.attrib.get('t')=='inlineStr':return ''.join(t.text or '' for t in c.findall('.//m:t',ns))
  v=c.find('m:v',ns)
  if v is None or v.text is None:return None
  if c.attrib.get('t')=='str':return v.text
  return float(v.text)
 s=cells('xl/worksheets/sheet1.xml');d=cells('xl/worksheets/sheet2.xml');delta=0
 for i,g in enumerate(groups,8):
  rr=[r for r in rows if r['case_index']==g['case_index']];vv=[r for r in rr if r['valid']];assert len(rr)==30 and len(vv)==g['valid']
  expected=[g['valid'],g['best'],g['avg'],g['sample_std'],g['best_hit_count'],g['best_hit_first_mean_seconds'],g['own_final_first_mean_seconds'],g['whole_mean_seconds'],g['whole_max_seconds']]
  for col,want in zip('DEFGHIJKL',expected):
   c=s[f'{col}{i}'];assert c.find('m:f',ns) is not None
   if want is None:assert value(c)=='n.a.'
   else:assert abs(value(c)-want)<1e-8;delta=max(delta,abs(value(c)-want))
  if len(vv)==30:
   costs=[r['cost'] for r in vv];best=min(costs);hit=[r for r in vv if r['cost']==best]
   assert g['best']==best and g['avg']==statistics.mean(costs) and g['sample_std']==statistics.stdev(costs)
   assert len(hit)==g['best_hit_count'] and statistics.mean(r['first_found_seconds'] for r in hit)==g['best_hit_first_mean_seconds']
   assert statistics.mean(r['first_found_seconds'] for r in vv)==g['own_final_first_mean_seconds']
 for i,r in enumerate(rows,8):
  for col,want in [('A',r['case_index']),('C',r['capacity']),('D',r['rep']),('E',r['seed']),('F',r['valid']),('G',r['cost']),('H',r['first_found_seconds']),('I',r['whole_seconds']),('J',r['LSS']),('K',r['raw_best_cost'])]:
   got=value(d.get(f'{col}{i}'))
   if want is None:assert got is None
   else:assert isinstance(got,(float,int)) and abs(got-want)<1e-10
  assert value(d[f'M{i}'])==r['identity'] and value(d[f'L{i}'])==r['result_status']
 assert all(c.attrib.get('t')!='e' for sh in [s,d] for c in sh.values())
 for name in ['xl/worksheets/sheet1.xml','xl/worksheets/sheet2.xml']:
  sh=ET.fromstring(z.read(name));p=sh.find('.//m:pane',ns);assert p is not None and float(p.attrib.get('xSplit',0))==2 and float(p.attrib.get('ySplit',0))==7
 assert value(s['B3'])==1200 and value(s['E3'])==m['independent_valid'] and value(s['H3'])==m['full30_cases']
receipt=read(E/'COLLECTION_RECEIPT.json')
for n,q in receipt['files'].items():assert sha(E/n)==q['sha256']
shutil.copy2(X,D/X.name)
for n in ['PROTOCOL.json','FINAL_INDEPENDENT_AUDIT.json','COLLECTION_RECEIPT.json']:shutil.copy2(E/n,D/n)
meta=read(R/'EXPORT.json');evidence=R/Path(meta['small_archive']).name;assert sha(evidence)==meta['small_sha256'];shutil.copy2(evidence,D/evidence.name)
notes=['# B1-v2.2全40例结果统计口径','',
 f'40例各30次，共1200次终末；独立有效{m["independent_valid"]}次，完整30次有效的算例{m["full30_cases"]}个；global_errors=[]。',
 f'审计完成时间（北京时间）：{m["audit_finished_beijing"]}。实际峰值{m["max_active_observed"]}并发；资源事件{m["resource_events"]}；单次最长完整耗时{m["whole_max_seconds"]:.6f}秒。', '',
 'Excel包含40例汇总和1200次明细。Best为本例30次最终原LSS接受成本的最小值；Avg为未四舍五入的算术均值；Std采用样本标准差ddof=1。只有30次全部独立有效才报告官方统计，缺失结果不赋假成本。', '',
 'I列“达到Best平均时间”：从最终成本严格等于该例本批Best的运行中，提取返回向量首次通过内部CDF认证的时刻（从完整进程启动计），这些向量随后通过原LSS终审，对这些时刻取均值。H列给出参与平均的命中次数。',
 'J列另列每次自身最终输出解的首次认证时间均值；K/L列为全部30次的完整平均/最长耗时，包含加载、构造、全部求解和评价、原LSS、保存/fsync及退出。源记录没有保留更早的未认证生成时刻，故首次达到时间采用冻结协议的首次内部认证时刻。', '',
 '原LSS≥.99、严格资源事件和样本索引0..L−1保持。每次均由当前run原始数据独立生成初始解，无历史解、跨重复输入或外部MIPstart。本次汇总只读取既有记录，没有新增求解或概率抽样。Best是本批实验最小成本，不代表已有全局最优证明。', '',
 '本批为新用户文档另行授权的独立全量实验，新seed1287201—1287230；旧35次冒烟的门槛、失败结论和记录均保留不变。', '',
 f'协议SHA256：`{m["protocol_sha256"]}`。',f'审计SHA256：`{m["audit_sha256"]}`。',f'二进制SHA256：`{m["binary_sha256"]}`。',
 f'独立审计核验文件SHA {m["files_sha_checked"]}项、KKT见证{m["KKT_witnesses_checked"]}项、整数CDF证书{m["native_integer_certificates_checked"]}份。',
 '完整逐次原始文件继续保留服务器，本交付附独立审计、协议和紧凑校验依据。']
(D/'B1_v22_全量统计口径与校验说明.md').write_text('\n'.join(notes)+'\n',encoding='utf-8')
with zipfile.ZipFile(D/'B1_v22_结果汇总生成与核验脚本.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in ['collect_remote.py','download.py','prepare_statistics.py','build_excel.mjs','verify_delivery.py']:z.write(R/n,n)
qa={'status':'PASS','stage':'FORMAL_COMPLETE','all_files_sha_verified':True,'terminal':1200,'independent_valid':m['independent_valid'],
 'full30_cases':m['full30_cases'],'sample_std_ddof':1,'summary_formula_results_verified':360,'all1200_detail_rows_verified':True,
 'conditional_time_to_Best_verified':True,'saved_xlsx_caches_and_freeze_panes_verified':True,'max_xlsx_difference':delta,
 'visual_review':True,'global_errors':[],'probability_resampling':False}
(D/'DELIVERY_QA.json').write_text(json.dumps(qa,indent=2),encoding='utf-8');(R/'DELIVERY_LOCAL_VERIFIED.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
checks={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in D.iterdir() if p.is_file() and p.name!='CHECKSUMS_SHA256.json'}
(D/'CHECKSUMS_SHA256.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
pub=(R.parent.parent/'CCMCKP_BE_RO_B1_v22_20261128/publish_code.py').read_text(encoding='utf-8').replace("FOLDER='BE_RO_B1_v2_20261128_CODE_ONLY'","FOLDER='BE_RO_B1_v22_20261128_FULL40_RESULTS'").replace('Prepare B1-v2 lambda-Huber source without compiling or running; wait for B2','Publish B1-v2.2 final40x30 Excel with audited best,avg,sample std and conditional time to Best')
(R/'publish_results.py').write_text(pub,encoding='utf-8');print(json.dumps(qa))
