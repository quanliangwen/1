from pathlib import Path
import json,hashlib,tarfile
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b1_v22_full_20261128';F=H/'full40';X=H/'report_exports_20261128'
assert Path.cwd()==B
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if not (F/'FINAL_AUDIT_PROCESS.json').exists():
 lines=(F/'FINAL_AUDIT.log').read_text().splitlines();n=0
 for line in lines:
  try:n+='identity' in json.loads(line)
  except ValueError:pass
 print(json.dumps({'status':'WAIT_FINAL_AUDIT','audited_rows':n,'solver_terminal':read(F/'COMPLETED.json')['terminal']}));raise SystemExit(0)
assert read(F/'FINAL_AUDIT_PROCESS.json')['rc']==0
A=read(F/'FINAL_INDEPENDENT_AUDIT.json');C=read(F/'COMPLETED.json');P=read(F/'PROTOCOL.json')
assert C['phase']=='completed' and C['terminal']==A['terminal']==1200 and C['pending']==0 and not A['global_errors']
assert sha(F/'PROTOCOL.json')=='69d56bfa25ed4c9f24c6002f9851e53111e6d8648aa80f423e4b835f5c57b442'
assert sha(H/'bin/ccmckp_s10')=='cd471cac2459b10557678ec667a55f3643f0be4497b792f2c4466d0ea45bc7af'
for n,h in P['source_and_binary_pins'].items():assert sha(F/n)==h,n
outs=sorted((read(p) for p in (F/'outcomes').glob('*.json')),key=lambda r:(r['case_index'],r['rep']))
assert len(outs)==1200 and len({o['identity'] for o in outs})==1200
lookup={r['identity']:r for r in A['rows']}
for o in outs:
 r=lookup[o['identity']];assert r['process_wall_seconds']==o['process_wall_seconds'] and r['seed']==o['seed'] and r['rc']==o['rc']
 if r['valid']:
  path=F/'runs'/o['identity']/'RESULT.json';q=o['output_files']['RESULT.json'];assert sha(path)==q['sha256'] and path.stat().st_size==q['bytes']
  result=read(path);assert result['cost']==r['cost'] and result['original_LSS_confidence']==r['LSS']>=.99
X.mkdir(exist_ok=True)
def immutable(name,data):
 p=X/name;content=json.dumps(data,ensure_ascii=False,indent=2).encode()
 if p.exists():assert p.read_bytes()==content
 else:p.write_bytes(content)
immutable('OUTCOMES_ALL.json',outs)
files={}
for n in ['PROTOCOL.json','FINAL_INDEPENDENT_AUDIT.json','COMPLETED.json','STATE.json','FROZEN.json','LAUNCH.json','FINAL_AUDIT_PROCESS.json','PILOT_CONTINUATION_DECISION.json','OUTCOMES_ALL.json']:
 p=X/n if n=='OUTCOMES_ALL.json' else F/n;files[n]={'sha256':sha(p),'bytes':p.stat().st_size}
receipt={'status':'PASS','terminal':1200,'independent_valid':A['independent_valid'],'global_errors':A['global_errors'],
 'all_terminal_outputs_already_SHA_verified_by_final_auditor':A['files_sha_checked'],'collection_additionally_verified_RESULT_files':A['independent_valid'],
 'source_and_binary_pins_checked':len(P['source_and_binary_pins']),'audit_sha256':sha(F/'FINAL_INDEPENDENT_AUDIT.json'),
 'protocol_sha256':sha(F/'PROTOCOL.json'),'no_new_solver_or_probability_calls':True,'raw_records_retained_at':str(F/'runs'),'files':files}
immutable('COLLECTION_RECEIPT.json',receipt)
p=X/'B1_v22_全40例统计与独立审计证据.tar.gz'
if not p.exists():
 with tarfile.open(p,'w:gz') as t:
  for n in files:t.add(X/n if n=='OUTCOMES_ALL.json' else F/n,arcname=n)
  t.add(X/'COLLECTION_RECEIPT.json',arcname='COLLECTION_RECEIPT.json')
export={'status':'PASS','small_archive':str(p),'small_bytes':p.stat().st_size,'small_sha256':sha(p),'terminal':1200,
 'independent_valid':A['independent_valid'],'audit_sha256':receipt['audit_sha256'],'protocol_sha256':receipt['protocol_sha256']}
immutable('EXPORT.json',export);print(json.dumps(export,ensure_ascii=False))
