from pathlib import Path
import subprocess,hashlib,json,tarfile
R=Path(__file__).resolve().parent;E=R/'evidence';E.mkdir(exist_ok=True)
root='/home/junhao/quan/parallel_test_solver/CCMKCP/work/be_ro_b1_v22_full_20261128/report_exports_20261128'
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60','cat '+root+'/EXPORT.json'],capture_output=True,timeout=60)
assert p.returncode==0,p.stderr.decode(errors='replace');M=json.loads(p.stdout);(R/'EXPORT.json').write_bytes(p.stdout)
target=R/Path(M['small_archive']).name
if not target.exists():
 p=subprocess.run(['scp','-o','BatchMode=yes','junhao@10.112.162.60:'+M['small_archive'],str(target)],capture_output=True,timeout=120);assert p.returncode==0,p.stderr.decode(errors='replace')
assert target.stat().st_size==M['small_bytes'] and hashlib.sha256(target.read_bytes()).hexdigest()==M['small_sha256']
with tarfile.open(target) as t:
 for m in t:
  out=(E/m.name).resolve();assert E.resolve() in out.parents and m.isfile();out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(t.extractfile(m).read())
C=json.loads((E/'COLLECTION_RECEIPT.json').read_text())
for n,q in C['files'].items():assert hashlib.sha256((E/n).read_bytes()).hexdigest()==q['sha256'] and (E/n).stat().st_size==q['bytes']
print(json.dumps({'status':'PASS','terminal':M['terminal'],'independent_valid':M['independent_valid'],'evidence_files':len(C['files'])}))
