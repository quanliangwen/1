cmake_minimum_required(VERSION 3.20)
project(ccmckp_s10 LANGUAGES C CXX)

set(S10_GUROBI_ROOT "$ENV{GUROBI_HOME}" CACHE PATH "Gurobi SDK root")
set(S10_GMP_ROOT "" CACHE PATH "GMP installation prefix")

find_path(S10_GMP_INCLUDE gmpxx.h HINTS "${S10_GMP_ROOT}/include" REQUIRED)
find_library(S10_GMP gmp HINTS "${S10_GMP_ROOT}/lib" REQUIRED)
find_library(S10_GMPXX gmpxx HINTS "${S10_GMP_ROOT}/lib" REQUIRED)

add_executable(ccmckp_s10 main.cpp model.cpp rng.cpp evaluation.cpp search.cpp mip.cpp report.cpp ellipsoid.cpp)
target_compile_features(ccmckp_s10 PRIVATE cxx_std_17)
target_include_directories(ccmckp_s10 SYSTEM PRIVATE "${S10_GMP_INCLUDE}" "${CMAKE_CURRENT_SOURCE_DIR}/third_party")
target_link_libraries(ccmckp_s10 PRIVATE "${S10_GMPXX}" "${S10_GMP}")
if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(ccmckp_s10 PRIVATE -Wall -Wextra -ffp-contract=off)
else()
    message(FATAL_ERROR "Use 64-bit GCC or Clang with unsigned __int128 support")
endif()

find_path(S10_GUROBI_INCLUDE gurobi_c.h HINTS "${S10_GUROBI_ROOT}/include" REQUIRED)
find_library(S10_GUROBI_LIBRARY NAMES gurobi130 gurobi120 gurobi110 gurobi100 gurobi
    HINTS "${S10_GUROBI_ROOT}/lib" REQUIRED)
target_include_directories(ccmckp_s10 SYSTEM PRIVATE "${S10_GUROBI_INCLUDE}")
target_link_libraries(ccmckp_s10 PRIVATE "${S10_GUROBI_LIBRARY}")

configure_file(CASES.json CASES.json COPYONLY)
configure_file(BENCHMARK_MANIFEST.json BENCHMARK_MANIFEST.json COPYONLY)

option(S10_BUILD_EGS_TESTS "Build the exhaustive tiny ellipsoid regression" OFF)
if(S10_BUILD_EGS_TESTS)
    enable_testing()
    add_executable(egs_math_test tests/ellipsoid_test.cpp model.cpp ellipsoid.cpp)
    target_compile_features(egs_math_test PRIVATE cxx_std_17)
    target_include_directories(egs_math_test PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}" "${S10_GUROBI_INCLUDE}")
    target_link_libraries(egs_math_test PRIVATE "${S10_GUROBI_LIBRARY}")
    if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
        target_compile_options(egs_math_test PRIVATE -Wall -Wextra -ffp-contract=off)
    endif()
endif()

