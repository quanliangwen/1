import pathlib,json,time,os,signal,hashlib
H=pathlib.Path(__file__).resolve().parent;rec=json.load(open(H/'S8_CAMPAIGN_ABORT_RECORD.json'));remaining={r['pid']:r for r in rec['active_children']};results=[]
def current_args(pid):
 try:return [v.decode() for v in pathlib.Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0') if v]
 except OSError:return []
while remaining:
 for pid,r in list(remaining.items()):
  args=current_args(pid);p=pathlib.Path(r['out']);side=p.with_name(p.name+'.run.json');state=None
  if args!=r['command']:state='active_at_abort_process_finished_or_reused'
  else:
   try:
    stat=pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split();started=int(stat[19])/os.sysconf('SC_CLK_TCK');age=float(pathlib.Path('/proc/uptime').read_text().split()[0])-started
    if age>640:
     os.kill(pid,signal.SIGKILL);state='original_640s_watchdog_applied_to_exact_orphan_worker'
   except (OSError,ValueError):continue
  if state:
   z=dict(**r,state=state,original_exit_status_unknown_after_parent_stop=True,sidecar_exists=side.exists())
   if side.exists():
    a=json.load(open(side));z.update(returned_selection=a.get('selected'),elapsed=a.get('elapsed'),within_budget=a.get('within_budget'),sidecar_sha256=hashlib.sha256(side.read_bytes()).hexdigest())
   results.append(z);del remaining[pid]
 (H/'S8_ABORTED_ACTIVE_STATUS.json').write_text(json.dumps(dict(remaining=len(remaining),finished=len(results),results=results),indent=2));time.sleep(3)
# Let pending original MC calls finish, then stop only the waiting S8 validator.
while True:
 p=H/'formal30_lss_validation/STATUS.json'
 if p.exists() and json.load(open(p)).get('active_unique',1)==0:break
 time.sleep(3)
stopped=[]
for proc in pathlib.Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 args=current_args(int(proc.name))
 for filename in ['formal_lss_validate.py','monitor_final_summary.py']:
  if len(args)>=3 and args[:2]==['python3','-u'] and args[2]==str(H/filename):
   os.kill(int(proc.name),signal.SIGTERM);stopped.append(dict(pid=int(proc.name),script=filename))
(H/'S8_ABORTED_ATTEMPT_ACCOUNTING.json').write_text(json.dumps(dict(status='aborted S8 campaign; raw partial results preserved; never substituted for S9 final 40x30',completed_regular_terminal_records=len(list((H/'formal30_lss').glob('*.terminal.json'))),active_at_abort_results=results,stopped_waiting_supervisors=stopped),indent=2));print('S8_ABORTED_ACCOUNTING_COMPLETE',flush=True)
