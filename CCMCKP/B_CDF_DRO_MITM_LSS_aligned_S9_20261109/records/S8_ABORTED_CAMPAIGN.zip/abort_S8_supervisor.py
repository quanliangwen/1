import pathlib,os,json,signal,time
H=pathlib.Path(__file__).resolve().parent;target=str(H/'formal_campaign.py');matches=[]
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  cmd=(p/'cmdline').read_bytes().split(b'\0');args=[s.decode() for s in cmd if s]
  if len(args)>=3 and args[:2]==['python3','-u'] and args[2]==target:matches.append(int(p.name))
 except (OSError,UnicodeDecodeError):pass
if len(matches)!=1:raise RuntimeError('Expected exactly one task supervisor; found '+str(matches))
pid=matches[0];active=[]
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  args=[s.decode() for s in (p/'cmdline').read_bytes().split(b'\0') if s]
  status=(p/'status').read_text();ppid=int(next(s.split()[1] for s in status.splitlines() if s.startswith('PPid:')))
  if ppid==pid and str(H/'frozen_candidate/run.py') in args:
   active.append(dict(pid=int(p.name),command=args,out=args[args.index('--out')+1]))
 except (OSError,UnicodeDecodeError,StopIteration,ValueError):pass
record=dict(status='aborted campaign; do not use as final 40x30 evidence',reason='S8 APP5_10 n30 full auxiliary model enumeration consumed entire search budget at case27 rep3, returning no solution; source frozen, failed attempt retained; fix in a separately registered full campaign',supervisor_pid=pid,supervisor_command=target,signal='SIGTERM to this exact supervisor only; active solver children allowed to finish',active_children=active,unix_time=time.time(),completed_terminal_records=len(list((H/'formal30_lss').glob('*.terminal.json'))),planned_runs=1200)
(H/'S8_CAMPAIGN_ABORT_RECORD.json').write_text(json.dumps(record,indent=2));os.kill(pid,signal.SIGTERM);print(json.dumps(dict(stopped_only_supervisor=pid,active_children_allowed_to_finish=len(active),completed_before_abort=record['completed_terminal_records'])))
