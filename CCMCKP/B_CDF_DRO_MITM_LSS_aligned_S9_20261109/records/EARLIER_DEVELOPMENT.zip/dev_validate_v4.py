import pathlib,json,gzip,subprocess,concurrent.futures,time
H=pathlib.Path(__file__).parent;D=H/'development_v4';V=H/'development_v4_lss';V.mkdir(exist_ok=True);cases=[c for c in json.load(open(H/'CASES.json')) if c['index']>=21]
def run(c):
 i=c['index'];term=D/f'S3_{i:02d}.terminal.json'
 while not term.exists():time.sleep(2)
 t=json.load(open(term));out=V/f'case_{i:02d}.json'
 if t['exit']!=0:print(i,'optimizer failure',flush=True);return
 r=json.load(gzip.open(D/f'S3_{i:02d}.json.gz','rt'));selection=r['selected']['selection'];cmd=['python3','-u',str(H/'lss_real_eval.py'),'--instance','/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/'+c['instance'],'--capacity',str(c['tmax']),'--selection',json.dumps(selection),'--out',str(out)]
 with open(str(out)+'.log','x') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
 if p.returncode:print(i,'evaluator failure',flush=True);return
 v=json.load(open(out));print(json.dumps(dict(index=i,cost=r['selected']['cost'],real_probability=v['real_probability'],passes_LSS_tolerance=v['real_probability']>=.985)),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as p:list(p.map(run,cases))
(V/'FINISHED').write_text('all 40 development tests accounted for')
