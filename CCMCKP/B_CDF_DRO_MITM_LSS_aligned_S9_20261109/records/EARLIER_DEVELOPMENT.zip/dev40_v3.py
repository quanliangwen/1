import pathlib,json,subprocess,concurrent.futures,time
H=pathlib.Path(__file__).parent;D=H/'development_v3';D.mkdir(exist_ok=True);cases=json.load(open(H/'CASES.json'))
def run(c):
 out=D/f"S3_{c['index']:02d}.json.gz";cmd=['/home/junhao/miniconda3/bin/python','-u',str(H/'candidate_v3/run.py'),'--instance','/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/'+c['instance'],'--capacity',str(c['tmax']),'--seed','955304','--seconds','600','--out',str(out)]
 with open(str(out)+'.log','x') as log:
  started=time.time()
  try:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=640);code=p.returncode
  except subprocess.TimeoutExpired:code='timeout'
 r=dict(index=c['index'],exit=code,wall=time.time()-started);(D/f"S3_{c['index']:02d}.terminal.json").write_text(json.dumps(r));print(json.dumps(r),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=16) as p:list(p.map(run,cases))
(D/'FINISHED').write_text('all 40 accounted for')
