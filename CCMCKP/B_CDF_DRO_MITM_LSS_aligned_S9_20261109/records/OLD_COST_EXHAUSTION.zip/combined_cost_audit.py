import pathlib,pickle,itertools,json,numpy as np
H=pathlib.Path(__file__).parent;B=pathlib.Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark');S=pathlib.Path('/home/quanliangwen/work/cdf_feasible_S2_20261109');s=json.load(open(S/'formal30/SUMMARY.json'));audit=json.load(open(S/'LSS_ACCEPTANCE_SCOPE_SUMMARY.json'));test={r['index']:r for r in audit['rows']};out=[]
for r in s['rows']:
 i=r['index']
 if not 21<=i<=28:continue
 p=B/r['instance'];gs=list(pickle.load(open(p/'node_to_factor.pkl','rb')).values());cost=np.loadtxt(p/'cost.txt');same=[];prefix=0
 for raw in itertools.product(*gs):
  ids=list(map(int,raw));v=float(cost[ids].sum())
  if v<=r['new_best']+1e-8:prefix+=1
  if abs(v-r['new_best'])<=1e-8:same.append(ids)
 run=r['runs'][0];ex=run['exhaustive'];mc=test[i]['runs'][0]['real_probability'];unique=len(same)==1 and same[0]==run['selection'];proved=ex.get('proved_optimal',False) and ex['refuted']==prefix-1 and unique
 # A cost-prefix rejection is only a statement about BOTH this solver's raw
 # empirical 0.99 constraint and the original LSS 0.985 final test.
 impossible=proved and (r['new_best']>r['old_best']+1e-8 or (abs(r['new_best']-r['old_best'])<=1e-8 and mc<.985))
 out.append(dict(index=i,instance=r['instance'],tmax=r['tmax'],old_best=r['old_best'],minimum_raw_empirical_99_cost=r['new_best'],all_cheaper_choices_exactly_refuted=ex['refuted'],total_choices=ex['total'],exact_cost_prefix_count=prefix,unique_minimum=unique,minimum_selection=run['selection'],minimum_selection_LSS_real_probability=mc,raw_empirical_optimality_verified_by_prefix_count=proved,old_cost_impossible_under_combined_constraints=impossible,refutations_sha256=ex['refutations_sha256']))
(H/'COMBINED_CONSTRAINT_COST_AUDIT.json').write_text(json.dumps(dict(scope='Raw empirical marginal product >=0.99 PLUS original fixed-seed LSS test >=0.985. Not a claim that LSS alone rejects all eight cost targets.',empirical_proof_source='S2 exact cost-ordered enumeration; raw data unchanged; every cheaper choice rejected by integer upper count',rows=out),indent=2));print(json.dumps(dict(all_eight_combined_constraint_targets_impossible=all(r['old_cost_impossible_under_combined_constraints'] for r in out),rows=len(out))))
