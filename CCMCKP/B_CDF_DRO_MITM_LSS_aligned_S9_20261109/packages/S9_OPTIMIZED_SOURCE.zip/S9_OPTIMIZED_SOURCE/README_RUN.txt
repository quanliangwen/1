CCMCKP S9 优化源码包

求解器：frozen_candidate/；该目录11个Python模块与40×30次正式验证使用的冻结版本逐字节一致。
最终验收：原LSS real_P_test，1000万次仿真，种子832273，sum<=Tmax，真实分布仿真概率>=0.985。内部名义CL=0.99。

运行环境：原Linux服务器，求解器Python3.13.9 / NumPy2.4.0 / SciPy1.17.1 / python-flint0.8.0。
原LSS真实仿真：Python3.8.10 / NumPy1.24.4 / SciPy1.10.1。

安装求解器依赖（在源码包根目录执行）：
python3.13 -m pip install --target vendor313 -r requirements_solver.txt

单算例示例（使用原服务器已有基准数据；输出目录必须是新的）：
python3.13 frozen_candidate/run.py --instance /home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/LAB_3_5_30_ --capacity 11 --seed 940001 --seconds 600 --out new_outputs/LAB3_T11_seed940001.json.gz

对得到的解向量调用原LSS验收（使用安装了requirements_LSS_evaluator.txt的Python3.8环境）：
python3.8 lss_real_eval.py --instance /home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/LAB_3_5_30_ --capacity 11 --selection '[12,10,5]' --out new_outputs/LAB3_T11_LSS.json

全40例的名称与容量见CASES.json。formal_campaign.py和formal_lss_validate.py为实际使用的批处理脚本，分别负责独立求解和外部LSS验收。脚本含原服务器Python及数据绝对路径，迁移机器需调整路径；正式结果目录不得覆盖复用。

源码包不重复打包原始基准数据。原始样本、成本和分组来自用户上传的LSS压缩包；文件身份及SHA256见INPUT_ARCHIVE_IDENTITIES.json、RAW_REFERENCE.json与lss_eval_reference/REFERENCE_MANIFEST.json。源码与数据目录应分开。

运行结果单独交付：RESULTS.md为全部40例统计；USER_VALIDATION_SUMMARY.json为1200次输出的概率统计；FINAL_SUMMARY.json保留严格600秒核验。5次含收尾总耗时超过600秒，概率仍合格，未补跑或剔除；时间偏差单列于报告。完整逐次日志位于records/FORMAL_1200_RECORDS.zip。

本包含代码与复现所需配置，不包含完整逐次日志和结果图。不要将修改后的源码与原冻结版本的验证结果混用。
