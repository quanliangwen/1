import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const R=path.dirname(fileURLToPath(import.meta.url)),D=path.join(R,'delivery');
const data=JSON.parse(await fs.readFile(path.join(R,'statistics.json'),'utf8'));
const wb=Workbook.create(),s=wb.worksheets.add('40例汇总'),d=wb.worksheets.add('1200次明细');
const navy='#17365D',light='#F1F5F9',ink='#1F2937',muted='#536171';
for(const [sh,lastcol,lastrow] of [[s,'N',47],[d,'L',1207]]){
 sh.showGridLines=false;sh.getRange(`A1:${lastcol}${lastrow}`).format.font={name:'Arial',size:10,color:ink};
 sh.getRange(`A1:${lastcol}${lastrow}`).format.verticalAlignment='center';sh.getRange(`A1:${lastcol}${lastrow}`).format.rowHeight=20;
 sh.getRange('A1').format.rowHeight=9;sh.getRange('A2').format.rowHeight=28;sh.getRange('A2').format.font={name:'Arial',size:14,bold:true,color:navy};
 sh.getRange(`A6:${lastcol}6`).format.borders={bottom:{style:'thin',color:'#CBD5E1'}};
 sh.freezePanes.freezeRows(7);sh.freezePanes.freezeColumns(2);
 sh.getRange(`A7:${lastcol}7`).format={fill:navy,font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},horizontalAlignment:'center',verticalAlignment:'center',wrapText:true,rowHeight:48};
 sh.getRange(`A7:${lastcol}7`).format.borders={insideVertical:{style:'thin',color:'#FFFFFF'}};
}
s.tabColor=navy;s.getRange('A2').values=[['B1全40例测试结果']];
s.getRange('A3').values=[['独立有效']];s.getRange('B3').formulas=[["=SUM('1200次明细'!F8:F1207)"]];
s.getRange('D3').values=[['失败']];s.getRange('E3').formulas=[['=1200-B3']];
s.getRange('G3').values=[['完整30次算例']];s.getRange('H3').formulas=[['=COUNTIFS(D8:D47,30)']];
s.getRange('J3').values=[['最长完整秒']];s.getRange('K3').formulas=[["=MAX('1200次明细'!I8:I1207)"]];
s.getRange('A4').values=[['Avg、样本Std及官方首次达Best均时：仅30/30有效时报告。n.a.表示缺完整有效结果；L至N列为部分有效组诊断。']];
s.getRange('A5').values=[['首次达Best均时只平均命中本例Best的运行；完整均时包含全部30次（含失败），单位秒。Best未宣称全局最优。']];
s.getRange('A4:N5').format.font={name:'Arial',size:10,italic:true,color:muted};
s.getRange('A7:N7').values=[['编号','算例','阈值T','有效次数\n/30','Best\n(有效解)','Avg\n(30全有效)','样本Std\n(ddof=1)','命中Best\n次数','首次达Best\n均时(s)','完整均时\n全部30次(s)','完整最长\n(s)','有效子集Avg\n仅诊断','有效子集Std\n仅诊断','子集达Best\n均时(s)仅诊断']];
d.getRange('A2').values=[['B1逐次测试结果']];
d.getRange('A3').values=[['每行一次登记运行。失败成本、概率与首次找到时间留空，完整耗时保留。独立有效1=是。']];
d.getRange('A4').values=[['来源：同目录FINAL_INDEPENDENT_AUDIT.json、DIAGNOSTICS.json；SHA256及原LSS验收说明见总结MD。']];
d.getRange('A5').values=[['首次找到时间从进程启动计，取最终输出解首次通过内部CDF认证时刻，随后原LSS终审接受。']];
d.getRange('A3:L5').format.font={name:'Arial',size:10,italic:true,color:muted};
d.getRange('A7:L7').values=[['编号','算例','阈值T','重复','seed','独立有效\n(1=是)','最终成本','输出解首次\n找到时间(s)','完整运行\n时间(s)','最终LSS','失败阶段','失败原始信息']];
d.getRange('A8:L1207').values=data.rows.map(x=>[x.case_index,x.instance_label,x.capacity,x.rep,x.seed,x.valid,x.cost,x.first_found_seconds,x.whole_seconds,x.LSS,x.failure_stage,x.failure_message]);
s.getRange('A8:C47').values=data.groups.map(x=>[x.case_index,x.instance_label,x.capacity]);
s.getRange('D8:N47').formulas=data.groups.map((g,i)=>{
 const r=i+8,lo=8+30*i,hi=lo+29,cr=`'1200次明细'!$G$${lo}:$G$${hi}`,first=`'1200次明细'!$H$${lo}:$H$${hi}`,tr=`'1200次明细'!$I$${lo}:$I$${hi}`,vr=`'1200次明细'!$F$${lo}:$F$${hi}`;
 return [`=COUNTIFS(${vr},1)`,`=IF(D${r}>0,MIN(${cr}),"n.a.")`,`=IF(D${r}=30,AVERAGE(${cr}),"n.a.")`,`=IF(D${r}=30,STDEV(${cr}),"n.a.")`,`=IF(D${r}>0,COUNTIFS(${cr},E${r}),"n.a.")`,`=IF(D${r}=30,SUMIFS(${first},${cr},E${r})/H${r},"n.a.")`,`=AVERAGE(${tr})`,`=MAX(${tr})`,`=IF(AND(D${r}>0,D${r}<30),AVERAGE(${cr}),"n.a.")`,`=IF(AND(D${r}>1,D${r}<30),STDEV(${cr}),"n.a.")`,`=IF(AND(D${r}>0,D${r}<30),SUMIFS(${first},${cr},E${r})/H${r},"n.a.")`];
});
for(let i=0;i<40;i++){
 if(i%2===1)s.getRange(`A${8+i}:N${8+i}`).format.fill=light;
 if(i%2===1)d.getRange(`A${8+i*30}:L${37+i*30}`).format.fill=light;
 if(i>0)d.getRange(`A${8+i*30}:L${8+i*30}`).format.borders={top:{style:'thin',color:'#CBD5E1'}};
}
s.getRange('A28:N28').format.borders={top:{style:'medium',color:navy}};
s.getRange('A8:N47').format.horizontalAlignment='right';s.getRange('B8:B47').format.horizontalAlignment='left';s.getRange('A8:A47').format.horizontalAlignment='center';
d.getRange('A8:L1207').format.horizontalAlignment='right';d.getRange('B8:B1207').format.horizontalAlignment='left';d.getRange('K8:L1207').format.horizontalAlignment='left';d.getRange('A8:A1207').format.horizontalAlignment='center';
s.getRange('A8:D47').setNumberFormat('0');s.getRange('E8:G47').setNumberFormat('0.000000');s.getRange('H8:H47').setNumberFormat('0');s.getRange('I8:K47').setNumberFormat('0.000');s.getRange('L8:M47').setNumberFormat('0.000000');s.getRange('N8:N47').setNumberFormat('0.000');s.getRange('K3').setNumberFormat('0.000');
d.getRange('A8:F1207').setNumberFormat('0');d.getRange('G8:G1207').setNumberFormat('0.000000');d.getRange('H8:I1207').setNumberFormat('0.000');d.getRange('J8:J1207').setNumberFormat('0.000000');
s.getRange('A:A').format.columnWidth=7;s.getRange('B:B').format.columnWidth=25;s.getRange('C:D').format.columnWidth=10;s.getRange('E:G').format.columnWidth=18;s.getRange('H:H').format.columnWidth=12;s.getRange('I:K').format.columnWidth=19;s.getRange('L:N').format.columnWidth=21;
d.getRange('A:A').format.columnWidth=7;d.getRange('B:B').format.columnWidth=25;d.getRange('C:D').format.columnWidth=10;d.getRange('E:E').format.columnWidth=14;d.getRange('F:F').format.columnWidth=12;d.getRange('G:J').format.columnWidth=20;d.getRange('K:K').format.columnWidth=33;d.getRange('L:L').format.columnWidth=70;
for(let i=0;i<data.rows.length;i++)if(!data.rows[i].valid){d.getRange(`L${i+8}`).format.wrapText=true;d.getRange(`A${i+8}:L${i+8}`).format.rowHeight=32;}
s.getRange('D8:D47').conditionalFormats.add('cellIs',{operator:'lessThan',formula:30,format:{fill:'#FEE2E2',font:{color:'#991B1B',bold:true}}});
d.getRange('F8:F1207').conditionalFormats.add('cellIs',{operator:'equal',formula:0,format:{fill:'#FEE2E2',font:{color:'#991B1B'}}});
wb.recalculate();
let maxDelta=0;
for(let i=0;i<40;i++){
 const g=data.groups[i],full=g.valid===30,expected=[g.valid,g.best_valid,g.official_avg,g.official_sample_std,g.valid?g.best_hit_count:null,g.official_best_hit_first_mean_seconds,g.whole_mean_all30_seconds,g.whole_max_all30_seconds,g.valid_only_avg,g.valid_only_sample_std,g.valid_only_best_hit_first_mean_seconds],actual=s.getRange(`D${i+8}:N${i+8}`).values[0];
 for(let j=0;j<expected.length;j++){if(expected[j]===null){if(actual[j]!=='n.a.')throw Error(`Expected unavailable ${i}/${j}:${actual[j]}`);}else{if(typeof actual[j]!=='number'||Math.abs(actual[j]-expected[j])>1e-8)throw Error(`Mismatch ${i}/${j}:${actual[j]} expected ${expected[j]}`);maxDelta=Math.max(maxDelta,Math.abs(actual[j]-expected[j]));}}
}
await fs.writeFile(path.join(R,'WORKBOOK_INSPECT.ndjson'),(await wb.inspect({kind:'table',range:"'40例汇总'!D39:N47",include:'values,formulas',tableMaxRows:9,tableMaxCols:11,maxChars:5000})).ndjson);
await fs.writeFile(path.join(R,'WORKBOOK_ERROR_SCAN.ndjson'),(await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:20},maxChars:2000})).ndjson);
for(const [sheetName,range,out] of [['40例汇总','A1:K18','summary_preview.png'],['40例汇总','D39:N47','partial_preview.png'],['1200次明细','F7:L17','detail_preview.png'],['1200次明细','F1028:L1036','failed_preview.png']]){const p=await wb.render({sheetName,range,scale:1.25,format:'png'});await fs.writeFile(path.join(R,out),new Uint8Array(await p.arrayBuffer()));}
const x=await SpreadsheetFile.exportXlsx(wb);await x.save(path.join(D,'B1_全40算例_1200次_结果汇总.xlsx'));
await fs.writeFile(path.join(R,'WORKBOOK_QA.json'),JSON.stringify({status:'PASS',sheets:2,raw_runs:1200,independently_valid:1028,failed_costs_blank:172,full30_cases:34,summary_formulas_checked:440,max_delta:maxDelta,creator:'@oai/artifact-tool'},null,2));
console.log(JSON.stringify({status:'PASS',max_delta:maxDelta}));
