from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import json,hashlib,tarfile,os
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b1_20261128';F=H/'full40';X=H/'report_exports_20261128'
assert Path.cwd()==B
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
C=read(F/'COMPLETED.json');A=read(F/'FINAL_INDEPENDENT_AUDIT.json');P=read(F/'PROTOCOL.json')
assert C['phase']=='completed' and C['terminal']==A['terminal']==1200 and C['pending']==0 and not A['global_errors']
assert read(F/'FINAL_AUDIT_PROCESS.json')['rc']==0 and sha(F/'PROTOCOL.json')=='a564937a02c5e74ab94d160d3ae67e88f489164155b7b1fdc61641dd8a340dee'
for n,h in P['source_and_binary_pins'].items():assert sha(F/n)==h,n
outs=sorted((read(p) for p in (F/'outcomes').glob('*.json')),key=lambda o:(o['case_index'],o['rep']))
assert len(outs)==1200 and len({o['identity'] for o in outs})==1200
diag=[];checks={};bytes_checked=0
for o in outs:
 root=F/'runs'/o['identity']
 for n,h in o['output_files'].items():
  p=root/n;assert p.stat().st_size==h['bytes'] and sha(p)==h['sha256'],(o['identity'],n)
  checks[p.relative_to(F).as_posix()]=h;bytes_checked+=h['bytes']
 raw=read(root/'S10_search.json') if (root/'S10_search.json').exists() else None
 m=raw.get('BE_RO_model',{}) if raw else {};qs=m.get('queries',[]);ns=m.get('native_calls',[])
 failure=read(root/'FAILED.json') if (root/'FAILED.json').exists() else None
 result=read(root/'RESULT.json') if (root/'RESULT.json').exists() else None
 diag.append({'identity':o['identity'],'case_index':o['case_index'],'rep':o['rep'],'seed':o['seed'],'rc':o['rc'],'whole_seconds':o['process_wall_seconds'],'termination_reason':o['termination_reason'],'failure':failure,'returned_LSS':result['original_LSS_confidence'] if result else None,'raw_pool_count':raw.get('raw_certified_pool_count') if raw else None,'raw_best_cost':raw.get('selected',{}).get('cost') if raw and isinstance(raw.get('selected'),dict) else None,'resource_unknown':m.get('resource_search_unknown'),'omega_star':m.get('omega_star'),'omega_resource_used':m.get('omega_resource_used'),'omega_cap':m.get('omega_cap'),'stop_seconds':m.get('stop_seconds'),'partial':m.get('partial'),'epsilon_fft_final':m.get('epsilon_fft_final'),'native_states':dict(Counter(q['state'] for q in ns)),'native_timeouts':sum(q['hard_timeout'] for q in ns),'candidate_decisions':dict(Counter(q['decision'] for q in m.get('candidates',[]))),'queries':[{'phase':q['phase'],'radius':q['radius'],'solver_status':q['solver_status'],'solutions':q['solutions_retained'],'distinct':q['distinct_returned'],'robust_pass':sum(w['robust_feasible'] for w in q['returned']),'whole_seconds':q['whole_subproblem_seconds']} for q in qs],'calibration_queries':len(m.get('calibration',[])),'critical_pool_queries':sum(q['phase']=='critical_pool' for q in qs),'critical_pool_total_solutions':sum(q['solutions_retained'] for q in qs if q['phase']=='critical_pool')})
X.mkdir(exist_ok=True)
assert not (X/'DIAGNOSTICS.json').exists(),'Export already exists: use existing immutable manifest'
(X/'DIAGNOSTICS.json').write_text(json.dumps(diag,ensure_ascii=False,indent=2))
(X/'OUTCOMES_ALL.json').write_text(json.dumps(outs,ensure_ascii=False,indent=2))
files={}
for n in ['PROTOCOL.json','FINAL_INDEPENDENT_AUDIT.json','COMPLETED.json','STATE.json','FROZEN.json','LAUNCH.json','PILOT_CONTINUATION_DECISION.json','FINAL_AUDIT_PROCESS.json']:
 p=F/n;files[n]={'sha256':sha(p),'bytes':p.stat().st_size}
files['DIAGNOSTICS.json']={'sha256':sha(X/'DIAGNOSTICS.json'),'bytes':(X/'DIAGNOSTICS.json').stat().st_size}
files['OUTCOMES_ALL.json']={'sha256':sha(X/'OUTCOMES_ALL.json'),'bytes':(X/'OUTCOMES_ALL.json').stat().st_size}
receipt={'status':'PASS','utc':datetime.now(timezone.utc).isoformat(),'terminal':1200,'independent_valid':A['independent_valid'],'global_errors':[],'all_terminal_output_sha_checked':len(checks),'output_bytes':bytes_checked,'original_audit_sha256':sha(F/'FINAL_INDEPENDENT_AUDIT.json'),'protocol_sha256':sha(F/'PROTOCOL.json'),'files':files}
(X/'COLLECTION_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
small=X/'B1_统计与诊断证据.tar.gz'
with tarfile.open(small,'w:gz') as tar:
 for n in files:tar.add(X/n if (X/n).exists() else F/n,arcname=n)
 tar.add(X/'COLLECTION_RECEIPT.json',arcname='COLLECTION_RECEIPT.json')
allfiles=[p for p in F.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
manifest={p.relative_to(F).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size} for p in allfiles}
(X/'ALL_COMPACT_FILES_SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
full=X/'B1_1200次全部紧凑证据.tar.gz'
with tarfile.open(full,'w:gz') as tar:
 for p in allfiles:tar.add(p,arcname='full40/'+p.relative_to(F).as_posix())
 tar.add(X/'ALL_COMPACT_FILES_SHA256.json',arcname='ALL_COMPACT_FILES_SHA256.json')
result={'status':'PASS','small_archive':str(small),'small_bytes':small.stat().st_size,'small_sha256':sha(small),'full_archive':str(full),'full_bytes':full.stat().st_size,'full_sha256':sha(full),'compact_files':len(allfiles),'audit_sha256':receipt['original_audit_sha256'],'outputs_sha_checked':len(checks)}
(X/'EXPORT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
