from pathlib import Path
from collections import Counter
import json,statistics,hashlib,csv,math
R=Path(__file__).resolve().parent;E=R/'evidence';D=R/'delivery';D.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
A=read(E/'FINAL_INDEPENDENT_AUDIT.json');P=read(E/'PROTOCOL.json');O=read(E/'OUTCOMES_ALL.json');G=read(E/'DIAGNOSTICS.json');C=read(E/'COMPLETED.json')
assert A['terminal']==C['terminal']==len(O)==len(G)==1200 and not A['global_errors'] and A['independent_valid']==1028
assert sha(E/'PROTOCOL.json')=='a564937a02c5e74ab94d160d3ae67e88f489164155b7b1fdc61641dd8a340dee'
assert sha(E/'FINAL_INDEPENDENT_AUDIT.json')=='0e4463086f67a2d3b88c25016083b5ee18e013909f6f4035f0927d25c9611ab0'
lookup={x['identity']:x for x in A['rows']};diag={x['identity']:x for x in G};assert len(lookup)==1200
rows=[];groups=[]
for c in P['cases']:
 rr=sorted((x for x in O if x['case_index']==c['index']),key=lambda x:x['rep'])
 assert len(rr)==30 and {x['rep'] for x in rr}==set(range(1,31))
 part=[]
 for o in rr:
  a=lookup[o['identity']];d=diag[o['identity']]
  assert a['seed']==o['seed']==P['seed_base']+o['rep'] and a['process_wall_seconds']==o['process_wall_seconds']==d['whole_seconds'] and 0<d['whole_seconds']<=600
  valid=a['valid'];assert valid==(o['rc']==0) and o['termination_reason'] is None
  if valid:assert a['LSS']>=.99 and 0<=a['first_found_seconds']<=o['process_wall_seconds']
  else:assert 'cost' not in a and len(a['errors'])==1 and a['errors'][0].startswith('AssertionError:process_failure:')
  failure_stage=None
  if not valid:
   if d['critical_pool_total_solutions']==0:failure_stage='临界池4次限时均零候选'
   elif d['raw_pool_count']==0:failure_stage='模型候选未进入内部CDF接受池'
   else:failure_stage='内部CDF接受后原LSS拒绝'
  x={'case_index':c['index'],'instance':c['instance'],'instance_label':c['instance'].rstrip('_'),'capacity':c['tmax'],'rep':o['rep'],'seed':o['seed'],'valid':int(valid),'cost':a.get('cost'),'first_found_seconds':a.get('first_found_seconds'),'whole_seconds':o['process_wall_seconds'],'LSS':a.get('LSS'),'identity':o['identity'],'failure_stage':failure_stage,'failure_message':d['failure']['error'] if d['failure'] else None,'critical_pool_total_solutions':d['critical_pool_total_solutions'],'native_timeouts':d['native_timeouts'],'resource_unknown':d['resource_unknown']}
  rows.append(x);part.append(x)
 vv=[x for x in part if x['valid']];cost=[x['cost'] for x in vv];tt=[x['whole_seconds'] for x in part];best=min(cost) if cost else None;hit=[x for x in vv if x['cost']==best]
 full=len(vv)==30;mean=statistics.mean(cost) if cost else None;std=statistics.stdev(cost) if len(cost)>1 else None;hitmean=statistics.mean(x['first_found_seconds'] for x in hit) if hit else None
 g={'case_index':c['index'],'instance_label':c['instance'].rstrip('_'),'capacity':c['tmax'],'terminal':30,'valid':len(vv),'failed':30-len(vv),'best_valid':best,'official_avg':mean if full else None,'official_sample_std':std if full else None,'best_hit_count':len(hit),'official_best_hit_first_mean_seconds':hitmean if full else None,'whole_mean_all30_seconds':statistics.mean(tt),'whole_max_all30_seconds':max(tt),'whole_min_all30_seconds':min(tt),'valid_only_avg':mean if not full else None,'valid_only_sample_std':std if not full else None,'valid_only_best_hit_first_mean_seconds':hitmean if not full else None,'failure_stages':dict(Counter(x['failure_stage'] for x in part if not x['valid']))}
 q=next(g for g in A['groups'] if g['case_index']==c['index']);assert q['valid']==g['valid'] and q['best_diagnostic']==best and q['official_avg']==g['official_avg']
 if full:assert math.isclose(q['official_std'],std,abs_tol=1e-12,rel_tol=0) and q['best_hit_first_mean_seconds']==hitmean
 groups.append(g)
oldroot=Path('E:/codex/S10_R07_adaptive_20261127/report_full40_20261128');oldfile=oldroot/'delivery/R07_全40例统计与1200次明细.json'
assert sha(oldfile)==read(oldroot/'REMOTE_VERIFIED.json')['files'][oldfile.name]['sha256']
old=read(oldfile)
comparisons=[]
for g in groups:
 h=next(x for x in old['groups'] if x['case_index']==g['case_index']);assert h['instance_label']==g['instance_label'] and h['capacity']==g['capacity']
 if g['valid']!=30:continue
 delta=g['official_avg']-h['avg']
 comparisons.append({'case_index':g['case_index'],'instance_label':g['instance_label'],'capacity':g['capacity'],'B1_best':g['best_valid'],'R07_best':h['best'],'B1_avg':g['official_avg'],'R07_avg':h['avg'],'B1_std':g['official_sample_std'],'R07_std':h['sample_std'],'B1_whole_mean':g['whole_mean_all30_seconds'],'R07_whole_mean':h['whole_mean_seconds'],'relative_mean_cost_change':delta/h['avg'],'mean_cost_sign':'优' if delta<0 else '劣' if delta>0 else '平'})
failed=[r for r in rows if not r['valid']];zero=[d for d in G if d['rc'] and not d['critical_pool_total_solutions']]
assert len(zero)==155 and all(q['solver_status']==9 for d in zero for q in d['queries'] if q['phase']=='critical_pool')
metrics={'terminal':1200,'independent_valid':1028,'failed':172,'valid_rate':1028/1200,'full30_cases':sum(g['valid']==30 for g in groups),'partial_cases':[g['case_index'] for g in groups if 0<g['valid']<30],'zero_valid_cases':[g['case_index'] for g in groups if not g['valid']],'constant_cost_full_cases':sum(g['valid']==30 and g['official_sample_std']==0 for g in groups),'whole_mean_all1200_seconds':statistics.mean(r['whole_seconds'] for r in rows),'whole_mean_valid1028_seconds':statistics.mean(r['whole_seconds'] for r in rows if r['valid']),'whole_mean_failed172_seconds':statistics.mean(r['whole_seconds'] for r in failed),'whole_max_seconds':max(r['whole_seconds'] for r in rows),'whole_sum_seconds':sum(r['whole_seconds'] for r in rows),'failure_stages':dict(Counter(r['failure_stage'] for r in failed)),'native_timeouts':sum(r['native_timeouts'] for r in rows),'resource_protections':C['resource_events'],'max_active_observed':C['max_active_observed'],'batch_elapsed_seconds':C['elapsed_seconds'],'global_errors':A['global_errors'],'KKT_witnesses_checked':A['KKT_witnesses_checked'],'native_integer_certificates_checked':A['native_integer_certificates_checked'],'files_sha_checked':A['files_sha_checked'],'protocol_sha256':sha(E/'PROTOCOL.json'),'audit_sha256':sha(E/'FINAL_INDEPENDENT_AUDIT.json'),'historical_34case_avg_sign':dict(Counter(x['mean_cost_sign'] for x in comparisons)),'historical_34case_equal_weight_relative_avg_change':statistics.mean(x['relative_mean_cost_change'] for x in comparisons),'historical_34case_B1_whole_mean':statistics.mean(x['B1_whole_mean'] for x in comparisons),'historical_34case_R07_whole_mean':statistics.mean(x['R07_whole_mean'] for x in comparisons),'historical_fresh_paired_test':False,'sample_std_ddof':1,'probability_resampling':False}
S={'metrics':metrics,'groups':groups,'rows':rows,'historical_comparison':comparisons,'protocol':P,'diagnostics':G}
(R/'statistics.json').write_text(json.dumps(S,ensure_ascii=False,indent=2),encoding='utf-8')
(D/'B1_40例统计与1200次明细.json').write_text(json.dumps({k:v for k,v in S.items() if k not in ['protocol','diagnostics']},ensure_ascii=False,indent=2),encoding='utf-8')
for name,data in [('B1_40例统计.csv',groups),('B1_1200次明细.csv',rows),('B1与R07_34例历史描述对照.csv',comparisons)]:
 with (D/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(data[0]),extrasaction='ignore');w.writeheader();w.writerows(data)
print(json.dumps(metrics,ensure_ascii=False))
