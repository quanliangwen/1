from pathlib import Path
import json,hashlib,statistics,math,csv,tarfile,zipfile,xml.etree.ElementTree as ET,shutil
R=Path(__file__).resolve().parent;D=R/'delivery';E=R/'evidence'
read=lambda p:json.loads(p.read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
S=read(R/'statistics.json');groups=S['groups'];rows=S['rows'];m=S['metrics'];assert len(groups)==40 and len(rows)==1200 and len({r['identity'] for r in rows})==1200
assert sum(r['valid'] for r in rows)==1028 and len([r for r in rows if not r['valid']])==172
for g in groups:
 rr=[r for r in rows if r['case_index']==g['case_index']];vv=[r for r in rr if r['valid']];assert len(rr)==30 and len(vv)==g['valid']
 assert g['whole_mean_all30_seconds']==statistics.mean(r['whole_seconds'] for r in rr)
 if g['valid']==30:
  assert g['official_avg']==statistics.mean(r['cost'] for r in vv) and g['official_sample_std']==statistics.stdev(r['cost'] for r in vv)
  hit=[r for r in vv if r['cost']==g['best_valid']];assert len(hit)==g['best_hit_count'] and g['official_best_hit_first_mean_seconds']==statistics.mean(r['first_found_seconds'] for r in hit)
 else:assert g['official_avg'] is g['official_sample_std'] is g['official_best_hit_first_mean_seconds'] is None
ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def cells(data):return {c.attrib['r']:c for c in ET.fromstring(data).findall('.//m:sheetData/m:row/m:c',ns)}
def val(c):return float(c.find('m:v',ns).text)
with zipfile.ZipFile(D/'B1_全40算例_1200次_结果汇总.xlsx') as z:
 assert z.testzip() is None
 ss=ET.fromstring(z.read('xl/sharedStrings.xml'));strings=[''.join(t.text or '' for t in s.findall('.//m:t',ns)) for s in ss]
 def get(c):
  if c.attrib.get('t')=='s':return strings[int(c.find('m:v',ns).text)]
  if c.attrib.get('t')=='inlineStr':return ''.join(t.text or '' for t in c.findall('.//m:t',ns))
  if c.attrib.get('t')=='str':return c.find('m:v',ns).text
  return val(c)
 s=cells(z.read('xl/worksheets/sheet1.xml'));d=cells(z.read('xl/worksheets/sheet2.xml'));delta=0
 for i,g in enumerate(groups,8):
  expected=[g['valid'],g['best_valid'],g['official_avg'],g['official_sample_std'],g['best_hit_count'] if g['valid'] else None,g['official_best_hit_first_mean_seconds'],g['whole_mean_all30_seconds'],g['whole_max_all30_seconds'],g['valid_only_avg'],g['valid_only_sample_std'],g['valid_only_best_hit_first_mean_seconds']]
  for col,want in zip('DEFGHIJKLMN',expected):
   c=s[f'{col}{i}'];assert c.find('m:f',ns) is not None
   if want is None:assert get(c)=='n.a.',(i,col,get(c))
   else:assert abs(get(c)-want)<1e-8,(i,col,get(c),want);delta=max(delta,abs(get(c)-want))
 for i,r in enumerate(rows,8):
  for col,want in [('A',r['case_index']),('C',r['capacity']),('D',r['rep']),('E',r['seed']),('F',r['valid']),('G',r['cost']),('H',r['first_found_seconds']),('I',r['whole_seconds']),('J',r['LSS'])]:
   key=f'{col}{i}'
   if want is None:assert key not in d or d[key].find('m:v',ns) is None,(i,col)
   else:assert abs(val(d[key])-want)<1e-10,(i,col)
 assert all(c.attrib.get('t')!='e' for sh in [s,d] for c in sh.values())
 for name in ['sheet1','sheet2']:
  pane=ET.fromstring(z.read('xl/worksheets/'+name+'.xml')).find('.//m:pane',ns);assert pane.attrib['xSplit']=='2' and pane.attrib['ySplit']=='7'
md=(D/'B1_BE_RO_Pure_全40例1200次_最终测试总结.md').read_text(encoding='utf-8')
for g in groups:
 b='—' if g['best_valid'] is None else f'{g["best_valid"]:.9f}';a='—' if g['official_avg'] is None else f'{g["official_avg"]:.9f}';std='—' if g['official_sample_std'] is None else f'{g["official_sample_std"]:.9f}';tm='—' if g['official_best_hit_first_mean_seconds'] is None else f'{g["official_best_hit_first_mean_seconds"]:.6f}'
 assert f'|{g["case_index"]}|{g["instance_label"]}|{g["capacity"]:g}|{g["valid"]}/30|{b}|{a}|{std}|{g["best_hit_count"]}|{tm}|' in md,g['case_index']
assert '1028' in md and '172' in md and '155' in md and '并行' in md and '首次达Best' in md
assert len(list(csv.DictReader((D/'B1_1200次明细.csv').open(encoding='utf-8-sig'))))==1200
manifest=None;checked={}
with tarfile.open(D/'B1_1200次全部紧凑证据.tar.gz','r:gz') as t:
 for member in t:
  assert member.isfile();f=t.extractfile(member)
  if member.name=='ALL_COMPACT_FILES_SHA256.json':manifest=json.loads(f.read());continue
  h=hashlib.sha256();size=0
  while True:
   chunk=f.read(1024*1024)
   if not chunk:break
   h.update(chunk);size+=len(chunk)
  assert member.name.startswith('full40/');checked[member.name[len('full40/'):]]={'sha256':h.hexdigest(),'bytes':size}
assert manifest==checked and len(checked)==14416
export=read(R/'EXPORT.json');assert sha(D/'B1_1200次全部紧凑证据.tar.gz')==export['full_sha256']
with zipfile.ZipFile(D/'B1_统计报告生成与校验脚本.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in ['prepare_statistics.py','build_report.py','build_excel.mjs','collect_remote.py','download.py','verify_delivery.py','inspect_remote.py','final_state_remote.py']:z.write(R/n,n)
qa={'status':'PASS','stage':'FORMAL_COMPLETE','all_files_sha_verified':True,'terminal':1200,'independent_valid':1028,'failed':172,'complete30_cases':34,'source_audit_global_errors':[],'xlsx_saved_summary_formula_results_checked':440,'xlsx_failed_cost_probability_firsttime_cells_blank_checked':172*3,'xlsx_max_difference_vs_independent_stats':delta,'all40_MD_statistics_rows_checked':True,'full_evidence_archive_members_SHA256_verified':len(checked),'full_evidence_archive_sha256':export['full_sha256'],'visual_review_both_sheets_and_missing_values_passed':True,'raw_worker_records_rerun':False,'probability_resampling':False,'historical_R07_comparison_descriptive_only':True}
(D/'DELIVERY_QA.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
checks={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in D.iterdir() if p.is_file() and p.name!='CHECKSUMS_SHA256.json' and not p.name.endswith('.ndjson')}
assert all(q['bytes']<95*2**20 for q in checks.values())
(D/'CHECKSUMS_SHA256.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8');(R/'DELIVERY_LOCAL_VERIFIED.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
pub=(R.parent/'publish_results.py').read_text(encoding='utf-8').replace("FOLDER='BE_RO_B1_20261128_OFFLINE_TEST'","FOLDER='BE_RO_B1_20261128_FULL40_RESULTS'").replace('Publish frozen BE-RO-Pure B1 source, validation and all40 offline launch evidence','Publish final B1 full40 results: 1028 valid, 172 retained failures, MD and Excel')
(R/'publish_results.py').write_text(pub,encoding='utf-8');print(json.dumps(qa))
