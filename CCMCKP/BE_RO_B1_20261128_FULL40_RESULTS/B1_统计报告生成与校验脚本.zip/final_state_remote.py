from pathlib import Path
import json
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b1_20261128';F=H/'full40';assert Path.cwd()==B
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  argv=(p/'cmdline').read_bytes().decode(errors='replace')
  if str(H) in argv and any(k in argv for k in ['controller.py','audit_reader.py','ccmckp_s10']):active.append({'pid':int(p.name),'argv':argv.split('\0')})
 except OSError:pass
read=lambda n:json.loads((F/n).read_text())
print(json.dumps({'active':active,'completed':read('COMPLETED.json'),'audit_process':read('FINAL_AUDIT_PROCESS.json')}))
