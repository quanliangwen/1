"""Postprocessing only: seal terminal observations; never starts optimization."""
import hashlib,json,os,subprocess,sys,time,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from common import read,sha,process_table,check_freeze,atomic

s=read(ROOT/'STATE.json');table=process_table()
assert s.get('scheduling_freeze_sha')=='96b28599b2facac514e30aac25382114b818e4a24810fb8e7428f3bde2b46a04'
assert s['status'] in ('performance_gates_passed_delivery_pending','full_failed_requires_new_mechanism','controller_error_not_complete')
assert not any(str(ROOT/'worker.py') in v['cmd'] for v in table.values())
assert check_freeze()=='2fb919ae87d332bf6bfbe8dc11c14b3c00a83bdd804a8e74edb7986598d92aa4'
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
p=subprocess.run([sys.executable,'-B',str(ROOT/'reporting/snapshot_readonly.py'),'--which','full'],capture_output=True,text=True,env=env)
assert p.returncode==0,p.stderr
original=Path(json.loads(p.stdout.strip().splitlines()[-1])['path']);d=read(original);tag=d['snapshot_utc']
amend=ROOT/'scheduling_amendments/A02_20261101T1144Z'
d.update(parallel_amendment=read(amend/'AMENDMENT.json'),full_gate=read(ROOT/'FINAL_GATE.json') if (ROOT/'FINAL_GATE.json').exists() else None,collection_scope='Terminal postprocessing only; no native resampling, initialization or search. Final delivery still requires review.')
snapshot=original.with_name(original.stem+'_A02.json');assert not snapshot.exists();atomic(snapshot,d)
entries={}
def add(p,name):
    assert name not in entries;entries[name]=p
def tree(p,prefix):
    for f in sorted(p.rglob('*')):
        if f.is_file():add(f,prefix+'/'+f.relative_to(p).as_posix())
for folder in sorted((ROOT/'waves').iterdir()):
    if folder.is_dir():tree(folder,'waves/'+folder.name)
for entry in read(ROOT/'REFERENCE_REGISTRY.json')['waves'].values():
    folder=Path(entry['directory']);tree(folder,'waves/'+folder.name)
for name in ['STATE.json','CURRENT_POINTER.json','FINAL_GATE.json','EVENTS.jsonl','FREEZE.json','PROTOCOL.json','INPUTS.json','REFERENCE_REGISTRY.json']:
    p=ROOT/name
    if p.exists():add(p,'control/'+name)
for name in ['audits','summaries','WAVE_POINTERS','scheduling_amendments']:
    tree(ROOT/name,'control/'+name)
add(snapshot,'reports/'+snapshot.name)
add(Path(__file__).resolve(),'offline_reporting/'+Path(__file__).name)
out=ROOT/'deliverable_snapshots'/('terminal_results_'+tag+'.zip');assert not out.exists();manifest={}
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,p in entries.items():
        b=p.read_bytes();z.writestr(name,b);manifest[name]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
    z.writestr('EXPORT_MANIFEST.json',json.dumps({'scope':'All terminal-stage records, including failed/incomplete attempts, and separately registered B references. Original raw inputs/source delivered separately. No new optimization.','snapshot':snapshot.name,'files':manifest,'algorithm_freeze':check_freeze(),'scheduling_freeze':s['scheduling_freeze_sha']},ensure_ascii=False,indent=2))
result={'path':str(out),'sha256':sha(out),'bytes':out.stat().st_size,'members':len(manifest)+1,'snapshot':snapshot.name,'terminal_comparison_records':len(d['terminal_records']),'state':s['status'],'goal_complete':False}
atomic(out.with_suffix('.zip.sha.json'),result);print(json.dumps(result))
