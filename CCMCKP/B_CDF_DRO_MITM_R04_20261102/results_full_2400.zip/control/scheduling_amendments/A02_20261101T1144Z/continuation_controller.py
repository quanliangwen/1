"""Scheduling amendment only. Imports immutable R04 workers, solvers and audits."""
import argparse,fcntl,gzip,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
from common import read,sha,atomic,check_freeze,process_table,mem_available,descendants_rss,envelope
from controller import Controller as OriginalController
from audit_campaign import audit_wave,audit_run

ENV=dict(os.environ,OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')

def scheduling_freeze():
    f=read(HERE/'SCHEDULING_FREEZE.json')
    for name,h in f['files'].items():assert sha(HERE/name)==h,name
    assert check_freeze()==read(HERE/'AMENDMENT.json')['original_freeze_sha']
    return sha(HERE/'SCHEDULING_FREEZE.json')

def preflight():
    scheduling_freeze();directory=HERE/'PREFLIGHT_WAVE';directory.mkdir(exist_ok=False)
    # Reuse the original full synthetic child with original-native RNG replay.
    # This new test checks reduced concurrency and refill; it is not a benchmark.
    from preflight_helpers import fixture_for
    table=process_table();foreign=sum(v['rss'] for v in table.values() if str(ROOT) not in v['cmd'])
    assert mem_available()>=24*envelope({'m':12,'max_group':5,'n':60})+5*2**30+max(2*2**30,foreign//2)
    jobs=[];active={};pending=list(range(1,31));peak=0
    atomic(directory/'START.json',{'mode':'new_reduced_scheduling_functionality_only'})
    try:
        while pending or active:
            while pending and len(active)<24:
                rep=pending.pop(0);log=(directory/('r%02d.log'%rep)).open('x');started=time.monotonic()
                p=subprocess.Popen([sys.executable,'-B',str(ROOT/'functional_preflight.py'),'--child','--rep',str(rep),'--started',str(started),'--directory',str(directory)],stdout=log,stderr=subprocess.STDOUT,env=ENV,start_new_session=True)
                j=dict(rep=rep,p=p,log=log,started=started);jobs.append(j);active[p.pid]=j;peak=max(peak,len(active))
                if len(jobs)==24:assert sum(x['p'].poll() is None for x in jobs)==24
            assert mem_available()>=5*2**30
            for pid,j in list(active.items()):
                if j['p'].poll() is not None:
                    j['log'].flush();os.fsync(j['log'].fileno());j['log'].close();j['elapsed']=time.monotonic()-j['started'];del active[pid]
                elif time.monotonic()-j['started']>=600:raise RuntimeError('synthetic hard600 timeout')
            time.sleep(.05)
        rows=[]
        for j in jobs:
            assert j['p'].returncode==0
            d=json.loads(gzip.decompress((directory/('r%02d.json.gz'%j['rep'])).read_bytes()));rng=read(directory/('r%02d.RNG.json'%j['rep']))
            name,T,cost,active_aux=fixture_for(j['rep']);s=d['selected'];h=[x for x in d['match_history'] if x.get('engine')=='entropic_cost_MILP']
            assert s and s['cost']==cost and s['probability']>=.99 and d['seed']==832272+j['rep'] and j['elapsed']<=600
            assert rng['passed'] and len(h)==1 and h[0]['active']==active_aux and len(d['match_history'])==10
            cfg=d['config'];assert cfg['time_budget']==600 and cfg['work_reserve']==15 and cfg['native_draws']==1000000 and cfg['native_gate']==.99 and cfg['screen_gate']==.975
            rows.append({'rep':j['rep'],'seed':d['seed'],'elapsed':j['elapsed'],'cost':s['cost'],'probability':s['probability'],'record_sha':sha(directory/('r%02d.json.gz'%j['rep'])),'RNG_sha':sha(directory/('r%02d.RNG.json'%j['rep']))})
        assert len(rows)==30 and peak==24
        atomic(HERE/'PREFLIGHT.json',{'passed':True,'scheduling_freeze':scheduling_freeze(),'actual_peak_concurrency':peak,'records':rows,'official_performance_runs':0,'scope':'30 new synthetic queue/refill tests using immutable original child and original-native RNG replay; no repeated formal stage.'})
        print('Scheduling synthetic preflight passed',flush=True)
    finally:
        for pid,j in active.items():
            if j['p'].poll() is None:
                try:os.killpg(pid,signal.SIGKILL)
                except ProcessLookupError:pass
            j['p'].wait();j['log'].flush();os.fsync(j['log'].fileno());j['log'].close()

class Continuation(OriginalController):
    def __init__(self):
        self.schedule_sha=scheduling_freeze();self.amend=read(HERE/'AMENDMENT.json')
        assert read(HERE/'PREFLIGHT.json')['passed'] and read(HERE/'PREFLIGHT.json')['scheduling_freeze']==self.schedule_sha
        old=process_table().get(self.amend['old_controller']['pid'])
        assert not(old and old['start_ticks']==self.amend['old_controller']['start_ticks'])
        assert not any(str(ROOT/'worker.py') in v['cmd'] for v in process_table().values())
        for directory,files in self.amend['reused_valid_wave_files'].items():
            for name,h in files.items():assert sha(Path(directory)/name)==h
        super().__init__() # Includes the original shared singleton flock.
        # Original growth origin was private controller state. Zero is a
        # conservative lower bound, so handing off never reduces that reserve.
        self.foreign_start=0
        for p in (ROOT/'waves').glob('*/WAVE.json'):
            w=read(p);case=next(c for c in self.reg['cases'] if c['index']==w['index'])
            self.peak[case['instance']]=max(self.peak.get(case['instance'],0),w.get('peak_worker_rss',0))
        for idx,e in self.reference_registry['waves'].items():
            case=next(c for c in self.reg['cases'] if c['index']==int(idx));self.peak[case['instance']]=max(self.peak.get(case['instance'],0),e['peak_worker_rss'])
    def state(self,status,**kwargs):
        self.status=status
        d=dict(schema='R04_scheduling_amendment_A01',status=status,controller_pid=os.getpid(),controller_start_ticks=self.ticks,freeze_sha=self.freeze,scheduling_freeze_sha=self.schedule_sha,updated_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),registered_repetitions=30,parallel_ceiling=30,high_memory_ceiling=24,active=list(self.active),goal_achieved=False,**kwargs)
        atomic(HERE/'STATE.json',d);atomic(ROOT/'STATE.json',d)
        atomic(ROOT/'CURRENT_POINTER.json',dict(root=str(ROOT),state='STATE.json',controller_pid=os.getpid(),controller_start_ticks=self.ticks,freeze_sha=self.freeze,scheduling_freeze_sha=self.schedule_sha,controller_source=str(Path(__file__).resolve()),scheduling_directory=str(HERE),status=status))
    def event(self,name,**kwargs):
        d=dict(kwargs)
        if 'scheduling_freeze_sha' in d:assert d['scheduling_freeze_sha']==self.schedule_sha
        d.update(event=name,utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),monotonic=time.monotonic(),scheduling_freeze_sha=self.schedule_sha)
        with (HERE/'EVENTS.jsonl').open('a') as f:f.write(json.dumps(d)+'\n');f.flush();os.fsync(f.fileno())
        print(json.dumps(d),flush=True)
    def ticket(self,case,count,table=None):
        table=table or process_table();foreign=sum(v['rss'] for v in table.values() if str(ROOT) not in v['cmd']);growth=max(2*2**30,foreign//2,max(0,foreign-self.foreign_start));each=max(envelope(case),int(self.peak.get(case['instance'],0)*1.25));own=descendants_rss(self.active,table);available=mem_available();st=os.statvfs(ROOT);disk=st.f_bavail*st.f_frsize;required=count*each+5*2**30+growth
        return available>=required and disk>=3*2**30,dict(available_bytes=available,own_active_rss=own,own_rss_used_as_admission_credit=False,required_bytes=required,worker_future_bound=each,foreign_growth_reserve=growth,free_disk_bytes=disk,admitted_concurrency=count)
    def terminal(self,job,reason):
        atomic(job['dir']/('r%02d.schedule.json'%job['rep']),dict(scheduling_freeze_sha=self.schedule_sha,amendment_sha=sha(HERE/'AMENDMENT.json'),parallel_limit=job['parallel_limit'],dispatch_ticket=job['ticket'],started_monotonic=job['started'],scope='Scheduling provenance, saved before original terminal-clock measurement. Not a worker input.'))
        super().terminal(job,reason)
    def wave(self,phase,case,arm):
        pointer=ROOT/'WAVE_POINTERS'/('%s_c%02d.json'%(phase,case['index']));attempt=1
        if arm=='B' and str(case['index']) in self.reference_registry['waves']:return super().wave(phase,case,arm)
        if pointer.exists():
            prev=read(pointer);folder=ROOT/prev['relative_dir'];meta=read(folder/'WAVE.json')
            if meta['status']=='valid_complete':return super().wave(phase,case,arm)
            if meta['status']=='ordinary_failure_complete':return audit_wave(folder,case,arm)
            if meta['status'] not in ('resource_interrupted','infrastructure_incomplete'):raise RuntimeError('Refuse to resume an unverified previous wave')
            attempt=prev['attempt']+1
        ceiling=24 if envelope(case)>=3*2**30 else 30
        while True:
            chosen=0
            for n in range(ceiling,0,-1):
                ready,ticket=self.ticket(case,n)
                if ready:chosen=n;break
            if chosen:break
            self.state('waiting_resources_reduced_parallel',phase=phase,index=case['index'],resources=ticket);self.event('resource_wait',phase=phase,index=case['index'],**ticket);time.sleep(30)
        check_freeze();scheduling_freeze();directory=ROOT/'waves'/('%s_c%02d_a%02d'%(phase,case['index'],attempt));directory.mkdir(parents=True,exist_ok=False)
        with (directory/'launch.lock').open('x') as f:f.write('one amended wave only\n');f.flush();os.fsync(f.fileno())
        atomic(pointer,dict(phase=phase,index=case['index'],arm=arm,attempt=attempt,relative_dir=directory.relative_to(ROOT).as_posix(),scheduling_freeze_sha=self.schedule_sha))
        meta=dict(phase=phase,index=case['index'],arm=arm,attempt=attempt,status='running',workers=30,parallel_limit=chosen,parallel_ceiling=ceiling,scheduling_freeze_sha=self.schedule_sha,freeze_sha=self.freeze,resources_at_dispatch=ticket)
        atomic(directory/'WAVE.json',meta);self.event('wave_start',**meta)
        pending=list(range(1,31));jobs=[];interrupted=False;last_sample=0;last_observation=0
        def launch(rep,tkt):
            log=(directory/('r%02d.log'%rep)).open('x');started=time.monotonic();p=subprocess.Popen([sys.executable,'-B',str(ROOT/'worker.py'),'--arm',arm,'--case',str(case['index']),'--rep',str(rep),'--started',str(started),'--dir',str(directory)],env=ENV,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            j=dict(rep=rep,p=p,log=log,dir=directory,started=started,parallel_limit=chosen,ticket=tkt);jobs.append(j);self.active[p.pid]=j
        try:
            for _ in range(chosen):launch(pending.pop(0),ticket)
            until=time.monotonic()+20
            while sum((directory/('r%02d.ready.json'%j['rep'])).exists() for j in jobs)<chosen:
                if time.monotonic()>until or any(j['p'].poll() is not None for j in jobs):raise RuntimeError('Reduced initial barrier failed')
                time.sleep(.01)
            atomic(directory/'START.json',dict(ready=chosen,release_monotonic=time.monotonic(),parallel_amendment=True))
            self.state('running_wave',phase=phase,index=case['index'],arm=arm,wave=directory.name,parallel_limit=chosen)
            while pending or self.active:
                now=time.monotonic()
                if now-last_sample>=1:
                    table=process_table();last_sample=now;self.peak[case['instance']]=max(self.peak.get(case['instance'],0),max((descendants_rss([pid],table) for pid in self.active),default=0))
                    st=os.statvfs(ROOT)
                    if mem_available()<5*2**30 or st.f_bavail*st.f_frsize<1*2**30:
                        interrupted=True;pending=[];self.event('resource_emergency_wave_invalid',wave=directory.name,available=mem_available())
                        for pid in list(self.active):
                            try:os.killpg(pid,signal.SIGKILL)
                            except ProcessLookupError:pass
                    if now-last_observation>=30:
                        last_observation=now;self.event('resource_observation',wave=directory.name,actual_active_workers=sum(pid in table for pid in self.active),own_rss=descendants_rss(self.active,table),available_bytes=mem_available(),loadavg=list(os.getloadavg()),cpu_count=os.cpu_count(),foreign_rss=sum(v['rss'] for v in table.values() if str(ROOT) not in v['cmd']))
                for pid,j in list(self.active.items()):
                    if j['p'].poll() is not None:
                        self.terminal(j,'resource_interruption' if interrupted else ('returned' if j['p'].returncode==0 else 'worker_error'));del self.active[pid]
                    elif now-j['started']>=600:
                        try:os.killpg(pid,signal.SIGKILL)
                        except ProcessLookupError:pass
                        self.terminal(j,'hard_600s_timeout');del self.active[pid]
                while pending and len(self.active)<chosen and not interrupted:
                    ready,tkt=self.ticket(case,len(self.active)+1)
                    if not ready:break
                    launch(pending.pop(0),tkt)
                if pending and not self.active:
                    self.state('waiting_refill_resources',phase=phase,index=case['index'],arm=arm,wave=directory.name,parallel_limit=chosen,resources=tkt)
                time.sleep(.1)
        except Exception:
            for pid,j in list(self.active.items()):
                if j['p'].poll() is None:
                    try:os.killpg(pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                self.terminal(j,'controller_infrastructure_interruption');del self.active[pid]
            atomic(directory/'TIMING_JOURNAL.json',{str(j['rep']):j['terminal']['elapsed_upper'] for j in jobs});meta.update(status='infrastructure_incomplete',terminal=len(jobs));atomic(directory/'WAVE.json',meta);raise
        atomic(directory/'TIMING_JOURNAL.json',{str(j['rep']):j['terminal']['elapsed_upper'] for j in jobs})
        if interrupted:
            rows=[audit_run(directory,r,case,arm) for r in range(1,31)]
            rows=[dict(x or {'rep':r,'cost':None,'elapsed_upper':None,'target_time':None},valid=False,reason='resource_invalid_entire_wave') for r,x in enumerate(rows,1)]
            status='resource_interrupted'
        else:
            rows=audit_wave(directory,case,arm);status='valid_complete' if all(x['valid'] for x in rows) else 'ordinary_failure_complete'
        meta.update(status=status,valid=sum(x['valid'] for x in rows),terminal=len(jobs),peak_worker_rss=self.peak[case['instance']]);atomic(directory/'AUDIT.json',rows);atomic(directory/'WAVE.json',meta);self.event('wave_terminal',**meta);self.state('wave_terminal',latest_wave=meta)
        if interrupted:return self.wave(phase,case,arm)
        return rows
    def run(self):
        assert read(ROOT/'summaries/R04_pilot.json')['performance_gate']
        assert read(ROOT/'audits/pilot_subprocess.json')['returncode']==0 and read(ROOT/'audits/R04_pilot_independent.json')['all_30_valid']
        self.event('continuation_after_valid_pilot_no_rerun',user_authorized_parallel_amendment=True)
        for case in self.reg['cases']:self.wave('reference',case,'B')
        for case in self.reg['cases']:self.wave('R04_full',case,'R04')
        result=self.comparison('R04','full')
        audit=subprocess.run([sys.executable,'-B',str(ROOT/'audit_campaign.py'),'--stage','R04','--which','full'],capture_output=True,text=True,env=ENV)
        atomic(ROOT/'audits/full_subprocess.json',dict(returncode=audit.returncode,stdout=audit.stdout,stderr=audit.stderr))
        comps=result['comparisons'];complete=result['all_valid'] and all(c['assessable'] for c in comps);better=sum(c.get('relative_mean_difference',0)<-1e-10 for c in comps);worse=sum(c.get('relative_mean_difference',0)>1e-10 for c in comps);gr={};ga={}
        for name,lo,hi in [('small',1,5),('medium',6,20),('large',21,999)]:
            sub=[c for c in comps if lo<=next(x for x in self.reg['cases'] if x['index']==c['index'])['m']<=hi]
            gr[name]=sum(c['relative_mean_difference'] for c in sub)/len(sub) if complete else None;ga[name]=sum(c['mean_difference'] for c in sub)/len(sub) if complete else None
        relative=sum(c['relative_mean_difference'] for c in comps)/40 if complete else None;absolute=sum(c['mean_difference'] for c in comps)/40 if complete else None
        achieved=bool(complete and audit.returncode==0 and better>worse and relative<0 and absolute<0 and all(v<=1e-10 for v in list(gr.values())+list(ga.values())))
        final=dict(performance_gates_passed=achieved,all_valid=result['all_valid'],overall_mean_relative=relative,overall_mean_cost_difference=absolute,improved_cases=better,degraded_cases=worse,size_groups_mean_relative=gr,size_groups_mean_cost_difference=ga,independent_audit_returncode=audit.returncode,all_runtime_and_SHA_checked=audit.returncode==0,scheduling_freeze_sha=self.schedule_sha,concurrency_limitation='Previously completed B14 cases used30; subsequent B and fresh R04 use the same memory-adaptive30/24 ceilings. No valid control repeated. Wall-clock and load confounding disclosed.')
        atomic(ROOT/'FINAL_GATE.json',final);atomic(HERE/'FINAL_GATE.json',final);self.state('performance_gates_passed_delivery_pending' if achieved else 'full_failed_requires_new_mechanism',final_gate=final);self.event('objective_check',**final)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--preflight',action='store_true');args=ap.parse_args()
    if args.preflight:preflight()
    else:
        c=None
        try:c=Continuation();c.run()
        except Exception as exc:
            traceback.print_exc()
            if c:c.state('controller_error_not_complete',error=repr(exc));c.event('controller_error',error=repr(exc))
            raise
