"""One detached scheduling successor; never overlaps the waiting controller."""
import os,subprocess,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from continuation_controller import ROOT,ENV,scheduling_freeze
from common import read,process_table,atomic
scheduling_freeze();a=read(HERE/'AMENDMENT.json');t=process_table();old=t.get(a['old_controller']['pid'])
assert not(old and old['start_ticks']==a['old_controller']['start_ticks'])
assert not any(str(ROOT/'worker.py') in v['cmd'] for v in t.values())
assert read(HERE/'PREFLIGHT.json')['passed']
with (HERE/'FORMAL_LAUNCH_ONCE').open('x') as f:f.write('User-authorized scheduling-only successor; original worker and algorithms unchanged\n');f.flush();os.fsync(f.fileno())
with (HERE/'controller.log').open('x') as log:
    p=subprocess.Popen([sys.executable,'-B','-u',str(HERE/'continuation_controller.py')],cwd=ROOT,env=ENV,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
atomic(HERE/'LAUNCH.json',dict(pid=p.pid,source=str(HERE/'continuation_controller.py'),scheduling_freeze_sha=scheduling_freeze(),old_controller_relaunched=False))
print('Detached scheduling successor PID',p.pid)
