"""Read-only final gate on frozen target functional/numeric reports."""
from common import ROOT,read,sha,atomic,check_freeze
def main():
    frozen=check_freeze();f=read(ROOT/'FUNCTIONAL_PREFLIGHT.json');n=read(ROOT/'SCORE_PREFLIGHT.json');c=read(ROOT/'COMPONENT_PREFLIGHT.json')
    assert all(x['passed'] and x['freeze_sha']==frozen for x in (f,n,c))
    assert len(f['rows'])==30 and sum(x['auxiliary_active'] for x in f['rows'])==10
    assert all(x['probability']>=.99 and x['actual_elapsed']<=600 for x in f['rows'])
    assert read(ROOT/'COMPONENT_PROCESS.json')['returncode']==0
    atomic(ROOT/'PREFLIGHT.json',{'passed':True,'freeze_sha':frozen,'functional_processes':30,'reports':{p:sha(ROOT/p) for p in ('FUNCTIONAL_PREFLIGHT.json','SCORE_PREFLIGHT.json','COMPONENT_PREFLIGHT.json')},'official_candidate_runs':0,'performance_improvement_proven':False})
    print('Target preflight passed; formal performance not proven',flush=True)
if __name__=='__main__':main()
