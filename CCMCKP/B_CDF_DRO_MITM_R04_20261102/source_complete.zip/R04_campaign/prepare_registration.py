"""One registration; fixed B reference is distinct from the previous candidate."""
import ast,copy,json,pickle,sys
from pathlib import Path
import numpy as np
from common import ROOT,read,sha,atomic,process_table
BASE=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/work/codex_B_DRO_goal_20261101')
PREVIOUS=BASE.parent/'codex_B_DRO_R03_20261101'
BASE_FREEZE='264d624f87b9b0892238993f31606caf6077e9745fdae769a4e113f9da450f38'
PREVIOUS_FREEZE='8f0b3b6d680e105693932272b124013edf31c3c5ba5d479c9fe859f4d59eaa2e'
SOLVER_SHA='94ada0a7b6e02066e5848ab2bc9d34c5430ef3ce52aa2f21afaced4d3070b938'

def source_invariants():
    for name,digest in read(ROOT/'sources/B/SOURCE_MANIFEST.json')['original_source_sha256'].items():assert sha(ROOT/'sources/B'/name)==digest
    for name in ('instance.py','native_evaluator.py','native_support.py','lss_vendor.py'):assert (ROOT/'sources/B'/name).read_bytes()==(ROOT/'sources/R04'/name).read_bytes()
    assert sha(ROOT/'sources/R04/solver.py')==SOLVER_SHA
    a=ast.parse((ROOT/'sources/B/solver.py').read_text());b=ast.parse((ROOT/'sources/R04/solver.py').read_text())
    ac=next(x for x in a.body if isinstance(x,ast.ClassDef));bc=next(x for x in b.body if isinstance(x,ast.ClassDef));bm={x.name:x for x in bc.body if isinstance(x,ast.FunctionDef)};count=0
    for x in ac.body:
        if not isinstance(x,ast.FunctionDef):continue
        y=bm[x.name]
        if x.name=='run':y.body=[z for z in y.body if not (isinstance(z,ast.If) and any(isinstance(q,ast.Call) and isinstance(q.func,ast.Attribute) and q.func.attr=='entropic_cost_proposal' for q in ast.walk(z)))]
        assert ast.dump(x)==ast.dump(y),x.name;count+=1
    assert count==17 and set(bm)=={x.name for x in ac.body if isinstance(x,ast.FunctionDef)}|{'entropic_cost_proposal'}
    assert {x.name:ast.dump(x) for x in a.body if isinstance(x,ast.FunctionDef)}=={x.name:ast.dump(x) for x in b.body if isinstance(x,ast.FunctionDef)}

def main():
    if (ROOT/'FREEZE.json').exists() or (ROOT/'PROTOCOL.json').exists():raise RuntimeError('Registration exists; no overwrite')
    previous=read(PREVIOUS/'STATE.json');table=process_table();row=table.get(previous['controller_pid'])
    if row and row['start_ticks']==previous['controller_start_ticks']:raise RuntimeError('Previous controller live')
    if any('worker.py' in v['cmd'] and str(PREVIOUS) in v['cmd'] for v in table.values()):raise RuntimeError('Previous workers live')
    assert previous['status']=='pilot_failed_requires_diagnosis'
    assert not read(PREVIOUS/'summaries/R03_pilot.json')['performance_gate']
    assert sha(PREVIOUS/'FREEZE.json')==PREVIOUS_FREEZE and sha(BASE/'FREEZE.json')==BASE_FREEZE
    for folder in (BASE,PREVIOUS):
        for name,digest in read(folder/'FREEZE.json')['files'].items():assert sha(folder/name)==digest
    source_invariants();assert sha(ROOT/'INPUTS.json')==sha(BASE/'INPUTS.json')
    proto=copy.deepcopy(read(BASE/'PROTOCOL.json'))
    registry={'campaign_root':str(BASE),'freeze_sha':BASE_FREEZE,'protocol_sha':sha(BASE/'PROTOCOL.json'),'old_controller':{'root':str(PREVIOUS),'pid':previous['controller_pid'],'start_ticks':previous['controller_start_ticks'],'terminal_status':previous['status']},'waves':{}}
    for idx in proto['pilot_cases']:
        ptr=read(BASE/'WAVE_POINTERS'/('reference_c%02d.json'%idx));directory=BASE/ptr['relative_dir'];meta=read(directory/'WAVE.json');rows=read(directory/'AUDIT.json')
        assert meta['status']=='valid_complete' and len(rows)==30 and all(r['valid'] for r in rows)
        registry['waves'][str(idx)]={'directory':str(directory),'peak_worker_rss':meta['peak_worker_rss'],'files':{p.name:sha(p) for p in sorted(directory.iterdir()) if p.is_file()}}
    atomic(ROOT/'REFERENCE_REGISTRY.json',registry)
    for name,m,K,L,values,costs in (('small_L30',3,3,30,[.2,.8,2.2],[10.,5.,1.]),('small_L500',3,3,500,[.2,.8,2.2],[10.,5.,1.]),('large_L30',12,5,30,[.1,.2,.3,.4,.5],[5.,4.,3.,2.,1.]),('negative_L500',3,3,500,[.2,.8,2.2],[10.,5.,1.])):
        folder=ROOT/'functional_fixtures'/name;folder.mkdir(parents=True,exist_ok=False)
        np.savetxt(folder/'cost.txt',np.tile(costs,m))
        with (folder/'node_to_factor.pkl').open('wb') as f:pickle.dump({g:list(range(g*K,(g+1)*K)) for g in range(m)},f)
        for j in range(m*K):
            samples=np.full(L,values[j%K])
            if name=='negative_L500' and j==2:samples[:]=.2;samples[-10:]=10.
            np.savetxt(folder/('%s_sample.txt'%j),samples)
    fixture_files={p.relative_to(ROOT).as_posix():sha(p) for p in sorted((ROOT/'functional_fixtures').rglob('*')) if p.is_file()}
    atomic(ROOT/'FUNCTIONAL_INPUTS.json',{'scope':'Synthetic functional only; expected costs never solver inputs','large':{'T':3.75,'expected':35.,'active':True},'small':{'T3.5_expected':15.,'T1_expected':30.,'active':False},'files':fixture_files})
    import scipy,gurobipy
    env={'python':sys.version.split()[0],'numpy':np.__version__,'scipy':scipy.__version__,'gurobi':list(gurobipy.gurobi.version()),'executable':str(Path(sys.executable).resolve())}
    assert env['numpy']=='1.24.4' and env['scipy']=='1.10.1' and env['gurobi']==[11,0,3]
    proto.update(schema='B_DRO_R04_entropic_cost_MILP_v1',arms=['B','R04'],environment=env,candidate='One optional original-robust-MGF risk-constrained cost MILP proposal phase, then unchanged original CDF-MITM. No R01/R02/R03 operator code.',pilot_order='Reuse four pinned valid fresh fixed B waves; run R04 40/25/18/14 each30. No repeated valid control; full candidate stage fresh1200 excluding pilot.',previous_candidate={'root':str(PREVIOUS),'freeze_sha':PREVIOUS_FREEZE,'summary_sha':sha(PREVIOUS/'summaries/R03_pilot.json'),'status':'failed pilot retained; never resumed'},functional_preflight='Source frozen first;30 simultaneous independent complete synthetic processes, all600s/15 reserve/M1m/gates.10 active m12K5 cases plus10 small exact/10 small MC with activation skipped. Original native call transcript RNG replay, actual Gurobi, additional rejection/dedup units. Never official performance observations.',proposal_parameters={'delta':.00025,'soft_seconds':20,'max_distinct_proposals':8,'SoftMemLimit_GB':.25,'constraint_margin':1e-10,'activation':'product of largest ceil(m/2) group cardinalities exceeds original half_width','THETA':'unchanged uploaded B grid','acceptance':'original CDF.975 then native_check, no force'},fixed_parameters='Original17 Solver methods AST unchanged except one run call; all module functions AST and4 dependencies unchanged. Native gate.99/screen.975/M1m/index/quick rejection/positive-only reuse/RNG advancement retained. Original problem and all9 original CDF-MITM stage slots retained. Auxiliary finite-support feasible subset is stricter, not an evaluator replacement.',numeric_score_scope='Original robust_logmgf/SciPy1.10.1 and histogram functions retained; finite-support exponential bound/cdf relation checked before formal runs. Floating point checks are not directed-rounding population certificates.',auxiliary_reference_quality_time='Predeclared offline first hit of pinned fixed-control mean cost per case, never worker input. Original raw-cost targets retained.',exploratory_candidates='R01 and R03 formal negative retained; R02 local memory draft not formally tested and deep local timings mostly slower. R04 selected after those observations and raw geometry; all selection limits disclosed. No selection-adjusted confirmation claim.')
    proto['literature']=[{'authors':'Nemirovski and Shapiro','year':2006,'title':'Convex Approximations of Chance Constrained Programs','journal':'SIAM Journal on Optimization17(4):969-996','doi':'10.1137/050622328','original':'https://optimization-online.org/wp-content/uploads/2004/12/1033.pdf','read':'Sections2/3/3.1/6.1, equations3.2/3.3/6.10-6.16 and Lemma6.1/Theorem6.1 full proofs','adaptation':'Independent finite generated marginals and computable MGF; binary domain and finite theta grid lose convex tractability/continuous-scale equivalence. More conservative optional proposal subset; no unknown-population coverage or original global optimum.'}]
    proto['statistics']['assumptions']='Sign-flip requires null sign symmetry/exchangeability; paired bootstrap treats30 seed pairs as independent draws. Shared load, adaptive candidate selection, and reuse of same mandated benchmarks/seeds limit inference. Descriptive non-simultaneous intervals; nonsignificance is not equivalence.'
    atomic(ROOT/'PROTOCOL.json',proto)
    files=list(ROOT.glob('*.py'))+list(ROOT.glob('*.sh'))+[p for p in (ROOT/'sources').rglob('*') if p.is_file() and '__pycache__' not in p.parts]+[p for p in (ROOT/'evidence').rglob('*') if p.is_file()]
    files += [ROOT/n for n in ('README_执行与边界.txt','方案依据_尚未登记.txt','PROTOCOL.json','INPUTS.json','REFERENCE_REGISTRY.json','FUNCTIONAL_INPUTS.json')]+[ROOT/n for n in fixture_files]
    atomic(ROOT/'FREEZE.json',{'schema':'R04_source_protocol_inputs_before_any_official_run','files':{p.relative_to(ROOT).as_posix():sha(p) for p in sorted(files)}})
    print(json.dumps({'registered':True,'freeze_sha':sha(ROOT/'FREEZE.json'),'files':len(files),'formal_R04_runs':0}),flush=True)
if __name__=='__main__':main()
