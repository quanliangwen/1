#!/bin/sh
set -eu
cd /home/junhao/quan/parallel_test_solver/CCMKCP/work/codex_B_DRO_R04_20261101
(set -C; : > ADVANCE_LAUNCH_ONCE)
nohup setsid env OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 OMP_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 python3 -B -u advance.py </dev/null >advance.log 2>&1 &
printf '%s\n' "$!" > advance_launcher_pid.txt
