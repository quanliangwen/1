"""Detached, singleton, immutable-wave campaign. Goal gates, not queue exhaustion."""
import argparse,fcntl,gzip,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path
from common import ROOT,PROJECT,read,sha,atomic,event,check_freeze,mem_available,process_table,descendants_rss,envelope
from audit_campaign import audit_wave

class Controller:
    def __init__(self):
        self.reg=read(ROOT/'PROTOCOL.json');self.active={};self.peak={};self.completed=0;self.status='initializing'
        self.reference_registry=read(ROOT/'REFERENCE_REGISTRY.json')
        legacy=self.reference_registry['old_controller'];previous_root=legacy['root'];table=process_table();row=table.get(legacy['pid'])
        if row and row['start_ticks']==legacy['start_ticks']:
            raise RuntimeError('Old controller is still live: no second 30-wave controller')
        if any('worker.py' in r['cmd'] and previous_root in r['cmd'] for r in table.values()):
            raise RuntimeError('Old campaign has live workers')
        for pid,r in table.items():
            if 'controller.py' in r['cmd']:
                try:cwd=(Path('/proc')/str(pid)/'cwd').resolve()
                except OSError:continue
                if str(cwd)==previous_root:
                    raise RuntimeError('Verified old controller cwd is still live')

        self.freeze=check_freeze();self.guard_floor=5*2**30;self.disk_floor=3*2**30
        self.lock=(ROOT/'controller.lock').open('a+')
        fcntl.flock(self.lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        self.lock.seek(0);self.lock.truncate();self.lock.write(str(os.getpid()));self.lock.flush();os.fsync(self.lock.fileno())
        self.ticks=process_table()[os.getpid()]['start_ticks']
        self.foreign_start=sum(r['rss'] for pid,r in process_table().items() if pid!=os.getpid())
        self.state('preflight_verified',latest_preflight=read(ROOT/'PREFLIGHT.json'))
    def state(self,status,**kwargs):
        self.status=status;d=dict(schema='B_DRO_goal_campaign_v1',status=status,controller_pid=os.getpid(),controller_start_ticks=self.ticks,freeze_sha=self.freeze,updated_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),registered_parallel=30,active=list(self.active),goal_achieved=False,**kwargs)
        atomic(ROOT/'STATE.json',d);atomic(ROOT/'CURRENT_POINTER.json',dict(root=str(ROOT),state='STATE.json',controller_pid=os.getpid(),controller_start_ticks=self.ticks,freeze_sha=self.freeze,status=status))
    def resource_ready(self,case):
        table=process_table();available=mem_available();foreign=sum(r['rss'] for pid,r in table.items() if str(ROOT) not in r['cmd'])
        # Include an allowance for ongoing foreign growth; worker bound already
        # covers later full beam expansion, not just instantaneous RSS.
        foreign_growth=max(2*2**30,foreign//2,max(0,foreign-self.foreign_start))
        each=max(envelope(case),int(self.peak.get(case['instance'],0)*1.25))
        need=30*each+self.guard_floor+foreign_growth
        stat=os.statvfs(ROOT);disk=stat.f_bavail*stat.f_frsize
        return available>=need and disk>=self.disk_floor,dict(available_bytes=available,required_bytes=need,worker_future_bound=each,foreign_growth_reserve=foreign_growth,free_disk_bytes=disk)
    def terminal(self,job,reason):
        job['p'].wait();job['log'].flush();os.fsync(job['log'].fileno());job['log'].close()
        out=job['dir']/('r%02d.json.gz'%job['rep']);side=out.with_name(out.name+'.worker.json')
        d={'rep':job['rep'],'pid':job['p'].pid,'returncode':job['p'].returncode,'reason':reason,'elapsed_before_terminal_save':time.monotonic()-job['started'],'record_sha':sha(out) if out.exists() else None,'worker_sha':sha(side) if side.exists() else None,'started_monotonic':job['started']}
        path=job['dir']/('r%02d.terminal.json'%job['rep']);atomic(path,d)
        # Final official audit bound is stored in the wave journal after all run
        # result/log/sidecar/terminal bytes have been fsynced.
        d['elapsed_upper']=time.monotonic()-job['started'];job['terminal']=d
        self.completed+=1
    def wave(self,phase,case,arm):
        pointer=ROOT/'WAVE_POINTERS'/('%s_c%02d.json'%(phase,case['index']))
        if arm=='B' and phase=='reference' and str(case['index']) in self.reference_registry['waves']:
            entry=self.reference_registry['waves'][str(case['index'])];directory=Path(entry['directory'])
            rows=audit_wave(directory,case,arm)
            if not all(r['valid'] for r in rows):raise RuntimeError('Pinned reference is not 30/30 valid')
            if pointer.exists():
                if Path(read(pointer)['relative_dir']).resolve()!=directory.resolve():raise RuntimeError('Reference pointer changed')
            else:
                atomic(pointer,dict(phase=phase,index=case['index'],arm=arm,attempt=0,relative_dir=str(directory),external_registered_reference=True))
            self.peak[case['instance']]=max(self.peak.get(case['instance'],0),entry['peak_worker_rss'])
            event('reuse_valid_fresh_fixed_control',phase=phase,index=case['index'],directory=str(directory))
            return rows
        if pointer.exists():
            old=read(pointer);directory=ROOT/old['relative_dir'];meta=read(directory/'WAVE.json')
            if meta['status']=='valid_complete':
                rows=audit_wave(directory,case,arm);assert all(r['valid'] for r in rows)
                event('reuse_valid_wave',phase=phase,index=case['index'],arm=arm);return rows
            if meta['status'] not in ('resource_interrupted','infrastructure_incomplete'):
                event('retain_nonretryable_wave',phase=phase,index=case['index'],arm=arm,status=meta['status'])
                return audit_wave(directory,case,arm)
            attempt=old['attempt']+1
        else:attempt=1
        while True:
            ready,resources=self.resource_ready(case)
            if ready:break
            self.state('waiting_resources_fixed_30',phase=phase,index=case['index'],resources=resources)
            event('resource_wait',phase=phase,index=case['index'],**resources);time.sleep(30)
        check_freeze();directory=ROOT/'waves'/('%s_c%02d_a%02d'%(phase,case['index'],attempt));directory.mkdir(parents=True,exist_ok=False)
        with (directory/'launch.lock').open('x') as f:f.write('one wave only\n');f.flush();os.fsync(f.fileno())
        atomic(pointer,dict(phase=phase,index=case['index'],arm=arm,attempt=attempt,relative_dir=directory.relative_to(ROOT).as_posix()))
        meta=dict(phase=phase,index=case['index'],arm=arm,attempt=attempt,status='running',workers=30,freeze_sha=self.freeze,resources_at_dispatch=resources)
        atomic(directory/'WAVE.json',meta);event('wave_start',**meta)
        env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
        jobs=[];interrupted=False
        for rep in range(1,31):
            log=(directory/('r%02d.log'%rep)).open('x');started=time.monotonic()
            cmd=[sys.executable,'-B',str(ROOT/'worker.py'),'--arm',arm,'--case',str(case['index']),'--rep',str(rep),'--started',str(started),'--dir',str(directory)]
            p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            j=dict(rep=rep,p=p,log=log,dir=directory,started=started);jobs.append(j);self.active[p.pid]=j
        barrier_end=time.monotonic()+20
        while sum((directory/('r%02d.ready.json'%r)).exists() for r in range(1,31))<30:
            if time.monotonic()>barrier_end or any(j['p'].poll() is not None for j in jobs):raise RuntimeError('30-process launch barrier failed')
            time.sleep(.01)
        assert len(self.active)==30 and all(j['p'].poll() is None for j in jobs)
        atomic(directory/'START.json',{'ready':30,'release_monotonic':time.monotonic()})
        self.state('running_wave',phase=phase,index=case['index'],arm=arm,wave=directory.name)
        last_sample=0
        while self.active:
            now=time.monotonic()
            if now-last_sample>=1:
                table=process_table();rss=descendants_rss(self.active,table);last_sample=now
                self.peak[case['instance']]=max(self.peak.get(case['instance'],0),max((descendants_rss([pid],table) for pid in self.active),default=0))
                if mem_available()<self.guard_floor or os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize<1*2**30:
                    interrupted=True
                    event('resource_emergency_wave_invalid',wave=directory.name,available=mem_available(),own_rss=rss)
                    for pid in list(self.active):
                        try:os.killpg(pid,signal.SIGKILL)
                        except ProcessLookupError:pass
            for pid,j in list(self.active.items()):
                if j['p'].poll() is not None:
                    reason='resource_interruption' if interrupted else ('returned' if j['p'].returncode==0 else 'worker_error')
                    self.terminal(j,reason);del self.active[pid]
                elif now-j['started']>=600:
                    try:os.killpg(pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                    self.terminal(j,'hard_600s_timeout');del self.active[pid]
            time.sleep(.1)
        # Upper times are finalized only after fsync of each worker's terminal.
        # This journal is retained independently of records being summarized.
        atomic(directory/'TIMING_JOURNAL.json',{str(j['rep']):j['terminal']['elapsed_upper'] for j in jobs})
        rows=audit_wave(directory,case,arm)
        if interrupted:
            for r in rows:r.update(valid=False,reason='resource_invalid_entire_wave')
            meta['status']='resource_interrupted'
        elif all(r['valid'] for r in rows):meta['status']='valid_complete'
        else:meta['status']='ordinary_failure_complete'
        meta.update(valid=sum(r['valid'] for r in rows),peak_worker_rss=self.peak[case['instance']],terminal=30)
        atomic(directory/'WAVE.json',meta);atomic(directory/'AUDIT.json',rows)
        event('wave_terminal',**meta);self.state('wave_terminal',latest_wave=meta)
        if interrupted:
            # Do not dispatch immediately from current RSS. Recheck entire peak
            # bound plus foreign growth; the invalid attempt is never overwritten.
            return self.wave(phase,case,arm)
        return rows
    def comparison(self,stage,which):
        from statistics_campaign import summary,paired,holm
        indices=self.reg['pilot_cases'] if which=='pilot' else list(range(1,41));ss=[];cc=[];allrows={};reference_quality_times=[]
        for idx in indices:
            case=next(c for c in self.reg['cases'] if c['index']==idx);pair={}
            for arm in self.reg['arms']:
                phase='reference' if arm=='B' else stage+'_'+which
                ptr=read(ROOT/'WAVE_POINTERS'/('%s_c%02d.json'%(phase,idx)));rows=audit_wave(ROOT/ptr['relative_dir'],case,arm)
                pair[arm]=rows;ss.append(dict(arm=arm,index=idx,instance=case['instance'],m=case['m'],**summary(rows)))
            comp=paired(pair['B'],pair['R04'],20261101+idx);comp['index']=idx;cc.append(comp);allrows[str(idx)]=pair
            if all(len(v)==30 and all(r['valid'] for r in v) for v in pair.values()):
                threshold=sum(r['cost'] for r in pair['B'])/30
                by_arm={}
                for arm,records in pair.items():
                    times=[]
                    for r in records:
                        hits=[e['elapsed'] for e in r['incumbent_path'] if e['cost']<=threshold+1e-8]
                        times.append(min(hits) if hits else None)
                    observed=[t for t in times if t is not None]
                    by_arm[arm]={'hits':len(observed),'conditional_seconds':sum(observed)/len(observed) if observed else None,'restricted_seconds':sum(t if t is not None else 600. for t in times)/30}
                reference_quality_times.append({'index':idx,'fixed_reference_mean_cost_target':threshold,'arms':by_arm,'scope':'Predeclared R04 auxiliary time metric; no threshold is input to a search worker, original raw-cost target retained.'})
        holm(cc);valid=all(s['valid']==30 for s in ss);ratios=[c.get('relative_mean_ratio') for c in cc]
        gate=valid and all(r<=1+1e-10 for r in ratios) and sum(ratios)<len(ratios)-1e-10 if which=='pilot' else False
        result=dict(stage=stage,which=which,all_valid=valid,summaries=ss,comparisons=cc,reference_quality_times=reference_quality_times,performance_gate=gate,coverage_cases=len(indices),total_cases=40,negative_cases=[c['index'] for c in cc if c.get('relative_mean_difference',0)>1e-10],selection_limitations='Pilot and full use the same benchmark suite and mandated seed set. Full runs are fresh executions, not unseen data or independent algorithm selection. Do not interpret bootstrap intervals as selection-adjusted confirmation.')
        atomic(ROOT/'summaries'/('%s_%s.json'%(stage,which)),result);return result
    def run(self):
        assert read(ROOT/'PREFLIGHT.json')['passed'] is True
        assert read(ROOT/'PREFLIGHT.json')['freeze_sha']==self.freeze
        for k,idx in enumerate(self.reg['pilot_cases']):
            case=next(c for c in self.reg['cases'] if c['index']==idx)
            for arm in ('B','R04') if k%2==0 else ('R04','B'):
                self.wave('reference' if arm=='B' else 'R04_pilot',case,arm)
        pilot=self.comparison('R04','pilot')
        if not pilot['performance_gate']:
            self.state('pilot_failed_requires_diagnosis',pilot_summary='summaries/R04_pilot.json');event('pilot_failed_no_full_expansion');return
        # Fresh audit subprocess has no controller state and does no new native MC.
        audit=subprocess.run([sys.executable,'-B',str(ROOT/'audit_campaign.py'),'--stage','R04','--which','pilot'],capture_output=True,text=True)
        atomic(ROOT/'audits'/'pilot_subprocess.json',dict(returncode=audit.returncode,stdout=audit.stdout,stderr=audit.stderr))
        if audit.returncode or not read(ROOT/'audits/R04_pilot_independent.json')['all_30_valid']:
            self.state('pilot_integrity_audit_failed_no_expansion');return
        self.state('pilot_passed_independent_audit_passed');event('full_stage_authorized_by_predeclared_gates')
        # Complete fresh fixed control without repeating its 4 valid pilot waves.
        for case in self.reg['cases']:
            self.wave('reference',case,'B')
        # Explicitly new 1200 candidate runs; no pilot records mixed in.
        for case in self.reg['cases']:
            self.wave('R04_full',case,'R04')
        result=self.comparison('R04','full')
        audit=subprocess.run([sys.executable,'-B',str(ROOT/'audit_campaign.py'),'--stage','R04','--which','full'],capture_output=True,text=True)
        atomic(ROOT/'audits/full_subprocess.json',dict(returncode=audit.returncode,stdout=audit.stdout,stderr=audit.stderr))
        comps=result['comparisons'];ss=result['summaries'];better=sum(c.get('relative_mean_difference',0)<-1e-10 for c in comps);worse=sum(c.get('relative_mean_difference',0)>1e-10 for c in comps)
        groups={};groups_absolute={}
        for name,lo,hi in (('small',1,5),('medium',6,20),('large',21,999)):
            subset=[c for c in comps if lo<=next(x for x in self.reg['cases'] if x['index']==c['index'])['m']<=hi]
            groups[name]=sum(c.get('relative_mean_difference',float('inf')) for c in subset)/len(subset)
            groups_absolute[name]=sum(c.get('mean_difference',float('inf')) for c in subset)/len(subset)
        mean_relative=sum(c.get('relative_mean_difference',float('inf')) for c in comps)/40
        mean_absolute=sum(c.get('mean_difference',float('inf')) for c in comps)/40
        achieved=result['all_valid'] and audit.returncode==0 and better>worse and mean_relative<0 and mean_absolute<0 and all(v<=1e-10 for v in list(groups.values())+list(groups_absolute.values()))
        final=dict(performance_gates_passed=achieved,all_valid=result['all_valid'],overall_mean_relative=mean_relative,overall_mean_cost_difference=mean_absolute,improved_cases=better,degraded_cases=worse,size_groups_mean_relative=groups,size_groups_mean_cost_difference=groups_absolute,independent_audit_returncode=audit.returncode,all_runtime_and_SHA_checked=(audit.returncode==0))
        atomic(ROOT/'FINAL_GATE.json',final);self.state('performance_gates_passed_delivery_pending' if achieved else 'full_failed_requires_new_mechanism',final_gate=final)
        event('objective_check',**final)

if __name__=='__main__':
    c=None
    try:c=Controller();c.run()
    except Exception as exc:
        traceback.print_exc()
        if c:
            for pid,j in list(c.active.items()):
                if j['p'].poll() is None:
                    try:os.killpg(pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                try:c.terminal(j,'controller_infrastructure_interruption')
                except Exception:traceback.print_exc()
            c.state('controller_error_not_complete',error=repr(exc));event('controller_error',error=repr(exc))
        raise
