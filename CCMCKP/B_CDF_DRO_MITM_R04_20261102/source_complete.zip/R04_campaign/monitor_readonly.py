"""Read-only PID/start-tick/cwd/pointer/log snapshot. No dispatch or resumption."""
import json,time
from pathlib import Path
from common import ROOT,read,process_table,mem_available

table=process_table();result={'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'root':str(ROOT),'available_GiB':round(mem_available()/2**30,2)}
for name,key in [('ADVANCE_STATE.json','advance'),('STATE.json','controller')]:
    path=ROOT/name
    if not path.exists():continue
    state=read(path);pid=state.get('controller_pid',state.get('pid'));row=table.get(pid)
    ticks=state.get('controller_start_ticks',state.get('start_ticks'))
    cwd=None
    if row:
        try:cwd=str((Path('/proc')/str(pid)/'cwd').resolve())
        except OSError:pass
    result[key]={'state':state,'live_verified':bool(row and row['start_ticks']==ticks and cwd==str(ROOT)),'actual_cwd':cwd,'actual_cmd':row['cmd'] if row else None}
workers=[{'pid':pid,'start_ticks':r['start_ticks'],'rss_MiB':round(r['rss']/2**20,1)} for pid,r in table.items() if 'worker.py' in r['cmd'] and str(ROOT) in r['cmd']]
result['actual_workers']=workers
result['actual_functional_workers']=sum('functional_preflight.py --child' in r['cmd'] and str(ROOT) in r['cmd'] for r in table.values())
if (ROOT/'CURRENT_POINTER.json').exists():result['pointer']=read(ROOT/'CURRENT_POINTER.json')
for name in ('advance.log','controller.py.log','score_preflight.py.log','functional_preflight.py.log','EVENTS.jsonl'):
    p=ROOT/name
    if p.exists():result[name]=p.read_text(errors='replace').splitlines()[-3:]
print(json.dumps(result,ensure_ascii=False))
