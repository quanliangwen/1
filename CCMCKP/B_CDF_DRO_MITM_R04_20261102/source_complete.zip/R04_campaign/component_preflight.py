"""Target original negative RNG replay and isolated MILP rejection injection."""
import json,signal,sys,time
from common import ROOT,read,atomic,check_freeze
from preflight_helpers import state_digest,original_native_check,previous_live

def main():
    signal.alarm(600);frozen=check_freeze();assert not previous_live()
    if (ROOT/'COMPONENT_PREFLIGHT.json').exists():raise RuntimeError('Retain existing component report')
    sys.path.insert(0,str(ROOT/'sources/R04'))
    import numpy as np
    from instance import load_instance
    from solver import Solver
    folder=ROOT/'COMPONENT_TESTS';folder.mkdir(exist_ok=False)
    inst=load_instance(ROOT/'functional_fixtures/negative_L500');seed=832273;started=time.monotonic()
    s=Solver(inst,3.5,seed,600,folder/'negative.json.gz',started,'B_CDF_DRO_MITM');s.save=lambda *_:None
    b=Solver(inst,3.5,seed,600,folder/'replay_unused.json.gz',started,'B_CDF_DRO_MITM');b.save=lambda *_:None
    baseline=original_native_check(np);seq=[((0,3,6),True),((0,5,6),False),((2,5,6),False),((1,5,6),False),((2,5,6),False)];probabilities=[]
    outer=state_digest(np.random.get_state())
    for ids,force in seq:
        p=s.native_check(ids,'synthetic_oracle_semantics_only',force);q=baseline(b,ids,'synthetic_oracle_semantics_only',force)
        assert p==q and state_digest(s.native_rng.get_state())==state_digest(b.native_rng.get_state()) and state_digest(np.random.get_state())==outer
        probabilities.append(p)
    assert 0<probabilities[2]<.99 and 0<probabilities[4]<.99 and s.native_calls==5 and s.best['cost']==16.
    # This injection rejects every proposal. It never supplies a success,
    # replaces an acceptance decision, or runs in a formal worker.
    inst=load_instance(ROOT/'functional_fixtures/large_L30');s=Solver(inst,3.75,832274,600,folder/'injection_initial.json.gz',time.monotonic(),'B_CDF_DRO_MITM')
    for _,_,selection in s.propose(s.mu+3*s.sd,float(s.cost.max()*inst.m),theta=0.,pool=8,seconds=3):
        s.native_check(selection,'injection_unit_own_original_initialization',True)
        if s.best is not None:break
    assert s.best and s.best['cost']==60.
    calls=[];s.save=lambda *_:None
    def reject_only(selection,source,force=False):calls.append(tuple(selection));return None
    s.native_check=reject_only;s.entropic_cost_proposal(.00025)
    record=s.match_history[-1]
    assert len(calls)==len(set(calls))==8 and s.best['cost']==60. and record['stop_reason']=='eight_distinct_proposal_limit'
    assert len(record['attempts'])==8 and all(a['finite_support_bound_valid'] for a in record['attempts'])
    # Deadline branch performs no extra model/evaluator work.
    models=s.models;s.deadline=time.monotonic();s.entropic_cost_proposal(.00025);assert s.models==models and len(calls)==8
    result={'passed':True,'freeze_sha':frozen,'negative_original_probabilities':probabilities,'negative_repeated_calls':2,'native_RNG_matches_original_after_every_call':True,'MILP_rejection_injection_unit_only':{'distinct_proposals':8,'original_initializer_cost':60.,'best_stays':60.,'all_proposals_rejected':True,'never_a_performance_or_feasibility_result':True},'deadline_no_work':True,'scope':'Original native positive/negative repeat behavior and RNG replay. Separate synthetic always-reject injection validates local enumeration, not an evaluator or a success claim. Actual30 full runs use the real evaluator.'}
    atomic(ROOT/'COMPONENT_PREFLIGHT.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':main()
