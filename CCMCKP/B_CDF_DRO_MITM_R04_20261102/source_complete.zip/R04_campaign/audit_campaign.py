"""Independent read-only checks; never reruns a native oracle or selects reruns."""
import gzip,json,math,pickle
from pathlib import Path
from common import ROOT,PROJECT,read,sha,check_freeze,atomic

_REFERENCE_VERIFIED=set()
def reference_context(folder,case,arm):
    folder=Path(folder).resolve()
    if ROOT==folder or ROOT in folder.parents:
        return ROOT,sha(ROOT/'FREEZE.json'),sha(ROOT/'PROTOCOL.json')
    registry=read(ROOT/'REFERENCE_REGISTRY.json')
    if arm!='B' or str(case['index']) not in registry['waves']:
        raise RuntimeError('Unregistered external comparison result')
    entry=registry['waves'][str(case['index'])]
    if folder!=Path(entry['directory']).resolve():raise RuntimeError('Reference path changed')
    key=str(folder)
    if key not in _REFERENCE_VERIFIED:
        if sha(Path(registry['campaign_root'])/'FREEZE.json')!=registry['freeze_sha']:
            raise RuntimeError('Reference campaign freeze changed')
        for filename,digest in entry['files'].items():
            if sha(folder/filename)!=digest:raise RuntimeError('Reference record changed: '+filename)
        _REFERENCE_VERIFIED.add(key)
    return Path(registry['campaign_root']),registry['freeze_sha'],registry['protocol_sha']

def audit_run(folder,rep,case,arm):
    context_root,expected_freeze,expected_protocol=reference_context(folder,case,arm)
    p=Path(folder);terminal=p/('r%02d.terminal.json'%rep);answer={'rep':rep,'valid':False,'reason':'not_terminal','elapsed_upper':None,'cost':None,'target_time':None}
    if not terminal.exists():return None
    t=read(terminal)
    journal=read(p/'TIMING_JOURNAL.json')
    answer['elapsed_upper']=journal[str(rep)]
    if t['reason']!='returned':answer['reason']=t['reason'];return answer
    if answer['elapsed_upper']>600:answer['reason']='actual_runtime_over_600';return answer
    out=p/('r%02d.json.gz'%rep);side=out.with_name(out.name+'.worker.json')
    if not out.exists() or not side.exists():answer['reason']='missing_result_or_sidecar';return answer
    if sha(out)!=t['record_sha'] or sha(side)!=t['worker_sha']:raise RuntimeError('terminal result SHA mismatch')
    d=json.loads(gzip.decompress(out.read_bytes()));w=read(side)
    assert d['seed']==w['seed']==832272+rep and d['capacity']==case['tmax']
    assert d['instance']==case['instance'] and w['arm']==arm and w['index']==case['index']
    assert w['freeze_sha']==expected_freeze and w['protocol_sha']==expected_protocol
    assert w['input_registry_sha']==sha(ROOT/'INPUTS.json')
    if context_root==ROOT:assert w['environment']==read(ROOT/'PROTOCOL.json')['environment']
    assert d['external_solution_inputs'] is False and d['prior_count']==0 and w['no_cross_seed_weights'] is True
    cfg=d['config'];assert cfg['native_gate']==.99 and cfg['screen_gate']==.975 and cfg['native_draws']==1000000 and cfg['screen_draws']==60000 and cfg['time_budget']==600 and cfg['work_reserve']==15
    assert cfg['radii']==[.00025,0.,.0005] and cfg['bins']==4096
    if not d['selected']:answer['reason']='no_native_feasible_initial_solution';return answer
    selected=d['selected'];assert selected==w['selected']
    # The checks here use raw data, no native re-evaluation / resampling.
    import numpy as np
    data=PROJECT/'benchmark'/case['instance'];cost=np.asarray(np.loadtxt(data/'cost.txt')).reshape(-1)
    with (data/'node_to_factor.pkl').open('rb') as f:groups=pickle.load(f)
    if isinstance(groups,dict):groups=[groups[k] for k in sorted(groups,key=lambda v:int(v))]
    ids=selected['selection'];assert len(ids)==len(groups) and len(set(ids))==len(ids)
    assert all(len(set(g)&set(ids))==1 for g in groups)
    assert abs(float(cost[ids].sum())-selected['cost'])<1e-8
    if selected['probability']<.99:answer['reason']='native_probability_below_0.99';return answer
    assert 0<=selected['found_seconds']<=600
    positive=[v for v in d['native_observations'] if v['probability']>=.99]
    assert positive and any(v['selection']==ids and v['cost']==selected['cost'] and v['probability']==selected['probability'] for v in positive)
    assert selected['cost']==min(v['cost'] for v in positive)
    first=min(v['elapsed'] for v in d['events'] if v.get('event')=='native_incumbent' and abs(v['cost']-selected['cost'])<=1e-8)
    assert abs(first-selected['found_seconds'])<1e-8
    hits=[v['elapsed'] for v in d['events'] if v.get('event')=='native_incumbent' and v['cost']<=case['target_cost']+1e-8]
    for raw in w['project_paths_opened']:
        path=Path(raw)
        assert ('benchmark' in path.parts and case['instance'] in path.parts) or (context_root/'sources'/arm in path.parents) or path in {context_root/'PROTOCOL.json',context_root/'INPUTS.json'} or p==path or p in path.parents
    answer.update(valid=True,reason='valid',cost=selected['cost'],probability=selected['probability'],found_seconds=selected['found_seconds'],target_time=min(hits) if hits else None,native_calls=d['native_probability_calls'],native_seconds=d['native_seconds'],stages=len(d['match_history']),incumbent_path=[{'cost':v['cost'],'elapsed':v['elapsed']} for v in d['events'] if v.get('event')=='native_incumbent'])
    return answer

def audit_wave(folder,case,arm):
    rows=[audit_run(folder,r,case,arm) for r in range(1,31)]
    if any(r is None for r in rows):raise RuntimeError('wave not fully terminal')
    return rows

def verify_stage(stage,which):
    reg=read(ROOT/'PROTOCOL.json');check_freeze();rows={}
    for idx in reg['pilot_cases'] if which=='pilot' else list(range(1,41)):
        case=next(c for c in reg['cases'] if c['index']==idx)
        for arm in reg['arms']:
            phase='reference' if arm=='B' else stage+'_'+which
            pointer=read(ROOT/'WAVE_POINTERS'/('%s_c%02d.json'%(phase,idx)))
            rows['%s_%s'%(arm,idx)]=audit_wave(ROOT/pointer['relative_dir'],case,arm)
    result={'stage':stage,'which':which,'all_terminal':True,'all_30_valid':all(all(r['valid'] for r in v) for v in rows.values()),'rows':rows,'freeze_sha':sha(ROOT/'FREEZE.json')}
    atomic(ROOT/'audits'/('%s_%s_independent.json'%(stage,which)),result)
    return result

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--stage',default='R04');ap.add_argument('--which',choices=('pilot','full'),required=True);a=ap.parse_args()
    result=verify_stage(a.stage,a.which);print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
