"""One detached successor, waiting without resuming any previous campaign."""
import fcntl,json,os,stat,subprocess,sys,time,traceback
from pathlib import Path
from common import ROOT,read,sha,atomic,process_table
OLD=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/work/codex_B_DRO_R03_20261101')
lock=(ROOT/'advance.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
pid=os.getpid();ticks=process_table()[pid]['start_ticks']
def state(status,**kwargs):
    atomic(ROOT/'ADVANCE_STATE.json',{'status':status,'pid':pid,'start_ticks':ticks,'updated_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'goal_achieved':False,**kwargs})
def run(script):
    path=ROOT/(script+'.log')
    with path.open('x') as log:
        p=subprocess.Popen([sys.executable,'-B','-u',str(ROOT/script)],stdout=log,stderr=subprocess.STDOUT,cwd=ROOT,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1'),start_new_session=True)
        state('executing_'+script,child_pid=p.pid)
        result=p.wait();log.flush();os.fsync(log.fileno())
    if result:raise RuntimeError(script+' failed; no implicit restart')
try:
    while True:
        old=read(OLD/'STATE.json');table=process_table();row=table.get(old['controller_pid'])
        live=bool(row and row['start_ticks']==old['controller_start_ticks']) or any('worker.py' in r['cmd'] and str(OLD) in r['cmd'] for r in table.values())
        if not live:break
        state('waiting_previous_registered_stage',previous_status=old['status'],previous_pid=old['controller_pid'])
        time.sleep(30)
    if old['status']!='pilot_failed_requires_diagnosis':
        state('halted_previous_stage_not_normal_failed_pilot',previous_status=old['status']);sys.exit(0)
    run('prepare_registration.py')
    freeze=read(ROOT/'FREEZE.json')
    for name in list(freeze['files'])+['FREEZE.json']:
        p=ROOT/name;p.chmod(p.stat().st_mode&~(stat.S_IWUSR|stat.S_IWGRP|stat.S_IWOTH))
    run('score_preflight.py');run('functional_preflight.py');run('finish_preflight.py')
    assert read(ROOT/'PREFLIGHT.json')['passed']
    with (ROOT/'FORMAL_LAUNCH_ONCE').open('x') as f:f.write('Fresh R04; no repeated valid B waves\n')
    run('controller.py')
    state('experiment_terminal_review_required',controller_state=read(ROOT/'STATE.json'))
except Exception as exc:
    traceback.print_exc();state('halted_error_no_implicit_restart',error=repr(exc));raise
