"""Original target MGF/CDF algebra and raw-geometry validation; no optimization."""
import itertools,json,sys
from pathlib import Path
import numpy as np
from common import ROOT,PROJECT,read,sha,atomic,check_freeze
from preflight_helpers import previous_live

def main():
    frozen=check_freeze();assert not previous_live()
    if (ROOT/'SCORE_PREFLIGHT.json').exists():raise RuntimeError('Retain existing preflight; no implicit rerun')
    sys.path.insert(0,str(ROOT/'sources/R04'))
    from solver import robust_logmgf,worst_cdf_hist,THETA
    from instance import load_instance
    checks=0
    for delta in (0.,.00025,.0005):
        arrays=[np.array([0.,.2,.8]),np.array([.1,.4,1.2]),np.array([0.,.3,.7])];supports=[]
        for a in arrays:
            ix=np.ceil(a*4096-1e-12).astype(int);pos,count=np.unique(ix,return_counts=True);mass=count.astype(float)/len(a);left=delta
            for k in range(len(mass)):
                moved=min(left,mass[k]);mass[k]-=moved;left-=moved
                if left<=1e-15:break
            mass[-1]+=delta-left;supports.append((pos,mass));expected=np.zeros(4096)
            for p,v in zip(pos,mass):
                if p<4096:expected[p]+=v
            assert np.allclose(worst_cdf_hist(a,1.,4096,delta),expected,atol=1e-15,rtol=0);checks+=1
        failure=0.
        for ids in itertools.product(*[range(len(x[0])) for x in supports]):
            if sum(supports[j][0][k] for j,k in enumerate(ids))>=4096:failure+=float(np.prod([supports[j][1][k] for j,k in enumerate(ids)]))
        residual=sum(robust_logmgf(a,1.,4096,delta) for a in arrays)-THETA
        for bound in residual:assert failure<=np.exp(min(0.,bound))+1e-12;checks+=1
    geometry=read(ROOT/'evidence/entropic_cost_raw_evidence.json');rows=[]
    for old in geometry['rows']:
        case=next(c for c in read(ROOT/'PROTOCOL.json')['cases'] if c['index']==old['index']);folder=PROJECT/'benchmark'/case['instance']
        for name,digest in read(ROOT/'INPUTS.json').items():
            if Path(name).parent==folder:assert sha(name)==digest
        inst=load_instance(folder);mc=len(inst.samples[0])**inst.m>=10**7
        w=np.asarray([robust_logmgf(a[:-1] if mc else a,case['tmax'],4096,.00025) for a in inst.samples])
        center=tuple(min(g,key=lambda j:inst.samples[j].mean()+3*inst.samples[j].std(ddof=1)) for g in inst.groups)
        residual=w[list(center)].sum(axis=0)-THETA;error=abs(min(0.,float(residual.min()))-np.log(old['initial_center_best_exponential_failure_upper_bound']))
        assert error<1e-9
        minimum=sum(w[g].min(axis=0) for g in inst.groups)-THETA
        feasible=THETA[minimum<=np.log(.01)].tolist();assert feasible==old['grid_theta_with_at_least_one_risk_feasible_combination']
        C=int(np.prod(sorted((len(g) for g in inst.groups),reverse=True)[:(inst.m+1)//2],dtype=object));W=max(1024,min(4096,(40960//inst.m)//512*512))
        rows.append({'index':case['index'],'log_bound_difference_from_local_numpy':float(error),'risk_feasible_theta':feasible,'activation':C>W,'half_width':W,'largest_half_states':C})
    atomic(ROOT/'SCORE_PREFLIGHT.json',{'passed':True,'freeze_sha':frozen,'finite_support_checks':checks,'raw_rows':rows,'scope':'Original SciPy target functions, exact tiny finite-support sums including boundary/overflow, and four predefined raw geometry checks. No native evaluator/optimization/warm-start vectors, no population coverage or performance proof.'})
    print(json.dumps({'numeric_passed':True,'checks':checks,'raw_cases':4,'freeze_sha':frozen}),flush=True)
if __name__=='__main__':main()
