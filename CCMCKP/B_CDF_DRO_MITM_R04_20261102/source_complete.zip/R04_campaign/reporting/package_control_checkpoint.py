"""Seal completed fixed-control observations; never launches a solver."""
import hashlib,json,sys,zipfile
from pathlib import Path,PurePosixPath

root=Path(__file__).resolve().parents[1];reference=root.parent/'CCMCKP_DRO_goal_20261101'
snapshot=Path(sys.argv[1]);d=json.loads(snapshot.read_text(encoding='utf8'));tag=d['snapshot_utc']
assert d['which']=='full'
summaries=[s for s in d['summaries'] if s['arm']=='B' and s['wave_status']=='valid_complete']
assert len(summaries)==14 and all(s['valid']==30 for s in summaries)
assert not any(r['arm']=='R04' for r in d['terminal_records'])
registry=json.loads((root/'REFERENCE_REGISTRY.json').read_text(encoding='utf8'));files={}
sha=lambda b:hashlib.sha256(b).hexdigest()
for s in summaries:
    idx=s['index'];name='reference_c%02d_a01'%idx
    folder=(reference if str(idx) in registry['waves'] else root)/'evidence/waves'/name
    for p in sorted(folder.rglob('*')):
        if p.is_file():files['waves/'+name+'/'+p.relative_to(folder).as_posix()]=p
for name in ['PROTOCOL.json','FREEZE.json','REFERENCE_REGISTRY.json','INPUTS.json']:
    files['registration/'+name]=root/name
for name in [snapshot.name,'R04_全量统计_'+tag+'.xlsx','independent_download_audit_'+tag+'.json','raw_archive_independent_audit_20261101T0655Z.json','source_archive_independent_audit_20261101T0650Z.json','资源守卫等待_20261101_首次核验.json','resource_wait_goalturn2_20261101T0702Z.json']:
    files['reports/'+name]=root/'report_snapshots'/name
files['offline_reporting/package_control_checkpoint.py']=Path(__file__).resolve()
manifest={name:{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for name,p in files.items()}
metadata={'scope':'Interim fixed-control checkpoint:14/40 cases,420 valid B observations. No candidate full observations. R04 pilot is separate and excluded from full. Goal not complete.','cases':[s['index'] for s in summaries],'official_comparison_observations':420,'candidate_full_observations':0,'freeze_sha':d['freeze_sha'],'files':manifest,'separate_raw_input_archive_sha256':'e5ebd0a26ff4a3d6d8e66cd2c3e0a342d8268dcf831315bb9fe657d9b4fb88b7','separate_source_archive_sha256':'3a49ef410ece32d0233a0f8985d0afe13135edf80997409bc8379ce71b0969c4','operation':'Only local compression and hashing of completed observations; no evaluation, optimization, source mutation, parameter change or worker feedback.'}
out=root/'deliverable_snapshots'/('固定对照14例检查点_'+tag+'.zip')
assert not out.exists()
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,p in files.items():z.write(p,name)
    z.writestr('CHECKPOINT_MANIFEST.json',json.dumps(metadata,ensure_ascii=False,indent=2))
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None and len(z.namelist())==len(files)+1
    for name,m in manifest.items():assert sha(z.read(name))==m['sha256']
result={'path':str(out),'sha256':sha(out.read_bytes()),'bytes':out.stat().st_size,'members':len(files)+1,'records':420,'CRC_and_all_member_SHA256':'passed','goal_complete':False}
out.with_suffix('.zip.sha.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(result,ensure_ascii=False))
