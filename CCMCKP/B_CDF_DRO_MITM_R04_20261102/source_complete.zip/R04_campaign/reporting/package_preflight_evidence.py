"""Archive actual functional evidence; no new tests or solver evaluations."""
import hashlib,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
files={p.relative_to(root/'evidence').as_posix():p for p in (root/'evidence/FUNCTIONAL_WAVE').rglob('*') if p.is_file()}
files.update({p.relative_to(root).as_posix():p for p in (root/'target_preflight').glob('*') if p.is_file()})
for name in ('FREEZE.json','PROTOCOL.json','FUNCTIONAL_INPUTS.json'):
    files[name]=root/name
f=json.loads((root/'target_preflight/FUNCTIONAL_PREFLIGHT.json').read_text())
for row in f['rows']:
    p=files['FUNCTIONAL_WAVE/r%02d.json.gz'%row['rep']]
    assert hashlib.sha256(p.read_bytes()).hexdigest()==row['record_sha']
out=root/'deliverable_snapshots'/('R04_预检证据_'+f['freeze_sha'][:16]+'.zip')
manifest={'scope':'Actual synthetic full-solver and numeric component preflight, never official performance results','freeze_sha':f['freeze_sha'],'functional_processes':30,'files':{name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in files.items()}}
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
    for name,p in files.items():z.write(p,name)
    z.writestr('EVIDENCE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read(n)).hexdigest()==v for n,v in manifest['files'].items())
print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'members':len(files)+1}))
