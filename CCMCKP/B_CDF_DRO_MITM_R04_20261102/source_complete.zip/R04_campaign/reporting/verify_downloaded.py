"""Independent archive-based audit; never imports or calls native evaluators."""
import gzip,hashlib,io,json,math,pickle,sys,zipfile
from pathlib import Path,PurePosixPath
import numpy as np
root=Path(__file__).resolve().parents[1];reference=Path(r'E:\codex\CCMCKP_DRO_goal_20261101')
snapshot=Path(sys.argv[1]) if len(sys.argv)>1 else sorted((root/'report_snapshots').glob('pilot_*.json'))[-1]
read=lambda p:json.loads(p.read_text(encoding='utf8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=read(snapshot);protocol=read(root/'PROTOCOL.json');registry=read(root/'REFERENCE_REGISTRY.json');audited=[]
with zipfile.ZipFile(reference/'CCMCKP_frozen_raw_inputs.zip') as z:
    for summary in d['summaries']:
        if summary['wave_status'] not in ('valid_complete','ordinary_failure_complete'):continue
        idx=summary['index'];arm=summary['arm'];case=next(c for c in protocol['cases'] if c['index']==idx)
        if arm=='B' and str(idx) in registry['waves']:
            entry=registry['waves'][str(idx)];folder=reference/'evidence/waves'/PurePosixPath(entry['directory']).name
            for name,digest in entry['files'].items():assert sha(folder/name)==digest
            expected_freeze=registry['freeze_sha'];expected_protocol=registry['protocol_sha'];context=PurePosixPath(registry['campaign_root'])
        else:
            matches=[p for p in (root/'evidence/waves').iterdir() if (p/'WAVE.json').exists() and read(p/'WAVE.json')['index']==idx and read(p/'WAVE.json')['arm']==arm and read(p/'WAVE.json')['phase']==summary['phase'] and read(p/'WAVE.json')['status']==summary['wave_status']]
            assert len(matches)==1;folder=matches[0];expected_freeze=sha(root/'FREEZE.json');expected_protocol=sha(root/'PROTOCOL.json');context=PurePosixPath(registry['campaign_root']).parent/'codex_B_DRO_R04_20261101'
        meta=read(folder/'WAVE.json');times=read(folder/'TIMING_JOURNAL.json');prefix='benchmark/'+case['instance']+'/'
        costs=np.loadtxt(io.BytesIO(z.read(prefix+'cost.txt'))).reshape(-1);raw=pickle.loads(z.read(prefix+'node_to_factor.pkl'));groups=[raw[k] for k in sorted(raw,key=lambda k:int(k))] if isinstance(raw,dict) else raw
        values=[];bounds=[]
        for rep in range(1,31):
            p=folder/('r%02d.json.gz'%rep);t=read(folder/('r%02d.terminal.json'%rep));w=read(p.with_name(p.name+'.worker.json'));x=json.loads(gzip.decompress(p.read_bytes()))
            assert t['reason']=='returned' and t['returncode']==0
            assert sha(p)==t['record_sha'] and sha(p.with_name(p.name+'.worker.json'))==t['worker_sha']
            assert w['freeze_sha']==expected_freeze and w['protocol_sha']==expected_protocol and w['input_registry_sha']==sha(root/'INPUTS.json')
            assert x['seed']==w['seed']==832272+rep and w['rep']==rep and w['arm']==arm and w['index']==idx
            assert x['instance']==case['instance'] and x['capacity']==case['tmax']
            cfg=x['config'];assert cfg['time_budget']==600 and cfg['work_reserve']==15 and cfg['native_draws']==1000000 and cfg['native_gate']==.99 and cfg['screen_gate']==.975 and cfg['screen_draws']==60000
            assert cfg['bins']==4096 and cfg['radii']==[.00025,0.,.0005]
            s=x['selected'];assert s and s==w['selected'];ids=s['selection'];assert len(ids)==len(groups) and len(set(ids))==len(groups)
            assert all(len(set(g)&set(ids))==1 for g in groups);assert abs(math.fsum(float(costs[j]) for j in ids)-s['cost'])<1e-8
            assert s['probability']>=.99 and any(o['selection']==ids and o['probability']==s['probability'] for o in x['native_observations'])
            assert times[str(rep)]<=600 and times[str(rep)]>=t['elapsed_before_terminal_save']>=w['elapsed_before_worker_sidecar']>=x['runtime_before_save']
            assert x['external_solution_inputs'] is False and x['prior_count']==0 and w['no_cross_seed_weights'] is True
            wave=context/'waves'/folder.name;data=PurePosixPath('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/case['instance']
            for name in w['project_paths_opened']:
                path=PurePosixPath(name)
                assert path==data or data in path.parents or context/'sources'/arm in path.parents or path in (context/'PROTOCOL.json',context/'INPUTS.json',wave) or wave in path.parents
            values.append(s['cost']);bounds.append(times[str(rep)])
        assert len(values)==30 and abs(math.fsum(values)/30-summary['avg'])<1e-8
        audited.append({'arm':arm,'index':idx,'records':30,'mean_cost':math.fsum(values)/30,'min_saved_runtime':min(bounds),'max_saved_runtime':max(bounds)})
result={'status':'passed','snapshot':snapshot.name,'records':sum(a['records'] for a in audited),'waves':audited,'scope':'Raw archive cost/groups/seeds/native-return threshold/terminal SHA/frozen input registry/open-path isolation/saved-result clock chain. No native resampling, population certificate or server-load causal matching claim.'}
out=root/'report_snapshots'/('independent_download_audit_'+d['snapshot_utc']+'.json')
if out.exists():raise RuntimeError('Retain existing audit; do not overwrite')
out.write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result))
