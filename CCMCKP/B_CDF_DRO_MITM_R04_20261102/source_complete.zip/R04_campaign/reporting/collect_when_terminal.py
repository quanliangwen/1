"""Read-only terminal collection. Never launches/restarts optimization workers."""
import datetime,hashlib,json,os,subprocess,sys,time,traceback,zipfile
from pathlib import Path,PurePosixPath

ROOT=Path(__file__).resolve().parents[1];HERE=ROOT/'terminal_collection_A02';HERE.mkdir(exist_ok=True)
REMOTE='/home/junhao/quan/parallel_test_solver/CCMKCP/work/codex_B_DRO_R04_20261101'
HOST='junhao@10.112.162.60';NODE=Path(r'C:\Users\Administrator\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe')
SHA='96b28599b2facac514e30aac25382114b818e4a24810fb8e7428f3bde2b46a04'
POLL="""from pathlib import Path
import sys,json,datetime
r=Path('%s');sys.path.insert(0,str(r))
from common import read,process_table
s=read(r/'STATE.json');t=process_table();p=t.get(s['controller_pid'])
print(json.dumps({'utc':datetime.datetime.utcnow().isoformat(),'state':s,'controller_verified_live':bool(p and p['start_ticks']==s['controller_start_ticks']),'workers':sum(str(r/'worker.py') in v['cmd'] for v in t.values())}))
"""%REMOTE
ENV=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,d):
    tmp=p.with_name(p.name+'.tmp');tmp.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8');os.replace(tmp,p)
def event(name,**kw):
    with (HERE/'events.jsonl').open('a',encoding='utf8') as f:f.write(json.dumps(dict(utc=now(),event=name,**kw),ensure_ascii=False)+'\n');f.flush();os.fsync(f.fileno())
def command(args,**kw):
    p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,encoding='utf8',errors='replace',env=ENV,**kw)
    if p.returncode:raise RuntimeError('Command failed: '+repr(args)+'\n'+p.stdout[-2000:]+'\n'+p.stderr[-2000:])
    return p.stdout
def ssh_python(code,timeout=60):return command(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15',HOST,'python3','-B','-'],input=code,timeout=timeout)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def report(d,audit_rc,out):
    f=lambda x:'留空' if x is None else '%.8g'%x
    lines=['R04全量终末材料（自动准备，仍需最终人工审阅）','快照UTC：'+d['snapshot_utc'],'算法冻结SHA：'+d['freeze_sha'],'调度冻结SHA：'+d['campaign_state'].get('scheduling_freeze_sha',''),'只统计正式固定B与全新R04_full；R04先导不混入。','服务端终末门槛：'+json.dumps(d.get('full_gate'),ensure_ascii=False),'独立下载原始记录审计退出码：'+str(audit_rc),'',
    '原主问题与评价器保持：每组一项、原成本最小化、原容量、原生.99/M1000000及.975预筛、原精确/MC/索引/快速拒绝/RNG规则。每次600秒实际预算、15秒收尾，独立初始化，无跨种子权重。',
    '用户后续授权降低并行；高内存四类算例上限24，其余上限30并受原未来界、峰值1.25倍、5GiB余量、外部增长及磁盘守卫限制。旧有效B14例保留。A01仅调度日志重复字段故障，在任何worker派发前退出，空波保留为基础设施未完成；A02仅修复该日志方法，不改算法。',
    'R04在B原初始化之后，以原robust_logmgf及THETA网格建立有限支撑指数矩充分条件的辅助成本MILP，再接原CDF/MITM。对独立有限边际，P(sumY>=T)<=exp(sum logEexp(thetaY/T)−theta)，约束右侧log(.01)并保留数值余量；delta .00025不缩小，所有提案仍需原评分和原生评价通过。有限theta与整数域适配不能继承连续凸规划的可解性或原CCMCKP全局最优保证。',
    '文献：Nemirovski & Shapiro (2006), Convex Approximations of Chance Constrained Programs, SIAM J Optim17(4):969–996, DOI10.1137/050622328；作者全文https://optimization-online.org/wp-content/uploads/2004/12/1033.pdf 。已读2/3/3.1/6.1节及Lemma6.1/Theorem6.1完整证明、式3.2/3.3/6.10–6.16。适用独立有限可计算MGF；本题二进制域及有限网格更保守。原扰动半径未经统计覆盖校准，不声称未知真分布覆盖。',
    '原生返回通过只表示满足原程序验收，不是未知总体概率的置信证书。计时从Popen前到结果/日志/sidecar/terminal保存后，阶段统计是离线处理，无新增优化或重抽MC。不同质量的各自最好达到时间不能单独证明提速，须看预登记共同质量目标命中率与限制均时。','', '每例成本及波动（不足30有效时官方avg/std/CV留空）：']
    for s in d['summaries']:
        lines.append('%s 编号%d：登记%d，有效%d，失败%d；best=%s avg=%s std=%s CV=%s；最终最好首次均秒=%s，best命中%d/条件均秒%s，实际均秒%s；原目标命中%d/条件均秒%s/限制均秒%s；失败原因%s'%(s['arm'],s['index'],s['registered'],s['valid'],s['failed'],f(s['best']),f(s['avg']),f(s['std']),f(s['CV']),f(s['mean_final_best_first_seconds']),s['best_hits'],f(s['conditional_best_hit_seconds']),f(s['mean_actual_runtime']),s['target_hits'],f(s['conditional_target_seconds']),f(s['restricted_target_seconds']),json.dumps(s['failure_reasons'],ensure_ascii=False)))
    lines+=['','配对比较（候选−B）：']
    for c in d['comparisons']:lines.append('编号%d：%s'%(c['index'],json.dumps(c,ensure_ascii=False)))
    lines+=['','所有区间为19999次配对bootstrap的描述性百分位95%非同时区间；符号翻转<=20非零精确枚举，否则99999随机翻转加观察值，40项Holm。依赖配对符号对称/可交换及种子对独立抽样假设。共享服务器负载、调度变化、自适应算法选择及相同强制种子限制因果解释与泛化；不显著不等于等效。',
    'R01、R03正式负结果和R02未正式试验的本地重物化负时间证据全部保留。R01第40例退化约1.53%；R03第40/18例退化约10.05%/5.51%。R04是在这些探索后选定；全新执行不等于未见数据确认，区间未对候选选择校正。',
    '完整验收需要2400条比较全部有效、整体原均成本及归一化均成本下降、改善例数多于退化、小中大组均不劣、完整时间和源/输入/解审计及交付核验。自动准备材料、程序退出或服务端门槛通过不自动完成线程目标；仍须人工检查覆盖范围、图表和局限。']
    out.write_text('\n'.join(lines)+'\n',encoding='utf8')
def collect():
    result=json.loads(ssh_python("import runpy;runpy.run_path('%s/reporting/export_terminal_readonly.py',run_name='__main__')"%REMOTE,timeout=900).strip().splitlines()[-1]);event('remote_export_finished',result=result)
    archive=ROOT/'deliverable_snapshots'/Path(result['path']).name
    assert not archive.exists();command(['scp','-q',HOST+':'+result['path'],str(archive)],timeout=900);assert sha(archive)==result['sha256']
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None;m=json.loads(z.read('EXPORT_MANIFEST.json'));tag=m['snapshot'];snapshot=ROOT/'report_snapshots'/tag;control=ROOT/'evidence'/('terminal_collection_'+tag.removesuffix('.json'));control.mkdir(exist_ok=False)
        for name,entry in m['files'].items():
            pp=PurePosixPath(name);assert not pp.is_absolute() and '..' not in pp.parts;b=z.read(name);assert hashlib.sha256(b).hexdigest()==entry['sha256']
            dest=ROOT/'evidence'/Path(name) if pp.parts[0]=='waves' else control/Path(name)
            if dest.exists():assert dest.read_bytes()==b
            else:dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
        assert not snapshot.exists();snapshot.write_bytes(z.read('reports/'+tag))
    d=json.loads(snapshot.read_text(encoding='utf8'));stamp=d['snapshot_utc'];audit=subprocess.run([sys.executable,'-B',str(ROOT/'reporting/verify_downloaded.py'),str(snapshot)],capture_output=True,encoding='utf8',errors='replace',env=ENV)
    write(HERE/'RAW_AUDIT_PROCESS.json',{'returncode':audit.returncode,'stdout':audit.stdout,'stderr':audit.stderr})
    out=command([str(NODE),str(ROOT/'reporting/build_statistics.mjs'),str(snapshot)],timeout=300);(HERE/'excel_build.log').write_text(out,encoding='utf8')
    prose=ROOT/'report_snapshots'/('R04_全量终末说明_'+stamp+'.txt');assert not prose.exists();report(d,audit.returncode,prose)
    excel=ROOT/'report_snapshots'/('R04_全量统计_'+stamp+'.xlsx');assert excel.exists()
    inputs=ROOT.parent/'CCMCKP_DRO_goal_20261101/CCMCKP_frozen_raw_inputs.zip';source=ROOT/'deliverable_snapshots/R04_frozen_source_2fb919ae87d332bf.zip'
    files=[archive,snapshot,excel,prose,HERE/'RAW_AUDIT_PROCESS.json',inputs,source]
    source_amendment=ROOT/'deliverable_snapshots/调度修订与预检证据_A02_20261101.zip'
    if source_amendment.exists():files.append(source_amendment)
    manifest=ROOT/'deliverable_snapshots'/('SHA_全量终末自动材料_'+stamp+'.json');assert not manifest.exists();manifest.write_text(json.dumps({'status':'prepared_requires_manual_review','goal_complete':False,'full_gate':d.get('full_gate'),'files':{str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in files}},ensure_ascii=False,indent=2),encoding='utf8')
    write(HERE/'STATE.json',{'status':'prepared_requires_manual_review','utc':now(),'snapshot':str(snapshot),'excel':str(excel),'report':str(prose),'results_zip':str(archive),'sha_manifest':str(manifest),'raw_audit_returncode':audit.returncode,'server_full_gate':d.get('full_gate'),'goal_complete':False});event('delivery_materials_prepared',manifest=str(manifest),raw_audit_returncode=audit.returncode)

if __name__=='__main__':
    with (HERE/'COLLECTOR_ONCE').open('x') as f:f.write(json.dumps({'pid':os.getpid(),'utc':now(),'scope':'read-only collection; never starts optimization'}));f.flush();os.fsync(f.fileno())
    try:
        event('collector_started',pid=os.getpid())
        deadline_written=False
        while True:
            try:o=json.loads(ssh_python(POLL).strip())
            except Exception as e:event('observation_error_not_terminal',error=repr(e));time.sleep(60);continue
            s=o['state'];write(HERE/'STATE.json',{'status':'observing_existing_campaign','pid':os.getpid(),'utc':now(),'observation':o,'goal_complete':False})
            assert s.get('scheduling_freeze_sha')==SHA,'Unexpected scheduler: do not silently collect a different experiment'
            event('observation',server_status=s['status'],phase=s.get('phase'),case=s.get('index'),workers=o['workers'],controller_live=o['controller_verified_live'])
            if s['status'] in ('performance_gates_passed_delivery_pending','full_failed_requires_new_mechanism','controller_error_not_complete') and o['workers']==0:collect();break
            if not deadline_written and datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime(2026,11,1,23,36,24,tzinfo=datetime.timezone.utc):
                write(HERE/'TWELVE_HOUR_TARGET_NOT_YET_COMPLETE.json',o);event('twelve_hour_target_not_complete_no_budget_cut');deadline_written=True
            if not o['controller_verified_live'] and o['workers']==0:
                write(HERE/'REQUIRES_REVIEW_CONTROLLER_MISSING.json',o);event('controller_missing_no_restart');break
            time.sleep(60)
    except Exception as exc:
        traceback.print_exc();write(HERE/'STATE.json',{'status':'collection_error_requires_review','utc':now(),'error':repr(exc),'goal_complete':False});event('collection_error',error=repr(exc));raise
