"""Offline prose from terminal observations; never launches or evaluates a solver."""
import hashlib,json,sys
from pathlib import Path

root=Path(__file__).resolve().parents[1]
snapshot=Path(sys.argv[1])
read=lambda p:json.loads(p.read_text(encoding='utf8'))
d=read(snapshot);tag=d['snapshot_utc']
assert d['which']=='pilot' and len(d['terminal_records'])==240
assert all(s['valid']==30 for s in d['summaries'])
audit=read(root/'report_snapshots'/('independent_download_audit_'+tag+'.json'))
assert audit['status']=='passed' and audit['records']==240
gate=d['stage_gate'];assert gate and gate['coverage_cases']==4
by={(s['arm'],s['index']):s for s in d['summaries']}
fmt=lambda x:'未定义' if x is None else '%.8g'%x
lines=[
'R04四例完整先导：阶段证据与局限',
'数据快照：'+snapshot.name,
'冻结SHA256：'+d['freeze_sha'],
'该报告只覆盖40、25、18、14各版本各30次，不是全40例成功结论。',
'',
'机制与依据',
'唯一代码基线为上传B_CDF_DRO_MITM。R04只在原独立初始化后增加一次有限支撑指数矩界约束的成本MILP提案阶段；原9个CDF/MITM阶段随后照常运行。原4个概率/数据依赖保持原字节，原17个Solver方法除run插入一次调用外AST保持不变。R01缓存、R02重物化、R03单组算子均未叠加。',
'Nemirovski与Shapiro，Convex Approximations of Chance Constrained Programs，SIAM Journal on Optimization 17(4):969–996 (2006)，DOI:10.1137/050622328；作者全文 https://optimization-online.org/wp-content/uploads/2004/12/1033.pdf 。已读第2/3/3.1/6.1节、(3.2)(3.3)(6.10)–(6.16)、Lemma6.1和Theorem6.1完整证明。适用前提包括独立边际和有限可计算MGF；连续凸规划可解性不能移植为本二进制问题的全局求解保证。',
'沿用B的robust_logmgf与THETA网格。令psi_j(theta)=log E exp(theta*Y_j/T)，独立有限支撑边际下P(sum Y>=T)<=exp(sum psi_j-theta)。固定theta时，二进制选择使sum psi_j*x_j线性；辅助MILP施加sum psi_j*x_j-theta<=log(.01)，原成本最小化且每组一项。实际归一化约束另留1e-10余量并按原系数复核。有限theta并集比连续theta的充分条件更保守。',
'辅助使用原delta=.00025，不缩半径、不降门槛。其有限支撑可行子集比主问题更窄，只生成提案；提案仍经原CDF .975及原native_check（包括原screen/MC/精确/快速拒绝/正结果复用/随机流规则），不能凭指数界直接接受。未覆盖未知真分布，也不声称全局最优。',
'辅助20秒软预算含MGF、建模、优化、评分与原生评价，最多8个不同提案，GP单线程/SoftMemLimit .25GB。软限额不是强制截断原生调用。只有当最大半区状态上界超过原束宽时才启用，否则保持原B提案流。该结构条件不表示原MITM全局穷尽。',
'',
'成本、波动与配对区间（差=R04−B；样本std的ddof=1）',
]
for c in d['comparisons']:
    i=c['index'];b=by['B',i];r=by['R04',i]
    lines += [
      '编号%d：两版各登记30、有效30、失败0。'%i,
      '  B best/avg/std/CV：%s / %s / %s / %s。'%tuple(fmt(b[k]) for k in ('best','avg','std','CV')),
      '  R04 best/avg/std/CV：%s / %s / %s / %s。'%tuple(fmt(r[k]) for k in ('best','avg','std','CV')),
      '  配对均差%s，相对均差%.6f%%，差中位数%s，dz=%s；描述性95%%配对bootstrap区间[%s,%s]，符号翻转p=%s，4项Holm p=%s。'%(fmt(c['mean_difference']),100*c['relative_mean_difference'],fmt(c['median_difference']),fmt(c['paired_dz']),fmt(c['paired_bootstrap_95'][0]),fmt(c['paired_bootstrap_95'][1]),fmt(c['p']),fmt(c['holm_p'])),
      '  B/R04实际平均秒 %s/%s；各自最终最好首次达到平均秒 %s/%s；命中各自30次best次数 %d/%d，命中条件均秒 %s/%s。'%(fmt(b['mean_actual_runtime']),fmt(r['mean_actual_runtime']),fmt(b['mean_final_best_first_seconds']),fmt(r['mean_final_best_first_seconds']),b['best_hits'],r['best_hits'],fmt(b['conditional_best_hit_seconds']),fmt(r['conditional_best_hit_seconds'])),
      '  原定目标成本%s，B/R04命中%d/%d，命中条件均秒%s/%s，未命中按600计的限制均秒%s/%s。'%(fmt(b['target_cost']),b['target_hits'],r['target_hits'],fmt(b['conditional_target_seconds']),fmt(r['conditional_target_seconds']),fmt(b['restricted_target_seconds']),fmt(r['restricted_target_seconds'])),
    ]
lines += ['', '同质量辅助时间（预登记固定B均成本目标；从不进入worker输入）']
for a in gate.get('reference_quality_times',[]):
    b=a['arms']['B'];r=a['arms']['R04']
    lines.append('编号%d，目标%s：B/R04命中%d/%d，条件均秒%s/%s，限制均秒%s/%s。'%(a['index'],fmt(a['fixed_reference_mean_cost_target']),b['hits'],r['hits'],fmt(b['conditional_seconds']),fmt(r['conditional_seconds']),fmt(b['restricted_seconds']),fmt(r['restricted_seconds'])))
lines += [
'', '验收、完整性及时间范围',
'预登记先导数值门槛：每例两版30次有效、R04逐例均成本不劣且四例归一化均成本严格改善。当前数值门槛结果：'+str(gate['performance_gate'])+'。后续扩展另受服务器独立完整性/时间审计门槛约束，需以该审计原始JSON为证。',
'本地另从原始输入ZIP及全部240条gzip结果、worker侧记录、terminal哈希、WAVE及TIMING_JOURNAL独立核对成本、恰好每组一项、种子、冻结输入、原生返回>=.99、无跨种子权重/旧解输入和保存后的时钟链，已通过；不重新抽MC样本。',
'时间从控制器Popen前的monotonic起点计算，覆盖解释器/导入/SHA/启动屏障/数据加载/独立初始化/MIP/CDF/MITM/原生评价/结果和日志保存fsync。每次600秒硬预算，15秒收尾；自然提前完成如实报告。离线统计不算搜索时间，不产生任何新增解。不同质量的各自最终最好达到时间不能单独证明提速，须结合共同质量目标的命中率与限制均时间。',
'固定30同时启动或按原资源守卫等待，不按当前RSS降低未来包络；至少5GiB余量、外部活动增长储备及磁盘保护保留。共享服务器负载有独立观察日志，但不是随机分配的受控负载实验。',
'', '保留的负结果与选择限制',
'R01正式先导240条均保留，第40例均成本退化约1.53%，未扩展全量。R03正式先导240条均保留，第40/18例分别退化约10.05%/5.51%；40例约95.8%时间用于原生评价，29/30次未完成原MITM阶段，未扩展全量。R02仅本地重物化草案，完整半区输出一致但大例耗时多为增加约3%–6%，未登记正式性能实验。',
'R04是在上述失败诊断及原始数据几何后选择，所有机制/参数/算例/种子/门槛在R04成绩出现前冻结。全量使用相同基准和强制种子的新独立执行，不等于未见数据确认；区间与p值没有对候选自适应选择作校正。',
'配对符号翻转依赖零假设下差值符号对称/可交换；<=20个非零差时精确枚举，否则99999次随机符号加观察值；每例19999次配对bootstrap百分位95%为非同时描述性区间。Holm族先导4项、全量40项。非显著不能解释为等效或无用；某例逐对相同仅说明该次数据。',
'原CDF扰动半径未经统计覆盖校准；所有“有效/可行”指本实验原生评价器返回通过，不能推出未知总体覆盖概率或MC置信保证。',
'全目标仍需：保留有效新固定B并补齐其余36例；R04另作全新1200次且先导不混入；比较2400条全有效，整体原均成本和归一化均成本下降、改善例数多于退化、小中大组均不劣，并完成全量时间/源/输入/解/负结果审计和源码数据ZIP、Excel、SHA交付。队列耗尽、先导通过或进程正常退出均不等于全目标完成。',
]
out=root/'report_snapshots'/('R04_完整先导说明_'+tag+'.txt')
if out.exists():raise RuntimeError('Do not overwrite an existing report')
out.write_text('\n'.join(lines)+'\n',encoding='utf8')
print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},ensure_ascii=False))
