"""Source-only archival after real freeze/preflight, never a performance claim."""
import hashlib,json,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from common import read,sha,check_freeze
frozen=check_freeze();files=dict(read(ROOT/'FREEZE.json')['files']);files['FREEZE.json']=frozen
for name in ('SCORE_PREFLIGHT.json','FUNCTIONAL_PREFLIGHT.json','PREFLIGHT.json','LOCAL_PREFLIGHT.json','LOCAL_NEGATIVE_PREFLIGHT.json','preflight_local.py.target.json','preflight_negative_local.py.target.json','ADVANCE_STATE.json','COMPONENT_PREFLIGHT.json','COMPONENT_PROCESS.json','PRELAUNCH_INFRASTRUCTURE_NOTE.json'):
    p=ROOT/name
    if p.exists():files[name]=sha(p)
out=ROOT/'reporting'/'deliverable_snapshots'/('R04_frozen_source_'+frozen[:16]+'.zip');out.parent.mkdir(parents=True,exist_ok=True)
if out.exists():raise RuntimeError('Existing source snapshot retained; do not overwrite')
manifest={'kind':'Source freeze and observed preflight records, not performance improvement evidence','freeze_sha':frozen,'solver_sha':sha(ROOT/'sources/R04/solver.py'),'files':files,'external_reference_provenance':'REFERENCE_REGISTRY pins the separately retained new fixed B waves; their evidence archive and original campaign source are delivered separately. No reference selection is a candidate search input.'}
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,digest in files.items():
        assert sha(ROOT/name)==digest;z.write(ROOT/name,name)
    z.writestr('ARCHIVE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    for name,digest in files.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
result={'file':str(out),'sha256':sha(out),'bytes':out.stat().st_size,'source_files':len(read(ROOT/'FREEZE.json')['files']),'members':len(files)+1,'freeze_sha':frozen}
out.with_suffix('.sha.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result))
