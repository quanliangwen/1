import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const input=path.resolve(process.argv[2]);
const d=JSON.parse(await fs.readFile(input,'utf8'));
const candidate=[...new Set(d.summaries.map(x=>x.arm))].filter(x=>x!=='B').join('/');
const which=d.which??'pilot';const stamp=d.snapshot_utc;
const iso=`${stamp.slice(0,4)}-${stamp.slice(4,6)}-${stamp.slice(6,8)}T${stamp.slice(9,11)}:${stamp.slice(11,13)}:${stamp.slice(13,15)}Z`;
const dated=new Date(iso).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false});
const outdir=path.join(root,'report_snapshots');await fs.mkdir(outdir,{recursive:true});
const name=process.argv[3]??`${candidate}_${which==='pilot'?'先导':'全量'}统计_${stamp}`;
const w=Workbook.create();
function table(tab,title,headers,rows,widths=[]){
 const s=w.worksheets.add(tab);s.showGridLines=false;
 const all=s.getRangeByIndexes(0,0,Math.max(rows.length+9,23),headers.length);all.format={font:{name:'Microsoft YaHei',size:10},columnWidth:16,rowHeight:23,verticalAlignment:'center'};
 s.getRange('A2').values=[[title]];s.getRange('A2').format.font={name:'Microsoft YaHei',size:14,bold:true};
 s.getRange('A3').values=[[`${dated} 北京时间；只统计终末记录，缺30次有效的官方avg/std/CV留空。`]];
 s.getRangeByIndexes(4,0,1,headers.length).values=[headers];s.getRangeByIndexes(4,0,1,headers.length).format={fill:'#243B53',font:{name:'Microsoft YaHei',size:10,bold:true,color:'#FFFFFF'},horizontalAlignment:'center',rowHeight:27};
 if(rows.length)s.getRangeByIndexes(5,0,rows.length,headers.length).values=rows;
 for(const [col,width] of widths)s.getRange(`${col}5:${col}${Math.max(6,rows.length+5)}`).format.columnWidth=width;
 s.freezePanes.freezeRows(5);return s;
}
const ss=d.summaries;const last=ss.length+5;
if(which==='full'&&d.full_gate&&ss.length===80&&ss.every(s=>s.valid===30)){
 const mean=a=>a.reduce((s,x)=>s+x,0)/a.length;
 const per=arm=>ss.filter(s=>s.arm===arm);
 const b=per('B'),c=per(candidate),bm=mean(b.map(s=>s.avg)),cm=mean(c.map(s=>s.avg));
 const q=d.stage_gate.reference_quality_times;
 const limits=arm=>mean(q.map(x=>x.arms[arm].restricted_seconds));
 const hits=arm=>q.reduce((n,x)=>n+x.arms[arm].hits,0);
 const actual=arm=>mean(d.terminal_records.filter(x=>x.arm===arm).map(x=>x.elapsed_upper));
 const native=arm=>mean(d.terminal_records.filter(x=>x.arm===arm).map(x=>x.native_seconds));
 const numeric=(x,n=6)=>x.toFixed(n);
 const cvB=mean(b.map(x=>x.CV)),cvC=mean(c.map(x=>x.CV));
 table('完整验收','40例正式比较：数值门槛通过，增益较小且有退化例',
  ['指标','B基线','R04候选','解释与范围'],[
   ['有效/登记','1200/1200','1200/1200','候选全新1200次；先导不混入'],
   ['各算例avg再平均',numeric(bm),numeric(cm),`下降${numeric((1-cm/bm)*100,4)}%；不是异规模成本的全局best`],
   ['归一化均成本指数','1.000000',numeric(1+d.full_gate.overall_mean_relative),`下降${numeric(-d.full_gate.overall_mean_relative*100,4)}%`],
   ['改善/退化/持平','参照','7 / 6 / 27','全部40例保留，无按结果挑选子集'],
   ['每例CV再平均',`${numeric(cvB*100,4)}%`,`${numeric(cvC*100,4)}%`,'描述性比较；std/CV下降7例、上升6例'],
   ['最终最好首次达到均秒',numeric(mean(b.map(x=>x.mean_final_best_first_seconds)),3),numeric(mean(c.map(x=>x.mean_final_best_first_seconds)),3),'各次最终最好，不是已证明的全局最优；质量不同'],
   ['同B均成本目标限制均秒',numeric(limits('B'),3),numeric(limits(candidate),3),'同质量指标；未命中按600秒计，仅时间不填失败成本'],
   ['同质量目标命中数',`${hits('B')}/1200`,`${hits(candidate)}/1200`,'目标由固定B均成本预登记定义，从不输入worker'],
   ['实际运行均秒',numeric(actual('B'),3),numeric(actual(candidate),3),'候选实际总时间略增，不声称单次总耗时下降'],
   ['原生评价均秒',numeric(native('B'),3),numeric(native(candidate),3),'评价器未变；评价总开销上升，调用次数下降'],
   ['分组验收','小/中/大','均不劣','原成本均差及归一化均差均≤0，见分组表'],
   ['Holm显著改善','40项检验族','14、36、40','描述性非同时配对区间，未对算法探索选择校正'],
   ['Holm显著退化','40项检验族','17、38、39','其余退化31、32、37亦完整保留'],
   ['时间及完整性','原始数据复核','2400条通过','原生≥.99，全部实际≤600秒；原冻结源码未改'],
   ['因果与保证限制','相同服务器','共享负载/动态并行','11、30例并发数不同；无未知真分布覆盖或全局最优保证']
  ],[['A',32],['B',25],['C',25],['D',88]]);
}
const state={valid_complete:'30次有效完成',running:'运行中',unstarted:'未启动',ordinary_failure_complete:'终末含失败',resource_interrupted:'资源中断，保留证据',infrastructure_incomplete:'基础设施未完成'};
const overview=table('成本与有效率',`B与${candidate}：${which==='pilot'?'四例先导':'40例全量'}`,
 ['版本','编号','算例','组数','登记','终末','有效','失败','待终末','best','avg','样本std','CV','波状态','失败原因'],
 ss.map(x=>[x.arm,x.index,x.instance,x.m,x.registered,x.terminal,x.valid,x.failed,x.pending,x.best,x.avg,x.std,x.CV,state[x.wave_status]??x.wave_status,JSON.stringify(x.failure_reasons)]),
 [['A',9],['B',8],['C',28],['D',8],['E',9],['F',9],['G',9],['H',9],['I',10],['N',26],['O',35]]);
overview.getRange(`J6:L${last}`).setNumberFormat('0.000000');overview.getRange(`M6:M${last}`).setNumberFormat('0.00%');
overview.getRange(`A${last+3}`).values=[['终末记录']];overview.getRange(`B${last+3}`).formulas=[[`=SUM(F6:F${last})`]];
overview.getRange(`D${last+3}`).values=[['有效记录']];overview.getRange(`E${last+3}`).formulas=[[`=SUM(G6:G${last})`]];
const timing=table('时间与目标',`实际时间、最终最好首次达到及固定目标`,
 ['版本','编号','有效','最终最好首次均秒','命中30次best次数','命中best条件均秒','实际运行均秒','实际最短秒','实际最长秒','原定目标成本','目标命中数','目标条件均秒','目标限制均秒'],
 ss.map(x=>{const r=d.terminal_records.filter(r=>r.arm===x.arm&&r.index===x.index).map(r=>r.elapsed_upper).filter(t=>t!=null);return[x.arm,x.index,x.valid,x.mean_final_best_first_seconds,x.best_hits,x.conditional_best_hit_seconds,x.mean_actual_runtime,r.length?Math.min(...r):null,r.length?Math.max(...r):null,x.target_cost,x.target_hits,x.conditional_target_seconds,x.restricted_target_seconds];}),
 [['A',9],['B',8],['C',9],['D',25],['E',23],['F',27],['G',24],['H',20],['I',20],['J',23],['K',17],['L',26],['M',26]]);
timing.getRange(`D6:M${last}`).setNumberFormat('0.000000');
const cc=d.comparisons;const clast=cc.length+5;
const pair=table('配对比较',`${candidate}−B：负值表示候选成本更低`,
 ['编号','完整30对可检验','均成本差','相对均成本差','差中位数','配对dz','描述性区间下限','描述性区间上限','符号翻转p','Holm p','仅B有效','仅候选有效'],
 cc.map(c=>[c.index,c.assessable,c.mean_difference??null,c.relative_mean_difference??null,c.median_difference??null,c.paired_dz??null,c.paired_bootstrap_95?.[0]??null,c.paired_bootstrap_95?.[1]??null,c.p??null,c.holm_p??null,c.reference_only_valid,c.candidate_only_valid]),
 [['A',8],['B',22],['C',22],['D',23],['E',21],['F',18],['G',25],['H',25]]);
pair.getRange(`C6:J${clast}`).setNumberFormat('0.000000');pair.getRange(`D6:D${clast}`).setNumberFormat('0.00%');
pair.getRange(`C6:D${clast}`).conditionalFormats.add('cellIs',{operator:'greaterThan',formula:1e-8,format:{fill:'#FDE8E7',font:{color:'#9C1C20'}}});
pair.getRange(`C6:D${clast}`).conditionalFormats.add('cellIs',{operator:'lessThan',formula:-1e-8,format:{fill:'#E3F2E7',font:{color:'#176B3B'}}});
const rr=d.terminal_records;
const raw=table('逐次终末',`终末记录：失败不填成本`,
 ['版本','编号','重复','种子','有效','原因','成本','原生返回','最终最好首次秒','保存后实际秒','原定目标达到秒','原生调用','原生评价秒','阶段数'],
 rr.map(r=>[r.arm,r.index,r.rep,832272+r.rep,r.valid,r.reason,r.cost,r.probability??null,r.found_seconds??null,r.elapsed_upper,r.target_time??null,r.native_calls??null,r.native_seconds??null,r.stages??null]),
 [['A',9],['B',8],['C',8],['D',15],['E',9],['F',32],['G',22],['H',20],['I',25],['J',23],['K',26]]);
if(rr.length)raw.getRange(`G6:M${rr.length+5}`).setNumberFormat('0.000000');
const attempts=d.own_attempts??[];
table('运行波与资源','本候选任务目录的全部尝试；外部固定对照由冻结登记另列',
 ['阶段','编号','版本','尝试','状态','登记重复数','派发并发上限','终末数','有效数','派发可用GiB','派发需求GiB','单进程未来界GiB','观察峰值GiB','目录'],
 attempts.map(x=>[x.phase,x.index,x.arm,x.attempt,x.status,x.workers,x.parallel_limit??x.workers,x.terminal??null,x.valid??null,x.resources_at_dispatch?.available_bytes/2**30||null,x.resources_at_dispatch?.required_bytes/2**30||null,x.resources_at_dispatch?.worker_future_bound/2**30||null,x.peak_worker_rss/2**30||null,x.directory]),
 [['A',24],['B',8],['C',9],['D',8],['E',32],['F',19],['G',22],['N',90]]);
const aux=d.stage_gate?.reference_quality_times??[];
table('共同质量目标时间','预登记辅助指标：达到固定B均成本；只用于离线统计',
 ['编号','固定B均成本目标','B命中数','候选命中数','B命中条件均秒','候选命中条件均秒','B限制均秒','候选限制均秒'],
 aux.map(x=>[x.index,x.fixed_reference_mean_cost_target,x.arms.B.hits,x.arms[candidate].hits,x.arms.B.conditional_seconds,x.arms[candidate].conditional_seconds,x.arms.B.restricted_seconds,x.arms[candidate].restricted_seconds]),
 [['A',8],['B',27],['C',17],['D',20],['E',25],['F',29],['G',22],['H',25]]);
if(which==='full'){
 const groups=[['全部',1,Infinity],['小组',1,5],['中组',6,20],['大组',21,Infinity]];
 const grouped=groups.map(([label,lo,hi])=>{
  const indices=[...new Set(ss.filter(s=>s.m>=lo&&s.m<=hi).map(s=>s.index))];
  const comps=cc.filter(c=>indices.includes(c.index)&&c.assessable);
  const ready=comps.length===indices.length&&indices.length>0;
  const mean=v=>v.reduce((a,b)=>a+b,0)/v.length;
  const ba=ready?mean(indices.map(i=>ss.find(s=>s.arm==='B'&&s.index===i).avg)):null;
  const ca=ready?mean(indices.map(i=>ss.find(s=>s.arm===candidate&&s.index===i).avg)):null;
  return [label,indices.length,comps.length,ready,ba,ca,ready?mean(comps.map(c=>c.mean_difference)):null,ready?mean(comps.map(c=>c.relative_mean_difference)):null,ready?comps.filter(c=>c.relative_mean_difference< -1e-10).length:null,ready?comps.filter(c=>c.relative_mean_difference>1e-10).length:null,ready?comps.filter(c=>Math.abs(c.relative_mean_difference)<=1e-10).length:null];
 });
 const gs=table('全量分组门槛','仅完整覆盖后形成官方总体/分组统计；未完成不能据覆盖子集判全目标通过',
  ['范围','所需算例','完整有效对数','全范围可判','B算例均成本均值','候选算例均成本均值','原成本均差','归一化均差','改善例数','退化例数','持平例数'],grouped,
  [['A',12],['B',15],['C',20],['D',19],['E',29],['F',32],['G',22],['H',22],['I',16],['J',16],['K',16]]);
 gs.getRange('E6:G9').setNumberFormat('0.000000');gs.getRange('H6:H9').setNumberFormat('0.00%');
}
const notes=[
 ['源数据快照',path.basename(input)],['阶段冻结SHA256',d.freeze_sha],['协议SHA256',d.protocol_sha],['控制器状态',d.campaign_state?.status??'未知'],
 ['并行修订',d.parallel_amendment?'用户授权仅调整调度：高内存算例上限24，其余上限30，按未来内存界可进一步降低；每例仍30重复，600秒/评价/算法不变。A01日志故障在worker启动前发生，保留为基础设施未完成；A02仅修复日志字段。既有有效波未重跑。':'本快照尚未附加并行修订；以实际波元数据和已登记协议为准。'],
 ['统计门槛状态',which==='pilot'?(d.stage_gate?String(d.stage_gate.performance_gate):'本阶段尚未形成完整门槛结论'):'全量综合判定须核对FINAL_GATE.json及独立终末审计；未完整覆盖时不形成成功结论。'],
 ['官方统计','每版本每例必须30次有效，avg/std/CV否则留空；样本std用ddof=1，未给失败填虚假成本。'],
 ['时间','外部时钟从Popen前开始，覆盖导入/加载/初始化/搜索/评价/保存/fsync；预算600，15秒收尾；自然提前完成允许。'],
 ['原目标与辅助目标','原定raw目标保持；共同质量目标是固定对照均成本，预登记为R04离线辅助指标，不进入搜索输入。'],
 ['检验','配对差均值双侧符号翻转，<=20非零时精确，否则99999随机翻转加观察值；预定先导4项/全量40项Holm。'],
 ['区间','19999次配对bootstrap百分位95%为描述性、非同时区间，未校正候选自适应选择；不能据不显著声称等效。'],
 ['假设限制','符号翻转依赖零假设下配对差符号对称/可交换；共享服务器负载及非随机算法分配限制因果解释。'],
 ['探索限制','R01与R03正式先导负结果、R02未正式试验草案均保留；R04由源审查与原数据依据选择。同指定算例与种子的全新执行不等于未见数据确认。'],
 ['模型保证','扰动半径未经统计覆盖校准，有限CDF评分不是未知真分布覆盖保证；原生返回>=.99不等于总体置信证书或全局最优。'],
 ['失败与尝试','资源无效/基础设施未完成波另留全部记录，只能重试此类波；普通算法失败或有效阶段不得补跑选优。'],
 ['全量门槛','先导逐例均成本不劣、整体严格改善，独立完整性/时间审计再次通过才进入新1200次候选全量，先导不计入。'],
 ['最终目标','全部有效、整体原均成本和归一化均成本下降、改善例多于退化、小中大组均不劣；完成全量审计及交付核验后才算目标完成。']
];
table('口径与局限','证据范围与判断限制',['项目','说明'],notes,[['A',27],['B',135]]);
w.recalculate();
const errors=await w.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:30},summary:'formula error scan'});
await fs.writeFile(path.join(outdir,name+'_checks.ndjson'),errors.ndjson);
const img=await w.render({sheetName:'成本与有效率',range:`A1:N${Math.min(last+3,19)}`,scale:1.2,format:'png'});
await fs.writeFile(path.join(outdir,name+'_preview.png'),new Uint8Array(await img.arrayBuffer()));
if(which==='full'&&d.full_gate){
 for(const [sheet,range,suffix] of [['完整验收','A1:D20','验收'],['全量分组门槛','A1:K9','分组'],['成本与有效率','A70:N85','成本末段'],['时间与目标','A70:M85','时间末段']]){
  const p=await w.render({sheetName:sheet,range,scale:1.2,format:'png'});
  await fs.writeFile(path.join(outdir,name+'_'+suffix+'.png'),new Uint8Array(await p.arrayBuffer()));
 }
}
const book=await SpreadsheetFile.exportXlsx(w);await book.save(path.join(outdir,name+'.xlsx'));
console.log(JSON.stringify({output:path.join(outdir,name+'.xlsx'),terminal:rr.length,candidate,which}));console.log(errors.ndjson);
