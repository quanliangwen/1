"""Final audit of stored results only; no solver or native evaluator is called."""
import collections,csv,gzip,hashlib,json,math,sys
from pathlib import Path,PurePosixPath
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from statistics_campaign import paired,holm
read=lambda p:json.loads(p.read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
snapshot=ROOT/'report_snapshots/full_20261102T010934Z_A02.json';d=read(snapshot);reg=read(ROOT/'PROTOCOL.json');legacy=read(ROOT/'REFERENCE_REGISTRY.json')
assert len(d['terminal_records'])==2400 and len({(r['arm'],r['index'],r['rep']) for r in d['terminal_records']})==2400
assert all(r['valid'] for r in d['terminal_records'])
assert {r['index'] for r in d['terminal_records']}==set(range(1,41))
summ={(s['arm'],s['index']):s for s in d['summaries']};rows={};foldermap={};starts=collections.defaultdict(list);ends=collections.defaultdict(list);schedule_count=0;initializations=0;native_min=1.;runtime_max=0.;counter=collections.Counter();concurrency={};checks=[]
for idx in range(1,41):
    case=next(c for c in reg['cases'] if c['index']==idx)
    for arm in ['B','R04']:
        phase='reference' if arm=='B' else 'R04_full';rr=sorted([r for r in d['terminal_records'] if r['arm']==arm and r['index']==idx],key=lambda r:r['rep']);assert [r['rep'] for r in rr]==list(range(1,31));assert all(r['phase']==phase for r in rr)
        rows[arm,idx]=rr
        if arm=='B' and str(idx) in legacy['waves']:
            folder=ROOT.parent/'CCMCKP_DRO_goal_20261101/evidence/waves'/PurePosixPath(legacy['waves'][str(idx)]['directory']).name
        else:
            matches=[p for p in (ROOT/'evidence/waves').iterdir() if (p/'WAVE.json').exists() and read(p/'WAVE.json').get('phase')==phase and read(p/'WAVE.json')['index']==idx and read(p/'WAVE.json')['status']=='valid_complete'];assert len(matches)==1;folder=matches[0]
        foldermap[arm,idx]=folder;meta=read(folder/'WAVE.json');journal=read(folder/'TIMING_JOURNAL.json');assert meta['valid']==meta['terminal']==meta['workers']==30
        concurrency[arm,idx]=meta.get('parallel_limit',30)
        values=np.asarray([r['cost'] for r in rr]);s=summ[arm,idx]
        for key,value in [('best',values.min()),('avg',values.mean()),('std',values.std(ddof=1)),('CV',values.std(ddof=1)/values.mean())]:assert abs(s[key]-value)<1e-8,(idx,arm,key)
        hits=[r for r in rr if abs(r['cost']-values.min())<=1e-8];assert s['best_hits']==len(hits);assert abs(s['conditional_best_hit_seconds']-np.mean([r['found_seconds'] for r in hits]))<1e-8
        assert abs(s['mean_final_best_first_seconds']-np.mean([r['found_seconds'] for r in rr]))<1e-8
        for r in rr:
            rep=r['rep'];p=folder/('r%02d.json.gz'%rep);x=json.loads(gzip.decompress(p.read_bytes()));w=read(p.with_name(p.name+'.worker.json'));t=read(folder/('r%02d.terminal.json'%rep));upper=journal[str(rep)]
            assert sha(p)==t['record_sha'] and sha(p.with_name(p.name+'.worker.json'))==t['worker_sha'];assert x['seed']==w['seed']==832272+rep
            assert t['reason']=='returned' and t['returncode']==0
            assert upper<=600 and upper>=t['elapsed_before_terminal_save']>=w['elapsed_before_worker_sidecar']>=x['runtime_before_save']
            assert abs(upper-r['elapsed_upper'])<1e-8 and r['found_seconds']<=upper
            assert w['independent_initialization'] and w['no_cross_seed_weights'] and x['external_solution_inputs'] is False and x['prior_count']==0
            assert any(v['source']=='current_run_V50_original_low_risk_initialization' for v in x['native_observations']);initializations+=1
            cfg=x['config'];assert cfg['native_draws']==1000000 and cfg['native_gate']==.99 and cfg['screen_gate']==.975 and cfg['screen_draws']==60000 and cfg['time_budget']==600 and cfg['work_reserve']==15 and cfg['bins']==4096 and cfg['radii']==[.00025,0.,.0005]
            positive=[v for v in x['native_observations'] if v['probability']>=.99];selected=x['selected'];assert selected and selected['cost']==min(v['cost'] for v in positive)
            assert selected['probability']>=.99;native_min=min(native_min,selected['probability']);runtime_max=max(runtime_max,upper)
            first=min(v['elapsed'] for v in x['events'] if v.get('event')=='native_incumbent' and abs(v['cost']-selected['cost'])<=1e-8);assert abs(first-selected['found_seconds'])<1e-8
            starts[arm].append(t['started_monotonic']);ends[arm].append(t['started_monotonic']+upper)
            sp=folder/('r%02d.schedule.json'%rep)
            if sp.exists():
                z=read(sp);a=z['dispatch_ticket'];assert z['scheduling_freeze_sha']==d['campaign_state']['scheduling_freeze_sha'];assert z['started_monotonic']==t['started_monotonic'];assert a['available_bytes']>=a['required_bytes'] and a['foreign_growth_reserve']>=2*2**30 and not a['own_rss_used_as_admission_credit'];assert a['required_bytes']==a['admitted_concurrency']*a['worker_future_bound']+5*2**30+a['foreign_growth_reserve'];assert a['free_disk_bytes']>=3*2**30;schedule_count+=1
            counter[arm]+=1
    p=paired(rows['B',idx],rows['R04',idx],20261101+idx);p['index']=idx;checks.append(p)
assert schedule_count==1980 and initializations==2400 and min(starts['R04'])>=max(ends['B'])
holm(checks)
for a,b in zip(checks,d['comparisons']):
    assert a['index']==b['index']
    for key in ['p','holm_p','mean_difference','relative_mean_difference','median_difference','paired_dz']:
        if a.get(key) is None:assert b.get(key) is None
        else:assert abs(a[key]-b[key])<1e-8,(a['index'],key,a[key],b[key])
    assert np.max(np.abs(np.asarray(a['paired_bootstrap_95'])-b['paired_bootstrap_95']))<1e-8
mean=lambda values:float(np.mean(values))
aggregate={}
for arm in ['B','R04']:
    ss=[summ[arm,i] for i in range(1,41)];rr=[r for r in d['terminal_records'] if r['arm']==arm];quality=d['stage_gate']['reference_quality_times']
    aggregate[arm]={'registered':1200,'valid':1200,'failures':0,'case_mean_cost_mean':mean([s['avg'] for s in ss]),'mean_case_CV':mean([s['CV'] for s in ss]),'mean_final_best_first_seconds':mean([s['mean_final_best_first_seconds'] for s in ss]),'actual_mean_seconds':mean([r['elapsed_upper'] for r in rr]),'actual_min_seconds':min(r['elapsed_upper'] for r in rr),'actual_max_seconds':max(r['elapsed_upper'] for r in rr),'native_mean_seconds':mean([r['native_seconds'] for r in rr]),'native_mean_calls':mean([r['native_calls'] for r in rr]),'same_quality_hits':sum(q['arms'][arm]['hits'] for q in quality),'same_quality_restricted_mean_seconds':mean([q['arms'][arm]['restricted_seconds'] for q in quality])}
groups={}
for name,lo,hi in [('small',1,5),('medium',6,20),('large',21,999)]:
    subset=[c for c in checks if lo<=next(x for x in reg['cases'] if x['index']==c['index'])['m']<=hi]
    groups[name]={'cases':len(subset),'mean_absolute_cost_difference':mean([x['mean_difference'] for x in subset]),'mean_normalized_cost_difference':mean([x['relative_mean_difference'] for x in subset])}
gain=mean([c['mean_difference'] for c in checks]);norm=mean([c['relative_mean_difference'] for c in checks]);better=[c['index'] for c in checks if c['relative_mean_difference']< -1e-10];worse=[c['index'] for c in checks if c['relative_mean_difference']>1e-10];assert gain<0 and norm<0 and len(better)>len(worse) and all(g['mean_absolute_cost_difference']<=1e-10 and g['mean_normalized_cost_difference']<=1e-10 for g in groups.values())
source_control=ROOT/'evidence/terminal_collection_full_20261102T010934Z_A02/control';events=[json.loads(x) for x in (source_control/'scheduling_amendments/A02_20261101T1144Z/EVENTS.jsonl').read_text().splitlines()];assert not any(x['event']=='resource_emergency_wave_invalid' for x in events);observations=[x for x in events if x['event']=='resource_observation'];assert min(x['available_bytes'] for x in observations)>=5*2**30
variance={'std_lower':sum(summ['R04',i]['std']<summ['B',i]['std']-1e-8 for i in range(1,41)),'std_higher':sum(summ['R04',i]['std']>summ['B',i]['std']+1e-8 for i in range(1,41)),'CV_lower':sum(summ['R04',i]['CV']<summ['B',i]['CV']-1e-10 for i in range(1,41)),'CV_higher':sum(summ['R04',i]['CV']>summ['B',i]['CV']+1e-10 for i in range(1,41)),'note':'Descriptive only; numeric tolerances do not change acceptance criteria.'}
output={'status':'passed','scope':'2400 stored full-stage comparisons, all40 cases. No optimization, native re-evaluation or resampling.','source_snapshot':snapshot.name,'source_snapshot_sha':sha(snapshot),'records':dict(counter),'independent_initializations':initializations,'new_amended_dispatch_records':schedule_count,'candidate_fresh_after_entire_fixed_control':True,'all_original_native_returns_at_least':native_min,'all_saved_runtime_at_most_seconds':runtime_max,'all_percase_summary_time_best_hits_and_cost_moments_checked':True,'all40_paired_bootstrap_effect_and_Holm_outputs_reproduced':True,'aggregate':aggregate,'normalized_mean_difference':norm,'raw_mean_cost_difference':gain,'relative_raw_mean_cost_difference':aggregate['R04']['case_mean_cost_mean']/aggregate['B']['case_mean_cost_mean']-1,'improved_cases':better,'degraded_cases':worse,'ties':40-len(better)-len(worse),'size_groups':groups,'variance_diagnostics':variance,'Holm_significant_improvements':[c['index'] for c in checks if c['holm_p']<.05 and c['mean_difference']<0],'Holm_significant_degradations':[c['index'] for c in checks if c['holm_p']<.05 and c['mean_difference']>0],'concurrency_B_R04':{str(i):[concurrency['B',i],concurrency['R04',i]] for i in range(1,41)},'cases_with_different_concurrency':[i for i in range(1,41) if concurrency['B',i]!=concurrency['R04',i]],'sampled_new_scheduler_min_available_GiB':min(x['available_bytes'] for x in observations)/2**30,'causal_limitations':'Shared server load, adaptive concurrency and algorithm selection limit pure-operator causal attribution and generalization. Per-case intervals are descriptive non-simultaneous and not selection-adjusted. No unknown-distribution coverage/global optimum claim.'}
out=ROOT/'report_snapshots/FINAL_INDEPENDENT_REVIEW_20261102.json';assert not out.exists();out.write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf8')
csvpath=ROOT/'report_snapshots/全40例_best_avg_std_时间_20261102.csv';assert not csvpath.exists()
with csvpath.open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['编号','算例','容量','版本','登记','有效','失败','best','avg','样本std','CV','各次最终最好首次达到均秒','30次best命中数','命中best条件均秒','实际运行均秒','原定目标成本','目标命中数','目标命中条件均秒','目标限制均秒','并发上限'])
    for i in range(1,41):
        for arm in ['B','R04']:
            s=summ[arm,i];w.writerow([i,s['instance'],s['capacity'],arm,s['registered'],s['valid'],s['failed'],s['best'],s['avg'],s['std'],s['CV'],s['mean_final_best_first_seconds'],s['best_hits'],s['conditional_best_hit_seconds'],s['mean_actual_runtime'],s['target_cost'],s['target_hits'],s['conditional_target_seconds'],s['restricted_target_seconds'],concurrency[arm,i]])
print(json.dumps(output,ensure_ascii=False))
