"""Summarize stored trajectories only; no selection vectors are exported as inputs."""
import collections,gzip,json,math,sys
from pathlib import Path

root=Path(__file__).resolve().parents[1];reference=root.parent/'CCMCKP_DRO_goal_20261101'
out=Path(sys.argv[1]);assert not out.exists()
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
mean=lambda x:math.fsum(x)/len(x) if x else None
summaries=[]
for idx in [40,25,18,14]:
    pairs=[];by_arm={}
    for arm in ['B','R04']:
        folder=(reference if arm=='B' else root)/'evidence/waves'/(('reference' if arm=='B' else 'R04_pilot')+'_c%02d_a01'%idx)
        rows=[load(folder/('r%02d.json.gz'%rep)) for rep in range(1,31)]
        assert all(x['selected'] and x['selected']['probability']>=.99 for x in rows)
        by_arm[arm]=rows
        original_stages=[sum('left_states' in h for h in x['match_history']) for x in rows]
        calls=[x['native_probability_calls'] for x in rows];native_seconds=[x['native_seconds'] for x in rows]
        observations=[v for x in rows for v in x['native_observations'] if v['source']!='current_run_V50_original_low_risk_initialization']
        summary={'arm':arm,'case':idx,'records':30,'mean_native_calls':mean(calls),'mean_native_seconds':mean(native_seconds),'mean_native_fraction_record_runtime':mean([x['native_seconds']/x['runtime_before_save'] for x in rows]),'logged_original_stage_counts':dict(collections.Counter(original_stages)),'noninitial_native_observations':len(observations),'noninitial_native_rejection_fraction':sum(v['probability']<.99 for v in observations)/len(observations) if observations else None,'mean_initial_cost':mean([next(v['cost'] for v in x['native_observations'] if v['source']=='current_run_V50_original_low_risk_initialization') for x in rows])}
        if arm=='R04':
            aux=[next(h for h in x['match_history'] if h.get('engine')=='entropic_cost_MILP') for x in rows]
            accepted=[v for x in rows for v in x['events'] if v.get('event')=='native_incumbent' and v.get('source','').startswith('entropic_cost_MILP_delta')]
            attempts=[a for h in aux for a in h.get('attempts',[])]
            summary['auxiliary']={'active':sum(h['active'] for h in aux),'stop_reasons':dict(collections.Counter(h['stop_reason'] for h in aux)),'mean_phase_seconds':mean([h['seconds'] for h in aux]),'max_phase_seconds':max(h['seconds'] for h in aux),'mean_native_calls':mean([h['native_calls'] for h in aux]),'mean_solver_seconds':mean([h.get('solver_seconds',0.) for h in aux]),'accepted_improvements':len(accepted),'mean_accepted_cost':mean([v['cost'] for v in accepted]),'mean_accepted_elapsed':mean([v['elapsed'] for v in accepted]),'solver_statuses':dict(collections.Counter(a['solver_status'] for a in attempts)),'theta_counts':dict(collections.Counter(a.get('theta') for a in attempts if 'theta' in a)),'mean_further_cost_drop_after_auxiliary':mean([next(v['cost'] for v in x['events'] if v.get('event')=='native_incumbent' and v.get('source','').startswith('entropic_cost_MILP_delta'))-x['selected']['cost'] for x in rows if any(v.get('event')=='native_incumbent' and v.get('source','').startswith('entropic_cost_MILP_delta') for v in x['events'])])}
        summaries.append(summary)
    same=0
    for b,c in zip(by_arm['B'],by_arm['R04']):
        bi=[{k:v[k] for k in ['selection','cost','probability','source']} for v in b['native_observations'] if v['source']=='current_run_V50_original_low_risk_initialization']
        ci=[{k:v[k] for k in ['selection','cost','probability','source']} for v in c['native_observations'] if v['source']=='current_run_V50_original_low_risk_initialization']
        same+=bi==ci
    summaries[-1]['matched_pairs_with_identical_stored_initial_native_transcript']=same
result={'status':'completed_records_only','cases':[40,25,18,14],'source_scope':'Stored, completed pilot raw records; external fixed control B is read only for statistics. No optimization, initialization, native resampling, parameter update or worker feedback.','diagnostic_limitations':'Native rejection fractions are conditional on adaptively visited proposals and do not identify a global CDF calibration error. Original logged stage completion counts do not imply exhaustive search. Equal matched initial transcripts do not mean initializations were shared; source/path/worker audits establish independent construction. Solver status2 refers only to the conservative auxiliary MILP. Pilot selection and server load limit causal and generalization claims.','summaries':summaries}
out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(result,ensure_ascii=False))
