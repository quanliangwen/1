"""Immutable local package of completed pilot evidence only."""
import hashlib,json,sys,zipfile
from pathlib import Path

root=Path(__file__).resolve().parents[1]
previous=root.parent/'CCMCKP_DRO_goal_20261101'
snapshot=Path(sys.argv[1]);d=json.loads(snapshot.read_text(encoding='utf8'));tag=d['snapshot_utc']
assert d['which']=='pilot' and len(d['terminal_records'])==240
assert d['stage_gate']['performance_gate'] and all(x['valid']==30 for x in d['summaries'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf8'))
assert read(root/'report_snapshots'/('independent_download_audit_'+tag+'.json'))['records']==240
assert read(root/'terminal_control/audits/R04_pilot_independent.json')['all_30_valid']
assert read(root/'terminal_control/audits/pilot_subprocess.json')['returncode']==0
entries={}
def put(p,name):
    assert p.is_file() and name not in entries,(str(p),name)
    entries[name]=p
def tree(p,prefix):
    for f in sorted(p.rglob('*')):
        if f.is_file():put(f,prefix+'/'+f.relative_to(p).as_posix())
for name in ['FREEZE.json','PROTOCOL.json','INPUTS.json','REFERENCE_REGISTRY.json','README_执行与边界.txt','R04_single_mechanism.patch','PRELAUNCH_INFRASTRUCTURE_NOTE.json']:
    put(root/name,'registration/'+name)
for s in d['summaries']:
    name=('reference' if s['arm']=='B' else 'R04_pilot')+'_c%02d_a01'%s['index']
    p=(previous if s['arm']=='B' else root)/'evidence/waves'/name
    assert read(p/'WAVE.json')['status']=='valid_complete'
    tree(p,'waves/'+name)
for name in ['R04_pilot_independent.json','pilot_subprocess.json']:
    put(root/'terminal_control/audits'/name,'audits/'+name)
put(root/'terminal_control/summaries/R04_pilot.json','summaries/R04_pilot.json')
for p in sorted((root/'report_snapshots').glob('*'+tag+'*')):
    if p.is_file():put(p,'reports/'+p.name)
tree(root/'terminal_control'/('pilot_'+tag),'control_snapshot')
for name in ['write_pilot_report.py','package_pilot_evidence.py','verify_downloaded.py','build_statistics.mjs','snapshot_readonly.py']:
    put(root/'reporting'/name,'offline_reporting/'+name)
for name in ['R04_frozen_source_2fb919ae87d332bf.zip','R04_预检证据_2fb919ae87d332bf.zip']:
    put(root/'deliverable_snapshots'/name,'frozen_packages/'+name)
for name,p in [
    ('R01阶段负结果_20261101_终末.txt',previous/'R01阶段负结果_20261101_终末.txt'),
    ('R03完整先导负结果_20261101.txt',root.parent/'CCMCKP_DRO_R03_20261101'/'R03完整先导负结果_20261101.txt'),
    ('R02_deep_local_checks.json',previous/'research/R02_deep_local_checks.json'),
]:
    put(p,'negative_results/'+name)
manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in entries.items()}
external=previous/'CCMCKP_frozen_raw_inputs.zip'
assert sha(external)=='e5ebd0a26ff4a3d6d8e66cd2c3e0a342d8268dcf831315bb9fe657d9b4fb88b7'
metadata={'scope':'Completed R04 four-case pilot, 240 valid comparison records, not full-stage success. Raw inputs separately delivered. No optimization performed by packaging. Volatile control snapshot may show subsequent fixed control waves.','files':manifest,'separate_raw_input_package':{'path':str(external),'sha256':sha(external),'bytes':external.stat().st_size},'freeze_sha':d['freeze_sha'],'protocol_sha':d['protocol_sha']}
out=root/'deliverable_snapshots'/('R04_完整先导证据_'+tag+'.zip')
if out.exists():raise RuntimeError('Never overwrite evidence package')
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,p in entries.items():z.write(p,n)
    z.writestr('PACKAGE_MANIFEST.json',json.dumps(metadata,ensure_ascii=False,indent=2))
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(entries)+1
    for n,m in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==m['sha256']
digest={'path':str(out),'sha256':sha(out),'bytes':out.stat().st_size,'members':len(entries)+1,'all_member_hashes_and_crc':'passed','records':240}
out.with_suffix('.zip.sha.json').write_text(json.dumps(digest,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(digest,ensure_ascii=False))
