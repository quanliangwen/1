"""Prepare temporary Git staging files from audited results. No optimization."""
import csv,hashlib,json,os,shutil,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'github_staging_20261102/CCMCKP/B_CDF_DRO_MITM_R04_20261102'
read=lambda p:json.loads(p.read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=read(ROOT/'report_snapshots/full_20261102T010934Z_A02.json');v=read(ROOT/'report_snapshots/FINAL_INDEPENDENT_REVIEW_20261102.json');assert v['status']=='passed'
ss={(s['arm'],s['index']):s for s in d['summaries']};cc={c['index']:c for c in d['comparisons']}
def stage(src,name):
    p=DEST/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists()
    try:os.link(src,p)
    except OSError:shutil.copyfile(src,p)
    assert sha(src)==sha(p)
stage(ROOT/'deliverable_snapshots/terminal_results_20261102T010934Z.zip','results_full_2400.zip')
stage(ROOT.parent/'CCMCKP_DRO_goal_20261101/CCMCKP_frozen_raw_inputs.zip','inputs_frozen.zip')
stage(ROOT/'report_snapshots/CCMCKP_R04_全40例终审_20261102.xlsx','statistics.xlsx')
stage(ROOT/'report_snapshots/全40例_best_avg_std_时间_20261102.csv','case_statistics.csv')
for p,name in [(ROOT/'report_snapshots/FINAL_INDEPENDENT_REVIEW_20261102.json','final_review.json'),(ROOT/'report_snapshots/independent_download_audit_20261102T010934Z.json','raw_records_review.json'),(ROOT/'report_snapshots/source_archive_independent_audit_20261101T0650Z.json','original_source_review.json'),(ROOT/'report_snapshots/raw_archive_independent_audit_20261101T0655Z.json','raw_input_review.json'),(ROOT/'FREEZE.json','experiment_freeze.json'),(ROOT/'PROTOCOL.json','protocol_original.json'),(ROOT/'evidence/scheduling/A02_20261101T1144Z/AMENDMENT.json','parallel_amendment.json'),(ROOT/'evidence/scheduling/A02_20261101T1144Z/SCHEDULING_FREEZE.json','scheduling_freeze.json')]:stage(p,'audit/'+name)

commands='''本次实际执行与只读复核命令（不是要求重跑有效阶段）

环境：服务器Python3.8.10、NumPy1.24.4、SciPy1.10.1、Gurobi11.0.3；OpenBLAS/MKL/OMP/NUMEXPR线程均1。需有效Gurobi许可。原运行环境和已登记路径在协议/worker中严格核对。
算法冻结：2fb919ae87d332bf6bfbe8dc11c14b3c00a83bdd804a8e74edb7986598d92aa4。
调度冻结：96b28599b2facac514e30aac25382114b818e4a24810fb8e7428f3bde2b46a04。

历史命令：
cd /home/junhao/quan/parallel_test_solver/CCMKCP/work/codex_B_DRO_R04_20261101
/usr/bin/python3 -B scheduling_amendments/A01_20261101T1136Z/continuation_controller.py --preflight
# A01合成预检30次通过；日志错误在任何worker启动前发生，完整保留。
# A02仅修复日志元数据合并，其他方法AST相同；复用有效预检并通过4项日志回归。
/usr/bin/python3 -B scheduling_amendments/A02_20261101T1144Z/launch.py
# 实际启动2651271，现已正常结束。单次保护文件保留，不要再次执行本行。

完整离线校验（仅读取归档，不调用求解器或原生概率评价器）：
python tools/verify_delivery.py --directory .
# Python3.8或更新版及NumPy；从本GitHub任务目录运行。校验SHA256SUMS、ZIP CRC、
# 原始输入/冻结文件、2400条成本、恰好每组一项、种子、原生返回来源及完整保存时钟。

只读重统计（原服务器归档路径仍在时；不产生新解）：
OPENBLAS_NUM_THREADS=1 python3 -B reporting/snapshot_readonly.py --which full
# 新JSON是既有终末记录的统计快照，不能计作新的独立重复。

本包源文件保留当时注册的绝对项目路径和单次启动保护，供复核及溯源，不是任意路径可直接重启的模板。
当前任务已完整终末。未来若另做新实验，须先另立目录、登记新输入/调度/源码清单与验收；
不能修改本次冻结文件来冒充同一试验，也不能重跑已有有效波挑优。
'''
(DEST/'RUN_COMMANDS.txt').write_text(commands,encoding='utf8')

source={}
with zipfile.ZipFile(ROOT/'deliverable_snapshots/R04_frozen_source_2fb919ae87d332bf.zip') as z:
    for name in z.namelist():source['R04_campaign/'+name]=z.read(name)
with zipfile.ZipFile(ROOT/'deliverable_snapshots/调度修订与预检证据_A02_20261101.zip') as z:
    for name in z.namelist():
        if name.startswith(('A01_','A02_')):source['R04_campaign/scheduling_amendments/'+name]=z.read(name)
for p in (ROOT/'reporting').iterdir():
    if p.is_file() and p.suffix in ('.py','.mjs','.txt'):source['R04_campaign/reporting/'+p.name]=p.read_bytes()
source['RUN_COMMANDS.txt']=commands.encode('utf8');source['tools/verify_delivery.py']=(DEST/'tools/verify_delivery.py').read_bytes()
for p,name in [(ROOT.parent/'CCMCKP_DRO_goal_20261101/CCMCKP_B_R01_frozen_source.zip','failed_history/R01_frozen_source.zip'),(ROOT.parent/'CCMCKP_DRO_R03_20261101/deliverable_snapshots/R03_frozen_source_8f0b3b6d680e1056.zip','failed_history/R03_frozen_source.zip')]:source[name]=p.read_bytes()
r02=ROOT.parent/'CCMCKP_DRO_goal_20261101/research/R02_REMAT_DRAFT'
for p in r02.iterdir():
    if p.is_file() and p.suffix in ('.py','.txt'):source['failed_history/R02_not_formally_tested/'+p.name]=p.read_bytes()
source['failed_history/README.txt']='R01/R03是失败先导，R02仅本地未正式测试草案；均不是本次活跃基线/热启动。原历史协议不恢复执行。'.encode('utf8')
manifest={n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in source.items()}
with zipfile.ZipFile(DEST/'source_complete.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,b in source.items():z.writestr(n,b)
    z.writestr('SOURCE_PACKAGE_MANIFEST.json',json.dumps({'scope':'Uploaded baseline plus R04, immutable execution/scheduling, reporting/audit tools and clearly separated failed historical candidates. No runtime algorithm bytes modified.','files':manifest},ensure_ascii=False,indent=2))
neg={}
for p,name in [(ROOT.parent/'CCMCKP_DRO_goal_20261101/阶段证据_20261101T053518Z.zip','R01_failed_pilot_evidence.zip'),(ROOT.parent/'CCMCKP_DRO_R03_20261101/deliverable_snapshots/R03_完整先导负结果_20261101.zip','R03_failed_pilot_evidence.zip')]:neg[name]=p.read_bytes()
research=ROOT.parent/'CCMCKP_DRO_goal_20261101/research'
for name in ['R02_deep_local_checks.json','R02_memory_local_checks.json','R02_raw_local_checks.json','R02机制与证据.txt','R02内存预检补充.txt']:
    p=research/name
    if p.exists():neg['R02_not_formal/'+name]=p.read_bytes()
with zipfile.ZipFile(DEST/'negative_evidence.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,b in neg.items():z.writestr(n,b)
    z.writestr('NEGATIVE_MANIFEST.json',json.dumps({n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in neg.items()},ensure_ascii=False,indent=2))

b=v['aggregate']['B'];c=v['aggregate']['R04'];f=lambda x,n=6:format(x,'.%df'%n);pct=lambda x:format(x*100,'.4f')+'%'
lines=['# CCMCKP：B_CDF_DRO_MITM → R04 完整实验与验收','',
'**全40例已完成，预登记数值门槛通过；总体增益较小，仍有显著退化例。** 这不是普遍优越、未知真分布覆盖或全局最优的证明。',
'', '2026-11-02 03:59:39（北京时间）服务器完成终末统计，降并行实际启动后约8小时14分，早于07:36目标。复核时原控制器及所有本任务worker均已退出。没有重新启动或重跑有效波。',
'', '## 结果与完整验收','',
'- 唯一基线是上传B_CDF_DRO_MITM。固定B共1200次、候选R04全新1200次，**2400/2400有效**，每例30次、匹配种子832273—832302。每次独立原初始化；R04先导120次未混入全量。有效旧B420次保留，只补剩余780次。',
'- 改善7例（11、14、18、19、20、36、40），退化6例（17、31、32、37、38、39），持平27例；7>6。全40例均进入验收，没有按候选成绩筛选。',
'', '|指标|B|R04|解释|','|---|---:|---:|---|',
f'|各算例avg的算术均值|{f(b["case_mean_cost_mean"])}|{f(c["case_mean_cost_mean"])}|下降{pct(-v["relative_raw_mean_cost_difference"])}|',
f'|归一化均成本指数|1.000000|{f(1+v["normalized_mean_difference"])}|下降{pct(-v["normalized_mean_difference"])}|',
f'|每例CV的平均值|{pct(b["mean_case_CV"])}|{pct(c["mean_case_CV"])}|描述性下降{pct(1-c["mean_case_CV"]/b["mean_case_CV"])}；不是混合规模成本的总体std|',
f'|各次最终最好首次达到均秒|{f(b["mean_final_best_first_seconds"],3)}|{f(c["mean_final_best_first_seconds"],3)}|各自最终质量不同，不能单独据此证明提速|',
f'|同质量目标限制平均秒|{f(b["same_quality_restricted_mean_seconds"],3)}|{f(c["same_quality_restricted_mean_seconds"],3)}|下降{pct(1-c["same_quality_restricted_mean_seconds"]/b["same_quality_restricted_mean_seconds"])}|',
f'|同质量目标命中数/1200|{b["same_quality_hits"]}|{c["same_quality_hits"]}|目标为预登记固定B均成本，未命中仅对时间计600秒|',
f'|实际总运行平均秒|{f(b["actual_mean_seconds"],3)}|{f(c["actual_mean_seconds"],3)}|候选略增，不能声称每次总耗时下降|',
f'|原生评价平均秒|{f(b["native_mean_seconds"],3)}|{f(c["native_mean_seconds"],3)}|原生总开销增加，评价器没有提速|',
f'|原生调用平均次数|{f(b["native_mean_calls"],3)}|{f(c["native_mean_calls"],3)}|调用减少，但候选分布与每调用开销不同|',
f'|最大实际保存后秒|{f(b["actual_max_seconds"],6)}|{f(c["actual_max_seconds"],6)}|全部≤600秒；不是裁剪或填充后的时间|',
'', '**波动并非逐例降低：** 按数值容差std 1e-8/CV 1e-10作描述性比较，std和CV均为7例下降、6例上升、27例持平。这不是新增验收门槛；原始高精度值见CSV。',
'', '|分组（预登记）|例数|原成本均差 R04−B|归一化均差|结论|','|---|---:|---:|---:|---|']
for name,label in [('small','小：m≤5'),('medium','中：6≤m≤20'),('large','大：m≥21')]:
    g=v['size_groups'][name];lines.append(f'|{label}|{g["cases"]}|{f(g["mean_absolute_cost_difference"])}|{pct(g["mean_normalized_cost_difference"])}|两项均不劣|')
lines += ['', '## best / avg / 样本std / 达到最好解的平均时间','',
'`t_final`为30次运行中**各次最终最好可行解首次达到时间的平均值**，不是已证明的全局最优时间。各版各例30次best的命中次数、命中运行条件均时、CV、实际时间、原定目标与共同质量目标时间，完整列于[Excel](statistics.xlsx)和[80行高精度CSV](case_statistics.csv)。',
'', '|编号|B best|B avg|B std|B t_final秒|R04 best|R04 avg|R04 std|R04 t_final秒|Δavg|', '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
for i in range(1,41):
    x=ss['B',i];y=ss['R04',i];lines.append('|'+ '|'.join([str(i),f(x['best']),f(x['avg']),f(x['std']),f(x['mean_final_best_first_seconds'],3),f(y['best']),f(y['avg']),f(y['std']),f(y['mean_final_best_first_seconds'],3),pct(cc[i]['relative_mean_difference'])])+'|')
lines += ['', '## 配对检验、负结果与限制','',
'每例30个匹配种子做均差双侧符号翻转检验：≤20个非零差时精确枚举，否则99999次随机翻转加观察值；40项Holm。19999次配对bootstrap百分位95%为描述性、非同时区间。效应大小（绝对/相对均差、中位差、配对dz）及全部区间见Excel“配对比较”。方法依赖零假设下差值符号对称/可交换及种子对抽样假设，不显著不能解释为等效或无用。',
'', '**Holm校正后显著改善：14、36、40；显著退化：17、38、39。** 因而不能把预设数值门槛通过解释成所有算例更好。',
'', '|退化例|均差 R04−B|相对均差|描述性配对95%区间|Holm p|','|---|---:|---:|---|---:|']
for i in v['degraded_cases']:
    x=cc[i];ci=x['paired_bootstrap_95'];lines.append(f'|{i}|{f(x["mean_difference"])}|{pct(x["relative_mean_difference"])}|[{f(ci[0])}, {f(ci[1])}]|{x["holm_p"]:.8g}|')
lines += ['',
'- R01仅排序视图复用，正式先导第40例均成本退化约1.53%，未扩全量。R03单组局部提案第40/18例分别退化约10.05%/5.51%；第40例约95.8%记录内时间用于原生评价，29/30没有完成原MITM阶段，未扩全量。R02两遍重物化仅本地草案，完整半区输出相同、内存显著减少，但大例多慢约3%—6%，未登记正式性能结果。完整失败证据见[negative_evidence.zip](negative_evidence.zip)，历史源码在source_complete.zip中单独标注。',
'- R04基于上述探索和原数据选择。全量虽是全新独立执行，却使用同一40例和强制种子；不等于未见数据确认。区间/p值未对自适应候选选择校正。跨算例覆盖40/40，不能由此推断其他分布/规模的普遍性能。',
'- 用户后续授权降低并行以解除资源等待；高内存例上限24，其余上限30，按原未来界可进一步下调。原固定B14例保持不变。11例B/R04并发24/21，30例30/13；其余38例实际并发上限相同。共享负载和内存竞争仍限制纯算子的因果速度解释，不能把调度变化的效果归到DRO算子。新调度采样最低可用内存约41.28GiB，未触发资源中断。',
'', '## 代码审查、机制与文献依据','',
'基线：每组一项，原总成本最小化与容量/原生门槛不变。原初始化先以均值+3倍样本std为代理目标，用Gurobi构造最多8个池解（3秒），第一个原生通过者为本run起点；不用历史解。CDF扰动把低端最多δ质量移向观测最大支撑，上取整4096格并卷积评分。评分.975筛候选，原60000抽样预筛.975、原生M1000000/.99决定接纳；原精确/MC、末样本索引、快速拒绝、正结果复用及RNG推进方式均保留。',
'', '原搜索用成本分层的有限半区束（512成本桶），在三种分区和三个原半径的九个阶段槽位间联动，再MITM分块拼接；有限束宽、top候选、降本档与检查上限会舍弃解，不能声称完整枚举或全局最优。FFT、子状态PDF拼接/复制、原生排序快拒绝和百万MC是主要计算/内存开销；MC近门槛的接受差异及墙钟内完成阶段数会改变自适应搜索轨迹。',
'', 'R04唯一实质算子是在原初始化后加入一个成本MILP提案阶段，再继续原九阶段CDF/MITM。沿用原robust_logmgf、THETA网格及δ=.00025。若独立有限支撑边际为Y_j，ψ_j(θ)=log E exp(θY_j/T)，则',
'', '`P(ΣY_j≥T) ≤ exp(Σψ_j(θ)−θ)`；所以固定θ时以二进制每组选一项约束 `Σψ_j(θ)x_j−θ≤log(.01)` 为保守充分条件。辅助MILP以原成本为目标，用指标变量表达有限θ并集，归一化行保留1e-10余量并按原系数回读核验。最多8个不同提案、20秒软阶段；第一个原生接受的严格降本提案即结束。结构上半区状态总数不超过原束宽时跳过。',
'', '**新旧模型关系：** 没有缩小δ、降低门槛或替换主问题。有限θ的指数界提案集合更保守，只生成候选；所有提案仍需原CDF及原生评价通过。有限支撑、独立性和可计算MGF是公式适用前提；二进制域不继承连续凸规划可解性。原扰动半径未校准统计覆盖，观测最大值不是未知总体上界，浮点计算也不是有向舍入证书；不声称严格未知真分布DRO覆盖或原问题全局最优。',
'', '原始文献及适配：',
'1. Nemirovski & Shapiro (2006), *Convex Approximations of Chance Constrained Programs*, SIAM J Optim 17(4):969–996, DOI [10.1137/050622328](https://doi.org/10.1137/050622328)，[作者全文](https://optimization-online.org/wp-content/uploads/2004/12/1033.pdf)。已读2/3/3.1/6.1节、式3.2/3.3/6.10—6.16、Lemma6.1与Theorem6.1完整证明；本题仅借独立有限MGF的保守充分条件，有限网格/整数域偏差如上。',
'2. Michie (1968), *Memo Functions and Machine Learning*, Nature 218:19–22, DOI [10.1038/218019a0](https://doi.org/10.1038/218019a0)。原文关于等值调用记忆化用于R01不可变样本排序视图，未将内核提速推成搜索成本改善，正式负结果保留。',
'3. Chen et al. (2016), *Training Deep Nets with Sublinear Memory Cost*, [arXiv:1604.06174](https://arxiv.org/abs/1604.06174)，已读3/4.1/4.3节、Algorithm2与式1。R02适配为先评分后重构保留PDF；这里是自适应束状态，不套用其训练图O(√n)界，且本地时间负结果保留。',
'4. Fischetti & Lodi (2003), *Local Branching*, Mathematical Programming 98:23–47, DOI [10.1007/s10107-003-0395-5](https://doi.org/10.1007/s10107-003-0395-5)，已读原文2—4节及式7/8。R03只借二进制局部邻域/分解动机，单组变化不提供全局覆盖或最优保证；未用摘要充当证明。',
'', '## 冻结、计时与交付审计','',
'- 上传包SOURCE_MANIFEST的7项来源哈希吻合。当前原算法冻结137文件保持；原B Solver17个方法及模块函数，除R04新增一方法和run插入调用外AST相同，四依赖逐字节相同。算法冻结SHA `2fb919ae87d332bf6bfbe8dc11c14b3c00a83bdd804a8e74edb7986598d92aa4`；降并行A02冻结SHA `96b28599b2facac514e30aac25382114b818e4a24810fb8e7428f3bde2b46a04`。原协议的固定30条款由用户后续调度授权覆盖，其余条款不变。历史协议仅作溯源，不恢复旧任务。',
'- 两版所有运行均从Popen前独立起表，覆盖导入/哈希/加载/独立初始化/评分/MIP/搜索/原生评价/结果与日志sidecar/terminal保存fsync。每次600秒，15秒收尾；自然提前完成照实保留。2400条时钟链全部验证，无裁剪或补睡。R04全新1200次的起点晚于全部固定B完成，先导排除。',
'- A01新调度合成24并发/补位30次通过，原生调用及RNG回放匹配。随后日志重复字段故障发生在任何worker派发前，空波保留为基础设施未完成、启动0次；A02仅修复日志合并，其他AST相同，复用有效合成测试并通过4项日志回归。既有有效波未重跑；没有普通失败、超时或资源中断被补跑筛选。',
'- 本机只读收集进程最后日志停在11月1日20:05，原因不能从现有日志确定；服务器实验独立持续并按时完成。11月2日只读整理时先补建缺失导出目录，未重新初始化、重抽概率或执行优化。运行终末时间与材料整理/上传时间分开报告。',
'- [audit/final_review.json](audit/final_review.json)复算全部best/avg/ddof1 std/CV、达到时间、best命中、40例配对区间/效应/Holm；核验1980条新调度记录的完整内存界、2400次独立初始化、原始记录哈希、原生返回、保存时钟。另有2400条独立原始成本/组约束/输入/路径审计、3660个输入文件的SHA/CRC以及原源码AST审计。',
'', '## 文件','',
'- [statistics.xlsx](statistics.xlsx)：完整验收、80行成本/有效率、时间/目标、40例配对比较、逐次2400记录、全部波/资源、分组、方法限制。',
'- [case_statistics.csv](case_statistics.csv)：80行高精度best/avg/std/CV和两种“最好达到时间”明细。',
'- [source_complete.zip](source_complete.zip)：唯一B基线、R04、冻结/调度、预检和完整统计/审计工具；失败历史源码单列。',
'- [results_full_2400.zip](results_full_2400.zip)：原始逐次结果、worker/terminal/时钟、先导单列、无效空波、日志/冻结/全部统计快照；没有用先导替代全新1200次。',
'- [inputs_frozen.zip](inputs_frozen.zip)：20目录、40容量算例使用的3660个原始cost/map/sample文件及逐文件SHA。',
'- [negative_evidence.zip](negative_evidence.zip)：R01/R03正式失败先导和R02未正式测试负证据。复用B引用不是新的独立重复。',
'- [RUN_COMMANDS.txt](RUN_COMMANDS.txt)：实际命令、环境及安全的只读复核方式；本次已完成，不应重启原启动器。',
'- [SHA256SUMS.txt](SHA256SUMS.txt)、[FILE_MANIFEST.json](FILE_MANIFEST.json)：交付文件的字节数及SHA256。',
'', '离线复核：`python tools/verify_delivery.py --directory .`（需NumPy，不需要Gurobi，不调用原生评价器）。GitHub最终提交标识和上传后远端字节校验结果由交付回复给出。',
]
(DEST/'README.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
files={p.relative_to(DEST).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(DEST.rglob('*')) if p.is_file() and p.name not in ['SHA256SUMS.txt','FILE_MANIFEST.json']}
(DEST/'FILE_MANIFEST.json').write_text(json.dumps({'scope':'Final reviewed40-case delivery;2400 valid comparisons, candidate pilot excluded; numerical gates passed with disclosed limitations.','files':files},ensure_ascii=False,indent=2),encoding='utf8')
all_files=[p for p in sorted(DEST.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt']
(DEST/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+p.relative_to(DEST).as_posix()+'\n' for p in all_files),encoding='utf8')
for name in ['source_complete.zip','negative_evidence.zip']:
    with zipfile.ZipFile(DEST/name) as z:assert z.testzip() is None
print(json.dumps({'staging_directory':str(DEST),'files':len(all_files)+1,'largest_file_bytes':max(p.stat().st_size for p in all_files),'total_bytes':sum(p.stat().st_size for p in all_files)}))
