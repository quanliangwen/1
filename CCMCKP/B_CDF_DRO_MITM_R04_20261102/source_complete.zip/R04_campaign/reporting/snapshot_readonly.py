"""Only terminal audit records; never evaluates, launches or changes a solver."""
import argparse,json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from common import read,atomic,sha
from statistics_campaign import summary,paired,holm
ap=argparse.ArgumentParser();ap.add_argument('--which',choices=('pilot','full'),default='pilot');a=ap.parse_args()
reg=read(ROOT/'PROTOCOL.json');indices=reg['pilot_cases'] if a.which=='pilot' else list(range(1,41));summaries=[];comparisons=[];records=[];attempts=[]
for idx in indices:
    case=next(c for c in reg['cases'] if c['index']==idx);pair={}
    for arm in ('B','R04'):
        phase='reference' if arm=='B' else 'R04_'+a.which;pointer=ROOT/'WAVE_POINTERS'/('%s_c%02d.json'%(phase,idx));rows=[];status='unstarted';folder=None
        if pointer.exists():
            ptr=read(pointer);folder=ROOT/ptr['relative_dir'];meta=read(folder/'WAVE.json');status=meta['status']
            if status in ('valid_complete','ordinary_failure_complete'):
                rows=read(folder/'AUDIT.json');records.extend(dict(r,arm=arm,index=idx,phase=phase,wave=str(folder)) for r in rows)
        elif arm=='B' and str(idx) in read(ROOT/'REFERENCE_REGISTRY.json')['waves']:
            from audit_campaign import reference_context
            folder=Path(read(ROOT/'REFERENCE_REGISTRY.json')['waves'][str(idx)]['directory'])
            reference_context(folder,case,arm)
            meta=read(folder/'WAVE.json');status=meta['status'];rows=read(folder/'AUDIT.json')
            records.extend(dict(r,arm=arm,index=idx,phase=phase,wave=str(folder)) for r in rows)
        pair[arm]=rows
        summaries.append(dict(arm=arm,index=idx,phase=phase,instance=case['instance'],m=case['m'],capacity=case['tmax'],target_cost=case['target_cost'],wave_status=status,**summary(rows)))
    comparisons.append(dict(index=idx,**paired(pair['B'],pair['R04'],20261101+idx)))
holm(comparisons)
for p in sorted((ROOT/'waves').glob('*/WAVE.json')) if (ROOT/'waves').exists() else []:
    m=read(p);attempts.append(dict(directory=str(p.parent),**m))
tag=time.strftime('%Y%m%dT%H%M%SZ',time.gmtime());state=read(ROOT/'STATE.json') if (ROOT/'STATE.json').exists() else {}
stage_summary=ROOT/'summaries'/('R04_'+a.which+'.json')
d={'snapshot_utc':tag,'which':a.which,'freeze_sha':sha(ROOT/'FREEZE.json'),'protocol_sha':sha(ROOT/'PROTOCOL.json'),'campaign_state':state,'summaries':summaries,'comparisons':comparisons,'terminal_records':records,'own_attempts':attempts,'official_cost_statistics_require_30_valid':True,'stage_gate':read(stage_summary) if stage_summary.exists() else None,'scope':'Read-only terminal snapshot. Resource-invalid attempts retained separately, never cost-imputed. Candidate pilot is excluded from full stage. External B waves are frozen registered statistical references, never worker inputs.'}
out=ROOT/'report_snapshots'/('%s_%s.json'%(a.which,tag));atomic(out,d)
print(json.dumps({'path':str(out),'terminal':len(records),'all_pairs_assessable':all(c['assessable'] for c in comparisons)}))
