"""Read-only source provenance audit of the delivered archive, not an experiment."""
import ast,copy,hashlib,json,sys,zipfile
from pathlib import Path

root=Path(__file__).resolve().parents[1]
archive=root/'deliverable_snapshots/R04_frozen_source_2fb919ae87d332bf.zip'
out=Path(sys.argv[1])
if out.exists():raise RuntimeError('Preserve existing source audit')
digest=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    am=json.loads(z.read('ARCHIVE_MANIFEST.json'))
    for name,h in am['files'].items():assert digest(z.read(name))==h,name
    assert digest(z.read('FREEZE.json'))==am['freeze_sha']
    frozen=json.loads(z.read('FREEZE.json'))['files']
    for name,h in frozen.items():assert digest(z.read(name))==h,name
    manifest=json.loads(z.read('sources/B/SOURCE_MANIFEST.json'))
    original=manifest['original_source_sha256']
    for name,h in original.items():assert digest(z.read('sources/B/'+name))==h,name
    assert digest(z.read('sources/B/original_experiment/worker.py'))==manifest['original_worker_sha256']
    assert digest(z.read('sources/B/original_experiment/source_inputs.json'))==manifest['original_registry_sha256']
    deps=['instance.py','native_evaluator.py','native_support.py','lss_vendor.py']
    for name in deps:assert z.read('sources/R04/'+name)==z.read('sources/B/'+name),name
    b=ast.parse(z.read('sources/B/solver.py').decode('utf8'))
    c=ast.parse(z.read('sources/R04/solver.py').decode('utf8'))
    bc=next(x for x in b.body if isinstance(x,ast.ClassDef) and x.name=='Solver')
    cc=next(x for x in c.body if isinstance(x,ast.ClassDef) and x.name=='Solver')
    base_methods=[x.name for x in bc.body if isinstance(x,ast.FunctionDef)]
    new=[x for x in cc.body if isinstance(x,ast.FunctionDef) and x.name not in base_methods]
    assert len(base_methods)==17 and len(new)==1 and new[0].name=='entropic_cost_proposal'
    cc.body.remove(new[0])
    run=next(x for x in cc.body if isinstance(x,ast.FunctionDef) and x.name=='run')
    template=ast.parse("if self.arm=='B_CDF_DRO_MITM':self.entropic_cost_proposal(.00025)").body[0]
    calls=[x for x in run.body if ast.dump(x)==ast.dump(template)]
    assert len(calls)==1;run.body.remove(calls[0])
    assert ast.dump(b)==ast.dump(c),'Unexpected change outside the single added method and run call'
    result={'status':'passed','archive':str(archive),'archive_sha256':digest(archive.read_bytes()),'freeze_sha256':am['freeze_sha'],'frozen_files_checked':len(frozen),'archive_manifest_files_checked':len(am['files']),'uploaded_original_registered_hashes_checked':7,'original_solver_sha256':digest(z.read('sources/B/solver.py')),'candidate_solver_sha256':digest(z.read('sources/R04/solver.py')),'unchanged_dependency_bytes':deps,'original_solver_methods':base_methods,'only_new_method':'entropic_cost_proposal','only_changed_original_method':'run: one conditional call inserted','whole_module_ast_matches_after_removing_only_these_additions':True,'scope':'Source identity and isolation proof; no performance claim, no oracle evaluation, no unknown-distribution coverage or global-optimality claim.'}
out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k not in ('original_solver_methods','unchanged_dependency_bytes')},ensure_ascii=False))
