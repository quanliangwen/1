"""Read-only export and independent saved-record checks; no reevaluation."""
import base64,gzip,hashlib,json,subprocess,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SERVER='/home/junhao/quan/parallel_test_solver/CCMKCP/work/codex_B_Gamma_flow_20261109'
HOST='junhao@10.112.162.60'
src=r'''
import hashlib,json,sys,zipfile
from pathlib import Path
r=Path(SERVER);sys.path.insert(0,str(r));from run_task import verify
freeze=verify();assert (r/'PRECHECK_RESULT.json').exists()
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
  assert not(str(r) in cmd and any(x in cmd for x in ['run_precheck.py','run_task.py'])),cmd
 except OSError:pass
paths=[p for p in (r/'functional').iterdir() if p.is_file()]
paths += [r/n for n in ['MATH_TARGET.json','MATH_PROCESS.json','PRECHECK_RESULT.json','PRECHECK_STATE.json','PRECHECK_LAUNCH_RECEIPT.json','precheck.log','PREREG_REMOTE_VERIFICATION.json','FREEZE.json']]
manifest={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
dest=r/'precheck_data.zip'
if dest.exists():raise FileExistsError('Read-only export already exists; fetch without rebuilding')
with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED) as z:
 for p in paths:z.write(p,str(p.relative_to(r)))
 z.writestr('EXPORT_MEMBER_SHA.json',json.dumps(manifest,indent=2))
print(json.dumps({'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,'files':len(paths),'freeze':freeze}))
'''.replace('SERVER',repr(SERVER))
cmd='/usr/bin/python3.8 -c "import base64;exec(base64.b64decode(\'%s\'))"'%base64.b64encode(src.encode()).decode()
p=subprocess.run(['ssh','-o','BatchMode=yes',HOST,cmd],capture_output=True);p.check_returncode();receipt=json.loads(p.stdout)
subprocess.run(['scp','-q',HOST+':'+SERVER+'/precheck_data.zip',str(ROOT/'precheck_data.zip')],check=True)
assert hashlib.sha256((ROOT/'precheck_data.zip').read_bytes()).hexdigest()==receipt['sha256']
dest=ROOT/'saved_evidence';dest.mkdir(exist_ok=False)
with zipfile.ZipFile(ROOT/'precheck_data.zip') as z:
    manifest=json.loads(z.read('EXPORT_MEMBER_SHA.json'))
    for name,h in manifest.items():
        raw=z.read(name);assert hashlib.sha256(raw).hexdigest()==h,name
        p=dest/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
for name in ['PRECHECK_RESULT.json','MATH_TARGET.json']:(ROOT/name).write_bytes((dest/name).read_bytes())
rows=[]
for case in [17,38,39,40,25,18,14]:
    d=json.loads((dest/'functional'/('c%d.json.gz.detail.json'%case)).read_text(encoding='utf-8'))
    raw=json.loads(gzip.decompress((dest/'functional'/('c%d.json.gz'%case)).read_bytes()))
    assert d['selected']==raw['selected'] and d['native_calls']==raw['native_probability_calls']
    assert raw['config']['native_draws']==1000000 and raw['config']['native_gate']==.99 and raw['config']['screen_gate']==.975
    assert raw['config']['time_budget']==600 and raw['config']['work_reserve']==15
    assert d['source_freeze_sha']==receipt['freeze'] and raw['seed']==832273
    assert raw['selected']['probability']>=.99
    found=[x for x in raw['native_observations'] if x['selection']==raw['selected']['selection'] and x['cost']==raw['selected']['cost'] and x['probability']==raw['selected']['probability']]
    assert found and d['native_transcript_replay_passed']
    decisions={};props=[]
    for attempt in d['gamma']['attempts']:
        for q in attempt['proposals']:
            decisions[q['decision']]=decisions.get(q['decision'],0)+1
            props.append(dict(gamma=attempt['gamma'],**q))
    rows.append(dict(case=case,decisions=decisions,proposals=props,
        initial_cost=d['initial']['cost'],final_cost=d['selected']['cost'],
        final_best_first_seconds=d['selected']['found_seconds'],native_observations=raw['native_observations']))
audit=dict(passed=True,source_freeze=receipt['freeze'],export=receipt,rows=rows,
    official_avg=None,official_std=None,official_CV=None,comparison_to_B_performance_valid=False)
(ROOT/'SAVED_RECORD_AUDIT.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'passed':True,'rows':[{k:v for k,v in x.items() if k not in ['proposals','native_observations']} for x in rows]}))
