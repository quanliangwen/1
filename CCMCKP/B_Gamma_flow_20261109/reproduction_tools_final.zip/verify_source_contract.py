"""Final immutable-byte and AST contracts against the actual uploaded B zip."""
import ast,hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
upload=Path(r'E:\CCMCKP\10.28\B_CDF_DRO_MITM_冻结源码包.zip')
assert sha(upload)=='a9a2ed74625b13e6055340810ee306e2a63954e7b7627cd2ec28b8ad09aa2017'
rows=[]
with zipfile.ZipFile(upload) as original:
    for version,root in [('A01',ROOT),('A02',ROOT/'A02')]:
        manifest=json.loads((root/'FREEZE.json').read_text(encoding='utf-8'))
        for name,h in manifest['files'].items():assert sha(root/name)==h,(version,name)
        for name in original.namelist():
            if name.endswith('/'):continue
            assert (root/'sources/B'/name).read_bytes()==original.read(name),(version,name)
        with zipfile.ZipFile(root/'source_frozen.zip') as z:
            assert set(z.namelist())==set(manifest['files'])|{'FREEZE.json'}
            for name,h in manifest['files'].items():assert hashlib.sha256(z.read(name)).hexdigest()==h
            assert z.read('FREEZE.json')==(root/'FREEZE.json').read_bytes()
        baseline=root/'sources/B/B_CDF_DRO_MITM'
        b=ast.parse((baseline/'solver.py').read_text(encoding='utf-8'))
        c=ast.parse((root/'sources/GAMMA/solver.py').read_text(encoding='utf-8'))
        cls=next(x for x in c.body if isinstance(x,ast.ClassDef) and x.name=='Solver')
        run=next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='run')
        imports=[x for x in run.body if isinstance(x,ast.ImportFrom) and x.module=='gamma_operator']
        calls=[x for x in run.body if isinstance(x,ast.Expr) and isinstance(x.value,ast.Call) and isinstance(x.value.func,ast.Name) and x.value.func.id=='gamma_frontier']
        assert len(imports)==len(calls)==1
        run.body=[x for x in run.body if x not in imports and x not in calls]
        assert ast.dump(b)==ast.dump(c),version
        for name in ['instance.py','native_evaluator.py','native_support.py','lss_vendor.py']:
            assert sha(baseline/name)==sha(root/'sources/GAMMA'/name)
        cfg=json.loads((root/'PROTOCOL.json').read_text(encoding='utf-8'))
        assert cfg['M']==1000000 and cfg['native_gate']==.99 and cfg['screen_gate']==.975
        assert cfg['total_seconds']==600 and cfg['reserve']==15 and cfg['seeds']==list(range(832273,832303))
        assert max(x['original_future_envelope'] for x in cfg['case_info'])*1.25<8*2**30
        rows.append(dict(version=version,passed=True,freeze_sha256=sha(root/'FREEZE.json'),source_zip_sha256=sha(root/'source_frozen.zip'),
            frozen_files=len(manifest['files']),uploaded_B_members=14,sole_solver_change='one gamma import and call after successful own B initialization',native_four_byte_identical=True,
            inherited_other_candidate_operators=False,future_8GiB_exceeds_original_envelope_times125pct=True))
d=dict(passed=True,versions=rows,official_B_runs_repeated=0,full_suite_started=False)
(ROOT/'SOURCE_CONTRACT_AUDIT.json').write_text(json.dumps(d,indent=2),encoding='utf-8')
print(json.dumps(d))
