"""Freeze one mechanism, raw input identities and a functionality-only plan."""
import ast,hashlib,io,json,pickle,shutil,zipfile
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=ROOT/'sources/B/B_CDF_DRO_MITM'
cases=json.loads((base/'original_experiment/cases.json').read_text(encoding='utf-8'))
(ROOT/'cases.json').write_text(json.dumps(cases,indent=2),encoding='utf-8')
chosen=[17,38,39,40,25,18,14]
inputzip=Path(r'E:\codex\CCMCKP_DRO_R04_20261101\github_staging_20261102\CCMCKP\B_CDF_DRO_MITM_R04_20261102\inputs_frozen.zip')
assert sha(inputzip)=='e5ebd0a26ff4a3d6d8e66cd2c3e0a342d8268dcf831315bb9fe657d9b4fb88b7'
inputs={};case_info=[]
with zipfile.ZipFile(inputzip) as z:
    for case in cases:
        if case['index'] not in chosen:continue
        prefix='benchmark/'+case['instance']+'/'
        files={}
        for name in z.namelist():
            if not name.startswith(prefix) or name.endswith('/'):continue
            rel=name[len(prefix):];assert '/' not in rel
            raw=z.read(name);files[rel]=hashlib.sha256(raw).hexdigest()
        inputs[case['instance']]=files
        groups=pickle.loads(z.read(prefix+'node_to_factor.pkl'))
        if isinstance(groups,dict):groups=list(groups.values())
        n=sum(map(len,groups));m=len(groups);B=4096;K=max(map(len,groups));W=max(1024,min(4096,(40960//m)//512*512))
        parents=min(W,K**max(0,(m+1)//2-1));children=parents*K
        q=2*4*children*B+16*W*(B+1)+2*4*W*B+4*16*64*K*(B+1)+8*W*B+n*(8*B+16*(B+1))+512*2**20
        joint=2*(m+1)*B*8+n*(B*8+(B+1)*16)+8*K*(B+1)*16+768*(m*(m-1)//2)*K*K+128*2**20
        original_bound=max(1*2**30,q)+max(512*2**20,joint)
        assert original_bound < 8*2**30
        case_info.append(dict(**case,m=m,n=n,max_group=K,original_future_envelope=original_bound))
(ROOT/'INPUT_SHA.json').write_text(json.dumps(inputs,indent=2),encoding='utf-8')
protocol=dict(version='GAMMA_A01',one_mechanism='Budgeted upper-resource continuation candidate generator, LP-dual compact implementation of finite-threshold identity',
    official_baseline='uploaded B_CDF_DRO_MITM, byte-identical 14 source members',
    main_problem_unchanged=True,native_gate=.99,screen_gate=.975,M=1000000,
    total_seconds=600,reserve=15,seeds=list(range(832273,832303)),
    gamma_schedule='all integers 0..m ascending, truncated only by shared phase time',phase_seconds=45.,
    model_seconds=.75,pool_solutions=4,uncertainty='empirical mean plus [0, samplemax-mean] budgeted deviations; proposal only',
    score_gate='complete original worst_cdf_hist at delta=.00025, original truncated_convolution, score>=.975',
    statistical_radius_calibration=False,probability_coverage_guarantee=False,main_problem_global_optimality_claim=False,
    paper=dict(title='Heuristic Methods for Gamma-Robust Mixed-Integer Linear Bilevel Problems',authors=['Yasmine Beck','Ivana Ljubic','Martin Schmidt'],uploaded_date='2025-01-07',doi='10.1287/ijoc.2023.0239',
        uploaded_sha256=sha(Path(r'E:\26课程\鲁棒优化分享\Heuristic Methods for Γ-Robust.pdf')),
        read_sections='2,3.1-3.5,4.1-4.3,5.1-5.2,Appendix A Lemma2 proof; visual p4,p6',
        original_source='Bertsimas & Sim 2003 Math Programming98:49-71, DOI10.1007/s10107-003-0396-4, Theorem1 pp53-54 and Theorem3 pp56-57 full proofs read'),
    adaptation='Single-level uncertain packing proxy, not follower objective/bilevel optimization; no transfer of paper lower bounds, gap, global-optimality certificates, or symmetry-based probability bounds.',
    functional_cases=chosen,functional_seed=832273,functional_parallel=2,
    case_info=case_info,functional_scope='ONLY original own initialization + new operator + actual original-native RNG replay; no formal cost result and no full1200 autostart',
    formal_admission='Separate full-run functional tests, target saved-data diagnostics, then prospective frozen 7case x30 pilot with original gates and reused B; no auto start in A01.',
    formal_pilot_cases=chosen,formal_gate='all30valid each, each avg<=B and overall strict improvement; mean-case std/CV and fixed-B-mean restricted target times nonworse; independent time/integrity audit before full',
    no_rerun_valid_waves=True,no_historical_solution_inputs=True,no_cross_seed_weights=True,
    negative_history='R04 full gains small and focused cases regress; R08F pilot fails38; R09 seven cases all terminal, failed38. None restored/restarted. New mechanism not combined with old candidates.',
    selection_limitations='Same benchmark suite previously inspected. Functional seed is fixed first prescribed seed; no inference of population equivalence or performance improvement.')
(ROOT/'PROTOCOL.json').write_text(json.dumps(protocol,ensure_ascii=False,indent=2),encoding='utf-8')
names=['gamma_math.py','gamma_operator.py','run_task.py','run_precheck.py','test_math.py','PROTOCOL.json','cases.json','INPUT_SHA.json','BASELINE_AUDIT.json']
paths=[ROOT/n for n in names]+[p for p in (ROOT/'sources').rglob('*') if p.is_file()]
files={str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in sorted(paths)}
freeze=ROOT/'FREEZE.json'
with freeze.open('x',encoding='utf-8') as f:json.dump(dict(files=files,source='sole uploaded B plus one Gamma auxiliary operator',formal_performance_started=False),f,indent=2)
with zipfile.ZipFile(ROOT/'source_frozen.zip','x',zipfile.ZIP_DEFLATED) as z:
    for name in files:z.write(ROOT/name,name)
    z.write(freeze,'FREEZE.json')
print(json.dumps(dict(freeze_sha=sha(freeze),source_zip_sha=sha(ROOT/'source_frozen.zip'),files=len(files),cases=chosen)))
