"""Independent saved-XLSX values/formulas, official missing fields, errors."""
import hashlib,json,math,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=ROOT/'statistics.xlsx';ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(p) as z:
    shared=[]
    if 'xl/sharedStrings.xml' in z.namelist():
        for si in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si',ns):
            shared.append(''.join(t.text or '' for t in si.findall('.//s:t',ns)))
    sheets=[ET.fromstring(z.read(n)) for n in ['xl/worksheets/sheet1.xml','xl/worksheets/sheet2.xml']]
    assert not any(c.get('t')=='e' for sheet in sheets for c in sheet.findall('.//s:c',ns))
    cells={c.get('r'):c for c in sheets[0].findall('.//s:c',ns)}
    def value(addr):
        c=cells.get(addr)
        if c is None:return None
        v=c.find('s:v',ns)
        if c.get('t')=='s':return shared[int(v.text)]
        if c.get('t')=='str':return v.text if v is not None else None
        if c.get('t')=='inlineStr':return ''.join(t.text or '' for t in c.findall('.//s:t',ns))
        return float(v.text) if v is not None and v.text else None
    rowno=6
    for version,docpath,dirpath in [('A01','PRECHECK_RESULT.json','saved_evidence'),('A02','A02/PRECHECK_RESULT.json','A02/saved_evidence')]:
        d=json.loads((ROOT/docpath).read_text(encoding='utf-8'))
        for row in d['cases']:
            detail=json.loads((ROOT/dirpath/'functional'/('c%d.json.gz.detail.json'%row['case'])).read_text(encoding='utf-8'))
            terminal=next(x for x in d['terminals'] if x['case']==row['case'])
            proposals=[p for a in detail['gamma']['attempts'] for p in a['proposals']]
            values=[version,row['case'],832273,1,1,row['initial_cost'],row['final_cost'],row['final_cost']-row['initial_cost'],row['probability'],detail['selected']['found_seconds'],row['gamma_seconds'],terminal['actual_elapsed'],sum(p['decision']=='original_CDF_rejected' for p in proposals),sum(p.get('native_calls',0) for p in proposals),None,None,None]
            for i,expected in enumerate(values):
                addr=chr(65+i)+str(rowno);actual=value(addr)
                if isinstance(expected,(float,int)):assert actual is not None and math.isclose(actual,expected,rel_tol=1e-12,abs_tol=1e-12),(addr,actual,expected)
                else:assert actual==expected,(addr,actual,expected)
            f=cells['H'+str(rowno)].find('s:f',ns);assert f is not None and f.text=='G%d-F%d'%(rowno,rowno)
            rowno+=1
assert rowno==20
receipt=dict(passed=True,workbook_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),sheets=2,
    raw_source_rows_checked=14,columns_checked=17,official_avg_std_CV_blank=True,
    formula_errors=0,delta_formulas_checked=14,input_change_restore_check=True,
    all_sheets_rendered=True,visual_review_required_before_publish=True)
(ROOT/'SPREADSHEET_QA.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))
