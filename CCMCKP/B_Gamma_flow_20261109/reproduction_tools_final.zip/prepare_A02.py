"""Numerical-path correction in a NEW isolated revision, preserve A01 forever."""
import hashlib,json,shutil,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
DEST=ROOT/'A02';DEST.mkdir(exist_ok=False)
old=json.loads((ROOT/'FREEZE.json').read_text(encoding='utf-8'))
for name,h in old['files'].items():
    p=ROOT/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==h
    q=DEST/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
operator=(DEST/'gamma_operator.py').read_text(encoding='utf-8')
needle="    hist = solver.histograms(.00025)\n"
operator=operator.replace(needle,needle+'    original_fft = np.fft.rfft(hist,2*solver.bins,axis=1)\n')
start=operator.index('                # Full circular FFT')
end=operator.index("                row['original_CDF_delta00025']=score",start)
operator=operator[:start]+'''                # Same first-partition marginal PDFs, float32 storage after
                # every depth, float64 reverse CDF and pair scoring as B.
                halves=[]
                for groups in [range(0,solver.inst.m,2),range(1,solver.inst.m,2)]:
                    pdf=np.zeros((1,solver.bins),np.float32);pdf[0,0]=1.
                    for g in groups:
                        freq=np.fft.rfft(pdf,2*solver.bins,axis=1)*original_fft[selection[g]][None,:]
                        pdf=np.maximum(0.,np.fft.irfft(freq,2*solver.bins,axis=1)[:,:solver.bins]).astype(np.float32)
                    halves.append(pdf)
                cdf=np.ascontiguousarray(np.cumsum(halves[1],axis=1,dtype=np.float64)[:,::-1].T)
                score=float(np.clip((halves[0]@cdf)[0,0],0.,1.))
'''+operator[end:]
(DEST/'gamma_operator.py').write_text(operator,encoding='utf-8',newline='\n')
cfg=json.loads((DEST/'PROTOCOL.json').read_text(encoding='utf-8'))
cfg.update(version='GAMMA_A02',parent_frozen_A01=hashlib.sha256((ROOT/'FREEZE.json').read_bytes()).hexdigest(),
    reason='A01 complete auxiliary CDF used original convolution algebra but float64 sequential grouping. Max observed difference1.95e-8 with no observed gate crossing. A02 preserves B half-PDF float32 depth casts and reverse-CDF pair arithmetic.',
    no_parameter_change=True,no_A01_performance_wave_rerun=True,
    previous_negative_retained='A01 38/39 zero auxiliary improvements,8 originalCDF rejections each; retain, do not claim A02 will improve them.',
    score_gate='Original B first-partition half-PDF arithmetic/dtypes and pair score, delta=.00025, score>=.975')
(DEST/'PROTOCOL.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
# Reuse the already valid algebra/MILP test because none of its code or inputs changed.
shutil.copyfile(ROOT/'MATH_TARGET.json',DEST/'MATH_TARGET.json')
manager=(DEST/'run_precheck.py').read_text(encoding='utf-8')
start=manager.index('    tests=subprocess.run(');end=manager.index("    outdir=ROOT/'functional'",start)
manager=manager[:start]+'''    math=json.loads((ROOT/'MATH_TARGET.json').read_text())
    assert math['passed'] and math['compact_MILP_exhaustive_checks']==560
'''+manager[end:]
(DEST/'run_precheck.py').write_text(manager,encoding='utf-8',newline='\n')
# Preserve original failed L3 synthetic evidence; a fresh L30 fixture is needed
# because the unchanged native exact branch returns1-2/L^m on all-safe data.
synthetic=(ROOT/'run_synthetic_precheck.py').read_text(encoding='utf-8')
synthetic=synthetic.replace("L=3 if exact else 30","L=30")
synthetic=synthetic.replace("m=2 if exact else 8;L=3 if exact else 30","m=2 if exact else 8;L=30")
(DEST/'run_synthetic_precheck.py').write_text(synthetic,encoding='utf-8',newline='\n')
shutil.copyfile(ROOT/'MATH_LOCAL.json',DEST/'MATH_LOCAL.json')
note=dict(parent=cfg['parent_frozen_A01'],math_reused=True,
    math_code_sha=hashlib.sha256((ROOT/'gamma_math.py').read_bytes()).hexdigest(),
    test_code_sha=hashlib.sha256((ROOT/'test_math.py').read_bytes()).hexdigest(),
    math_result_sha=hashlib.sha256((ROOT/'MATH_TARGET.json').read_bytes()).hexdigest(),
    synthetic_fixture_change='L3 failed original exact returned.7777777778 for all-safe two-group data. Keep failure; new L30 exact fixture expects original p>=.99. No evaluator correction or looser gate.',
    prior_functional_runs=7,prior_formal_runs=0,new_formal_runs=0)
(DEST/'REVISION_AND_REUSE.json').write_text(json.dumps(note,ensure_ascii=False,indent=2),encoding='utf-8')
paths=[p for p in DEST.rglob('*') if p.is_file()]
files={str(p.relative_to(DEST)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
(DEST/'FREEZE.json').write_text(json.dumps(dict(files=files,source='sole uploaded B plus corrected one Gamma auxiliary operator, A01 retained',formal_performance_started=False),indent=2),encoding='utf-8')
with zipfile.ZipFile(DEST/'source_frozen.zip','x',zipfile.ZIP_DEFLATED) as z:
    for name in files:z.write(DEST/name,name)
    z.write(DEST/'FREEZE.json','FREEZE.json')
print(json.dumps({'A02_freeze':hashlib.sha256((DEST/'FREEZE.json').read_bytes()).hexdigest(),'files':len(files)}))
