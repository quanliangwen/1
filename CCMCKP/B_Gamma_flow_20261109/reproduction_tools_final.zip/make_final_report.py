"""Report only actual completed prechecks, preserving negative attempts."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
a=json.loads((ROOT/'A02/PRECHECK_RESULT.json').read_text(encoding='utf-8'))
s=json.loads((ROOT/'A02/SYNTHETIC_RESULT.json').read_text(encoding='utf-8'))
audit=json.loads((ROOT/'FINAL_INDEPENDENT_AUDIT.json').read_text(encoding='utf-8'));assert audit['passed']
score=json.loads((ROOT/'A02/SCORE_ALIGNMENT_AUDIT_V2.json').read_text(encoding='utf-8'));assert score['passed']
lines=['Γ鲁棒论文流程适配：实际功能测试结论（非正式性能结论）','',
'本次实现的是“Γ预算辅助候选→原CDF评分→原生概率核验→原B搜索”的单一新增机制。唯一官方基线仍为上传B，未继承其他版本算子。',
'A01源码冻结后先测，保留全部结果；随后仅因评分数值路径统一建立隔离A02，未改Γ序列、45秒阶段预算、.75秒单模型预算、池4或任何门槛。两个源码及数据ZIP均交付，A01未改动。','',
'数学预检：1120项预算值/阈值恒等式、560项可行集并集检查、560项紧凑MILP与穷举对比通过。A02中数学代码和输入均未变，复用这些有效证据，未再运行。',
f"A02完整合成预检：{len(s['rows'])}个独立进程，种子832273—832302，精确分支{s['exact_processes']}、MC分支{s['MC_processes']}。各自原初始化、完整九阶段、新Γ算子、逐调用原生返回值/随机状态回放、正缓存复用和两次负结果重评均通过。每个进程总预算600/工作585，实际含全部回放和保存；最大实际时间{max(x['actual_elapsed'] for x in s['rows']):.6f}秒。合成自然结束，不填充600秒，也不计正式候选结果。",
'A02七例实数据功能预检：每例仅种子832273一次，全部有效、原生回放一致。这里仅运行原初始化与新算子，不执行全部MITM阶段。即使有起点到末点的成本下降，也不能归因为相对B完整600秒的改进。','',
'例号\t本次原初始化成本\t算子后成本\t原生概率\tGamma阶段秒\t实际总秒\t新增原生调用']
for q in a['cases']:
    detail=json.loads((ROOT/'A02/saved_evidence/functional'/('c%d.json.gz.detail.json'%q['case'])).read_text(encoding='utf-8'))
    terminal=next(x for x in a['terminals'] if x['case']==q['case'])
    calls=sum(p.get('native_calls',0) for x in detail['gamma']['attempts'] for p in x['proposals'])
    lines.append('%d\t%.9f\t%.9f\t%.6f\t%.6f\t%.6f\t%d'%(q['case'],q['initial_cost'],q['final_cost'],q['probability'],q['gamma_seconds'],terminal['actual_elapsed'],calls))
lines += ['',
'重点负结果：38例Γ=1的四个低成本提案，其CDF评分约0.959809—0.960759；39例约0.972303—0.972680，均低于0.975。两例Γ=0/1共各八个提案全被原CDF拒绝，未新增原生调用；Γ≥2在当次起点成本上限下均判不可行。两个算子末成本保持287.244956009与401.941893580。这只说明此固定功能检查未修复38/39，不能等同于正式30次失败或成功。',
'诊断：辅助模型只找每个Γ下最便宜的四个选择，整数Γ从1跳到2可能跨过与原CDF风险相匹配的区域。经验最大偏差主导预算风险，导致低Γ模型过于乐观、较高Γ又过于保守。现有数据不足以支持将此机制扩大为正式试点或全量；没有通过缩小CDF半径、放松概率或临时改参数来选取好看结果。若后续研究分数Γ或原CDF可行边界，应另立有理论依据的新计划，保留本负结果，并重新冻结后测试。','',
'保留的预检失败：A01首个两组L=3合成例中，原生精确评价器对全安全选择仍返回0.7777777778，按0.99门槛导致原初始化无解，检查停止；不是资源中断，未重启或补跑A01。原评价器不修改。A02另登记L=30精确分支的合成输入，原评价器返回规则照旧，15个独立精确分支完整运行通过。这是对功能输入适用性的修订，不作为算法性能改进证据。',
'数值检查：A01复用原卷积函数但顺序float64分组与B半区逐层float32有约1.95e-8差异，七例未见门槛翻转；A02按原B半区存储精度、分区与反向CDF矩阵积计算，全部已测提案的数值对照差为0。初版独立检查器用一维向量点积而非B二维矩阵积，曾观测1e-15—1.2e-14舍入差；保留V1记录及其失败断言，V2改用B真实矩阵形状且仍要求零差，检查通过。没有放宽容差或修改候选运行源码。','',
'时间与资源：实数据功能2并行、合成完整检查1并行；上限低于30。每worker未来预留8GiB，高于七例原守卫包络，保留5GiB、峰值1.25、外部增长预留及磁盘检查，不把自身瞬时RSS加回可派发额度。外部Popen前起钟，源/输入SHA、导入、加载、初始化、模型、CDF、原生评价与回放、结果保存/fsync均计入600。源文件在运行前冻结并在结束后重新验SHA。日志、claim、flock、PID/start_ticks、终末记录和失败均在数据ZIP。','',
'统计状态：A01和A02各七次实数据功能记录，A02另有30次合成完整预检；正式新B=0，正式候选=0，正式先导=未启动，全40例1200=未启动。没有每例30次独立有效正式结果，因此官方best/avg/std/CV、配对置信区间、p值、效应量与多重校正结果均不出具；Excel中的当次末成本只是功能诊断。不能声称目标已达成，也不能声称与B等效。','',
'复现：解压A02/source_frozen.zip到新的Linux目录；将reproduction_tools.zip中的prepare_inputs.py放到同一根目录，执行python3.8 -B prepare_inputs.py --zip PATH/inputs_frozen.zip。当前仅登记固定七例输入。已有文件只验SHA不覆盖。候选完整运行入口为python3.8 -B run_task.py --case 38 --seed 832273 --out NEW_DIR/c38_r01.json.gz（不带--operator-only）；它使用全部原B阶段，600秒计时。这个命令示例本轮没有作为正式试验启动。来源中保留的旧便捷入口仅作溯源，不用于本轮计时。不得重跑已登记的有效功能波或改运行源码。','',
'完整交付含两版冻结源码、来源审计、原始数据/失败证据ZIP、统计Excel、输入逐文件SHA及FILE_MANIFEST/SHA256SUMS。用户原PDF不重复分发，文献信息、已读公式/假设与适配偏差见README_中文.txt。']
(ROOT/'RESULTS_中文.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
with zipfile.ZipFile(ROOT/'reproduction_tools_final.zip','x',zipfile.ZIP_DEFLATED) as z:
    for name in ['prepare_inputs.py','prepare.py','freeze_packet.py','prepare_A02.py','collect.py','collect_all_final.py','make_final_report.py','build_workbook.mjs','verify_workbook.py','verify_source_contract.py']:
        z.write(ROOT/name,name)
print(json.dumps({'report_written':True,'synthetic':len(s['rows']),'real_functional':len(a['cases'])}))
