"""Extract sole uploaded baseline and isolate one inserted operator call."""
import ast,hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
UPLOAD=Path(r'E:\CCMCKP\10.28\B_CDF_DRO_MITM_冻结源码包.zip')
EXPECTED='a9a2ed74625b13e6055340810ee306e2a63954e7b7627cd2ec28b8ad09aa2017'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(UPLOAD)==EXPECTED
base=ROOT/'sources/B';base.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(UPLOAD) as z:
    for info in z.infolist():
        if info.is_dir():continue
        p=base/info.filename
        assert p.resolve().is_relative_to(base.resolve()),info.filename
        p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(info))
solver=next(base.rglob('solver.py'));base=solver.parent
manifest=json.loads((base/'SOURCE_MANIFEST.json').read_text(encoding='utf-8'))
for name,h in manifest['original_source_sha256'].items():assert sha(base/name)==h
dest=ROOT/'sources/GAMMA';dest.mkdir(parents=True,exist_ok=False)
for p in base.glob('*.py'):(dest/p.name).write_bytes(p.read_bytes())
old=solver.read_text(encoding='utf-8')
needle="        if self.best is None:self.save('completed');return\n"
assert old.count(needle)==1
new=old.replace(needle,needle+'        from gamma_operator import gamma_frontier\n        gamma_frontier(self)\n')
(dest/'solver.py').write_text(new,encoding='utf-8',newline='\n')
ob=ast.parse(old);nb=ast.parse(new)
original=next(x for x in ob.body if isinstance(x,ast.ClassDef) and x.name=='Solver')
candidate=next(x for x in nb.body if isinstance(x,ast.ClassDef) and x.name=='Solver')
changed=[a.name for a,b in zip(original.body,candidate.body) if ast.dump(a)!=ast.dump(b)]
assert changed==['run'],changed
files={str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in base.rglob('*') if p.is_file()}
(ROOT/'BASELINE_AUDIT.json').write_text(json.dumps(dict(passed=True,upload_sha256=EXPECTED,
    baseline_files=files,original_methods_changed=changed,
    exact_change='Import and call gamma_frontier after original successful initialization; all B methods otherwise identical.',
    original_native_four={n:sha(base/n) for n in ['instance.py','native_evaluator.py','native_support.py','lss_vendor.py']}),indent=2),encoding='utf-8')
print(json.dumps({'passed':True,'baseline_members':len(files),'changed_methods':changed}))
