"""Install registered RAW benchmark files only, never solutions; verify all SHA."""
import argparse,hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--zip',required=True);a=ap.parse_args()
source=Path(a.zip)
assert hashlib.sha256(source.read_bytes()).hexdigest()=='e5ebd0a26ff4a3d6d8e66cd2c3e0a342d8268dcf831315bb9fe657d9b4fb88b7'
registry=json.loads((ROOT/'INPUT_SHA.json').read_text(encoding='utf-8'));count=0
with zipfile.ZipFile(source) as z:
    for instance,files in registry.items():
        for name,h in files.items():
            assert Path(instance).name==instance and Path(name).name==name
            raw=z.read('benchmark/'+instance+'/'+name);assert hashlib.sha256(raw).hexdigest()==h
            dest=ROOT/'inputs/benchmark'/instance/name
            if dest.exists():assert hashlib.sha256(dest.read_bytes()).hexdigest()==h
            else:
                dest.parent.mkdir(parents=True,exist_ok=True)
                with dest.open('xb') as f:f.write(raw)
            count+=1
print(json.dumps({'verified_raw_files':count,'historical_solution_files':0}))
