import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const root=path.dirname(fileURLToPath(import.meta.url));
const a01=JSON.parse(await fs.readFile(path.join(root,'PRECHECK_RESULT.json'),'utf8'));
const a02=JSON.parse(await fs.readFile(path.join(root,'A02/PRECHECK_RESULT.json'),'utf8'));
const synth=JSON.parse(await fs.readFile(path.join(root,'A02/SYNTHETIC_RESULT.json'),'utf8'));
if(!a01.passed||!a02.passed||!synth.passed)throw Error('Actual complete precheck evidence required');
const w=Workbook.create();const main=w.worksheets.add('实数据功能记录');const notes=w.worksheets.add('预检与局限');
for(const s of [main,notes]){s.showGridLines=false;s.getRange('A1:S32').format={font:{name:'Microsoft YaHei',size:10},rowHeight:24,columnWidth:14,verticalAlignment:'center'};}
main.getRange('A2').values=[['Γ鲁棒流程适配：功能检查结果']];main.getRange('A2').format.font={size:14,bold:true};
main.getRange('A3').values=[['每例每版本仅种子832273一次；只测原初始化加新算子。末成本与当次起点比较，不能作为对B的600秒性能改进。']];
const headers=['版本','例号','种子','登记','有效','本次起点成本','算子后成本','成本变化','原生概率','首次达末成本秒','算子秒','实际总秒','CDF拒绝数','新增原生调用','官方avg','官方std','官方CV'];
main.getRange('A5:Q5').values=[headers];
main.getRange('A5:Q5').format={fill:'#243B53',font:{bold:true,color:'#FFFFFF'},horizontalAlignment:'center',rowHeight:28};
const rows=[];
for(const [version,doc,dir] of [['A01',a01,'saved_evidence'],['A02',a02,'A02/saved_evidence']]){
 for(const q of doc.cases){
  const d=JSON.parse(await fs.readFile(path.join(root,dir,`functional/c${q.case}.json.gz.detail.json`),'utf8'));
  const t=doc.terminals.find(x=>x.case===q.case);
  const proposals=d.gamma.attempts.flatMap(x=>x.proposals);
  rows.push([version,q.case,832273,1,t.valid?1:0,q.initial_cost,q.final_cost,null,q.probability,d.selected.found_seconds,q.gamma_seconds,t.actual_elapsed,
    proposals.filter(x=>x.decision==='original_CDF_rejected').length,
    proposals.reduce((n,x)=>n+(x.native_calls??0),0),null,null,null]);
 }
}
main.getRange('A6:Q19').values=rows;
for(let r=6;r<=19;r++)main.getRange(`H${r}`).formulas=[[`=G${r}-F${r}`]];
main.getRange('A5:A19').format.columnWidth=9;main.getRange('B5:B19').format.columnWidth=8;main.getRange('C5:C19').format.columnWidth=13;
main.getRange('D5:E19').format.columnWidth=8;main.getRange('F5:H19').format.columnWidth=18;
main.getRange('J5:J19').format.columnWidth=22;main.getRange('N5:N19').format.columnWidth=20;
main.getRange('F6:H19').setNumberFormat('0.000000');main.getRange('I6:I19').setNumberFormat('0.000000');main.getRange('J6:L19').setNumberFormat('0.000');
main.getRange('O6:Q19').setNumberFormat('0.000000');main.getRange('A22').values=[['官方avg/std/CV留空：没有30次独立有效正式运行。无配对区间或显著性结论。功能模式原生回放的额外计算已计时。']];
main.freezePanes.freezeRows(5);
notes.getRange('A2').values=[['预检覆盖与保留的负结果']];notes.getRange('A2').format.font={size:14,bold:true};
notes.getRange('A5:D5').values=[['事项','A01','A02','含义']];notes.getRange('A5:D5').format={fill:'#243B53',font:{bold:true,color:'#FFFFFF'},rowHeight:28,horizontalAlignment:'center'};
const nr=[
 ['预算值与阈值恒等式',1120,1120,'A02复用未改变代码及输入的有效数学证据'],
 ['可行集并集检查',560,560,'存在一个阈值，并非所有阈值约束的交集'],
 ['MILP与穷举对比',560,560,'辅助模型正确性，不代表原机会约束的全局最优'],
 ['七例功能有效次数',7,7,'各一次；全部是原评价器0.99接受的当次结果'],
 ['完整合成运行数',0,synth.rows.length,'A02每次独立原初始化，完整九阶段，原生逐调用随机状态回放'],
 ['精确分支完整合成数',0,synth.exact_processes,'保留原评价器语义和返回值'],
 ['MC分支完整合成数',0,synth.MC_processes,'保留末样本排除、快速拒绝、负缓存重评与随机流'],
 ['新正式B运行数',0,0,'原B结果复用，没有重跑旧有效波'],
 ['正式候选30次先导',0,0,'未启动，功能成功不能当性能验收通过'],
 ['全量1200次候选',0,0,'未启动'],
 ['38、39算子改善次数',0,0,'八个低成本提案分别均被CDF门槛拒绝；不能声称修复退化'],
 ['L3精确合成预检','失败后停止','另登记L30输入','原评价器在全安全两组L3例返回0.7778，保留失败，不改变评价器'],
 ['辅助CDF数值路径','顺序float64','原B半区float32','A01最大观测差约1.95e-8、无门槛翻转；A02统一原B路径'],
 ['总预算秒',600,600,'外部Popen前起钟，工作截止585，导入/哈希/加载/构造/评价/保存均计入'],
 ['辅助阶段上限秒',45,45,'单模型.75秒、池4、Γ整数0..m；未按测试结果改参数'],
 ['实数据功能并行数',2,2,'8GiB未来worker预留、5GiB底线、外部增长，满足原资源守卫'],
 ['DRO覆盖及最优性','未证明','未证明','经验最大值非未知真支撑；Γ预算集与原CDF集合不等同'],
 ['选择限制','同一旧套件','同一旧套件','这些是探索性功能记录，不能视为未见数据或选择校正后的确认'],
 ['论文依据','Beck/Ljubić/Schmidt','Bertsimas/Sim','DOI10.1287/ijoc.2023.0239；10.1007/s10107-003-0396-4，正文公式与证明已读'],
 ['数据来源','首版终末JSON','A02终末JSON','PRECHECK_RESULT.json及A02版本；完整提案、拒绝、原生记录及SHA见数据ZIP']
];
notes.getRangeByIndexes(5,0,nr.length,4).values=nr;
notes.getRange('A5:A25').format.columnWidth=31;notes.getRange('B5:C25').format.columnWidth=23;notes.getRange('D5:D25').format.columnWidth=110;
const originalInput=rows[0][5];const originalDelta=rows[0][6]-originalInput;
main.getRange('F6').values=[[originalInput+1]];w.recalculate();
if(Math.abs(main.getRange('H6').values[0][0]-(originalDelta-1))>1e-10)throw Error('Delta formula input-change check failed');
main.getRange('F6').values=[[originalInput]];
w.recalculate();
const error=await w.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:20},maxChars:1500});
await fs.writeFile(path.join(root,'WORKBOOK_ERROR_SCAN.json'),error.ndjson);
const check=await w.inspect({kind:'table',range:'实数据功能记录!A5:Q19',include:'values,formulas',tableMaxRows:16,tableMaxCols:17,maxChars:14000});
await fs.writeFile(path.join(root,'WORKBOOK_INSPECTION.json'),check.ndjson);
await fs.mkdir(path.join(root,'previews'),{recursive:true});
for(const [name,sheet,range] of [['functional','实数据功能记录','A1:Q23'],['notes','预检与局限','A1:D25']]){
 if(process.argv.includes('--notes-only-preview')&&name!=='notes')continue;
 const img=await w.render({sheetName:sheet,range,scale:1.4,format:'png'});
 await fs.writeFile(path.join(root,'previews',name+'.png'),new Uint8Array(await img.arrayBuffer()));
}
await (await SpreadsheetFile.exportXlsx(w)).save(path.join(root,'statistics.xlsx'));
console.log(JSON.stringify({workbook:'statistics.xlsx',sheets:2,rows:rows.length,bytes:(await fs.stat(path.join(root,'statistics.xlsx'))).size}));
