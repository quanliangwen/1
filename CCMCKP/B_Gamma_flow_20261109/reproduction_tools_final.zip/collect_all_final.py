"""Export all attempts including failures only after actual diagnostics exit."""
import base64,gzip,hashlib,json,subprocess,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
HOST='junhao@10.112.162.60'
base='/home/junhao/quan/parallel_test_solver/CCMKCP/work/'
src=r'''
import hashlib,json,sys,zipfile
from pathlib import Path
base=Path(BASE);r=base/'codex_B_Gamma_flow_A02_20261109';old=base/'codex_B_Gamma_flow_20261109'
sys.path.insert(0,str(r));from run_task import verify
freeze=verify();synth=json.loads((r/'SYNTHETIC_RESULT.json').read_text());assert synth['passed']
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
  assert not(str(r) in cmd and any(x in cmd for x in ['run_precheck.py','run_task.py','run_synthetic_precheck.py']))
 except OSError:pass
paths=[p for q in ['functional','synthetic'] for p in (r/q).rglob('*') if p.is_file()]
names=['PRECHECK_RESULT.json','PRECHECK_STATE.json','PRECHECK_LAUNCH_RECEIPT.json','precheck.log','PREREG_REMOTE_VERIFICATION.json','FREEZE.json','MATH_TARGET.json','REVISION_AND_REUSE.json','SYNTHETIC_RESULT.json','SYNTHETIC_STATE.json','SYNTHETIC_LAUNCH_RECEIPT.json','synthetic.log','SCORE_ALIGNMENT_AUDIT.json','SCORE_ALIGNMENT_AUDIT_V2.json','SCORE_CHECKER_V2_FREEZE.json','score_alignment_audit.py','score_alignment_audit_v2.py']
paths += [r/n for n in names if (r/n).exists()]
def export(root,paths,dest):
 assert not dest.exists(),dest
 manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED) as z:
  for p in paths:z.write(p,str(p.relative_to(root)))
  z.writestr('EXPORT_MEMBER_SHA.json',json.dumps(manifest,indent=2))
 return dict(sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),bytes=dest.stat().st_size,members=len(paths))
a=export(r,paths,r/'precheck_data.zip')
neg=[p for p in (old/'synthetic').rglob('*') if p.is_file()]
neg += [old/n for n in ['SCORE_NUMERICAL_AUDIT.json','SCORE_PROCESS.json','SYNTHETIC_FAILURE.json','SUPPLEMENT_FREEZE.json','SUPPLEMENT_LAUNCH.json','supplement.log','run_synthetic_precheck.py','score_audit.py'] if (old/n).exists()]
b=export(old,neg,old/'negative_synthetic_and_score.zip')
print(json.dumps({'A02':a,'A01_negative':b,'freeze':freeze}))
'''.replace('BASE',repr(base))
cmd='/usr/bin/python3.8 -c "import base64;exec(base64.b64decode(\'%s\'))"'%base64.b64encode(src.encode()).decode()
p=subprocess.run(['ssh','-o','BatchMode=yes',HOST,cmd],capture_output=True)
if p.returncode:raise RuntimeError(p.stderr.decode('utf-8',errors='replace'))
receipt=json.loads(p.stdout)
for version,remote,local in [('A02','codex_B_Gamma_flow_A02_20261109/precheck_data.zip',ROOT/'A02/precheck_data.zip'),('A01_negative','codex_B_Gamma_flow_20261109/negative_synthetic_and_score.zip',ROOT/'negative_synthetic_and_score.zip')]:
    subprocess.run(['scp','-q',HOST+':'+base+remote,str(local)],check=True)
    assert hashlib.sha256(local.read_bytes()).hexdigest()==receipt[version]['sha256']
    folder=ROOT/('A02/saved_evidence' if version=='A02' else 'negative_evidence');folder.mkdir(exist_ok=False)
    with zipfile.ZipFile(local) as z:
        manifest=json.loads(z.read('EXPORT_MEMBER_SHA.json'))
        for name,h in manifest.items():
            raw=z.read(name);assert hashlib.sha256(raw).hexdigest()==h,name
            target=(folder/name).resolve();assert folder.resolve() in target.parents
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
for name in ['PRECHECK_RESULT.json','SYNTHETIC_RESULT.json','SCORE_ALIGNMENT_AUDIT_V2.json']:
    (ROOT/'A02'/name).write_bytes((ROOT/'A02/saved_evidence'/name).read_bytes())
synth=json.loads((ROOT/'A02/SYNTHETIC_RESULT.json').read_text())
assert synth['passed'] and synth['exact_processes']==15 and synth['MC_processes']==15
assert [x['seed'] for x in synth['rows']]==list(range(832273,832303))
for row in synth['rows']:
    raw=ROOT/'A02/saved_evidence/synthetic'/('r%02d'%row['rep'])/'AUDIT.json'
    assert hashlib.sha256(raw.read_bytes()).hexdigest()==row['audit_sha']
    d=json.loads(raw.read_text());assert d['passed'] and d['nine_original_stages'] and d['work_upper']<585 and row['actual_elapsed']<=600
    assert d['source_freeze']==receipt['freeze'] and d['selection']['probability']>=.99
    assert any(q['source']=='forced_negative_replay_2' for q in d['transcript'])
    assert d['transcript'][-1]['p'] is not None and d['transcript'][-1]['p']<.99
aligned=json.loads((ROOT/'A02/SCORE_ALIGNMENT_AUDIT_V2.json').read_text());assert aligned['passed']
assert all(x['max_abs_difference']==0 and x['all_observed_gates_same'] for x in aligned['rows'])
real=json.loads((ROOT/'A02/PRECHECK_RESULT.json').read_text());assert real['passed'] and len(real['cases'])==7
for row in real['cases']:
    p=ROOT/'A02/saved_evidence/functional'/('c%d.json.gz.detail.json'%row['case']);assert hashlib.sha256(p.read_bytes()).hexdigest()==row['detail_sha']
    d=json.loads(p.read_text());raw=json.loads(gzip.decompress(p.with_name('c%d.json.gz'%row['case']).read_bytes()))
    assert d['environment']==dict(numpy='1.24.4',scipy='1.10.1',gurobi=[11,0,3])
    assert d['source_freeze_sha']==receipt['freeze'] and d['native_transcript_replay_passed'] and d['selected']==raw['selected']
    assert raw['seed']==832273 and raw['selected']['probability']>=.99
    assert raw['config']['native_draws']==1000000 and raw['config']['native_gate']==.99 and raw['config']['screen_gate']==.975
    assert raw['config']['time_budget']==600 and raw['config']['work_reserve']==15
audit=dict(passed=True,source_freeze=receipt['freeze'],export=receipt,synthetic_complete=30,real_functional_complete=7,
    exact_complete=15,MC_complete=15,score_alignment_max_abs=0.,new_B_performance_runs=0,new_formal_candidate_runs=0,
    official_avg=None,official_std=None,official_CV=None,full_goal_achieved=False)
(ROOT/'FINAL_INDEPENDENT_AUDIT.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
print(json.dumps(audit))
