"""Detached, exclusive seven-case functional study. No automatic formal pilot."""
import fcntl,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
from run_task import atomic,verify
ROOT=Path(__file__).resolve().parent

def resources(count,foreign_start=0):
    available=next(int(x.split()[1])*1024 for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'))
    foreign=0
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
            rss=int(next(x.split()[1] for x in (p/'status').read_text().splitlines() if x.startswith('VmRSS:')))*1024
            if str(ROOT) not in cmd:foreign+=rss
        except (OSError,StopIteration,ValueError):pass
    growth=max(2*2**30,foreign//2,max(0,foreign-foreign_start))
    # 8 GiB per worker is above the original conservative R09 future envelope
    # for every selected case and covers the independent native replay object.
    need=count*8*2**30+5*2**30+growth
    ticket=dict(available=available,required=need,foreign_rss=foreign,foreign_growth=growth,
                future_per_worker=8*2**30,peak_factor=1.25,floor=5*2**30,
                own_RSS_admission_credit=False,free_disk=shutil.disk_usage(ROOT).free)
    return available>=need and ticket['free_disk']>=3*2**30,ticket

def main():
    lock=(ROOT/'PRECHECK.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    with (ROOT/'PRECHECK_UNIQUE_CLAIM').open('x') as f:f.write(str(os.getpid()))
    freeze=verify();cfg=json.loads((ROOT/'PROTOCOL.json').read_text())
    math=json.loads((ROOT/'MATH_TARGET.json').read_text())
    assert math['passed'] and math['compact_MILP_exhaustive_checks']==560
    outdir=ROOT/'functional';outdir.mkdir(exist_ok=False)
    jobs={};pending=list(cfg['functional_cases']);terminals=[]
    _,initial=resources(0);foreign_start=initial['foreign_rss']
    while pending or jobs:
        for pid,(p,case,log) in list(jobs.items()):
            if p.poll() is not None:
                log.flush();os.fsync(log.fileno());log.close()
                record=json.loads((outdir/('c%d.json.gz.terminal.json'%case)).read_text())
                terminals.append(record);del jobs[pid]
                if not record['valid']:raise RuntimeError('Functional worker failed; preserve evidence, no automatic rerun')
        ok,ticket=resources(2,foreign_start)
        while pending and len(jobs)<2 and ok:
            case=pending.pop(0);out=outdir/('c%d.json.gz'%case)
            log=(outdir/('c%d.parent.log'%case)).open('x')
            cmd=[sys.executable,'-B',str(ROOT/'run_task.py'),'--case',str(case),'--seed','832273','--out',str(out),'--operator-only']
            p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            jobs[p.pid]=(p,case,log)
            atomic(outdir/('c%d.dispatch.json'%case),dict(case=case,pid=p.pid,resources=ticket,source_freeze=freeze))
            ok,ticket=resources(2,foreign_start)
        atomic(ROOT/'PRECHECK_STATE.json',dict(status='running' if jobs else 'waiting_original_guard',pid=os.getpid(),
            pending=pending,active=[{'pid':pid,'case':x[1]} for pid,x in jobs.items()],terminal=len(terminals),resources=ticket))
        if pending or jobs:time.sleep(.5)
    verify()
    rows=[]
    for case in cfg['functional_cases']:
        p=outdir/('c%d.json.gz.detail.json'%case);d=json.loads(p.read_text())
        assert d['native_transcript_replay_passed'] and d['source_freeze_sha']==freeze
        assert d['selected'] and d['selected']['probability']>=.99
        assert d['gamma']['seconds'] < 60 and d['seconds_before_final_save'] < 585
        rows.append(dict(case=case,initial_cost=d['initial']['cost'],final_cost=d['selected']['cost'],
            probability=d['selected']['probability'],gamma_seconds=d['gamma']['seconds'],
            gamma_models=len(d['gamma']['attempts']),gamma_status=d['gamma']['status'],native_calls=d['native_calls'],
            transcript_calls=len(d['transcript']),native_mode=d['selected']['probability_evaluator'],detail_sha=hashlib.sha256(p.read_bytes()).hexdigest()))
    atomic(ROOT/'PRECHECK_RESULT.json',dict(passed=True,scope='functionality_only',source_freeze=freeze,
        cases=rows,terminals=terminals,new_B_runs=0,new_official_candidate_runs=0,
        formal_pilot_started=False,full_1200_started=False,performance_success=False,
        limitations='One prescribed seed per case; real native replay doubles evaluation work; no best/avg/std/CV inference. Original B frontier and full nine-stage behavior not timed in this component study.'))
    atomic(ROOT/'PRECHECK_STATE.json',dict(status='completed_functional_only',pid=os.getpid(),active=[],terminal=len(rows)))

if __name__=='__main__':
    try:main()
    except Exception as e:
        atomic(ROOT/'PRECHECK_FAILURE.json',dict(error=repr(e),pid=os.getpid()))
        raise
