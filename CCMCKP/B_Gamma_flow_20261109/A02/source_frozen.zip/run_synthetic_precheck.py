"""Supplemental registered 30-seed full-run exact/MC native transcript replay."""
import argparse,ast,copy,hashlib,json,os,pickle,signal,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def child(a):
    signal.signal(signal.SIGALRM,lambda *_:os._exit(124))
    signal.setitimer(signal.ITIMER_REAL,max(.001,a.started+600-time.monotonic()))
    from run_task import verify,atomic
    freeze=verify();sys.path.insert(0,str(ROOT/'sources/GAMMA'))
    import numpy as np,solver as sm
    from instance import load_instance
    folder=ROOT/'synthetic'/('r%02d'%a.rep);folder.mkdir(exist_ok=False)
    exact=a.rep%2==1;m=2 if exact else 8;L=30
    (folder/'node_to_factor.pkl').write_bytes(pickle.dumps([[2*g,2*g+1] for g in range(m)],protocol=4))
    np.savetxt(folder/'cost.txt',np.tile([3.,8.],m))
    for j in range(2*m):
        samples=np.full(L,.08 if j%2 else .55)
        if j%2==0:samples[:max(1,L//10)]=1.4
        np.savetxt(folder/('%d_sample.txt'%j),samples)
    inst=load_instance(folder);out=folder/'result.json.gz';seed=832272+a.rep
    np.random.seed(seed)
    s=sm.Solver(inst,1. if exact else 3.,seed,600,out,a.started,'B_CDF_DRO_MITM')
    other=sm.Solver(inst,s.T,seed,600,out,a.started,'B_CDF_DRO_MITM');other.save=lambda *_:None
    tree=ast.parse((ROOT/'sources/B/B_CDF_DRO_MITM/solver.py').read_text())
    cls=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='Solver')
    method=copy.deepcopy(next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='native_check'))
    env=dict(sm.__dict__);exec(compile(ast.fix_missing_locations(ast.Module(body=[method],type_ignores=[])),'uploadedB_native_check','exec'),env)
    original=env['native_check'];real=s.native_check;transcript=[]
    digest=lambda state:hashlib.sha256(pickle.dumps(state,protocol=4)).hexdigest()
    def checked(selection,source,force=False):
        outside=digest(np.random.get_state());value=real(selection,source,force)
        expected=original(other,selection,source,force)
        assert value==expected and s.native_calls==other.native_calls
        assert digest(s.native_rng.get_state())==digest(other.native_rng.get_state())
        assert digest(np.random.get_state())==outside
        transcript.append(dict(selection=list(selection),source=source,force=force,p=value,state=digest(s.native_rng.get_state())))
        return value
    s.native_check=checked;s.run()
    assert s.best and s.best['probability']>=.99
    assert len([q for q in s.match_history if 'delta' in q])==9
    # Explicit original-cache semantics: positive cached call, then twice force a
    # negative selection. Failed cache entries must not become acceptance or an
    # extra skip; random state must advance exactly as the original code does.
    checked(tuple(s.best['selection']),'cache_positive_replay',True)
    bad=tuple(2*g for g in range(m))
    checked(bad,'forced_negative_replay_1',True)
    checked(bad,'forced_negative_replay_2',True)
    atomic(folder/'AUDIT.json',dict(passed=True,rep=a.rep,seed=seed,source_freeze=freeze,
        branch=s.native_func.__name__,selection=s.best,nine_original_stages=True,
        gamma_models=len(s.gamma_report['attempts']),native_calls=s.native_calls,
        transcript=transcript,work_upper=time.monotonic()-a.started,official_performance=False))

def main():
    import fcntl
    from run_task import verify,atomic
    from run_precheck import resources
    lock=(ROOT/'SYNTHETIC.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    with (ROOT/'SYNTHETIC_UNIQUE_CLAIM').open('x') as f:f.write(str(os.getpid()))
    freeze=verify();outdir=ROOT/'synthetic';outdir.mkdir(exist_ok=False);rows=[]
    for rep in range(1,31):
        while not resources(1)[0]:time.sleep(30)
        log=(outdir/('r%02d.log'%rep)).open('x');started=time.monotonic()
        p=subprocess.Popen([sys.executable,'-B',str(Path(__file__).resolve()),'--child','--rep',str(rep),'--started',repr(started)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try:p.wait(timeout=600)
        except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
        log.flush();os.fsync(log.fileno());log.close();elapsed=time.monotonic()-started
        path=outdir/('r%02d'%rep)/'AUDIT.json'
        if p.returncode or not path.exists():raise RuntimeError('Synthetic failed rep%d; no automatic retry'%rep)
        d=json.loads(path.read_text());assert d['passed'] and d['work_upper']<585 and elapsed<=600
        rows.append(dict(rep=rep,seed=d['seed'],branch=d['branch'],native_calls=d['native_calls'],actual_elapsed=elapsed,audit_sha=hashlib.sha256(path.read_bytes()).hexdigest()))
        atomic(ROOT/'SYNTHETIC_STATE.json',dict(completed=len(rows),total=30,pid=os.getpid()))
    atomic(ROOT/'SYNTHETIC_RESULT.json',dict(passed=True,source_freeze=freeze,rows=rows,
        exact_processes=sum(x['branch']=='advanced_exact_evaluation' for x in rows),
        MC_processes=sum(x['branch']=='advanced_monte_carlo' for x in rows),
        official_candidate_runs=0,new_B_performance_runs=0,scope='Synthetic full-run functionality and native/RNG transcript, not benchmark quality'))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--child',action='store_true');ap.add_argument('--rep',type=int);ap.add_argument('--started',type=float);a=ap.parse_args()
    if a.child:child(a)
    else:
        try:main()
        except Exception as e:
            from run_task import atomic
            atomic(ROOT/'SYNTHETIC_FAILURE.json',dict(error=repr(e)));raise
