"""One auxiliary Gamma-frontier operator; all acceptance uses unchanged B.

The compact MILP implements the LP dual of the finite-threshold decomposition.
It does not replace the CCMCKP chance constraint or the original CDF score.
"""
import time
import numpy as np
import gurobipy as gp
from gurobipy import GRB
from gamma_math import validate, robust_load, protection

PHASE_SECONDS = 45.
MODEL_SECONDS = .75
POOL_SIZE = 4


def gamma_frontier(solver):
    started = time.monotonic()
    end = min(started + PHASE_SECONDS, solver.deadline - 5.)
    report = dict(engine='Gamma_budget_frontier', phase_budget=PHASE_SECONDS,
                  gamma_schedule=list(range(solver.inst.m+1)), attempts=[],
                  initial_cost=None if solver.best is None else solver.best['cost'],
                  auxiliary_only=True, population_coverage_claim=False)
    solver.gamma_report = report
    if solver.best is None or end-time.monotonic() < 5:
        report.update(status='skipped_no_incumbent_or_time', seconds=time.monotonic()-started)
        return report
    # Match the support used by the unchanged evaluator's MC branch. The original
    # exact branch uses every sample. This changes no evaluator indexing rule.
    legacy = solver.native_func.__name__ == 'advanced_monte_carlo'
    samples = [a[:-1] if legacy else a for a in solver.inst.samples]
    mu = np.array([a.mean() for a in samples])
    deviation = np.array([max(0., float(a.max()-a.mean())) for a in samples])
    validate(mu, deviation, solver.groups, solver.inst.m)
    hist = solver.histograms(.00025)
    report.update(nominal='empirical mean', deviation='observed maximum minus mean',
                  support='exclude last sample in original MC branch only',
                  original_initial_gamma_load=[robust_load(mu,deviation,solver.best['selection'],g)
                                               for g in range(solver.inst.m+1)],
                  preparation_seconds=time.monotonic()-started)
    model = gp.Model('Gamma_auxiliary_candidate_only')
    model.Params.OutputFlag=0
    model.Params.Threads=1
    model.Params.Seed=solver.seed
    model.Params.MIPGap=0.
    model.Params.PoolSearchMode=2
    model.Params.PoolSolutions=POOL_SIZE
    x = model.addMVar(solver.inst.n, vtype=GRB.BINARY, name='choice')
    theta = model.addVar(lb=0., ub=float(deviation.max()), name='budget_threshold')
    slack = model.addMVar(solver.inst.n, lb=0., name='positive_deviation')
    for group in solver.groups:
        model.addConstr(x[group].sum()==1)
    model.addConstr(slack + theta >= deviation*x)
    capacity = model.addConstr(mu@x + slack.sum() <= solver.T-1e-8).item()
    costcap = model.addConstr(solver.cost@x <= solver.best['cost']-1e-8)
    model.setObjective(solver.cost@x, GRB.MINIMIZE)
    seen = set()  # Deduplicate auxiliary proposals, never alter B's native cache.
    try:
        for gamma in range(solver.inst.m+1):
            if end-time.monotonic() < 3. or solver.remaining() < 5.:
                break
            model.chgCoeff(capacity, theta, float(gamma))
            costcap.RHS = solver.best['cost']-1e-8
            model.Params.TimeLimit=min(MODEL_SECONDS, end-time.monotonic()-2.)
            t = time.monotonic()
            model.optimize()
            elapsed = time.monotonic()-t
            solver.models += 1
            solver.model_seconds += elapsed
            attempt=dict(gamma=gamma, status=int(model.Status), sol_count=int(model.SolCount),
                         optimize_seconds=elapsed, auxiliary_bound=float(model.ObjBound)
                         if np.isfinite(model.ObjBound) else None, proposals=[])
            report['attempts'].append(attempt)
            proposals=[]
            for k in range(model.SolCount):
                model.Params.SolutionNumber=k
                v=np.asarray(x.Xn).reshape(-1)
                selection=tuple(int(group[int(np.argmax(v[group]))]) for group in solver.groups)
                solver.inst.validate_selection(selection)
                proposals.append((solver.cost_of(selection),selection))
            for cost,selection in sorted(set(proposals)):
                if end-time.monotonic()<3. or solver.remaining()<5.:
                    break
                row=dict(selection=list(selection),cost=cost,robust_load=robust_load(mu,deviation,selection,gamma))
                attempt['proposals'].append(row)
                if selection in seen:
                    row['decision']='duplicate_auxiliary_proposal';continue
                seen.add(selection)
                if cost >= solver.best['cost']-1e-8:
                    row['decision']='not_cost_improving';continue
                # Defend against numerical feasibility tolerances in the surrogate.
                if row['robust_load'] > solver.T+1e-6:
                    row['decision']='auxiliary_numerical_infeasibility';continue
                # Full circular FFT is NOT valid for >2 groups: use the original
                # truncated sequential convolution instead of aliasing high sums.
                q=np.r_[1.,np.zeros(solver.bins-1)]
                from solver import truncated_convolution
                for j in selection:
                    q=truncated_convolution(q,hist[j],solver.bins)
                score=float(np.clip(q.sum(),0.,1.))
                row['original_CDF_delta00025']=score
                if score < .975:
                    row['decision']='original_CDF_rejected';continue
                before=solver.native_calls
                probability=solver.native_check(selection,'Gamma_budget_frontier_g'+str(gamma))
                row.update(probability=probability,native_calls=solver.native_calls-before,
                           decision='original_native_returned',elapsed=time.monotonic()-solver.start)
    finally:
        model.dispose()
        report.update(status='finished' if len(report['attempts'])==solver.inst.m+1 else 'phase_budget_exhausted',
                      seconds=time.monotonic()-started, final_cost=solver.best['cost'],
                      unique_proposals=len(seen))
        solver.match_history.append(report)
    return report
