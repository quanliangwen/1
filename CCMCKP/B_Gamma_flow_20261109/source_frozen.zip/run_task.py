"""External 600s clock, immutable source/input verification, exclusive outputs.

--operator-only is a functionality study, NOT a full optimization trial. Formal
mode executes the complete original B schedule with the one inserted operator.
No campaign or full-suite expansion is automatically launched by this script.
"""
import argparse,hashlib,json,os,signal,subprocess,sys,time,gzip
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def verify():
    d=json.loads((ROOT/'FREEZE.json').read_text(encoding='utf-8'))
    for name,h in d['files'].items():assert digest(ROOT/name)==h,name
    return digest(ROOT/'FREEZE.json')

def atomic(path,data):
    raw=json.dumps(data,ensure_ascii=False,allow_nan=False,indent=2).encode('utf-8')
    with path.with_suffix(path.suffix+'.tmp').open('xb') as f:
        f.write(raw);f.flush();os.fsync(f.fileno())
    os.replace(str(path.with_suffix(path.suffix+'.tmp')),str(path))
    fd=os.open(str(path.parent),os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)

def child(a):
    signal.signal(signal.SIGALRM,lambda *_:os._exit(124))
    signal.setitimer(signal.ITIMER_REAL,max(.001,a.started+600-time.monotonic()))
    freeze=verify()
    cfg=json.loads((ROOT/'PROTOCOL.json').read_text(encoding='utf-8'))
    cases=json.loads((ROOT/'cases.json').read_text(encoding='utf-8'))
    case=next(x for x in cases if x['index']==a.case)
    instdir=ROOT/'inputs/benchmark'/case['instance']
    allowed={p.resolve() for p in instdir.iterdir() if p.is_file()}
    allowed.update(p.resolve() for p in (ROOT/'sources/GAMMA').glob('*.py'))
    allowed.update((ROOT/n).resolve() for n in ['gamma_operator.py','gamma_math.py','PROTOCOL.json','sources/B/B_CDF_DRO_MITM/solver.py'])
    out=Path(a.out).resolve()
    detail=out.with_name(out.name+'.detail.json')
    own_outputs={out,out.with_name(out.name+'.tmp'),out.parent,detail,detail.with_suffix(detail.suffix+'.tmp')}
    def guard(event,args):
        if event!='open' or not isinstance(args[0],(str,bytes,os.PathLike)):return
        path=Path(os.fsdecode(args[0])).resolve()
        project=ROOT.parent.parent
        if project==path or project in path.parents:
            if path not in allowed and path not in own_outputs:
                raise PermissionError('Unregistered experiment input: '+str(path))
    # Source and input hashing precede data-read audit, but are within total clock.
    inputhash=json.loads((ROOT/'INPUT_SHA.json').read_text(encoding='utf-8'))
    for name,h in inputhash[case['instance']].items():assert digest(instdir/name)==h,name
    sys.addaudithook(guard)
    sys.path.insert(0,str(ROOT/'sources/GAMMA'));sys.path.insert(0,str(ROOT))
    import random,numpy as np,scipy,gurobipy,ast,copy
    from instance import load_instance
    import solver as sm
    seed=a.seed;random.seed(seed);np.random.seed(seed)
    inst=load_instance(instdir)
    s=sm.Solver(inst,case['tmax'],seed,600,out,a.started,'B_CDF_DRO_MITM')
    initial=None;transcript=[]
    # Replay each *actual* original native-wrapper invocation on an independent
    # same-seed object. Only functionality mode does this; its time is charged.
    if a.operator_only:
        other=sm.Solver(inst,case['tmax'],seed,600,out,a.started,'B_CDF_DRO_MITM')
        other.save=lambda *_:None
        tree=ast.parse((ROOT/'sources/B/B_CDF_DRO_MITM/solver.py').read_text(encoding='utf-8'))
        cls=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='Solver')
        method=copy.deepcopy(next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='native_check'))
        env=dict(sm.__dict__);exec(compile(ast.fix_missing_locations(ast.Module(body=[method],type_ignores=[])),'original_B_native_check','exec'),env)
        original=env['native_check'];real=s.native_check
        def statehash(value):
            import pickle
            return hashlib.sha256(pickle.dumps(value,protocol=4)).hexdigest()
        def checked(selection,source,force=False):
            outside=statehash(np.random.get_state())
            got=real(selection,source,force)
            assert statehash(np.random.get_state())==outside
            expected=original(other,selection,source,force)
            assert got==expected and s.native_calls==other.native_calls
            assert statehash(s.native_rng.get_state())==statehash(other.native_rng.get_state())
            assert statehash(np.random.get_state())==outside
            transcript.append(dict(selection=list(selection),force=force,p=got,native_state=statehash(s.native_rng.get_state())))
            return got
        s.native_check=checked
        for _,_,selection in s.propose(s.mu+3*s.sd,float(s.cost.max()*inst.m),theta=0.,pool=8,seconds=3):
            s.native_check(selection,'current_run_V50_original_low_risk_initialization',True)
            if s.best is not None:break
        initial=s.best.copy() if s.best else None
        from gamma_operator import gamma_frontier
        gamma_frontier(s)
        s.save('completed')
    else:
        s.run()
    assert s.best is None or inst.selection_cost(s.best['selection'])==s.best['cost']
    # Source/input checks and this save are all before the external receipt.
    record=dict(scope='operator_functionality_only' if a.operator_only else 'full_candidate_run',
        source_freeze_sha=freeze,case=a.case,seed=seed,initial=initial,selected=s.best,
        gamma=getattr(s,'gamma_report',None),native_transcript_replay_passed=a.operator_only,
        transcript=transcript,native_calls=s.native_calls,stages=len(s.match_history),
        environment=dict(numpy=np.__version__,scipy=scipy.__version__,gurobi=list(gurobipy.gurobi.version())),
        seconds_before_final_save=time.monotonic()-a.started,
        official_avg=None,official_std=None,official_CV=None,
        cost_performance_claim=False)
    atomic(out.with_name(out.name+'.detail.json'),record)

def main(a):
    if a.seed not in range(832273,832303):raise ValueError('Unregistered seed')
    out=Path(a.out).resolve();out.parent.mkdir(parents=True,exist_ok=True)
    with out.with_name(out.name+'.launch.lock').open('x') as f:f.write('Exclusive new run; no implicit restart\n')
    if out.exists():raise FileExistsError(out)
    env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
    log=out.with_name(out.name+'.log').open('x')
    started=time.monotonic()  # Before Popen and every algorithm import/load/hash.
    cmd=[sys.executable,'-B',str(Path(__file__).resolve()),'--child','--case',str(a.case),'--seed',str(a.seed),'--out',str(out),'--started',repr(started)]
    if a.operator_only:cmd.append('--operator-only')
    p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
    reason=None
    try:
        while p.poll() is None:
            if time.monotonic()-started>=600:
                reason='hard600_timeout';os.killpg(p.pid,signal.SIGKILL);break
            available=next(int(l.split()[1])*1024 for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:'))
            if available<5*2**30:
                reason='resource_interrupted';os.killpg(p.pid,signal.SIGKILL);break
            time.sleep(.05)
        p.wait();log.flush();os.fsync(log.fileno());log.close()
    finally:
        if p.poll() is None:os.killpg(p.pid,signal.SIGKILL);p.wait()
    actual=time.monotonic()-started
    detail=out.with_name(out.name+'.detail.json')
    good=p.returncode==0 and detail.exists() and actual<=600
    if good:
        d=json.loads(detail.read_text());good=d['selected'] is not None and d['selected']['probability']>=.99
    atomic(out.with_name(out.name+'.terminal.json'),dict(case=a.case,seed=a.seed,valid=good,
        reason='valid_functionality' if good and a.operator_only else 'valid' if good else reason or 'algorithm_or_functional_failure',
        returncode=p.returncode,actual_elapsed=actual,budget=600,reserve=15,
        final_save_and_fsync_included=True,official_performance_run=not a.operator_only,
        detail_sha=digest(detail) if detail.exists() else None))
    print(json.dumps({'case':a.case,'valid':good,'actual_elapsed':actual,'reason':reason}))
    if not good:raise SystemExit(1)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--case',type=int,required=True);ap.add_argument('--seed',type=int,required=True)
    ap.add_argument('--out',required=True);ap.add_argument('--operator-only',action='store_true');ap.add_argument('--child',action='store_true');ap.add_argument('--started',type=float)
    a=ap.parse_args();child(a) if a.child else main(a)
