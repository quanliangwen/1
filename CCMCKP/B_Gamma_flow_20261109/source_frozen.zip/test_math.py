"""Exhaustive small-case oracle: top-budget, threshold union, compact MILP."""
import argparse,itertools,json,time
from pathlib import Path
import numpy as np
from gamma_math import protection,thresholds,robust_load,threshold_load,validate
ROOT=Path(__file__).resolve().parent


def run(mip=False):
    rng=np.random.default_rng(832273);identities=0;unions=0;models=0
    for trial in range(20):
        groups=[[0,1],[2,3],[4,5]]
        mu=rng.integers(0,5,6).astype(float)
        d=rng.integers(0,6,6).astype(float)
        c=rng.integers(1,20,6).astype(float)
        selections=list(itertools.product(*groups))
        for gamma in [0.,.5,1.,1.5,2.,2.5,3.]:
            validate(mu,d,groups,gamma)
            for s in selections:
                # Independent cardinality oracle at integer budgets.
                if gamma==int(gamma):
                    brute=max(sum(d[s[k]] for k in subset)
                              for count in range(int(gamma)+1)
                              for subset in itertools.combinations(range(3),count))
                    assert abs(brute-protection(d[list(s)],gamma))<1e-10
                a=robust_load(mu,d,s,gamma)
                b=min(threshold_load(mu,d,s,gamma,t) for t in thresholds(d))
                assert abs(a-b)<1e-10,(s,gamma,a,b)
                identities+=1
            for T in [0.,10.,20.,100.]:
                feasible={s for s in selections if robust_load(mu,d,s,gamma)<=T+1e-10}
                union={s for s in selections if any(threshold_load(mu,d,s,gamma,t)<=T+1e-10
                                                  for t in thresholds(d))}
                assert feasible==union
                expected=min((float(c[list(s)].sum()) for s in feasible),default=None)
                if mip:
                    import gurobipy as gp
                    model=gp.Model();model.Params.OutputFlag=0;model.Params.Threads=1
                    x=model.addMVar(6,vtype=gp.GRB.BINARY)
                    theta=model.addVar(lb=0.,ub=float(d.max()))
                    q=model.addMVar(6,lb=0.)
                    for g in groups:model.addConstr(x[g].sum()==1)
                    model.addConstr(q+theta>=d*x)
                    model.addConstr(mu@x+gamma*theta+q.sum()<=T)
                    model.setObjective(c@x);model.optimize()
                    actual=float(model.ObjVal) if model.SolCount else None
                    assert expected==actual,(trial,gamma,T,expected,actual)
                    model.dispose();models+=1
                unions+=1
    # Selected endpoints, tied/zero deviations, negative input and invalid budget.
    assert protection([0.,0.],2)==0
    for args in [([1.],[-1.],[[0]],0.),([1.],[0.],[[0]],2.),([1.],[0.],[[0],[0]],0.)]:
        try:validate(*args)
        except ValueError:pass
        else:raise AssertionError('invalid data accepted')
    return dict(passed=True,top_budget_threshold_identities=identities,
                exact_feasible_union_checks=unions,compact_MILP_exhaustive_checks=models,
                strict_capacity_note='auxiliary tests use <=; formal proposal subtracts 1e-8; native strict sum<T unchanged',
                numpy=np.__version__)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--mip',action='store_true');a=ap.parse_args()
    d=run(a.mip);p=ROOT/('MATH_TARGET.json' if a.mip else 'MATH_LOCAL.json')
    with p.open('x',encoding='utf-8') as f:json.dump(d,f,indent=2)
    print(json.dumps(d))
