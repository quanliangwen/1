"""Budgeted upper-load identities. These are not probability certificates."""
import math
import numpy as np


def validate(mu, deviation, groups, gamma):
    mu = np.asarray(mu, dtype=float)
    deviation = np.asarray(deviation, dtype=float)
    flat = [int(j) for group in groups for j in group]
    if mu.ndim != 1 or deviation.shape != mu.shape or not np.all(np.isfinite(mu)) or not np.all(np.isfinite(deviation)):
        raise ValueError('Finite equal-length one-dimensional coefficient arrays required')
    if np.any(mu < 0) or np.any(deviation < 0) or any(not len(g) for g in groups):
        raise ValueError('Nonnegative coefficients and nonempty groups required')
    if len(set(flat)) != len(flat) or set(flat) != set(range(len(mu))):
        raise ValueError('Groups must partition all items exactly')
    if not math.isfinite(gamma) or not 0 <= gamma <= len(groups):
        raise ValueError('Gamma outside [0, number of selected groups]')
    return mu, deviation


def protection(selected_deviations, gamma):
    d = np.sort(np.asarray(selected_deviations, dtype=float))[::-1]
    if d.ndim != 1 or not np.all(np.isfinite(d)) or np.any(d < 0) or not 0 <= gamma <= len(d):
        raise ValueError('Invalid budget or deviations')
    k = int(math.floor(gamma))
    return float(d[:k].sum() + ((gamma-k)*d[k] if k < len(d) else 0.))


def thresholds(deviation):
    d = np.asarray(deviation, dtype=float)
    if d.ndim != 1 or not np.all(np.isfinite(d)) or np.any(d < 0):
        raise ValueError('Invalid deviations')
    return np.unique(np.r_[0., d])


def threshold_load(mu, deviation, selection, gamma, theta):
    ids = list(selection)
    return float(gamma*theta + (mu[ids] + np.maximum(deviation[ids]-theta, 0.)).sum())


def robust_load(mu, deviation, selection, gamma):
    ids = list(selection)
    return float(mu[ids].sum() + protection(deviation[ids], gamma))
