from pathlib import Path
import json,shutil
R=Path(__file__).resolve().parent;D=R/'delivery';S=json.loads((R/'statistics.json').read_text(encoding='utf-8'));m=S['metrics']
fmt=lambda x,n=9:'—' if x is None else f'{x:.{n}f}'
lines=['# B2 BE-RO-LB 全40例1200次最终测试总结','',
'B2已于北京时间2026年11月28日14:24:27自然完成，独立审核于14:34:52完成。1200次全部终末，1023次独立有效、177次未得到最终LSS接受输出；global_errors=[]。服务器未发现该批控制器、worker或审核器残留。', '',
'## 结论','',
f'B2在与B1均完整的33例上，平均成本10优、22平、1劣，等权相对均值差为{m["B2_vs_B1_equal_weight_relative_avg_change"]:.4%}。但同33例的完整平均耗时由B1的{m["B1_whole_mean_closed_cases"]:.3f}秒增加到B2的{m["B2_vs_B1_whole_mean_closed_cases"]:.3f}秒。B2仍依赖原B1起点，未解决大算例首阶段经常没有认证候选的问题，不能视为全量稳定改进版。', '',
'B1与B2使用不同的新鲜seed，以上是历史描述对照，未做同seed配对显著性推断，也未将缺30次有效的组纳入总体均值胜负。B2的188次有效运行最终成本低于同run首阶段内部CDF最好成本；这是阶段内的成本变化，不能替代首阶段单独最终LSS验收后的公平对照。', '',
'## 实验口径','',
'40例×30次；seed1282001—1282030；峰值60并行。每次自原始数据重新构造B1盒-椭球鲁棒候选，再在同run内做最多5组变化的局部支化；不读历史解，不跨重复输入。Stage 1与原B1字节一致。局部支化候选不强加原BE半径约束，所以不能继承该半径的鲁棒见证；仍经统一原CDF和原LSS≥0.99验收。', '',
f'所有1200次（包括失败）的完整耗时均值为{m["whole_mean_all1200_seconds"]:.6f}秒，最长{m["whole_max_seconds"]:.6f}秒，均未超过600秒。批次历时{m["batch_elapsed_seconds"]:.3f}秒，包含首40次技术审核等待，不是单run求解时间。资源保护事件0，原CDF 90秒硬超时0。', '',
'## 指标定义','',
'Best是有效运行输出中观测到的最低成本，不宣称全局最优。Avg和样本Std(ddof=1)仅在30/30独立有效时给出；不足30次保持空缺，另在Excel单列有效子集诊断。失败不赋虚假成本。', '',
'“首次达Best均时”只对最终成本等于本例本批Best的运行取平均，取其最终输出解在本run首次通过内部CDF认证的时刻（从进程启动计），且随后通过最终LSS；同时给出命中次数。不是将所有30次各自最好解的时间混合平均，也不是完整运行耗时。', '',
'## 全40例统计','',
'|编号|算例|T|有效|Best|Avg|样本Std|命中Best次数|首次达Best均时(s)|完整均时(s)|完整最长(s)|',
'|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
for g in S['groups']:
 lines.append(f'|{g["case_index"]}|{g["instance_label"]}|{g["capacity"]:g}|{g["valid"]}/30|{fmt(g["best_valid"])}|{fmt(g["official_avg"])}|{fmt(g["official_sample_std"])}|{g["best_hit_count"]}|{fmt(g["official_best_hit_first_mean_seconds"],6)}|{fmt(g["whole_mean_all30_seconds"],6)}|{fmt(g["whole_max_all30_seconds"],6)}|')
lines+=['','33例拥有完整30次有效结果。编号19有效28/30，编号35有效5/30；编号36—40为0/30。部分有效组的观测Best只作诊断，不据此填补官方Avg/Std。', '',
'## 177次失败的结构','',
'- 163次：首阶段临界MISOCP解池未返回任何解，无法启动依赖认证起点的LB。',
'- 13次：首阶段虽有模型候选，但没有内部CDF接受候选，LB同样未获得合格起点。',
'- 1次：首阶段有内部认证池，但最终LSS未输出接受解。', '',
'原始报错“No completed LSS-accepted candidate before the wall deadline”并不表示每次用满600秒。这里按阶段记录区分失败原因；无资源保护和90秒CDF硬超时，不能归因于资源不足。失败身份全部保留，未重跑挑seed。', '',
'## 与B1的完整组描述对照','',
'|编号|B1 Avg|B2 Avg|B2成本变化|B1完整均时(s)|B2完整均时(s)|',
'|---:|---:|---:|---:|---:|---:|']
for c in S['historical_comparison']:
 lines.append(f'|{c["case_index"]}|{c["B1_avg"]:.9f}|{c["B2_avg"]:.9f}|{c["mean_cost_sign"]} ({c["relative_mean_cost_change"]:+.4%})|{c["B1_whole_mean"]:.3f}|{c["B2_whole_mean"]:.3f}|')
lines+=['','## 后续B1-v2的验证重点','',
'按用户新指示，先编译新线性λ-Huber版本，再按设计做tiny与7例×5次冒烟。主要核验：能否消除弱锥模型首解瓶颈、二分候选保留能否减少退化、兜底是否产生最终LSS接受解。有限λ网格是保守候选生成器，不冒称完整BE等价最优求解。只有冒烟门槛通过才开始新的40×30、最多60并行离线测试，不修改B2结果。', '',
'## 审计与证据','',
f'- 独立审核：{m["files_sha_checked"]}个输出文件SHA、{m["KKT_witnesses_checked"]}个KKT见证、{m["native_integer_certificates_checked"]}个原整数CDF证书，global_errors=[]。没有重新概率抽样。',
f'- 协议SHA256：`{m["protocol_sha256"]}`。',f'- 最终审计SHA256：`{m["audit_sha256"]}`。',
'- Excel含40例汇总和1200次明细，公式已重算并与独立统计逐格核对。紧凑统计、诊断与输出SHA清单随附；逐run原记录继续保留服务器原目录。',
'- B1历史报告来源：GitHub quanliangwen/1，CCMCKP/BE_RO_B1_20261128_FULL40_RESULTS，提交ef1b8ab1ecdefff3d550a189af961520c1126b12。']
(D/'B2_BE_RO_LB_全40例1200次_最终测试总结.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
for n in ['FINAL_INDEPENDENT_AUDIT.json','PROTOCOL.json','COLLECTION_RECEIPT.json','DIAGNOSTICS.json','OUTCOMES_ALL.json','ALL_OUTPUT_SHA256.json','COMPLETED.json']:
 shutil.copy2(R/'evidence'/n,D/n)
shutil.copy2(R/'B2_统计与诊断证据.tar.gz',D/'B2_统计与诊断证据.tar.gz')
print('B2 report generated')
