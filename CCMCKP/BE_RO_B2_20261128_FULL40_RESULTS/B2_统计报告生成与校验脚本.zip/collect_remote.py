from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import json,hashlib,tarfile
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b2_20261128';F=H/'full40';X=H/'report_exports_20261128'
assert Path.cwd()==B
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
C=read(F/'COMPLETED.json');A=read(F/'FINAL_INDEPENDENT_AUDIT.json');P=read(F/'PROTOCOL.json')
assert C['phase']=='completed' and C['terminal']==A['terminal']==1200 and C['pending']==0 and not A['global_errors']
assert read(F/'FINAL_AUDIT_PROCESS.json')['rc']==0 and sha(F/'PROTOCOL.json')=='441b94dacb03315d9aaa7f975247b5fb9b3893d5a2ac4848e9cda2b12090d84c'
for n,h in P['source_and_binary_pins'].items():assert sha(F/n)==h,n
outs=sorted((read(p) for p in (F/'outcomes').glob('*.json')),key=lambda o:(o['case_index'],o['rep']))
assert len(outs)==1200 and len({o['identity'] for o in outs})==1200
diag=[];checks={};bytes_checked=0
for o in outs:
 root=F/'runs'/o['identity']
 for n,h in o['output_files'].items():
  p=root/n;assert p.stat().st_size==h['bytes'] and sha(p)==h['sha256'],(o['identity'],n)
  checks[p.relative_to(F).as_posix()]=h;bytes_checked+=h['bytes']
 raw=read(root/'S10_search.json') if (root/'S10_search.json').exists() else None
 stage1=read(root/'BE_RO_STAGE1.json') if (root/'BE_RO_STAGE1.json').exists() else None
 m=stage1.get('BE_RO_model',{}) if stage1 else {};lb=raw.get('BE_RO_LB_model',{}) if raw else {}
 ns=m.get('native_calls',[])+lb.get('native_calls',[]);qs=m.get('queries',[])
 failure=read(root/'FAILED.json') if (root/'FAILED.json').exists() else None
 stage1_pool=m.get('certified_pool',[])
 diag.append({'identity':o['identity'],'case_index':o['case_index'],'rep':o['rep'],'seed':o['seed'],'rc':o['rc'],
 'whole_seconds':o['process_wall_seconds'],'termination_reason':o['termination_reason'],'failure':failure,
 'stage1_pool_count':len(stage1_pool),'stage1_best':min((q['cost'] for q in stage1_pool),default=None),
 'stage1_candidates':len(m.get('candidates',[])),'stage1_calibration_queries':len(m.get('calibration',[])),
 'stage1_candidate_decisions':dict(Counter(q['decision'] for q in m.get('candidates',[]))),
 'stage1_native_states':dict(Counter(q['state'] for q in m.get('native_calls',[]))),
 'critical_pool_queries':sum(q['phase']=='critical_pool' for q in qs),
 'critical_pool_total_solutions':sum(q['solutions_retained'] for q in qs if q['phase']=='critical_pool'),
 'critical_pool_statuses':[q['solver_status'] for q in qs if q['phase']=='critical_pool'],
 'native_timeouts':sum(q['hard_timeout'] for q in ns),'LB_rounds':len(lb.get('rounds',[])),
 'LB_native_states':dict(Counter(q['state'] for q in lb.get('native_calls',[]))),
 'LB_stop_reason':lb.get('stop_reason')})
X.mkdir(exist_ok=True)
def immutable(name,obj):
 data=json.dumps(obj,ensure_ascii=False,indent=2).encode()
 p=X/name
 if p.exists():assert p.read_bytes()==data,'Existing export differs'
 else:p.write_bytes(data)
immutable('DIAGNOSTICS.json',diag);immutable('OUTCOMES_ALL.json',outs);immutable('ALL_OUTPUT_SHA256.json',checks)
files={}
for n in ['PROTOCOL.json','FINAL_INDEPENDENT_AUDIT.json','COMPLETED.json','STATE.json','FROZEN.json','LAUNCH.json','PILOT_CONTINUATION_DECISION.json','FINAL_AUDIT_PROCESS.json','DIAGNOSTICS.json','OUTCOMES_ALL.json','ALL_OUTPUT_SHA256.json']:
 p=X/n if (X/n).exists() else F/n;files[n]={'sha256':sha(p),'bytes':p.stat().st_size}
receipt={'status':'PASS','terminal':1200,'independent_valid':A['independent_valid'],'global_errors':[],
 'all_terminal_output_sha_checked':len(checks),'output_bytes':bytes_checked,'original_audit_sha256':sha(F/'FINAL_INDEPENDENT_AUDIT.json'),
 'protocol_sha256':sha(F/'PROTOCOL.json'),'files':files}
immutable('COLLECTION_RECEIPT.json',receipt)
small=X/'B2_统计与诊断证据.tar.gz'
if not small.exists():
 with tarfile.open(small,'w:gz') as tar:
  for n in files:tar.add(X/n if (X/n).exists() else F/n,arcname=n)
  tar.add(X/'COLLECTION_RECEIPT.json',arcname='COLLECTION_RECEIPT.json')
result={'status':'PASS','small_archive':str(small),'small_bytes':small.stat().st_size,'small_sha256':sha(small),
 'audit_sha256':receipt['original_audit_sha256'],'outputs_sha_checked':len(checks),'raw_records_retained_at':str(F/'runs')}
immutable('EXPORT.json',result);print(json.dumps(result,ensure_ascii=False))
