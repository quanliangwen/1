from pathlib import Path
from collections import Counter
import json
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');F=B/'work/be_ro_b2_20261128/full40'
assert Path.cwd()==B
read=lambda p:json.loads(p.read_text())
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  argv=[x.decode(errors='replace') for x in (p/'cmdline').read_bytes().split(b'\0') if x]
  if any(str(F) in x and any(k in x for k in ['controller.py','audit_reader.py','ccmckp_s10']) for x in argv):active.append({'pid':int(p.name),'argv':argv})
 except OSError:pass
metadata={n:read(F/n) for n in ['STATE.json','COMPLETED.json','FINAL_AUDIT_PROCESS.json','CONTROLLER_ERROR.json'] if (F/n).exists()}
outcomes=[read(p) for p in (F/'outcomes').glob('*.json')]
audit=read(F/'FINAL_INDEPENDENT_AUDIT.json') if (F/'FINAL_INDEPENDENT_AUDIT.json').exists() else None
print(json.dumps({'active':active,'metadata':metadata,'terminal_files':len(outcomes),'rc_counts':dict(Counter(x['rc'] for x in outcomes)),'termination_reasons':dict(Counter(str(x['termination_reason']) for x in outcomes)),'whole_max_seconds':max((x['process_wall_seconds'] for x in outcomes),default=None),'audit':{k:audit[k] for k in ['terminal','independent_valid','global_errors','files_sha_checked','KKT_witnesses_checked','native_integer_certificates_checked']} if audit else None,'group_valid_counts':[{k:g[k] for k in ['case_index','valid','official_avg','official_std','best_hit_count','best_hit_first_mean_seconds']} for g in audit['groups']] if audit else None}))
