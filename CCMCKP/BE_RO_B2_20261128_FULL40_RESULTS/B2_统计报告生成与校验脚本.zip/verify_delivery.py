from pathlib import Path
import json,hashlib,statistics,zipfile,xml.etree.ElementTree as ET,tarfile,csv
R=Path(__file__).resolve().parent;D=R/'delivery';E=R/'evidence'
read=lambda p:json.loads(p.read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
S=read(R/'statistics.json');m=S['metrics'];groups=S['groups'];rows=S['rows']
assert len(rows)==1200 and len(groups)==40 and len({x['identity'] for x in rows})==1200 and sum(x['valid'] for x in rows)==1023
ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(D/'B2_全40算例_1200次_结果汇总.xlsx') as z:
 assert z.testzip() is None
 ss=ET.fromstring(z.read('xl/sharedStrings.xml'));strings=[''.join(t.text or '' for t in s.findall('.//m:t',ns)) for s in ss]
 def cells(name):return {c.attrib['r']:c for c in ET.fromstring(z.read(name)).findall('.//m:sheetData/m:row/m:c',ns)}
 def get(c):
  if c.attrib.get('t')=='s':return strings[int(c.find('m:v',ns).text)]
  if c.attrib.get('t')=='inlineStr':return ''.join(t.text or '' for t in c.findall('.//m:t',ns))
  if c.attrib.get('t')=='str':return c.find('m:v',ns).text
  return float(c.find('m:v',ns).text)
 s=cells('xl/worksheets/sheet1.xml');d=cells('xl/worksheets/sheet2.xml');delta=0
 for i,g in enumerate(groups,8):
  rr=[r for r in rows if r['case_index']==g['case_index']];vv=[r for r in rr if r['valid']]
  assert len(rr)==30 and len(vv)==g['valid']
  expected=[g['valid'],g['best_valid'],g['official_avg'],g['official_sample_std'],g['best_hit_count'] if g['valid'] else None,g['official_best_hit_first_mean_seconds'],g['whole_mean_all30_seconds'],g['whole_max_all30_seconds'],g['valid_only_avg'],g['valid_only_sample_std'],g['valid_only_best_hit_first_mean_seconds']]
  for col,want in zip('DEFGHIJKLMN',expected):
   c=s[f'{col}{i}'];assert c.find('m:f',ns) is not None
   if want is None:assert get(c)=='n.a.'
   else:assert abs(get(c)-want)<1e-8;delta=max(delta,abs(get(c)-want))
  if len(vv)==30:
   assert g['official_avg']==statistics.mean(r['cost'] for r in vv) and g['official_sample_std']==statistics.stdev(r['cost'] for r in vv)
   hits=[r for r in vv if r['cost']==g['best_valid']]
   assert len(hits)==g['best_hit_count'] and statistics.mean(r['first_found_seconds'] for r in hits)==g['official_best_hit_first_mean_seconds']
  else:assert g['official_avg'] is g['official_sample_std'] is g['official_best_hit_first_mean_seconds'] is None
 for i,r in enumerate(rows,8):
  for col,want in [('A',r['case_index']),('C',r['capacity']),('D',r['rep']),('E',r['seed']),('F',r['valid']),('G',r['cost']),('H',r['first_found_seconds']),('I',r['whole_seconds']),('J',r['LSS'])]:
   c=d.get(f'{col}{i}')
   if want is None:assert c is None or c.find('m:v',ns) is None
   else:assert abs(get(c)-want)<1e-10
 assert all(c.attrib.get('t')!='e' for sh in [s,d] for c in sh.values())
md=(D/'B2_BE_RO_LB_全40例1200次_最终测试总结.md').read_text(encoding='utf-8')
for g in groups:
 fmt=lambda x,n=9:'—' if x is None else f'{x:.{n}f}'
 assert f'|{g["case_index"]}|{g["instance_label"]}|{g["capacity"]:g}|{g["valid"]}/30|{fmt(g["best_valid"])}|{fmt(g["official_avg"])}|{fmt(g["official_sample_std"])}|{g["best_hit_count"]}|{fmt(g["official_best_hit_first_mean_seconds"],6)}|' in md
receipt=read(E/'COLLECTION_RECEIPT.json')
for n,q in receipt['files'].items():assert sha(E/n)==q['sha256']
assert sha(D/'B2_统计与诊断证据.tar.gz')==read(R/'EXPORT.json')['small_sha256']
with zipfile.ZipFile(D/'B2_统计报告生成与校验脚本.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in ['prepare_statistics.py','build_report.py','build_excel.mjs','collect_remote.py','download.py','verify_delivery.py','inspect_remote.py']:z.write(R/n,n)
qa={'status':'PASS','stage':'FORMAL_COMPLETE','all_files_sha_verified':True,'terminal':1200,'independent_valid':1023,'failed':177,'full30_cases':33,
 'saved_xlsx_formula_results_verified':440,'all_detail_cells_verified':True,'failed_costs_blank':True,'conditional_first_Best_times_verified':True,
 'max_xlsx_difference':delta,'visual_review':True,'global_errors':[],'probability_resampling':False}
(D/'DELIVERY_QA.json').write_text(json.dumps(qa,indent=2),encoding='utf-8');(R/'DELIVERY_LOCAL_VERIFIED.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
checks={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in D.iterdir() if p.is_file() and p.name!='CHECKSUMS_SHA256.json' and not p.name.endswith('.ndjson')}
(D/'CHECKSUMS_SHA256.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
pub=(R.parent/'publish_results.py').read_text(encoding='utf-8').replace("FOLDER='BE_RO_B2_20261128_OFFLINE_TEST'","FOLDER='BE_RO_B2_20261128_FULL40_RESULTS'").replace('Publish frozen BE-RO-LB B2 source, independent pretests and all40 offline launch','Publish B2 final40 results with 1023 valid runs, Excel and Chinese report')
(R/'publish_results.py').write_text(pub,encoding='utf-8');print(json.dumps(qa))
