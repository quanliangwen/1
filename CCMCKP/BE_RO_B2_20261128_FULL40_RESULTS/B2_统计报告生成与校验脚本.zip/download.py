from pathlib import Path
import subprocess,json,hashlib,sys,tarfile
R=Path(__file__).resolve().parent;E=R/'evidence';E.mkdir(exist_ok=True)
root='/home/junhao/quan/parallel_test_solver/CCMKCP/work/be_ro_b2_20261128/report_exports_20261128'
if not (R/'EXPORT.json').exists():
 p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60','cat '+root+'/EXPORT.json'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
 assert p.returncode==0,p.stderr.decode(errors='replace');json.loads(p.stdout);(R/'EXPORT.json').write_bytes(p.stdout)
m=json.loads((R/'EXPORT.json').read_text(encoding='utf-8'))
prefix='full' if '--full' in sys.argv else 'small';remote=m[prefix+'_archive'];target=R/Path(remote).name
if not target.exists():
 p=subprocess.run(['scp','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60:'+remote,str(target)],capture_output=True,timeout=300)
 assert p.returncode==0,p.stderr.decode(errors='replace')
assert target.stat().st_size==m[prefix+'_bytes'] and hashlib.sha256(target.read_bytes()).hexdigest()==m[prefix+'_sha256']
if prefix=='small':
 with tarfile.open(target) as t:
  for member in t.getmembers():
   out=(E/member.name).resolve();assert E.resolve() in out.parents and member.isfile();out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(t.extractfile(member).read())
 receipt=json.loads((E/'COLLECTION_RECEIPT.json').read_text(encoding='utf-8'))
 for n,h in receipt['files'].items():assert hashlib.sha256((E/n).read_bytes()).hexdigest()==h['sha256'] and (E/n).stat().st_size==h['bytes']
print(json.dumps({'status':'PASS','kind':prefix,'bytes':target.stat().st_size,'sha256':m[prefix+'_sha256']},ensure_ascii=False))
