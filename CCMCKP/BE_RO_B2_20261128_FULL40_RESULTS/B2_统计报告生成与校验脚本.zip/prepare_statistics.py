from pathlib import Path
from collections import Counter
import json,statistics,csv,hashlib,math
R=Path(__file__).resolve().parent;E=R/'evidence';D=R/'delivery';D.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
A=read(E/'FINAL_INDEPENDENT_AUDIT.json');P=read(E/'PROTOCOL.json');C=read(E/'COMPLETED.json');G=read(E/'DIAGNOSTICS.json');O=read(E/'OUTCOMES_ALL.json')
assert A['terminal']==1200 and not A['global_errors'] and C['pending']==0
rows=[];groups=[]
for c in P['cases']:
 part=[]
 for a in sorted((x for x in A['rows'] if x['case_index']==c['index']),key=lambda x:x['rep']):
  d=next(x for x in G if x['identity']==a['identity']);valid=a['valid'];stage='';message=''
  if not valid:
   if a['termination_reason']:stage='resource_or_wall_guard'
   elif not d['stage1_pool_count']:
    stage='stage1_zero_MISOCP_pool' if not d['critical_pool_total_solutions'] else 'stage1_no_CDF_accepted_candidate'
   else:stage='final_LSS_rejected_or_no_output'
   message=(d.get('failure') or {}).get('error',';'.join(a['errors']))
  x={'identity':a['identity'],'case_index':c['index'],'instance_label':c['instance'].rstrip('_'),'capacity':c['tmax'],'rep':a['rep'],'seed':a['seed'],
     'valid':int(valid),'cost':a.get('cost') if valid else None,'first_found_seconds':a.get('first_found_seconds') if valid else None,
     'whole_seconds':a['process_wall_seconds'],'LSS':a.get('LSS') if valid else None,'failure_stage':stage,'failure_message':message,
     'stage1_best':d['stage1_best'],'LB_rounds':d['LB_rounds'],'native_timeouts':d['native_timeouts']}
  rows.append(x);part.append(x)
 vv=[x for x in part if x['valid']];cost=[x['cost'] for x in vv];tt=[x['whole_seconds'] for x in part];best=min(cost) if cost else None;hit=[x for x in vv if x['cost']==best]
 full=len(vv)==30;avg=statistics.mean(cost) if cost else None;std=statistics.stdev(cost) if len(cost)>1 else None;hitmean=statistics.mean(x['first_found_seconds'] for x in hit) if hit else None
 g={'case_index':c['index'],'instance_label':c['instance'].rstrip('_'),'capacity':c['tmax'],'terminal':len(part),'valid':len(vv),'failed':30-len(vv),
    'best_valid':best,'official_avg':avg if full else None,'official_sample_std':std if full else None,'best_hit_count':len(hit),
    'official_best_hit_first_mean_seconds':hitmean if full else None,'whole_mean_all30_seconds':statistics.mean(tt),'whole_max_all30_seconds':max(tt),
    'valid_only_avg':avg if not full else None,'valid_only_sample_std':std if not full else None,'valid_only_best_hit_first_mean_seconds':hitmean if not full else None}
 q=next(x for x in A['groups'] if x['case_index']==c['index']);assert q['valid']==g['valid'] and q['official_avg']==g['official_avg']
 if full:assert math.isclose(q['official_std'],std,abs_tol=1e-12) and q['best_hit_first_mean_seconds']==hitmean
 groups.append(g)
B1=read(Path('E:/codex/CCMCKP_BE_RO_B1_20261128/report_full40_20261128/statistics.json'))
comparisons=[]
for g in groups:
 b=next(x for x in B1['groups'] if x['case_index']==g['case_index'])
 if g['valid']!=30 or b['valid']!=30:continue
 delta=g['official_avg']-b['official_avg']
 comparisons.append({'case_index':g['case_index'],'instance_label':g['instance_label'],'capacity':g['capacity'],
 'B1_avg':b['official_avg'],'B2_avg':g['official_avg'],'B1_std':b['official_sample_std'],'B2_std':g['official_sample_std'],
 'B1_whole_mean':b['whole_mean_all30_seconds'],'B2_whole_mean':g['whole_mean_all30_seconds'],
 'relative_mean_cost_change':delta/b['official_avg'],'mean_cost_sign':'优' if delta<0 else '劣' if delta>0 else '平'})
failed=[x for x in rows if not x['valid']]
metrics={'terminal':len(rows),'independent_valid':sum(x['valid'] for x in rows),'failed':len(failed),'full30_cases':sum(g['valid']==30 for g in groups),
 'partial_cases':[g['case_index'] for g in groups if 0<g['valid']<30],'zero_valid_cases':[g['case_index'] for g in groups if not g['valid']],
 'whole_mean_all1200_seconds':statistics.mean(x['whole_seconds'] for x in rows),'whole_max_seconds':max(x['whole_seconds'] for x in rows),
 'failure_stages':dict(Counter(x['failure_stage'] for x in failed)),'resource_events':C['resource_events'],'max_active_observed':C['max_active_observed'],
 'batch_elapsed_seconds':C['elapsed_seconds'],'completed_utc':C['utc'],'audit_utc':A['utc'],'global_errors':A['global_errors'],
 'files_sha_checked':A['files_sha_checked'],'KKT_witnesses_checked':A['KKT_witnesses_checked'],'native_integer_certificates_checked':A['native_integer_certificates_checked'],
 'audit_sha256':sha(E/'FINAL_INDEPENDENT_AUDIT.json'),'protocol_sha256':sha(E/'PROTOCOL.json'),
 'B2_vs_B1_closed_cases':len(comparisons),'B2_vs_B1_avg_sign':dict(Counter(x['mean_cost_sign'] for x in comparisons)),
 'B2_vs_B1_equal_weight_relative_avg_change':statistics.mean(x['relative_mean_cost_change'] for x in comparisons),
 'B2_vs_B1_whole_mean_closed_cases':statistics.mean(x['B2_whole_mean'] for x in comparisons),
 'B1_whole_mean_closed_cases':statistics.mean(x['B1_whole_mean'] for x in comparisons),
 'within_run_final_better_than_stage1':sum(x['valid'] and x['stage1_best'] is not None and x['cost']<x['stage1_best']-1e-8 for x in rows),
 'native_timeouts':sum(x['native_timeouts'] for x in rows),'probability_resampling':False}
S={'metrics':metrics,'groups':groups,'rows':rows,'historical_comparison':comparisons}
(R/'statistics.json').write_text(json.dumps(S,ensure_ascii=False,indent=2),encoding='utf-8')
(D/'B2_40例统计与1200次明细.json').write_text(json.dumps(S,ensure_ascii=False,indent=2),encoding='utf-8')
for name,data in [('B2_40例统计.csv',groups),('B2_1200次明细.csv',rows),('B2与B1_完整组历史描述对照.csv',comparisons)]:
 with (D/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
print(json.dumps(metrics,ensure_ascii=False))
