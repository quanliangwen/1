"""Frozen retrospective first-CF-quantile diagnostic, never an optimizer/native evaluator."""
from pathlib import Path
import json,zipfile,gzip,math,hashlib,ast,time
import numpy as np
R=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def inv_cf(z,gamma):
 a=gamma/6.;y=z+a;disc=1+4*a*y
 if disc<=0:return None
 u=z if abs(a)<1e-14 else 2*y/(1+math.sqrt(disc))
 assert abs(u+a*(u*u-1)-z)<=1e-10
 return .5*math.erfc(-u/math.sqrt(2))

def main():
 f=json.loads((R/'CF_DIAGNOSTIC_FREEZE.json').read_text(encoding='utf8'))
 for n,h in f['files'].items():assert sha(n)==h,n
 gau=json.loads((R/'GAUSSIAN_ASSUMPTION_DIAGNOSIS.json').read_text(encoding='utf8'));protocol=json.loads(Path(f['protocol']).read_text(encoding='utf8'));source=Path(f['baseline_solver']);t=ast.parse(source.read_text(encoding='utf8'));ns={'np':np};nodes=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name in ['worst_cdf_hist','truncated_convolution']];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source)+'<originalCDFonly>','exec'),ns);result=[];begin=time.monotonic()
 with zipfile.ZipFile(f['records_zip']) as zr,zipfile.ZipFile(f['inputs_zip']) as zi:
  for base in gau['rows']:
   idx=base['summary']['index'];case=next(c for c in protocol['cases'] if c['index']==idx);samples=[np.asarray(np.loadtxt(__import__('io').BytesIO(zi.read('benchmark/'+case['instance']+'/'+str(j)+'_sample.txt')))).reshape(-1)[:-1] for j in range(case['n'])];hist=np.asarray([ns['worst_cdf_hist'](a,case['tmax'],4096,.00025) for a in samples]);moments={x['selection_sha']:x for x in base['diagnostic_points']};seen={}
   for rep in range(1,31):
    d=json.loads(gzip.decompress(zr.read('reused_B/reference_c%02d_a01/r%02d.json.gz'%(idx,rep))))
    for o in d['native_observations']:
     ids=tuple(o['selection']);h=hashlib.sha256(json.dumps(ids).encode()).hexdigest();seen[h]=ids
   rows=[]
   for h,ids in seen.items():
    x=moments[h];p=inv_cf(x['nominal_z'],x['nominal_sum_skew']);rp=inv_cf(x['rounded_robust_z'],x['rounded_robust_sum_skew']);pdf=np.r_[1.,np.zeros(4095)]
    for j in ids:pdf=ns['truncated_convolution'](pdf,hist[j],4096)
    original=float(np.clip(pdf.sum(),0,1));ob=x['recorded_positive_mean'];rows.append(dict(selection_sha=h,cost=x['cost'],nominal_CF_prediction=p,recorded_native_positive_mean=ob,nominal_CF_error=p-ob if p is not None and ob is not None else None,rounded_same_delta_CF_prediction=rp,original_same_delta_fullCDF=original,robust_CF_error=rp-original if rp is not None else None))
   a=np.asarray([abs(x['nominal_CF_error']) for x in rows if x['nominal_CF_error'] is not None]);b=np.asarray([abs(x['robust_CF_error']) for x in rows if x['robust_CF_error'] is not None]);undefined=sum(x['nominal_CF_prediction'] is None or x['rounded_same_delta_CF_prediction'] is None for x in rows);summary=dict(index=idx,unique_points=len(rows),undefined_inverse=undefined,nominal_CF_MAE=float(a.mean()),nominal_CF_abs_p90=float(np.quantile(a,.9)),robust_CF_to_original_score_MAE=float(b.mean()),robust_CF_to_original_score_abs_p90=float(np.quantile(b,.9)),gate=bool(undefined==0 and a.mean()<=.001 and np.quantile(a,.9)<=.0025 and b.mean()<=.001 and np.quantile(b,.9)<=.0025));result.append(dict(summary=summary,rows=rows));print(json.dumps(summary),flush=True)
 out=R/'CF_ASSUMPTION_DIAGNOSIS.json';assert not out.exists();out.write_text(json.dumps({'scope':'Exploratory retrospective diagnostic only, same oldBselectedpoints. No new native draws/optimizer/formalruns; original worstCDF/truncatedconvolution functions reused without modification. Numeric diagnostic inlocalNumPy, not substitute formalserverevaluator. No fullvector/learnedweights output to futureworker.','formula':'Own stable inversion of first-order CF quantile z+a(z^2-1), a=skew/6, using positive-derivative branch. This is not identical to a higher-order Cornish-Fisher normalizing expansion, and has no uniform non-Gaussian/lattice error guarantee.','paper':'Fisher&Cornish1960 SectionII Eq1–2 and SectionIII firstadjustment c*(x^2-1)/6, originalfullpaperread; assumptionsrequireasymptoticcumulantorders; finiteL499 skew.9 not a proof these hold. Native/CDF acceptance remainsoriginal.','freeze_sha':sha(R/'CF_DIAGNOSTIC_FREEZE.json'),'elapsed':time.monotonic()-begin,'results':result,'all_diagnostic_gates_passed':all(x['summary']['gate'] for x in result)},ensure_ascii=False,indent=2),encoding='utf8')
if __name__=='__main__':main()
