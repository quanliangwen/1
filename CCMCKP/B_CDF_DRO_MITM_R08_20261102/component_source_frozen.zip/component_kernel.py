"""R08 computational precheck only: no Solver initialization, no optimizer, no native oracle."""
import os
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,ast,hashlib,json,time,types,resource,cProfile,pstats,io,pickle
from pathlib import Path
import numpy as np
from scipy.fft import irfft as packed_irfft,next_fast_len
ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def check():
 d=json.loads((ROOT/'COMPONENT_FREEZE.json').read_text())
 for n,h in d['files'].items():assert sha(ROOT/n)==h,('componentfreezechanged',n)
 return sha(ROOT/'COMPONENT_FREEZE.json')
def functions(arm):
 p=ROOT/'sources'/('kernel_control' if arm=='control' else 'R08')/'solver.py';t=ast.parse(p.read_text());cl=next(n for n in t.body if isinstance(n,ast.ClassDef) and n.name=='Solver');mods=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name in ('worst_cdf_hist','truncated_convolution')];methods=[n for n in cl.body if isinstance(n,ast.FunctionDef) and n.name in ('build_half','half_prune','diverse_half_prune')];ns=dict(np=np,time=time,math=__import__('math'),next_fast_len=next_fast_len,packed_irfft=packed_irfft);exec(compile(ast.Module(body=mods+methods,type_ignores=[]),str(p)+'<pure-component-only>','exec'),ns);return ns

def numeric():
 frozen=check();rng=np.random.default_rng(20261102);rows=[]
 for N in (1,2,3,8,16,64,5000,5400,5832,6000,8192):
  a=rng.random((3,min(N,4096)));a/=a.sum(axis=1)[:,None];b=rng.random(min(7,N));b/=b.sum();f=np.fft.rfft(a,N,axis=1)*np.fft.rfft(b,N)[None,:];old=np.fft.irfft(f,N,axis=1);new=packed_irfft(f,N,axis=1,workers=1);assert new.dtype==old.dtype==np.dtype('float64');err=float(np.abs(old-new).max());assert err<=1e-12,(N,err)
  if N>=a.shape[1]+len(b)-1:
   direct=np.array([np.pad(np.convolve(x,b),(0,N-(len(x)+len(b)-1))) for x in a]);directerr=float(np.abs(new-direct).max());assert directerr<=1e-12
  else:directerr=None
  rows.append({'N':N,'max_numpy_scipy_error':err,'max_direct_error':directerr})
 # Strict B-overflow boundary, zero coefficients, nonnegative clipping unchanged.
 for B in (1,2,3,8,16,64,4096):
  for mode in ('zero','boundary'):
   a=np.zeros(B);b=np.zeros(B)
   if mode=='boundary':a[-1]=1.;b[min(1,B-1)]=1.
   f=np.fft.rfft(a,2*B)*np.fft.rfft(b,2*B);v=np.maximum(0.,packed_irfft(f,2*B,workers=1)[:B]);direct=np.convolve(a,b)[:B];err=float(np.abs(v-direct).max());assert err<=1e-12;rows.append({'B':B,'mode':mode,'max_direct_error':err})
 return {'passed':True,'component_freeze_sha':frozen,'rows':rows,'no_native_draws_or_optimizer':True}

def child(case_index,arm,out):
 frozen=check();protocol=json.loads((ROOT/'PRECHECK_PROTOCOL.json').read_text());case=next(c for c in protocol['cases'] if c['index']==case_index);data=Path(protocol['benchmark_root'])/case['instance'];registered=json.loads((ROOT/'INPUTS.json').read_text());needed=[str(data/'cost.txt'),str(data/'node_to_factor.pkl')]+[str(data/('%d_sample.txt'%j)) for j in range(case['n'])]
 for n in needed:assert sha(n)==registered[n],('rawinputchanged',n)
 costs=np.asarray(np.loadtxt(data/'cost.txt')).reshape(-1)
 with (data/'node_to_factor.pkl').open('rb') as f:groups=pickle.load(f)
 if isinstance(groups,dict):groups=[groups[k] for k in sorted(groups,key=lambda x:int(x))]
 samples=[np.asarray(np.loadtxt(data/('%d_sample.txt'%j))).reshape(-1) for j in range(case['n'])];ns=functions(arm);s=types.SimpleNamespace(inst=types.SimpleNamespace(m=case['m']),T=case['tmax'],bins=4096,groups=[np.asarray(g,int) for g in groups],cost=costs,half_width=max(1024,min(4096,(40960//case['m'])//512*512)),arm='B_CDF_DRO_MITM',remaining=lambda:1e6)
 # Raw-only deterministic fixture; never a formal optimizer's initial solution.
 center=tuple(min(g,key=lambda j:float(samples[j].mean()+3*samples[j].std(ddof=1))) for g in groups);s.best={'cost':float(costs[list(center)].sum()),'selection':list(center)}
 for n in ('half_prune','diverse_half_prune'):setattr(s,n,types.MethodType(ns[n],s))
 legacy=len(samples[0])**case['m']>=10**7;hist=np.asarray([ns['worst_cdf_hist'](a[:-1] if legacy else a,s.T,4096,.00025) for a in samples]);fft=np.fft.rfft(hist,8192,axis=1);left=list(range(0,case['m'],2));right=list(range(1,case['m'],2));profile=cProfile.Profile();begin=time.monotonic();profile.enable();result=ns['build_half'](s,left,right,hist,fft,[center]);profile.disable();elapsed=time.monotonic()-begin;assert result is not None
 out=Path(out);np.savez(out.with_suffix('.npz'),cost=result[0],pdf=result[1],selection=result[2]);ss=io.StringIO();pstats.Stats(profile,stream=ss).sort_stats('cumtime').print_stats(20);d={'component_freeze_sha':frozen,'case':case_index,'arm':arm,'kernel_seconds':elapsed,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'arrays_sha':[hashlib.sha256(x.tobytes()).hexdigest() for x in result],'rows':len(result[0]),'profile':ss.getvalue(),'fixture':'Own raw deterministic mu+3sd. Zero native/MIP calls; not formalrun, no warmstart.','loadavg':os.getloadavg()};out.write_text(json.dumps(d,indent=2));print(json.dumps({k:v for k,v in d.items() if k!='profile'}),flush=True)

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--numeric',action='store_true');ap.add_argument('--case',type=int);ap.add_argument('--arm',choices=['control','candidate']);ap.add_argument('--out',required=True);a=ap.parse_args()
 if a.numeric:Path(a.out).write_text(json.dumps(numeric(),indent=2))
 else:child(a.case,a.arm,a.out)
