"""Singleton component-only precheck. Waits for actual R07 termination. Never launches optimization."""
import os
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,fcntl,subprocess,signal,statistics,hashlib,traceback
from pathlib import Path
import numpy as np
from common import ROOT,read,atomic,process_table,mem_available,envelope
from component_kernel import check
HERE=ROOT

def log(event,**kw):
 d=dict(event=event,utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),**kw);print(json.dumps(d),flush=True)
 with (ROOT/'COMPONENT_EVENTS.jsonl').open('a') as f:f.write(json.dumps(d)+'\n');f.flush();os.fsync(f.fileno())
def ticket(case,count):
 table=process_table();foreign=sum(x['rss'] for x in table.values() if str(ROOT) not in x['cmd']);required=count*envelope(case)+5*2**30+max(2*2**30,foreign,foreign//2);st=os.statvfs(ROOT);disk=st.f_bavail*st.f_frsize;available=mem_available();return available>=required and disk>=5*2**30,dict(available_bytes=available,required_bytes=required,foreign_growth_reserve=max(2*2**30,foreign),future_bound=envelope(case),own_RSS_credit=False,free_disk_bytes=disk,count=count)
def wait_ticket(case,count):
 while True:
  ok,info=ticket(case,count)
  if ok:return info
  atomic(ROOT/'COMPONENT_STATE.json',dict(status='waiting_original_resource_guard',case=case['index'],**info));time.sleep(30)
def wait_previous(reg):
 prior=Path(reg['previous_R07_root']);receipt=read(prior/'LAUNCH_RECEIPT.json');previous_watch=read(prior/'reporting/WATCHER_LAUNCH.json')
 while True:
  rows=process_table();p=rows.get(receipt['pid']);alive=bool(p and p['start_ticks']==receipt['start_ticks']);watch=rows.get(previous_watch['pid']);watchalive=bool(watch and watch['start_ticks']==previous_watch['start_ticks']);workers=sum('/work/codex_B_DRO_' in x['cmd'] and '/worker.py' in x['cmd'] for x in rows.values());state=read(prior/'STATE.json');atomic(ROOT/'COMPONENT_STATE.json',dict(status='waiting_actual_previous_processes',previous_live=alive,previous_workers=workers,prior_watcher_live=watchalive,prior_state=state['status']))
  if not alive and not workers and not watchalive:
   assert state['status']=='pilot_failed_requires_diagnosis',state
   for idx in reg['indices']:
    meta=read(prior/'waves'/('R07_pilot_c%02d_a01'%idx)/'WAVE.json');assert meta['status'] in ('valid_complete','ordinary_failure_complete')
   oldf=read(prior/'FREEZE.json')
   for name,h in oldf['files'].items():assert hashlib.sha256((prior/name).read_bytes()).hexdigest()==h
   log('prior_R07_all7terminal_controller_workers_watcher_dead_no_restart',freeze=hashlib.sha256((prior/'FREEZE.json').read_bytes()).hexdigest());return
  time.sleep(30)

def run_wave(case,tag,arm,count):
 check();info=wait_ticket(case,count);folder=ROOT/'component_results'/tag;folder.mkdir(parents=True,exist_ok=False);log('component_wave_start',case=case['index'],arm=arm,count=count,resources=info);jobs=[]
 try:
  for rep in range(count):
   output=folder/('r%02d.json'%(rep+1));lf=(folder/('r%02d.log'%(rep+1))).open('xb');started=time.monotonic();p=subprocess.Popen([sys.executable,'-B',str(ROOT/'component_kernel.py'),'--case',str(case['index']),'--arm',arm,'--out',str(output)],stdin=subprocess.DEVNULL,stdout=lf,stderr=subprocess.STDOUT,start_new_session=True);jobs.append(dict(p=p,log=lf,started=started,out=output))
  active=list(jobs)
  while active:
   if mem_available()<5*2**30:raise RuntimeError('original5GiBguard breach: resource interruption; preserve, do not retry')
   for j in active[:]:
    rc=j['p'].poll()
    if rc is None:
     if time.monotonic()-j['started']>600:raise RuntimeError('kernel subprocess external600s timeout; no formal run')
     continue
    j['log'].close();assert rc==0,('kernel child failed',str(j['out']),rc);d=read(j['out']);d['total_external_seconds']=time.monotonic()-j['started'];d['read_only_numeric_kernel_not_formal_optimizer']=True;atomic(j['out'],d);active.remove(j)
   time.sleep(.1)
  log('component_wave_complete',case=case['index'],arm=arm,count=count);return [j['out'] for j in jobs]
 except BaseException:
  for j in jobs:
   if j['p'].poll() is None:os.killpg(j['p'].pid,signal.SIGTERM)
   j['log'].close()
  raise

def compare(paths,reference):
 with np.load(reference.with_suffix('.npz'),allow_pickle=False) as z:base={k:z[k].copy() for k in z.files}
 checks=[]
 for p in paths:
  with np.load(p.with_suffix('.npz'),allow_pickle=False) as z:
   assert np.array_equal(z['cost'],base['cost']) and np.array_equal(z['selection'],base['selection']),('retained selection/cost mismatch',str(p));assert z['pdf'].shape==base['pdf'].shape
   maxl1=float(np.max(np.sum(np.abs(z['pdf'].astype(float)-base['pdf'].astype(float)),axis=1)));assert maxl1<=1e-6,('PDF error',str(p),maxl1);checks.append(dict(result=str(p.relative_to(ROOT)),max_retained_pdf_L1=maxl1,cost_and_selection_bitwise_equal=True))
 return checks

def main():
 lock=(ROOT/'component_advance.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);lock.seek(0);lock.truncate();lock.write(str(os.getpid()));lock.flush();frozen=check();reg=read(ROOT/'PRECHECK_PROTOCOL.json');assert not (ROOT/'COMPONENT_TERMINAL.json').exists(),'No repeat of completed component stage'
 wait_previous(reg);check();numeric=subprocess.run([sys.executable,'-B',str(ROOT/'component_kernel.py'),'--numeric','--out',str(ROOT/'NUMERIC_PREFLIGHT.json')]);assert numeric.returncode==0 and read(ROOT/'NUMERIC_PREFLIGHT.json')['passed'];serial=[];allchecks=[];reference=None
 for idx in reg['kernel_cases']:
  case=next(c for c in reg['cases'] if c['index']==idx);paths=[]
  for slot,arm in enumerate(('control','candidate','candidate','control')):paths+=run_wave(case,'serial_c%02d_%02d_%s'%(idx,slot,arm),arm,1)
  allchecks+=compare(paths,paths[0]);control=[read(p) for p in paths if read(p)['arm']=='control'];candidate=[read(p) for p in paths if read(p)['arm']=='candidate'];old=statistics.mean(x['kernel_seconds'] for x in control);new=statistics.mean(x['kernel_seconds'] for x in candidate);serial.append(dict(case=idx,control_seconds=old,candidate_seconds=new,ratio=new/old,control_peak=statistics.mean(x['peak_rss_bytes'] for x in control),candidate_peak=statistics.mean(x['peak_rss_bytes'] for x in candidate)))
  if idx==39:reference=paths[0]
 serial_gate=statistics.mean(x['ratio'] for x in serial)<=.95 and all(x['ratio']<=1.02 and x['candidate_peak']<=x['control_peak'] for x in serial);atomic(ROOT/'SERIAL_KERNEL_PREFLIGHT.json',dict(passed=serial_gate,rows=serial,checks=allchecks,scope='Three fixed actualraw cases ABBA onceeach. No optimizer/native, no reruns.'))
 if not serial_gate:atomic(ROOT/'COMPONENT_TERMINAL.json',dict(status='serial_kernel_gate_failed_no_formal',freeze=frozen,goal_complete=False));return
 case=next(c for c in reg['cases'] if c['index']==39)
 while True:
  count=next((n for n in range(30,7,-1) if ticket(case,n)[0]),0)
  if count:break
  atomic(ROOT/'COMPONENT_STATE.json',dict(status='waiting_concurrent_guard_min8_max30'));time.sleep(30)
 parallel=[];checks=[]
 for slot,arm in enumerate(('control','candidate','candidate','control')):
  paths=run_wave(case,'parallel39_%02d_%s'%(slot,arm),arm,count);checks+=compare(paths,reference);parallel.append(dict(slot=slot,arm=arm,count=count,rows=[read(p) for p in paths]))
 old=[x for w in parallel if w['arm']=='control' for x in w['rows']];new=[x for w in parallel if w['arm']=='candidate' for x in w['rows']];ratio=statistics.mean(x['kernel_seconds'] for x in new)/statistics.mean(x['kernel_seconds'] for x in old);passed=ratio<=.90 and statistics.mean(x['peak_rss_bytes'] for x in new)<=statistics.mean(x['peak_rss_bytes'] for x in old)
 atomic(ROOT/'CONCURRENT_KERNEL_PREFLIGHT.json',dict(passed=passed,ratio=ratio,count=count,waves=parallel,checks=checks));atomic(ROOT/'COMPONENT_TERMINAL.json',dict(status='component_passed_REVIEW_REQUIRED_NO_FORMAL_AUTO_START' if passed else 'concurrent_kernel_gate_failed_no_formal',freeze=frozen,goal_complete=False,only_component_test=True));log('component_terminal',passed=passed,automatic_optimizer_launch=False)
if __name__=='__main__':
 try:main()
 except BaseException as e:
  atomic(ROOT/'COMPONENT_FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc(),optimizer_started=False,do_not_rerun_valid_stage=True));raise
