"""Post-freeze diagnostic of original Best vectors; never read by search."""
import pathlib,json,subprocess,sys,concurrent.futures,os
H=pathlib.Path(__file__).parent;D=H/'old_best_raw_audit';D.mkdir(exist_ok=True)
if '--one' in sys.argv:
 for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
 sys.path[:0]=[str(H/'frozen_candidate'),str(H/'vendor313')]
 from instance import load_instance
 from exact_oracle import ExactOracle
 index=int(sys.argv[2]);c=next(x for x in json.load(open(H/'CASES.json')) if x['index']==index);old=next(x for x in json.load(open(H/'OLD_BEST_REFERENCE.json'))['rows'] if x['index']==index);inst=load_instance('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/'+c['instance']);s=inst.validate_selection(old['selection']);oracle=ExactOracle(inst,c['tmax'],'.99');steps=[]
 for bins in [1024,4096,16384,65536,262144,1048576]:
  v=oracle.certify(s,bins,True);steps.append(v)
  if v['accepted'] or v['infeasible']:break
 result=dict(index=index,instance=c['instance'],tmax=c['tmax'],selection=list(s),old_cost=inst.selection_cost(s),old_real_probability=old['real_probability'],raw99_passed=steps[-1]['accepted'],raw99_refuted=steps[-1]['infeasible'],last_certificate=steps[-1],steps=steps,scope='Only this original Best vector; does not rule out different cheaper feasible vectors')
 with (D/f'case_{index:02d}.json').open('x') as f:json.dump(result,f,indent=2)
else:
 def run(i):
  with (D/f'case_{i:02d}.log').open('x') as f:r=subprocess.run(['/home/junhao/miniconda3/bin/python',str(H/'audit_old_raw.py'),'--one',str(i)],stdout=f,stderr=subprocess.STDOUT,timeout=1800)
  if r.returncode:raise RuntimeError('Original raw audit failed '+str(i))
 with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:list(pool.map(run,range(1,41)))
 rows=[json.load(open(p)) for p in sorted(D.glob('case_*.json'))]
 result=dict(cases=len(rows),raw99_passed=sum(r['raw99_passed'] for r in rows),raw99_refuted=sum(r['raw99_refuted'] for r in rows),unresolved=sum(not r['raw99_passed'] and not r['raw99_refuted'] for r in rows),rows=rows)
 (H/'OLD_BEST_RAW_AUDIT.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
