import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import pathlib,json,time,argparse,random,itertools,math
import numpy as np
from reference_loader import H,R,real_module,estimator,Factor,manifest
ap=argparse.ArgumentParser();ap.add_argument('--instance',required=True);ap.add_argument('--capacity',type=float,required=True);ap.add_argument('--selection',required=True);ap.add_argument('--seed',type=int,default=832273);ap.add_argument('--out',required=True);ap.add_argument('--native',action='store_true');a=ap.parse_args()
p=pathlib.Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/a.instance;s=list(map(int,json.loads(a.selection)));out=pathlib.Path(a.out)
if out.exists():raise RuntimeError('No overwrite')
cost=np.loadtxt(p/'cost.txt');arrays=[np.loadtxt(p/(str(j)+'_sample.txt')) for j in s]
v=np.array([0.])
for x in arrays:v=(v[:,None]+x[None,:]).reshape(-1)
count=int(np.count_nonzero(v<=a.capacity));strict=int(np.count_nonzero(v<a.capacity));minimum_gap=float(np.min(np.abs(v-a.capacity)))
result=dict(instance=a.instance,capacity=a.capacity,selection=s,cost=float(cost[s].sum()),seed=a.seed,draws=10000000,event='sum<=T',empirical_count=count,empirical_denominator=len(v),empirical_probability=count/len(v),empirical_strict_count=strict,minimum_distance_to_capacity=minimum_gap,original_module_file=str(real_module.__file__),original_sources_unmodified=True,import_aliases_only=True,reference_zip_sha256=manifest['zip_sha256'])
if a.native:
 random.seed(a.seed);np.random.seed(a.seed);m=len(s);k=len(cost)//m;L=len(arrays[0]);param=[m,k,L]
 q=estimator.factorization_list(L,m,.99,10,50);factors=[Factor(j,float(cost[j]),float(cost.max()-cost[j]),str(p/(str(j)+'_sample.txt')),str(p/(str(j)+'_big_sample.txt'))) for j in s]
 start=time.monotonic();result['original_advanced_exact_probability']=float(estimator.advanced_exact_evaluation(factors,a.capacity,1000000,.99,param,q));result['original_native_seconds']=time.monotonic()-start
start=time.monotonic();result['real_probability']=float(real_module.real_P_test(np.asarray(s,dtype=int),a.capacity,a.seed,str(p),'app'));result['real_seconds']=time.monotonic()-start;result['LSS_tolerance_passed']=result['real_probability']>=.985
out.parent.mkdir(exist_ok=True,parents=True);out.write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
