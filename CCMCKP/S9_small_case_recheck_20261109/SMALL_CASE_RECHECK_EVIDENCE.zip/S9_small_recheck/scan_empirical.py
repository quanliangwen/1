import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import pathlib,json,pickle,itertools,time,numpy as np
H=pathlib.Path(__file__).resolve().parent;B=pathlib.Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark');output=[]
for c in json.load(open(H/'CASES.json')):
 p=B/c['instance'];groups=list(pickle.load(open(p/'node_to_factor.pkl','rb')).values());cost=np.loadtxt(p/'cost.txt');samples=[np.loadtxt(p/(str(j)+'_sample.txt')) for j in range(len(cost))];split=len(groups)//2
 def half(gs):
  result=[]
  for s in itertools.product(*gs):
   sums=np.array([0.])
   for j in s:sums=(sums[:,None]+samples[j][None,:]).reshape(-1)
   result.append((tuple(map(int,s)),np.sort(sums)))
  return result
 left=half(groups[:split]);right=half(groups[split:]);items=[]
 for x,a in left:
  for y,b in right:
   s=x+y;n=int(np.searchsorted(b,c['capacity']-a,side='right').sum());den=len(a)*len(b);v=float(cost[list(s)].sum());
   if v<=c['S9_cost']+1e-8:items.append(dict(selection=list(s),cost=v,count=n,denominator=den,empirical_probability=n/den,empirical_nominal_99=100*n>=99*den))
 items.sort(key=lambda r:(r['cost'],r['selection']));eligible=[r for r in items if r['empirical_nominal_99']]
 output.append(dict(**c,total_choices=len(left)*len(right),cost_prefix_choices=len(items),nominal_99_candidates=eligible,all_cost_prefix=items))
(H/'EMPIRICAL_COST_PREFIX.json').write_text(json.dumps(output,indent=2));print(json.dumps([dict(index=r['index'],total=r['total_choices'],prefix=r['cost_prefix_choices'],empirical99=len(r['nominal_99_candidates']),candidate_costs=[x['cost'] for x in r['nominal_99_candidates']]) for r in output]))
