import pathlib,json,subprocess,concurrent.futures,hashlib,time
H=pathlib.Path(__file__).resolve().parent;D=H/'direct_results';D.mkdir(exist_ok=True);cases=json.load(open(H/'EMPIRICAL_COST_PREFIX.json'));tasks={}
for c in cases:
 for r in c['nominal_99_candidates']:
  seed=832273;key=hashlib.sha256(json.dumps([c['instance'],c['capacity'],r['selection'],seed],separators=(',',':')).encode()).hexdigest()
  tasks[key]=dict(key=key,index=c['index'],instance=c['instance'],capacity=c['capacity'],selection=r['selection'],seed=seed,native=r['selection'] in [c['old'],c['S9']])
 for selection in [c['old'],c['S9']]:
  seed=832274;key=hashlib.sha256(json.dumps([c['instance'],c['capacity'],selection,seed],separators=(',',':')).encode()).hexdigest();tasks[key]=dict(key=key,index=c['index'],instance=c['instance'],capacity=c['capacity'],selection=selection,seed=seed,native=False)
(H/'DIRECT_RECHECK_REGISTRATION.json').write_text(json.dumps(dict(purpose='Diagnostic only; directly import unmodified uploaded LSS functions, restore module aliases only; no optimized-solver feedback',tasks=list(tasks.values()),max_workers=8,draws_per_task=10000000,official_seed=832273,supplementary_seed=832274),indent=2))
def run(t):
 out=D/(t['key']+'.json');cmd=['python3','-u',str(H/'direct_original_eval.py'),'--instance',t['instance'],'--capacity',str(t['capacity']),'--selection',json.dumps(t['selection']),'--seed',str(t['seed']),'--out',str(out)]
 if t['native']:cmd.append('--native')
 start=time.time()
 with open(str(out)+'.log','x') as log:
  try:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=1200);code=p.returncode
  except subprocess.TimeoutExpired:code='timeout'
 r=dict(**t,exit=code,wall=time.time()-start)
 if code==0:
  v=json.load(open(out));r.update(cost=v['cost'],real_probability=v['real_probability'],passed=v['LSS_tolerance_passed'])
 (D/(t['key']+'.terminal.json')).write_text(json.dumps(r));print(json.dumps(r),flush=True);return r
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:results=list(pool.map(run,tasks.values()))
(H/'DIRECT_DISPATCH_RESULTS.json').write_text(json.dumps(results,indent=2));print('DIRECT_RECHECK_FINISHED',flush=True)
