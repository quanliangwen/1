import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import json,time,random,pathlib,argparse,importlib,numpy as np
from reference_loader import H,R,manifest,estimator
sf=importlib.import_module('functions.func_solution_factor');cp=importlib.import_module('functions.func_localsearch_cp');ls=importlib.import_module('functions.func_localsearch')
ap=argparse.ArgumentParser();ap.add_argument('--index',type=int,required=True);a=ap.parse_args();c=next(r for r in json.load(open(H/'CASES.json')) if r['index']==a.index);p=pathlib.Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/c['instance'];param=[3,5,30];seed=832273
random.seed(seed);np.random.seed(seed);q=estimator.factorization_list(30,3,.99,10,50);Aw,Au,Av,fi=sf.Statistic_factor(param,5,str(p));started=time.monotonic();initial=cp.Construct_Procedure(estimator.advanced_exact_evaluation,Aw,Au,fi,.99,c['capacity'],param,1000000,q);sol=ls.Local_Search_DD(estimator.advanced_exact_evaluation,initial,Av,fi,.99,c['capacity'],param,30,1000000,q);elapsed=time.monotonic()-started
def encode(v):
 if isinstance(v,np.ndarray):return v.tolist()
 if isinstance(v,np.generic):return v.item()
 raise TypeError(type(v).__name__)
r=dict(index=a.index,instance=c['instance'],capacity=c['capacity'],source='Unmodified original LSS Construct_Procedure and Local_Search_DD; module aliases only',parameters=dict(lambda_=5,CL=.99,maxiter=30,MC_sample_size=1000000,seed_initialization=seed),elapsed=elapsed,variant_0=sol[0],variant_1=sol[1],variant_2=sol[2],evaluations=sol[4]);(H/('LSS_SEARCH_REPRODUCED_%d.json'%a.index)).write_text(json.dumps(r,default=encode,indent=2));print(json.dumps(r,default=encode),flush=True)
