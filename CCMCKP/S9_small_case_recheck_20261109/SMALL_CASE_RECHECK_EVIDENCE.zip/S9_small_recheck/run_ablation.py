import pathlib,concurrent.futures,subprocess,json,time,gzip,statistics,hashlib
H=pathlib.Path(__file__).resolve().parent;D=H/'ablation90';D.mkdir(exist_ok=True);cases=json.load(open(H/'CASES.json'));registered=dict(scope='Causal diagnostic only; added tail module disabled; retain empirical nominal0.99; DO NOT count as final LSS-real-feasible runs',seeds=list(range(950001,950031)),cases=cases,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (H/'ablation_source').glob('*.py')});(D/'REGISTRATION.json').write_text(json.dumps(registered,indent=2))
def run(task):
 c,rep=task;out=D/('case%d_r%02d.json.gz'%(c['index'],rep));cmd=['/home/junhao/miniconda3/bin/python','-u',str(H/'ablation_source/run.py'),'--instance','/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/'+c['instance'],'--capacity',str(c['capacity']),'--seed',str(950000+rep),'--seconds','600','--out',str(out)];started=time.time()
 with open(str(out)+'.log','x') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=640)
 r=dict(index=c['index'],rep=rep,exit=p.returncode,wall=time.time()-started)
 if p.returncode==0:
  s=json.load(open(str(out)+'.run.json'));r.update(cost=s['selected']['cost'] if s['selected'] else None,selection=s['selected']['selection'] if s['selected'] else None,within_budget=s['within_budget'])
 (D/('case%d_r%02d.terminal.json'%(c['index'],rep))).write_text(json.dumps(r));return r
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:results=list(pool.map(run,[(c,r) for c in cases for r in range(1,31)]))
rows=[]
for c in cases:
 a=[r for r in results if r['index']==c['index']];cost=[r['cost'] for r in a if r['exit']==0 and r.get('cost') is not None]
 rows.append(dict(index=c['index'],instance=c['instance'],capacity=c['capacity'],n=len(cost),best=min(cost) if cost else None,avg=statistics.mean(cost) if cost else None,std=statistics.pstdev(cost) if cost else None,all30_same_original_selection=len(a)==30 and all(r.get('selection')==c['old'] for r in a),actual_LSS_probability_not_changed='See direct original-module old-solution results; these runs do not pass real>=0.985'))
(D/'SUMMARY.json').write_text(json.dumps(dict(scope=registered['scope'],rows=rows,runs=results),indent=2));print(json.dumps(rows),flush=True)
