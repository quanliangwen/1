import pathlib,json,hashlib,gzip,zipfile,statistics
H=pathlib.Path(__file__).resolve().parent;S=pathlib.Path('/home/quanliangwen/work/cdf_lss_aligned_S9_20261109');B=pathlib.Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark');summary=json.load(open(H/'RECHECK_SUMMARY.json'));dispatch=json.load(open(H/'DIRECT_DISPATCH_RESULTS.json'));follow=json.load(open(H/'FOLLOWUP_DISPATCH.json'));ab=json.load(open(H/'ablation90/SUMMARY.json'))
if len(dispatch)!=93 or any(r['exit']!=0 for r in dispatch) or any(r['exit']!=0 for r in follow):raise RuntimeError('Reference evaluation incomplete')
manifest=json.load(open(S/'lss_eval_reference/REFERENCE_MANIFEST.json'));data=[]
for name in ['APP_3_5_30_','APP_4_5_30_']:
 for p in sorted((B/name).iterdir()):
  key=name+'/'+p.name
  if key in manifest['dataset_sha256']:
   actual=hashlib.sha256(p.read_bytes()).hexdigest()
   if actual!=manifest['dataset_sha256'][key]:raise RuntimeError('Input data changed '+key)
   data.append(dict(path=key,sha256=actual))
(H/'DATA_IDENTITY_CHECK.json').write_text(json.dumps(dict(all_match_uploaded_LSS_archive=True,files_verified=len(data),files=data),indent=2))
areg=json.load(open(H/'ablation90/REGISTRATION.json'));checks=[]
for run in ab['runs']:
 if run['exit']!=0 or not run['within_budget']:raise RuntimeError('Ablation run failed')
 stem='case%d_r%02d.json.gz'%(run['index'],run['rep']);v=json.load(open(H/'ablation90'/(stem+'.run.json')))
 if v['source_sha256']!=areg['source_sha256'] or v['seed']!=950000+run['rep']:raise RuntimeError('Ablation source/seed mismatch')
 if any(p.endswith('_dist.txt') for p in v['opened_task_paths']):raise RuntimeError('True distribution read by ablation optimizer')
 c=next(c for c in summary['rows'] if c['index']==run['index'])
 if v['selected']['selection']!=c['old']['selection']:raise RuntimeError('Unexpected ablation decision')
 checks.append(dict(index=run['index'],rep=run['rep'],seed=v['seed'],cost=v['selected']['cost'],empirical_lower=v['selected']['probability'],elapsed=v['elapsed'],within_budget=v['within_budget'],original_LSS_real_probability=c['old']['real_probability'],final_real_probability_passed=False))
summary['ablation90']=ab['rows'];summary['ablation_source_input_seed_checked']=True;summary['ablation_final_real_probability_accepted']=0;summary['ablation_runs']=checks;summary['data_identity_files_verified']=len(data);summary['direct_original_real_MC_calls']=99;summary['official_seed']=832273;summary['supplementary_seed']=832274
for r in summary['rows']:
 r['lower_candidate_native_followup']=json.load(open(H/'followup'/('case%d_seed832273.json'%r['index'])))
 r['lower_candidate_second_seed']=json.load(open(H/'followup'/('case%d_seed832274.json'%r['index'])))
 if not r['lower_candidate_native_followup']['LSS_tolerance_passed'] or not r['lower_candidate_second_seed']['LSS_tolerance_passed']:raise RuntimeError('Lower candidate not reproduced')
 if r['lower_candidate_native_followup']['original_advanced_exact_probability']<.99:raise RuntimeError('Original LSS sample check fails lower candidate')
 r['original_cost_contributions']=[dict(item=j,cost=float(__import__('numpy').loadtxt(B/r['instance']/'cost.txt')[j])) for j in r['old']['selection']]
 r['S9_cost_contributions']=[dict(item=j,cost=float(__import__('numpy').loadtxt(B/r['instance']/'cost.txt')[j])) for j in r['S9']['selection']]
(H/'RECHECK_SUMMARY.json').write_text(json.dumps(summary,indent=2))
lines=['# 三例成本跳升复核','', '复核结论：S9新增的APP长尾重构及概率硬筛选抬高了成本，改变了原样本模型的候选可行集。其结果不能作为原DRO同约束下的等价搜索改进。15.741492等数值是S9那一版30次运行的实际输出，但并非最便宜的合格候选。','', '同时，原LSS主实验的样本Confidence Level与独立real_P_test的Real Confidence Level是两种不同的量。旧9.034717在原样本检查中合格；按此前用户确认的真实仿真>=0.985标准不合格。这两个事实必须分别报告。','', '## 原值与直接原LSS复核','', '|算例|T|原成本|原LSS样本检查输出|原解真实概率|S9成本|','|---|---:|---:|---:|---:|---:|']
for r in summary['rows']:lines.append('|%s|%g|%.9f|%.9f|%.7f|%.9f|'%(r['instance'],r['capacity'],r['old']['cost'],r['old']['original_advanced_exact_probability'],r['old']['real_probability'],r['S9']['cost']))
lines+=['','本次从上传ZIP重新提取全部21个Python文件并逐文件核对哈希，直接导入原real_P_test及原生成函数，保留原my_file路径实现。仅恢复原包中失配的benchmark_lab/benchmark_huawei模块别名，函数体未改。每次真实仿真1000万次，正式对照种子832273；另用832274复核旧解、新解及更低候选。两份数据目录共74个样本/成本/分组/分布元数据文件均与上传归档哈希一致。此前AST接线版本的这些原解/S9解概率与本次全模块直接调用结果完全一致。','', '原LSS入口exp_Result_Localsearch.py先得到Solution_LS，再调用real_P_test，随后直接record_to_csv1写出Cost及Real Confidence Level，没有按真实概率过滤Cost。其原始Optimal_0由内部样本概率筛选后的CostList[0]返回。单独辅助整理函数才有0.985容差。','', '另直接运行原Construct_Procedure和Local_Search_DD（lambda=5、CL=0.99、maxiter=30、MC=1000000），两个APP_3_5算例的Optimal_0分别重现9.0347172995和7.2500131701；并非成本单位、容量或数据集切换。','', '## 关闭新增尾部模块的因果对照','', '|算例|T|独立次数|关闭模块后的Avg|Std|是否均回到原向量|原真实验收|','|---|---:|---:|---:|---:|---|---|']
for r in ab['rows']:lines.append('|%s|%g|%d|%.9f|%.9f|%s|不合格|'%(r['instance'],r['capacity'],r['n'],r['avg'],r['std'],'是' if r['all30_same_original_selection'] else '否'))
lines+=['', '这个90次实验只用于定位成本差异：复制S9源码，关闭新增尾部重构及其硬筛选，保留整数经验概率0.99检查和其余搜索代码，使用新种子950001–950030。每次实际独立运行且没有读取真实分布参数或旧解。90次全部回到原向量，但真实概率均不满足0.985，不能算新的可行优化结果。','', '## 找到的更低合格候选','', '|算例|T|S9成本|更低候选成本|原LSS样本输出|真实概率832273|真实概率832274|较S9降低|','|---|---:|---:|---:|---:|---:|---:|---:|']
for r in summary['rows']:lines.append('|%s|%g|%.9f|%.9f|%.9f|%.7f|%.7f|%.3f%%|'%(r['instance'],r['capacity'],r['S9']['cost'],r['lower_candidate']['cost'],r['lower_candidate_native_followup']['original_advanced_exact_probability'],r['lower_candidate']['real_probability'],r['lower_candidate_second_seed']['real_probability'],r['improvement_over_S9_percent']))
lines+=['','这些候选同时通过：原LSS样本检查>=0.99、全部原样本整数概率下界>=0.99，以及原LSS真实仿真>=0.985。它们被S9新增辅助模型硬门槛排除，说明S9存在可以避免的保守性：','', '|算例|S9辅助门槛|较低候选辅助分数|是否被硬筛排除|','|---|---:|---:|---|']
for r in summary['rows']:lines.append('|%s T%g|%.9f|%.9f|是|'%(r['instance'],r['capacity'],r['S9_auxiliary_hard_threshold'],r['S9_auxiliary_scores']['lower_candidate']))
lines+=['','本次对125、125、625个选择计算原样本经验概率，针对成本不超过S9结果且经验概率>=0.99的13、11、63个候选逐个调用原LSS真实检验；87个正式种子候选均完成。含补充复核共99次真实仿真调用，所有错误/日志保留。这些是诊断参考解，不是新算法40x30的Avg，不回填到旧S9统计。','', '## 对前次交付表述的修正','', '前次将额外尾部限制与搜索稳定化合并介绍，不足以说明它改变了内部筛选条件。原S9的1200次结果仍是当时冻结代码的真实结果；它证明该扩展版本在这些运行中满足所选验收，不能证明它与原模型等价或成本已最优。原统计和日志保持不变，复核单独交付。','', '后续求解器修正应保留原DRO模型约束，将额外尾部先验改成明确可选的候选引导，分别记录内部样本概率和外部真实概率。真实分布参数只能用于独立验收，不能将本次穷举得到的参考向量硬编码进优化器，也不能将参考解冒充新的30次平均结果。', '', '文件：RECHECK_SUMMARY.json为完整数值与向量，SMALL_CASE_RECHECK_EVIDENCE.zip包含原LSS源码哈希、99次直接检验、两次原LSS搜索和90次消融原始记录。']
(H/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
roots=['reference','REFERENCE_SHA256.json','DATA_IDENTITY_CHECK.json','CASES.json','DIRECT_RECHECK_REGISTRATION.json','DIRECT_DISPATCH_RESULTS.json','EMPIRICAL_COST_PREFIX.json','direct_results','followup','FOLLOWUP_DISPATCH.json','LSS_SEARCH_REPRODUCED_21.json','LSS_SEARCH_REPRODUCED_22.json','lss_search21.log','lss_search22.log','ablation_source','ablation90','ablation90.log','reference_loader.py','direct_original_eval.py','scan_empirical.py','run_recheck.py','run_followup.py','reproduce_lss_search.py','analyze_s9_screen.py','run_ablation.py','finalize_recheck.py','RECHECK_SUMMARY.json','REPORT.md']
archive=H/'SMALL_CASE_RECHECK_EVIDENCE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in roots:
  root=H/name
  for p in sorted(root.rglob('*')) if root.is_dir() else [root]:
   if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith('.lock'):z.write(p,'S9_small_recheck/'+p.relative_to(H).as_posix())
with zipfile.ZipFile(archive) as z:
 if z.testzip():raise RuntimeError('Archive CRC failed')
print(json.dumps(dict(rows=3,ablation_runs=len(checks),original_real_MC_calls=99,data_files=len(data),evidence_bytes=archive.stat().st_size,evidence_sha256=hashlib.sha256(archive.read_bytes()).hexdigest())))
