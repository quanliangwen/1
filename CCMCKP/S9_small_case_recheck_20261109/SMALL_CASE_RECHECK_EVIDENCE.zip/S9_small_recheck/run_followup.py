import pathlib,json,subprocess,concurrent.futures,time
H=pathlib.Path(__file__).resolve().parent;S=json.load(open(H/'RECHECK_SUMMARY.json'));D=H/'followup';D.mkdir(exist_ok=True);tasks=[]
for r in S['rows']:
 for seed in [832273,832274]:tasks.append(dict(index=r['index'],instance=r['instance'],capacity=r['capacity'],selection=r['lower_candidate']['selection'],seed=seed))
def run(t):
 out=D/('case%d_seed%d.json'%(t['index'],t['seed']));cmd=['python3','-u',str(H/'direct_original_eval.py'),'--instance',t['instance'],'--capacity',str(t['capacity']),'--selection',json.dumps(t['selection']),'--seed',str(t['seed']),'--out',str(out),'--native'];start=time.time()
 with open(str(out)+'.log','x') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
 v=dict(**t,exit=p.returncode,wall=time.time()-start);print(json.dumps(v),flush=True);return v
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:results=list(pool.map(run,tasks))
(H/'FOLLOWUP_DISPATCH.json').write_text(json.dumps(results,indent=2))
