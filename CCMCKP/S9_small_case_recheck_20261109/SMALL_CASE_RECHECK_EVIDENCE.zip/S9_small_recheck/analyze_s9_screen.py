import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import pathlib,sys,json,time,gzip,hashlib
H=pathlib.Path(__file__).resolve().parent;S=pathlib.Path('/home/quanliangwen/work/cdf_lss_aligned_S9_20261109');sys.path[:0]=[str(S/'vendor313'),str(S/'frozen_candidate')]
from instance import load_instance
from strict_solver import StrictSolver
cases=json.load(open(H/'EMPIRICAL_COST_PREFIX.json'));results=[]
for p in (H/'direct_results').glob('*.json'):
 if p.name.endswith('.terminal.json'):continue
 results.append(json.load(open(p)))
rows=[]
for c in cases:
 matches=[r for r in results if r['instance']==c['instance'] and r['capacity']==c['capacity'] and r['seed']==832273]
 if len(matches)!=len(c['nominal_99_candidates']):raise RuntimeError('Incomplete reference candidates')
 mapping={tuple(r['selection']):r for r in matches}
 for x in c['nominal_99_candidates']:
  r=mapping[tuple(x['selection'])]
  if r['empirical_count']!=x['count'] or r['empirical_denominator']!=x['denominator']:raise RuntimeError('Two independent empirical enumerators disagree')
 passed=[r for r in matches if r['real_probability']>=.985];best=min(passed,key=lambda r:(r['cost'],r['selection']))
 old=mapping[tuple(c['old'])];s9=mapping[tuple(c['S9'])];b=pathlib.Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/c['instance'];inst=load_instance(b);solver=StrictSolver(inst,c['capacity'],955511,600,H/'not_a_solver_run.json.gz',time.monotonic(),'B_CDF_DRO_MITM')
 saved=json.load(gzip.open(S/'formal30_lss'/('LSS_%02d_r01.json.gz'%c['index']),'rt'));target=saved['tail_model_target']
 scores={name:solver.guide_probability(r['selection']) for name,r in [('old',old),('S9',s9),('lower_candidate',best)]}
 cert=None
 for bins in [256,1024,4096,16384,65536,262144,1048576]:
  cert=solver.oracle.certify(best['selection'],bins,True)
  if cert['accepted'] or cert['infeasible']:break
 if not cert['accepted']:raise RuntimeError('Lower candidate fails exact original-sample 0.99 constraint')
 row=dict(index=c['index'],instance=c['instance'],capacity=c['capacity'],old=old,S9=s9,lower_candidate=best,S9_auxiliary_hard_threshold=target,S9_auxiliary_scores=scores,lower_candidate_rejected_by_S9_extra_screen=scores['lower_candidate']<target,lower_candidate_exact_empirical_certificate=cert,improvement_over_S9_percent=100*(s9['cost']-best['cost'])/s9['cost'],old_cost_gap_not_a_units_or_dataset_change=True)
 rows.append(row)
out=dict(scope='Independent diagnostic; candidate enumeration uses original sample empirical>=0.99, original full-module real_P_test>=0.985. Lower candidates are diagnostic references, not new30-run or40x30 results.',original_LSS_sources_unmodified=True,import_aliases_only=True,rows=rows)
(H/'RECHECK_SUMMARY.json').write_text(json.dumps(out,indent=2));print(json.dumps([dict(index=r['index'],old_cost=r['old']['cost'],old_native_probability=r['old'].get('original_advanced_exact_probability'),old_real_probability=r['old']['real_probability'],S9_cost=r['S9']['cost'],lower_cost=r['lower_candidate']['cost'],lower_real_probability=r['lower_candidate']['real_probability'],lower_selection=r['lower_candidate']['selection'],S9_threshold=r['S9_auxiliary_hard_threshold'],model_scores=r['S9_auxiliary_scores'],rejected=r['lower_candidate_rejected_by_S9_extra_screen']) for r in rows]))
