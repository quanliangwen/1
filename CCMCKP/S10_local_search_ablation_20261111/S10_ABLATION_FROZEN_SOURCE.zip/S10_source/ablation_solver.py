"""Run the frozen S10 schedule with independently switchable local phases."""
import os
import time

import stable_solver
from strict_solver import StrictSolver


class AblationSolver(StrictSolver):
    def __init__(self, *args, **kwargs):
        self.backend = os.environ['S10_BACKEND']
        self.local_phases = os.environ['S10_LOCAL_PHASES']
        if self.backend == 'gurobi':
            from gurobi_backend import binary_model
            stable_solver.binary_model = binary_model
        self.local_calls = 0
        self.phase_records = []
        super().__init__(*args, **kwargs)

    def record_phase(self, name, action, **metadata):
        started = time.monotonic()
        before = self.best['cost'] if self.best else None
        pool_size = len(self.pool)
        action()
        self.phase_records.append(dict(
            phase=name, elapsed=time.monotonic() - started,
            best_before=before, best_after=self.best['cost'] if self.best else None,
            candidates_added=len(self.pool) - pool_size, **metadata,
        ))

    def init_frontier(self):
        self.record_phase('initialization', super().init_frontier)

    def local_search(self, seconds=160):
        self.local_calls += 1
        phase = 'pre' if self.local_calls == 1 else 'post'
        enabled = self.local_phases in ('both', phase)
        def search():
            super(AblationSolver, self).local_search(seconds)
        self.record_phase('local_' + phase, search if enabled else lambda: None, enabled=enabled)

    def matching(self, delta, left, right):
        def search():
            super(AblationSolver, self).matching(delta, left, right)
        self.record_phase('MITM', search, delta=delta, left=left, right=right)
