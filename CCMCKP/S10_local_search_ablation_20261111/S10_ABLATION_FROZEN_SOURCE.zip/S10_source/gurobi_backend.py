"""Solve the same binary models and enumerate by the same exclusion cuts."""
import math
import os
import time

import gurobipy as gp

_env = None


def binary_model(groups, n, objective, rows=(), lo=(), hi=(), seconds=1., pool=1):
    global _env
    if _env is None:
        _env = gp.Env(empty=True)
        _env.setParam('OutputFlag', 0)
        _env.start()
    selections = []
    with gp.Model(env=_env) as model:
        model.Params.Threads = 1
        model.Params.Seed = int(os.environ['S2_SEARCH_SEED'])
        model.Params.MIPGap = 0.
        x = model.addVars(n, vtype=gp.GRB.BINARY)
        for group in groups:
            model.addConstr(gp.quicksum(x[int(i)] for i in group) == 1)
        for row, lower, upper in zip(rows, lo, hi):
            terms = [(float(v), x[i]) for i, v in enumerate(row) if v]
            linear = gp.LinExpr([v for v, _ in terms], [var for _, var in terms])
            if math.isfinite(lower):
                model.addConstr(linear >= float(lower))
            if math.isfinite(upper):
                model.addConstr(linear <= float(upper))
        model.setObjective(gp.quicksum(float(v) * x[i] for i, v in enumerate(objective)), gp.GRB.MINIMIZE)
        deadline = time.monotonic() + seconds
        for _ in range(pool):
            remaining = deadline - time.monotonic()
            if remaining <= .005:
                break
            model.Params.TimeLimit = remaining
            model.optimize()
            if not model.SolCount:
                break
            selection = tuple(max(map(int, group), key=lambda i: x[i].X) for group in groups)
            selections.append(selection)
            model.addConstr(gp.quicksum(x[i] for i in selection) <= len(groups) - 1)
            model.reset(0)
    return selections
