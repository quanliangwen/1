"""Schedule the registered paired pilot on one server."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import hashlib
import json
import os
import random
import signal
import subprocess
import time

D = Path(__file__).resolve().parent
reg = json.loads((D/'REGISTRATION.json').read_text())


def verify_inputs():
    for filename, expected in reg['driver_sha256'].items():
        assert hashlib.sha256((D/filename).read_bytes()).hexdigest() == expected, filename
    inputs = json.loads((D/'BENCHMARK_MANIFEST.json').read_text())
    for instance, files in inputs.items():
        for filename, expected in files.items():
            path = Path(reg['benchmark_root'])/instance/filename
            assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, path


def run(arm, case, rep):
    output = D/'runs'/arm/f'case_{case:02}'/f'rep_{rep:02}'
    output.mkdir(parents=True, exist_ok=False)
    began = time.monotonic()
    with (output/'worker.stdout.log').open('x') as log:
        process = subprocess.Popen(['/usr/bin/python3', '-u', str(D/'worker.py'),
                                    '--arm', arm, '--index', str(case), '--rep', str(rep)],
                                   cwd=D, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        try:
            exit_code = process.wait(timeout=3600)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            exit_code = 'timeout'
    return dict(arm=arm, case=case, rep=rep, exit_code=exit_code,
                completed=exit_code == 0 and (output/'RESULT.json').is_file(),
                wall_seconds=time.monotonic() - began)


def main():
    verify_inputs()
    tasks = [(arm, c['index'], rep) for c in reg['cases'] for rep in reg['repetitions']
             for arm in reg['arms']]
    random.Random(714615).shuffle(tasks)
    with (D/'DISPATCH_ORDER.json').open('x') as file:
        json.dump(tasks, file, indent=2)
    results = []
    with ThreadPoolExecutor(max_workers=reg['concurrent_trials']) as pool:
        futures = [pool.submit(run, *task) for task in tasks]
        for future in as_completed(futures):
            result = future.result()
            results.append(result)
            print(json.dumps(result), flush=True)
    with (D/'TERMINAL.json').open('x') as file:
        json.dump(results, file, indent=2)


if __name__ == '__main__':
    main()
