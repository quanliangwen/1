"""One detached strict-check -> fixed manager pipeline; never formal optimize."""
import os,sys,json,hashlib,time,subprocess,fcntl,signal,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'research'))
from component_manager_guarded_A02 import Manager,atomic,read,available,envelope,ENV

def main():
    lock=(ROOT/'component_advance.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    with (ROOT/'RUNNER_UNIQUE_CLAIM.json').open('x') as f:json.dump({'pid':os.getpid(),'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())},f);f.flush();os.fsync(f.fileno())
    runtime=read(ROOT/'reporting/TARGET_RUNTIME_FREEZE_A02.json')
    for n,h in runtime['files'].items():assert hashlib.sha256((ROOT/'reporting'/n).read_bytes()).hexdigest()==h
    proof=read(ROOT/'GITHUB_PREREG_REMOTE_VERIFY.json');assert proof['passed'] and proof['commit']=='7a3596c233bd0f8aa696678e37071d18c0328173' and proof['verified_files']==8
    extra=read(ROOT/'GITHUB_RUNTIME_ADDENDUM_VERIFY.json');assert extra['passed'] and extra['verified_files']>=10
    guard=Manager();guard.wait_previous()
    while True:
        t=guard.ticket(max(guard.protocol['cases'],key=envelope),1)
        if t['available_bytes']>=t['required_bytes'] and t['free_disk_bytes']>=3*2**30:break
        guard.state('waiting_strict_checker_resources',ticket=t);time.sleep(30)
    guard.state('strict_byte_and_inverse_checks')
    with (ROOT/'strict_byte_check.log').open('x') as log:
        start=time.monotonic();p=subprocess.Popen([sys.executable,'-B',str(ROOT/'reporting/strict_byte_and_inverse_check.py')],env=ENV,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
        while p.poll() is None:
            if available()<5*2**30 or time.monotonic()-start>600:
                os.killpg(p.pid,signal.SIGKILL);p.wait();raise RuntimeError('Strict arithmetic checker resource/time interruption retained; no automatic restore')
            time.sleep(.25)
        assert p.returncode==0
    strict=read(ROOT/'reporting/STRICT_BYTE_AND_INVERSE_CHECKS_LINUX.json');assert strict['passed'] and strict['all18_literal_output_digests_equal'] and strict['all18_actual_packed_inverse_row_counts_equal'] and strict['main_component_freeze_sha256']==guard.freeze
    guard.state('strict_checks_passed_launch_fixed_component_manager')
    with (ROOT/'component_manager.log').open('x') as log:p=subprocess.run([sys.executable,'-B',str(ROOT/'reporting/component_manager_guarded_A02.py')],env=ENV,stdout=log,stderr=subprocess.STDOUT)
    assert p.returncode==0 and (ROOT/'COMPONENT_TERMINAL.json').exists()
    terminal=read(ROOT/'COMPONENT_TERMINAL.json');assert terminal['goal_complete'] is False;atomic(ROOT/'PIPELINE_TERMINAL.json',{'strict_checks_passed':True,'manager_status':terminal['status'],'formal_auto_start':False,'goal_complete':False})
if __name__=='__main__':
    try:main()
    except Exception:
        atomic(ROOT/'PIPELINE_FAILURE.json',{'error':traceback.format_exc(),'formal_auto_start':False,'goal_complete':False})
        if not(ROOT/'COMPONENT_TERMINAL.json').exists():atomic(ROOT/'COMPONENT_TERMINAL.json',{'status':'component_preflight_or_pipeline_failed_NO_FORMAL','passed':False,'goal_complete':False,'formal_auto_start':False})
        raise
