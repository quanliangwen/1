"""Supplement literal byte/inverse-row evidence, no frozen code modification.

array_equal does not distinguish signed zeros. This addresses that validation
gap without changing algorithms, inputs, parameters or original admission gate.
No optimization/native run or performance-wave retry occurs.
"""
import os,sys,json,hashlib,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];HERE=ROOT/'research';sys.path.insert(0,str(HERE))
import kernel_support as k
from streaming_pdf_cache import BucketPDFCache

def bytes_hash(answer):
    h=hashlib.sha256()
    for x in answer:h.update(str((x.dtype.str,x.shape)).encode());h.update(x.tobytes())
    return h.hexdigest()

def main():
    freeze=k.verify_freeze();addon=ROOT/'reporting/SUPPLEMENTARY_CHECKER_FREEZE.json';ad=json.loads(addon.read_text(encoding='utf-8'));assert ad['main_component_freeze_sha256']==freeze and ad['checker_sha256']==hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    out=ROOT/'reporting'/('STRICT_BYTE_AND_INVERSE_CHECKS_'+('WINDOWS' if os.name=='nt' else 'LINUX')+'.json');assert not out.exists()
    n=1100;width=1024;cc=k.np.ones(n);p0=k.np.ones(n);p1=k.np.ones(n);pdf=k.np.tile(k.np.array([0.,-0.,1e-30,1.],dtype=k.np.float32),(n,1));pdf[1::2,:2]=pdf[1::2,1::-1]
    ids=k.np.arange(n,dtype=k.np.int64)[:,None];cls,_=k.kernel_class('base');base=k.make_kernel(cls,[1.,2.],[[0],[1]],4,100.,width);_,keep,_=base.half_prune(cc,p0,p1,ids,ids);cache=BucketPDFCache(cc,width,4)
    for first in range(0,n,63):cache.add(first,pdf[first:first+63],p0,p1)
    assert cache.take(keep[:,0]).tobytes()==pdf[keep[:,0]].tobytes()
    rows=[];real=k.packed_irfft;counter=[0]
    def counted(freq,*args,**kwargs):counter[0]+=len(freq) if freq.ndim==2 else 1;return real(freq,*args,**kwargs)
    k.packed_irfft=counted
    for index in (17,38,39):
        case,cost,groups,samples=k.input_case(index)
        for delta in (0.,.00025,.0005):
            for anchors in (1,2):
                prepared=k.boundary(case,cost,groups,samples,delta,anchors);counter[0]=0;answer,_,_=k.run_kernel('base',case,cost,groups,prepared);h0=bytes_hash(answer);n0=counter[0];del answer
                counter[0]=0;answer,_,_=k.run_kernel('cache',case,cost,groups,prepared);h1=bytes_hash(answer);n1=counter[0];del answer
                assert h0==h1 and n0==n1,(index,delta,anchors,n0,n1)
                row={'case':index,'delta':delta,'anchors':anchors,'literal_byte_SHA256':h0,'packed_inverse_rows_base':n0,'packed_inverse_rows_cache':n1};rows.append(row);print(json.dumps(row),flush=True)
    d={'passed':True,'main_component_freeze_sha256':freeze,'checker_sha256':ad['checker_sha256'],'signed_zero_payload_bytes_preserved':True,'all18_literal_output_digests_equal':True,'all18_actual_packed_inverse_row_counts_equal':True,'environment':{'numpy':k.np.__version__,'scipy':k.scipy.__version__},'no_native_or_optimization_calls':True,'original_gate_not_weakened':True,'rows':rows}
    out.write_text(json.dumps(d,indent=2),encoding='utf-8');print(json.dumps({x:y for x,y in d.items() if x!='rows'}),flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        p=ROOT/'reporting'/('STRICT_FAILURE_'+('WINDOWS' if os.name=='nt' else 'LINUX')+'.txt')
        if not p.exists():p.write_text(traceback.format_exc(),encoding='utf-8')
        raise
