"""Detached singleton fixed kernel precheck. Never launches formal optimization."""
import os,sys,json,time,math,signal,subprocess,fcntl,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];HERE=ROOT/'research';sys.path.insert(0,str(HERE))
from kernel_support import verify_freeze
ENV=dict(os.environ,OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')

def read(p):return json.loads(Path(p).read_text())
def atomic(p,d):
    p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp')
    with tmp.open('w') as f:json.dump(d,f);f.flush();os.fsync(f.fileno())
    os.replace(tmp,p)
def processes():
    result={}
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            s=(p/'stat').read_text();f=s[s.rfind(')')+2:].split();result[int(p.name)]={'ticks':int(f[19]),'rss':int(f[21])*os.sysconf('SC_PAGE_SIZE'),'cmd':(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')}
        except (OSError,ValueError,IndexError):pass
    return result
def available():return int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
def envelope(case):
    m=case['m'];K=case['max_group'];B=4096;W=max(1024,min(4096,(40960//m)//512*512));parents=min(W,K**max(0,(m+1)//2-1));children=parents*K
    q=2*4*children*B+16*W*(B+1)+2*4*W*B+4*16*64*K*(B+1)+8*W*B+case['n']*(8*B+16*(B+1))+512*2**20
    joint=2*(m+1)*B*8+case['n']*(B*8+(B+1)*16)+8*K*(B+1)*16+768*(m*(m-1)//2)*K*K+128*2**20
    return max(1*2**30,q)+max(512*2**20,joint)

class Manager:
    def __init__(self):
        self.freeze=verify_freeze();self.protocol=read(HERE/'COMPONENT_PROTOCOL.json');self.active={};self.peak={};self.case_parallel={};self.foreign_start=sum(x['rss'] for x in processes().values() if str(ROOT) not in x['cmd'])
        (ROOT/'waves').mkdir(exist_ok=True);(ROOT/'WAVE_POINTERS').mkdir(exist_ok=True)
    def event(self,name,**kw):
        d=dict(event=name,utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),monotonic=time.monotonic(),**kw)
        with (ROOT/'EVENTS.jsonl').open('a') as f:f.write(json.dumps(d)+'\n');f.flush();os.fsync(f.fileno())
        print(json.dumps(d),flush=True)
    def state(self,status,**kw):atomic(ROOT/'COMPONENT_STATE.json',dict(status=status,pid=os.getpid(),freeze_sha256=self.freeze,active=list(self.active),goal_complete=False,**kw))
    def old_live(self):
        p=self.protocol['previous_campaign'];table=processes()
        for pid,ticks in [(p['pid'],p['ticks']),(p['watcher_pid'],p['watcher_ticks'])]:
            row=table.get(pid)
            if row and row['ticks']==ticks:return True
        return any(p['root']+'/worker.py' in row['cmd'] for row in table.values())
    def wait_previous(self):
        while self.old_live():self.state('waiting_previous_actual_process_exit');time.sleep(30)
        p=Path(self.protocol['previous_campaign']['root']);assert read(p/'STATE.json')['status']=='pilot_failed_requires_diagnosis' and (p/'LATEST_TERMINAL_EXPORT.json').exists()
        for idx in (17,38,39,40,25,18,14):assert read(p/read(p/'WAVE_POINTERS'/('R09_pilot_c%02d.json'%idx))['relative_dir']/'WAVE.json')['status'] in ('valid_complete','ordinary_failure_complete')
    def ticket(self,case,count):
        table=processes();foreign=sum(x['rss'] for x in table.values() if str(ROOT) not in x['cmd']);growth=max(2*2**30,foreign//2,max(0,foreign-self.foreign_start));each=max(envelope(case),int(self.peak.get(case['index'],0)*1.25));need=count*each+5*2**30+growth;disk=os.statvfs(ROOT);free=disk.f_bavail*disk.f_frsize
        return dict(available_bytes=available(),required_bytes=need,worker_future_bound=each,foreign_growth_reserve=growth,own_RSS_admission_credit=False,free_disk_bytes=free,workers=count,loadavg=os.getloadavg())
    def terminate_own(self):
        for pid,j in self.active.items():
            if j['p'].poll() is None:
                try:os.killpg(pid,signal.SIGKILL)
                except ProcessLookupError:pass
        for j in self.active.values():j['p'].wait();j['log'].close()
        self.active={}
    def wave(self,case,mode,block,arm):
        if mode=='serial':count=1
        else:
            if case['index'] not in self.case_parallel:
                while True:
                    chosen=None
                    for possible in range(30,1,-1):
                        ticket=self.ticket(case,possible)
                        if ticket['available_bytes']>=ticket['required_bytes'] and ticket['free_disk_bytes']>=3*2**30:chosen=possible;break
                    if chosen is not None:break
                    self.state('waiting_safe_matched_cohort_resources',case=case['index'],ticket=ticket);self.event('resource_wait_matched_cohort',case=case['index'],**ticket);time.sleep(30)
                self.case_parallel[case['index']]=chosen
                atomic(ROOT/'MATCHED_PARALLEL_COHORTS.json',{'case_workers':self.case_parallel,'rule':'Largestoriginalguardadmitted2..30 at firstparallelblock; sameNall4blocks/case; no outcomes used','original_ticket':ticket,'amendment':'RESOURCE_ONLY_AMENDMENT_A02.json'})
                self.event('matched_cohort_fixed_before_ABBA',case=case['index'],workers=chosen,original_ticket=ticket)
            count=self.case_parallel[case['index']]
        key='%s_c%02d_b%d_%s'%(mode,case['index'],block,arm);attempt=0
        while True:
            attempt+=1
            while True:
                assert not self.old_live();t=self.ticket(case,count)
                if t['available_bytes']>=t['required_bytes'] and t['free_disk_bytes']>=3*2**30:break
                self.state('waiting_original_future_memory_guard',key=key,ticket=t);self.event('resource_wait',key=key,**t);time.sleep(30)
            folder=ROOT/'waves'/('%s_a%02d'%(key,attempt));folder.mkdir(exist_ok=False);meta=dict(key=key,mode=mode,case=case['index'],block=block,arm=arm,workers=count,attempt=attempt,status='running',component_freeze_sha256=self.freeze,resources_at_dispatch=t)
            atomic(folder/'WAVE.json',meta);atomic(ROOT/'WAVE_POINTERS'/(key+'.json'),{'relative_dir':str(folder.relative_to(ROOT)),'attempt':attempt});self.event('wave_start',**meta);jobs=[]
            for rep in range(1,count+1):
                started=time.monotonic();log=(folder/('r%02d.log'%rep)).open('x');cmd=[sys.executable,'-B',str(HERE/'component_worker.py'),'--arm',arm,'--case',str(case['index']),'--rep',str(rep),'--started',repr(started),'--dir',str(folder)];p=subprocess.Popen(cmd,env=ENV,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True);job={'p':p,'log':log,'rep':rep,'started':started};jobs.append(job);self.active[p.pid]=job
            self.state('running_component_wave',key=key,attempt=attempt);release=False;resource_abort=False;last=0
            while any(j['p'].poll() is None for j in jobs):
                now=time.monotonic();st=os.statvfs(ROOT)
                if available()<5*2**30 or st.f_bavail*st.f_frsize<1*2**30:resource_abort=True;self.terminate_own();break
                for j in jobs:
                    if j['p'].poll() is None and now-j['started']>600:
                        os.killpg(j['p'].pid,signal.SIGKILL);raise RuntimeError('Component ordinary hard600 timeout '+key)
                if not release and all((folder/('r%02d.ready.json'%j['rep'])).exists() for j in jobs):atomic(folder/'RUN.json',{'release_monotonic':now,'freeze_sha256':self.freeze});release=True
                if not release and any(j['p'].poll() is not None for j in jobs):raise RuntimeError('Component exited before ready '+key)
                if now-last>=30:self.event('resource_observation',key=key,available_bytes=available(),loadavg=os.getloadavg(),actual_live=sum(j['p'].poll() is None for j in jobs));last=now
                time.sleep(.05)
            journal={};rows=[]
            for j in jobs:
                j['p'].wait();j['log'].close();journal[str(j['rep'])]=time.monotonic()-j['started'];self.active.pop(j['p'].pid,None)
                p=folder/('r%02d.json'%j['rep'])
                if p.exists():rows.append(read(p))
            atomic(folder/'TIMING_JOURNAL.json',journal)
            if resource_abort:
                meta['status']='resource_interrupted';atomic(folder/'WAVE.json',meta);self.event('resource_interruption_retained',key=key,attempt=attempt);continue
            assert len(rows)==count and all(j['p'].returncode==0 for j in jobs) and max(journal.values())<=600
            assert all(r['status']=='completed' and r['component_freeze_sha256']==self.freeze and r['native_evaluation_calls']==0 and r['full_optimization_runs']==0 for r in rows)
            assert len({r['output_digest'] for r in rows})==1
            peak=max(r['peak_rss_bytes'] for r in rows);self.peak[case['index']]=max(self.peak.get(case['index'],0),peak)
            meta.update(status='valid_complete',max_peak_rss=peak,kernel_mean_seconds=sum(r['kernel_total_seconds'] for r in rows)/count,actual_wave_end=time.monotonic());atomic(folder/'WAVE.json',meta);self.event('wave_terminal',**meta)
            return meta
    def run(self):
        self.wait_previous();verify_freeze()
        while True:
            t=self.ticket(max(self.protocol['cases'],key=envelope),1)
            if t['available_bytes']>=t['required_bytes'] and t['free_disk_bytes']>=3*2**30:break
            self.state('waiting_math_resources',ticket=t);time.sleep(30)
        self.state('mathematical_checks')
        with (ROOT/'mathematical_checks.log').open('x') as log:p=subprocess.run([sys.executable,'-B',str(HERE/'unit_exact_cache.py'),'--output','TARGET_EXACT_CACHE_CHECKS.json'],env=ENV,stdout=log,stderr=subprocess.STDOUT,timeout=600)
        math_result=read(HERE/'TARGET_EXACT_CACHE_CHECKS.json');assert p.returncode==0 and math_result['passed'] and math_result['local_environment']==self.protocol['target_environment'];results=[]
        for mode in ('serial','parallel_guarded'):
            for case in self.protocol['cases']:
                for block,arm in enumerate(('base','cache','cache','base')):results.append(self.wave(case,mode,block,arm))
        table={};passed=True;peak_ratios=[];serial_ratios=[]
        for case in self.protocol['cases']:
            idx=case['index'];ratios={}
            relevant=[r for r in results if r['case']==idx]
            for mode in ('serial','parallel_guarded'):
                by={a:[r for r in relevant if r['mode']==mode and r['arm']==a] for a in ('base','cache')}
                for a in by:assert len(by[a])==2
                ratios[mode]=math.sqrt(math.prod(r['kernel_mean_seconds'] for r in by['cache'])/math.prod(r['kernel_mean_seconds'] for r in by['base']))
                digests=[]
                for r in relevant:
                    key=r['key'];ptr=read(ROOT/'WAVE_POINTERS'/(key+'.json'));folder=ROOT/ptr['relative_dir'];digests.extend(read(p)['output_digest'] for p in folder.glob('r??.json'))
                assert len(set(digests))==1
            peak_base=max(r['max_peak_rss'] for r in relevant if r['arm']=='base');peak_cache=max(r['max_peak_rss'] for r in relevant if r['arm']=='cache');ratios['max_peak_rss']=peak_cache/peak_base
            passed=passed and ratios['serial']<=1.10 and ratios['parallel_guarded']<=.95 and ratios['max_peak_rss']<=1.;peak_ratios.append(ratios['max_peak_rss']);serial_ratios.append(ratios['serial']);table[str(idx)]=ratios
        serial_geo=math.prod(serial_ratios)**(1/3);peak_geo=math.prod(peak_ratios)**(1/3);passed=bool(passed and serial_geo<=1.05 and peak_geo<=.80);verify_freeze()
        terminal={'status':'component_passed_REVIEW_REQUIRED_NO_FORMAL_AUTO_START' if passed else 'component_failed_NO_FORMAL','passed':passed,'component_freeze_sha256':self.freeze,'per_case':table,'serial_geomean_ratio':serial_geo,'peak_geomean_ratio':peak_geo,'all_fidelity_digests_equal':True,'fixed_valid_waves':len(results),'full_optimization_runs':0,'native_evaluation_calls':0,'goal_complete':False}
        terminal.update(resource_only_amendment='RESOURCE_ONLY_AMENDMENT_A02.json',matched_case_workers=self.case_parallel,not_fixed30_when_reduced=True)
        atomic(ROOT/'COMPONENT_TERMINAL.json',terminal);self.state(terminal['status']);print(json.dumps(terminal),flush=True)

if __name__=='__main__':
    lock=(ROOT/'component_manager.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    with (ROOT/'MANAGER_UNIQUE_CLAIM.json').open('x') as f:json.dump({'pid':os.getpid(),'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())},f);f.flush();os.fsync(f.fileno())
    m=None
    try:m=Manager();m.run()
    except Exception:
        if m:m.terminate_own()
        atomic(ROOT/'COMPONENT_FAILURE.json',{'error':traceback.format_exc(),'goal_complete':False,'formal_auto_start':False});raise
