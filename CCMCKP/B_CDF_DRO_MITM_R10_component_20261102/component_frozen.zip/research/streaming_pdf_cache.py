"""Exact fixed-bucket top-k union cache for already-scored float32 rows.

No FFT, CDF scoring, evaluator, RNG, file IO, or learned/historical weights.
Keys use global surviving-child row IDs to preserve original stable ties.
"""
import numpy as np

def first_per_bucket(ids,cc,p,buckets,quota):
    ids=np.asarray(ids,np.int64)
    if not len(ids):return ids
    if p is None:order=np.lexsort((ids,cc[ids],buckets[ids]))
    else:order=np.lexsort((ids,cc[ids],-p[ids],buckets[ids]))
    ranked=ids[order];bb=buckets[ranked];positions=np.arange(len(ranked))
    starts=np.maximum.accumulate(np.where(np.r_[True,bb[1:]!=bb[:-1]],positions,0))
    return ranked[positions-starts<int(quota)]

class BucketPDFCache:
    def __init__(self,cc,width,bins):
        self.cc=np.asarray(cc,np.float64);self.width=int(width);self.bins=int(bins)
        assert self.width>=1024 and len(self.cc)>self.width and np.all(np.isfinite(self.cc))
        self.slots=self.width//512;self.middle=max(2,(self.slots+1)//2)
        self.buckets=np.minimum(511,((self.cc-self.cc.min())/max(1e-9,self.cc.max()-self.cc.min())*512).astype(int))
        self.capacity=min(len(self.cc),512*(1+self.middle+self.slots))
        self.pdf=np.empty((self.capacity,self.bins),np.float32)
        self.location=np.full(len(self.cc),-1,np.int32);self.owner=np.full(self.capacity,-1,np.int64)
        self.ids=np.empty(0,np.int64);self.next_row=0;self.rows_copied=0;self.max_rows=0

    def add(self,first,pp,p0,p1):
        first=int(first);assert first==self.next_row and pp.dtype==np.float32 and pp.ndim==2 and pp.shape[1]==self.bins
        last=first+len(pp);assert last<=len(self.cc);new=np.arange(first,last,dtype=np.int64)
        assert np.all(np.isfinite(p0[new])) and np.all(np.isfinite(p1[new]))
        union=np.r_[self.ids,new]
        keep=np.unique(np.r_[first_per_bucket(union,self.cc,None,self.buckets,1),first_per_bucket(union,self.cc,p0,self.buckets,self.middle),first_per_bucket(union,self.cc,p1,self.buckets,self.slots)])
        assert len(keep)<=self.capacity
        dropped=np.setdiff1d(self.ids,keep,assume_unique=True)
        released=self.location[dropped];self.owner[released]=-1;self.location[dropped]=-1
        entered=np.setdiff1d(keep,self.ids,assume_unique=True)
        assert np.all((entered>=first)&(entered<last))
        free=np.flatnonzero(self.owner<0)[:len(entered)];assert len(free)==len(entered)
        self.pdf[free]=pp[entered-first];self.owner[free]=entered;self.location[entered]=free
        self.ids=keep;self.next_row=last;self.rows_copied+=len(entered);self.max_rows=max(self.max_rows,len(keep))

    def take(self,ids):
        ids=np.asarray(ids,np.int64);assert self.next_row==len(self.cc) and np.all(self.location[ids]>=0)
        return self.pdf[self.location[ids]]
