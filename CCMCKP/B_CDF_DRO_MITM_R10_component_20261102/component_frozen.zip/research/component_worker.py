"""Arithmetic kernel benchmark only. No Gurobi/native/full solver execution."""
import os
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,hashlib,json,resource,sys,time,traceback
from pathlib import Path
from kernel_support import HERE,np,scipy,verify_freeze,input_case,boundary,run_kernel

def atomic(path,data):
    tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('w') as f:json.dump(data,f);f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--case',type=int,required=True);ap.add_argument('--arm',choices=['base','cache'],required=True);ap.add_argument('--rep',type=int,required=True);ap.add_argument('--started',type=float,required=True);ap.add_argument('--dir',required=True);a=ap.parse_args();folder=Path(a.dir);deadline=a.started+585.;tag='r%02d'%a.rep
    freeze=verify_freeze();protocol=json.loads((HERE/'COMPONENT_PROTOCOL.json').read_text());assert sys.platform.startswith('linux')
    assert {'numpy':np.__version__,'scipy':scipy.__version__}==protocol['target_environment']
    case,cost,groups,samples=input_case(a.case);prepared=boundary(case,cost,groups,samples,.00025,1)
    warm,_,_=run_kernel(a.arm,case,cost,groups,prepared,deadline);del warm
    atomic(folder/(tag+'.ready.json'),{'pid':os.getpid(),'freeze_sha':freeze,'elapsed':time.monotonic()-a.started})
    while not(folder/'RUN.json').exists():
        assert time.monotonic()<deadline,'Component barrier time reserve exhausted';time.sleep(.02)
    scores=[];hashes=[];metrics=[]
    for i in range(protocol['kernel_repetitions']):
        answer,seconds,stats=run_kernel(a.arm,case,cost,groups,prepared,deadline);scores.append(seconds);metrics.append(stats)
        h=hashlib.sha256()
        for x in answer:h.update(str((str(x.dtype),x.shape)).encode());h.update(x.tobytes())
        hashes.append(h.hexdigest());del answer
    assert len(set(hashes))==1
    d={'status':'completed','arm':a.arm,'case':a.case,'rep':a.rep,'component_freeze_sha256':freeze,'kernel_seconds':scores,'kernel_total_seconds':sum(scores),'output_digest':hashes[0],'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'cache_metrics':metrics,'elapsed_before_save':time.monotonic()-a.started,'native_evaluation_calls':0,'full_optimization_runs':0,'historical_solution_inputs':False,'environment':{'numpy':np.__version__,'scipy':scipy.__version__}}
    atomic(folder/(tag+'.json'),d);print(json.dumps({k:v for k,v in d.items() if k!='cache_metrics'}),flush=True)
if __name__=='__main__':main()
