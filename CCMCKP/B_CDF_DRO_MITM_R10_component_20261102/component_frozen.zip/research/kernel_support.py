"""Component-only exact AST kernels and raw-input boundary generation.

No full solver, Gurobi model, native evaluator, historical vectors or warm start.
"""
import os,sys,ast,copy,hashlib,io,json,pickle,time,zipfile
from pathlib import Path
from types import SimpleNamespace
for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
HERE=Path(__file__).resolve().parent
if os.name=='nt':sys.path.insert(0,r'E:\codex\CCMCKP_DRO_goal_20261101\research\local_deps_scipy')
import numpy as np
import scipy
from scipy.fft import irfft as packed_irfft,next_fast_len

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def verify_freeze():
    freeze=json.loads((HERE/'COMPONENT_FREEZE.json').read_text(encoding='utf-8'))
    for name,h in freeze['files'].items():assert digest(HERE/name)==h,name
    return digest(HERE/'COMPONENT_FREEZE.json')

def kernel_class(arm):
    filename={'base':'R09_frozen_baseline.py','cache':'solver_stream_cache.py'}[arm]
    tree=ast.parse((HERE/filename).read_text(encoding='utf-8'));cls=copy.deepcopy(next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='Solver'))
    cls.name='Kernel';cls.body=[x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name in ('build_half','half_prune','diverse_half_prune')]
    functions=[copy.deepcopy(x) for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in ('truncated_convolution','worst_cdf_hist')]
    env={'np':np,'time':time,'packed_irfft':packed_irfft,'next_fast_len':next_fast_len}
    exec(compile(ast.fix_missing_locations(ast.Module(body=functions+[cls],type_ignores=[])),filename,'exec'),env)
    return env['Kernel'],env['worst_cdf_hist']

def make_kernel(cls,cost,groups,bins,cap,width=None,arm='B_CDF_DRO_MITM'):
    k=cls();k.cost=np.asarray(cost,float);k.groups=[np.asarray(g,int) for g in groups];k.inst=SimpleNamespace(m=len(groups));k.bins=int(bins);k.best={'cost':float(cap)};k.arm=arm
    k.half_width=int(width if width is not None else max(1024,min(4096,(40960//len(groups))//512*512)));k.remaining=lambda:1e9
    return k

def input_case(index):
    protocol=json.loads((HERE/'COMPONENT_PROTOCOL.json').read_text(encoding='utf-8'));case=next(x for x in protocol['cases'] if x['index']==index);name=case['instance'];n=case['n']
    source=Path(protocol['local_input_zip'] if os.name=='nt' else protocol['server_input_zip']);assert digest(source)==protocol['input_zip_sha256']
    with zipfile.ZipFile(source) as z:
        prefix='benchmark/'+name+'/'
        cost=np.asarray(np.loadtxt(io.BytesIO(z.read(prefix+'cost.txt')))).reshape(-1);groups=pickle.loads(z.read(prefix+'node_to_factor.pkl'))
        samples=[np.asarray(np.loadtxt(io.BytesIO(z.read(prefix+str(j)+'_sample.txt')))).reshape(-1) for j in range(n)]
    if isinstance(groups,dict):groups=[groups[g] for g in sorted(groups,key=lambda x:int(x))]
    assert len(cost)==n and len(groups)==case['m'] and all(len(a)>=2 and np.all(np.isfinite(a)) and a.min()>=0 for a in samples)
    return case,cost,groups,samples

def boundary(case,cost,groups,samples,delta,anchor_count):
    # Own input-derived kernel boundary only, no feasibility/optimization claim.
    mu=np.array([a.mean() for a in samples]);sd=np.array([a.std(ddof=1) for a in samples]);ordered=[sorted(g,key=lambda j:(mu[j]+3*sd[j],j)) for g in groups]
    anchors=[tuple(g[0] for g in ordered)]
    if anchor_count==2:anchors.append(tuple(g[1] for g in ordered))
    cap=float(cost[list(anchors[0])].sum());chosen=list(range(0,len(groups),2))[:6];other=[g for g in range(len(groups)) if g not in chosen]
    cls,original_hist=kernel_class('base');hist=np.asarray([original_hist(a[:-1],case['tmax'],4096,delta) for a in samples],np.float64);fft=np.fft.rfft(hist,8192,axis=1)
    return cap,chosen,other,anchors,hist,fft

def run_kernel(arm,case,cost,groups,prepared,deadline=None):
    cls,_=kernel_class(arm);cap,chosen,other,anchors,hist,fft=prepared;k=make_kernel(cls,cost,groups,4096,cap)
    if deadline is not None:k.remaining=lambda:deadline-time.monotonic()
    started=time.perf_counter();result=k.build_half(chosen,other,hist,fft,anchors);elapsed=time.perf_counter()-started;assert result is not None
    metrics=getattr(k,'pdf_cache_diagnostics',[])
    return result,elapsed,metrics

def exact_equal(a,b):
    assert len(a)==len(b)==3
    for x,y in zip(a,b):assert x.dtype==y.dtype and x.shape==y.shape and np.array_equal(x,y)
