"""Frozen component math/actual-input fidelity; not official algorithm runs."""
from pathlib import Path
import argparse,json,traceback
from kernel_support import HERE,np,scipy,verify_freeze,kernel_class,make_kernel,input_case,boundary,run_kernel,exact_equal
from streaming_pdf_cache import BucketPDFCache

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',default='LOCAL_EXACT_CACHE_CHECKS.json');a=ap.parse_args()
    freeze=verify_freeze();out=HERE/a.output;assert out.parent==HERE and not out.exists();rng=np.random.default_rng(20261102);generic=[]
    cls,_=kernel_class('base')
    for width in (1024,2048,4096):
        for mode in ('single_bucket_all_ties','sparse_buckets_ties','continuous_scores'):
            n=width+137 if mode=='single_bucket_all_ties' else width*3+17
            cc=np.ones(n) if mode=='single_bucket_all_ties' else rng.integers(0,7,n).astype(float) if mode=='sparse_buckets_ties' else rng.uniform(0,100,n)
            p0=np.ones(n) if mode=='single_bucket_all_ties' else rng.integers(0,11,n)/10 if mode=='sparse_buckets_ties' else rng.random(n)
            p1=p0.copy() if mode=='single_bucket_all_ties' else rng.integers(0,11,n)/10 if mode=='sparse_buckets_ties' else rng.random(n)
            pdf=rng.random((n,3),dtype=np.float32);ids=np.arange(n,dtype=np.int64)[:,None];k=make_kernel(cls,[1.,2.],[[0],[1]],3,1000.,width)
            expected_cost,keep,_=k.half_prune(cc,p0,p1,ids,ids)
            for block in (63,640):
                cache=BucketPDFCache(cc,width,3)
                for first in range(0,n,block):cache.add(first,pdf[first:first+block],p0,p1)
                actual=cache.take(keep[:,0]);assert np.array_equal(actual,pdf[keep[:,0]]) and cache.rows_copied<=n
                generic.append({'W':width,'N':n,'mode':mode,'block':block,'kept':len(keep),'cache_high_water_rows':cache.max_rows,'copied_rows':cache.rows_copied,'bitwise_equal':True})
    # Original nonpruning path and deadline guard remain exact at boundaries.
    for arm in ('base','cache'):
        cls,histogram=kernel_class(arm);groups=[[0,1],[2,3]];cost=np.array([1.,2.,1.,2.]);hist=np.zeros((4,32));hist[:,0]=1.;fft=np.fft.rfft(hist,64,axis=1)
        for label in ('B_CDF_DRO_MITM','A4_NO_COST_DIVERSITY'):
            k=make_kernel(cls,cost,groups,32,100.,1024,label);answer=k.build_half([0],[1],hist,fft,[(0,2)]);assert len(answer[0])==2 and not getattr(k,'pdf_cache_diagnostics',[])
            k.remaining=lambda:0;assert k.build_half([0],[1],hist,fft,[(0,2)]) is None
    actual=[]
    for index in (17,38,39):
        case,cost,groups,samples=input_case(index)
        for delta in (0.,.00025,.0005):
            for anchors in (1,2):
                prepared=boundary(case,cost,groups,samples,delta,anchors);base,t0,_=run_kernel('base',case,cost,groups,prepared);candidate,t1,metrics=run_kernel('cache',case,cost,groups,prepared);exact_equal(base,candidate)
                assert metrics and all(x['inverse_rows']==x['valid_children'] and x['rows_copied_once']<=x['valid_children'] for x in metrics)
                row={'case':index,'delta':delta,'anchors':anchors,'cost_PDF_selection_bitwise_equal':True,'retained':len(base[0]),'diagnostic_kernel_seconds_base':t0,'diagnostic_kernel_seconds_cache':t1,'cache_layers':metrics};actual.append(row)
                print(json.dumps({k:v for k,v in row.items() if k!='cache_layers'}),flush=True)
    result={'passed':True,'component_freeze_sha256':freeze,'local_environment':{'numpy':np.__version__,'scipy':scipy.__version__},'generic_cases':generic,'actual_cases':actual,'scope':'Pure arithmetic/component checks, own input-derived boundaries; no native oracle or original Gurobi initialization/full optimizer run. Diagnostic times are not target ABBA admission evidence. Target Linux and parallel checks still required.','official_candidate_runs':0,'historical_solution_inputs':False}
    out.write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({'passed':True,'generic':len(generic),'actual':len(actual),'official_runs':0,'target_preflight_still_required':True}),flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        p=HERE/'LOCAL_EXACT_CACHE_FAILURE.txt'
        if not p.exists():p.write_text(traceback.format_exc(),encoding='utf-8')
        raise
