"""Verify downloaded/repository delivery bytes, source freeze, results member manifest, and Excel-vs-JSON. No optimization."""
import argparse,hashlib,json,statistics,zipfile,xml.etree.ElementTree as ET
from pathlib import Path

def digest(b):return hashlib.sha256(b).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('directory');a=ap.parse_args();r=Path(a.directory);manifest=json.loads((r/'FILE_MANIFEST.json').read_text(encoding='utf8'));checked=[]
 for rel,item in manifest.items():
  p=r/rel;assert p.is_file(),rel;b=p.read_bytes();assert digest(b)==item['sha256'] and len(b)==item['bytes'],rel;checked.append(rel)
 with zipfile.ZipFile(r/'source_frozen.zip') as z:
  f=json.loads(z.read('FREEZE.json'));assert digest(z.read('FREEZE.json'))=='f7ae776791b0b78b0be37e0f5c55d4c98b3f7613892152365971beff536060c3'
  for rel,h in f['files'].items():assert digest(z.read(rel))==h,rel
 members=0
 if (r/'results_complete.zip').exists():
  with zipfile.ZipFile(r/'results_complete.zip') as z:
   m=json.loads(z.read('EXPORT_MANIFEST.json'))
   for rel,item in m['files'].items():
    b=z.read(rel);assert len(b)==item['bytes'] and digest(b)==item['sha256'],rel
   members=len(m['files']);d=json.loads(z.read('reports/statistics_snapshot.json'))
  if (r/'statistics.xlsx').exists():verify_excel(r/'statistics.xlsx',d)
 print(json.dumps({'passed':True,'delivery_files':len(checked),'frozen_source_members':len(f['files']),'verified_results_members':members,'no_new_evaluation':True}))

def verify_excel(path,d):
 ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
 with zipfile.ZipFile(path) as z:
  ss=[]
  if 'xl/sharedStrings.xml' in z.namelist():
   ss=[''.join(x.itertext()) for x in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si',ns)]
  wb=ET.fromstring(z.read('xl/workbook.xml'));rels=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'));targets={x.attrib['Id']:x.attrib['Target'] for x in rels};sheets={}
  for s in wb.find('s:sheets',ns):
   rel=s.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'];target=targets[rel].lstrip('/');sheets[s.attrib['name']]=target if target.startswith('xl/') else 'xl/'+target
  def readsheet(name):
   cells={}
   for c in ET.fromstring(z.read(sheets[name])).findall('.//s:sheetData/s:row/s:c',ns):
    v=c.find('s:v',ns);t=c.attrib.get('t');val=None
    if t=='inlineStr':val=''.join(c.find('s:is',ns).itertext())
    elif v is not None:val=ss[int(v.text)] if t=='s' else float(v.text) if t not in ('str','e') else v.text
    assert t!='e',(name,c.attrib['r'],val);cells[c.attrib['r']]=val
   return cells
  costs=readsheet('成本与有效率');raw=readsheet('逐次终末')
  def equal(sheet,cells,cell,expected):
   actual=cells.get(cell)
   if expected is None:assert actual is None,(sheet,cell,actual,expected)
   elif isinstance(expected,(int,float)):assert actual is not None and isinstance(actual,(int,float)) and abs(actual-expected)<=max(1e-12,abs(expected)*1e-12),(sheet,cell,actual,expected)
   else:assert actual==expected,(sheet,cell,actual,expected)
  for i,row in enumerate(d['summaries'],6):
   for col,key in [('A','arm'),('B','index'),('C','instance'),('D','m'),('E','registered'),('F','terminal'),('G','valid'),('H','failed'),('I','pending'),('J','best'),('K','avg'),('L','std'),('M','CV')]:equal('成本与有效率',costs,col+str(i),row[key])
   if row['valid']!=30:assert row['avg'] is row['std'] is row['CV'] is None,'Partial official statistics not blank'
  times=readsheet('时间与目标')
  for i,row in enumerate(d['summaries'],6):
   for col,key in [('A','arm'),('B','index'),('C','valid'),('D','mean_final_best_first_seconds'),('E','best_hits'),('F','conditional_best_hit_seconds'),('G','mean_actual_runtime'),('J','target_cost'),('K','target_hits'),('L','conditional_target_seconds'),('M','restricted_target_seconds')]:equal('时间与目标',times,col+str(i),row[key])
   elapsed=[r['elapsed_upper'] for r in d['terminal_records'] if r['arm']==row['arm'] and r['index']==row['index'] and r['elapsed_upper'] is not None]
   equal('时间与目标',times,'H'+str(i),min(elapsed) if elapsed else None);equal('时间与目标',times,'I'+str(i),max(elapsed) if elapsed else None)
  for i,row in enumerate(d['terminal_records'],6):
   for col,key in [('A','arm'),('B','index'),('C','rep'),('E','valid'),('F','reason'),('G','cost'),('H','probability'),('I','found_seconds'),('J','elapsed_upper'),('K','target_time'),('L','native_calls'),('M','native_seconds'),('N','stages')]:equal('逐次终末',raw,col+str(i),row.get(key))
   equal('逐次终末',raw,'D'+str(i),832272+row['rep'])
  pair=readsheet('配对比较')
  for i,row in enumerate(d['comparisons'],6):
   for col,key in [('A','index'),('B','assessable'),('C','mean_difference'),('D','relative_mean_difference'),('E','median_difference'),('F','paired_dz'),('I','p'),('J','holm_p'),('K','reference_only_valid'),('L','candidate_only_valid'),('M','paired_validity_p')]:equal('配对比较',pair,col+str(i),row.get(key))
   ci=row.get('paired_bootstrap_95');equal('配对比较',pair,'G'+str(i),ci[0] if ci else None);equal('配对比较',pair,'H'+str(i),ci[1] if ci else None)
  quality=readsheet('共同质量目标时间')
  for i,row in enumerate(d['stage_gate']['reference_quality_times'],6):
   rb=row['arms']['B'];rc=row['arms']['R08F'];values=[row['index'],row['fixed_reference_mean_cost_target'],rb['hits'],rc['hits'],rb['conditional_seconds'],rc['conditional_seconds'],rb['restricted_seconds'],rc['restricted_seconds']]
   for col,value in zip('ABCDEFGH',values):equal('共同质量目标时间',quality,col+str(i),value)
  if d['which']=='full':
   groups=readsheet('全量分组门槛')
   for i,(label,lo,hi) in enumerate([('全部',1,999),('小组',1,5),('中组',6,20),('大组',21,999)],6):
    indices=sorted({r['index'] for r in d['summaries'] if lo<=r['m']<=hi});comps=[r for r in d['comparisons'] if r['index'] in indices and r['assessable']];ready=len(comps)==len(indices) and bool(indices)
    get=lambda arm,key:statistics.mean(r[key] for r in d['summaries'] if r['arm']==arm and r['index'] in indices)
    values=[label,len(indices),len(comps),ready,get('B','avg') if ready else None,get('R08F','avg') if ready else None,statistics.mean(r['mean_difference'] for r in comps) if ready else None,statistics.mean(r['relative_mean_difference'] for r in comps) if ready else None,sum(r['relative_mean_difference']< -1e-10 for r in comps) if ready else None,sum(r['relative_mean_difference']>1e-10 for r in comps) if ready else None,sum(abs(r['relative_mean_difference'])<=1e-10 for r in comps) if ready else None]
    for col,value in zip('ABCDEFGHIJK',values):equal('全量分组门槛',groups,col+str(i),value)
if __name__=='__main__':main()
