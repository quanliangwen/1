"""Extra offline reserve-clock audit. No evaluator imports, draws, or solver launches."""
import argparse,gzip,json,sys,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from common import read,atomic,check_freeze

def review(rows):
 result=[]
 for rec in rows:
  folder=Path(rec['wave']);rep=rec['rep'];d=json.loads(gzip.decompress((folder/('r%02d.json.gz'%rep)).read_bytes()));cfg=d['config'];assert cfg['time_budget']==600 and cfg['work_reserve']==15
  native=d['native_observations'];last=max((o['elapsed'] for o in native),default=0);best=d['selected']['found_seconds'] if d['selected'] else None;outer=read(folder/'TIMING_JOURNAL.json').get(str(rep));assert outer is not None and outer<=600
  result.append({'arm':rec['arm'],'index':rec['index'],'rep':rep,'last_native_end_seconds':last,'final_best_first_seconds':best,'last_native_past_planned585_seconds':max(0.,last-585),'external_inclusive_saved_seconds':outer,'native_calls':len(native)})
 groups={}
 for arm in sorted(set(x['arm'] for x in result)):
  subset=[x for x in result if x['arm']==arm];groups[arm]={'records':len(subset),'max_last_native_end':max(x['last_native_end_seconds'] for x in subset),'native_end_past585_runs':sum(x['last_native_end_seconds']>585 for x in subset),'max_external':max(x['external_inclusive_saved_seconds'] for x in subset)}
 return {'freeze_sha':check_freeze(),'scope':'Postprocessing original clock records only. Plannedworkdeadline585/reserve15 checked; disclose any native-call end beyond planned deadline separately, do not silently redefine validity gates or infer call begin times from call end records. No new oracle samples.','by_arm':groups,'rows':result,'actual_total_600_all_passed':all(x['external_inclusive_saved_seconds']<=600 for x in result)}

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--snapshot');ap.add_argument('--cases',nargs='+',type=int);ap.add_argument('--out',required=True);a=ap.parse_args();rows=[]
 if a.snapshot:rows=read(a.snapshot)['terminal_records']
 else:
  for idx in a.cases:
   ref=Path(read(ROOT/'REFERENCE_REGISTRY.json')['waves'][str(idx)]['directory']);p=read(ROOT/'WAVE_POINTERS'/('R08F_pilot_c%02d.json'%idx));candidate=ROOT/p['relative_dir']
   for arm,folder in [('B',ref),('R08F',candidate)]:
    assert read(folder/'WAVE.json')['status'] in ('valid_complete','ordinary_failure_complete');rows.extend(dict(x,index=idx,arm=arm,wave=str(folder)) for x in read(folder/'AUDIT.json'))
 out=Path(a.out);assert not out.exists();result=review(rows);atomic(out,result);print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
