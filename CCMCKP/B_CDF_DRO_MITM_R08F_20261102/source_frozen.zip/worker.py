"""One fresh run; start clock supplied before Popen by campaign controller."""
import argparse,os,random,signal,sys,time
from pathlib import Path
from common import ROOT,PROJECT,read,sha,atomic,check_freeze
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--arm',required=True);ap.add_argument('--case',type=int,required=True);ap.add_argument('--rep',type=int,required=True);ap.add_argument('--started',type=float,required=True);ap.add_argument('--dir',required=True)
    a=ap.parse_args()
    signal.signal(signal.SIGALRM,lambda *_:os._exit(124))
    signal.setitimer(signal.ITIMER_REAL,max(.001,a.started+600-time.monotonic()))
    wave=Path(a.dir).resolve()
    atomic(wave/('r%02d.ready.json'%a.rep),{'pid':os.getpid(),'rep':a.rep})
    while not (wave/'START.json').exists():time.sleep(.01)
    reg=read(ROOT/'PROTOCOL.json');assert a.arm in reg['arms'] and 1<=a.rep<=30
    freeze=check_freeze();case=next(x for x in reg['cases'] if x['index']==a.case)
    src=(ROOT/'sources'/a.arm).resolve();data=(PROJECT/'benchmark'/case['instance']).resolve();out=Path(a.dir).resolve()/('r%02d.json.gz'%a.rep)
    inputs=read(ROOT/'INPUTS.json');registered={Path(k).resolve():h for k,h in inputs.items() if Path(k).parent.resolve()==data}
    assert len(registered)==case['n']+2
    for p,h in registered.items():
        if p.is_symlink() or sha(p)!=h:raise RuntimeError('input SHA mismatch: '+str(p))
    allowed=set(registered)|{p.resolve() for p in src.glob('*.py')}|{(ROOT/'PROTOCOL.json').resolve(),(ROOT/'INPUTS.json').resolve()}
    own={out,out.with_name(out.name+'.tmp'),out.with_name(out.name+'.worker.json'),out.with_name(out.name+'.worker.json.tmp'),out.parent}
    observed=set()
    def guard(event,args):
        if event!='open' or not isinstance(args[0],(str,bytes,os.PathLike)):return
        p=Path(os.fsdecode(args[0])).resolve()
        if PROJECT==p or PROJECT in p.parents:
            if p not in allowed and p not in own:raise PermissionError('historical/cross-run/unregistered read: '+str(p))
            observed.add(str(p))
    sys.addaudithook(guard);sys.path.insert(0,str(src))
    import numpy as np
    from instance import load_instance
    from solver import Solver
    import scipy,gurobipy
    environment={'python':sys.version.split()[0],'numpy':np.__version__,'scipy':scipy.__version__,'gurobi':list(gurobipy.gurobi.version()),'executable':str(Path(sys.executable).resolve())}
    if environment!=reg['environment']:raise RuntimeError('Runtime environment changed')
    seed=832272+a.rep;random.seed(seed);np.random.seed(seed)
    inst=load_instance(data);solver=Solver(inst,case['tmax'],seed,600,out,a.started,'B_CDF_DRO_MITM')
    solver.run()
    if solver.best is not None:
        ids=inst.validate_selection(solver.best['selection']);assert abs(inst.selection_cost(ids)-solver.best['cost'])<1e-8
    atomic(out.with_name(out.name+'.worker.json'),dict(arm=a.arm,index=a.case,rep=a.rep,seed=seed,selected=solver.best,freeze_sha=freeze,protocol_sha=sha(ROOT/'PROTOCOL.json'),input_registry_sha=sha(ROOT/'INPUTS.json'),elapsed_before_worker_sidecar=time.monotonic()-a.started,project_paths_opened=sorted(observed),independent_initialization=True,prior_count=0,no_cross_seed_weights=True,environment=environment))
if __name__=='__main__':main()
