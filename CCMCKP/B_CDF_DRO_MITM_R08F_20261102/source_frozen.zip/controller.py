"""Detached, singleton, immutable-wave campaign. Goal gates, not queue exhaustion."""
import argparse,fcntl,gzip,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path
ENV=dict(os.environ,OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
from common import ROOT,PROJECT,read,sha,atomic,event,check_freeze,mem_available,process_table,descendants_rss,envelope
from audit_campaign import audit_wave,audit_run

class Controller:
    def __init__(self):
        self.reg=read(ROOT/'PROTOCOL.json');self.active={};self.peak={};self.completed=0;self.status='initializing'
        self.reference_registry=read(ROOT/'REFERENCE_REGISTRY.json')
        legacy=self.reference_registry['old_controller'];previous_root=legacy['root'];table=process_table();row=table.get(legacy['pid'])
        if row and row['start_ticks']==legacy['start_ticks']:
            raise RuntimeError('Old controller is still live: no second 30-wave controller')
        if any('worker.py' in r['cmd'] and previous_root in r['cmd'] for r in table.values()):
            raise RuntimeError('Old campaign has live workers')
        for pid,r in table.items():
            if 'controller.py' in r['cmd']:
                try:cwd=(Path('/proc')/str(pid)/'cwd').resolve()
                except OSError:continue
                if str(cwd)==previous_root:
                    raise RuntimeError('Verified old controller cwd is still live')

        self.freeze=check_freeze();self.guard_floor=5*2**30;self.disk_floor=3*2**30
        self.lock=(ROOT/'controller.lock').open('a+')
        fcntl.flock(self.lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        self.lock.seek(0);self.lock.truncate();self.lock.write(str(os.getpid()));self.lock.flush();os.fsync(self.lock.fileno())
        self.ticks=process_table()[os.getpid()]['start_ticks']
        self.foreign_start=0
        for idx,e in self.reference_registry['waves'].items():
            case=next(c for c in self.reg['cases'] if c['index']==int(idx));self.peak[case['instance']]=max(self.peak.get(case['instance'],0),e['peak_worker_rss'])
        self.state('preflight_verified',latest_preflight=read(ROOT/'PREFLIGHT.json'))
    def state(self,status,**kwargs):
        self.status=status;d=dict(schema='B_DRO_goal_campaign_v1',status=status,controller_pid=os.getpid(),controller_start_ticks=self.ticks,freeze_sha=self.freeze,updated_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),registered_parallel=self.reg['parallel'],active=list(self.active),goal_achieved=False,**kwargs)
        atomic(ROOT/'STATE.json',d);atomic(ROOT/'CURRENT_POINTER.json',dict(root=str(ROOT),state='STATE.json',controller_pid=os.getpid(),controller_start_ticks=self.ticks,freeze_sha=self.freeze,status=status))
    def resource_ready(self,case):
        table=process_table();available=mem_available();foreign=sum(r['rss'] for pid,r in table.items() if str(ROOT) not in r['cmd'])
        # Include an allowance for ongoing foreign growth; worker bound already
        # covers later full beam expansion, not just instantaneous RSS.
        foreign_growth=max(2*2**30,foreign//2,max(0,foreign-self.foreign_start))
        each=max(envelope(case),int(self.peak.get(case['instance'],0)*1.25))
        need=self.reg['parallel']*each+self.guard_floor+foreign_growth
        stat=os.statvfs(ROOT);disk=stat.f_bavail*stat.f_frsize
        return available>=need and disk>=self.disk_floor,dict(available_bytes=available,required_bytes=need,worker_future_bound=each,foreign_growth_reserve=foreign_growth,free_disk_bytes=disk)
    def terminal(self,job,reason):
        job['p'].wait();job['log'].flush();os.fsync(job['log'].fileno());job['log'].close()
        out=job['dir']/('r%02d.json.gz'%job['rep']);side=out.with_name(out.name+'.worker.json')
        d={'rep':job['rep'],'pid':job['p'].pid,'returncode':job['p'].returncode,'reason':reason,'elapsed_before_terminal_save':time.monotonic()-job['started'],'record_sha':sha(out) if out.exists() else None,'worker_sha':sha(side) if side.exists() else None,'started_monotonic':job['started']}
        path=job['dir']/('r%02d.terminal.json'%job['rep']);atomic(path,d)
        # Final official audit bound is stored in the wave journal after all run
        # result/log/sidecar/terminal bytes have been fsynced.
        d['elapsed_upper']=time.monotonic()-job['started'];job['terminal']=d
        self.completed+=1
    def reuse(self,phase,case,arm):
        pointer=ROOT/'WAVE_POINTERS'/('%s_c%02d.json'%(phase,case['index']))
        if arm=='B':
            entry=self.reference_registry['waves'][str(case['index'])];folder=Path(entry['directory']);rows=audit_wave(folder,case,arm)
            assert all(r['valid'] for r in rows)
            if pointer.exists():assert Path(read(pointer)['relative_dir']).resolve()==folder.resolve()
            else:atomic(pointer,dict(phase=phase,index=case['index'],arm=arm,attempt=0,relative_dir=str(folder),external_registered_reference=True))
            self.peak[case['instance']]=max(self.peak.get(case['instance'],0),entry['peak_worker_rss']);event('reuse_valid_B_no_new_run',index=case['index'],directory=str(folder));return rows
        folder=ROOT/read(pointer)['relative_dir'];rows=audit_wave(folder,case,arm);assert all(r['valid'] for r in rows);return rows
    def wave(self,phase,case,arm):
            pointer=ROOT/'WAVE_POINTERS'/('%s_c%02d.json'%(phase,case['index']));attempt=1
            if arm=='B' and str(case['index']) in self.reference_registry['waves']:return self.reuse(phase,case,arm)
            if pointer.exists():
                prev=read(pointer);folder=ROOT/prev['relative_dir'];meta=read(folder/'WAVE.json')
                if meta['status']=='valid_complete':return self.reuse(phase,case,arm)
                if meta['status']=='ordinary_failure_complete':return audit_wave(folder,case,arm)
                if meta['status'] not in ('resource_interrupted','infrastructure_incomplete'):raise RuntimeError('Refuse to resume an unverified previous wave')
                attempt=prev['attempt']+1
            ceiling=min(self.reg['parallel'],24 if envelope(case)>=3*2**30 else 30)
            while True:
                chosen=0
                for n in range(ceiling,0,-1):
                    ready,ticket=self.ticket(case,n)
                    if ready:chosen=n;break
                if chosen:break
                self.state('waiting_resources_reduced_parallel',phase=phase,index=case['index'],resources=ticket);self.event('resource_wait',phase=phase,index=case['index'],**ticket);time.sleep(30)
            check_freeze();directory=ROOT/'waves'/('%s_c%02d_a%02d'%(phase,case['index'],attempt));directory.mkdir(parents=True,exist_ok=False)
            with (directory/'launch.lock').open('x') as f:f.write('one amended wave only\n');f.flush();os.fsync(f.fileno())
            atomic(pointer,dict(phase=phase,index=case['index'],arm=arm,attempt=attempt,relative_dir=directory.relative_to(ROOT).as_posix(),execution_freeze_sha=self.freeze))
            meta=dict(phase=phase,index=case['index'],arm=arm,attempt=attempt,status='running',workers=30,parallel_limit=chosen,parallel_ceiling=ceiling,execution_freeze_sha=self.freeze,freeze_sha=self.freeze,resources_at_dispatch=ticket)
            atomic(directory/'WAVE.json',meta);self.event('wave_start',**meta)
            pending=list(range(1,31));jobs=[];interrupted=False;last_sample=0;last_observation=0
            def launch(rep,tkt):
                log=(directory/('r%02d.log'%rep)).open('x');started=time.monotonic();p=subprocess.Popen([sys.executable,'-B',str(ROOT/'worker.py'),'--arm',arm,'--case',str(case['index']),'--rep',str(rep),'--started',str(started),'--dir',str(directory)],env=ENV,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                j=dict(rep=rep,p=p,log=log,dir=directory,started=started,parallel_limit=chosen,ticket=tkt);jobs.append(j);self.active[p.pid]=j
            try:
                for _ in range(chosen):launch(pending.pop(0),ticket)
                until=time.monotonic()+20
                while sum((directory/('r%02d.ready.json'%j['rep'])).exists() for j in jobs)<chosen:
                    if time.monotonic()>until or any(j['p'].poll() is not None for j in jobs):raise RuntimeError('Reduced initial barrier failed')
                    time.sleep(.01)
                atomic(directory/'START.json',dict(ready=chosen,release_monotonic=time.monotonic(),parallel_amendment=True))
                self.state('running_wave',phase=phase,index=case['index'],arm=arm,wave=directory.name,parallel_limit=chosen)
                while pending or self.active:
                    now=time.monotonic()
                    if now-last_sample>=1:
                        table=process_table();last_sample=now;self.peak[case['instance']]=max(self.peak.get(case['instance'],0),max((descendants_rss([pid],table) for pid in self.active),default=0))
                        st=os.statvfs(ROOT)
                        if mem_available()<5*2**30 or st.f_bavail*st.f_frsize<1*2**30:
                            interrupted=True;pending=[];self.event('resource_emergency_wave_invalid',wave=directory.name,available=mem_available())
                            for pid in list(self.active):
                                try:os.killpg(pid,signal.SIGKILL)
                                except ProcessLookupError:pass
                        if now-last_observation>=30:
                            last_observation=now;self.event('resource_observation',wave=directory.name,actual_active_workers=sum(pid in table for pid in self.active),own_rss=descendants_rss(self.active,table),available_bytes=mem_available(),loadavg=list(os.getloadavg()),cpu_count=os.cpu_count(),foreign_rss=sum(v['rss'] for v in table.values() if str(ROOT) not in v['cmd']))
                    for pid,j in list(self.active.items()):
                        if j['p'].poll() is not None:
                            self.terminal(j,'resource_interruption' if interrupted else ('returned' if j['p'].returncode==0 else 'worker_error'));del self.active[pid]
                        elif now-j['started']>=600:
                            try:os.killpg(pid,signal.SIGKILL)
                            except ProcessLookupError:pass
                            self.terminal(j,'hard_600s_timeout');del self.active[pid]
                    while pending and len(self.active)<chosen and not interrupted:
                        ready,tkt=self.ticket(case,len(self.active)+1)
                        if not ready:break
                        launch(pending.pop(0),tkt)
                    if pending and not self.active:
                        self.state('waiting_refill_resources',phase=phase,index=case['index'],arm=arm,wave=directory.name,parallel_limit=chosen,resources=tkt)
                    time.sleep(.1)
            except Exception:
                for pid,j in list(self.active.items()):
                    if j['p'].poll() is None:
                        try:os.killpg(pid,signal.SIGKILL)
                        except ProcessLookupError:pass
                    self.terminal(j,'controller_infrastructure_interruption');del self.active[pid]
                atomic(directory/'TIMING_JOURNAL.json',{str(j['rep']):j['terminal']['elapsed_upper'] for j in jobs});meta.update(status='infrastructure_incomplete',terminal=len(jobs));atomic(directory/'WAVE.json',meta);raise
            atomic(directory/'TIMING_JOURNAL.json',{str(j['rep']):j['terminal']['elapsed_upper'] for j in jobs})
            if interrupted:
                rows=[audit_run(directory,r,case,arm) for r in range(1,31)]
                rows=[dict(x or {'rep':r,'cost':None,'elapsed_upper':None,'target_time':None},valid=False,reason='resource_invalid_entire_wave') for r,x in enumerate(rows,1)]
                status='resource_interrupted'
            else:
                rows=audit_wave(directory,case,arm);status='valid_complete' if all(x['valid'] for x in rows) else 'ordinary_failure_complete'
            meta.update(status=status,valid=sum(x['valid'] for x in rows),terminal=len(jobs),peak_worker_rss=self.peak[case['instance']]);atomic(directory/'AUDIT.json',rows);atomic(directory/'WAVE.json',meta);self.event('wave_terminal',**meta);self.state('wave_terminal',latest_wave=meta)
            if interrupted:return self.wave(phase,case,arm)
            return rows

    def ticket(self,case,count,table=None):
            table=table or process_table();foreign=sum(v['rss'] for v in table.values() if str(ROOT) not in v['cmd']);growth=max(2*2**30,foreign//2,max(0,foreign-self.foreign_start));each=max(envelope(case),int(self.peak.get(case['instance'],0)*1.25));own=descendants_rss(self.active,table);available=mem_available();st=os.statvfs(ROOT);disk=st.f_bavail*st.f_frsize;required=count*each+5*2**30+growth
            return available>=required and disk>=3*2**30,dict(available_bytes=available,own_active_rss=own,own_rss_used_as_admission_credit=False,required_bytes=required,worker_future_bound=each,foreign_growth_reserve=growth,free_disk_bytes=disk,admitted_concurrency=count)

    def event(self,name,**kwargs):
        event(name,**kwargs)
    def comparison(self,stage,which):
        from statistics_campaign import summary,paired,holm
        indices=self.reg['pilot_cases'] if which=='pilot' else list(range(1,41));ss=[];cc=[];allrows={};reference_quality_times=[]
        for idx in indices:
            case=next(c for c in self.reg['cases'] if c['index']==idx);pair={}
            for arm in self.reg['arms']:
                phase='reference' if arm=='B' else stage+'_'+which
                ptr=read(ROOT/'WAVE_POINTERS'/('%s_c%02d.json'%(phase,idx)));rows=audit_wave(ROOT/ptr['relative_dir'],case,arm)
                pair[arm]=rows;ss.append(dict(arm=arm,index=idx,instance=case['instance'],m=case['m'],**summary(rows)))
            comp=paired(pair['B'],pair['R08F'],20261101+idx);comp['index']=idx;cc.append(comp);allrows[str(idx)]=pair
            if all(len(v)==30 and all(r['valid'] for r in v) for v in pair.values()):
                threshold=sum(r['cost'] for r in pair['B'])/30
                by_arm={}
                for arm,records in pair.items():
                    times=[]
                    for r in records:
                        hits=[e['elapsed'] for e in r['incumbent_path'] if e['cost']<=threshold+1e-8]
                        times.append(min(hits) if hits else None)
                    observed=[t for t in times if t is not None]
                    by_arm[arm]={'hits':len(observed),'conditional_seconds':sum(observed)/len(observed) if observed else None,'restricted_seconds':sum(t if t is not None else 600. for t in times)/30}
                reference_quality_times.append({'index':idx,'fixed_reference_mean_cost_target':threshold,'arms':by_arm,'scope':'Predeclared R08F auxiliary time metric; no threshold is input to a search worker, original raw-cost target retained.'})
        holm(cc);valid=all(s['valid']==30 for s in ss);ratios=[c.get('relative_mean_ratio') for c in cc]
        gate=valid and all(r<=1+1e-10 for r in ratios) and sum(ratios)/len(ratios)<1-1e-10 if which=='pilot' else False
        mean_std_B=sum(x['std'] for x in ss if x['arm']=='B')/len(indices) if valid else None
        mean_std_C=sum(x['std'] for x in ss if x['arm']=='R08F')/len(indices) if valid else None
        mean_CV_B=sum(x['CV'] for x in ss if x['arm']=='B')/len(indices) if valid else None
        mean_CV_C=sum(x['CV'] for x in ss if x['arm']=='R08F')/len(indices) if valid else None
        mean_time_B=sum(x['arms']['B']['restricted_seconds'] for x in reference_quality_times)/len(indices) if valid else None
        mean_time_C=sum(x['arms']['R08F']['restricted_seconds'] for x in reference_quality_times)/len(indices) if valid else None
        stability=bool(valid and mean_std_C<=mean_std_B+1e-8 and mean_CV_C<=mean_CV_B+1e-10)
        time_gate=bool(valid and mean_time_C<=mean_time_B+1e-8)
        cost_gate=gate;full_cost=None
        if which=='full':
            complete=valid and all(c['assessable'] for c in cc);gr={};ga={}
            for name,lo,hi in [('small',1,5),('medium',6,20),('large',21,999)]:
                sub=[c for c in cc if lo<=next(x for x in self.reg['cases'] if x['index']==c['index'])['m']<=hi]
                gr[name]=sum(c['relative_mean_difference'] for c in sub)/len(sub) if complete else None
                ga[name]=sum(c['mean_difference'] for c in sub)/len(sub) if complete else None
            relative=sum(c['relative_mean_difference'] for c in cc)/40 if complete else None
            absolute=sum(c['mean_difference'] for c in cc)/40 if complete else None
            better=sum(c.get('relative_mean_difference',0)<-1e-10 for c in cc if c['assessable']);worse=sum(c.get('relative_mean_difference',0)>1e-10 for c in cc if c['assessable'])
            focused=bool(complete and all(c['relative_mean_difference']<=1e-10 for c in cc if c['index'] in (17,38,39)))
            cost_gate=bool(complete and focused and better>worse and relative<0 and absolute<0 and all(x<=1e-10 for x in list(gr.values())+list(ga.values())))
            full_cost=dict(overall_mean_relative=relative,overall_mean_cost_difference=absolute,improved_cases=better,degraded_cases=worse,size_groups_mean_relative=gr,size_groups_mean_cost_difference=ga,focused_regressions_absent=focused)
        gate=bool(cost_gate and stability and time_gate)
        result=dict(stage=stage,which=which,all_valid=valid,summaries=ss,comparisons=cc,reference_quality_times=reference_quality_times,performance_gate=gate,cost_gate=cost_gate,full_cost_checks=full_cost,stability_gate=stability,time_gate=time_gate,mean_case_std={'B':mean_std_B,'R08F':mean_std_C},mean_case_CV={'B':mean_CV_B,'R08F':mean_CV_C},mean_restricted_common_target_seconds={'B':mean_time_B,'R08F':mean_time_C},coverage_cases=len(indices),total_cases=40,negative_cases=[c['index'] for c in cc if c.get('relative_mean_difference',0)>1e-10],selection_limitations='Pilot and full use the same benchmark suite and mandated seed set. Full runs are fresh executions, not unseen data or independent algorithm selection. Do not interpret bootstrap intervals as selection-adjusted confirmation.')
        atomic(ROOT/'summaries'/('%s_%s.json'%(stage,which)),result);return result
    def run(self):
        assert read(ROOT/'PREFLIGHT.json')['passed'] is True
        assert read(ROOT/'PREFLIGHT.json')['freeze_sha']==self.freeze
        for k,idx in enumerate(self.reg['pilot_cases']):
            case=next(c for c in self.reg['cases'] if c['index']==idx)
            for arm in ('B','R08F') if k%2==0 else ('R08F','B'):
                self.wave('reference' if arm=='B' else 'R08F_pilot',case,arm)
        pilot=self.comparison('R08F','pilot')
        if not pilot['performance_gate']:
            self.state('pilot_failed_requires_diagnosis',pilot_summary='summaries/R08F_pilot.json');event('pilot_failed_no_full_expansion');return
        # Fresh audit subprocess has no controller state and does no new native MC.
        audit=subprocess.run([sys.executable,'-B',str(ROOT/'audit_campaign.py'),'--stage','R08F','--which','pilot'],capture_output=True,text=True)
        atomic(ROOT/'audits'/'pilot_subprocess.json',dict(returncode=audit.returncode,stdout=audit.stdout,stderr=audit.stderr))
        if audit.returncode or not read(ROOT/'audits/R08F_pilot_independent.json')['all_30_valid']:
            self.state('pilot_integrity_audit_failed_no_expansion');return
        self.state('pilot_passed_independent_audit_passed');event('full_stage_authorized_by_predeclared_gates')
        # Reuse all40 pinned valid B waves; no new B execution.
        for case in self.reg['cases']:
            self.wave('reference',case,'B')
        # Explicitly new 1200 candidate runs; no pilot records mixed in.
        for case in self.reg['cases']:
            self.wave('R08F_full',case,'R08F')
        result=self.comparison('R08F','full')
        audit=subprocess.run([sys.executable,'-B',str(ROOT/'audit_campaign.py'),'--stage','R08F','--which','full'],capture_output=True,text=True)
        atomic(ROOT/'audits/full_subprocess.json',dict(returncode=audit.returncode,stdout=audit.stdout,stderr=audit.stderr))
        achieved=bool(result['performance_gate'] and audit.returncode==0 and read(ROOT/'audits/R08F_full_independent.json')['all_30_valid'])
        final=dict(result['full_cost_checks'],cost_gate=result['cost_gate'],stability_gate=result['stability_gate'],time_gate=result['time_gate'],mean_case_std=result['mean_case_std'],mean_case_CV=result['mean_case_CV'],mean_restricted_common_target_seconds=result['mean_restricted_common_target_seconds'],performance_gates_passed=achieved,all_valid=result['all_valid'],independent_audit_returncode=audit.returncode,all_runtime_and_SHA_checked=(audit.returncode==0))
        atomic(ROOT/'FINAL_GATE.json',final);self.state('performance_gates_passed_delivery_pending' if achieved else 'full_failed_requires_new_mechanism',final_gate=final)
        event('objective_check',**final)

if __name__=='__main__':
    c=None
    try:c=Controller();c.run()
    except Exception as exc:
        traceback.print_exc()
        if c:
            for pid,j in list(c.active.items()):
                if j['p'].poll() is None:
                    try:os.killpg(pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                try:c.terminal(j,'controller_infrastructure_interruption')
                except Exception:traceback.print_exc()
            c.state('controller_error_not_complete',error=repr(exc));event('controller_error',error=repr(exc))
        raise
