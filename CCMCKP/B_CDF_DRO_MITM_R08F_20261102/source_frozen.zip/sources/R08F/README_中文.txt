这是R07候选源码，不是B对照。唯一B对照完整保留在../B，原上传14成员逐字节一致。
R07保留R04熵风险提案和R06有限支撑FFT实现，只新增联合两组CDF消息交换。实际代码、参数、理论及验收见任务根目录机制与验收.txt、PROTOCOL.json与FREEZE.json。
内部构造arm=B_CDF_DRO_MITM沿用原B分支；worker.sidecar.arm和源目录R07标识候选版本。原生评价器4依赖字节不变，门槛.99/预筛.975/M1m与随机流规则不变。
正式入口为根目录advance.py，原便利runner仅供单次调试，不能替代带真实计时/冻结/I-O守卫的正式worker。
original_experiment只作原包源码/协议溯源，绝不恢复其任务。有限CDF扰动半径未统计覆盖校准，不声称全局最优或未知分布覆盖。
