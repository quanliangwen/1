"""All statistical outputs distinguish conditional results from official n=30."""
import itertools,math
import numpy as np
def summary(rows):
    good=[r for r in rows if r['valid']];costs=np.array([r['cost'] for r in good],float)
    d={'registered':30,'terminal':len(rows),'valid':len(good),'failed':sum(not r['valid'] for r in rows),'pending':30-len(rows),'failure_reasons':{}}
    for r in rows:
        if not r['valid']:d['failure_reasons'][r['reason']]=d['failure_reasons'].get(r['reason'],0)+1
    official=len(good)==30;d.update(best=float(costs.min()) if len(costs) else None,avg=float(costs.mean()) if official else None,std=float(costs.std(ddof=1)) if official else None,CV=float(costs.std(ddof=1)/costs.mean()) if official and costs.mean()!=0 else None,conditional_avg=float(costs.mean()) if len(costs) else None)
    hits=[r for r in good if abs(r['cost']-d['best'])<=1e-8] if len(good) else []
    d.update(mean_final_best_first_seconds=float(np.mean([r['found_seconds'] for r in good])) if good else None,best_hits=len(hits),conditional_best_hit_seconds=float(np.mean([r['found_seconds'] for r in hits])) if hits else None,mean_actual_runtime=float(np.mean([r['elapsed_upper'] for r in rows])) if rows else None,target_hits=sum(r['target_time'] is not None for r in good),conditional_target_seconds=float(np.mean([r['target_time'] for r in good if r['target_time'] is not None])) if any(r['target_time'] is not None for r in good) else None,restricted_target_seconds=float(np.mean([r['target_time'] if r['valid'] and r['target_time'] is not None else 600. for r in rows])) if rows else None)
    return d
def paired(a,b,seed=20261101):
    # a=reference, b=candidate; require all 30 valid, no penalty costs.
    aa={r['rep']:r for r in a};bb={r['rep']:r for r in b}
    common=set(aa)&set(bb);ab=sum(aa[i]['valid'] and not bb[i]['valid'] for i in common);ba=sum(bb[i]['valid'] and not aa[i]['valid'] for i in common);n=ab+ba
    validity={'reference_only_valid':ab,'candidate_only_valid':ba,'paired_validity_p':min(1.,2*sum(math.comb(n,k) for k in range(min(ab,ba)+1))/2**n) if n else 1.}
    if len(aa)!=30 or len(bb)!=30 or any(not r['valid'] for r in list(aa.values())+list(bb.values())):return {'assessable':False,'p':None,**validity}
    x=np.array([aa[i]['cost'] for i in range(1,31)]);y=np.array([bb[i]['cost'] for i in range(1,31)]);d=y-x;nz=d[np.abs(d)>1e-8];obs=abs(float(nz.sum()))
    rng=np.random.default_rng(seed)
    if not len(nz):p=1.
    elif len(nz)<=20:
        extreme=0;total=2**len(nz)
        for first in range(0,total,4096):
            ids=np.arange(first,min(first+4096,total),dtype=np.uint32)
            signs=2*((ids[:,None]>>np.arange(len(nz)))&1).astype(float)-1
            extreme+=int(np.sum(np.abs(signs@nz)>=obs-1e-10))
        p=extreme/total
    else:
        extreme=1
        for first in range(0,99999,4096):
            signs=rng.integers(0,2,size=(min(4096,99999-first),len(nz)))*2-1
            extreme+=int(np.sum(np.abs(signs@nz)>=obs-1e-10))
        p=extreme/100000
    samples=np.empty(19999)
    for first in range(0,len(samples),2048):
        ix=rng.integers(0,30,size=(min(2048,len(samples)-first),30));samples[first:first+len(ix)]=d[ix].mean(axis=1)
    return {'assessable':True,'p':float(p),'mean_difference':float(d.mean()),'relative_mean_difference':float(y.mean()/x.mean()-1),'median_difference':float(np.median(d)),'paired_dz':float(d.mean()/d.std(ddof=1)) if d.std(ddof=1)>0 else None,'paired_bootstrap_95':list(map(float,np.quantile(samples,[.025,.975]))),'relative_mean_ratio':float(y.mean()/x.mean()),**validity}
def holm(comparisons):
    order=sorted(range(len(comparisons)),key=lambda i:comparisons[i].get('p') if comparisons[i].get('p') is not None else 1.)
    old=0.
    for k,i in enumerate(order):
        p=comparisons[i].get('p');old=max(old,min(1.,(len(order)-k)*(p if p is not None else 1.)))
        comparisons[i]['holm_p']=old if p is not None else None
