"""Post-freeze all-entry CDF matrix algebra and unchanged-original invariants."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
import ast,sys,json,time
import numpy as np
from common import ROOT,read,sha,atomic,check_freeze

def main():
 freeze=check_freeze();assert not (ROOT/'MATH_PREFLIGHT.json').exists();sys.path.insert(0,str(ROOT/'sources/R08F'))
 from solver import joint_pair_cdf_scores,truncated_convolution,worst_cdf_hist
 rng=np.random.default_rng(20261102);checks=[]
 from scipy.fft import irfft as packed_irfft
 inverse_checks=[]
 for n in [1,2,3,8,16,64,5000,5400,5832,6000,8192]:
  for mode in ['random','zero','boundary']:
   x=rng.random((3,n));x[:]=0 if mode=='zero' else x
   if mode=='boundary':x[:]=0;x[:,-1]=1
   freq=np.fft.rfft(x,n,axis=1);y=packed_irfft(freq,n,axis=1,workers=1);old_inverse=np.fft.irfft(freq,n,axis=1)
   error=float(max(np.max(abs(y-old_inverse)),np.max(abs(y-x))));assert error<=1e-12
   inverse_checks.append(dict(N=n,mode=mode,max_error=error))
 for B in (1,2,3,8,16,64,4096):
  for mode in ('random','zero','boundary'):
   comp=rng.random(B);comp/=max(1.,comp.sum());comp*=.8
   a=rng.random((3,B));a/=np.maximum(1.,a.sum(axis=1,keepdims=True));b=rng.random((2,B));b/=np.maximum(1.,b.sum(axis=1,keepdims=True));b*=.9
   if mode=='zero':comp[:]=0
   if mode=='boundary':comp[:]=0;comp[-1]=1;a[:]=0;a[:,0]=1;b[:]=0;b[:,0]=1
   q=joint_pair_cdf_scores(comp,a,b,B);qcached=joint_pair_cdf_scores(comp,a,b,B,left_fft=np.fft.rfft(a,2*B,axis=1));assert np.array_equal(q,qcached)
   expected=np.array([[np.convolve(np.convolve(comp,x),y)[:B].sum() for y in b] for x in a]);err=float(np.max(abs(q-expected)));assert err<=1e-12
   checks.append({'B':B,'mode':mode,'entries':q.size,'max_direct_coefficient_error':err})
 # Tiny empirical finite support/radius cases, including mass above strict T.
 arrays=[np.array([0.,.2,.8,1.2]),np.array([.1,.5,.9,1.1]),np.array([0.,.3,.7,1.5])]
 for delta in (0.,.00025,.0005):
  B=16;h=[worst_cdf_hist(x,1.,B,delta) for x in arrays];left=np.array([h[0],h[1]]);right=np.array([h[1],h[2]]);q=joint_pair_cdf_scores(h[2],left,right,B)
  for i in range(2):
   for j in range(2):
    brute=sum(float(h[2][k]*left[i,u]*right[j,v]) for k in range(B) for u in range(B) for v in range(B) if k+u+v<B);assert abs(q[i,j]-brute)<1e-12
  checks.append({'B':B,'delta':delta,'entries':4,'explicit_three_variable_coefficient_enumeration':True})
 def parsed(p):
  t=ast.parse(p.read_text());cl=next(x for x in t.body if isinstance(x,ast.ClassDef) and x.name=='Solver');return t,{x.name:ast.dump(x,include_attributes=False) for x in cl.body if isinstance(x,ast.FunctionDef)}
 tb,bm=parsed(ROOT/'sources/B/solver.py');tc,cm=parsed(ROOT/'sources/R08F/solver.py');unchanged=[k for k in bm if bm[k]==cm[k]];assert set(bm)-set(unchanged)=={'build_half','run'};assert set(cm)-set(bm)=={'entropic_cost_proposal','joint_cdf_pair_exchange'}
 fb={x.name:ast.dump(x,include_attributes=False) for x in tb.body if isinstance(x,ast.FunctionDef)};fc={x.name:ast.dump(x,include_attributes=False) for x in tc.body if isinstance(x,ast.FunctionDef)};assert all(fc[k]==v for k,v in fb.items());assert set(fc)-set(fb)=={'joint_pair_cdf_scores'}
 for name,digest in read(ROOT/'sources/B/SOURCE_MANIFEST.json')['original_source_sha256'].items():assert sha(ROOT/'sources/B'/name)==digest
 for name in ('instance.py','native_evaluator.py','native_support.py','lss_vendor.py'):assert sha(ROOT/'sources/B'/name)==sha(ROOT/'sources/R08F'/name)
 atomic(ROOT/'MATH_PREFLIGHT.json',{'passed':True,'freeze_sha':freeze,'packed_inverse_checks':inverse_checks,'all_entry_checks':checks,'matrix_entries_checked':sum(c['entries'] for c in checks),'original_module_functions_unchanged':list(fb),'original_native_methods_unchanged':unchanged,'native4dependencies_byte_identical':True,'formal_runs':0,'scope':'Direct polynomial coefficients and explicit finite-support enumeration, zero/strict-B overflow boundaries. Float checks not directed certificates; no new native samples or optimizer.'});print('All-entry joint-CDF algebra and native/source invariants passed',flush=True)
if __name__=='__main__':main()
