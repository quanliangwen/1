"""Read-only singleton terminal exporter watcher. Never launches or retries optimization."""
import os,sys,time,json,fcntl,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from common import read,atomic,process_table,mem_available,sha,check_freeze
HERE=Path(__file__).resolve().parent

def main():
 lock=(HERE/'postprocess.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);lock.seek(0);lock.truncate();lock.write(str(os.getpid()));lock.flush();os.fsync(lock.fileno());f=check_freeze()
 receipt=read(ROOT/'LAUNCH_RECEIPT.json');allowed=('pilot_failed_requires_diagnosis','pilot_integrity_audit_failed_no_expansion','performance_gates_passed_delivery_pending','full_failed_requires_new_mechanism');last=None
 while True:
  table=process_table();row=table.get(receipt['pid']);live=bool(row and row['start_ticks']==receipt['start_ticks']);workers=sum(str(ROOT/'worker.py') in x['cmd'] for x in table.values());state=read(ROOT/'STATE.json') if (ROOT/'STATE.json').exists() else {};status=state.get('status','preflight');info={'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'watcher_pid':os.getpid(),'controller_live':live,'workers':workers,'status':status,'index':state.get('index'),'freeze_sha':f,'read_only':True};atomic(HERE/'WATCH_STATE.json',info)
  key=(status,state.get('phase'),state.get('index'),live)
  if key!=last:print(json.dumps(info),flush=True);last=key
  if not live and not workers:
   if status not in allowed:
    atomic(HERE/'REQUIRES_ATTENTION.json',dict(info,reason='Controller exited outside registered terminal status; no optimization is restarted.'));return
   if (ROOT/'LATEST_TERMINAL_EXPORT.json').exists():print('Reuse existing terminal export; no duplicate packet',flush=True);return
   if mem_available()<6*2**30 or os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize<1*2**30:time.sleep(30);continue
   check_freeze();env=dict(os.environ,OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
   p=subprocess.run([sys.executable,'-B',str(HERE/'export_terminal.py')],env=env,capture_output=True,text=True)
   atomic(HERE/'POSTPROCESS_TERMINAL.json',dict(info,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,goal_complete=False,remaining='Spreadsheet/visual QA/GitHub final upload and remote SHA verification. On pilot fail, goal requires next mechanism diagnosis.'))
   print(p.stdout,p.stderr,flush=True);return
  time.sleep(30)
if __name__=='__main__':main()
