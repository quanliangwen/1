"""Independent terminal audit/export only. Never import Solver or invoke native oracle."""
import os
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import json,sys,time,gzip,hashlib,zipfile,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from common import read,sha,atomic,check_freeze,process_table
from audit_campaign import audit_wave
from statistics_campaign import summary,paired,holm

def snapshot(which):
 reg=read(ROOT/'PROTOCOL.json');indices=reg['pilot_cases'] if which=='pilot' else list(range(1,41));ss=[];cc=[];records=[];quality=[]
 for idx in indices:
  case=next(x for x in reg['cases'] if x['index']==idx);pair={}
  for arm in ('B','R08F'):
   phase='reference' if arm=='B' else 'R08F_'+which
   folder=Path(read(ROOT/'REFERENCE_REGISTRY.json')['waves'][str(idx)]['directory']) if arm=='B' else ROOT/read(ROOT/'WAVE_POINTERS'/('%s_c%02d.json'%(phase,idx)))['relative_dir']
   meta=read(folder/'WAVE.json');assert meta['status'] in ('valid_complete','ordinary_failure_complete'),meta
   rows=audit_wave(folder,case,arm);pair[arm]=rows;records.extend(dict(x,index=idx,arm=arm,phase=phase,wave=str(folder)) for x in rows)
   ss.append(dict(arm=arm,index=idx,instance=case['instance'],m=case['m'],capacity=case['tmax'],target_cost=case['target_cost'],wave_status=meta['status'],**summary(rows)))
  comp=paired(pair['B'],pair['R08F'],20261101+idx);cc.append(dict(index=idx,**comp))
  if all(len(x)==30 and all(y['valid'] for y in x) for x in pair.values()):
   target=statistics.mean(x['cost'] for x in pair['B']);by={}
   for arm,rows in pair.items():
    times=[]
    for row in rows:
     hits=[e['elapsed'] for e in row['incumbent_path'] if e['cost']<=target+1e-8];times.append(min(hits) if hits else None)
    hits=[x for x in times if x is not None];by[arm]={'hits':len(hits),'conditional_seconds':statistics.mean(hits) if hits else None,'restricted_seconds':statistics.mean(t if t is not None else 600 for t in times)}
   quality.append({'index':idx,'fixed_reference_mean_cost_target':target,'arms':by})
 holm(cc);gate=read(ROOT/'summaries'/('R08F_'+which+'.json'));assert len(gate['summaries'])==len(ss)
 # Reproduce every official summary, p, CI from separate subprocess (same declared statistical RNG).
 for a in ss:
  b=next(x for x in gate['summaries'] if x['index']==a['index'] and x['arm']==a['arm'])
  for k in ('registered','valid','best','avg','std','CV','mean_final_best_first_seconds','best_hits','conditional_best_hit_seconds','mean_actual_runtime'):
   assert a[k]==b[k] or (isinstance(a[k],(int,float)) and isinstance(b[k],(int,float)) and abs(a[k]-b[k])<1e-10),(a['arm'],a['index'],k,a[k],b[k])
 for a,b in zip(cc,gate['comparisons']):
  for k in ('mean_difference','relative_mean_difference','p','holm_p','paired_bootstrap_95'):assert a.get(k)==b.get(k),(a['index'],k)
 return {'snapshot_utc':time.strftime('%Y%m%dT%H%M%SZ',time.gmtime()),'which':which,'freeze_sha':check_freeze(),'protocol_sha':sha(ROOT/'PROTOCOL.json'),'campaign_state':read(ROOT/'STATE.json'),'summaries':ss,'comparisons':cc,'terminal_records':records,'own_attempts':[dict(read(p),directory=str(p.parent)) for p in sorted((ROOT/'waves').glob('*/WAVE.json'))],'stage_gate':dict(gate,reference_quality_times=quality),'full_gate':read(ROOT/'FINAL_GATE.json') if which=='full' else None,'scope':'Independent terminal-only recomputation, original costs/group constraints/native returned values/random-seed config/source/SHA/time audited. No additional native samples or optimization.','official_cost_statistics_require_30_valid':True,'selection_limitations':reg['statistics']['selection_limit'],'attribution_limit':'Official B comparison includes retained R04 entropic proposal, R06 support FFT, R07 joint pair proposal and R08F packed inverse call. R08 incremental kernel ABBA isolates the full backend-call replacement, not padding alone. Formal concurrency cap15 and shared server load differ from reused B; whole-candidate cost effects cannot be assigned to one component.'}

def main():
 state=read(ROOT/'STATE.json');allowed=('pilot_failed_requires_diagnosis','pilot_integrity_audit_failed_no_expansion','performance_gates_passed_delivery_pending','full_failed_requires_new_mechanism');assert state['status'] in allowed,state['status'];assert not any(str(ROOT/'worker.py') in v['cmd'] for v in process_table().values())
 which='full' if state['status'] in allowed[-2:] else 'pilot';d=snapshot(which);tag=d['snapshot_utc'];out=ROOT/'terminal_exports'/tag;out.mkdir(parents=True,exist_ok=False);atomic(out/'statistics_snapshot.json',d)
 # All B references retained with all candidate pilot/full/failed attempts.
 entries={}
 def add(p,name):
  assert name not in entries;entries[name]=p
 def tree(p,prefix):
  if p.exists():
   for f in sorted(p.rglob('*')):
    if f.is_file():add(f,prefix+'/'+f.relative_to(p).as_posix())
 tree(ROOT/'waves','waves')
 for entry in read(ROOT/'REFERENCE_REGISTRY.json')['waves'].values():
  folder=Path(entry['directory']);tree(folder,'reused_B/'+folder.name)
 for name in ('audits','summaries','WAVE_POINTERS','FUNCTIONAL_WAVE','COMPONENT_TESTS'):tree(ROOT/name,'control/'+name)
 for p in ROOT.glob('*.json'):add(p,'control/'+p.name)
 for name in ('advance.log','EVENTS.jsonl','mathematical_preflight.py.log','functional_preflight.py.log'):
  p=ROOT/name
  if p.exists():add(p,'control/'+name)
 add(out/'statistics_snapshot.json','reports/statistics_snapshot.json');add(Path(__file__),'offline_reporting/export_terminal.py');manifest={}
 with zipfile.ZipFile(out/'results_complete.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,p in entries.items():
   b=p.read_bytes();z.writestr(name,b);manifest[name]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
  z.writestr('EXPORT_MANIFEST.json',json.dumps({'scope':'All new candidate attempts plus all40 valid reused B reference waves. Prior historical failures remain in linked R04 delivery. No optimization/redraw.','freeze':check_freeze(),'files':manifest},ensure_ascii=False,indent=2))
 atomic(out/'INDEPENDENT_REVIEW.json',{'all_summary_and_paired_recomputed':True,'official_comparison_records':len(d['terminal_records']),'all_records_valid':all(r['valid'] for r in d['terminal_records']),'max_actual_elapsed':max(r['elapsed_upper'] for r in d['terminal_records']),'source_freeze':check_freeze(),'source_unchanged':True,'all_B_reused':True,'no_new_evaluation':True,'status':state['status'],'goal_complete':False,'delivery_remaining':'Excel and remote GitHub SHA verification'})
 receipt={'export_directory':str(out),'zip_sha256':sha(out/'results_complete.zip'),'zip_bytes':(out/'results_complete.zip').stat().st_size,'snapshot_sha256':sha(out/'statistics_snapshot.json'),'scope':which,'candidate_state':state['status']};atomic(ROOT/'LATEST_TERMINAL_EXPORT.json',receipt);print(json.dumps(receipt),flush=True)
if __name__=='__main__':main()
