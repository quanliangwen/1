"""Independent Fraction/KKT reader; imports no optimizer or C++ writer."""
from fractions import Fraction as F
import math
from r05_fft_reader import r05_private_tools
def moments(samples):
 out=[]
 for row in samples:
  a=sorted(F(x) for x in row);n=len(a);mu=sum(a,F())/n;var=sum((x*x for x in a),F())/n-mu*mu;m=min(n,max(3,(n+19)//20));dev=sum(a[-m:],F())/m-mu
  assert var>=0 and dev>=0 and (var!=0 or dev==0);out.append((mu,var,dev))
 return out
def sqrt_bounds(v):
 assert v>=0
 scale=1<<208;a=v.numerator*scale*scale;b=v.denominator;r=math.isqrt(a//b)
 return F(r,scale),F(r+(r*r*b<a),scale)
def witness(parameters,s,omega):
 omega=F(omega);mu=sum((parameters[j][0] for j in s),F());order=sorted((j for j in s if parameters[j][1]>0 and parameters[j][2]>0),key=lambda j:(parameters[j][2]/parameters[j][1],j))
 corner=sum((parameters[j][2]**2/parameters[j][1] for j in order),F())
 if corner<=omega**2:return mu+sum((parameters[j][2] for j in order),F()),mu+sum((parameters[j][2] for j in order),F())
 for q in range(len(order)):
  sat=order[:q];interior=order[q:];R=omega**2-sum((parameters[j][2]**2/parameters[j][1] for j in sat),F());V=sum((parameters[j][1] for j in interior),F())
  if R<0:continue
  left=parameters[order[q-1]][2]/parameters[order[q-1]][1] if q else F();right=parameters[order[q]][2]/parameters[order[q]][1]
  if left**2<=R/V<=right**2:
   l,u=sqrt_bounds(R*V);base=mu+sum((parameters[j][2] for j in sat),F());return base+l,base+u
 raise AssertionError('No KKT interval')
def verify_proof(p,parameters,capacity):
 s=p['selection'];lo,hi=witness(parameters,s,p['omega']);rhs=F(str(capacity))-F(1,10**8)
 assert F(p['worst_lower'])==lo and F(p['worst_upper'])==hi and F(p['rhs'])==rhs and p['bits']==208
 assert p['robust_feasible']==(hi<=rhs)
 return p['robust_feasible']
def verify_be(raw,groups,costs,samples,capacity,parameters=None):
 m=raw['BE_RO_model'];assert raw['search_flow']=='be_ro_pure' and m['model']=='BE_RO_Pure_B1'
 assert m['beta']=='19/20' and m['K']==5 and not m['historical_solution_inputs'] and not m['external_MIPstarts'] and not m['local_search_enabled']
 assert not m['radius_is_probability_guarantee'] and not m['CDF_solution_probability_monotonicity_claim'] and not m['private_FFT_is_certificate']
 assert m['tail_count']==min(len(samples[0]),max(3,(len(samples[0])+19)//20))
 params=parameters if parameters is not None else moments(samples)
 assert len(m['items'])==len(params)
 for j,q in enumerate(m['items']):assert q['item']==j and tuple(F(q[k]) for k in ['mu','variance','deviation'])==params[j]
 selection,cost,prob,marginals,near=r05_private_tools(groups,costs,samples,capacity)
 proofs=0
 for q in m['queries']:
  assert 0<=q['start']<=480 and q['finish']>=q['start'] and not q['external_MIPstarts']
  assert q['PoolSolutions'] in [1,25] and q['time_limit'] in [.5,2.,3.]
  for p in q['returned']:selection(p['selection']);verify_proof(p,params,capacity);proofs+=1
 for q in m['calibration']:
  selection(q['selection']);assert q['original_CDF_calls']==0;near(q['private_probability'],prob(q['selection']))
 accepted={};attempted=set();epsilon=.0015
 for q in m['candidates']:
  s=q['selection'];selection(s);key=tuple(s);assert key not in accepted
  assert verify_proof(q['witness'],params,capacity)
  near(q['private_probability'],prob(s));assert abs(q['cost']-float(cost(s)))<1e-8
  expected=sorted(accepted.values())[4] if len(accepted)>=5 else None
  assert q['Kth_cost_before']==expected and q['epsilon_before']==epsilon
  if q['decision']=='dynamic_cost_cutoff':assert expected is not None and q['cost']>=expected-1e-6;continue
  if q['decision']=='private_FFT_rejected':assert q['private_probability']<.99-epsilon;continue
  assert expected is None or q['cost']<expected-1e-6
  assert q['private_probability']>=.99-epsilon and key not in attempted;attempted.add(key)
  call=next(c for c in m['native_calls'] if c['selection']==s)
  assert 0<=call['start']<=480 and call['start']<=call['finish']<=570.1 and call['slice_deadline']<=min(call['start']+90,570)+1e-5
  assert call['state']==q['decision'] and call['epsilon_before']==epsilon
  if call['state']=='accepted':
   c=call['certificate'];assert int(c['lower_numerator'])*100>=99*int(c['denominator'])
   accepted[key]=q['cost'];epsilon=max(epsilon,.001,.99-q['private_probability'])
  if call['hard_timeout']:assert call['state']=='unknown' and 'certificate' not in call
  assert call['epsilon_after']==epsilon
 assert len(attempted)==len(m['native_calls']) and epsilon==m['epsilon_fft_final']
 pool={tuple(q['selection']):q for q in m['certified_pool']};assert set(pool)==set(accepted)
 for s,q in pool.items():assert q['cost']==accepted[s] and q['source']=='BE_RO_Pure' and 0<=q['found_seconds']<=m['stop_seconds']
 assert raw['entropic_model'] is None and raw['adaptive_RO_model'] is None and raw['DRO_model'] is None and not raw['match_history'] and not raw['local_history'] and not raw['block_history']
 return {'witnesses':proofs,'native_calls':len(attempted),'certified':len(accepted)}
