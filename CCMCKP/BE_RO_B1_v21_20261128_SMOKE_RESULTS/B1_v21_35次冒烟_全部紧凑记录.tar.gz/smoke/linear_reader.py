"""Independent Fraction reader: unchanged BE/native core plus v2.1 grid checks.

No optimizer/writer imports. Original integer-CDF certificates and final LSS
still require the existing native/full-record audit in a future test campaign.
"""
from fractions import Fraction as F
import math
import struct
from be_reader import moments, verify_proof
from r05_fft_reader import r05_private_tools


def outward(q, up):
    x = float(q)
    if not math.isfinite(x):
        raise AssertionError('Nonfinite coefficient')
    while ((F(x) < q) if up else (F(x) > q)):
        # Server Python3.8 has no math.nextafter. Step one IEEE754 binary64 ULP.
        if x == 0:
            x = float.fromhex('0x0.0000000000001p-1022') * (1 if up else -1)
        else:
            bits = struct.unpack('>Q', struct.pack('>d', x))[0]
            bits += 1 if (x > 0) == up else -1
            x = struct.unpack('>d', struct.pack('>Q', bits))[0]
    return F(x)


def row_values(parameters, omega, lam, kind, capacity):
    omega, lam, capacity = F(omega), F(lam), F(str(capacity))
    assert omega >= 0 and capacity > 0
    assert kind in ('lambda_huber', 'zero_radius', 'box_corner')
    if kind == 'lambda_huber':
        assert omega > 0 and lam > 0
    elif kind == 'zero_radius':
        assert omega == 0 and lam == 0
    else:
        assert lam == 0
    weights = []
    for mu, var, dev in parameters:
        a = mu
        if kind == 'box_corner':
            a += dev
        elif kind == 'lambda_huber' and var > 0 and dev > 0:
            z = min(dev, var / (2 * lam))
            a += z - lam * z * z / var
        weights.append(a)
    rhs = capacity - F(1, 10**8)
    if kind == 'lambda_huber':
        rhs -= lam * omega**2
    return weights, rhs, [outward(a / capacity, True) for a in weights], outward(rhs / capacity, False)


def verify_row(p, s, parameters, capacity):
    weights, rhs, rounded, rr = row_values(parameters, p['omega'], p['lambda'], p['kind'], capacity)
    lhs = sum((weights[j] for j in s), F())
    actual = sum((rounded[j] for j in s), F())
    assert F(p['exact_lhs']) == lhs and F(p['exact_rhs']) == rhs
    assert F(p['rounded_lhs']) == actual and F(p['rounded_rhs']) == rr
    assert p['row_feasible'] == (lhs <= rhs and actual <= rr)
    return p['row_feasible']


def model_cost(s, costs):
    # Independently reproduce the inherited eight-lane binary64 model sum.
    # Final LSS costs retain the original separate sequential-sum convention.
    def total(a):
        n = len(a)
        if n < 8:
            value = -0.0
            for x in a:
                value += x
            return value
        if n > 128:
            half = (n//2) & ~7
            return total(a[:half]) + total(a[half:])
        lanes = list(a[:8]); blocks = n-n%8
        for i in range(8, blocks, 8):
            for j in range(8):
                lanes[j] += a[i+j]
        value = ((lanes[0]+lanes[1])+(lanes[2]+lanes[3])) + ((lanes[4]+lanes[5])+(lanes[6]+lanes[7]))
        for i in range(blocks, n):
            value += a[i]
        return value
    return total([costs[j] for j in s])


def verify_radius_grid(m, archive, good_queries, costs):
    assert m['revision'] == 'B1-v2.1' and m['non_monotone_radius_scan'] is True
    assert m['grid_resolution_is_complete'] is False
    maximum = F(m['omega_resource_used']) if 'omega_resource_used' in m else F(m['omega_resource_lower'])
    scans = m['calibration']; assert len(scans) <= 16
    coarse = scans[:8]; candidates = []; end = 0
    rstar = 8
    if len(coarse) == 8:
        finite = [(q['feasible_private_min_cost'], i+1) for i, q in enumerate(coarse) if q['feasible_private_min_cost'] is not None]
        if finite:
            rstar = min(finite)[1]
        assert m['coarse_r_star'] == rstar
        left, right = maximum * F(max(0, rstar-2), 8), maximum * F(rstar, 8)
        assert [F(x) for x in m['zoom_interval']] == [left, right]
    for i, scan in enumerate(scans):
        stage, index = ('private_coarse', i+1) if i < 8 else ('private_zoom', i-7)
        omega = maximum * F(index, 8) if i < 8 else left + F(index, 9) * (right-left)
        assert scan['pass'] == stage and scan['point'] == index and F(scan['omega']) == omega
        assert scan['original_CDF_calls'] == 0 and scan['query_begin'] == end
        begin, end = scan['query_begin'], scan['query_end']
        assert end-begin == (1 if omega == 0 else 10)
        possible = set()
        for qi in range(begin, end):
            query = m['queries'][qi]
            assert query['phase'] == stage and F(query['radius']) == omega
            assert query['time_limit'] == .5 and query['PoolSolutions'] == 1
            assert query['no_good_count'] == 0 and query['cost_cutoff'] is None
            possible.update(good_queries[qi])
        feasible = [s for s in possible if archive[s]['private_probability_complete'] and archive[s]['private_probability'] >= .99]
        if feasible:
            # Same binary64 item costs and summation order as the actual model.
            selected = min(feasible, key=lambda s: (model_cost(s, costs), s))
            value = model_cost(selected, costs)
            assert tuple(scan['selection']) == selected and scan['feasible_private_min_cost'] == value
            assert scan['private_probability'] == archive[selected]['private_probability']
            candidates.append((value, omega))
        else:
            assert scan['feasible_private_min_cost'] is None and 'selection' not in scan
    if len(scans) < 16:
        assert m.get('partial') == 'global_new_call_deadline'
        assert not m['certified_pool'] and not m['native_calls']
        return
    best_cost, best_omega = min(candidates) if candidates else (None, maximum)
    assert F(m['omega_best']) == F(m['omega_star']) == best_omega
    assert m['private_grid_global_min_cost'] == best_cost
    clip = lambda x: min(maximum, max(F(), x))
    points = []
    for x in (clip(max(F(1, 20), best_omega*F(24, 25))), clip(best_omega), clip(best_omega*F(26, 25))):
        if x not in points:
            points.append(x)
    actual = [F(x) for x in m['critical_points']]
    assert actual == points[:len(actual)]
    if len(actual) < len(points):
        assert m.get('partial') == 'global_new_call_deadline'
    assert m['archive_min_cost'] == min((x['cost'] for x in archive.values()), default=None)


def verify_v2(raw, groups, costs, samples, capacity):
    m = raw['BE_RO_model']
    assert raw['search_flow'] == 'be_ro_pure' and m['model'] == 'BE_RO_Pure_B1_v2'
    assert m['beta'] == '19/20' and m['K'] == 5
    for key in ('finite_lambda_grid_is_exact_optimizer', 'omega_max_is_exact_claim',
                'external_MIPstarts', 'historical_solution_inputs', 'local_search_enabled',
                'radius_is_probability_guarantee', 'CDF_solution_probability_monotonicity_claim',
                'private_FFT_is_certificate'):
        assert m[key] is False, key
    params = moments(samples)
    assert len(params) == len(m['items'])
    for j, p in enumerate(m['items']):
        assert p['item'] == j and tuple(F(p[k]) for k in ('mu', 'variance', 'deviation')) == params[j]
    selection, cost, probability, _, near = r05_private_tools(groups, costs, samples, capacity)
    known_rows = {}
    good_queries = {}
    for qi, q in enumerate(m['queries']):
        assert 0 <= q['start'] <= 480 and q['finish'] >= q['start']
        assert q['model'] == 'BE_Linear_MCKP' and not q['external_MIPstarts']
        grid_query = m.get('revision') == 'B1-v2.1' and q['phase'] in ('private_coarse', 'private_zoom')
        assert q['time_limit'] == (.5 if grid_query else 1) and q['PoolSolutions'] == (1 if grid_query else 10)
        weights, rhs, rounded, rr = row_values(params, q['radius'], q['lambda'], q['kind'], capacity)
        minimum = sum((min(rounded[j] for j in g) for g in groups), F())
        assert F(q['minimum_rounded_sum']) == minimum and F(q['rounded_rhs']) == rr
        assert q['array_feasible'] == (minimum <= rr)
        rows = set()
        for p in q['returned_rows']:
            s = p['selection']; selection(s)
            assert p['omega'] == q['radius'] and p['lambda'] == q['lambda'] and p['kind'] == q['kind']
            clean = verify_row(p, s, params, capacity)
            if p['kept']:
                assert clean
                if q['cost_cutoff'] is not None:
                    assert float(cost(s)) <= q['cost_cutoff'] + 1e-10
                rows.add(tuple(s))
        known_rows[qi] = rows
        good = set()
        for p in q['returned']:
            s = p['selection']; selection(s); assert tuple(s) in rows
            assert F(p['omega']) == F(q['radius'])
            if verify_proof(p, params, capacity):
                good.add(tuple(s))
        good_queries[qi] = good
    archive = {}
    for a in m['archive']:
        s = a['selection']; selection(s); key = tuple(s)
        assert key not in archive; archive[key] = a
        near(a['cost'], float(cost(s)))
        assert a['witness']['selection'] == s and F(a['witness']['omega']) == F(a['omega'])
        assert verify_proof(a['witness'], params, capacity)
        assert a['origins']
        for origin in a['origins']:
            qi = origin['query_index']; q = m['queries'][qi]
            assert key in good_queries[qi]
            assert (origin['omega'], origin['lambda'], origin['kind'], origin['phase']) == (q['radius'], q['lambda'], q['kind'], q['phase'])
            assert verify_row(origin['row'], s, params, capacity)
        first = a['origins'][0]
        assert (a['omega'], a['lambda'], a['kind']) == (first['omega'], first['lambda'], first['kind'])
        if a['private_probability_complete']:
            near(a['private_probability'], probability(s))
        else:
            assert a['private_probability'] is None and m.get('partial') == 'global_new_call_deadline'
    for qi, vectors in good_queries.items():
        assert vectors <= set(archive), 'A binary-search/pool candidate was discarded'
        for s in vectors:
            assert any(o['query_index'] == qi for o in archive[s]['origins'])
    verify_radius_grid(m, archive, good_queries, costs)
    calls = m['native_calls']; accepted = {}; attempted = set(); epsilon = .0015; ci = 0
    for q in m['candidates']:
        s = q['selection']; key = tuple(s); assert key in archive
        a = archive[key]; near(q['cost'], a['cost']); near(q['private_probability'], a['private_probability'])
        assert verify_proof(q['witness'], params, capacity)
        expected = sorted(accepted.values())[4] if len(accepted) >= 5 else None
        assert q['Kth_cost_before'] == expected and q['epsilon_before'] == epsilon
        if q['mode'] == 'escape_empty':
            assert not accepted and q['gate'] is None
            gate = -math.inf
        else:
            assert q['mode'] in ('escape_nonempty', 'archive_cost_order')
            gate = .985 if q['mode'] == 'escape_nonempty' else .99 - epsilon
            near(q['gate'], gate)
        if q['decision'] == 'dynamic_cost_cutoff':
            assert expected is not None and q['cost'] >= expected - 1e-6
            continue
        if q['decision'] == 'private_FFT_rejected':
            assert q['private_probability'] < gate
            continue
        assert key not in attempted and q['private_probability'] >= gate
        assert expected is None or q['cost'] < expected - 1e-6
        attempted.add(key)
        call = calls[ci]; ci += 1
        assert call['selection'] == s and call['state'] == q['decision']
        assert call['mode'] == q['mode'] and call['epsilon_before'] == epsilon
        assert 0 <= call['start'] <= 480 and call['start'] <= call['finish'] <= 570.1
        assert call['slice_deadline'] <= min(call['start'] + 90, 570) + 1e-5
        if call['hard_timeout']:
            assert call['state'] == 'unknown' and 'certificate' not in call
        if call['state'] == 'accepted':
            c = call['certificate']
            assert int(c['lower_numerator']) * 100 >= 99 * int(c['denominator'])
            accepted[key] = q['cost']
            epsilon = max(epsilon, .001, .99 - q['private_probability'])
        assert call['epsilon_after'] == epsilon
    assert ci == len(calls) and epsilon == m['epsilon_fft_final']
    pool = {tuple(p['selection']): p for p in m['certified_pool']}
    assert set(pool) == set(accepted)
    for s, p in pool.items():
        assert p['cost'] == accepted[s] and p['source'] == 'BE_RO_Pure'
        assert 0 <= p['found_seconds'] <= m['stop_seconds']
    assert len(m['escape']) <= 3
    assert all(not p['full_model_infeasibility_claim'] for p in m['resource_probes'])
    assert raw['entropic_model'] is None and raw['adaptive_RO_model'] is None and raw['DRO_model'] is None
    assert not raw['match_history'] and not raw['local_history'] and not raw['block_history']
    return {'archive': len(archive), 'native_calls': len(calls), 'certified': len(pool),
            'scope': 'BE rows/archive/clock/provenance; full native/LSS audit additionally required'}
