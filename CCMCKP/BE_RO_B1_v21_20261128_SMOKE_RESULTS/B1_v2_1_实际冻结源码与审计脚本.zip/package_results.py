from pathlib import Path
from fractions import Fraction
import json,hashlib,statistics,csv,shutil,tarfile,zipfile
R=Path(__file__).resolve().parent;E=R/'execution_evidence';X=R/'results_20261128';D=X/'delivery';D.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
A=read(E/'smoke/FINAL_INDEPENDENT_AUDIT.json');G=read(E/'smoke/SMOKE_EXPANSION_DECISION.json');P=read(E/'smoke/PROTOCOL.json');C=read(E/'smoke/COMPLETED.json');V=read(E/'VALIDATION.json');diag=read(E/'smoke/POSTRUN_DIAGNOSTICS.json')
assert A['terminal']==35 and not A['global_errors']
groups=G['groups'];passed=G['pass']
state={'stage':'B1_V21_SMOKE_PASSED_WAIT_FULL40' if passed else 'B1_V21_SMOKE_QUALITY_FAILED_NO_FULL40',
 'compiled':True,'tiny_validation':'PASS','smoke_terminal':35,'smoke_independent_valid':A['independent_valid'],
 'smoke_gate_pass':passed,'full40_started':False,'no_after_result_gate_changes':True,'old_results_unchanged':True,
 'binary_sha256':V['binary_sha256'],'smoke_protocol_sha256':sha(E/'smoke/PROTOCOL.json')}
fmt=lambda x,n=6:'—' if x is None else f'{x:.{n}f}'
lines=['# B1-v2.1两级半径网格修复与冒烟测试总结','',
f'已按本轮设计实现、编译和测试。7例各5次，共35次终末；{A["independent_valid"]}/35独立有效，global_errors=[]。'+('新文档全部质量门槛通过，允许进入独立全量测试。' if passed else '**新文档质量门槛未全部通过，因此未启动40例×30次全量。**'), '',
'## 代码是否符合本轮设计','',
'|设计项|实际实现与验证|', '|---|---|',
'|8点全局粗扫|r/8×搜索半径，r=1..8；每点10个λ单解，0.5秒；不因一个点未通过私人FFT丢弃半区|',
'|8点局部加密|按最低私人可行成本选r*，平手取小r；在左拓两格区间取q/9内点；全无私人可行候选时r*=8|',
'|3点解池扩展|围绕16点中的最低私人可行成本对应半径，取0.96/1/1.04三点及盒角；10解池，1秒|',
'|候选与评价|所有KKT合法返回向量归档；原FFT、CDF、动态第5成本截断、3轮兜底及最终LSS保持|',
'|继承边界|89个原源码文件字节不变；Step1、认证/归档门控、Step5核心文本SHA相同；线性模型、KKT、原native/LSS/main未变|',
'|审计|主生产审计器字节未变；独立读者只增加0.5秒新阶段与网格坐标/argmin检查，未改Fraction或CDF/LSS核|',
'|初始解与隔离|当前run原始数据自行建模产生，不读旧解、外部MIPstart或其他重复结果；旧向量仅在所有新run结束后用于只读诊断|', '',
'诊断记录保留coarse_r_star、zoom_interval、omega_best、archive_min_cost及全部16点来源。零半径和max<.05按既有边界裁剪处理。几何测试首次发现GMP分数规范化比较问题，已在冻结前修正并留存日志，仍严格取q/9。', '',
'## 技术验证与预算','',
f'新网格648项几何检查、4个新流程tiny完整集成、64项篡改检查、11份整数CDF证书核算和4次生产审计回放通过。旧920项线性行/KKT数学证据仅在相同源码SHA下有限复用，未重跑未变模型或额外原生MC。', '',
f'新鲜seed1284101—1284105；上限60并行，本次峰值{C["max_active_observed"]}。全部完整运行耗时最大{max(r["process_wall_seconds"] for r in A["rows"]):.6f}秒，均≤600秒；资源事件{C["resource_events"]}，TIME_LIMIT且SolCount0查询{len(G["TIME_LIMIT_zero_solution_queries"])}次。批次历时{C["elapsed_seconds"]:.3f}秒，之后进行只读独立审计。', '',
'600秒包括加载、全部求解/评分、原LSS、保存fsync与返回；新调用480秒前发起，CDF单次90秒/最迟570秒，LSS截至590秒，外部595秒守护。没有clip、失败补跑或跨版本热启动。', '',
'## 35次冒烟统计和新文档门槛','',
'|编号|算例|T|有效|Best|5次Avg|样本Std|首次达Best均时(s)|命中次数|完整均时(s)|Best上限|Avg上限|门槛|',
'|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|']
for g in groups:
 lines.append(f'|{g["case_index"]}|{g["instance"].rstrip("_")}|{g["capacity"]:g}|{g["valid"]}/5|{fmt(g["best"])}|{fmt(g["avg"])}|{fmt(g["sample_std"])}|{fmt(g["first_Best_mean"])}|{g["best_hit_count"]}|{fmt(g["whole_mean"])}|{fmt(g["best_limit"],8)}|{fmt(g["avg_limit"],8)}|{"通过" if g["cost_gate_pass"] else "未通过"}|')
lines+=['','Std为ddof=1；首次达Best均时只平均最终输出成本命中本例本批Best的运行，取最终输出向量首次内部CDF认证时刻，且随后通过原LSS。5次Avg是冒烟诊断，不冒称正式30次均值；Best没有全局最优证书。39按新文档仅限制Best，不添加Avg限制。', '',
'## 编号8、28：已修复的覆盖缺口','',
'编号8的5次最终成本均为11.1850840224，编号28均为16.4236268477，分别达到新文档11.18515、16.42365门槛。两者都由当前run自生成候选得到。', '',
'旧B1-v2的重复1中，编号8首个中点约2.55、最低候选12.9491534872，私人FFT约0.982219；编号28首个中点约3.00、最低候选16.6231963821，私人FFT约0.977002。旧算法因此移走左半区，整个旧归档也没有恢复目标候选。新网格保留更多半径来源后，两例恢复成功。', '',
'本次真实r*与设计中的原型预测不同：重复1编号8为r*=1，编号28为r*=2，而非文档示例中的3、5。算法确实按实际返回候选选择r*；不能把文档原型落点表当作真实Gurobi解池输出的证明。坐标和选点规则由独立读者核验。', '',
'## 大算例退化：覆盖仍不完整','',
'同样的网格未保住其余5例。全部5次各自收敛到相同但较高的最终成本：18约142.3902、35约197.5443、36约159.8953、38约196.6746、39约326.4139。Std=0说明本批输出一致，不代表质量更好。', '',
'对重复1的只读事后向量比对发现，旧B1-v2曾认证的低成本向量，在18、35、36、38、39的新归档中均不存在；两版本对应源/数据和评价核均保留。因此这些退化不能笼统归为“LSS正常随机回退”，候选生成覆盖缺失是直接证据。该比对发生在新run全部终末后，没有将旧向量输入求解器。', '',
'新归档中虽有不少低于Best门槛的其他向量，但它们被私人FFT门控或原CDF拒绝，不能将这些未通过的向量赋为有效成本。详细计数、16点轨迹和旧向量是否出现记录在POSTRUN_DIAGNOSTICS.json。', '',
'8点粗扫并不穷尽半径；只围绕一个r*做8点加密，仍可能漏掉其他区间的好组合；每λ仅返回一个最低成本解，私人FFT可行的替代组合可能只在解池扩展时出现。因而取消二分修复了一类缺口，但“粗点夹住目标窗口”不等于已命中目标向量。有限λ/半径网格不具备全局覆盖或真分布概率保证。', '',
'## 扩展决定','',
('本批门槛通过，可继续按冻结协议安排全40例各30次。' if passed else '本批只有8、28通过质量门槛，其他5例未通过。按用户“通过后才全量”的条件，未启动1200次测试，也未降低新门槛或重跑挑seed。没有自动启动文档展望中的B2-v2。'), '',
'## 证据与校验','',
f'- 冻结协议SHA256：`{sha(E/"smoke/PROTOCOL.json")}`。',
f'- 最终独立审计SHA256：`{sha(E/"smoke/FINAL_INDEPENDENT_AUDIT.json")}`。',
f'- 二进制SHA256：`{V["binary_sha256"]}`。',
f'- 核验输出文件SHA {A["files_sha_checked"]}项、KKT见证{A["KKT_witnesses_checked"]}项、整数CDF证书{A["native_integer_certificates_checked"]}份；没有重新抽样概率。',
'- 随附实际源码包、源差异/边界SHA、35次统计CSV、全部紧凑记录、审计与门槛JSON。旧B1-v2结论、门槛和结果没有回改。']
(D/'B1_v2_1_两级网格修复与35次冒烟总结.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
with (D/'B1_v2_1_7例35次冒烟统计.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(groups[0]));w.writeheader();w.writerows(groups)
(D/'B1_v2_1_35次结果与审计明细.json').write_text(json.dumps({'groups':groups,'rows':A['rows'],'gate':G},ensure_ascii=False,indent=2),encoding='utf-8')
for n in ['PROTOCOL.json','FROZEN.json','COMPLETED.json','SMOKE_EXPANSION_DECISION.json','FINAL_INDEPENDENT_AUDIT.json','POSTRUN_DIAGNOSTICS.json']:shutil.copy2(E/'smoke'/n,D/n)
for n in ['VALIDATION.json','READER_VALIDATION.json','SOURCE_MANIFEST_SHA256.json','STATIC_REVIEW.json']:shutil.copy2(E/n,D/n)
for n in ['SOURCE_DIFF.patch','EXECUTION_NOTES.md','USER_DESIGN.md']:shutil.copy2(R/n,D/n)
for p in E.glob('*.tar.gz'):shutil.copy2(p,D/p.name)
sources=read(E/'SOURCE_MANIFEST_SHA256.json')['files']
with zipfile.ZipFile(D/'B1_v2_1_实际冻结源码与审计脚本.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in (R/'source').rglob('*'):
  if p.is_file():
   name=p.relative_to(R/'source').as_posix();assert sha(p)==sources[name];z.write(p,'source/'+name)
 for n in ['linear_reader.py','be_reader.py','native_reader.py','r05_fft_reader.py','audit_reader.py','controller.py','validate_remote.py']:
  assert sha(R/n)==P['source_and_binary_pins'][n] if n in P['source_and_binary_pins'] else True
  z.write(R/n,n)
 for n in ['prepare_execution.py','replay_reader_remote.py','freeze_smoke_remote.py','launch_smoke_remote.py','decide_smoke_remote.py','diagnose_smoke_remote.py','collect_smoke_remote.py','download_smoke.py','package_results.py','EXECUTION_NOTES.md','USER_DESIGN.md','SOURCE_MANIFEST_SHA256.json','STATIC_REVIEW.json','SOURCE_DIFF.patch']:z.write(R/n,n)
actual={};manifest=None
full=next(p for p in D.glob('*.tar.gz') if '全部紧凑' in p.name)
with tarfile.open(full) as tar:
 for member in tar:
  data=tar.extractfile(member).read()
  if member.name=='SMOKE_ALL_FILES_SHA256.json':manifest=json.loads(data)
  else:
   assert member.name.startswith('smoke/');actual[member.name[6:]]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
assert manifest==actual
assert len(groups)==7 and sum(g['valid'] for g in groups)==A['independent_valid']
for g in groups:
 rr=[r for r in A['rows'] if r['case_index']==g['case_index'] and r['valid']]
 if len(rr)==5:
  assert statistics.mean(r['cost'] for r in rr)==g['avg'] and statistics.stdev(r['cost'] for r in rr)==g['sample_std']
qa={'status':'PASS','stage':'FORMAL_COMPLETE','publication_scope':'B1-v2.1 smoke results and source; quality-gated full40 only',
 'all_files_sha_verified':True,'smoke_gate_pass':passed,'source_matches_freeze':True,'full_compact_files_SHA_verified':len(actual)}
(X/'DELIVERY_LOCAL_VERIFIED.json').write_text(json.dumps(qa,indent=2),encoding='utf-8');(D/'DELIVERY_QA.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
(R/'CURRENT_STATUS.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8');(D/'CURRENT_STATUS.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
checks={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in D.iterdir() if p.is_file() and p.name!='CHECKSUMS_SHA256.json'}
assert all(q['bytes']<95*2**20 for q in checks.values())
(D/'CHECKSUMS_SHA256.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
pub=(R/'publish_code.py').read_text(encoding='utf-8').replace("FOLDER='BE_RO_B1_v2_20261128_CODE_ONLY'","FOLDER='BE_RO_B1_v21_20261128_SMOKE_RESULTS'").replace('Prepare B1-v2 lambda-Huber source without compiling or running; wait for B2','Publish B1-v2.1 radius-grid repair,35-run smoke results and frozen source')
(X/'publish_results.py').write_text(pub,encoding='utf-8')
print(json.dumps({'status':'PACKAGED','smoke_gate_pass':passed,'independent_valid':A['independent_valid'],'groups':groups,'files':len(checks)},ensure_ascii=False))
