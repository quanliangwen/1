from pathlib import Path
import json,subprocess,sys,os,time
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');F=B/'work/be_ro_b1_v21_20261128/smoke'
assert Path.cwd()==B and (F/'FROZEN.json').exists() and not (F/'LAUNCH_REQUEST.json').exists() and not (F/'LAUNCH.json').exists()
with (F/'controller.log').open('xb') as log:
 p=subprocess.Popen([sys.executable,str(F/'controller.py')],cwd=F,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,close_fds=True)
(F/'LAUNCH_REQUEST.json').write_text(json.dumps({'pid':p.pid,'time':time.time()}));time.sleep(1)
assert p.poll() is None,(F/'controller.log').read_text()
print(json.dumps({'status':'STARTED_SMOKE_OFFLINE','pid':p.pid,'session':os.getsid(p.pid),'stdin':os.readlink('/proc/%d/fd/0'%p.pid),'registered_runs':35}))
