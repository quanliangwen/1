from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil,os
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b1_v21_20261128';F=H/'smoke'
assert Path.cwd()==B and not F.exists()
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
V=read(H/'VALIDATION.json');RV=read(H/'READER_VALIDATION.json');P=read(H/'SMOKE_PROTOCOL_TEMPLATE.json')
assert V['status']==RV['status']=='PASS' and V['binary_sha256']==sha(H/'build/ccmckp_s10') and RV['production_reader_sha256']==sha(H/'audit_reader.py')
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  args=(p/'cmdline').read_bytes().split(b'\0')
  assert not any(str(H).encode() in a and (b'controller.py' in a or b'ccmckp_s10' in a or b'audit_reader.py' in a) for a in args),'Existing B1-v2 process'
 except OSError:pass
manifest=read(H/'source/BENCHMARK_MANIFEST.json');pins={}
for c in P['cases']:
 for n,h in manifest[c['instance']].items():
  p=B/'benchmark'/c['instance']/n;assert sha(p)==h
  pins['benchmark/'+c['instance']+'/'+n]=h
available=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
assert available>6*2**30 and shutil.disk_usage(H).free>6*2**30
(H/'bin').mkdir();shutil.copy2(H/'build/ccmckp_s10',H/'bin/ccmckp_s10')
F.mkdir()
for n in ['runs','outcomes','logs']:(F/n).mkdir()
support=['controller.py','audit_reader.py','linear_reader.py','be_reader.py','native_reader.py','r05_fft_reader.py']
for n in support:shutil.copy2(H/n,F/n)
P['source_and_binary_pins']={'../source/'+p.relative_to(H/'source').as_posix():sha(p) for p in (H/'source').rglob('*') if p.is_file()}
P['source_and_binary_pins']['../bin/ccmckp_s10']=sha(H/'bin/ccmckp_s10')
for n in ['USER_DESIGN.md','SOURCE_MANIFEST_SHA256.json','VALIDATION.json','READER_VALIDATION.json']:P['source_and_binary_pins']['../'+n]=sha(H/n)
for n in support:P['source_and_binary_pins'][n]=sha(F/n)
P['input_pins']=pins;P['registered_utc']=datetime.now(timezone.utc).isoformat()
(F/'PROTOCOL.json').write_text(json.dumps(P,ensure_ascii=False,indent=2))
record={'status':'FROZEN_SMOKE_READY','registered_runs':35,'max_workers':60,'protocol_sha256':sha(F/'PROTOCOL.json'),
 'binary_sha256':sha(H/'bin/ccmckp_s10'),'available_GiB':available/2**30,'free_disk_GiB':shutil.disk_usage(H).free/2**30,
 'source_pins':len(P['source_and_binary_pins']),'input_pins':len(pins),'quality_gate':P['pre_registered_quality_gate']}
(F/'FROZEN.json').write_text(json.dumps(record,indent=2));print(json.dumps(record))
