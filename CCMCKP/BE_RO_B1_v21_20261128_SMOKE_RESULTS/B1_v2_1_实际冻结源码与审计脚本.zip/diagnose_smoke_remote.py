from pathlib import Path
from collections import Counter
import json
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b1_v21_20261128';F=H/'smoke';V=B/'work/be_ro_b1_v2_20261128/smoke'
assert Path.cwd()==B
read=lambda p:json.loads(p.read_text())
P=read(F/'PROTOCOL.json');outs=sorted((read(p) for p in (F/'outcomes').glob('*.json')),key=lambda x:(x['case_index'],x['rep']))
assert len(outs)==35,'Wait for all35 terminal records'
diag=[]
for o in outs:
 root=F/'runs'/o['identity'];raw=read(root/'S10_search.json');m=raw['BE_RO_model'];res=read(root/'RESULT.json') if (root/'RESULT.json').exists() else None
 limit=P['pre_registered_quality_gate']['best_cost_max'][str(o['case_index'])]
 archive=sorted(m['archive'],key=lambda x:x['cost']);cheap=[x for x in archive if x['cost']<=limit]
 decision={tuple(x['selection']):x['decision'] for x in m['candidates']}
 d={'identity':o['identity'],'case_index':o['case_index'],'rep':o['rep'],'seed':o['seed'],'final_cost':res['cost'] if res else None,
 'LSS':res['original_LSS_confidence'] if res else None,'whole_seconds':o['process_wall_seconds'],
 'omega_resource_used':m.get('omega_resource_used'),'coarse_r_star':m.get('coarse_r_star'),'zoom_interval':m.get('zoom_interval'),
 'omega_best':m.get('omega_best'),'private_grid_min_cost':m.get('private_grid_global_min_cost'),'archive_min_cost':m.get('archive_min_cost'),
 'archive_count':len(archive),'under_best_limit_archive_count':len(cheap),
 'under_best_limit_decisions':dict(Counter(decision.get(tuple(x['selection']),'not_CDF_attempted') for x in cheap)),
 'candidate_decisions':dict(Counter(x['decision'] for x in m['candidates'])),
 'native_states':dict(Counter(x['state'] for x in m['native_calls'])),
 'grid_trace':m['calibration'],'critical_points':m['critical_points'],'escape':m['escape'],'epsilon_fft_final':m['epsilon_fft_final']}
 if o['rep']==1:
  old=read(V/'runs'/('BE_RO_B1_V2_i%02d_r01'%o['case_index'])/'S10_search.json')['BE_RO_model']
  if o['case_index'] in [8,28]:
   q=old['calibration'][0];lookup={tuple(a['selection']):a for a in old['archive']}
   d['previous_v2_first_midpoint']={'omega':q['omega'],'private_probability':q.get('private_probability'),
    'cost':lookup[tuple(q['selection'])]['cost'] if 'selection' in q else None,
    'previous_archive_min_cost':min(a['cost'] for a in old['archive'])}
  previous=sorted(old['certified_pool'],key=lambda q:q['cost'])
  if previous:
   ref=previous[0];same=next((q for q in archive if q['selection']==ref['selection']),None)
   old_call=next((q for q in old['native_calls'] if q['selection']==ref['selection']),None)
   d['postrun_only_previous_candidate_comparison']={'cost':ref['cost'],'old_epsilon_final':old['epsilon_fft_final'],
    'old_private_probability':old_call.get('private_probability') if old_call else None,
    'new_archive_contains_same_vector':same is not None,'new_private_probability':same['private_probability'] if same else None,
    'new_decision':decision.get(tuple(ref['selection'])) if same else None,
    'old_native_calls_mode':old_call.get('mode') if old_call else None,'used_as_solver_input':False}
 diag.append(d)
p=F/'POSTRUN_DIAGNOSTICS.json';data=json.dumps(diag,ensure_ascii=False,indent=2)
if p.exists():assert p.read_text()==data
else:p.write_text(data)
print(json.dumps([{'case':d['case_index'],'cost':d['final_cost'],'rstar':d['coarse_r_star'],'omega_best':d['omega_best'],
 'under_best_limit_count':d['under_best_limit_archive_count'],'under_best_limit_decisions':d['under_best_limit_decisions'],
 'old':d.get('previous_v2_first_midpoint'),'previous_candidate':d.get('postrun_only_previous_candidate_comparison')} for d in diag if d['rep']==1]))
