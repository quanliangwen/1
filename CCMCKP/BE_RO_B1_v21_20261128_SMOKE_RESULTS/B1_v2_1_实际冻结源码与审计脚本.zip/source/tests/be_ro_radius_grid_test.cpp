#include "be_ro_radius_grid.hpp"
#include "model.hpp"
#include <iostream>
using namespace s10;
int main(){
 try{
  int checks=0;
  for(const char*raw:{"0","1/1000","1/20","1","5099/1000","599/100","8"}){
   BERadiusGrid g{mpq_class(raw)};
   for(int r=1;r<=8;++r){
    mpq_class expected=g.maximum*r/8;expected.canonicalize();
    if(g.coarse(r)!=expected)throw std::logic_error("Coarse formula");++checks;
    auto v=g.interval(r);
    for(int q=1;q<=8;++q){
     auto x=g.zoom(q,r);mpq_class expected=v.first+mpq_class(q)*(v.second-v.first)/9;expected.canonicalize();
     if(x!=expected)throw std::logic_error("Zoom formula");
     if(g.maximum>0&&!(v.first<x&&x<v.second))throw std::logic_error("Strict interior point");++checks;
    }
    for(const auto&x:g.pool(g.coarse(r))){if(x<0||x>g.maximum)throw std::logic_error("Pool clipping");++checks;}
   }
  }
  BERadiusGrid eight{mpq_class(5099,1000)},twentyeight{mpq_class(599,100)};
  if(!(eight.coarse(3)>mpq_class(19,10)&&eight.coarse(3)<2))throw std::logic_error("Case8 document grid window");
  if(!(twentyeight.zoom(4,5)>mpq_class(28,10)&&twentyeight.zoom(4,5)<mpq_class(295,100)))throw std::logic_error("Case28 document grid window");
  std::cout<<Json({{"status","PASS"},{"grid_checks",checks},{"arbitrary_window_hit_guarantee",false}}).dump()<<'\n';return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}
}
