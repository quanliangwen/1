#pragma once
#include <gmpxx.h>
#include <algorithm>
#include <stdexcept>
#include <utility>
#include <vector>

namespace s10 {
// Fixed finite coverage, not an assumption of monotonic candidate probability
// and not a guarantee of hitting every arbitrarily narrow feasible window.
struct BERadiusGrid {
 mpq_class maximum;
 explicit BERadiusGrid(mpq_class upper):maximum(std::move(upper)){
  maximum.canonicalize();if(maximum<0)throw std::logic_error("Negative grid radius");
 }
 mpq_class coarse(int r)const{
  if(r<0||r>8)throw std::logic_error("Coarse index");
  mpq_class x=maximum*r/8;x.canonicalize();return x;
 }
 std::pair<mpq_class,mpq_class> interval(int rstar)const{
  if(rstar<1||rstar>8)throw std::logic_error("Invalid winning index");
  return {coarse(std::max(0,rstar-2)),coarse(rstar)};
 }
 mpq_class zoom(int q,int rstar)const{
  if(q<1||q>8)throw std::logic_error("Zoom index");
  auto v=interval(rstar);mpq_class weight=mpq_class(q)/9;weight.canonicalize();
  mpq_class x=v.first+weight*(v.second-v.first);x.canonicalize();return x;
 }
 std::vector<mpq_class> pool(mpq_class best)const{
  auto clip=[&](mpq_class x){x.canonicalize();return std::min(maximum,std::max(mpq_class(0),x));};
  std::vector<mpq_class>out;
  for(auto p:{clip(std::max(mpq_class(1,20),mpq_class(best*24/25))),clip(best),clip(mpq_class(best*26/25))})
   if(std::find(out.begin(),out.end(),p)==out.end())out.push_back(p);
  return out;
 }
};
}
