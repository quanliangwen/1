from pathlib import Path
import json,hashlib,difflib,base64,io,zipfile
R=Path(__file__).resolve().parent;V2=Path('E:/codex/CCMCKP_BE_RO_B1_v2_20261128')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old={p.relative_to(V2/'source').as_posix():sha(p) for p in (V2/'source').rglob('*') if p.is_file()}
new={p.relative_to(R/'source').as_posix():sha(p) for p in (R/'source').rglob('*') if p.is_file()}
changed=sorted(n for n in old if old[n]!=new.get(n));added=sorted(set(new)-set(old))
assert changed==['CMakeLists.txt','be_ro_search.cpp'] and added==['be_ro_radius_grid.hpp','tests/be_ro_radius_grid_test.cpp']
a=(V2/'source/be_ro_search.cpp').read_text();b=(R/'source/be_ro_search.cpp').read_text()
blocks={}
for name,start,end in [('certification_and_archive_gate',' // No final LSS',' try{\n  const double rbegin'),
 ('resource_step1','  const double rbegin','  lo=0;hi=maximum;'),('escalation_step5','  mpq_class esc=star;',' }catch(const BudgetExpired&)')]:
 left=a[a.index(start):a.index(end,a.index(start))]
 if name=='resource_step1':right=b[b.index(start):b.index('  BERadiusGrid grid',b.index(start))]
 else:right=b[b.index(start):b.index(end,b.index(start))]
 assert left==right,name;blocks[name]=hashlib.sha256(left.encode()).hexdigest()
assert (V2/'audit_reader.py').read_bytes()==(R/'audit_reader.py').read_bytes()
manifest={'scope':'B1-v2.1 source; only radius localization/pool scheduling changed','files':new}
(R/'SOURCE_MANIFEST_SHA256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
review={'status':'PASS','scope':'Static preservation only, not algorithm validation','changed':changed,'added':added,
 'unchanged_source_files':len(old)-len(changed),'unchanged_blocks':blocks,
 'linear_model_witness_native_main_unchanged':True,'production_audit_main_identical_to_v2':True,
 'reader_schema_change':'Only .5s coarse/zoom allowance and explicit geometry/argmin/metadata checks; Fraction and native/LSS kernels retained',
 'old_v2_results_untouched':True}
(R/'STATIC_REVIEW.json').write_text(json.dumps(review,indent=2),encoding='utf-8')
patch=[]
for n in changed+added:
 before=(V2/'source'/n).read_text().splitlines(keepends=True) if n in old else []
 after=(R/'source'/n).read_text().splitlines(keepends=True)
 patch.extend(difflib.unified_diff(before,after,fromfile='a/source/'+n if n in old else '/dev/null',tofile='b/source/'+n))
(R/'SOURCE_DIFF.patch').write_text(''.join(patch),encoding='utf-8')
P=json.loads((V2/'FULL_PROTOCOL_TEMPLATE.json').read_text(encoding='utf-8'))
P.update(schema='BE_RO_B1_v21_two_level_radius_grid_v1',arms=[{'name':'BE_RO_B1_V21','flow':'be_ro_pure','gamma':None}],
 model='B1-v2.1 beta=.95,K=5;8 coarse+8 zoom,.5s;3 pool radii,1s;10lambda grid unchanged',
 user_design_sha256=sha(R/'USER_DESIGN.md'),scope='Fresh B1-v2.1 single-model cold starts only; old runs retained',
 seed_base=1284200,seeds=list(range(1284201,1284231)),radius_grid={'coarse':8,'zoom':8,'left_cells':2,'zoom_denominator':9,'scan_seconds':.5,'pool_seconds':1},
 first_wave_gate='Technical integrity only;35-run external quality gate must first pass')
smoke=dict(P);smoke.update(cases=[c for c in P['cases'] if c['index'] in [8,18,28,35,36,38,39]],repetitions=5,total_runs=35,
 seed_base=1284100,seeds=list(range(1284101,1284106)),first_wave_runs=0,first_wave_reps=5,first40_included_in_registered1200=False)
smoke['pre_registered_quality_gate']={'all35_independently_valid':True,'global_errors_empty':True,'TIME_LIMIT_zero_solution_queries':0,
 'best_cost_max':{'8':11.18515,'18':142.27125,'28':16.42365,'35':194.09625,'36':159.28105,'38':196.27715,'39':325.05},
 'avg_cost_max':{'8':11.18515,'18':142.32,'28':16.42365,'35':194.40,'36':159.35,'38':196.35},
 'threshold_basis':'Exact prospective thresholds from user B1-v2.1 design section5; not applied retroactively to v2',
 'max_whole_seconds_per_run':600,'no_after_result_relaxation':True}
(R/'SMOKE_PROTOCOL_TEMPLATE.json').write_text(json.dumps(smoke,ensure_ascii=False,indent=2),encoding='utf-8')
(R/'FULL_PROTOCOL_TEMPLATE.json').write_text(json.dumps(P,ensure_ascii=False,indent=2),encoding='utf-8')
payload=io.BytesIO()
with zipfile.ZipFile(payload,'w',zipfile.ZIP_DEFLATED) as z:
 for p in (R/'source').rglob('*'):
  if p.is_file():z.write(p,'source/'+p.relative_to(R/'source').as_posix())
 for n in ['linear_reader.py','be_reader.py','native_reader.py','r05_fft_reader.py','audit_reader.py','controller.py','validate_remote.py','USER_DESIGN.md','SOURCE_MANIFEST_SHA256.json','STATIC_REVIEW.json','SMOKE_PROTOCOL_TEMPLATE.json','FULL_PROTOCOL_TEMPLATE.json']:
  z.write(R/n,n)
blob=base64.b64encode(payload.getvalue()).decode()
script='''from pathlib import Path
import subprocess,json,base64,zipfile,io,shutil,hashlib
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b1_v21_20261128';V=B/'work/be_ro_b1_v2_20261128'
assert Path.cwd()==B and not H.exists(),'No overwrite or implicit restart'
assert json.loads((V/'smoke/COMPLETED.json').read_text())['terminal']==35
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  args=(p/'cmdline').read_bytes().split(b'\\0')
  assert not any((str(V).encode() in a or str(H).encode() in a) and any(k in a for k in [b'controller.py',b'ccmckp_s10',b'audit_reader.py']) for a in args),'Existing task process'
 except OSError:pass
H.mkdir()
with zipfile.ZipFile(io.BytesIO(base64.b64decode(PAYLOAD))) as z:
 for n in z.namelist():
  p=(H/n).resolve();assert H.resolve() in p.parents;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
for n,h in json.loads((H/'SOURCE_MANIFEST_SHA256.json').read_text())['files'].items():assert hashlib.sha256((H/'source'/n).read_bytes()).hexdigest()==h
for n in ['be_ro_linear.hpp','be_ro_linear.cpp','be_ro_witness.hpp','tests/be_ro_linear_test.cpp']:
 assert (H/'source'/n).read_bytes()==(V/'source'/n).read_bytes()
shutil.copytree(V/'fixtures',H/'fixtures')
for p in V.glob('linear_math_*.log'):shutil.copy2(p,H/p.name)
commands=[['cmake','-S',str(H/'source'),'-B',str(H/'build'),'-DCMAKE_BUILD_TYPE=Release','-DS10_BUILD_BE_GRID_TESTS=ON','-DS10_GUROBI_INCLUDE='+str(B/'work/egs_oa_validation_20261123/validation_deps'),'-DS10_GUROBI_LIBRARY=/home/junhao/.local/lib/python3.8/site-packages/gurobipy/.libs/libgurobi110.so'],['cmake','--build',str(H/'build'),'--target','ccmckp_s10','be_ro_radius_grid_test','-j','4']]
for i,cmd in enumerate(commands):
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=500);(H/('build_%d.log'%i)).write_bytes(p.stdout)
 print(json.dumps({'step':i,'rc':p.returncode,'tail':p.stdout.decode(errors='replace')[-2200:]}),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
print(json.dumps({'status':'COMPILED','binary_sha256':hashlib.sha256((H/'build/ccmckp_s10').read_bytes()).hexdigest()}))
'''.replace('PAYLOAD',repr(blob))
(R/'prepare_build_remote.py').write_text(script,encoding='utf-8')
print(json.dumps(review))
