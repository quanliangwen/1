"""Completed negative case38, exact saved paths only; no new native draws."""
from pathlib import Path
from collections import Counter
import gzip,hashlib,json,shutil,statistics,zipfile
ROOT=Path(__file__).resolve().parents[1];HERE=ROOT/'reporting';E=HERE/'case38_evidence';DEST=Path(r'E:\codex\CCMCKP_DRO_R04_20261101\github_staging_20261102\CCMCKP\B_CDF_DRO_MITM_R09_20261102')
read=lambda p:json.loads(p.read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
diag=read(E/'CASE38_TERMINAL_DIAGNOSIS.json');b=diag['summaries']['B'];c=diag['summaries']['R09'];assert b['valid']==c['valid']==30 and c['avg']>b['avg']
with zipfile.ZipFile(E/'completed_case_evidence.zip') as z:
 manifest=json.loads(z.read('CASE_EXPORT_MANIFEST.json'))
 for n,v in manifest['files'].items():
  raw=z.read(n);assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256']
 runs={arm:[json.loads(gzip.decompress(z.read(arm+'/r%02d.json.gz'%i))) for i in range(1,31)] for arm in ('B','R09')}
best=min((d['selected'] for d in runs['B']),key=lambda x:x['cost']);target=tuple(best['selection']);quality={};paths={}
for arm,rows in runs.items():
 visits=[];times=[];negative=0;distances=[];costs=[];orig_sources=Counter()
 for d in rows:
  hits=[e['elapsed'] for e in d['events'] if e.get('event')=='native_incumbent' and e['cost']<=b['avg']+1e-8];times.append(min(hits) if hits else None)
  observed=[o for o in d['native_observations'] if tuple(o['selection'])==target];visits.append(len(observed));negative+=any(o['probability']<.99 and not o['source'].startswith('CF2_risk_pair_delta') for o in observed)
  orig_sources.update(o['source'] for o in observed)
  h=next((h for h in d['match_history'] if h.get('engine')=='CF2_risk_budget_pair' and h['active']),None)
  if h:
   accepted=[a for a in h['attempts'] if a['accepted_original_native']]
   final=accepted[-1]['selection'] if accepted else h['rounds'][0]['root_selection']
   finalcost=accepted[-1]['cost'] if accepted else h['rounds'][0]['root_cost']
   distances.append(sum(x!=y for x,y in zip(final,target)));costs.append(finalcost)
 hit=[t for t in times if t is not None];quality[arm]={'hits':len(hit),'conditional_mean_seconds':statistics.mean(hit) if hit else None,'restricted_mean_seconds':statistics.mean(t if t is not None else 600 for t in times),'fixed_B_mean_cost_target':b['avg']}
 paths[arm]={'Bbest_native_visited_runs':sum(v>0 for v in visits),'Bbest_native_calls':sum(visits),'Bbest_nonCF2_negative_observation_runs_all30':negative,'Bbest_observation_source_counts':dict(orig_sources),'after_CF2_root_distance_to_Bbest_counts':dict(Counter(distances)),'after_CF2_cost_counts':dict(Counter(costs))}
extra={'scope':'All30 records/arm, original saved paths only. No native evaluation or search. Historical Bbest used only for retrospective visitation/Hamming audit, never worker input.','correction_to_A01':'A01 nonCF2-negative counter was only computed inside CF2-active branch, so its B=0 did not mean zero B negatives. A02 computes all30; no official cost statistics or trials changed.','common_quality':quality,'paths':paths,'Bbest_selection_SHA256':hashlib.sha256(json.dumps(list(target)).encode()).hexdigest(),'interpretation':'Local-CF2 missing visits and slower earlier MITM stage can both limit coverage. Fewer completed original stages is an observation, not proof that memory bandwidth alone caused regression. Prior old-CDF ordering was a preference, never hard exclusion.'}
out=E/'CASE38_FAILURE_PATH_DIAGNOSIS_A02.json';assert not out.exists();out.write_text(json.dumps(extra,ensure_ascii=False,indent=2),encoding='utf-8')
deep=read(E/'CASE38_DEEP_TIME_AUDIT.json');tr=read(E/'CASE38_CF2_TRANSITION_AUDIT.json');assert deep['passed'] and tr['passed']
bounds={arm:max(x['clock_chain_seconds'][1] for x in deep['rows'] if x['arm']==arm) for arm in ('B','R09')};assert max(bounds.values())<=585 and deep['max_actual_elapsed']<=600
lines=['R09固定先导38例：有效运行但性能失败，禁止据此扩大全量','', 'B与候选各登记30、有效30、失败0；不足30官方统计留空的规则未改变。本例没有重跑有效波，候选源码281文件冻结不变。', '版本\tbest\tavg\t样本std\tCV\t自身最终最好首次均秒\t版本30次best命中数\t命中条件均秒\t实际均秒']
for arm,s in [('B',b),('R09',c)]:lines.append('\t'.join(map(str,[arm,s['best'],s['avg'],s['std'],s['CV'],s['mean_final_best_first_seconds'],s['best_hits'],s['conditional_best_hit_seconds'],s['mean_actual_runtime']])))
pp=diag['paired'];lines+=['',f'均成本退化{pp["relative_mean_difference"]:.8%}，差均值{pp["mean_difference"]:.12g}；描述性配对95%区间{pp["paired_bootstrap_95"]}，dz={pp["paired_dz"]:.9f}，原p={pp["p"]}；预定七例Holm校正等待全部终末，不选单例另定家族。std和CV也上升。最好值相同不能说明整体改善。', '达到自己更差最终解的平均时间较短，不等同相同质量提速。预定B均成本共同目标：',json.dumps(quality,ensure_ascii=False), 'B最好向量的原生访问、CF2后自身解与该向量距离：',json.dumps(paths,ensure_ascii=False),f'CF2实际30次激活，共{tr["attempts_checked"]}条提案记录、{tr["native_calls_linked"]}条原生调用、{tr["accepted_transitions_checked"]}次接受交换，均与本次原生观测重建的当前最好解和接受事件相连；没有用历史向量热启动。',f'原始MITM首阶段均时B {diag["phases"]["B"]["mean_first_stage_end"]:.9f}秒，R09 {diag["phases"]["R09"]["mean_first_stage_end"]:.9f}秒；平均完成原阶段B {diag["phases"]["B"]["mean_original_stages"]:.9f}，R09 {diag["phases"]["R09"]["mean_original_stages"]:.9f}。这段耗时在CF2调用之前，不能归因于尚未执行的CF2；并发/共享负载和初始化上下文限制因果解释，不能证明内存带宽单因子。',f'独立60记录/3660输入SHA/原生{deep["native_observations_checked"]}条检查通过，实际最大{deep["max_actual_elapsed"]:.9f}秒，全部工作结束的保守上界{json.dumps(bounds)}均小于585；无额外MC抽样。', '该例已违反逐例均成本不劣，R09先导必不通过。仍完成其余已登记七例，保留失败，不改源码/参数/门槛，不补跑选优，也不自动扩大1200次。完整目标仍在进行中，不能用其他例收益豁免38。', '源码解释勘误：旧R07/R08F仅优先CDF不下降的候选，其他候选仍可原生评价；不是硬性禁止CDF下降。R09替换辅助代理及排序，原完整CDF评分、原生评价器、半径、主问题和接受门槛不变；新旧有限时间实际尝试集合可能不同，不声称同代理评分下的纯搜索消融。', 'MC返回值仍是原评价器观察值，不是未知真分布覆盖证书。固定套件/种子多轮探索选择未校正，描述性区间和后续Holm不消除此限制。源代码/所有负结果和审计逐成员数据均保留。', '下一机制仅研究精确top-k合并与按块PDF缓存，尚未正式冻结/性能测试，不预称加速。已读Batagelj(2023) Exactly mergeable summaries, arXiv:2303.15465v1全文8页，核对Sect2式1、2.1.1例4的top-k扩展、2.1.4组合证明：https://arxiv.org/pdf/2303.15465。该文是原始预印本，不证明CCMCKP速度或全局最优；必须另证成本桶/稳定排序/原裁剪等值并做组件检查。R02重物化串行较慢的负证据不删。']
(DEST/'CASE38_失败结论与诊断.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8');shutil.copyfile(E/'completed_case_evidence.zip',DEST/'case38_completed_evidence.zip');shutil.copyfile(E/'CASE38_TERMINAL_DIAGNOSIS.json',DEST/'CASE38_TERMINAL_DIAGNOSIS.json');shutil.copyfile(out,DEST/out.name)
with zipfile.ZipFile(DEST/'case38_diagnostic_revisions.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in [E/'CASE38_FAILURE_PATH_DIAGNOSIS.json',out,HERE/'diagnose_case38_failure.py',Path(__file__)]:z.write(p,p.name)
status=DEST/'当前状态.txt';status.write_text('更新：R09的38例30/30有效，但均成本退化+.09547979%、std/CV上升，逐例门槛失败，禁止全量扩展；其他已登记先导继续。详见CASE38_失败结论与诊断.txt。\n\n'+status.read_text(encoding='utf-8'),encoding='utf-8')
m={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(DEST.iterdir()) if p.is_file() and p.name not in ('FILE_MANIFEST.json','SHA256SUMS.txt')};(DEST/'FILE_MANIFEST.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8');(DEST/'SHA256SUMS.txt').write_text(''.join(v['sha256']+'  '+n+'\n' for n,v in m.items())+sha(DEST/'FILE_MANIFEST.json')+'  FILE_MANIFEST.json\n',encoding='utf-8');print(json.dumps({'case38_valid':30,'performance_failure':True,'common_quality':quality,'paths':paths,'files':len(m)},ensure_ascii=False))
