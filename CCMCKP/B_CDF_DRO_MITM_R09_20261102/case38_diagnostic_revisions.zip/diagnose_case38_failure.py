"""All completed case38 records, no oracle, no proposal or weight transfer."""
import gzip,hashlib,json,statistics,zipfile
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[1];E=ROOT/'reporting/case38_evidence';out=E/'CASE38_FAILURE_PATH_DIAGNOSIS.json';assert not out.exists()
with zipfile.ZipFile(E/'completed_case_evidence.zip') as z:
 records={arm:[json.loads(gzip.decompress(z.read(arm+'/r%02d.json.gz'%i))) for i in range(1,31)] for arm in ('B','R09')}
best=min((d['selected'] for d in records['B']),key=lambda x:x['cost']);target=tuple(best['selection']);result={}
for arm,rows in records.items():
 visits=[];rootcost=[];phase_seconds=[];stops=Counter();attempts=Counter();best_trial=0;best_accepted=0;best_negative_before_CF2=0;target_times=[]
 for d in rows:
  hit=[o for o in d['native_observations'] if tuple(o['selection'])==target];visits.append(len(hit))
  if hit:target_times.append(hit[0]['elapsed'])
  stage=[h for h in d['match_history'] if h.get('engine')=='CF2_risk_budget_pair']
  if stage and stage[0]['active']:
   h=stage[0];phase_seconds.append(h['seconds']);stops[h['stop_reason']]+=1;attempts[len(h['attempts'])]+=1
   if h['rounds']:rootcost.append(h['rounds'][0]['root_cost'])
   for a in h['attempts']:
    if tuple(a['selection'])==target:best_trial+=1;best_accepted+=a['accepted_original_native']
   # A prior non-CF2 negative visit is in original cache, which local seen excludes.
   if any(o['probability']<.99 and not o['source'].startswith('CF2_risk_pair_delta') for o in hit):best_negative_before_CF2+=1
 result[arm]={'Bbest_original_native_visited_runs':sum(n>0 for n in visits),'Bbest_original_native_call_count':sum(visits),'Bbest_visit_counts':dict(Counter(visits)),'Bbest_first_visit_conditional_mean_seconds':statistics.mean(target_times) if target_times else None,'CF2_root_cost_counts':dict(Counter(rootcost)),'CF2_phase_seconds_mean':statistics.mean(phase_seconds) if phase_seconds else None,'CF2_phase_seconds_max':max(phase_seconds) if phase_seconds else None,'CF2_stop_reason_counts':dict(stops),'CF2_attempt_count_distribution':dict(attempts),'Bbest_attempts_within_CF2':best_trial,'Bbest_accepted_within_CF2':best_accepted,'Bbest_any_nonCF2_negative_record_runs':best_negative_before_CF2,'negative_visit_note':'This records any nonCF2 negative visit in the whole run, not proof it happened before CF2; inspect timestamps if asserting cache exclusion.'}
d={'scope':'All completed30/arm original records only. Bbest vector identified for retrospective visit auditing; only its SHA exported, never input to new workers. No extra native draws or optimization. No parameter change after results.','Bbest_cost':best['cost'],'Bbest_selection_sha256':hashlib.sha256(json.dumps(list(target)).encode()).hexdigest(),'arms':result,'causal_limit':'Longer original first stage precedes CF2 invocation; cannot attribute that earlier wall time to CF2 code. Shared load/concurrency/global initialization differences confound cause. Old ordering was preference, not hard CDF-nondecrease constraint.'}
out.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(d,ensure_ascii=False))
