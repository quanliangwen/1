"""Independent own-incumbent/native-record transition audit. No oracle draws.

Additional reporting only; never changes the frozen algorithm or decision gates.
Uses saved chronological original native observations, not self-reported CF2
accepted booleans alone. No Solver import, probability evaluation or new search.
"""
import argparse,gzip,json,math,pickle,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from common import read,atomic,sha,check_freeze

def main():
 import numpy as np
 ap=argparse.ArgumentParser();ap.add_argument('--snapshot');ap.add_argument('--case',type=int);a=ap.parse_args();freeze=check_freeze()
 if a.snapshot:
  records=[x for x in read(a.snapshot)['terminal_records'] if x['arm']=='R09'];out=Path(a.snapshot).with_name('CF2_TRANSITION_AUDIT.json')
 else:
  assert a.case;folder=ROOT/read(ROOT/'WAVE_POINTERS'/('R09_pilot_c%02d.json'%a.case))['relative_dir'];assert read(folder/'WAVE.json')['status'] in ('valid_complete','ordinary_failure_complete')
  records=[dict(x,index=a.case,wave=str(folder),arm='R09') for x in read(folder/'AUDIT.json')];out=ROOT/'reporting'/('CASE%02d_CF2_TRANSITION_AUDIT.json'%a.case)
 assert not out.exists();inputs=read(ROOT/'INPUTS.json');cache={};rows=[]
 for rec in records:
  if not rec['valid']:continue
  raw=Path(rec['wave'])/('r%02d.json.gz'%rec['rep']);d=json.loads(gzip.decompress(raw.read_bytes()));instance=d['instance']
  if instance not in cache:
   folder=next(Path(p).parent for p in inputs if Path(p).parent.name==instance)
   for name in ('cost.txt','node_to_factor.pkl'):assert sha(folder/name)==inputs[str(folder/name)]
   cost=np.asarray(np.loadtxt(folder/'cost.txt')).reshape(-1)
   with (folder/'node_to_factor.pkl').open('rb') as f:groups=pickle.load(f)
   if isinstance(groups,dict):groups=[groups[k] for k in sorted(groups,key=lambda x:int(x))]
   membership={int(j):g for g,ids in enumerate(groups) for j in ids};cache[instance]=(cost,groups,membership)
  cost,groups,membership=cache[instance]
  def selection(ids):
   assert len(ids)==len(groups) and len(set(ids))==len(ids) and all(membership[j]==g for g,j in enumerate(ids));return float(cost[ids].sum())
  stages=[(i,h) for i,h in enumerate(d['match_history']) if h.get('engine')=='CF2_risk_budget_pair'];assert len(stages)<=1
  observations=d['native_observations'];cf_native=[(i,o) for i,o in enumerate(observations) if o['source'].startswith('CF2_risk_pair_delta')];attempts=[];accepted=0;used=[]
  if stages:
   position,h=stages[0];assert sum('left' in x for x in d['match_history'][:position])==1
   if h['active']:
    attempts=h['attempts'];assert len(attempts)<=8 and h['native_calls']==len(cf_native)
    assert h['delta']==.00025 and h['proxy_targets']==[.99,.975] and h['soft_phase_seconds']==20. and h['max_distinct_proposals']==8
    assert len({tuple(x['selection']) for x in attempts})==len(attempts)
    for at in attempts:
     assert math.isclose(selection(at['selection']),at['cost'],abs_tol=1e-8,rel_tol=0)
     rootcost=selection(at['root_selection']);assert at['cost']<rootcost-1e-8
     changes=[g for g,(x,y) in enumerate(zip(at['root_selection'],at['selection'])) if x!=y];assert changes==at['groups_changed'] and 1<=len(changes)<=2
     assert at['nominal_quantile_proxy']<d['capacity'] and at['robust_quantile_proxy']<=d['capacity']-d['capacity']/d['config']['bins']
     assert at['native_calls'] in (0,1)
     if at['native_calls']:
      assert len(used)<len(cf_native);index,obs=cf_native[len(used)];used.append(index)
      assert obs['selection']==at['selection'] and obs['cost']==at['cost'] and obs['probability']==at['native_return'] and obs['elapsed']<=at['elapsed']
      assert at['original_full_CDF_score']>=.975;prefix=observations[:index]
     else:
      assert at['native_return'] is None;prefix=[o for o in observations if o['elapsed']<at['elapsed']]
     incumbent=None
     for o in prefix:
      if o['probability']>=.99 and (incumbent is None or o['cost']<incumbent['cost']-1e-8):incumbent=o
     assert incumbent is not None and incumbent['selection']==at['root_selection'],('root is not own chronological incumbent',rec['index'],rec['rep'])
     native_accepted=bool(at['native_calls'] and at['native_return']>=.99)
     assert at['accepted_original_native']==native_accepted
     if native_accepted:
      events=[e for e in d['events'] if e.get('event')=='native_incumbent' and e['source'].startswith('CF2_risk_pair_delta') and abs(e['cost']-at['cost'])<=1e-8 and e['p']==at['native_return'] and e['elapsed']<=at['elapsed']]
      assert len(events)==1;accepted+=1
  assert len(used)==len(cf_native)
  rows.append({'index':rec['index'],'rep':rec['rep'],'active':bool(stages and stages[0][1]['active']),'attempts':len(attempts),'native_calls_linked':len(cf_native),'original_native_accepted_own_root_transitions':accepted,'raw_sha256':sha(raw)})
 result={'passed':True,'freeze_sha':freeze,'scope':'All valid candidate rows in selected terminal snapshot/case; each proposal linked to original native observations/events and own chronological incumbent. No oracle evaluation, no optimization, no fitted weights, no change to performance gates. Invalid runs remain in separate all-attempt audit.','valid_candidate_records':len(rows),'active_runs':sum(x['active'] for x in rows),'attempts_checked':sum(x['attempts'] for x in rows),'native_calls_linked':sum(x['native_calls_linked'] for x in rows),'accepted_transitions_checked':sum(x['original_native_accepted_own_root_transitions'] for x in rows),'rows':rows}
 atomic(out,result);print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
if __name__=='__main__':main()
