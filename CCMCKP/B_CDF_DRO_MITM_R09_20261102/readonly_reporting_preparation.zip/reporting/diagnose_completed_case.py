"""One completed fixed pilot case, original records only. No oracle or rerun.

A case result is not a pilot/full decision. Family Holm remains pending until
the seven preregistered cases all complete. Existing evidence is never replaced.
"""
import argparse,gzip,json,statistics,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from common import read,atomic,check_freeze
from audit_campaign import audit_wave
from statistics_campaign import summary,paired

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--case',type=int,required=True);a=ap.parse_args();idx=a.case;reg=read(ROOT/'PROTOCOL.json');assert idx in reg['pilot_cases'];out=ROOT/'reporting'/('CASE%02d_TERMINAL_DIAGNOSIS.json'%idx);assert not out.exists()
 case=next(x for x in reg['cases'] if x['index']==idx);pointer=read(ROOT/'WAVE_POINTERS'/('R09_pilot_c%02d.json'%idx));candidate=ROOT/pointer['relative_dir'];assert read(candidate/'WAVE.json')['status'] in ('valid_complete','ordinary_failure_complete')
 reference=Path(read(ROOT/'REFERENCE_REGISTRY.json')['waves'][str(idx)]['directory']);records={};summaries={};phases={}
 for arm,folder in [('B',reference),('R09',candidate)]:
  rows=audit_wave(folder,case,arm);assert len(rows)==30;records[arm]=rows;summaries[arm]=summary(rows);details=[]
  for rep in range(1,31):
   p=folder/('r%02d.json.gz'%rep)
   if not p.exists():details.append({'rep':rep,'raw_present':False});continue
   try:data=json.loads(gzip.decompress(p.read_bytes()))
   except Exception as exc:details.append({'rep':rep,'raw_present':True,'decoded':False,'raw_decode_error':repr(exc)});continue
   completed=[h for h in data['match_history'] if 'left' in h];first=585-completed[0]['remaining'] if completed else None
   details.append({'rep':rep,'raw_present':True,'decoded':True,'completed_original_stages':len(completed),'first_stage_end':first,'first_stage_end_only_lower_bound':bool(completed and completed[0]['remaining']==0),'native_calls':data['native_probability_calls'],'native_seconds':data['native_seconds'],'record_status':data['status'],'official_valid':rows[rep-1]['valid']})
  raw=[x for x in details if x.get('decoded')];ends=[x['first_stage_end'] for x in raw if x['first_stage_end'] is not None]
  phases[arm]={'mean_original_stages':statistics.mean(x['completed_original_stages'] for x in raw) if raw else None,'stage_counts':{str(n):sum(x['completed_original_stages']==n for x in raw) for n in sorted({x['completed_original_stages'] for x in raw})},'mean_first_stage_end':statistics.mean(ends) if ends else None,'first_stage_clamped_end_count':sum(x['first_stage_end_only_lower_bound'] for x in raw),'mean_native_calls':statistics.mean(x['native_calls'] for x in raw) if raw else None,'diagnostic_scope':'Raw available records, including partial saved records if an ordinary failure occurs; official validity and summary are separate.','rows':details}
 result={'index':idx,'freeze_sha':check_freeze(),'all60_valid_independently_rechecked':all(r['valid'] for rows in records.values() for r in rows),'summaries':summaries,'paired':paired(records['B'],records['R09'],20261101+idx),'Holm':'pending all7, not applied to a selected single result','phases':phases,'scope':'One completed registered pilot case only; no pilot/full decision, no new native draws or optimization. Lower concurrency/shared load confound whole-candidate timing effects.'}
 atomic(out,result);print(json.dumps({k:v for k,v in result.items() if k!='phases'}));print(json.dumps({k:{a:b for a,b in v.items() if a!='rows'} for k,v in phases.items()}))
if __name__=='__main__':main()
