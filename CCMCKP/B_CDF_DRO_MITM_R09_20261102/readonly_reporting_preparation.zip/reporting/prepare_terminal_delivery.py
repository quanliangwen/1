"""Actual terminal evidence only -> delivery; no solver/native call or launch."""
from pathlib import Path
import argparse,hashlib,json,shutil,statistics,zipfile
ROOT=Path(__file__).resolve().parents[1]
FREEZE='d43ebf6e43df1ada55cfcbe2465e3975599617b44884c00932514a2acb80cf92'
DEST=Path(r'E:\codex\CCMCKP_DRO_R04_20261101\github_staging_20261102\CCMCKP\B_CDF_DRO_MITM_R09_20261102')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
def value(x):
 if x is None:return ''
 if isinstance(x,float):return format(x,'.12g')
 return str(x)
def table(rows,fields):
 return ['\t'.join(label for label,key in fields)]+['\t'.join(value(r.get(key)) for label,key in fields) for r in rows]
def main():
 ap=argparse.ArgumentParser();ap.add_argument('evidence');ap.add_argument('--workbook-name',required=True);a=ap.parse_args();e=Path(a.evidence)
 d=read(e/'statistics_snapshot.json');assert d['freeze_sha']==FREEZE;which=d['which'];assert which in ('pilot','full');n=7 if which=='pilot' else 40
 state=d['campaign_state']['status'];assert state in ('pilot_failed_requires_diagnosis','pilot_integrity_audit_failed_no_expansion','performance_gates_passed_delivery_pending','full_failed_requires_new_mechanism')
 assert len(d['summaries'])==2*n and len(d['terminal_records'])==60*n
 b=[r for r in d['summaries'] if r['arm']=='B'];c=[r for r in d['summaries'] if r['arm']=='R09'];assert len(b)==len(c)==n
 gate=d['stage_gate'];deep=read(e/'DEEP_TIME_AND_NATIVE_RECORD_AUDIT.json');reserve=read(e/'TIME_RESERVE_REVIEW.json');attempts=read(e/'ALL_ATTEMPTS_TIME_AND_FAILURE_AUDIT.json')
 assert deep['passed'] and deep['freeze_sha']==FREEZE and deep['valid_runs_checked']==sum(r['valid'] for r in d['summaries'])
 assert reserve['actual_total_600_all_passed'] and attempts['freeze_sha']==FREEZE and attempts['no_valid_or_ordinary_wave_rerun']
 book=ROOT/'report_snapshots'/(a.workbook_name+'.xlsx');qa=read(ROOT/'report_snapshots'/('VISUAL_QA_'+a.workbook_name+'.json'))
 assert qa['all_new_sheets_visually_checked'] is True and qa['sheet_count']==(8 if which=='pilot' else 9) and qa['formula_error_count']==0
 assert qa['snapshot_sha256']==sha(e/'statistics_snapshot.json') and qa['workbook_sha256']==sha(book)
 lines=['R09 终末实验报告：结果与完整目标须分别验收','',f'范围：{which}，覆盖{n}/40例；实际终末状态：{state}。候选登记{sum(r["registered"] for r in c)}次，有效{sum(r["valid"] for r in c)}次；B均为有效历史对照复用，新B执行0次。',f'冻结门槛：成本={gate["cost_gate"]}，std/CV={gate["stability_gate"]}，共同质量目标时间={gate["time_gate"]}，综合={gate["performance_gate"]}。',
 '固定先导17、38、39、40、25、18、14，全例完成后判断。先导任何一例均成本退化即不通过；不得因其他例大幅改善而豁免。独立审计再通过才允许候选全40例全新1200次，先导不计入全量。队列耗尽、预检通过和正常退出均不等于改进成功。',
 '', '一、唯一基线与本轮单一改动',
 '唯一官方对照为上传B_CDF_DRO_MITM；保留原14个源码包成员、原问题每组恰选一项且成本最小化。R09继承R04有限支撑MGF全局提案、R06支持长度卷积、R08打包逆FFT；只将R07当前CDF不得下降的一/二组候选筛选替换为逐候选CF2风险预算排序。不使用I01、历史解模板或跨种子权重。',
 '独立有限支撑边际的累积量相加：K_sum(t)=sum_i K_i(t)。对每个候选重新计算总均值mu、方差v、三阶累积量k3、四阶累积量k4=central4-3v²。gamma=k3/v^(3/2)，eta=k4/v²。二阶Cornish–Fisher前向分位代理：q(z)=z+gamma(z²-1)/6+eta(z³-3z)/24-gamma²(2z³-5z)/36；Q=mu+sqrt(v)q(z)。',
 '名义边际严格遵循原生实际样本支撑：原MC使用raw[:-1]，精确分支使用全部样本。鲁棒代理使用原delta=.00025、原向上取整网格和原全支撑扰动，保留溢出尾质量且不重归一化。仅生成Q_nominal(.99)<T、Q_robust(.975)<=T-T/4096且成本严格下降的候选，要求前向分位分支在[0,z]递增，零方差单独处理。',
 '原第一个MITM阶段后仅调用一次，软限20秒、至多8个不同提案，按成本和字典序排列；每次原生接受后以本次自己的新解重新生成候选。所有提案仍须原完整float64 CDF>=.975和原native_check返回>=.99。CF2不接受解、不替代评价器、不降低原约束，也不宣称全局或二交换局部最优。原九个MITM槽次顺序不变。',
 '', '二、原始文献、适用假设与实际诊断',
 'Fisher, R.A. & Cornish, E.A. (1960), The Percentile Points of Distributions Having Known Cumulants, Technometrics 2(2):209–225, DOI 10.1080/00401706.1960.10489895。原文：https://www.stat.cmu.edu/technometrics/59-69/VOL-02-02/v0202209.pdf。已读I–V，核对II式1/2及III第214页I(c)、II(d,c²)；标准化后的系数导出上式。原文为累积量阶数受控的渐近分位展开；本题有限、可能格点且偏度可约.96，未证明统一误差界或未知真分布覆盖。独立边际累积量相加是精确代数，CF2截断是近似。',
 '旧B全部1781条已登记轨迹的右尾分支诊断：17/38/39名义CF2 CDF拟合MAE分别.0000369512/.0002495919/.0001543930，鲁棒分别.0000774598/.0003137294/.0002615604，比普通Gaussian和一阶CF拟合更好。这是旧轨迹上的探索数据，不能当作正式算法胜出或新样本验证。正式算子只计算固定正分位，不进行全局CDF反演。',
 '负诊断完整保留：未限制全局反演在38/39有多递增分支而失败，不能用作评价器；后续右尾限制是明确另登记的探索选择。90个旧B首次MITM根到B最好解的两组一步覆盖率为0；R08F38的30个实际根成本均203.7925982，到B最好解距离三组，两组一步同样覆盖不到。前8个CF2候选可通过原CDF筛选，但当时未调用原生评价，不冒称可行或最终改善。',
 '同一已冻结旧轨迹诊断中，B最好向量的名义CF2预测：17为.990456789、38为.990143795、39为.989985602；对应旧原生观测平均返回值.990438/.989991933/.989881971。38代理可放行接近门槛的候选，39的B最好向量则会被代理略微挡住，说明仍可能漏掉原生随机观测曾接受的解。保留原MITM搜索正是为了不将代理设为全搜索的必要可行条件；这些数值不是新增原生抽样或未知真概率。',
 'R08F38均成本退化+.07994249%，且共同B均成本目标0/30命中，B为15/30；自己的最终解更早得到不能解释为同等质量提速。R08F39均成本改善约-.407469%，仍不能抵消38违反逐例门槛。此前R01/R03、R05速度门槛、R06/R07及未正式化R02负结果均保留。',
 '保留机制的原始文献与推导见冻结mechanism_evidence/component_evidence和链接的前版完整交付：Nemirovski–Shapiro(2006)有限MGF安全近似假设并不提供本题半径统计覆盖；Cooley–Tukey(1965)说明DFT分解等式，不证明整套搜索成本更好。R07联合有限和积消息等式保留为历史依据，其不得下降启发式本轮被替换。',
 '', '三、冻结、预检及实验口径',f'算法冻结281文件，FREEZE.json SHA256={FREEZE}；source_frozen.zip SHA256=f498160d32d93fc38b66ef88ecedd7cb5a8c376a9634560ce880a4189cdd135d；solver SHA256=07a486edb747cf380120155ae43a9ee6ff4c8e99e746378c8bab13f723a2db0d。事前远端核验提交690ee9c951fe2d0447c680b83449970435ff2f84，共14文件。冻结旧说明中的“尚未冻结”为成稿时状态，登记状态说明.txt已公开更正，冻结内容未回写。',
 '实际预检输出保存在results_complete.zip/control；只有输出passed=true才视作通过。预检包括全支撑矩、累积量可加性、Gaussian/零方差/非单调边界、枚举与朴素排序、超时不做工作、原B函数AST和四个评价依赖SHA核验。30个独立合成完整运行和CF2合成实例逐调用对照原native/RNG推进，包含代理通过而原生拒绝的反例。合成表现不计入正式成本。',
 '每次原独立初始化，种子832273—832302，M=1000000，P0=.99，预筛=.975。精确/MC切换、MC样本末项排除、快速拒绝和私有随机流推进不变。不得拿原生返回值称为未知真分布置信证书。当前仍为有限支撑边际CDF扰动+有限束宽MITM，半径未经统计校准，不宣称严格覆盖DRO或全局最优。',
 'R09事前登记并发上限30，原未来内存守卫动态降低，高内存例上限24，至少5GiB余量、峰值1.25和外部任务未来增长，不用自有瞬时RSS返还派发额度。R08F当时15并发未修改。复用B的负载、并发和时段与候选不同，正式差异属于整套候选，不能全归因于CF2单一部件。',
 '', '四、各版本各例官方统计', '不足30有效时官方avg/std/CV空白；失败不填虚假成本；std使用ddof=1。各失败分类另见原始状态和Excel。']
 lines+=table(d['summaries'],[('例','index'),('版本','arm'),('登记','registered'),('有效','valid'),('失败','failed'),('best','best'),('avg','avg'),('std','std'),('CV','CV'),('自身最终最好首次时间均值','mean_final_best_first_seconds'),('30次best命中数','best_hits'),('命中条件时间均值','conditional_best_hit_seconds'),('实际耗时均值','mean_actual_runtime'),('失败原因','failure_reasons')])
 if all(r['valid']==30 for r in d['summaries']):
  bm=statistics.mean(r['avg'] for r in b);cm=statistics.mean(r['avg'] for r in c)
  lines+=['',f'{n}/40例等权原始均成本：{bm:.12g} -> {cm:.12g}，相对变化{cm/bm-1:.8%}；逐例归一化差值均值{statistics.mean(r["relative_mean_difference"] for r in d["comparisons"]):.8%}。',f'逐例std均值：{statistics.mean(r["std"] for r in b):.12g} -> {statistics.mean(r["std"] for r in c):.12g}；逐例CV均值：{statistics.mean(r["CV"] for r in b):.12g} -> {statistics.mean(r["CV"] for r in c):.12g}。']
 lines+=['', '五、配对区间、多重比较与选择限制','差值为候选减B。19999次配对bootstrap百分位95%区间为描述性、非同时区间；配对符号翻转非零<=20精确，否则99999次加观察值；Holm家族7或40例，dz=差均值/差样本std。符号翻转需可交换/对称假设，bootstrap按配对种子独立；共享负载限制解释。有效率配对检验见Excel。']
 lines+=table(d['comparisons'],[('例','index'),('可评估','assessable'),('均值差','mean_difference'),('相对差','relative_mean_difference'),('配对95%区间','paired_bootstrap_95'),('dz','paired_dz'),('原p','p'),('Holm p','holm_p')])
 lines+=['退化例：'+str(gate['negative_cases'])+'。不显著不解释为等效、无用或未知分布无差异。','多轮设计复用同一套40例和固定种子，候选选择受旧结果影响；独立初始化与全新运行不能消除探索选择偏差，p/CI未经此选择校正。先导结论只覆盖7/40；全量也只覆盖该固定套件。', '', '六、相同质量目标与时间审计','最终最好首次达到时间为各自最终解的首次时间，成本不同不能直接当同质量速度。下表共同目标是事前B30次均成本，不向worker提供解；未命中仅在限制时间统计中记600，不作为失败成本。']
 for x in gate['reference_quality_times']:lines.append(json.dumps(x,ensure_ascii=False))
 lines+=['预登记其他目标的命中数/条件时间/限制时间详见Excel。',f'独立原始审计：{deep["valid_runs_checked"]}个有效比较记录，{deep["native_observations_checked"]}条原生调用，{deep["raw_input_SHA_files_verified"]}个原输入SHA；含保存和fsync实际耗时最大{deep["max_actual_elapsed"]:.12g}秒。','每次Popen前起算600秒，加载、初始化、数学模型、提案、搜索、CDF/原生评价及保存/fsync全计入；工作计划截止585秒，共留15秒。自然完成可以早于600。最后原生调用时间与所有搜索工作结束时间分别审计，不借最后原生调用掩盖后续评分。',json.dumps(reserve['by_arm'],ensure_ascii=False)]
 bounds={}
 for arm in ('B','R09'):
  rows=[r for r in deep['rows'] if r['arm']==arm];bounds[arm]={'count':len(rows),'max_before_final_save_upper':max((r['clock_chain_seconds'][1] for r in rows),default=None),'before_final_save_upper_past585':sum(r['clock_chain_seconds'][1]>585 for r in rows)}
 lines+=['最终solver保存前时间是全部搜索/评分结束的保守上界；上界<=585证明全部工作及时结束，上界>585不能仅凭最后native时间断言。此额外诊断不回改冻结门槛或重跑有效波。',json.dumps(bounds,ensure_ascii=False),'全部尝试含无效/中断/普通算法失败，不只审计成功记录：',json.dumps({k:attempts[k] for k in ('wave_count','registered_slots_all_attempts','actual_terminal_files','classification_counts','max_external_seconds_by_classification','all_attempt_time_config_checks_passed','no_valid_or_ordinary_wave_rerun','actual_phase_wall_times')},ensure_ascii=False),'阶段实际墙钟由事件中的首派发到终末复核，含补充派发和阶段内等待；不冒充包含首派发前预检等待或最后Excel制作。资源中断的未派发槽不算已经运行。', '', '七、完整目标与交付范围','完整目标仍要求全40例候选全新1200次全部原生有效；原始及归一化整体均成本下降，改善例多于退化，小/中/大组均不劣，17/38/39不劣，std/CV和共同目标时间通过；最后逐项核验全部时间/源码/输入/种子/尝试及远端文件。不能将本报告生成或上传视为目标达成。']
 if which=='full':lines+=['全量门槛原始结果：',json.dumps(d['full_gate'],ensure_ascii=False,indent=2)]
 lines+=['source_frozen.zip为冻结全部源码、参数和固定合成功能输入；results_complete.zip包含本候选所有尝试、全部40例复用B原始结果、控制状态/指针/日志/预检和EXPORT_MANIFEST成员SHA。complete表示该终末范围证据完整，未通过先导时没有候选1200次。','原输入冻结ZIP复用R04已核验交付：https://github.com/quanliangwen/1/tree/485e45e0ef85dae8563544d4d80697a92e980e73/CCMCKP/B_CDF_DRO_MITM_R04_20261102，inputs_frozen.zip SHA256 e5ebd0a26ff4a3d6d8e66cd2c3e0a342d8268dcf831315bb9fe657d9b4fb88b7。','statistics.xlsx含官方/条件统计、逐次记录、失败原因、目标时间、配对统计及门槛；所有表及官方行分页渲染目检、公式错误扫描、保存XML逐值核验。offline_reporting_reproduction.zip只做离线审计统计，不调用优化器。','文件按GitHub CCMCKP任务目录交付；FILE_MANIFEST/SHA256SUMS列实际字节摘要，必须另取远端提交核验后报告提交标识。']
 (DEST/'终末报告_按完整目标验收.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 for name in ['results_complete.zip','statistics_snapshot.json','INDEPENDENT_REVIEW.json','DEEP_TIME_AND_NATIVE_RECORD_AUDIT.json','TIME_RESERVE_REVIEW.json','ALL_ATTEMPTS_TIME_AND_FAILURE_AUDIT.json']:shutil.copyfile(e/name,DEST/name)
 shutil.copyfile(book,DEST/'statistics.xlsx');shutil.copyfile(ROOT/'report_snapshots'/('VISUAL_QA_'+a.workbook_name+'.json'),DEST/'SPREADSHEET_QA.json')
 with zipfile.ZipFile(DEST/'offline_reporting_reproduction.zip','w',zipfile.ZIP_DEFLATED) as z:
  for name in ['watch_terminal.py','export_terminal.py','deep_timing_review.py','time_reserve_review.py','audit_all_attempts.py','diagnose_completed_case.py','build_statistics.mjs','verify_delivery.py',Path(__file__).name]:z.write(ROOT/'reporting'/name,'reporting/'+name)
  for p in (ROOT/'report_snapshots').glob(a.workbook_name+'*.png'):z.write(p,'spreadsheet_QA/'+p.name)
  z.write(ROOT/'report_snapshots'/(a.workbook_name+'_checks.ndjson'),'spreadsheet_QA/formula_errors.ndjson')
 (DEST/'当前状态.txt').write_text(f'R09 {which} 终末：{state}；综合门槛{gate["performance_gate"]}，候选有效{sum(r["valid"] for r in c)}/{30*n}。完整目标是否达成须另经全40例、所有门槛与远端SHA最终验收。详见终末报告。\n',encoding='utf-8')
 m={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(DEST.iterdir()) if p.is_file() and p.name not in ('FILE_MANIFEST.json','SHA256SUMS.txt')}
 (DEST/'FILE_MANIFEST.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8');(DEST/'SHA256SUMS.txt').write_text(''.join(v['sha256']+'  '+k+'\n' for k,v in m.items())+sha(DEST/'FILE_MANIFEST.json')+'  FILE_MANIFEST.json\n',encoding='utf-8')
 print(json.dumps({'prepared':True,'scope':which,'valid':sum(r['valid'] for r in c),'performance_gate':gate['performance_gate'],'goal_complete':False,'files':len(m)}))
if __name__=='__main__':main()
