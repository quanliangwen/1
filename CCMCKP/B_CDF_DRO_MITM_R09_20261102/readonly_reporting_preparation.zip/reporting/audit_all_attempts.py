"""Audit every formal attempt, including interrupted/failed runs. Read-only.

Uses preserved clocks/files only. Never evaluates native probabilities or runs
an optimizer. Missing/failed records stay explicit instead of receiving costs.
"""
import argparse,gzip,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from common import read,sha,atomic,check_freeze,process_table,envelope

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);a=ap.parse_args();out=Path(a.out);assert not out.exists()
 freeze=check_freeze();state=read(ROOT/'STATE.json');receipt=read(ROOT/'LAUNCH_RECEIPT.json');table=process_table();p=table.get(receipt['pid'])
 assert not(p and p['start_ticks']==receipt['start_ticks']),'Controller still live'
 assert not any(str(ROOT/'worker.py') in r['cmd'] for r in table.values()),'Workers still live'
 assert state['status'] in ('pilot_failed_requires_diagnosis','pilot_integrity_audit_failed_no_expansion','performance_gates_passed_delivery_pending','full_failed_requires_new_mechanism')
 protocol=read(ROOT/'PROTOCOL.json');allowed=set(protocol['pilot_cases']);waves=[];allrows=[];issues=[];ordinary_repeats=[]
 event_index={}
 for line in (ROOT/'EVENTS.jsonl').read_text(encoding='utf8').splitlines():
  event=json.loads(line)
  if event.get('event') in ('wave_start','wave_terminal'):
   key=(event['phase'],event['index'],event['attempt'],event['event']);assert key not in event_index,('Duplicate wave event',key);event_index[key]=event
 for path in sorted((ROOT/'waves').glob('*/WAVE.json')):
  folder=path.parent;meta=read(path);assert meta['arm']=='R09' and meta['workers']==30
  assert meta['phase'] in ('R09_pilot','R09_full');assert meta['index'] in (allowed if meta['phase']=='R09_pilot' else set(range(1,41)))
  assert meta['freeze_sha']==freeze and meta['execution_freeze_sha']==freeze;assert 0<meta['parallel_limit']<=meta['parallel_ceiling']<=30
  case=next(c for c in protocol['cases'] if c['index']==meta['index'])
  assert meta['parallel_ceiling']==min(protocol['parallel'],24 if envelope(case)>=3*2**30 else 30)
  ticket=meta['resources_at_dispatch'];assert ticket['admitted_concurrency']==meta['parallel_limit']
  assert ticket['own_rss_used_as_admission_credit'] is False and ticket['foreign_growth_reserve']>=2*2**30
  assert ticket['required_bytes']>=meta['parallel_limit']*ticket['worker_future_bound']+5*2**30+ticket['foreign_growth_reserve']
  assert ticket['available_bytes']>=ticket['required_bytes'] and ticket['free_disk_bytes']>=3*2**30
  assert meta['status'] in ('valid_complete','ordinary_failure_complete','resource_interrupted','infrastructure_incomplete')
  pointer=read(ROOT/'WAVE_POINTERS'/('%s_c%02d.json'%(meta['phase'],meta['index'])))
  if meta['status'] in ('valid_complete','ordinary_failure_complete') and pointer['attempt']!=meta['attempt']:ordinary_repeats.append(folder.name)
  timing=read(folder/'TIMING_JOURNAL.json') if (folder/'TIMING_JOURNAL.json').exists() else {}
  audit=read(folder/'AUDIT.json') if (folder/'AUDIT.json').exists() else []
  byrep={r['rep']:r for r in audit if isinstance(r,dict) and 'rep' in r};terminal_count=0
  for rep in range(1,31):
   stem='r%02d'%rep;terminal=folder/(stem+'.terminal.json');raw=folder/(stem+'.json.gz');side=folder/(stem+'.json.gz.worker.json');tr=read(terminal) if terminal.exists() else None
   terminal_count+=bool(tr);elapsed=timing.get(str(rep));errors=[];data=None
   if raw.exists():
    try:data=json.loads(gzip.decompress(raw.read_bytes()))
    except Exception as exc:errors.append('raw_decode:'+repr(exc))
   if data is not None:
    cfg=data.get('config',{});expected={'time_budget':600,'work_reserve':15,'native_gate':.99,'screen_gate':.975,'native_draws':1000000}
    if any(cfg.get(k)!=v for k,v in expected.items()):errors.append('config_mismatch')
    if data.get('seed')!=832272+rep:errors.append('seed_mismatch')
    last_native=max((o['elapsed'] for o in data.get('native_observations',[])),default=None)
    if elapsed is not None and data.get('runtime_before_save',0)>elapsed+1e-8:errors.append('inner_after_outer_clock')
   else:last_native=None
   before_save=data.get('runtime_before_save') if data is not None else None
   valid=byrep.get(rep,{}).get('valid',False)
   if elapsed is not None and not 0<=elapsed<=600:errors.append('external_outside_0_600')
   if tr is not None:
    if tr.get('record_sha') is not None and (not raw.exists() or sha(raw)!=tr['record_sha']):errors.append('terminal_record_SHA_mismatch')
    if tr.get('worker_sha') is not None and (not side.exists() or sha(side)!=tr['worker_sha']):errors.append('terminal_worker_SHA_mismatch')
    if elapsed is not None and not 0<=tr['elapsed_before_terminal_save']<=elapsed+1e-8:errors.append('terminal_clock_after_outer')
   if meta['status']=='valid_complete' and (not valid or not raw.exists() or not side.exists() or tr is None or elapsed is None):errors.append('valid_wave_missing_required_evidence')
   if tr and not tr['reason'].startswith('resource') and (tr.get('returncode')==124 or tr['reason']=='hard_600s_timeout'):classification='ordinary_hard_watchdog_timeout'
   elif meta['status']=='resource_interrupted':classification='resource_invalid_entire_wave'
   elif meta['status']=='infrastructure_incomplete':classification='infrastructure_incomplete'
   elif valid:classification='valid'
   else:classification=byrep.get(rep,{}).get('reason') or (tr or {}).get('reason') or 'unlaunched_or_missing_terminal'
   row={'wave':folder.name,'phase':meta['phase'],'case':meta['index'],'attempt':meta['attempt'],'rep':rep,'registered_seed':832272+rep,'classification':classification,'valid':valid,'terminal_present':tr is not None,'raw_present':raw.exists(),'worker_sidecar_present':side.exists(),'elapsed_upper':elapsed,'last_native_end':last_native,'last_native_past585':last_native>585 if last_native is not None else None,'last_saved_solver_before_save_seconds':before_save,'before_save_upper_past585':before_save>585 if before_save is not None else None,'issues':errors}
   allrows.append(row)
   if errors:issues.append(row)
  start=event_index.get((meta['phase'],meta['index'],meta['attempt'],'wave_start'));end=event_index.get((meta['phase'],meta['index'],meta['attempt'],'wave_terminal'))
  wall=end['monotonic']-start['monotonic'] if start and end else None
  if wall is not None:assert wall>=0
  waves.append({'wave':folder.name,'phase':meta['phase'],'case':meta['index'],'attempt':meta['attempt'],'status':meta['status'],'parallel_limit':meta['parallel_limit'],'registered_slots':30,'terminal_files':terminal_count,'current_pointer_attempt':pointer['attempt'],'wave_start_utc':start['utc'] if start else None,'wave_terminal_utc':end['utc'] if end else None,'wave_wall_seconds_including_refill_wait_and_wave_audit':wall,'start_monotonic':start['monotonic'] if start else None,'terminal_monotonic':end['monotonic'] if end else None})
 assert not ordinary_repeats,('Valid/ordinary completed waves repeated',ordinary_repeats)
 classifications={};max_elapsed={}
 for row in allrows:
  k=row['classification'];classifications[k]=classifications.get(k,0)+1
  if row['elapsed_upper'] is not None:max_elapsed[k]=max(max_elapsed.get(k,0),row['elapsed_upper'])
 phase_wall={}
 for phase in sorted({w['phase'] for w in waves}):
  subset=[w for w in waves if w['phase']==phase];starts=[w['start_monotonic'] for w in subset if w['start_monotonic'] is not None];ends=[w['terminal_monotonic'] for w in subset if w['terminal_monotonic'] is not None];known=[w['wave_wall_seconds_including_refill_wait_and_wave_audit'] for w in subset if w['wave_wall_seconds_including_refill_wait_and_wave_audit'] is not None]
  span=max(ends)-min(starts) if starts and ends and len(known)==len(subset) else None
  phase_wall[phase]={'waves':len(subset),'waves_with_start_and_end':len(known),'sum_wave_wall_seconds':sum(known),'first_dispatch_to_last_terminal_seconds':span,'between_wave_dispatch_gap_seconds':max(0.,span-sum(known)) if span is not None else None,'scope':'Actual recorded monotonic events; includes refill/resource waits after first dispatch. Excludes preflight and waiting before first dispatch, and excludes final reporting. Not mean per-run time or time to a solution.'}
 result={'freeze_sha':freeze,'scope':'All candidate formal attempts, including resource/infrastructure/ordinary failures. No new samples/optimization. Registered slots may be unlaunched after interruption; not invented completed executions. Official accepted pilot/full statistics remain separate.','candidate_phase':state['status'],'wave_count':len(waves),'registered_slots_all_attempts':len(allrows),'actual_terminal_files':sum(x['terminal_present'] for x in allrows),'classification_counts':classifications,'max_external_seconds_by_classification':max_elapsed,'actual_phase_wall_times':phase_wall,'no_valid_or_ordinary_wave_rerun':not ordinary_repeats,'all_attempt_clock_and_config_issues':issues,'all_attempt_time_config_checks_passed':not issues,'waves':waves,'rows':allrows}
 atomic(out,result);print(json.dumps({k:v for k,v in result.items() if k not in ('waves','rows','all_attempt_clock_and_config_issues')}))
if __name__=='__main__':main()
