"""Read-only data-domain precheck of all original frozen inputs, no solver."""
import hashlib,io,json,time,zipfile
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
path=ROOT.parent/'CCMCKP_DRO_R04_20261101/github_staging_20261102/CCMCKP/B_CDF_DRO_MITM_R04_20261102/inputs_frozen.zip'
expected='e5ebd0a26ff4a3d6d8e66cd2c3e0a342d8268dcf831315bb9fe657d9b4fb88b7'
assert hashlib.sha256(path.read_bytes()).hexdigest()==expected
out=ROOT/'reporting/INPUT_SUPPORT_DOMAIN_AUDIT.json';assert not out.exists()
registered=json.loads((ROOT/'INPUTS.json').read_text(encoding='utf-8'));by_relative={str(Path(p).as_posix()).split('/benchmark/',1)[1]:h for p,h in registered.items()}
rows={};checked=0;began=time.monotonic()
with zipfile.ZipFile(path) as z:
 for name in z.namelist():
  rel=name.split('benchmark/',1)[-1]
  if rel not in by_relative:continue
  raw=z.read(name);assert hashlib.sha256(raw).hexdigest()==by_relative[rel],rel;checked+=1
  if not rel.endswith('_sample.txt'):continue
  a=np.asarray(np.loadtxt(io.BytesIO(raw))).reshape(-1);instance=rel.split('/')[0]
  assert len(a)>=2 and np.all(np.isfinite(a)) and a.min()>=0,rel
  r=rows.setdefault(instance,{'items':0,'sample_lengths':set(),'minimum':float('inf'),'maximum':-float('inf')})
  r['items']+=1;r['sample_lengths'].add(len(a));r['minimum']=min(r['minimum'],float(a.min()));r['maximum']=max(r['maximum'],float(a.max()))
assert checked==len(registered),(checked,len(registered))
for r in rows.values():r['sample_lengths']=sorted(r['sample_lengths'])
d={'passed':True,'all_registered_input_SHA_checked':checked,'instances':rows,'input_zip_sha256':expected,'elapsed':time.monotonic()-began,'scope':'Original frozen raw sample finite nonnegative domain and >=2 MC index support only; no native evaluation, no optimization, no solution read, not a formal candidate run.'}
out.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(d,ensure_ascii=False))
