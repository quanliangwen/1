"""Independent raw timing/provenance audit; never evaluates a probability or starts a solver."""
import argparse,gzip,json,math,pickle,hashlib,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from common import read,sha,atomic,check_freeze

def review(records):
 import numpy as np
 frozen=check_freeze();inputs=read(ROOT/'INPUTS.json');data_cache={};rows=[]
 for name,h in inputs.items():assert sha(name)==h,('input changed',name)
 for rec in records:
  if not rec['valid']:continue
  folder=Path(rec['wave']);rep=rec['rep'];base='r%02d'%rep;d=json.loads(gzip.decompress((folder/(base+'.json.gz')).read_bytes()));w=read(folder/(base+'.json.gz.worker.json'));t=read(folder/(base+'.terminal.json'));upper=read(folder/'TIMING_JOURNAL.json')[str(rep)]
  clocks=[d['selected']['found_seconds'],d['runtime_before_save'],w['elapsed_before_worker_sidecar'],t['elapsed_before_terminal_save'],upper]
  assert 0<=clocks[0] and all(a<=b+1e-8 for a,b in zip(clocks,clocks[1:])) and upper<=600,(rec['index'],rec['arm'],rep,clocks)
  assert d['native_probability_calls']==len(d['native_observations']);assert 0<=d['native_seconds']<=d['runtime_before_save']+1e-8;assert 0<=d['model_seconds'] and d['native_seconds']+d['model_seconds']<=d['runtime_before_save']+1e-6
  elapsed=[o['elapsed'] for o in d['native_observations']];assert all(0<=x<=d['runtime_before_save']+1e-8 for x in elapsed) and all(a<=b for a,b in zip(elapsed,elapsed[1:]))
  assert d['status']=='completed' and d['external_solution_inputs'] is False and d['prior_count']==0 and d['extra_completion'] is None
  instance=d['instance']
  if instance not in data_cache:
   data=next(Path(p).parent for p in inputs if Path(p).parent.name==instance);cost=np.asarray(np.loadtxt(data/'cost.txt')).reshape(-1)
   with (data/'node_to_factor.pkl').open('rb') as f:groups=pickle.load(f)
   if isinstance(groups,dict):groups=[groups[k] for k in sorted(groups,key=lambda x:int(x))]
   membership={int(j):g for g,row in enumerate(groups) for j in row};data_cache[instance]=(cost,groups,membership)
  cost,groups,membership=data_cache[instance]
  for o in d['native_observations']:
   ids=o['selection'];assert len(ids)==len(groups) and len(set(ids))==len(ids) and sorted(membership[j] for j in ids)==list(range(len(groups)));assert abs(float(cost[ids].sum())-o['cost'])<=1e-8;assert math.isfinite(o['probability']) and 0<=o['probability']<=1+1e-12
  cfg=d['config'];assert cfg['time_budget']==600 and cfg['work_reserve']==15 and cfg['native_gate']==.99 and cfg['screen_gate']==.975 and cfg['native_draws']==1000000;assert d['seed']==w['seed']==832272+rep
  aux=[h for h in d['match_history'] if h.get('engine')=='entropic_cost_MILP'];assert len(aux)==(0 if rec['arm']=='B' else 1)
  joint=[h for h in d['match_history'] if h.get('engine')=='CF2_risk_budget_pair'];assert len(joint)<=(0 if rec['arm']=='B' else 1)
  assert not any(h.get('engine')=='joint_CDF_pair_messages' for h in d['match_history'])
  if joint and joint[0]['active']:
   j=joint[0];assert j['soft_phase_seconds']==20. and j['max_distinct_proposals']==8 and len(j['attempts'])<=8 and j['native_calls']<=8
   assert j['proxy_targets']==[.99,.975] and j['proxy_order']==2 and j['delta']==.00025 and j['same_original_acceptance_gates']==[.975,.99]
   assert sum(x['native_calls'] for x in j['attempts'])==j['native_calls']
   assert sum(o['source'].startswith('CF2_risk_pair_delta') for o in d['native_observations'])==j['native_calls']
   seen=set()
   for a in j['attempts']:
    ids=a['selection'];root=a['root_selection'];key=tuple(ids);assert key not in seen;seen.add(key)
    changed=[g for g,(x,y) in enumerate(zip(root,ids)) if x!=y];assert changed==a['groups_changed'] and 1<=len(changed)<=2
    assert len(ids)==len(groups) and sorted(membership[x] for x in ids)==list(range(len(groups)))
    assert len(root)==len(groups) and sorted(membership[x] for x in root)==list(range(len(groups)))
    assert abs(float(cost[ids].sum())-a['cost'])<=1e-8 and a['cost']<float(cost[root].sum())-1e-8
    assert math.isfinite(a['nominal_quantile_proxy']) and a['nominal_quantile_proxy']<d['capacity']
    assert math.isfinite(a['robust_quantile_proxy']) and a['robust_quantile_proxy']<=d['capacity']-d['capacity']/cfg['bins']
    assert 0<=a['original_full_CDF_score']<=1 and a['native_calls'] in (0,1)
    if a['native_calls']:assert a['original_full_CDF_score']>=.975 and a['native_return'] is not None
    if a['accepted_original_native']:assert a['native_return']>=.99
  for h in d['match_history']:
   if 'left' not in h:continue
   ids=h['left']+h['right'];assert sorted(ids)==list(range(len(groups))) and len(ids)==len(set(ids));assert h['delta'] in (.00025,0.,.0005)
  rows.append({'index':rec['index'],'arm':rec['arm'],'rep':rep,'clock_chain_seconds':clocks,'native_observations_checked':len(elapsed),'native_seconds':d['native_seconds'],'model_seconds':d['model_seconds'],'record_sha':sha(folder/(base+'.json.gz'))})
 return {'passed':True,'freeze_sha':frozen,'valid_runs_checked':len(rows),'native_observations_checked':sum(x['native_observations_checked'] for x in rows),'raw_input_SHA_files_verified':len(inputs),'max_actual_elapsed':max((x['clock_chain_seconds'][-1] for x in rows),default=None),'rows':rows,'scope':'All five timestamp stages, per-call selection/cost/returned-value range and count, registered groups/seed/budget/gates, original input SHA and source freeze. Native oracle never re-evaluated. RNG evidence is unchanged native AST plus functional replay, not a new formal-run RNG simulation.'}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--snapshot');ap.add_argument('--pilot-case',type=int);a=ap.parse_args()
 if a.snapshot:records=read(a.snapshot)['terminal_records'];out=Path(a.snapshot).with_name('DEEP_TIME_AND_NATIVE_RECORD_AUDIT.json')
 else:
  assert a.pilot_case;idx=a.pilot_case;ref=Path(read(ROOT/'REFERENCE_REGISTRY.json')['waves'][str(idx)]['directory']);candidate=ROOT/'waves'/('R09_pilot_c%02d_a01'%idx);records=[]
  for arm,folder in [('B',ref),('R09',candidate)]:
   assert read(folder/'WAVE.json')['status']=='valid_complete';records.extend(dict(x,index=idx,arm=arm,wave=str(folder)) for x in read(folder/'AUDIT.json'))
  out=ROOT/'reporting'/('CASE%02d_DEEP_TIME_AUDIT.json'%idx)
 assert not out.exists();result=review(records);atomic(out,result);print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
if __name__=='__main__':main()
