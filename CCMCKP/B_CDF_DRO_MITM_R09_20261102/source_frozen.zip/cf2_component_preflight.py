"""Own original initialization + actual native CF2 moves, including rejection.

Synthetic only. Never run before prior campaign actual processes have stopped.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
import sys,time,signal,math
from common import ROOT,read,atomic,check_freeze
from preflight_helpers import previous_live,original_native_check,state_digest
def main():
 signal.alarm(600);freeze=check_freeze();assert not previous_live();assert not (ROOT/'CF2_COMPONENT_PREFLIGHT.json').exists();sys.path.insert(0,str(ROOT/'sources/R09'))
 import numpy as np
 from instance import load_instance
 from solver import Solver
 target=ROOT/'CF2_COMPONENT_TESTS';target.mkdir(exist_ok=False);started=time.monotonic();inst=load_instance(ROOT/'functional_fixtures/cf2_trade_L500');seed=832273
 s=Solver(inst,10.,seed,600,target/'component.json.gz',started,'B_CDF_DRO_MITM');replay=Solver(inst,10.,seed,600,target/'replay_unused.json.gz',started,'B_CDF_DRO_MITM');replay.save=lambda *_:None
 native=s.native_check;original=original_native_check(np);transcript=[]
 def checked(ids,source,force=False):
  outer=state_digest(np.random.get_state());p=native(ids,source,force);q=original(replay,ids,source,force)
  assert p==q and state_digest(np.random.get_state())==outer and state_digest(s.native_rng.get_state())==state_digest(replay.native_rng.get_state()) and s.native_calls==replay.native_calls
  transcript.append({'selection':list(ids),'source':source,'force':force,'native_return':p,'native_rng_sha':state_digest(s.native_rng.get_state())});return p
 s.native_check=checked
 for _,_,selection in s.propose(s.mu+3*s.sd,float(s.cost.max()*inst.m),theta=0.,pool=8,seconds=3):
  s.native_check(selection,'CF2_synthetic_own_original_initialization',True)
  if s.best is not None:break
 assert s.best and s.best['cost']==60.;calls=s.native_calls;models=s.models;outer=state_digest(np.random.get_state());s.cf2_risk_pair_exchange(.00025)
 assert state_digest(np.random.get_state())==outer and s.models==models
 assert s.best['cost']==16. and s.best['probability']>=.99
 stage=s.match_history[-1];assert stage['engine']=='CF2_risk_budget_pair' and stage['active'] and stage['proxy_targets']==[.99,.975]
 assert 1<=len(stage['attempts'])<=8 and s.native_calls-calls==stage['native_calls']==sum(a['native_calls'] for a in stage['attempts'])
 assert len({tuple(a['selection']) for a in stage['attempts']})==len(stage['attempts'])
 for a in stage['attempts']:
  assert 1<=len(a['groups_changed'])<=2 and a['cost']<inst.selection_cost(a['root_selection'])-1e-8
  if a['native_calls']:assert a['original_full_CDF_score']>=.975
  if a['accepted_original_native']:assert a['native_return']>=.99
 # Deliberate proxy false positive must NOT bypass the original .99 oracle.
 rejected=[a for a in stage['attempts'] if abs(a['cost']-12.)<1e-8];assert len(rejected)==1 and rejected[0]['native_calls']==1 and rejected[0]['native_return']<.99 and not rejected[0]['accepted_original_native']
 p=249/499;chance=lambda n:sum(math.comb(n,k)*p**k*(1-p)**(n-k) for k in range(min(9,n)+1));assert chance(12)<.99<chance(11)
 calls=s.native_calls;models=s.models;history=len(s.match_history);s.deadline=time.monotonic()-1.;s.cf2_risk_pair_exchange(.00025);assert s.native_calls==calls and s.models==models and len(s.match_history)==history
 atomic(ROOT/'CF2_COMPONENT_PREFLIGHT.json',{'passed':True,'freeze_sha':freeze,'synthetic_only':True,'formal_runs':0,'own_original_initializer_cost':60.,'original_native_accepted_final_cost':16.,'native_return':s.best['probability'],'original_native_rejected_cost12':rejected[0]['native_return'],'exact_known_synthetic_chance12':chance(12),'exact_known_synthetic_chance11':chance(11),'proxy_is_not_acceptance_evaluator':True,'RNG_original_transcript_replay_passed':True,'deadline_no_work':True,'no_additional_gurobi_models':True,'elapsed':time.monotonic()-started,'transcript':transcript,'CF2_stage':stage});print('CF2 own-init improvement, actual original-native rejection and RNG replay passed',flush=True)
if __name__=='__main__':main()
