"""30-process full-solver synthetic functional wave, never official results."""
import argparse,gzip,json,os,random,signal,subprocess,sys,time
from pathlib import Path
from common import ROOT,PROJECT,read,sha,atomic,check_freeze,mem_available,process_table,envelope

from preflight_helpers import previous_live,fixture_for,state_digest,original_native_check

def child(a):
    signal.signal(signal.SIGALRM,lambda *_:os._exit(124));signal.setitimer(signal.ITIMER_REAL,max(.001,a.started+600-time.monotonic()))
    freeze=check_freeze();name,T,expected,active=fixture_for(a.rep);fixture=ROOT/'functional_fixtures'/name
    target=Path(a.directory);out=target/('r%02d.json.gz'%a.rep);rngout=target/('r%02d.RNG.json'%a.rep)
    atomic(target/('r%02d.ready.json'%a.rep),{'pid':os.getpid()})
    while not (target/'START.json').exists():time.sleep(.01)
    allowed={p.resolve() for p in fixture.iterdir() if p.is_file()}|{p.resolve() for p in (ROOT/'sources/R09').glob('*.py')}|{(ROOT/'PROTOCOL.json').resolve(),(ROOT/'sources/B/solver.py').resolve()}
    own={out,out.with_name(out.name+'.tmp'),rngout,rngout.with_name(rngout.name+'.tmp'),target}
    def guard(event,args):
        if event!='open' or not isinstance(args[0],(str,bytes,os.PathLike)):return
        p=Path(os.fsdecode(args[0])).resolve()
        if PROJECT==p or PROJECT in p.parents:
            if p not in allowed and p not in own:raise PermissionError('Unregistered functional input: '+str(p))
    sys.addaudithook(guard);sys.path.insert(0,str(ROOT/'sources/R09'))
    import numpy as np
    from instance import load_instance
    from solver import Solver
    import scipy,gurobipy
    environment={'python':sys.version.split()[0],'numpy':np.__version__,'scipy':scipy.__version__,'gurobi':list(gurobipy.gurobi.version()),'executable':str(Path(sys.executable).resolve())}
    assert environment==read(ROOT/'PROTOCOL.json')['environment']
    seed=832272+a.rep;random.seed(seed);np.random.seed(seed);inst=load_instance(fixture)
    s=Solver(inst,T,seed,600,out,a.started,'B_CDF_DRO_MITM')
    replay=Solver(inst,T,seed,600,out,a.started,'B_CDF_DRO_MITM');replay.save=lambda *_:None
    original=s.native_check;baseline=original_native_check(np);transcript=[]
    def checked(selection,source,force=False):
        outer=state_digest(np.random.get_state());value=original(selection,source,force)
        assert state_digest(np.random.get_state())==outer
        expected_value=baseline(replay,selection,source,force)
        assert value==expected_value and state_digest(s.native_rng.get_state())==state_digest(replay.native_rng.get_state())
        assert state_digest(np.random.get_state())==outer and s.native_calls==replay.native_calls
        transcript.append({'selection':list(selection),'force':force,'probability':value,'native_state_sha':state_digest(s.native_rng.get_state())})
        return value
    s.native_check=checked;s.run()
    atomic(rngout,{'scope':'Functional original-wrapper transcript replay only, never a benchmark initializer or second acceptance test','passed':True,'fixture':name,'calls':transcript,'source_freeze':freeze})

def main(a):
    frozen=check_freeze()
    if (ROOT/'FUNCTIONAL_PREFLIGHT.json').exists():
        done=read(ROOT/'FUNCTIONAL_PREFLIGHT.json')
        if done['passed'] and done['freeze_sha']==frozen:
            print('reuse_valid_preflight_no_rerun',flush=True);return
        raise RuntimeError('Existing failed/different preflight; diagnose, no automatic repetition')
    if previous_live():raise RuntimeError('Old 30-wave still active; functional wave must wait')
    table=process_table();foreign=sum(v['rss'] for v in table.values() if str(ROOT) not in v['cmd'])
    ready=envelope({'m':12,'max_group':5,'n':60})*30+5*2**30+max(2*2**30,foreign//2)
    while mem_available()<ready:
        print(json.dumps({'status':'waiting_fixed30_resources','available':mem_available(),'required':ready}),flush=True);time.sleep(30)
    directory=ROOT/'FUNCTIONAL_WAVE';directory.mkdir(exist_ok=False)
    with (directory/'launch.lock').open('x') as f:f.write('30 diagnostic full-solver processes, no repeats\n')
    jobs=[];env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
    active={};reason='running'
    try:
        for rep in range(1,31):
            log=(directory/('r%02d.log'%rep)).open('x');started=time.monotonic()
            cmd=[sys.executable,'-B',str(Path(__file__).resolve()),'--child','--rep',str(rep),'--started',str(started),'--directory',str(directory)]
            p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True);job=dict(rep=rep,p=p,log=log,started=started);jobs.append(job);active[p.pid]=job
        until=time.monotonic()+20
        while sum((directory/('r%02d.ready.json'%r)).exists() for r in range(1,31))<30:
            if time.monotonic()>until or any(j['p'].poll() is not None for j in jobs):raise RuntimeError('Functional 30-process barrier failed')
            time.sleep(.01)
        assert len(active)==30 and all(j['p'].poll() is None for j in jobs)
        atomic(directory/'START.json',{'ready':30,'released':time.monotonic()})
        while active:
            now=time.monotonic()
            if mem_available()<5*2**30:raise RuntimeError('Functional resource interruption')
            for pid,j in list(active.items()):
                if j['p'].poll() is not None:
                    j['log'].flush();os.fsync(j['log'].fileno());j['log'].close();j['elapsed']=time.monotonic()-j['started'];del active[pid]
                elif now-j['started']>=600:raise RuntimeError('Functional hard600 timeout')
            time.sleep(.05)
        reason='all_terminal'
    except Exception as exc:
        reason='resource_interrupted' if 'resource' in str(exc).lower() else 'infrastructure_or_functional_error'
        raise
    finally:
        for pid,j in list(active.items()):
            if j['p'].poll() is None:
                try:os.killpg(pid,signal.SIGKILL)
                except ProcessLookupError:pass
            j['p'].wait();j['log'].flush();os.fsync(j['log'].fileno());j['log'].close()
        atomic(directory/'STATUS.json',{'reason':reason,'terminal':sum(j['p'].poll() is not None for j in jobs),'complete_process_count':len(jobs)})
    rows=[]
    for j in jobs:
        p=directory/('r%02d.json.gz'%j['rep'])
        if j['p'].returncode!=0 or not p.exists():raise RuntimeError('Functional worker failed: '+str(j['rep']))
        d=json.loads(gzip.decompress(p.read_bytes()));selected=d['selected'];name,T,expected,active=fixture_for(j['rep'])
        proposal=[v for v in d['match_history'] if v.get('engine')=='entropic_cost_MILP']
        pair_stage=[v for v in d['match_history'] if v.get('engine')=='CF2_risk_budget_pair'];assert len(pair_stage)==1 and pair_stage[0]['active']==active
        assert selected and selected['cost']==expected and selected['probability']>=.99
        assert len(proposal)==1 and proposal[0]['active']==active and len(d['match_history'])==11
        if active:
            assert proposal[0]['stop_reason']=='accepted_original_native_improvement'
            assert proposal[0]['attempts'][-1]['cost']==35. and proposal[0]['attempts'][-1]['finite_support_bound_valid']
        else:assert proposal[0]['native_calls']==0 and proposal[0]['stop_reason']=='all_half_cardinalities_fit_original_width'
        cfg=d['config'];assert d['seed']==832272+j['rep'] and cfg['native_draws']==1000000 and cfg['screen_gate']==.975 and cfg['native_gate']==.99
        assert cfg['time_budget']==600 and cfg['work_reserve']==15 and j['elapsed']<=600
        rng=read(directory/('r%02d.RNG.json'%j['rep']));assert rng['passed'] and rng['source_freeze']==frozen and rng['calls']
        rows.append({'rep':j['rep'],'seed':d['seed'],'fixture':name,'T':T,'final_cost':selected['cost'],'probability':selected['probability'],'auxiliary_active':active,'actual_elapsed':j['elapsed'],'record_sha':sha(p),'RNG_record_sha':sha(directory/('r%02d.RNG.json'%j['rep']))})
    p=subprocess.run([sys.executable,'-B',str(ROOT/'component_preflight.py')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env=env)
    atomic(ROOT/'COMPONENT_PROCESS.json',{'returncode':p.returncode,'stdout':p.stdout})
    if p.returncode:raise RuntimeError('Target component checks failed')
    p=subprocess.run([sys.executable,'-B',str(ROOT/'cf2_component_preflight.py')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env=env)
    atomic(ROOT/'CF2_COMPONENT_PROCESS.json',{'returncode':p.returncode,'stdout':p.stdout})
    if p.returncode:raise RuntimeError('Target CF2 component checks failed')
    check_freeze()
    result={'passed':True,'freeze_sha':frozen,'functional_full_processes':30,'official_candidate_runs':0,'parallel':30,'rows':rows,'scope':'Actual target Linux/Gurobi complete runs and original native transcript RNG replay.10 active large cases and20 structural skips exact/MC. Component rejection injection is isolated from these real-oracle full runs and formal workers. Synthetic functionality only, no performance claim.'}
    atomic(ROOT/'FUNCTIONAL_PREFLIGHT.json',result)
    print(json.dumps({'functional_passed':True,'count':30,'max_elapsed':max(v['actual_elapsed'] for v in rows),'freeze_sha':frozen}),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--child',action='store_true');ap.add_argument('--rep',type=int);ap.add_argument('--started',type=float);ap.add_argument('--directory');args=ap.parse_args()
    if args.child:child(args)
    else:main(args)
