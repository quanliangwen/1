"""Postfreeze CF2 finite-law/math and unchanged-source preflight. No oracle."""
import sys,time,math,itertools,ast
import numpy as np
from common import ROOT,read,sha,atomic,check_freeze

def main():
 freeze=check_freeze();assert not (ROOT/'MATH_PREFLIGHT.json').exists();sys.path.insert(0,str(ROOT/'sources/R09'))
 from cf2_pair_math import finite_moments,tail_proxy,ranked_pairs,Z99,Z975
 from solver import worst_cdf_hist,truncated_convolution
 ns={'worst_cdf_hist':worst_cdf_hist,'truncated_convolution':truncated_convolution}
 checks=[]
 for B in [1,2,3,8,16,64]:
  for a in [np.array([0.,.2,.8,1.2]),np.zeros(4),np.ones(4)*1.5]:
   for delta in [0.,.00025,.0005,.4,1.]:
    grid=np.ceil(a/(1./B)-1e-12)/B;pos,count=np.unique(grid,return_counts=True);cdf=np.maximum(0.,np.cumsum(count/len(a))-delta);cdf[-1]=1.;w=np.diff(np.r_[0.,cdf]);mu=float(w@pos);dev=pos-mu;v=float(w@(dev*dev));expected=np.array([mu,v,float(w@(dev**3)),float(w@(dev**4))-3*v*v]);actual=finite_moments(a,1.,B,delta,True);error=float(np.max(abs(expected-actual)));assert error<=1e-11
    indices=np.rint(pos*B).astype(int);hist=np.bincount(indices[indices<B],weights=w[indices<B],minlength=B);original=ns['worst_cdf_hist'](a,1.,B,delta);assert np.max(abs(hist-original))<1e-12;checks.append({'B':B,'delta':delta,'moment_max_error':error,'same_original_histogram':True})
 for mu,v in [(0.,0.),(3.,0.),(3.,2.)]:
  risk,ok=tail_proxy(np.array([mu,v,0.,0.]),Z99);assert bool(ok) and abs(float(risk)-(mu+Z99*math.sqrt(v)))<1e-12
 _,ok=tail_proxy(np.array([0.,1.,100.,0.]),Z99);assert not bool(ok)
 # Additivity against a directly enumerated independent sum law.
 arrays=[np.array([0.,1.]),np.array([.1,.3,.9]),np.array([0.,.4])];summed=sum((finite_moments(a,2.,16,0.,False) for a in arrays),np.zeros(4));values=np.asarray([sum(t) for t in itertools.product(*arrays)]);direct=finite_moments(values,2.,16,0.,False);assert np.max(abs(summed-direct))<1e-12
 groups=[[0,1],[2,3],[4]];cost=np.array([10.,1.,10.,1.,10.]);samples=[np.zeros(4),np.array([0.,0.,1.,1.]),np.zeros(4),np.array([0.,0.,1.,1.]),np.zeros(4)];nom=np.asarray([finite_moments(x,10.,4096,0,False) for x in samples]);rob=np.asarray([finite_moments(x,10.,4096,.00025,True) for x in samples]);rank,info=ranked_pairs(groups,cost,(0,2,4),nom,rob,10.,4096);brute=[]
 for s in itertools.product(*groups):
  n,okn=tail_proxy(nom[list(s)].sum(axis=0),Z99);r,okr=tail_proxy(rob[list(s)].sum(axis=0),Z975)
  if cost[list(s)].sum()<30.-1e-8 and okn and okr and n<10 and r<=10-10/4096:brute.append((float(cost[list(s)].sum()),s))
 assert [(x['cost'],x['selection']) for x in rank]==sorted(brute);rank,info=ranked_pairs(groups,cost,(0,2,4),nom,rob,10.,4096,deadline=time.monotonic()-1);assert not rank and not info['enumeration_complete']
 def parsed(p):
  t=ast.parse(p.read_text());c=next(x for x in t.body if isinstance(x,ast.ClassDef) and x.name=='Solver');return t,{x.name:ast.dump(x,include_attributes=False) for x in c.body if isinstance(x,ast.FunctionDef)}
 tb,bm=parsed(ROOT/'sources/B/solver.py');tc,cm=parsed(ROOT/'sources/R09/solver.py');unchanged=[k for k in bm if bm[k]==cm[k]];assert set(bm)-set(unchanged)=={'build_half','run'};assert set(cm)-set(bm)=={'entropic_cost_proposal','cf2_risk_pair_exchange'}
 fb={x.name:ast.dump(x,include_attributes=False) for x in tb.body if isinstance(x,ast.FunctionDef)};fc={x.name:ast.dump(x,include_attributes=False) for x in tc.body if isinstance(x,ast.FunctionDef)};assert fc==fb
 for name,digest in read(ROOT/'sources/B/SOURCE_MANIFEST.json')['original_source_sha256'].items():assert sha(ROOT/'sources/B'/name)==digest
 for name in ('instance.py','native_evaluator.py','native_support.py','lss_vendor.py'):assert sha(ROOT/'sources/B'/name)==sha(ROOT/'sources/R09'/name)
 atomic(ROOT/'MATH_PREFLIGHT.json',{'passed':True,'freeze_sha':freeze,'histogram_moment_checks':checks,'moment_histogram_checks_count':len(checks),'independent_cumulant_additivity_enumerated':True,'ranked_all_choices_matches_naive':True,'Gaussian_limit_and_zero_variance_and_unsupported_branch_checked':True,'deadline_no_proposals':True,'original_module_functions_unchanged':list(fb),'original_native_methods_unchanged':unchanged,'native4dependencies_byte_identical':True,'new_native_calls':0,'formal_runs':0,'scope':'TargetLinux CF2math and byte/AST invariants; no unknownpopulation coverage or globalCDF claim.'});print('CF2 finite-law and original native/source invariants passed',flush=True)
if __name__=='__main__':main()
