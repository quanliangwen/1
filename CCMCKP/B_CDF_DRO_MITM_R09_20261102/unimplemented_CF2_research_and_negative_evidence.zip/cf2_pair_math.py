"""Finite-marginal cumulants and local right-tail CF2 PROPOSAL guidance.

No probability certificate, no native evaluator, no RNG, no file/history reads.
Every formal proposal must still pass original fullCDF and original native.
"""
import math,time
import numpy as np
Z99=2.3263478740408408
Z975=1.959963984540054

def finite_moments(samples,T,bins,delta,rounded):
 a=np.asarray(samples,np.float64)
 if not len(a) or not np.all(np.isfinite(a)) or a.min()<0:raise ValueError('Finite nonnegative support required')
 if not 0<=delta<=1:raise ValueError('Invalid radius')
 if rounded:a=np.ceil(a/(T/bins)-1e-12)*(T/bins)
 pos,count=np.unique(a,return_counts=True);mass=count.astype(np.float64)/len(a);left=float(delta)
 for k in range(len(mass)):
  moved=min(left,float(mass[k]));mass[k]-=moved;left-=moved
  if left<=1e-15:break
 mass[-1]+=float(delta)-left
 assert np.all(mass>=0) and abs(float(mass.sum())-1)<1e-12
 mu=float(mass@pos);center=pos-mu;var=float(mass@(center*center));c3=float(mass@(center**3));c4=float(mass@(center**4))-3*var*var
 return np.array([mu,var,c3,c4],np.float64)

def tail_proxy(moments,z):
 """Forward CF2 quantile at fixed positive normal z; not a global CDF."""
 x=np.asarray(moments,np.float64);mu=x[...,0];v=x[...,1];c3=x[...,2];c4=x[...,3]
 safe=np.where(v>0,v,1.);gamma=c3/safe**1.5;excess=c4/safe**2
 A=excess/24-gamma*gamma/18;B=gamma/6;C=1-excess/8+5*gamma*gamma/36;D=-gamma/6
 q=((A*z+B)*z+C)*z+D
 # Nonmonotone global negative branches never become a CDF implementation.
 # Require the forward quantile branch to increase throughout [0,z].
 derivative=np.minimum(C,3*A*z*z+2*B*z+C)
 vertex=np.divide(-B,3*A,out=np.zeros_like(np.asarray(A)),where=A!=0)
 vertex_value=3*A*vertex*vertex+2*B*vertex+C
 derivative=np.where((A>0)&(vertex>0)&(vertex<z),np.minimum(derivative,vertex_value),derivative)
 valid=np.all(np.isfinite(x),axis=-1)&(v>=0)&np.isfinite(q)&(q>0)&(derivative>0)
 deterministic=(v==0)&(c3==0)&(c4==0);valid=np.where(deterministic,np.isfinite(mu),valid)
 risk=mu+np.sqrt(np.maximum(0.,v))*q
 return risk,valid

def ranked_pairs(groups,cost,root,nominal,robust,T,bins,seen=(),deadline=None):
 """All one/two-group cost-lower CF2-eligible moves; lexicographic cost order.

No incumbent-CDF-nondecrease condition. Same .99 nominal and .975 finite-DRO
targets guide proposals, and original acceptance remains external/unchanged.
Partial enumeration at a deadline is disclosed, never a local-optimality claim.
"""
 root=tuple(map(int,root));cost=np.asarray(cost,float);nominal=np.asarray(nominal,float);robust=np.asarray(robust,float);m=len(groups);assert len(root)==m and m>0
 chosen_n=nominal[list(root)];chosen_r=robust[list(root)];cap=float(cost[list(root)].sum());seen=set(seen);entries={};visited_pairs=0;complete=True
 threshold_nom=np.nextafter(float(T),-np.inf);threshold_rob=float(T)-float(T)/bins
 def expired():return deadline is not None and time.monotonic()>=deadline
 def store(g,h,ids_g,ids_h,n,r,c):
  p0,ok0=tail_proxy(n,Z99);pr,okr=tail_proxy(r,Z975);mask=(c<cap-1e-8)&ok0&okr&(p0<=threshold_nom)&(pr<=threshold_rob)
  for at in np.argwhere(mask):
   ix=tuple(at);s=list(root);s[g]=int(ids_g[ix[0]])
   if h is not None:s[h]=int(ids_h[ix[1]])
   selection=tuple(s)
   if selection==root or selection in seen:continue
   actual=float(cost[list(selection)].sum())
   if actual>=cap-1e-8:continue
   entries[selection]={'selection':selection,'cost':actual,'nominal_quantile_proxy':float(p0[ix]),'robust_quantile_proxy':float(pr[ix]),'changed_groups':sum(a!=b for a,b in zip(root,selection))}
 for g in range(m):
  if expired():complete=False;break
  other=[k for k in range(m) if k!=g];rest_n=chosen_n[other].sum(axis=0) if other else np.zeros(4);rest_r=chosen_r[other].sum(axis=0) if other else np.zeros(4)
  ids=np.asarray(groups[g],int);cc=math.fsum(float(cost[root[k]]) for k in other)+cost[ids];store(g,None,ids,None,rest_n+nominal[ids],rest_r+robust[ids],cc)
 if complete:
  for g in range(m):
   for h in range(g+1,m):
    if expired():complete=False;break
    visited_pairs+=1;other=[k for k in range(m) if k not in (g,h)];rest_n=chosen_n[other].sum(axis=0) if other else np.zeros(4);rest_r=chosen_r[other].sum(axis=0) if other else np.zeros(4)
    a=np.asarray([j for j in groups[g] if j!=root[g]],int);b=np.asarray([j for j in groups[h] if j!=root[h]],int)
    if not len(a) or not len(b):continue
    nn=rest_n+nominal[a,None,:]+nominal[b][None,:,:];rr=rest_r+robust[a,None,:]+robust[b][None,:,:]
    cc=math.fsum(float(cost[root[k]]) for k in other)+cost[a,None]+cost[b][None,:]
    store(g,h,a,b,nn,rr,cc)
   if not complete:break
 ranked=sorted(entries.values(),key=lambda x:(x['cost'],x['selection']))
 return ranked,{'enumeration_complete':complete,'group_pairs_processed':visited_pairs,'eligible_distinct_moves':len(ranked),'same_original_targets':[.99,.975],'no_incumbent_CDF_nondecrease_filter':True}
