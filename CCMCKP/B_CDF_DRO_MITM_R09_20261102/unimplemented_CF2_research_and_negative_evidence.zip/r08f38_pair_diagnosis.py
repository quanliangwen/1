"""All30 failed-R08F38 first-stage roots, no new optimization/oracle."""
from pathlib import Path
import json,hashlib,zipfile,gzip,io,pickle,ast,time
import numpy as np
from cf2_pair_math import finite_moments,ranked_pairs
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 f=json.loads((ROOT/'R08F38_PAIR_DIAGNOSTIC_FREEZE.json').read_text(encoding='utf8'))
 for p,h in f['files'].items():assert sha(p)==h,p
 protocol=json.loads(Path(f['protocol']).read_text(encoding='utf8'));case=next(x for x in protocol['cases'] if x['index']==38);T=case['tmax'];ns={'np':np};tree=ast.parse(Path(f['baseline_solver']).read_text(encoding='utf8'));nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('worst_cdf_hist','truncated_convolution')];exec(compile(ast.Module(body=nodes,type_ignores=[]),'original_B_pureCDF','exec'),ns)
 with zipfile.ZipFile(f['inputs_zip']) as zi,zipfile.ZipFile(f['records_zip']) as zb,zipfile.ZipFile(f['candidate_records_zip']) as zc:
  prefix='benchmark/'+case['instance']+'/';groups=pickle.loads(zi.read(prefix+'node_to_factor.pkl'))
  if isinstance(groups,dict):groups=[groups[k] for k in sorted(groups,key=lambda x:int(x))]
  cost=np.asarray(np.loadtxt(io.BytesIO(zi.read(prefix+'cost.txt')))).reshape(-1);raw=[np.asarray(np.loadtxt(io.BytesIO(zi.read(prefix+str(j)+'_sample.txt')))).reshape(-1)[:-1] for j in range(case['n'])];nom=np.asarray([finite_moments(a,T,4096,0,False) for a in raw]);rob=np.asarray([finite_moments(a,T,4096,.00025,True) for a in raw]);base=[json.loads(gzip.decompress(zb.read('reused_B/reference_c38_a01/r%02d.json.gz'%rep))) for rep in range(1,31)];best=min(d['selected']['cost'] for d in base);targets={tuple(d['selected']['selection']) for d in base if abs(d['selected']['cost']-best)<1e-8};runs=[]
  for rep in range(1,31):
   d=json.loads(gzip.decompress(zc.read('r%02d.json.gz'%rep)));first=next(h for h in d['match_history'] if 'left' in h);end=585-first['remaining'];last=[e for e in d['events'] if e.get('event')=='native_incumbent' and e['elapsed']<=end+1e-8][-1];root=tuple([o for o in d['native_observations'] if o['probability']>=.99 and abs(o['cost']-last['cost'])<1e-8 and o['elapsed']<=end+1e-8][-1]['selection']);seen={tuple(o['selection']) for o in d['native_observations'] if o['elapsed']<=end+1e-8};begin=time.monotonic();rank,info=ranked_pairs(groups,cost,root,nom,rob,T,4096,seen);elapsed=time.monotonic()-begin;assert info['enumeration_complete'];ranks=[i+1 for i,p in enumerate(rank) if p['selection'] in targets];top=[]
   for p in rank[:8]:
    pdf=np.r_[1.,np.zeros(4095)]
    for j in p['selection']:pdf=ns['truncated_convolution'](pdf,ns['worst_cdf_hist'](raw[j],T,4096,.00025),4096)
    top.append({'cost':p['cost'],'selection_sha':hashlib.sha256(json.dumps(p['selection']).encode()).hexdigest(),'Bbest':p['selection'] in targets,'changes':p['changed_groups'],'nominal_quantile_proxy':p['nominal_quantile_proxy'],'robust_quantile_proxy':p['robust_quantile_proxy'],'original_fullCDF':float(np.clip(pdf.sum(),0,1))})
   runs.append({'rep':rep,'root_cost':last['cost'],'root_selection_sha':hashlib.sha256(json.dumps(root).encode()).hexdigest(),'Bbest_min_hamming':min(sum(a!=b for a,b in zip(root,s)) for s in targets),'Bbest_ranks':ranks,'eligible_moves':len(rank),'enumeration_seconds':elapsed,'top8':top})
 summary={'roots':30,'Bbest_within2':sum(r['Bbest_min_hamming']<=2 for r in runs),'Bbest_top8':sum(any(k<=8 for k in r['Bbest_ranks']) for r in runs),'mean_enumeration_seconds':float(np.mean([r['enumeration_seconds'] for r in runs])),'max_enumeration_seconds':max(r['enumeration_seconds'] for r in runs),'top8_originalCDF_pass':float(np.mean([p['original_fullCDF']>=.975 for r in runs for p in r['top8']])) if any(r['top8'] for r in runs) else None}
 out=ROOT/'R08F38_PAIR_DIAGNOSIS.json';assert not out.exists();out.write_text(json.dumps({'freeze_sha':sha(ROOT/'R08F38_PAIR_DIAGNOSTIC_FREEZE.json'),'summary':summary,'runs':runs,'scope':'All30 currentfailed38roots, same mathkernel as frozen90oldBroot diagnostic. B issoleofficial control; R08F roots are diagnostic context only. OriginalCDFcheck only, zero native/Gurobi/newformalruns. Doesnotprove nativefeasibility or mean improvement. No fullvectors/learnedweights output toworker.'},ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(summary),flush=True)
if __name__=='__main__':main()
