"""Second-order CF diagnostic, old B visits only. Never a native evaluator.

No proposals/solver/formal runs. Predeclared gates may fail; retain failure.
"""
from pathlib import Path
import json,hashlib,zipfile,gzip,io,math,time
import numpy as np
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def inverse_cf2_upper(z,gamma,excess):
 # Fisher/Cornish1960 p214 Table adjustment I(c), II(d,c^2), a=b=0.
 co=[excess/24-gamma*gamma/18,gamma/6,1-excess/8+5*gamma*gamma/36,-gamma/6-z]
 roots=np.roots(np.trim_zeros(co,'f'));eligible=[]
 for r in roots:
  if abs(float(r.imag))>1e-7*(1+abs(float(r.real))):continue
  u=float(r.real);deriv=3*co[0]*u*u+2*co[1]*u+co[2]
  if u>=0 and deriv>0 and abs(np.polyval(co,u))<=1e-7*(1+abs(z)):
   bound=max(u,2.3263478740408408);test=[co[2],3*co[0]*bound*bound+2*co[1]*bound+co[2]]
   if co[0]>0 and 0< -co[1]/(3*co[0])<bound:
    vertex=-co[1]/(3*co[0]);test.append(3*co[0]*vertex*vertex+2*co[1]*vertex+co[2])
   if min(test)>0:eligible.append(u)
 if len(eligible)!=1:return None,len(eligible)
 return .5*math.erfc(-eligible[0]/math.sqrt(2)),1
def moments(a,delta=0):
 a=np.asarray(a,float);assert a.min()>=0;assert delta<=1/len(a)
 # Completes the original truncated marginal by the same observed-support
 # mass shift min->max as robust_logmgf. All overflow mass remains included.
 raw=[float(np.mean(a**k)+delta*(a.max()**k-a.min()**k)) for k in range(1,5)]
 mu,e2,e3,e4=raw;var=max(0.,e2-mu*mu);c3=e3-3*mu*e2+2*mu**3;c4=e4-4*mu*e3+6*mu*mu*e2-3*mu**4-3*var*var
 return mu,var,c3,c4
def main():
 f=json.loads((ROOT/'CF2_UPPER_DIAGNOSTIC_FREEZE.json').read_text(encoding='utf8'))
 for n,h in f['files'].items():assert sha(n)==h,n
 first=json.loads(Path(f['first_cf_output']).read_text(encoding='utf8'));protocol=json.loads(Path(f['protocol']).read_text(encoding='utf8'));result=[];begin=time.monotonic()
 with zipfile.ZipFile(f['inputs_zip']) as zi,zipfile.ZipFile(f['records_zip']) as zr:
  for idx in f['cases']:
   case=next(x for x in protocol['cases'] if x['index']==idx);base=next(x for x in first['results'] if x['summary']['index']==idx);byhash={x['selection_sha']:x for x in base['rows']};seen={}
   samples=[np.asarray(np.loadtxt(io.BytesIO(zi.read('benchmark/'+case['instance']+'/'+str(j)+'_sample.txt')))).reshape(-1)[:-1] for j in range(case['n'])]
   nominal=np.asarray([moments(x) for x in samples]);unit=case['tmax']/4096;robust=np.asarray([moments(np.ceil(x/unit-1e-12)*unit,.00025) for x in samples])
   for rep in range(1,31):
    d=json.loads(gzip.decompress(zr.read('reused_B/reference_c%02d_a01/r%02d.json.gz'%(idx,rep))))
    for o in d['native_observations']:
     ids=tuple(o['selection']);seen[hashlib.sha256(json.dumps(ids).encode()).hexdigest()]=ids
   assert set(seen)==set(byhash);rows=[]
   for h,ids in seen.items():
    b=byhash[h];row={'selection_sha':h,'cost':b['cost'],'recorded_native_positive_mean':b['recorded_native_positive_mean'],'original_same_delta_fullCDF':b['original_same_delta_fullCDF']}
    for label,table,truth in [('nominal',nominal,b['recorded_native_positive_mean']),('robust',robust,b['original_same_delta_fullCDF'])]:
     mu,var,c3,c4=table[list(ids)].sum(axis=0);assert var>0;gamma=c3/var**1.5;excess=c4/var**2;z=(case['tmax']-mu)/math.sqrt(var);assert truth is not None and truth>=.5,'Outside preregistered upper-tail diagnostic domain';pred,nroots=inverse_cf2_upper(z,gamma,excess)
     row.update({label+'_CF2_prediction':pred,label+'_positive_derivative_roots':nroots,label+'_skew':float(gamma),label+'_excess':float(excess),label+'_CF2_error':pred-truth if pred is not None and truth is not None else None})
    rows.append(row)
   stats={'index':idx,'unique_points':len(rows)}
   for label,key in [('nominal','nominal_CF_MAE'),('robust','robust_CF_to_original_score_MAE')]:
    err=np.asarray([abs(x[label+'_CF2_error']) for x in rows if x[label+'_CF2_error'] is not None]);undefined=sum(x[label+'_CF2_prediction'] is None for x in rows);stats[label+'_undefined_inverse']=undefined;stats[label+'_CF2_MAE']=float(err.mean()) if len(err) else None;stats[label+'_CF2_p90']=float(np.quantile(err,.9)) if len(err) else None;stats[label+'_first_CF_MAE']=base['summary'][key]
   stats['gate']=bool(all(stats[k+'_undefined_inverse']==0 and stats[k+'_CF2_MAE']<=min(.001,stats[k+'_first_CF_MAE']) and stats[k+'_CF2_p90']<=.0025 for k in ['nominal','robust']) and any(stats[k+'_CF2_MAE']<stats[k+'_first_CF_MAE']-1e-8 for k in ['nominal','robust']))
   result.append({'summary':stats,'rows':rows});print(json.dumps(stats),flush=True)
 out=ROOT/'CF2_UPPER_ASSUMPTION_DIAGNOSIS.json';assert not out.exists();out.write_text(json.dumps({'scope':'Unimplemented right-tail retrospective diagnostic on ALL oldBvisited unique vectors of17/38/39. Earlier unrestricted globalinverse failed and remains archived underfreeze cb1cbd0a0b1e884f0fe45fbbbe86b31c63b9850cb990e8441fd5fb9e20c0a0a7. No new oracle samples, proposals or optimization. Original same-delta fullCDF values reused from pinned earlier diagnostic. Undefined/nonmonotone inverse branches preserved, never dropped to claim a gatepass. No fullselection vectors/learnedweights output.','formula':'q(u)=u+gamma*(u^2-1)/6+excess*(u^3-3u)/24-gamma^2*(2u^3-5u)/36; Upper-tail diagnostic requires exactlyone NONNEGATIVE realroot with positive derivative on [0,max(root,z.99)]. This is not a globally validCDF inverse. Formal proposal would use forward q(z.99)/q(z.975), no fitted coefficients.','paper':'Fisher&Cornish1960 Technometrics2(2)209–225 DOI10.1080/00401706.1960.10489895; SectionsI–V read, p214 adjustmentI/II table visually reread. Asymptotic cumulant order assumptions not established for these finite/lattice/skewed marginals; no error/coverage guarantee.','freeze_sha':sha(ROOT/'CF2_UPPER_DIAGNOSTIC_FREEZE.json'),'elapsed':time.monotonic()-begin,'results':result,'all_diagnostic_gates_passed':all(x['summary']['gate'] for x in result),'selection_limitations':'Same fixed benchmark and seeds, oldBchosen proposal points, adaptive research choice; not unseen validation or algorithm improvement. Never replaces originalCDF/native acceptance.'},ensure_ascii=False,indent=2),encoding='utf8')
if __name__=='__main__':main()
