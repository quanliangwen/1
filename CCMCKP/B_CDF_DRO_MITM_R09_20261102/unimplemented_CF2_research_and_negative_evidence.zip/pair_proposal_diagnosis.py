"""Frozen CF2 math checks and ALL90 old-B first-stage roots. Zero new oracle.

No native evaluator, Gurobi or solver import. Only original pure CDF functions
are AST-extracted. Results cannot warm-start any formal worker.
"""
from pathlib import Path
import json,hashlib,zipfile,gzip,io,pickle,ast,math,time,itertools
import numpy as np
from cf2_pair_math import finite_moments,tail_proxy,ranked_pairs,Z99,Z975
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 f=json.loads((ROOT/'PAIR_DIAGNOSTIC_FREEZE.json').read_text(encoding='utf8'))
 for p,h in f['files'].items():assert sha(p)==h,p
 ns={'np':np};t=ast.parse(Path(f['baseline_solver']).read_text(encoding='utf8'));nodes=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name in ('worst_cdf_hist','truncated_convolution')];exec(compile(ast.Module(body=nodes,type_ignores=[]),'original_B_pureCDF_only','exec'),ns)
 checks=[]
 for B in [1,2,3,8,16,64]:
  for a in [np.array([0.,.2,.8,1.2]),np.zeros(4),np.ones(4)*1.5]:
   for delta in [0.,.00025,.0005,.4,1.]:
    grid=np.ceil(a/(1./B)-1e-12)/B;pos,count=np.unique(grid,return_counts=True);cdf=np.maximum(0.,np.cumsum(count/len(a))-delta);cdf[-1]=1.;w=np.diff(np.r_[0.,cdf]);mu=float(w@pos);dev=pos-mu;v=float(w@(dev*dev));expected=np.array([mu,v,float(w@(dev**3)),float(w@(dev**4))-3*v*v]);actual=finite_moments(a,1.,B,delta,True);error=float(np.max(abs(expected-actual)));assert error<=1e-11
    indices=np.rint(pos*B).astype(int);hist=np.bincount(indices[indices<B],weights=w[indices<B],minlength=B);original=ns['worst_cdf_hist'](a,1.,B,delta);assert np.max(abs(hist-original))<1e-12;checks.append({'B':B,'delta':delta,'moment_max_error':error,'same_original_histogram':True})
 for mu,v in [(0.,0.),(3.,0.),(3.,2.)]:
  risk,ok=tail_proxy(np.array([mu,v,0.,0.]),Z99);assert bool(ok) and abs(float(risk)-(mu+Z99*math.sqrt(v)))<1e-12
 _,ok=tail_proxy(np.array([0.,1.,100.,0.]),Z99);assert not bool(ok)
 # Additivity against a directly enumerated independent sum law.
 arrays=[np.array([0.,1.]),np.array([.1,.3,.9]),np.array([0.,.4])];summed=sum((finite_moments(a,2.,16,0.,False) for a in arrays),np.zeros(4));values=np.asarray([sum(t) for t in itertools.product(*arrays)]);direct=finite_moments(values,2.,16,0.,False);assert np.max(abs(summed-direct))<1e-12
 groups=[[0,1],[2,3],[4]];cost=np.array([10.,1.,10.,1.,10.]);samples=[np.zeros(4),np.array([0.,0.,1.,1.]),np.zeros(4),np.array([0.,0.,1.,1.]),np.zeros(4)];nom=np.asarray([finite_moments(x,10.,4096,0,False) for x in samples]);rob=np.asarray([finite_moments(x,10.,4096,.00025,True) for x in samples]);rank,info=ranked_pairs(groups,cost,(0,2,4),nom,rob,10.,4096);brute=[]
 for s in itertools.product(*groups):
  n,okn=tail_proxy(nom[list(s)].sum(axis=0),Z99);r,okr=tail_proxy(rob[list(s)].sum(axis=0),Z975)
  if cost[list(s)].sum()<30.-1e-8 and okn and okr and n<10 and r<=10-10/4096:brute.append((float(cost[list(s)].sum()),s))
 assert [(x['cost'],x['selection']) for x in rank]==sorted(brute);rank,info=ranked_pairs(groups,cost,(0,2,4),nom,rob,10.,4096,deadline=time.monotonic()-1);assert not rank and not info['enumeration_complete']
 protocol=json.loads(Path(f['protocol']).read_text(encoding='utf8'));results=[]
 with zipfile.ZipFile(f['inputs_zip']) as zi,zipfile.ZipFile(f['records_zip']) as zr:
  for idx in f['cases']:
   case=next(c for c in protocol['cases'] if c['index']==idx);T=case['tmax'];prefix='benchmark/'+case['instance']+'/';groups=pickle.loads(zi.read(prefix+'node_to_factor.pkl'))
   if isinstance(groups,dict):groups=[groups[k] for k in sorted(groups,key=lambda x:int(x))]
   cost=np.asarray(np.loadtxt(io.BytesIO(zi.read(prefix+'cost.txt')))).reshape(-1);raw=[np.asarray(np.loadtxt(io.BytesIO(zi.read(prefix+str(j)+'_sample.txt')))).reshape(-1)[:-1] for j in range(case['n'])];nom=np.asarray([finite_moments(a,T,4096,0,False) for a in raw]);rob=np.asarray([finite_moments(a,T,4096,.00025,True) for a in raw]);runs=[];allrecords=[]
   for rep in range(1,31):allrecords.append(json.loads(gzip.decompress(zr.read('reused_B/reference_c%02d_a01/r%02d.json.gz'%(idx,rep)))))
   best=min(d['selected']['cost'] for d in allrecords);best_vectors={tuple(d['selected']['selection']) for d in allrecords if abs(d['selected']['cost']-best)<1e-8}
   for rep,d in enumerate(allrecords,1):
    first=next(h for h in d['match_history'] if 'left' in h);end=585-first['remaining'];events=[e for e in d['events'] if e.get('event')=='native_incumbent' and e['elapsed']<=end+1e-8];event=events[-1];positive=[o for o in d['native_observations'] if o['probability']>=.99 and abs(o['cost']-event['cost'])<1e-8 and o['elapsed']<=end+1e-8];root=tuple(positive[-1]['selection']);seen={tuple(o['selection']) for o in d['native_observations'] if o['elapsed']<=end+1e-8};begin=time.monotonic();rank,info=ranked_pairs(groups,cost,root,nom,rob,T,4096,seen=seen);elapsed=time.monotonic()-begin;assert info['enumeration_complete'];target_ranks=[k+1 for k,x in enumerate(rank) if x['selection'] in best_vectors];top=rank[:8];scores=[]
    for p in top:
     pdf=np.r_[1.,np.zeros(4095)]
     for j in p['selection']:pdf=ns['truncated_convolution'](pdf,ns['worst_cdf_hist'](raw[j],T,4096,.00025),4096)
     scores.append(float(np.clip(pdf.sum(),0,1)))
    runs.append({'rep':rep,'root_cost':event['cost'],'root_selection_sha':hashlib.sha256(json.dumps(root).encode()).hexdigest(),'Bbest_cost':best,'root_is_Bbest':root in best_vectors,'Bbest_min_hamming':min(sum(a!=b for a,b in zip(root,s)) for s in best_vectors),'eligible_moves':len(rank),'Bbest_ranks_among_eligible':target_ranks,'enumeration_seconds':elapsed,'top8':[{'cost':p['cost'],'selection_sha':hashlib.sha256(json.dumps(p['selection']).encode()).hexdigest(),'changes':p['changed_groups'],'nominal_quantile_proxy':p['nominal_quantile_proxy'],'robust_quantile_proxy':p['robust_quantile_proxy'],'original_fullCDF':score} for p,score in zip(top,scores)]})
   summary={'case':idx,'roots':30,'already_Bbest':sum(x['root_is_Bbest'] for x in runs),'Bbest_within2changes':sum(x['Bbest_min_hamming']<=2 for x in runs),'Bbest_top8_eligible':sum(any(k<=8 for k in x['Bbest_ranks_among_eligible']) for x in runs),'mean_enumeration_seconds':float(np.mean([x['enumeration_seconds'] for x in runs])),'max_enumeration_seconds':max(x['enumeration_seconds'] for x in runs),'top8_originalCDF_pass_fraction':float(np.mean([t['original_fullCDF']>=.975 for x in runs for t in x['top8']])) if any(x['top8'] for x in runs) else None};results.append({'summary':summary,'runs':runs});print(json.dumps(summary),flush=True)
 out=ROOT/'PAIR_PROPOSAL_DIAGNOSIS.json';assert not out.exists();out.write_text(json.dumps({'freeze_sha':sha(ROOT/'PAIR_DIAGNOSTIC_FREEZE.json'),'numeric_checks_passed':True,'histogram_moment_checks':checks,'cumulant_additivity_direct_enumeration':True,'ranked_pairs_matches_naive_allchoices':True,'results':results,'scope':'All90 fixed oldBfirststage roots; ownprior nativeprefix seenkeys only. No nativecalls/Gurobi/formalruns. Fullvectors notoutput, no templates/weights toformalworker. Top8CDF values are exact originalscorer only, not nativefeasibility/algorithmperformance proof. Samebenchmarks/seedselectionbias disclosed.'},ensure_ascii=False,indent=2),encoding='utf8')
if __name__=='__main__':main()
