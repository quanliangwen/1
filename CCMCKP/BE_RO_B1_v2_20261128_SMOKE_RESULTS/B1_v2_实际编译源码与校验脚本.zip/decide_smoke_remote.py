from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import json,hashlib,statistics,tarfile
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b1_v2_20261128';F=H/'smoke'
assert Path.cwd()==B
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (F/'FINAL_AUDIT_PROCESS.json').exists(),'Independent audit still running'
C=read(F/'COMPLETED.json');A=read(F/'FINAL_INDEPENDENT_AUDIT.json');P=read(F/'PROTOCOL.json');gate=P['pre_registered_quality_gate']
assert C['terminal']==35 and C['pending']==0 and read(F/'FINAL_AUDIT_PROCESS.json')['rc']==0
for n,h in P['source_and_binary_pins'].items():assert sha(F/n)==h,n
zero=[];groups=[];cost_pass=True
for o in sorted((read(p) for p in (F/'outcomes').glob('*.json')),key=lambda x:(x['case_index'],x['rep'])):
 root=F/'runs'/o['identity']
 if (root/'S10_search.json').exists():
  raw=read(root/'S10_search.json')
  for i,q in enumerate(raw['BE_RO_model']['queries']):
   if q.get('solver_status')==9 and q.get('solutions_retained')==0:zero.append({'identity':o['identity'],'query_index':i})
for c in P['cases']:
 rr=[r for r in A['rows'] if r['case_index']==c['index']];vv=[r for r in rr if r['valid']];cost=[r['cost'] for r in vv]
 limit=gate['max_final_cost_per_run'][str(c['index'])]
 okay=len(vv)==5 and all(x<=limit for x in cost);cost_pass=cost_pass and okay
 groups.append({'case_index':c['index'],'instance':c['instance'],'capacity':c['tmax'],'valid':len(vv),'terminal':len(rr),
 'best':min(cost) if cost else None,'avg':statistics.mean(cost) if len(cost)==5 else None,
 'sample_std':statistics.stdev(cost) if len(cost)==5 else None,'worst':max(cost) if cost else None,
 'max_cost_limit':limit,'cost_gate_pass':okay,'max_whole_seconds':max(r['process_wall_seconds'] for r in rr)})
passed=A['independent_valid']==35 and not A['global_errors'] and not zero and cost_pass and max(r['process_wall_seconds'] for r in A['rows'])<=600
decision={'utc':datetime.now(timezone.utc).isoformat(),'pass':passed,'terminal':35,'independent_valid':A['independent_valid'],
 'global_errors':A['global_errors'],'TIME_LIMIT_zero_solution_queries':zero,'groups':groups,'quality_gate':gate,
 'audit_sha256':sha(F/'FINAL_INDEPENDENT_AUDIT.json'),'protocol_sha256':sha(F/'PROTOCOL.json'),
 'source_frozen':True,'failed_repeats_rerun':False,'thresholds_changed_after_results':False,'can_launch_full40':passed}
out=F/'SMOKE_EXPANSION_DECISION.json'
if out.exists():
 old=read(out);assert {k:v for k,v in old.items() if k!='utc'}=={k:v for k,v in decision.items() if k!='utc'};decision=old
else:out.write_text(json.dumps(decision,ensure_ascii=False,indent=2))
print(json.dumps(decision,ensure_ascii=False))
