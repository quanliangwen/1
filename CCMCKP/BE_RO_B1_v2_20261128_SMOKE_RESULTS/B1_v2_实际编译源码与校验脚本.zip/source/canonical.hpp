#pragma once
#include "model.hpp"
#include <gmpxx.h>
#include <cmath>
#include <set>
namespace s10 {
// Exact arithmetic on the stored binary model coefficients, not decimal population moments.
inline Json canonical_soc_witness(const Instance& d,const Selection& s) {
    d.validate(s);mpq_class squared=0;Vector coefficients;
    for(int j:s){double a=std::sqrt(d.variance[j]);if(!std::isfinite(a))throw std::runtime_error("Nonfinite SOC coefficient");coefficients.push_back(a);mpq_class z(a);squared+=z*z;}
    double t=std::sqrt(squared.get_d());int outward=0;
    while(mpq_class(t)*mpq_class(t)<squared){if(++outward>8)throw std::runtime_error("Cannot outward round SOC witness");t=std::nextafter(t,INFINITY);}
    mpq_class slack=mpq_class(t)*mpq_class(t)-squared;
    return {{"selected_sd_coefficients",coefficients},{"canonical_t",t},{"sum_squared_sd_binary_rational",squared.get_str()},
        {"squared_slack_binary_rational",slack.get_str()},{"outward_steps",outward},{"exact_canonical_SOC_feasible",slack>=0},
        {"scope","cap_free_risk_master_only; not a probability certificate"}};
}
inline Json validate_discrete_proposal(const Instance& d,const Vector& raw,double bound,
        const std::set<Selection>& excluded,const std::set<Selection>& dominance) {
    if(int(raw.size())!=d.n())throw std::invalid_argument("Wrong proposal length");
    Selection s;bool integral=true,onehot=true;
    for(double v:raw)integral &= std::isfinite(v)&&std::abs(v-std::round(v))<=1e-6&&v>=-1e-6&&v<=1+1e-6;
    for(const auto& g:d.groups){int chosen=0,jj=-1;for(int j:g)if(raw[j]>.5){++chosen;jj=j;}onehot &= chosen==1;if(jj>=0)s.push_back(jj);}
    int violations=0;mpq_class c=0;
    if(onehot)for(int j:s)c+=mpq_class(d.costs[j]);
    if(onehot)for(const auto& cut:dominance){int hit=0;for(int j:s)hit+=std::binary_search(cut.begin(),cut.end(),j);violations+=hit>d.m()-1;}
    bool cost_ok=onehot&&(!std::isfinite(bound)||c<=mpq_class(bound)+mpq_class(1e-6));
    bool excluded_hit=onehot&&excluded.count(s);
    return {{"valid",integral&&onehot&&cost_ok&&!excluded_hit&&!violations},{"integral",integral},{"one_per_group",onehot},
        {"cost_within_original_1e6_tolerance",cost_ok},{"exact_cost_binary_rational",c.get_str()},
        {"cost_bound",std::isfinite(bound)?Json(bound):Json(nullptr)},{"excluded_hit",excluded_hit},
        {"violating_dominance_rows",violations},{"selection",s}};
}
}
