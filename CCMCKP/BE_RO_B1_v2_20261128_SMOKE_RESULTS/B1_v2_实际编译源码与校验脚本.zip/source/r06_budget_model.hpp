#pragma once
#include "calibrated_budget.hpp"
namespace s10 {
class R06Budget: public CalibratedBudget {
public:
 R06Budget(const Instance&d,const std::string&cap):CalibratedBudget(d,cap){
  const int count=std::min(d.sample_count,std::max(3,(d.sample_count+19)/20));
  if(mpq_class(count)!=mpq_class(d.sample_count,20)){
        const double begin=now();deviations.clear();upper.clear();thresholds.clear();gammas.clear();min_sums.clear();min_choices.clear();coarse.clear();gamma_max=0;gamma_floor=mpq_class(1,20);initial.clear();initial_theta=0;
        std::set<mpq_class> ts{mpq_class(0)};Json items=Json::array();
        for(int j=0;j<d.n();++j){check_budget();std::vector<mpq_class> values;
            for(const auto& text:d.decimals[j])values.push_back(rational_decimal(text));
            mpq_class mass=std::min(d.sample_count,std::max(3,(d.sample_count+19)/20));mass.canonicalize();
            auto es=tail_mean(values,mass);mpq_class delta=es-means[j];delta.canonicalize();
            if(delta<0)throw std::logic_error("ES below mean");
            upper.push_back(es);deviations.push_back(delta);ts.insert(delta);
            items.push_back({{"item",j},{"mean",means[j].get_str()},{"ES95",es.get_str()},{"deviation",delta.get_str()},{"tail_mass",mass.get_str()}});
        }
        thresholds.assign(ts.begin(),ts.end());
        for(const auto& theta:thresholds){check_budget();Selection sel;mpq_class total=0;
            for(const auto& group:d.groups){int best=group.front();
                auto weight=[&](int j){mpq_class value=means[j];if(deviations[j]>theta)value+=deviations[j]-theta;return value;};
                for(int j:group)if(weight(j)<weight(best)||(weight(j)==weight(best)&&j<best))best=j;
                sel.push_back(best);total+=weight(best);
            }total.canonicalize();min_sums.push_back(total);min_choices.push_back(sel);
        }
        mpq_class nominal_min=0;for(const auto& group:d.groups){mpq_class v=means[group.front()];for(int j:group)if(means[j]<v)v=means[j];nominal_min+=v;}
        mean_infeasible=nominal_min>capacity-margin;
        if(!mean_infeasible){
            for(std::size_t k=0;k<thresholds.size();++k){
                const auto& theta=thresholds[k];
                if(theta==0){if(min_sums[k]<=capacity-margin)gamma_max=d.m();continue;}
                mpq_class bound=(capacity-margin-min_sums[k])/theta;
                if(bound>gamma_max)gamma_max=bound;
            }
            if(gamma_max>d.m())gamma_max=d.m();gamma_max.canonicalize();
        }
        if(gamma_max>0){
            auto k=minimum_resource(gamma_max);initial=min_choices[k];initial_theta=thresholds[k];
            if(gamma_max<gamma_floor)gamma_floor=gamma_max/2;
            gamma_floor.canonicalize();
        }
        auto sorted=deviations;std::sort(sorted.begin(),sorted.end());std::set<std::size_t> ci{0};
        for(int k=0;k<15;++k){auto value=sorted[std::size_t(k)*(sorted.size()-1)/14];ci.insert(std::lower_bound(thresholds.begin(),thresholds.end(),value)-thresholds.begin());}
        coarse.assign(ci.begin(),ci.end());Json resource=Json::array();for(std::size_t k=0;k<thresholds.size();++k)resource.push_back({{"theta",thresholds[k].get_str()},{"group_min_sum",min_sums[k].get_str()}});
        preparation_seconds+=now()-begin;
        metadata={{"model","R02_empirical_ES95_calibrated_budget_RO"},{"items",items},{"all_original_samples",true},{"samples_per_item",d.sample_count},
            {"ES_beta","19/20"},{"uncertainty_set","a=mean+d*z; 0<=z<=1; sum z<=Gamma"},{"deviation_rule","fractional empirical upper 5 percent mean minus full sample mean"},
            {"threshold_count",thresholds.size()},{"resource_table",resource},{"gamma_max_exact",gamma_max.get_str()},{"gamma_max_method","exact max of affine threshold feasibility ratios; not finite-step bisection"},
            {"positive_gamma_floor",gamma_floor.get_str()},{"mean_infeasible",mean_infeasible},{"nominal_zero_budget_fallback",false},
            {"robust_guard",margin.get_str()},{"coarse_threshold_indices",coarse},{"localization_rounds",9},{"localization_is_heuristic",true},{"CDF_solution_probability_monotonicity_claim",false},
            {"safe_cost_pruning","exact rational Lagrangian dual lower bound >= exact incumbent cost"},{"cost_cutoff","incumbent exact cost, outward upper, retains every strict exact-cost improvement"},
            {"coarse_MIP_slice_seconds",.25},{"fine_MIP_slice_seconds",1.},{"pool_search_mode",2},{"pool_solutions",25},{"pool_gap",.02},{"fine_threshold_limit_per_gamma",5},
            {"global_optimality_claim",false},{"probability_coverage_claim",false},{"Gamma_is_probability_level",false},{"historical_solution_inputs",false},{"external_MIPstarts",false},
            {"original_CDF_gate_preserved",true},{"final_acceptance","unchanged original LSS"},{"preparation_seconds",preparation_seconds}};
  }
  metadata["model"]="R06_count_tail_calibrated_budget_RO";metadata["tail_window_count"]=count;metadata["ES_beta"]=mpq_class(1-mpq_class(count,d.sample_count)).get_str();metadata["deviation_rule"]="mean of highest min(L,max(3,ceil(L/20))) atoms minus full mean";
 }
};
}
