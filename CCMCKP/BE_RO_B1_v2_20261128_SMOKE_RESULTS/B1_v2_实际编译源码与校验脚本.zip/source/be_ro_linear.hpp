#pragma once
#include "be_ro_witness.hpp"
#include <algorithm>
#include <cmath>
#include <memory>
#include <numeric>
#include <set>

namespace s10 {
// The continuous lambda identity is exact (as an infimum, including endpoints).
// A FINITE grid is a conservative candidate generator, not an exact optimizer
// of the union over all lambda. All accepted vectors also need the old KKT proof.
struct BELinearRow {
 mpq_class omega,lambda,rhs;
 std::string kind;
 std::vector<mpq_class> weights;
 Vector rounded;
 double rounded_rhs=0;
 Selection minimum_selection;
 mpq_class minimum_rounded_sum;
 bool feasible=false;

 Json proof(const Selection&s)const {
  mpq_class exact=0,actual=0;
  for(int j:s){exact+=weights.at(j);actual+=mpq_class(rounded.at(j));}
  exact.canonicalize();actual.canonicalize();
  return {{"kind",kind},{"omega",omega.get_str()},{"lambda",lambda.get_str()},
   {"exact_lhs",exact.get_str()},{"exact_rhs",rhs.get_str()},
   {"rounded_lhs",actual.get_str()},{"rounded_rhs",mpq_class(rounded_rhs).get_str()},
   {"row_feasible",exact<=rhs&&actual<=mpq_class(rounded_rhs)}};
 }
};

struct BELinearMath {
 const Instance&d;const BEROWitness&w;
 mpq_class sigma_min,sigma_max;
 BELinearMath(const Instance&data,const BEROWitness&wit):d(data),w(wit){
  mpq_class low=0,high=0;
  for(const auto&g:d.groups){
   mpq_class a=w.var.at(g.front()),b=a;
   for(int j:g){a=std::min(a,w.var[j]);b=std::max(b,w.var[j]);}
   low+=a;high+=b;
  }
  sigma_min=std::max(mpq_class(1,10000),BEROWitness::sqrt_interval(low).first);
  sigma_max=std::max(mpq_class(sigma_min*6/5),BEROWitness::sqrt_interval(high).second);
 }
 static mpq_class huber(const mpq_class&variance,const mpq_class&dev,const mpq_class&lambda){
  if(lambda<=0)throw std::logic_error("Positive lambda required");
  if(variance==0||dev==0)return 0;
  mpq_class z=std::min(dev,mpq_class(variance/(2*lambda)));
  mpq_class h=z-lambda*z*z/variance;h.canonicalize();return h;
 }
 std::vector<mpq_class> grid(const mpq_class&omega,int count=10)const {
  if(omega<=0)return {mpq_class(0)};
  if(count<2)throw std::logic_error("Lambda grid too short");
  mpq_class low=sigma_min/(4*omega),high=2*sigma_max/omega;
  const double a=std::log(low.get_d()),b=std::log(high.get_d());
  std::vector<mpq_class> out;
  for(int k=0;k<count;++k){
   double x=std::exp(a+(b-a)*k/(count-1));
   if(!(x>0)||!std::isfinite(x))throw std::logic_error("Nonfinite lambda grid");
   mpq_class q(x);q.canonicalize();if(out.empty()||q!=out.back())out.push_back(q);
  }
  return out;
 }
 BELinearRow row(mpq_class omega,mpq_class lambda,bool box=false)const {
  omega.canonicalize();lambda.canonicalize();
  if(omega<0||(!box&&omega>0&&lambda<=0))throw std::logic_error("Invalid BE row");
  BELinearRow r;r.omega=omega;r.lambda=(box||omega==0)?mpq_class(0):lambda;
  r.kind=box?"box_corner":omega==0?"zero_radius":"lambda_huber";
  r.rhs=w.capacity-w.margin;
  if(r.kind=="lambda_huber")r.rhs-=lambda*omega*omega;
  r.rhs.canonicalize();
  for(int j=0;j<d.n();++j){
   mpq_class a=w.mu[j];
   if(box)a+=w.dev[j];
   else if(omega>0)a+=huber(w.var[j],w.dev[j],lambda);
   a.canonicalize();r.weights.push_back(a);
   // Normalize before outward conversion; exact rational row is also checked.
   r.rounded.push_back(BudgetRO::outward(mpq_class(a/w.capacity),true));
  }
  r.rounded_rhs=BudgetRO::outward(mpq_class(r.rhs/w.capacity),false);
  for(const auto&g:d.groups){
   int j=*std::min_element(g.begin(),g.end(),[&](int a,int b){
    return r.rounded[a]==r.rounded[b]?a<b:r.rounded[a]<r.rounded[b];});
   r.minimum_selection.push_back(j);r.minimum_rounded_sum+=mpq_class(r.rounded[j]);
  }
  r.minimum_rounded_sum.canonicalize();
  r.feasible=r.minimum_rounded_sum<=mpq_class(r.rounded_rhs);
  return r;
 }
 bool feasible_at(const mpq_class&omega,int count=12)const {
  auto box=row(omega,0,true);
  if(box.feasible&&w.evaluate(box.minimum_selection,omega)["robust_feasible"].get<bool>())return true;
  for(const auto&lambda:grid(omega,count)){
   auto r=row(omega,lambda);
   if(r.feasible&&w.evaluate(r.minimum_selection,omega)["robust_feasible"].get<bool>())return true;
  }
  return false;
 }
};

class BELinearSolver {
 struct Impl;std::unique_ptr<Impl>impl;
public:
 BELinearSolver(const Instance&,int seed);
 ~BELinearSolver();
 Groups solve(const BELinearRow&,double seconds,int count,
              const std::set<Selection>&excluded,double cutoff,Json&log);
};
}
