#include "search.hpp"
namespace s10 {
namespace {int dist07(const Selection&a,const Selection&b){int n=0;for(std::size_t k=0;k<a.size();++k)n+=a[k]!=b[k];return n;}}
void Search::r07_polish(){
 if(!best){r07["polish_stop_reason"]="no_own_certified_incumbent";return;}
 auto&fft=*r07_fft;auto cost=[&](const Selection&s){return calibrated->exact_cost(s);};
 auto history=[&](const Selection&s,const Selection&a,double p,const std::string&stage){r07_private.push_back({{"selection",s},{"anchor",a},{"probability",p},{"stage",stage},{"distance",dist07(s,a)}});};
 auto fallbacks=[&](){Groups out;double level=std::min(fft.probability(best->selection),.99)-r07_epsilon;std::set<Selection> keys;for(const auto&q:pool)if(q.first!=best->selection&&fft.probability(q.first)>=level)keys.insert(q.first);return cost_order(keys);};
 auto cutoff=[&]()->std::optional<mpq_class>{auto v=fallbacks();return v.size()<4?std::nullopt:std::optional<mpq_class>(cost(v[3]));};
 auto certify=[&](const Groups&xs,const std::string&stage,bool fb){
  std::set<Selection> keys(xs.begin(),xs.end());for(const auto&s:cost_order(keys)){
   check_budget();if(pool.count(s)||r07_attempted.count(s))continue;double p=fft.probability(s);if(p<r07_gate())continue;
   auto cap=fb?cutoff():std::optional<mpq_class>(cost(best->selection));if(cap&&cost(s)>*cap-mpq_class(1,1000000))continue;
   Json c=cap?Json(cap->get_str()):Json(nullptr);int count=fallbacks().size();r07_native(s,fb?"R07_fallback":"R07_local",stage);r07_calls.back()["admission_cap_exact"]=c;r07_calls.back()["fallback_count_before"]=count;
  }
 };
 auto ngcuts=[&](std::vector<LinearRow>&rows){for(const auto&s:r07_attempted){Vector ng(instance.n());for(int j:s)ng[j]=1;rows.push_back({ng,-INFINITY,double(instance.m()-1)});}for(const auto&s:r07_local_seen)if(!r07_attempted.count(s)){Vector ng(instance.n());for(int j:s)ng[j]=1;rows.push_back({ng,-INFINITY,double(instance.m()-1)});}for(const auto&q:pool)if(!r07_attempted.count(q.first)&&!r07_local_seen.count(q.first)){Vector ng(instance.n());for(int j:q.first)ng[j]=1;rows.push_back({ng,-INFINITY,double(instance.m()-1)});}};
 auto local=[&](bool fb,int round)->Groups{
  check_budget();const auto anchor=best->selection;auto p=fft.marginals(anchor);Vector risk(instance.n()),trust(instance.n());for(int j=0;j<instance.n();++j)risk[j]=p.first-p.second[j];for(int j:anchor)trust[j]=1;
  auto cap=fb?cutoff():std::optional<mpq_class>(cost(anchor));mpq_class strictcap=cap?mpq_class(*cap-mpq_class(1,1000000)):mpq_class(0);double rhs=p.first-(fb?.99:r07_gate());int radius=fb?3:5;
  std::vector<LinearRow> rows{{risk,-INFINITY,rhs},{trust,double(instance.m()-radius),double(instance.m()-1)}};if(cap)rows.push_back({instance.costs,-INFINITY,BudgetRO::outward(strictcap,false)});ngcuts(rows);
  check_budget();double b=now();r07_launches.push_back({{"stage",fb?"stage4_fallback":"stage3b_local"},{"kind","MIP"},{"start",b-started}});Json log;
  auto raw=calibration_solver->solve(instance.costs,rows,std::max(.001,std::min(2.,remaining())),fb?20:15,.02,log);
  Json task={{"kind",fb?"B":"A"},{"round",round},{"start",b-started},{"finish",now()-started},{"anchor",anchor},{"anchor_probability",p.first},{"epsilon",r07_epsilon},{"risk",risk},{"rhs",rhs},{"cost_lower",nullptr},{"cost_upper_exact",cap?Json(strictcap.get_str()):Json(nullptr)},{"radius_min",1},{"radius_max",radius},{"solver",log},{"raw_returned_count",raw.size()},{"returned",Json::array()},{"excluded",Json::array()}};
  for(const auto&s:r07_attempted)task["excluded"].push_back(s);for(const auto&s:r07_local_seen)if(!r07_attempted.count(s))task["excluded"].push_back(s);task["raw_solutions"]=raw;
  Groups good;for(const auto&s:raw){check_budget();r07_local_seen.insert(s);double lhs=0;for(int j:s)lhs+=risk[j];int d=dist07(s,anchor);if(d<1||d>radius||(cap&&cost(s)>strictcap)||lhs>rhs+1e-8)continue;
   double py=fft.probability(s);history(s,anchor,py,fb?"B_local_MCKP":"A_local_MCKP");task["returned"].push_back(s);if(py>=r07_gate())good.push_back(s);
  }r07_mips.push_back(task);return good;
 };
 double t=now(),cdf=r07["timing"]["stage3a_cdf"].get<double>();Groups scan;std::vector<Selection> seeds{best->selection};std::set<Selection> all=calibrated->generated;all.insert(entropic->generated.begin(),entropic->generated.end());
 struct Rated{Selection s;double p,c;};std::vector<Rated> rated;for(const auto&s:all){check_budget();rated.push_back({s,fft.probability(s),instance.cost_of(s)});}std::sort(rated.begin(),rated.end(),[](const Rated&a,const Rated&b){return std::make_tuple(std::abs(a.p-.99),a.c,a.s)<std::make_tuple(std::abs(b.p-.99),b.c,b.s);});for(const auto&q:rated)if(seeds.size()<4&&std::find(seeds.begin(),seeds.end(),q.s)==seeds.end())seeds.push_back(q.s);
 r07["seeds"]=seeds;std::set<Selection> seen;
 for(const auto&x:seeds){check_budget();auto p=fft.marginals(x);struct Move{int g,j;double dc,dp;};std::vector<Move> cheap,safe;
  for(int g=0;g<instance.m();++g)for(int j:instance.groups[g])if(j!=x[g]){check_budget();auto y=x;y[g]=j;double py=p.second[j];history(y,x,py,"A_one");seen.insert(y);if(cost(y)<=cost(best->selection)-mpq_class(1,1000000)&&py>=r07_gate())scan.push_back(y);Move mv{g,j,instance.costs[j]-instance.costs[x[g]],py-p.first};if(mv.dc<0)cheap.push_back(mv);if(mv.dp>0)safe.push_back(mv);}
  for(const auto&a:cheap)for(const auto&b:safe)if(a.g!=b.g){check_budget();auto y=x;y[a.g]=a.j;y[b.g]=b.j;if(!seen.insert(y).second||cost(y)>cost(best->selection)-mpq_class(1,1000000))continue;double py=fft.probability(y);history(y,x,py,"A_two");if(py>=r07_gate())scan.push_back(y);}
 }
 r07["stage3a_scan_complete"]=true;certify(scan,"stage3a_cdf",false);r07["timing"]["stage3a_12opt"]=now()-t-(r07["timing"]["stage3a_cdf"].get<double>()-cdf);
 int stall=0,rounds=0;r07["local_rounds"]=Json::array();
 while(now()<deadline&&stall<2){
  double old=best->cost,b=now(),native=r07["timing"]["stage3b_cdf"].get<double>();auto found=local(false,++rounds);bool rawempty=r07_mips.back()["raw_returned_count"]==0;
  certify(found,"stage3b_cdf",false);bool improved=best->cost<old-1e-6;stall=improved?0:stall+1;r07["local_rounds"].push_back({{"round",rounds},{"best_before",old},{"best_after",best->cost},{"improved",improved},{"stall_after",stall},{"raw_empty",rawempty}});
  r07["timing"]["stage3b_local_mckp_mip"]=r07["timing"].value("stage3b_local_mckp_mip",0.)+now()-b-(r07["timing"]["stage3b_cdf"].get<double>()-native);
  if(rawempty){r07["local_stop_reason"]="no_pool_candidate_not_infeasibility_proof";break;}
 }
 r07["local_mckp_rounds"]=rounds;r07["fallback_rounds"]=Json::array();
 for(int round=1;round<=2&&now()<deadline;++round){
  double b=now(),native=r07["timing"]["stage4_cdf"].get<double>();auto old=cutoff();auto before=fallbacks();Groups candidates;auto anchor=best->selection;auto p=fft.marginals(anchor);
  for(int g=0;g<instance.m();++g)for(int j:instance.groups[g])if(j!=anchor[g]){check_budget();auto s=anchor;s[g]=j;double py=p.second[j];history(s,anchor,py,"B_one");if((!old||cost(s)<*old-mpq_class(1,1000000))&&py>=r07_gate())candidates.push_back(s);}
  auto found=local(true,round);bool rawempty=r07_mips.back()["raw_returned_count"]==0;candidates.insert(candidates.end(),found.begin(),found.end());certify(candidates,"stage4_cdf",true);auto after=fallbacks();auto cap=cutoff();bool improved=(!old&&after.size()>before.size())||(cap&&(!old||*cap<*old-mpq_class(1,1000000)));
  r07["fallback_rounds"].push_back({{"round",round},{"count_before",before.size()},{"count_after",after.size()},{"cap_before",old?Json(old->get_str()):Json(nullptr)},{"cap_after",cap?Json(cap->get_str()):Json(nullptr)},{"improved",improved},{"raw_empty",rawempty}});
  r07["timing"]["stage4_fallback_mip"]=r07["timing"].value("stage4_fallback_mip",0.)+now()-b-(r07["timing"]["stage4_cdf"].get<double>()-native);if(!improved||rawempty)break;
 }
 auto fb=fallbacks();auto cap=cutoff();r07["fallback_count"]=fb.size();r07["fallback_cap_exact"]=cap?Json(cap->get_str()):Json(nullptr);r07["qualified_fallback_ladder"]=Json::array();for(const auto&s:fb){if(r07["qualified_fallback_ladder"].size()>=5)break;r07["qualified_fallback_ladder"].push_back({{"selection",s},{"cost",instance.cost_of(s)},{"private_probability",fft.probability(s)}});}
 r07["private_FFT_seconds"]=fft.seconds;r07["polish_stop_reason"]="operators_completed_or_state_stop";
}
}
