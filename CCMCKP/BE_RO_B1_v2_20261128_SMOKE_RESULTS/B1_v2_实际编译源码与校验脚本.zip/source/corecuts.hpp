#pragma once
#include "evaluation.hpp"
#include <memory>
#include <numeric>
namespace s10 {
// Coordinatewise minima of sorted empirical quantiles are a stochastic lower
// envelope, not an admissible item or a new probability acceptance evaluator.
struct CoreResult { Selection groups; Certificate certificate; int attempts=0; bool timed_out=false; double seconds=0; };
class CoreExtractor {
    Instance virtual_data;
    Selection envelope_ids;
    std::unique_ptr<ExactOracle> oracle;
public:
    double spent=0;
    explicit CoreExtractor(const Instance& d,const std::string& capacity):virtual_data(d) {
        const double start=now();
        for(const auto& group:d.groups) {
            check_budget();
            std::vector<std::vector<std::pair<mpq_class,std::string>>> ordered;
            for(int j:group) {
                std::vector<std::pair<mpq_class,std::string>> row;
                for(const auto& text:d.decimals[j])row.push_back({rational_decimal(text),text});
                std::sort(row.begin(),row.end(),[](const auto&a,const auto&b){return a.first<b.first;});ordered.push_back(std::move(row));
            }
            std::vector<std::string> values;
            for(int k=0;k<d.sample_count;++k) {
                auto v=ordered.front()[k];for(const auto& row:ordered)if(row[k].first<v.first)v=row[k];values.push_back(v.second);
            }
            envelope_ids.push_back(int(virtual_data.decimals.size()));virtual_data.decimals.push_back(std::move(values));
        }
        oracle=std::make_unique<ExactOracle>(virtual_data,capacity);spent=now()-start;
    }
    CoreResult reduce(const Selection& reference,const Certificate& known) {
        if(!known.infeasible())throw std::logic_error("Core extraction requires exact upper infeasibility proof");
        CoreResult out;out.groups.resize(reference.size());std::iota(out.groups.begin(),out.groups.end(),0);out.certificate=known;
        if(spent>=40 || budget_left()<=3)return out;
        const double start=now(),old=phase_deadline;
        struct Restore {double value;~Restore(){phase_deadline=value;}} restore{old};
        phase_deadline=std::min(old-1,start+std::min(2.,40-spent));
        try {
            // One deterministic deletion pass; no claim of minimum-cardinality core.
            for(int g=0;g<int(reference.size());++g) {
                check_budget();Selection trial=out.groups;trial.erase(std::find(trial.begin(),trial.end(),g));
                Selection mixed=envelope_ids;for(int h:trial)mixed[h]=reference[h];
                auto counts=oracle->count(mixed,1024,false);++out.attempts;
                Certificate proof{0,counts.first,counts.second,1024,now()-start};
                if(proof.infeasible()){out.groups=std::move(trial);out.certificate=std::move(proof);}
            }
        }catch(const BudgetExpired&){out.timed_out=true;}
        out.seconds=now()-start;spent+=out.seconds;return out;
    }
};
} // namespace s10
