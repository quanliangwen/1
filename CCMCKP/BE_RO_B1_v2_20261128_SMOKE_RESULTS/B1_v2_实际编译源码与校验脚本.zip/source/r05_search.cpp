#include "search.hpp"
#include "polish_fft.hpp"
#include <numeric>
namespace s10 {
namespace {constexpr double R05_SAFE=.99005,R05_SAFE_FFT=.98985;int distance5(const Selection&a,const Selection&b){int n=0;for(std::size_t i=0;i<a.size();++i)n+=a[i]!=b[i];return n;}}

double Search::r05_native(const Selection&s,const std::string& source,const std::string& stage){
 const bool fresh=!pool.count(s)&&!decisions.count(s);const double begin=now();const double before=best?best->cost:std::numeric_limits<double>::infinity();
 Json q={{"selection",s},{"source",source},{"stage",stage},{"fresh",fresh},{"start",begin-started},{"best_cost_before",best?Json(best->cost):Json(nullptr)},
  {"best_probability_before",best?Json(best->certificate.probability()):Json(nullptr)},{"cost",instance.cost_of(s)},{"slice_deadline",phase_deadline-started}};
 double value=0;bool expired=false;
 try{value=native_check(s,source);}catch(const BudgetExpired&){expired=true;}
 const double used=now()-begin;r05["timing"][stage]=r05["timing"].value(stage,0.)+used;
 const bool improved=best&&best->cost<before-1e-6;
 q["elapsed"]=used;q["finish"]=now()-started;q["expired"]=expired;q["state"]=pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown";q["improved_best"]=improved;
 if(pool.count(s))q["certificate"]=pool.at(s).certificate.json(s);
 else if(infeasible_proofs.count(s))q["certificate"]=infeasible_proofs.at(s).json(s);
 r05_calls.push_back(q);
 if(stage=="mother_es95_native_cdf"&&fresh){r05["es95_cdf_calls"]=r05.value("es95_cdf_calls",0)+1;r05["es95_no_improve"]=improved?0:r05.value("es95_no_improve",0)+1;}
 if(stage=="mother_entropic_native_cdf"&&fresh){r05["entropic_cdf_calls"]=r05.value("entropic_cdf_calls",0)+1;if(improved)r05["entropic_improved_best"]=true;}
 return value;
}

Json Search::r05_run(){
 const double full=deadline,phase=phase_deadline;
 r05={{"model","R05_dual_surrogate_certification_gated_empirical_chance_hybrid"},{"historical_solution_inputs",false},{"generator_LSS_calls",0},{"private_cache_isolated",true},
  {"safe_probability",R05_SAFE},{"safe_fft_gate",R05_SAFE_FFT},{"fallback_ratio",.005},{"es95_no_improve",0},{"es95_cdf_calls",0},{"es95_stop_reason","completed"},
  {"entropic_improved_best",false},{"entropic_cdf_calls",0},{"seeds",Json::array()},{"parent_pool",Json::array()},{"private_FFT_is_certificate",false},
  {"nearest_rounding_is_unbiased_claim",false},{"precision_damping",12},{"timing",Json::object()}};
 for(const char* k:{"load_and_model","mother_es95_mip","mother_es95_native_cdf","mother_entropic_mip_fft","mother_entropic_native_cdf","polish_private_proposal","polish_channelA_native_cdf","polish_channelB_native_cdf","final_lss","save_and_fsync","unaccounted_overhead"})r05["timing"][k]=0.;
 r05["timing"]["load_and_model"]=now()-started;
 deadline=std::min(full,started+65);phase_deadline=std::min(phase,deadline);
 try{
  if(!calibrated->mean_infeasible&&calibrated->gamma_max>0){auto i=calibrated_register(calibrated->initial,calibrated->gamma_max,calibrated->initial_theta,"R02_self_generated_gamma_max_anchor");
   r05_native(calibrated->initial,"R02_self_generated_gamma_max_anchor","mother_es95_native_cdf");
   calibrated->proposals[i]["native_state"]=pool.count(calibrated->initial)?"accepted":"unknown";
   phase_records.push_back({{"phase","initialization"},{"own_raw_sample_initialization",true},{"best_before",nullptr},{"best_after",best?Json(best->cost):Json(nullptr)}, {"elapsed",now()-started},{"candidates_added",pool.size()}});
   r05_budget_search();}
 }catch(const BudgetExpired&){if(r05["es95_stop_reason"]=="completed")r05["es95_stop_reason"]="time_cap";}
 r05["timing"]["mother_es95_mip"]=calibrated->solver_seconds;r05["ES95_finished_seconds"]=now()-started;
 for(auto& q:calibrated->proposals){const auto s=q["selection"].get<Selection>();q["native_state"]=pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown";q["native_evaluation_completed"]=pool.count(s)||infeasible_proofs.count(s);}
 Json parent=Json::array();for(const auto& q:pool)parent.push_back(q.second.json());r05["ES95_pool"]=parent;
 deadline=std::min(full,std::min(started+90,now()+25));phase_deadline=std::min(phase,deadline);
 r05["entropic_best_cost_before"]=best?Json(best->cost):Json(nullptr);const double eb=now(),cn=r05["timing"]["mother_entropic_native_cdf"].get<double>();
 try{r05_entropic();}catch(const BudgetExpired&){r05["entropic_slice_expired"]=true;}
 r05["timing"]["mother_entropic_mip_fft"]=now()-eb-(r05["timing"]["mother_entropic_native_cdf"].get<double>()-cn);
 r05["entropic_best_cost_after"]=best?Json(best->cost):Json(nullptr);r05["mother_finished_seconds"]=now()-started;
 for(const auto& q:pool)r05["parent_pool"].push_back(q.second.json());
 deadline=full;phase_deadline=phase;try{r05_polish();}catch(const BudgetExpired&){r05["polish_stop_reason"]="shared_search_deadline";}
 deadline=full;phase_deadline=phase;
 if(best&&remaining()>2)try{final_check();}catch(const BudgetExpired&){r05["final_recount_interrupted"]=true;}
 return save("completed");
}

void Search::r05_entropic(){
 auto& e=*entropic;e.tilts={mpq_class(3,5),mpq_class(1,4)};
 std::unique_ptr<PolishFFT> fft;
 auto cheaper=[&](const Selection&s){return !best||e.exact_cost(s)<=e.exact_cost(best->selection)-mpq_class(1,1000000);};
 for(int k=0;k<2&&remaining()>1;++k){
  const auto& tab=e.prepare(k);if(!fft)fft=std::make_unique<PolishFFT>(instance.samples,instance.groups,options.capacity);
  mpq_class lo(4,5),hi=std::min(tab.eta_max,mpq_class(921,200));if(hi<lo)continue;std::set<Selection> all;
  auto query=[&](const mpq_class& eta,bool fine){
   check_budget();Vector weights;for(const auto&w:tab.upper)weights.push_back(BudgetRO::outward(w,true));
   auto rhs=e.bound_rhs(tab,eta);std::vector<LinearRow> rows{{weights,-std::numeric_limits<double>::infinity(),BudgetRO::outward(rhs,false)}};
   // Cost cuts apply to final pool requests; coarse private localization has no native calls.
   if(fine&&best)rows.push_back({instance.costs,-std::numeric_limits<double>::infinity(),BudgetRO::outward(e.exact_cost(best->selection)-mpq_class(1,1000000),false)});
   Json log;const double b=now();auto found=entropic_solver->solve(instance.costs,rows,std::min(.5,remaining()-.05),fine?10:1,.02,log);e.mip_seconds+=now()-b;++e.mips;
   Json q={{"table_index",k},{"eta",eta.get_str()},{"private_only_localization",!fine},{"cost_cap",fine&&best?Json(best->cost-1e-6):Json(nullptr)},{"solver",log},{"returned",Json::array()}};
   Groups good;
   for(const auto&s:found){check_budget();auto w=e.witness(s,k,eta,"R05_entropic_model");if(!w["entropic_upper_feasible"].get<bool>())continue;
    auto i=entropic_register(s,k,eta,"R05_entropic_model");const double prob=fft->probability(s);
    q["returned"].push_back({{"record_index",i},{"private_probability",prob}});all.insert(s);good.push_back(s);
    r05_private.push_back({{"selection",s},{"probability",prob},{"stage","entropic"},{"table",k},{"record_index",i}});
   }
   e.queries.push_back(q);return good;
  };
  for(int n=0;n<8&&remaining()>.7;++n){mpq_class mid=(lo+hi)/2;auto out=query(mid,false);if(out.empty())break;
   auto s=*std::min_element(out.begin(),out.end(),[&](const Selection&a,const Selection&b){return std::make_pair(instance.cost_of(a),a)<std::make_pair(instance.cost_of(b),b);});
   if(fft->probability(s)>=.99)hi=mid;else lo=mid;
  }
  for(auto eta:std::vector<mpq_class>{hi,mpq_class(hi-mpq_class(1,20))}){if(eta<e.eta_floor)eta=e.eta_floor;if(remaining()>.7)query(eta,true);}
  int calls=0;for(const auto&s:cost_order(all)){if(remaining()<=5||calls>=5)break;if(pool.count(s)||decisions.count(s)||!cheaper(s))continue;const double prob=fft->probability(s);if(prob<.9885)continue;
   const auto i=e.records.at(s);++calls;r05_native(s,"R05_entropic","mother_entropic_native_cdf");
   e.proposals[i]["native_state"]=pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown";e.proposals[i]["native_evaluation_completed"]=pool.count(s)||infeasible_proofs.count(s);
  }
 }
}

void Search::r05_polish(){
 if(!best){r05["polish_stop_reason"]="no_own_certified_incumbent";return;}
 const double global_deadline=deadline,global_phase=phase_deadline;std::unique_ptr<PolishFFT> fft;
 std::set<Selection> visited;std::vector<Selection> seeds;
 const double build=now();
 try{phase_deadline=std::min(global_phase,now()+25);fft=std::make_unique<PolishFFT>(instance.samples,instance.groups,options.capacity);}catch(...){phase_deadline=global_phase;throw;}
 r05["timing"]["polish_private_proposal"]=now()-build;phase_deadline=global_phase;
 auto used_prop=[&](){return r05["timing"]["polish_private_proposal"].get<double>();};
 auto used_cdf=[&](){return r05["timing"]["polish_channelA_native_cdf"].get<double>()+r05["timing"]["polish_channelB_native_cdf"].get<double>();};
 int callsA=0,callsB=0,noA=0,improvedA=0;bool everB=false,bclosed=false;std::size_t proposedA=0,passedA=0;
 auto safe_count=[&](){int n=0;if(!best)return n;for(const auto&q:pool)if(q.second.cost>=best->cost-1e-9&&q.second.cost<=best->cost*1.005+1e-9&&q.second.certificate.probability()>=R05_SAFE)++n;return n;};
 auto Bactive=[&](){return best&&best->certificate.probability()<R05_SAFE&&safe_count()<3&&callsB<8&&!bclosed;};
 auto admissible=[&](const Selection&s,double probability,bool B){double cost=instance.cost_of(s);return B?(cost>=best->cost-1e-9&&cost<=best->cost*1.005+1e-9&&probability>=R05_SAFE_FFT):(calibrated->exact_cost(s)<=calibrated->exact_cost(best->selection)-mpq_class(1,1000000)&&probability>=.9885);};
 auto exhausted=[&](){return used_prop()>=25||used_cdf()>=60||callsA+callsB>=35||remaining()<7;};
 auto generate=[&](const Selection& anchor,bool B){
  const double begin=now();const double cap=std::max(.001,25-used_prop());phase_deadline=std::min(global_phase,now()+cap);
  struct Move{int g,j;double dp,dc,p;};std::vector<Selection> out;
  try{
   Selection x=anchor;
   for(int step=0;step<(B?1:6);++step){
    const auto values=fft->marginals(x);double prob=values.first;std::vector<Move> moves;
    for(int g=0;g<instance.m();++g)for(int j:instance.groups[g])if(j!=x[g])moves.push_back({g,j,values.second[j]-prob,instance.costs[j]-instance.costs[x[g]],values.second[j]});
    std::stable_sort(moves.begin(),moves.end(),[](const Move&a,const Move&b){return std::tie(a.dc,a.g,a.j)<std::tie(b.dc,b.g,b.j);});
    std::optional<Move> next;double rate=-std::numeric_limits<double>::infinity();
    for(const auto&mv:moves){auto y=x;y[mv.g]=mv.j;
     if(visited.insert(y).second){r05_private.push_back({{"selection",y},{"anchor",x},{"probability",mv.p},{"stage",B?"B_one":"A_one"},{"distance",1}});out.push_back(y);}
     if(!B){if(prob<.99&&mv.dp>1e-9){double v=mv.dp/std::max(.01,mv.dc);if(v>rate){rate=v;next=mv;}}
      else if(prob>=.99&&mv.dc< -1e-8&&mv.p>=.9885&&!next)next=mv;}
    }
    // Directed cheap/safe two-group proposals are rescored, never linearized as certificates.
    if((B&&std::count_if(out.begin(),out.end(),[&](const Selection&s){return admissible(s,fft->probability(s),true);})<6)||!B){
     auto cheap=moves,safer=moves;std::stable_sort(safer.begin(),safer.end(),[](const Move&a,const Move&b){return std::make_tuple(-a.dp,a.dc,a.g,a.j)<std::make_tuple(-b.dp,b.dc,b.g,b.j);});
     if(cheap.size()>20)cheap.resize(20);if(safer.size()>25)safer.resize(25);int n=0;
     for(const auto&a:cheap)for(const auto&b:safer)if(a.g!=b.g&&n<40){auto y=x;y[a.g]=a.j;y[b.g]=b.j;if(!visited.insert(y).second)continue;++n;const double py=fft->probability(y);
      r05_private.push_back({{"selection",y},{"anchor",x},{"probability",py},{"stage",B?"B_two":"A_two"},{"distance",2}});out.push_back(y);}
    }
    if(B||!next)break;x[next->g]=next->j;
   }
  }catch(const BudgetExpired&){r05["proposal_partial"]=true;}
  phase_deadline=global_phase;r05["timing"]["polish_private_proposal"]=used_prop()+now()-begin;return out;
 };
 auto certify=[&](std::vector<Selection> candidates,bool B){
  std::set<Selection> unique(candidates.begin(),candidates.end());auto sorted=cost_order(unique);int batch=0;
  for(const auto&s:sorted){if(exhausted()||batch>=8||(B&&!Bactive()))break;if(pool.count(s)||decisions.count(s))continue;
   const double score_begin=now();const double py=fft->probability(s);r05["timing"]["polish_private_proposal"]=used_prop()+now()-score_begin;
   if(!admissible(s,py,B))continue;if(!B)++passedA;
   const double cap=std::max(.001,60-used_cdf());phase_deadline=std::min(global_phase,now()+cap);deadline=std::min(global_deadline,phase_deadline);
   const auto old=best->selection;const double prior=best->cost;Json before={{"private_probability",py},{"N_safe_before",safe_count()},{"B_active_before",Bactive()}};
   r05_native(s,B?"R05_polish_B":"R05_polish_A",B?"polish_channelB_native_cdf":"polish_channelA_native_cdf");r05_calls.back()["gate"]=before;
   deadline=global_deadline;phase_deadline=global_phase;++batch;
   if(B)++callsB;else{++callsA;if(best->cost<prior-1e-6){++improvedA;noA=0;bclosed=false;}else ++noA;}
   if(!B&&noA>=10&&!Bactive())break;
  }
 };
 auto doB=[&](){if(!Bactive()||exhausted())return;everB=true;auto candidates=generate(best->selection,true);certify(candidates,true);bclosed=true;};
 doB();
 seeds.push_back(best->selection);
 const double rank_begin=now();phase_deadline=std::min(global_phase,now()+std::max(.001,25-used_prop()));
 try{
  std::set<Selection> all=calibrated->generated;all.insert(entropic->generated.begin(),entropic->generated.end());
  struct Rated{Selection s;double p,c;};std::vector<Rated> rated;
  for(const auto&s:all){check_budget();rated.push_back({s,fft->probability(s),instance.cost_of(s)});}
  std::stable_sort(rated.begin(),rated.end(),[](const Rated&a,const Rated&b){return std::make_tuple(std::abs(a.p-.99),a.c,a.s)<std::make_tuple(std::abs(b.p-.99),b.c,b.s);});
  for(const auto&q:rated)if(seeds.size()<4&&std::find(seeds.begin(),seeds.end(),q.s)==seeds.end())seeds.push_back(q.s);
 }catch(const BudgetExpired&){r05["rank_partial"]=true;}
 phase_deadline=global_phase;r05["timing"]["polish_private_proposal"]=used_prop()+now()-rank_begin;
 for(const auto&s:seeds)r05["seeds"].push_back(s);
 for(const auto&s:seeds){if(exhausted()||(noA>=10&&!Bactive()))break;auto out=generate(s,false);proposedA+=out.size();certify(out,false);doB();}
 for(int round=0;round<2&&!exhausted()&&!(noA>=10&&!Bactive());++round){
  const double begin=now();phase_deadline=std::min(global_phase,now()+std::max(.001,25-used_prop()));Groups out;
  try{
   auto x=best->selection;auto values=fft->marginals(x);Vector risk(instance.n()),trust(instance.n());for(int j=0;j<instance.n();++j)risk[j]=values.first-values.second[j];for(int j:x)trust[j]=1;
   const double cost_cap=best->cost-1e-6;std::vector<LinearRow> rows{{risk,-std::numeric_limits<double>::infinity(),values.first-.9895},{trust,double(instance.m()-5),std::numeric_limits<double>::infinity()},{instance.costs,-std::numeric_limits<double>::infinity(),cost_cap}};
   for(const auto&s:visited){Vector ng(instance.n());for(int j:s)ng[j]=1;rows.push_back({ng,-std::numeric_limits<double>::infinity(),double(instance.m()-1)});}
   Json log;out=calibration_solver->solve(instance.costs,rows,std::min(1.,budget_left()),10,.02,log);
   Json q={{"anchor",x},{"anchor_probability",values.first},{"risk",risk},{"cost_cap",cost_cap},{"solver",log},{"returned",Json::array()}};
   Groups filtered;for(const auto&s:out){check_budget();double lhs=0;for(int j:s)lhs+=risk[j];if(distance5(x,s)>5||instance.cost_of(s)>cost_cap+1e-8||lhs>values.first-.9895+1e-8)continue;
    double py=fft->probability(s);q["returned"].push_back(s);r05_private.push_back({{"selection",s},{"anchor",x},{"probability",py},{"stage","A_local_MCKP"},{"distance",distance5(x,s)}});visited.insert(s);filtered.push_back(s);}
   r05_mips.push_back(q);out=filtered;
  }catch(const BudgetExpired&){r05["local_MIP_partial"]=true;}
  phase_deadline=global_phase;r05["timing"]["polish_private_proposal"]=used_prop()+now()-begin;proposedA+=out.size();certify(out,false);doB();
 }
 r05["channelA_proposed_unique"]=proposedA;r05["channelA_passed_gate"]=passedA;r05["channelA_cdf_calls"]=callsA;r05["channelA_improved_best_count"]=improvedA;r05["channelA_no_improve"]=noA;
 r05["channelB_triggered"]=everB;r05["channelB_cdf_calls"]=callsB;r05["channelB_safe_certified_count"]=safe_count();r05["private_FFT_seconds"]=fft->seconds;
 r05["polish_stop_reason"]=used_prop()>=25?"proposal_time_cap":used_cdf()>=60?"cert_time_cap":callsA+callsB>=35?"cert_call_cap":noA>=10?"early_stop_no_improve":"max_rounds_or_queue_empty";
}

void Search::r05_save_fields(Json& data){
 if(options.search_flow!="dual_budget_gated")return;
 Json cert=Json::array();for(const auto&q:pool)cert.push_back(q.second.json());
 r05["certified_pool"]=cert;Json ladder=Json::array();for(const auto&s:cost_order([&]{std::set<Selection>x;for(const auto&q:pool)x.insert(q.first);return x;}())){
  if(ladder.size()==3)break;const auto&q=pool.at(s);ladder.push_back({{"selection",s},{"cost",q.cost},{"native_cdf_prob",q.certificate.probability()},{"source",q.source}});}
 r05["fallback_ladder_top3"]=ladder;
 data["R05_model"]=r05;data["r05_cert_funnel"]=r05;data["r05_native_calls"]=r05_calls;data["r05_private_history"]=r05_private;data["r05_local_MIP"]=r05_mips;data["r05_timing_breakdown_sec"]=r05["timing"];
}
}
