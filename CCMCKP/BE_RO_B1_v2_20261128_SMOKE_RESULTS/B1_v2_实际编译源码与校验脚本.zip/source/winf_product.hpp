#pragma once
#include "evaluation.hpp"
#include <memory>
#include <algorithm>
namespace s10 {
// Exact pointwise counterpart of a type-infinity Wasserstein ball centered at
// the FULL independent empirical product. Ground gauge: max_j |dy_j|/r_j.
// For nonnegative x, all-atom translation +r attains the worst upper-tail law.
// r_j = ceil_1e-12(sqrt(v_pop/(10000*N))). This is a fixed engineering transport
// budget, NOT a finite-sample confidence radius for an unknown population law.
class WinfProduct {
public:
    static std::string finite_decimal(mpq_class x) {
        x.canonicalize();mpz_class den=x.get_den(),two=2,five=5,rest;
        auto a=mpz_remove(rest.get_mpz_t(),den.get_mpz_t(),two.get_mpz_t());den=rest;
        auto b=mpz_remove(rest.get_mpz_t(),den.get_mpz_t(),five.get_mpz_t());
        if(rest!=1)throw std::logic_error("Nonterminating shifted input");
        auto power=std::max(a,b);mpz_class scale;mpz_ui_pow_ui(scale.get_mpz_t(),10,power);
        mpz_class integer=x.get_num()*(scale/x.get_den());std::string text=integer.get_str();
        if(power==0)return text;
        bool negative=!text.empty()&&text[0]=='-';if(negative)text.erase(0,1);
        if(text.size()<=power)text=std::string(power+1-text.size(),'0')+text;
        text.insert(text.size()-power,1,'.');return negative?"-"+text:text;
    }
public:
    Instance shifted;
    std::vector<mpz_class> radius_units;
    std::vector<mpq_class> variances;
    std::unique_ptr<ExactOracle> oracle;
    Json metadata;
    double preparation_seconds=0;
    WinfProduct(const Instance& d,const std::string& cap):shifted(d) {
        double start=now();const mpz_class scale("1000000000000");Json radii=Json::array();
        for(int j=0;j<d.n();++j) {
            check_budget();mpq_class s=0,s2=0;
            for(const auto& text:d.decimals[j]){auto x=rational_decimal(text);s+=x;s2+=x*x;}
            mpq_class v=s2/d.sample_count-(s/d.sample_count)*(s/d.sample_count);v.canonicalize();
            if(v<0)throw std::logic_error("Negative exact empirical variance");
            variances.push_back(v);
            mpq_class square=v*scale*scale/(10000L*d.sample_count);square.canonicalize();
            mpz_class ceiling;mpz_cdiv_q(ceiling.get_mpz_t(),square.get_num().get_mpz_t(),square.get_den().get_mpz_t());
            mpz_class units;mpz_sqrt(units.get_mpz_t(),ceiling.get_mpz_t());if(units*units<ceiling)++units;
            radius_units.push_back(units);mpq_class radius(units,scale);radius.canonicalize();
            shifted.decimals[j].clear();shifted.samples[j].clear();
            for(const auto& text:d.decimals[j]){
                mpq_class x=rational_decimal(text)+radius;shifted.decimals[j].push_back(finite_decimal(x));shifted.samples[j].push_back(x.get_d());
            }
            shifted.mean[j]=d.mean[j]+radius.get_d();
            // Original sd and population variance unchanged by translation.
            radii.push_back({{"item",j},{"units_1e12",units.get_str()},{"exact_variance",v.get_str()},
                {"radius",radius.get_d()},{"radius_rational",radius.get_str()}});
        }
        preparation_seconds=now()-start;oracle=std::make_unique<ExactOracle>(shifted,cap);
        metadata={{"model","weighted_ground_linf_type_infinity_Wasserstein"},{"transport_order","infinity"},
            {"ground_gauge","max_j abs(y_j-z_j)/r_j; zero-radius coordinates fixed"},{"transport_radius",1},
            {"center","full_independent_empirical_product_all_original_samples"},{"original_sample_count_per_item",d.sample_count},
            {"item_count",d.n()},{"group_count",d.m()},
            {"not_500_pseudo_joint_scenarios",true},{"uncertain_support","nonnegative_continuum; not confined to observed atoms"},
            {"kappa","1/100"},{"radius_rule","ceil(1e12*sqrt(v_pop/(10000*N)))/1e12"},
            {"radius_units_denominator","1000000000000"},{"radii",radii},
            {"worst_case_law","push full product center through z -> z+r"},{"worst_case_event","sum_selected(z_j+r_j)<T"},
            {"robust_search_threshold","99/100"},{"nominal_fallback_in_DRO_pool",false},
            {"statistical_population_coverage_claim",false},{"global_search_optimality_claim",false},
            {"preparation_seconds",preparation_seconds}};
    }
    mpq_class shift(const Selection& s)const {
        mpz_class total=0;for(int j:s)total+=radius_units[j];mpq_class out(total,mpz_class("1000000000000"));out.canonicalize();return out;
    }
};
}
