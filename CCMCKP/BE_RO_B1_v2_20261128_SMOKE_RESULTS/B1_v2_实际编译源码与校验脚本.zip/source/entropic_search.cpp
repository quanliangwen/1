#include "search.hpp"
namespace s10 {
std::size_t Search::entropic_register(const Selection& s,int k,const mpq_class& eta,const std::string& source){
 auto& e=*entropic;if(e.records.count(s))return e.records.at(s);
 auto w=e.witness(s,k,eta,source);if(!w["entropic_upper_feasible"].get<bool>())throw std::logic_error("Unqualified entropic registration");
 std::size_t index=e.proposals.size();e.proposals.push_back(w);e.records[s]=index;e.generated.insert(s);return index;
}
std::string Search::entropic_assess(const Selection& s,int k,const mpq_class& eta,const std::string& source){
 auto& e=*entropic;auto index=entropic_register(s,k,eta,source);native_check(s,source);
 std::string state=pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown";
 e.proposals[index]["native_state"]=state;e.proposals[index]["native_evaluation_completed"]=true;e.proposals[index]["evaluation_finished_seconds"]=now()-started;return state;
}
void Search::entropic_initialization(){
 auto& e=*entropic;const auto& tab=e.prepare(0);
 if(tab.eta_max>=e.eta_floor)entropic_assess(tab.initial,0,tab.eta_max,"R03b_self_generated_upper_weight_anchor");
}
Groups Search::entropic_query(int k,const mpq_class& eta,bool fine){
 auto& e=*entropic;const auto& tab=e.tables.at(k);const auto qi=e.queries.size();
 e.queries.push_back({{"table_index",k},{"t",tab.t.get_str()},{"eta",eta.get_str()},{"stage",fine?"fine":"coarse"},{"candidate_refs",Json::array()},
  {"solver_tasks",Json::array()},{"CDF_monotonicity_claim",false},{"complete",false}});
 auto rhs=e.bound_rhs(tab,eta);
 if(tab.min_sum>rhs){e.queries[qi]["resource_infeasible_exact"]=true;e.queries[qi]["complete"]=true;return {};}
 if(fine&&best){auto bound=e.dual_bound(tab,eta);
  if(bound.value>=e.exact_cost(best->selection)){
   if(e.incumbent_recorded.insert(best->selection).second)e.incumbents.push_back(best->json());
   e.cost_cuts.push_back({{"table_index",k},{"eta",eta.get_str()},{"lambda",bound.lambda.get_str()},{"dual_lower",bound.value.get_str()},
    {"incumbent_selection",best->selection},{"incumbent_exact_cost",e.exact_cost(best->selection).get_str()},{"current_run_integer_CDF_incumbent",true},
    {"safe_for_implemented_upper_weight_model",true}});
   e.queries[qi]["safe_pruned"]=true;e.queries[qi]["complete"]=true;return {};
  }
 }
 Vector weights;for(const auto& w:tab.upper)weights.push_back(BudgetRO::outward(w,true));
 std::vector<LinearRow> rows{{weights,-std::numeric_limits<double>::infinity(),BudgetRO::outward(rhs,false)}};
 Json cap=nullptr,excluded=Json::array();
 if(fine&&best){auto value=e.exact_cost(best->selection);rows.push_back({instance.costs,-std::numeric_limits<double>::infinity(),BudgetRO::outward(value,true)});cap={{"selection",best->selection},{"cost",value.get_str()}};}
 if(fine)for(const auto& record:e.records){auto state=e.proposals[record.second]["native_state"].get<std::string>();if(state!="accepted"&&state!="infeasible")continue;
  Vector ng(instance.n());for(int j:record.first)ng[j]=1;rows.push_back({ng,-std::numeric_limits<double>::infinity(),double(instance.m()-1)});excluded.push_back(record.second);}
 Json log;double begin=now();auto found=entropic_solver->solve(instance.costs,rows,std::min(fine?1.:.25,remaining()-5),fine?25:1,.02,log);
 e.mip_seconds+=now()-begin;++e.mips;e.raw_returned+=found.size();log["current_run_cost_cap"]=cap;log["excluded_proposal_indices"]=excluded;log["returned"]=found.size();e.queries[qi]["solver_tasks"].push_back(log);
 Groups out;std::set<Selection> unique;
 for(const auto& s:found){check_budget();auto w=e.witness(s,k,eta,fine?"R03b_fine_entropic_MCKP":"R03b_coarse_entropic_MCKP");
  if(!w["entropic_upper_feasible"].get<bool>()){e.queries[qi]["numerical_rejections"].push_back(w);continue;}
  ++e.rational_returned;auto index=entropic_register(s,k,eta,fine?"R03b_fine_entropic_MCKP":"R03b_coarse_entropic_MCKP");e.queries[qi]["candidate_refs"].push_back(index);
  if(unique.insert(s).second)out.push_back(s);
 }
 std::stable_sort(out.begin(),out.end(),[&](const Selection& a,const Selection& b){return std::make_tuple(instance.cost_of(a),a)<std::make_tuple(instance.cost_of(b),b);});e.queries[qi]["complete"]=true;return out;
}
void Search::entropic_search(){
 auto& e=*entropic;
 std::map<int,std::pair<mpq_class,mpq_class>> brackets;std::map<int,int> rounds;std::set<int> stopped;
 // Prepare every registered tilt before fine enumeration. This prevents a
 // single near-boundary coefficient model from using the whole common clock.
 for(int k=0;k<int(e.tilts.size())&&remaining()>20;++k){
  const auto& tab=e.prepare(k);if(tab.eta_max<e.eta_floor)continue;
  entropic_assess(tab.initial,k,tab.eta_max,"R03b_self_generated_upper_weight_anchor");
  brackets[k]={e.eta_floor,tab.eta_max};rounds[k]=0;
 }
 e.metadata["query_schedule"]="all tilt anchors; round-robin coarse localization; round-robin fine MIP pools; global cost-order native CDF adjudication";
 for(int n=0;n<9&&remaining()>10;++n)for(auto& entry:brackets){
   if(remaining()<=10)break;int k=entry.first;auto& lo=entry.second.first;auto& hi=entry.second.second;
   if(stopped.count(k)||hi<=lo)continue;
   mpq_class mid=(lo+hi)/2;mid.canonicalize();auto candidates=entropic_query(k,mid,false);++rounds[k];
   e.queries.back()["lo_before"]=lo.get_str();e.queries.back()["hi_before"]=hi.get_str();
   if(candidates.empty()){e.queries.back()["localization_state"]="no_solver_candidate_not_a_model_infeasibility_proof";stopped.insert(k);continue;}
   const auto& s=candidates.front();auto state=entropic_assess(s,k,mid,"R03b_coarse_entropic_MCKP");
   e.queries.back()["selected_proposal_index"]=e.records.at(s);e.queries.back()["localization_state"]=state;
   if(state=="accepted")hi=mid;else if(state=="infeasible")lo=mid;else stopped.insert(k);
 }
 std::map<int,std::vector<mpq_class>> fine_points;
 for(const auto& entry:brackets){int k=entry.first;const auto& tab=e.tables.at(k);const auto& lo=entry.second.first;const auto& hi=entry.second.second;
  mpq_class delta=tab.eta_max/10;if(delta<mpq_class(1,5))delta=mpq_class(1,5);
  std::vector<mpq_class> fine{hi,mpq_class((lo+hi)/2),mpq_class(hi+delta/20),mpq_class(lo-delta/20),mpq_class(hi+3*delta/25)};std::set<mpq_class> seen;Json points=Json::array();
  for(auto eta:fine){if(eta<e.eta_floor)eta=e.eta_floor;if(eta>tab.eta_max)eta=tab.eta_max;eta.canonicalize();if(!seen.insert(eta).second)continue;points.push_back(eta.get_str());fine_points[k].push_back(eta);}
  e.metadata["tables"][k]["eta_bisect_lo"]=lo.get_str();e.metadata["tables"][k]["eta_bisect_hi"]=hi.get_str();e.metadata["tables"][k]["eta_bisect_rounds"]=rounds[k];e.metadata["tables"][k]["fine_eta_points"]=points;
 }
 std::set<Selection> pending;
 for(std::size_t p=0;p<5&&remaining()>10;++p)for(const auto& entry:fine_points){
  if(remaining()<=10)break;if(p>=entry.second.size())continue;
  auto out=entropic_query(entry.first,entry.second[p],true);pending.insert(out.begin(),out.end());
 }
 for(const auto& s:cost_order(pending)){
  if(remaining()<=6)break;auto index=e.records.at(s);const auto& proof=e.proposals[index];
  if(proof["native_state"]!="not_assessed")continue;
  entropic_assess(s,proof["table_index"].get<int>(),mpq_class(proof["eta"].get<std::string>()),"R03b_fine_entropic_MCKP");
 }
}
}
