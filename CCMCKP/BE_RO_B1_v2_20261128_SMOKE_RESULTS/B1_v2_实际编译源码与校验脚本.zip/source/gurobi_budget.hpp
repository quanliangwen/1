#pragma once
#include "model.hpp"
#include <gurobi_c.h>
namespace s10 {
inline int budget_callback(GRBmodel* model, void*, int, void*) {
    if(now()>=phase_deadline) GRBterminate(model);
    return 0;
}
}
