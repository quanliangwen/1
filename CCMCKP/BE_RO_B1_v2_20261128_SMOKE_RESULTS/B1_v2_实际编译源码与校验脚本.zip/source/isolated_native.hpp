#pragma once
#include "model.hpp"
#include <sys/wait.h>
#include <sys/prctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <cerrno>
#include <functional>
namespace s10 {
struct IsolatedResult {Json payload=nullptr;bool timeout=false;int status=0;double elapsed=0;};
// A fresh child of THIS run only. Parent alone changes its accepted pool.
inline IsolatedResult isolated_native(double end,const std::function<Json()>& work){
 const double begin=now();int fds[2];if(pipe(fds))throw std::runtime_error("native pipe failed");
 const pid_t parent=getpid(),pid=fork();
 if(pid<0){close(fds[0]);close(fds[1]);throw std::runtime_error("native fork failed");}
 if(pid==0){
  close(fds[0]);prctl(PR_SET_PDEATHSIG,SIGKILL);if(getppid()!=parent)_exit(91);
  int code=0;std::string data;
  try{data=work().dump();}catch(const std::exception&e){data=Json({{"exception",e.what()}}).dump();code=92;}
  const char* p=data.data();std::size_t left=data.size();
  while(left){auto n=write(fds[1],p,left);if(n>0){p+=n;left-=n;}else if(errno!=EINTR)break;}
  close(fds[1]);_exit(code);
 }
 close(fds[1]);fcntl(fds[0],F_SETFL,fcntl(fds[0],F_GETFL)|O_NONBLOCK);
 IsolatedResult result;std::string data;bool exited=false,eof=false;
 while(!exited||!eof){
  char buf[16384];ssize_t n;
  while((n=read(fds[0],buf,sizeof(buf)))>0)data.append(buf,n);
  if(n==0)eof=true;
  if(data.size()>8*1024*1024){kill(pid,SIGKILL);waitpid(pid,&result.status,0);close(fds[0]);throw std::runtime_error("native IPC size guard");}
  if(!exited){auto w=waitpid(pid,&result.status,WNOHANG);if(w==pid)exited=true;}
  if(exited&&eof)break;
  if(now()>=end){result.timeout=true;kill(pid,SIGKILL);while(waitpid(pid,&result.status,0)<0&&errno==EINTR){};break;}
  pollfd q{fds[0],POLLIN|POLLHUP,0};poll(&q,1,std::max(1,std::min(5,int(1000*(end-now())))));
 }
 close(fds[0]);result.elapsed=now()-begin;
 if(!result.timeout){if(!WIFEXITED(result.status)||WEXITSTATUS(result.status)!=0)throw std::runtime_error("native child failed: "+data);result.payload=Json::parse(data);}
 return result;
}
}
