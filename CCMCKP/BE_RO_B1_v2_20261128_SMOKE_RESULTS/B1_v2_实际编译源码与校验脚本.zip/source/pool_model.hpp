#pragma once
#include "mip.hpp"
namespace s10 {
class PoolModel {
public:
    PoolModel(const Instance&,int seed);
    ~PoolModel();
    Groups solve(const Vector&,const std::vector<LinearRow>&,double seconds,int count,double gap,Json& telemetry);
private:
    struct Impl;
    std::unique_ptr<Impl> impl;
};
}
