#pragma once
#include "fft.hpp"
#include <cmath>
#include <numeric>

namespace s10 {
// Private proposal scores only. Neither this lattice nor floating FFT owns
// acceptance, infeasibility proofs, the public guide cache, or final LSS.
class PolishFFT {
public:
 using Real=long double;
 using Row=std::vector<Real>;
 int bins; Real damping; double seconds=0;std::size_t scores=0,marginal_tables=0;
 const Groups groups;
 std::vector<Row> hist;
 std::vector<Freq<Real>> freq;
 Row undo;
 PolishFFT(const std::vector<Vector>& samples,const Groups& g,double capacity,int b=8192,Real a=12)
 :bins(b),damping(a),groups(g),hist(samples.size(),Row(b)),undo(b){
  const double begin=now();
  if(b<2||(b&(b-1))||!(capacity>0)||!(a>0))throw std::invalid_argument("Private FFT geometry");
  for(int k=0;k<b;++k)undo[k]=std::exp(a*Real(k)/b);
  for(std::size_t j=0;j<samples.size();++j){
   check_budget();if(samples[j].empty())throw std::invalid_argument("Empty FFT marginal");
   for(double v:samples[j]){
    if(!std::isfinite(v)||v<0)throw std::invalid_argument("Private FFT requires nonnegative finite resources");
    Real position=Real(v)*b/capacity;
    if(position>=b-.5L)continue; // Do not renormalize mass outside this lattice.
    int k=static_cast<int>(std::floor(position+.5L));hist[j][k]+=Real(1)/samples[j].size();
   }
   Row damped=hist[j];for(int k=0;k<b;++k)damped[k]/=undo[k];
   freq.push_back(forward(damped));
  }
  seconds+=now()-begin;
 }
 double probability(const Selection& s){
  const double begin=now();Freq<Real> product(bins+1,Real(1));
  for(int j:s){check_budget();multiply(product,freq.at(j));}
  auto p=inverse(product,false);Real total=0;
  for(int k=0;k<bins;++k)total+=std::max(Real(0),p[k])*undo[k];
  ++scores;seconds+=now()-begin;return clipped(total);
 }
 std::pair<double,Vector> marginals(const Selection& s){
  if(s.size()!=groups.size())throw std::invalid_argument("FFT selection groups");
  double base=probability(s);const double begin=now();const std::size_t m=s.size();
  std::vector<Freq<Real>> left(m+1,Freq<Real>(bins+1,Real(1))),right=left;
  for(std::size_t g=0;g<m;++g){check_budget();left[g+1]=left[g];multiply(left[g+1],freq.at(s[g]));}
  for(std::size_t g=m;g>0;--g){check_budget();right[g-1]=right[g];multiply(right[g-1],freq.at(s[g-1]));}
  Vector result(hist.size());
  for(std::size_t g=0;g<m;++g){
   check_budget();auto product=left[g];multiply(product,right[g+1]);auto p=inverse(product,false);Row cdf(bins);Real running=0;
   for(int k=0;k<bins;++k){running+=std::max(Real(0),p[k])*undo[k];cdf[k]=running;}
   for(int j:groups[g]){Real value=0;for(int k=0;k<bins;++k)value+=hist[j][k]*cdf[bins-1-k];result[j]=clipped(value);}
   result[s[g]]=base; // This option is the unchanged center, not a move.
  }
  ++marginal_tables;seconds+=now()-begin;return {base,result};
 }
private:
 static double clipped(Real p){return static_cast<double>(std::max(Real(0),std::min(Real(1),p)));}
};
}
