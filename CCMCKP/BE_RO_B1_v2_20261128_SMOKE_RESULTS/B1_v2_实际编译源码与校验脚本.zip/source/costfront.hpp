#pragma once
#include "ellipsoid.hpp"
namespace s10 {
// This constraint restricts proposals, never certifies the LSS chance constraint.
class CostFrontMaster {
public:
    CostFrontMaster(const Instance&, int seed, double gamma, double risk_cap, const Selection& own_start);
    ~CostFrontMaster();
    void set_cost_bound(double bound);
    bool exclude_processed(const Selection&);
    EllipsoidQuery next_candidate(double seconds);
private:
    struct Impl;
    std::unique_ptr<Impl> impl;
};
}
