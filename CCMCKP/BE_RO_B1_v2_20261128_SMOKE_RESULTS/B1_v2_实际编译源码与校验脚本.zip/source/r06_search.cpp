#include "search.hpp"
#include "polish_fft.hpp"
#include <numeric>
namespace s10 {
namespace {int distance5(const Selection&a,const Selection&b){int n=0;for(std::size_t i=0;i<a.size();++i)n+=a[i]!=b[i];return n;}}

double Search::r06_native(const Selection&s,const std::string& source,const std::string& stage){
 const bool fresh=!pool.count(s)&&!decisions.count(s);const double begin=now();const double before=best?best->cost:std::numeric_limits<double>::infinity();
 Json q={{"selection",s},{"source",source},{"stage",stage},{"fresh",fresh},{"start",begin-started},{"best_cost_before",best?Json(best->cost):Json(nullptr)},
  {"best_probability_before",best?Json(best->certificate.probability()):Json(nullptr)},{"cost",instance.cost_of(s)},{"slice_deadline",phase_deadline-started}};
 double value=0;bool expired=false;
 try{value=native_check(s,source);}catch(const BudgetExpired&){expired=true;}
 const double used=now()-begin;r06["timing"][stage]=r06["timing"].value(stage,0.)+used;
 const bool improved=best&&best->cost<before-1e-6;
 q["elapsed"]=used;q["finish"]=now()-started;q["expired"]=expired;q["state"]=pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown";q["improved_best"]=improved;
 if(pool.count(s))q["certificate"]=pool.at(s).certificate.json(s);
 else if(infeasible_proofs.count(s))q["certificate"]=infeasible_proofs.at(s).json(s);
 r06_calls.push_back(q);
 if(stage=="mother_es95_native_cdf"&&fresh){r06["es95_cdf_calls"]=r06.value("es95_cdf_calls",0)+1;r06["es95_no_improve"]=improved?0:r06.value("es95_no_improve",0)+1;}
 if(stage=="mother_entropic_native_cdf"&&fresh){r06["entropic_cdf_calls"]=r06.value("entropic_cdf_calls",0)+1;if(improved)r06["entropic_improved_best"]=true;}
 return value;
}

Json Search::r06_run(){
 const double full=deadline,phase=phase_deadline;
 r06={{"model","R06_dual_surrogate_certification_gated_empirical_chance_hybrid"},{"historical_solution_inputs",false},{"generator_LSS_calls",0},{"private_cache_isolated",true},
  {"fallback_ratio",.006},{"es95_no_improve",0},{"es95_cdf_calls",0},{"es95_stop_reason","completed"},
  {"entropic_improved_best",false},{"entropic_cdf_calls",0},{"seeds",Json::array()},{"parent_pool",Json::array()},{"private_FFT_is_certificate",false},
  {"nearest_rounding_is_unbiased_claim",false},{"precision_damping",12},{"timing",Json::object()}};
 for(const char* k:{"load_and_model","mother_es95_mip","mother_es95_native_cdf","mother_entropic_mip_fft","mother_entropic_native_cdf","polish_private_proposal","polish_channelA_native_cdf","polish_channelB_native_cdf","final_lss","save_and_fsync","unaccounted_overhead"})r06["timing"][k]=0.;
 r06["timing"]["load_and_model"]=now()-started;
 deadline=std::min(full,started+180);phase_deadline=std::min(phase,deadline);
 try{
  if(!calibrated->mean_infeasible&&calibrated->gamma_max>0){auto i=calibrated_register(calibrated->initial,calibrated->gamma_max,calibrated->initial_theta,"R02_self_generated_gamma_max_anchor");
   r06_native(calibrated->initial,"R02_self_generated_gamma_max_anchor","mother_es95_native_cdf");
   calibrated->proposals[i]["native_state"]=pool.count(calibrated->initial)?"accepted":"unknown";
   phase_records.push_back({{"phase","initialization"},{"own_raw_sample_initialization",true},{"best_before",nullptr},{"best_after",best?Json(best->cost):Json(nullptr)}, {"elapsed",now()-started},{"candidates_added",pool.size()}});
   r06_budget_search();}
 }catch(const BudgetExpired&){if(r06["es95_stop_reason"]=="completed")r06["es95_stop_reason"]="time_cap";}
 r06["es95_only_best_cost"]=best?Json(best->cost):Json(nullptr);
 r06["timing"]["mother_es95_mip"]=calibrated->solver_seconds;r06["ES95_finished_seconds"]=now()-started;
 for(auto& q:calibrated->proposals){const auto s=q["selection"].get<Selection>();q["native_state"]=pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown";q["native_evaluation_completed"]=pool.count(s)||infeasible_proofs.count(s);}
 Json parent=Json::array();for(const auto& q:pool)parent.push_back(q.second.json());r06["ES95_pool"]=parent;
 deadline=std::min(full,std::min(started+240,now()+60));phase_deadline=std::min(phase,deadline);
 r06["entropic_best_cost_before"]=best?Json(best->cost):Json(nullptr);const double eb=now(),cn=r06["timing"]["mother_entropic_native_cdf"].get<double>();
 try{r06_entropic();}catch(const BudgetExpired&){r06["entropic_slice_expired"]=true;}
 r06["timing"]["mother_entropic_mip_fft"]=now()-eb-(r06["timing"]["mother_entropic_native_cdf"].get<double>()-cn);
 r06["mother_only_best_cost"]=best?Json(best->cost):Json(nullptr);r06["mother_only_native_cdf_prob"]=best?Json(best->certificate.probability()):Json(nullptr);
 r06["entropic_best_cost_after"]=best?Json(best->cost):Json(nullptr);r06["mother_finished_seconds"]=now()-started;
 for(const auto& q:pool)r06["parent_pool"].push_back(q.second.json());
 deadline=full;phase_deadline=phase;try{r06_polish();}catch(const BudgetExpired&){r06["polish_stop_reason"]="shared_search_deadline";}
 deadline=full;phase_deadline=phase;
 if(best&&remaining()>2)try{final_check();}catch(const BudgetExpired&){r06["final_recount_interrupted"]=true;}
 return save("completed");
}

void Search::r06_entropic(){
 auto& e=*entropic;e.eta_floor=mpq_class(3,5);e.metadata["eta_floor"]=e.eta_floor.get_str();
 Selection ref=best?best->selection:minimum(instance.mean);double variance=0;for(int j:ref)variance+=instance.variance[j];double sigma=std::sqrt(std::max(0.,variance));
 e.tilts.clear();r06["sigma_ref_used"]=sigma;r06["sigma_reference_selection"]=ref;r06["sigma_reference_source"]=best?"current_run_certified_ES_incumbent":"self_minimum_mean_reference_only";
 r06["entropic_t_values_used"]=Json::array();r06["entropic_t_exact"]=Json::array();
 for(double c:{2.,1.,.5,3.}){double t=sigma>0?std::max(.001,std::min(50.,c/sigma)):50.;e.tilts.push_back(mpq_class(t));r06["entropic_t_values_used"].push_back(t);r06["entropic_t_exact"].push_back(e.tilts.back().get_str());}
 std::unique_ptr<PolishFFT> fft;
 auto cheaper=[&](const Selection&s){return !best||e.exact_cost(s)<=e.exact_cost(best->selection)-mpq_class(1,1000000);};
 for(int k=0;k<4&&remaining()>1;++k){
  const auto& tab=e.prepare(k);if(!fft)fft=std::make_unique<PolishFFT>(instance.samples,instance.groups,options.capacity);
  mpq_class lo(3,5),hi=std::min(tab.eta_max,mpq_class(921,200));if(hi<lo)continue;std::set<Selection> all;
  auto query=[&](const mpq_class& eta,bool fine){
   check_budget();Vector weights;for(const auto&w:tab.upper)weights.push_back(BudgetRO::outward(w,true));
   auto rhs=e.bound_rhs(tab,eta);std::vector<LinearRow> rows{{weights,-std::numeric_limits<double>::infinity(),BudgetRO::outward(rhs,false)}};
   // Cost cuts apply to final pool requests; coarse private localization has no native calls.
   if(fine&&best)rows.push_back({instance.costs,-std::numeric_limits<double>::infinity(),BudgetRO::outward(e.exact_cost(best->selection)-mpq_class(1,1000000),false)});
   Json log;const double b=now();auto found=entropic_solver->solve(instance.costs,rows,std::min(.5,remaining()-.05),fine?15:1,.02,log);e.mip_seconds+=now()-b;++e.mips;
   Json q={{"table_index",k},{"eta",eta.get_str()},{"private_only_localization",!fine},{"cost_cap",fine&&best?Json(best->cost-1e-6):Json(nullptr)},{"solver",log},{"returned",Json::array()}};
   Groups good;
   for(const auto&s:found){check_budget();auto w=e.witness(s,k,eta,"R06_entropic_model");if(!w["entropic_upper_feasible"].get<bool>())continue;
    auto i=entropic_register(s,k,eta,"R06_entropic_model");const double prob=fft->probability(s);
    q["returned"].push_back({{"record_index",i},{"private_probability",prob}});all.insert(s);good.push_back(s);
    r06_private.push_back({{"selection",s},{"probability",prob},{"stage","entropic"},{"table",k},{"record_index",i}});
   }
   e.queries.push_back(q);return good;
  };
  for(int n=0;n<8&&remaining()>.7;++n){mpq_class mid=(lo+hi)/2;auto out=query(mid,false);if(out.empty())break;
   auto s=*std::min_element(out.begin(),out.end(),[&](const Selection&a,const Selection&b){return std::make_pair(instance.cost_of(a),a)<std::make_pair(instance.cost_of(b),b);});
   if(fft->probability(s)>=.99)hi=mid;else lo=mid;
  }
  for(auto eta:std::vector<mpq_class>{hi,mpq_class(hi-mpq_class(1,20))}){if(eta<e.eta_floor)eta=e.eta_floor;if(remaining()>.7)query(eta,true);}
  int calls=0;for(const auto&s:cost_order(all)){if(remaining()<=5||calls>=8)break;if(pool.count(s)||decisions.count(s)||!cheaper(s))continue;const double prob=fft->probability(s);if(prob<.9885)continue;
   const auto i=e.records.at(s);++calls;r06_native(s,"R06_entropic","mother_entropic_native_cdf");
   e.proposals[i]["native_state"]=pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown";e.proposals[i]["native_evaluation_completed"]=pool.count(s)||infeasible_proofs.count(s);
  }
 }
}

void Search::r06_polish(){
 if(!best){r06["polish_stop_reason"]="no_own_certified_incumbent";return;}
 const double outer=deadline,outer_phase=phase_deadline;std::unique_ptr<PolishFFT> fft;
 int callsA=0,callsB=0,rounds=0;std::set<Selection> private_seen;std::vector<Selection> seeds{best->selection};
 auto prop=[&](){return r06["timing"]["polish_private_proposal"].get<double>();};
 auto cert=[&](){return r06["timing"]["polish_channelA_native_cdf"].get<double>()+r06["timing"]["polish_channelB_native_cdf"].get<double>();};
 auto stop=[&](){return remaining()<7||cert()>=150||callsA+callsB>=100;};
 auto owncost=[&](const Selection&s){return calibrated->exact_cost(s);};
 auto addhist=[&](const Selection&s,const Selection&anchor,double p,const char* stage){r06_private.push_back({{"selection",s},{"anchor",anchor},{"probability",p},{"stage",stage},{"distance",distance5(s,anchor)}});};
 auto timed_private=[&](auto work,double cap){const double b=now();phase_deadline=std::min(outer_phase,now()+std::max(.001,std::min(cap,45-prop())));try{work();}catch(const BudgetExpired&){r06["private_partial"]=true;}phase_deadline=outer_phase;r06["timing"]["polish_private_proposal"]=prop()+now()-b;};
 timed_private([&](){fft=std::make_unique<PolishFFT>(instance.samples,instance.groups,options.capacity);},45);
 if(!fft){r06["polish_stop_reason"]="private_setup_budget";return;}
 auto countfb=[&](){int count=0;double level=std::min(fft->probability(best->selection),.99);for(const auto&q:pool)if(q.first!=best->selection&&owncost(q.first)>=owncost(best->selection)&&owncost(q.first)<=owncost(best->selection)*mpq_class(503,500)&&fft->probability(q.first)>=level)++count;return count;};
 auto certify=[&](const Groups& candidates,bool B,int limit){
  std::set<Selection> unique(candidates.begin(),candidates.end());auto ordered=cost_order(unique);int used=0;
  for(const auto&s:ordered){if(stop()||used>=limit||(B&&callsB>=15))break;if(pool.count(s)||decisions.count(s))continue;
   double probability=0;timed_private([&](){probability=fft->probability(s);},45);
   if(B){if(s==best->selection||owncost(s)<owncost(best->selection)||owncost(s)>owncost(best->selection)*mpq_class(503,500)||probability<.9898)continue;}
   else if(owncost(s)>owncost(best->selection)-mpq_class(1,1000000)||probability<.9885)continue;
   const auto center=best->selection;const double p=best->cost;
   phase_deadline=std::min(outer_phase,now()+std::max(.001,150-cert()));deadline=std::min(outer,phase_deadline);
   r06_native(s,B?"R06_polish_B":"R06_polish_A",B?"polish_channelB_native_cdf":"polish_channelA_native_cdf");
   r06_calls.back()["private_probability"]=probability;r06_calls.back()["incumbent_before_selection"]=center;
   deadline=outer;phase_deadline=outer_phase;++used;if(B)++callsB;else ++callsA;
   if(B){int n=0;timed_private([&](){n=countfb();},45);if(n>=4)break;}
   if(best->cost<p-1e-6)r06["polish_improvements"]=r06.value("polish_improvements",0)+1;
  }
 };
 // One bounded neighborhood scan only. Reserve at least two local MIP rounds.
 Groups round0;
 timed_private([&](){
  std::set<Selection> all=calibrated->generated;all.insert(entropic->generated.begin(),entropic->generated.end());
  struct Rated{Selection s;double p,c;};std::vector<Rated> ranked;
  for(const auto&s:all){check_budget();ranked.push_back({s,fft->probability(s),instance.cost_of(s)});}
  std::stable_sort(ranked.begin(),ranked.end(),[](const Rated&a,const Rated&b){return std::make_tuple(std::abs(a.p-.99),a.c,a.s)<std::make_tuple(std::abs(b.p-.99),b.c,b.s);});
  for(const auto&q:ranked)if(seeds.size()<4&&std::find(seeds.begin(),seeds.end(),q.s)==seeds.end())seeds.push_back(q.s);
  for(const auto&x:seeds){auto table=fft->marginals(x);struct Move{int g,j;double dc,dp;};std::vector<Move> cheap,safe;
   for(int g=0;g<instance.m();++g)for(int j:instance.groups[g])if(j!=x[g]){auto y=x;y[g]=j;
    double py=table.second[j];addhist(y,x,py,"A_one");private_seen.insert(y);
    if(owncost(y)<=owncost(best->selection)-mpq_class(1,1000000)&&py>=.9885)round0.push_back(y);
    Move mv{g,j,instance.costs[j]-instance.costs[x[g]],py-table.first};if(mv.dc<0)cheap.push_back(mv);if(mv.dp>0)safe.push_back(mv);
   }
   std::stable_sort(cheap.begin(),cheap.end(),[](const Move&a,const Move&b){return std::tie(a.dc,a.g,a.j)<std::tie(b.dc,b.g,b.j);});
   std::stable_sort(safe.begin(),safe.end(),[](const Move&a,const Move&b){return std::make_tuple(-a.dp,a.dc,a.g,a.j)<std::make_tuple(-b.dp,b.dc,b.g,b.j);});
   if(cheap.size()>20)cheap.resize(20);if(safe.size()>25)safe.resize(25);int pairs=0;
   for(const auto&a:cheap)for(const auto&b:safe)if(a.g!=b.g&&pairs<40){auto y=x;y[a.g]=a.j;y[b.g]=b.j;if(!private_seen.insert(y).second)continue;++pairs;check_budget();double py=fft->probability(y);addhist(y,x,py,"A_two");if(py>=.9885&&owncost(y)<=owncost(best->selection)-mpq_class(1,1000000))round0.push_back(y);}
  }
 },std::max(.001,15-prop()));
 r06["seeds"]=seeds;int beforeA=callsA;certify(round0,false,15);r06["round0_native_calls"]=callsA-beforeA;
 // Mandatory first two rounds even if round0 or round1 had no admitted vector.
 for(int k=0;k<3&&!stop()&&prop()<43;++k){
  Groups found;bool productive=false;Json task;Selection anchor=best->selection;
  timed_private([&](){
   auto p=fft->marginals(anchor);Vector risk(instance.n()),trust(instance.n());for(int j=0;j<instance.n();++j)risk[j]=p.first-p.second[j];for(int j:anchor)trust[j]=1;
   mpq_class cap=owncost(anchor)-mpq_class(1,1000000);
   std::vector<LinearRow> rows{{risk,-std::numeric_limits<double>::infinity(),p.first-.9890},{trust,double(instance.m()-5),double(instance.m()-1)},{instance.costs,-std::numeric_limits<double>::infinity(),BudgetRO::outward(cap,false)}};
   for(const auto&q:r06_calls)if(q["stage"].get<std::string>().find("polish_")==0){auto s=q["selection"].get<Selection>();Vector ng(instance.n());for(int j:s)ng[j]=1;rows.push_back({ng,-std::numeric_limits<double>::infinity(),double(instance.m()-1)});}
   Json log;auto raw=calibration_solver->solve(instance.costs,rows,std::min(2.,budget_left()),15,.02,log);++rounds;
   task={{"kind","A"},{"anchor",anchor},{"anchor_probability",p.first},{"risk",risk},{"rhs",p.first-.9890},{"cost_lower",nullptr},{"cost_upper_exact",cap.get_str()},{"radius_min",1},{"radius_max",5},{"solver",log},{"returned",Json::array()}};
   for(const auto&s:raw){check_budget();double lhs=0;for(int j:s)lhs+=risk[j];int d=distance5(s,anchor);if(d<1||d>5||owncost(s)>cap||lhs>p.first-.9890+1e-8)continue;
    double py=fft->probability(s);addhist(s,anchor,py,"A_local_MCKP");task["returned"].push_back(s);if(py>=.9885){found.push_back(s);productive=true;}}
  },45);if(!task.is_null())r06_mips.push_back(task);certify(found,false,10);
  if(k>=1&&!productive)break;
 }
 r06["local_mckp_rounds_executed"]=rounds;
 // Fallback-only local MIP enumerates a bounded pool, never claims complete enumeration.
 int nfb=0;timed_private([&](){nfb=countfb();},45);
 if(nfb<4&&!stop()&&prop()<43){
  Groups candidates;Json task;Selection anchor=best->selection;int generated=0;
  timed_private([&](){
   auto p=fft->marginals(anchor);Vector risk(instance.n()),trust(instance.n());for(int j=0;j<instance.n();++j)risk[j]=p.first-p.second[j];for(int j:anchor)trust[j]=1;
   auto lo=owncost(anchor),hi=mpq_class(lo*mpq_class(503,500));
   for(int g=0;g<instance.m();++g)for(int j:instance.groups[g])if(j!=anchor[g]){auto s=anchor;s[g]=j;double py=p.second[j];addhist(s,anchor,py,"B_one");if(owncost(s)>=lo&&owncost(s)<=hi&&py>=.9895)candidates.push_back(s);}
   std::vector<LinearRow> rows{{risk,-std::numeric_limits<double>::infinity(),p.first-.9900},{trust,double(instance.m()-3),double(instance.m()-1)},{instance.costs,BudgetRO::outward(lo,true),BudgetRO::outward(hi,false)}};
   for(const auto&q:pool){Vector ng(instance.n());for(int j:q.first)ng[j]=1;rows.push_back({ng,-std::numeric_limits<double>::infinity(),double(instance.m()-1)});}
   Json log;auto raw=calibration_solver->solve(instance.costs,rows,std::min(2.,budget_left()),25,.02,log);
   task={{"kind","B"},{"anchor",anchor},{"anchor_probability",p.first},{"risk",risk},{"rhs",p.first-.9900},{"cost_lower",lo.get_str()},{"cost_upper_exact",hi.get_str()},{"radius_min",1},{"radius_max",3},{"solver",log},{"returned",Json::array()}};
   for(const auto&s:raw){check_budget();double lhs=0;for(int j:s)lhs+=risk[j];int d=distance5(s,anchor);if(d<1||d>3||owncost(s)<lo||owncost(s)>hi||lhs>p.first-.99+1e-8)continue;
    double py=fft->probability(s);addhist(s,anchor,py,"B_local_MCKP");task["returned"].push_back(s);++generated;if(py>=.9898)candidates.push_back(s);}
  },45);if(!task.is_null())r06_mips.push_back(task);r06["channelB_mip_candidates_generated"]=generated;certify(candidates,true,15);
 }
 timed_private([&](){nfb=countfb();r06["private_best_probability"]=fft->probability(best->selection);},45);
 r06["channelB_certified_in_band_count"]=nfb;r06["channelA_cdf_calls"]=callsA;r06["channelB_cdf_calls"]=callsB;
 r06["private_FFT_seconds"]=fft->seconds;r06["polish_stop_reason"]=stop()?"certification_or_shared_budget":prop()>=45?"private_budget":"operators_completed_or_converged";
 Json ladder=Json::array();for(const auto&s:cost_order([&](){std::set<Selection>x;for(const auto&q:pool)x.insert(q.first);return x;}())){if(ladder.size()>=5)break;auto&q=pool.at(s);double py=0;timed_private([&](){py=fft->probability(s);},45);ladder.push_back({{"selection",s},{"cost",q.cost},{"private_fft_prob",py},{"native_cdf_lb",q.certificate.probability()},{"source",q.source}});}r06["ladder_private_snapshot"]=ladder;
 deadline=outer;phase_deadline=outer_phase;
}
void Search::r06_save_fields(Json& data){
 if(options.search_flow!="quality_dual_gated")return;
 Json cert=Json::array();for(const auto&q:pool)cert.push_back(q.second.json());
 r06["certified_pool"]=cert;Json ladder=Json::array();for(const auto&s:cost_order([&]{std::set<Selection>x;for(const auto&q:pool)x.insert(q.first);return x;}())){
  if(ladder.size()==5)break;const auto&q=pool.at(s);ladder.push_back({{"selection",s},{"cost",q.cost},{"native_cdf_prob",q.certificate.probability()},{"source",q.source}});}
 r06["low_cost_certified_ladder_top5"]=ladder;r06["final_best_internal_cost"]=best?Json(best->cost):Json(nullptr);
 data["config"]["LSS_reserve_seconds"]=std::min(120.,options.seconds*.3);data["r06_stage_milestones"]=r06;
 data["R06_model"]=r06;data["r06_cert_funnel"]=r06;data["r06_native_calls"]=r06_calls;data["r06_private_history"]=r06_private;data["r06_local_MIP"]=r06_mips;data["r06_timing_breakdown_sec"]=r06["timing"];
}
}
