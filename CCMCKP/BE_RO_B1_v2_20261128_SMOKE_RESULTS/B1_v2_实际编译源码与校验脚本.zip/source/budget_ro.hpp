#pragma once
#include "evaluation.hpp"
#include <algorithm>
#include <cmath>
#include <numeric>
#include <set>

namespace s10 {
// Bertsimas--Sim upper-deviation budget. This is a candidate-generation RO
// model, NOT a distributional ambiguity set and NOT a .99 coverage theorem.
// Exact decimal rationals own the model; outward doubles only propose MIP rows.
class BudgetRO {
public:
    const Instance& data;
    mpq_class capacity, margin=mpq_class(1,100000000);
    std::vector<mpq_class> means, deviations, upper, thresholds, gammas;
    Json metadata, proposals=Json::array(), subproblems=Json::array();
    double preparation_seconds=0, ranking_seconds=0;
    std::set<Selection> generated;
    static double outward(mpq_class q,bool upward) {
        q.canonicalize();double value=q.get_d();
        if(!std::isfinite(value))throw std::runtime_error("Nonfinite budget coefficient");
        while(upward?mpq_class(value)<q:mpq_class(value)>q)
            value=std::nextafter(value,upward?INFINITY:-INFINITY);
        return value;
    }
    static mpq_class protection(std::vector<mpq_class> values,mpq_class gamma) {
        if(gamma<0)throw std::logic_error("Negative uncertainty budget");
        std::sort(values.begin(),values.end(),std::greater<mpq_class>());
        mpq_class result=0;
        for(const auto& d:values) {
            if(d<0)throw std::logic_error("Negative deviation");
            if(gamma<=0)break;
            mpq_class z=gamma<1?gamma:mpq_class(1);result+=z*d;gamma-=z;
        }
        result.canonicalize();return result;
    }
    BudgetRO(const Instance& d,const std::string& cap):data(d),capacity(rational_decimal(cap)) {
        const double begin=now();Json items=Json::array();std::set<mpq_class> ts{mpq_class(0)};
        for(int j=0;j<d.n();++j) {
            check_budget();mpq_class total=0,top=0;
            for(const auto& text:d.decimals[j]){auto v=rational_decimal(text);total+=v;if(v>top)top=v;}
            mpq_class mu=total/d.sample_count,delta=top-mu;mu.canonicalize();delta.canonicalize();
            if(delta<0)throw std::logic_error("Mean above empirical maximum");
            means.push_back(mu);deviations.push_back(delta);upper.push_back(top);ts.insert(delta);
            items.push_back({{"item",j},{"mean",mu.get_str()},{"upper",top.get_str()},{"deviation",delta.get_str()}});
        }
        thresholds.assign(ts.begin(),ts.end());
        // A priori fixed positive-budget portfolio; no LSS-driven budget tuning.
        for(const char* ratio:{"1/10","3/20","1/20","1/5","1/40","3/10","1/2","1"}) {
            mpq_class g=mpq_class(ratio)*d.m();g.canonicalize();gammas.push_back(g);
        }
        Json gs=Json::array();for(const auto& g:gammas)gs.push_back(g.get_str());
        preparation_seconds=now()-begin;
        metadata={{"model","Bertsimas_Sim_upper_deviation_budget_RO"},{"items",items},
            {"all_original_samples",true},{"samples_per_item",d.sample_count},
            {"uncertainty_set","a=mean+d*z; 0<=z<=1; sum z<=Gamma"},
            {"deviation_rule","max(original samples)-exact sample mean"},
            {"budget_order",gs},{"threshold_count",thresholds.size()},
            {"thresholds","all distinct item deviations plus zero"},
            {"positive_budget_only",true},{"nominal_zero_budget_fallback",false},
            {"robust_guard",margin.get_str()},{"fixed_gamma_candidate_quota",16},
            {"MIP_slice_seconds",1.0},{"MIP_solutions_per_subproblem",2},
            {"subproblem_order","round robin budgets; ascending Lagrangian rank, rank is not a pruning certificate"},
            {"partial_threshold_enumeration_possible",true},{"global_optimality_claim",false},
            {"probability_coverage_claim",false},{"Gamma_is_probability_level",false},
            {"historical_solution_inputs",false},{"external_MIPstarts",false},
            {"original_CDF_gate_preserved",true},{"final_acceptance","unchanged original LSS"},
            {"preparation_seconds",preparation_seconds}};
    }
    mpq_class nominal(const Selection& s)const {mpq_class v=0;for(int j:s)v+=means[j];v.canonicalize();return v;}
    mpq_class worst(const Selection& s,const mpq_class& gamma)const {
        std::vector<mpq_class> ds;for(int j:s)ds.push_back(deviations[j]);
        mpq_class value=nominal(s)+protection(ds,gamma);value.canonicalize();return value;
    }
    mpq_class theta_value(const Selection& s,const mpq_class& gamma,const mpq_class& theta)const {
        mpq_class value=nominal(s)+gamma*theta;
        for(int j:s)if(deviations[j]>theta)value+=deviations[j]-theta;
        value.canonicalize();return value;
    }
    Vector row(const mpq_class& theta)const {
        Vector v;v.reserve(means.size());for(std::size_t j=0;j<means.size();++j) {
            mpq_class a=means[j];if(deviations[j]>theta)a+=deviations[j]-theta;
            v.push_back(outward(a,true));
        }return v;
    }
    double rhs(const mpq_class& gamma,const mpq_class& theta)const {
        return outward(capacity-margin-gamma*theta,false);
    }
    Json witness(const Selection& s,const mpq_class& gamma,const mpq_class& theta,const std::string& origin)const {
        data.validate(s);auto value=worst(s,gamma),fixed=theta_value(s,gamma,theta);mpq_class slack=capacity-margin-value;slack.canonicalize();
        return {{"selection",s},{"gamma",gamma.get_str()},{"theta",theta.get_str()},
            {"nominal_sum",nominal(s).get_str()},{"budget_worst_sum",value.get_str()},
            {"fixed_theta_sum",fixed.get_str()},{"robust_slack",slack.get_str()},
            {"robust_feasible",value<=capacity-margin},{"fixed_theta_feasible",fixed<=capacity-margin},
            {"source",origin},{"own_run_raw_samples",true},{"not_a_probability_estimate",true}};
    }
    // Lagrangian lower bounds only set traversal order. No floating hard cut.
    static double rank(const Instance& d,const Vector& w,double rhs) {
        auto evaluate=[&](double lambda){double value=-lambda*rhs,weight=0;
            for(const auto& group:d.groups){int best=group.front();for(int j:group) {
                if(d.costs[j]+lambda*w[j]<d.costs[best]+lambda*w[best])best=j;}
                value+=d.costs[best]+lambda*w[best];weight+=w[best];}
            return std::make_pair(value,weight);};
        double lo=0,hi=1,best=evaluate(0).first;
        for(int i=0;i<24&&evaluate(hi).second>rhs;++i)hi*=2;
        for(int i=0;i<32;++i){double mid=(lo+hi)/2;auto v=evaluate(mid);best=std::max(best,v.first);if(v.second>rhs)lo=mid;else hi=mid;}
        return best;
    }
    Json statistics()const {return {{"preparation_seconds",preparation_seconds},{"ranking_seconds",ranking_seconds},
        {"unique_proposals",generated.size()},{"subproblem_count",subproblems.size()},{"no_LSS_calls_in_generator",true}};}
};
}
