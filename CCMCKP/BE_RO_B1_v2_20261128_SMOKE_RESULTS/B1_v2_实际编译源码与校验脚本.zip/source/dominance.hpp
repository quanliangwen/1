#pragma once
#include "evaluation.hpp"
namespace s10 {
// Exact finite-empirical first-order stochastic order, local to this instance/run.
class DominanceTable {
public:
    explicit DominanceTable(const Instance& data);
    Groups worse_sets(const Selection& selection) const;
    const Selection& worse(int item) const { return sets.at(item); }
private:
    const Instance& data;
    Groups sets;
};
}
