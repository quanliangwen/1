#pragma once
#include "budget_ro.hpp"
#include "entropic_math.hpp"
#include <map>
namespace s10 {
class EntropicModel {
public:
 const Instance& data;mpq_class capacity,margin=mpq_class(1,100000000),eta_floor=mpq_class(4,5),eta_cap;
 std::vector<mpq_class> tilts{mpq_class(1,10),mpq_class(4,25),mpq_class(1,4),mpq_class(2,5),mpq_class(3,5),mpq_class(17,20)};
 std::vector<std::vector<mpq_class>> samples;
 struct Table {int index;mpq_class t,eta_max,min_sum;std::vector<mpq_class> lower,upper;Selection initial;};
 std::map<int,Table> tables;
 Json metadata,proposals=Json::array(),queries=Json::array(),cost_cuts=Json::array(),incumbents=Json::array();
 std::map<Selection,std::size_t> records;std::set<Selection> generated,incumbent_recorded;
 double preparation_seconds=0,mip_seconds=0;int mips=0,raw_returned=0,rational_returned=0;
 EntropicModel(const Instance& d,const std::string& cap):data(d),capacity(rational_decimal(cap)){
  double begin=now();auto c=EntropicMath::log_positive(mpq_class(100));eta_cap=mpq_class(c.upper,EntropicMath::scale());eta_cap.canonicalize();
  for(const auto& row:d.decimals){std::vector<mpq_class> values;for(const auto& s:row)values.push_back(rational_decimal(s));samples.push_back(std::move(values));check_budget();}
  metadata={{"model","R03b_empirical_entropic_risk_CDF_proxy"},{"center","full_independent_empirical_product_all_original_samples"},{"all_original_samples",true},{"samples_per_item",d.sample_count},
   {"risk_representation","(1/t) log E_P exp(t*sum) = sup_Q E_Q(sum)-KL(Q||P)/t"},{"fixed_radius_KL_ball_claim",false},{"population_probability_coverage_claim",false},
   {"eta_floor",eta_floor.get_str()},{"eta_cap_upper_log100",eta_cap.get_str()},{"eta_below_log100_is_not_a_0.99_sufficient_condition",true},
   {"coefficient_enclosure","directed_GMP_fixedpoint_exp_Taylor_squaring_and_log_atanh"},{"precision_bits",EntropicMath::bits},{"exp_terms",EntropicMath::exp_terms},{"log_terms",EntropicMath::log_terms},
   {"robust_guard",margin.get_str()},{"CDF_localization_is_heuristic",true},{"CDF_solution_probability_monotonicity_claim",false},{"coarse_rounds_per_t",9},
   {"historical_solution_inputs",false},{"external_MIPstarts",false},{"original_CDF_gate_preserved",true},{"final_acceptance","unchanged original LSS"},{"global_optimality_claim",false},{"tables",Json::array()}};
  preparation_seconds=now()-begin;
 }
 const Table& prepare(int index){
  if(tables.count(index))return tables.at(index);double begin=now();Table tab;tab.index=index;tab.t=tilts.at(index);Json items=Json::array();
  try{
   for(int j=0;j<data.n();++j){check_budget();auto w=EntropicMath::weight(samples[j],tab.t);tab.lower.push_back(w.first);tab.upper.push_back(w.second);
    items.push_back({{"item",j},{"lower",w.first.get_str()},{"upper",w.second.get_str()}});}
   tab.min_sum=0;for(const auto& g:data.groups){int j=*std::min_element(g.begin(),g.end(),[&](int a,int b){return std::make_pair(tab.upper[a],a)<std::make_pair(tab.upper[b],b);});tab.initial.push_back(j);tab.min_sum+=tab.upper[j];}
   tab.eta_max=tab.t*(capacity-margin-tab.min_sum);if(tab.eta_max>eta_cap)tab.eta_max=eta_cap;tab.eta_max.canonicalize();
   metadata["tables"].push_back({{"index",index},{"t",tab.t.get_str()},{"items",items},{"minimum_upper_weight_sum",tab.min_sum.get_str()},{"eta_max",tab.eta_max.get_str()},
    {"initial_selection",tab.initial},{"resource_feasible_at_eta_floor",tab.eta_max>=eta_floor}});
   preparation_seconds+=now()-begin;tables[index]=std::move(tab);return tables.at(index);
  }catch(...){preparation_seconds+=now()-begin;metadata["partial_preparation_interrupted"]=true;throw;}
 }
 mpq_class exact_cost(const Selection& s)const{mpq_class c=0;for(int j:s)c+=mpq_class(data.costs[j]);c.canonicalize();return c;}
 mpq_class bound_rhs(const Table& t,const mpq_class& eta)const{mpq_class rhs=capacity-margin-eta/t.t;rhs.canonicalize();return rhs;}
 Json witness(const Selection& s,int index,const mpq_class& eta,const std::string& source)const{
  data.validate(s);const auto& tab=tables.at(index);mpq_class lo=0,hi=0;for(int j:s){lo+=tab.lower[j];hi+=tab.upper[j];}lo.canonicalize();hi.canonicalize();auto rhs=bound_rhs(tab,eta);
  return {{"selection",s},{"table_index",index},{"t",tab.t.get_str()},{"eta",eta.get_str()},{"weight_sum_lower",lo.get_str()},{"weight_sum_upper",hi.get_str()},
   {"rhs_exact",rhs.get_str()},{"entropic_upper_feasible",hi<=rhs},{"empirical_0.99_sufficient_eta",eta>=eta_cap},
   {"source",source},{"own_run_raw_samples",true},{"not_a_probability_estimate",true},{"native_state","not_assessed"},{"native_evaluation_completed",false}};
 }
 struct Bound {mpq_class value,lambda;};
 Bound dual_bound(const Table& tab,const mpq_class& eta)const{
  auto rhs=bound_rhs(tab,eta);Vector weights;for(const auto& w:tab.upper)weights.push_back(w.get_d());double right=rhs.get_d();
  auto eval=[&](double lambda){double value=-lambda*right,weight=0;for(const auto& group:data.groups){int j=group.front();for(int k:group)if(data.costs[k]+lambda*weights[k]<data.costs[j]+lambda*weights[j])j=k;value+=data.costs[j]+lambda*weights[j];weight+=weights[j];}return std::make_pair(value,weight);};
  double lo=0,hi=1,pick=0,score=eval(0).first;
  for(int k=0;k<24&&eval(hi).second>right;++k)hi*=2;
  for(int k=0;k<32;++k){double middle=(lo+hi)/2;auto e=eval(middle);if(e.first>score){pick=middle;score=e.first;}if(e.second>right)lo=middle;else hi=middle;}
  mpq_class lambda(pick),lb=-lambda*rhs;
  for(const auto& group:data.groups){mpq_class best;bool first=true;for(int j:group){mpq_class v=mpq_class(data.costs[j])+lambda*tab.upper[j];if(first||v<best){best=v;first=false;}}lb+=best;}
  lb.canonicalize();return {lb,lambda};
 }
 Json statistics()const{return {{"preparation_seconds",preparation_seconds},{"MIP_seconds",mip_seconds},{"mip_subproblems_solved",mips},{"mip_pruned_by_safe_lb",cost_cuts.size()},
  {"raw_solver_candidates",raw_returned},{"rational_verified_returned",rational_returned},{"rational_verified_unique",generated.size()},{"no_LSS_calls_in_generator",true}};}
};
}
