#pragma once
#include "evaluation.hpp"
#include "mip.hpp"
#include "winf_product.hpp"
#include "transport_cuts.hpp"
#include "budget_ro.hpp"
#include "calibrated_budget.hpp"
#include "pool_model.hpp"
#include "entropic_model.hpp"
#include "r06_budget_model.hpp"
#include "polish_fft.hpp"
#include <map>
#include <complex>
#include <optional>
#include <set>

namespace s10 {
struct Options {
    double capacity;
    std::string capacity_text;
    std::uint32_t seed;
    double seconds;
    std::string local_phases;
    fs::path output;
    std::string search_flow = "ellipsoid_dominance";
    double ellipsoid_gamma = 2.4;
    double ellipsoid_slice = 5.;
};

class Search {
public:
    Search(const Instance& instance, Options options, double started);
    Json run();
    Json phase_records = Json::array();
    const Groups& quick_checks() const { return checks; }
    const std::vector<std::uint16_t>& screen_indices() const { return indices; }
private:
    struct Candidate {
        Selection selection;
        double cost;
        Certificate certificate;
        std::string source;
        double found_seconds;
        Json json() const;
    };
    struct HalfState {
        double cost;
        float p0, p1;
        std::vector<float> pdf;
        Selection selection;
    };

    const Instance& instance;
    Options options;
    double started, deadline;
    ExactOracle oracle;
    std::unique_ptr<WinfProduct> dro;
    std::unique_ptr<TransportCuts> transport;
    std::unique_ptr<BudgetRO> budget_ro;
    std::shared_ptr<CalibratedBudget> calibrated;
    std::unique_ptr<PoolModel> calibration_solver;
    std::unique_ptr<EntropicModel> entropic;
    std::unique_ptr<PoolModel> entropic_solver;
    ExactOracle& search_oracle() {return dro?*dro->oracle:oracle;}
    const Instance& search_data()const{return dro?dro->shifted:instance;}
    BinaryModel model;
    Groups checks;
    std::vector<std::uint16_t> indices;
    std::map<Selection, Candidate> pool;
    std::map<Selection, double> decisions, guide_cache;
    std::set<Selection> frontier_candidates;
    std::optional<Candidate> best;
    std::vector<Vector> guide_hist;
    std::vector<std::vector<std::complex<double>>> guide_fft;
    Vector guide_weight;
    Json events = Json::array(), matches = Json::array(), locals = Json::array();
    Json ellipsoid_history = Json::array();
    std::map<Selection,Certificate> infeasible_proofs;
    Json dominance_cuts = Json::array();
    bool recomputed = false;
    int models = 0;
    double model_seconds = 0, last_save = 0;

    double remaining() const { return deadline - now(); }
    Groups binary(const Vector& objective, const std::vector<LinearRow>& rows, double seconds, int count);
    Groups mip(const Vector& weights, double rhs, std::optional<double> vcap,
               int trust, const Selection& center, double seconds, int count);
    Selection minimum(const Vector& objective) const;
    Groups cost_order(const std::set<Selection>& selections) const;
    double accept(const Selection& selection, std::string source, const Certificate& certificate);
    double native_check(const Selection& selection, const std::string& source);
    std::pair<double, double> float_bounds(const Selection& selection, int bins);
    void init_frontier();
    void budget_initialization();
    void budget_search();
    void budget_proposal(const Selection&, const mpq_class&, const mpq_class&, const std::string&);
    void calibrated_initialization();
    void calibrated_search();
    std::string calibrated_assess(const Selection&,const mpq_class&,const mpq_class&,const std::string&);
    std::size_t calibrated_register(const Selection&,const mpq_class&,const mpq_class&,const std::string&);
    Groups calibrated_query(const mpq_class&,bool);
    void entropic_initialization();
    void entropic_search();
    std::size_t entropic_register(const Selection&,int,const mpq_class&,const std::string&);
    std::string entropic_assess(const Selection&,int,const mpq_class&,const std::string&);
    Groups entropic_query(int,const mpq_class&,bool);
    void block_search();
    void insurance_search();
    Json block_history = Json::array();
    void ellipsoid_search();
    void costfront_search();
    void dominance_search();
    Json run_impl();
    Json be_ro_run();
    void be_ro_save_fields(Json&);
    Json be_ro_log=Json::object();
    Json r07_run();
    Groups r07_budget_query(const mpq_class&,bool);
    void r07_budget_search();
    double r07_native(const Selection&,const std::string&,const std::string&);
    void r07_entropic();
    void r07_polish();
    void r07_save_fields(Json&);
    double r07_gate()const{return .99-r07_epsilon;}
    std::unique_ptr<PolishFFT> r07_fft;
    double r07_epsilon=.0015;
    std::vector<double> r07_completed_times;
    std::set<Selection> r07_attempted,r07_local_seen;
    Json r07=Json::object(),r07_calls=Json::array(),r07_private=Json::array(),r07_mips=Json::array(),r07_launches=Json::array();
    Json r06_run();
    Groups r06_budget_query(const mpq_class&,bool);
    void r06_budget_search();
    double r06_native(const Selection&,const std::string&,const std::string&);
    void r06_entropic();
    void r06_polish();
    void r06_save_fields(Json&);
    Json r06=Json::object(),r06_calls=Json::array(),r06_private=Json::array(),r06_mips=Json::array();
    Json r05_run();
    Groups r05_budget_query(const mpq_class&,bool);
    void r05_budget_search();
    double r05_native(const Selection&,const std::string&,const std::string&);
    void r05_entropic();
    void r05_polish();
    void r05_save_fields(Json&);
    Json r05=Json::object(),r05_calls=Json::array(),r05_private=Json::array(),r05_mips=Json::array();
    Json r04_run();
    void r04_polish();
    void r04_snapshot_parent();
    void r04_save_fields(Json&);
    Json r04 = Json::object(), polish_history=Json::array(),polish_proposals=Json::array(),polish_mips=Json::array();
    std::map<Selection,std::size_t> polish_index;
    void local_search(double seconds);
    void matching(double delta, const Selection& left, const Selection& right);
    std::vector<HalfState> build_half(const Selection& groups, const Selection& other,
                                    const std::vector<std::vector<float>>& hist);
    std::vector<HalfState> prune(std::vector<HalfState> states) const;
    std::vector<Vector> histograms(int bins, double delta) const;
    std::pair<double, Vector> gradients(const Selection& selection);
    double guide_probability(const Selection& selection);
    Json shortlist() const;
    Json save(const std::string& status);
    void final_check();
};
} // namespace s10
