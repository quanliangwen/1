#include "search.hpp"
#include "isolated_native.hpp"
#include <numeric>
namespace s10 {
double Search::r07_native(const Selection&s,const std::string&source,const std::string&stage){
 if(pool.count(s))return pool.at(s).certificate.probability();
 if(r07_attempted.count(s)||decisions.count(s))return decisions.count(s)?decisions.at(s):0;
 check_budget();const double begin=now();if(begin>=deadline||deadline-begin<.01)throw BudgetExpired();
 const double private_p=r07_fft->probability(s);std::vector<double> times=r07_completed_times;std::sort(times.begin(),times.end());
 double med=2.;if(times.size()>=3)med=times.size()%2?times[times.size()/2]:(times[times.size()/2-1]+times[times.size()/2])/2;
 const double allowance=std::min(deadline-begin,std::max(15.,std::min(35.,10*med))),end=begin+allowance;
 Json q={{"selection",s},{"source",source},{"stage",stage},{"start",begin-started},{"cost",instance.cost_of(s)},
  {"best_cost_before",best?Json(best->cost):Json(nullptr)},{"best_selection_before",best?Json(best->selection):Json(nullptr)},
  {"private_probability",private_p},{"epsilon_before",r07_epsilon},{"completed_calls_before",times.size()},{"median_before",med},
  {"tau_call",allowance},{"slice_deadline",end-started},{"search_deadline",deadline-started},{"fresh",true}};
 r07_attempted.insert(s);const int oldcalls=oracle.calls;const double oldseconds=oracle.seconds;
 auto result=isolated_native(end,[&](){
  phase_deadline=end;last_save=now()+1e9; // disable child-side periodic snapshots
  bool expired=false;double value=0;try{value=native_check(s,source);}catch(const BudgetExpired&){expired=true;}
  Json z={{"value",value},{"expired",expired},{"calls_delta",oracle.calls-oldcalls},{"seconds_delta",oracle.seconds-oldseconds},
   {"state",pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown"}};
  if(pool.count(s))z["certificate"]=pool.at(s).certificate.json(s);
  else if(infeasible_proofs.count(s))z["certificate"]=infeasible_proofs.at(s).json(s);
  return z;
 });
 q["hard_timeout"]=result.timeout;q["isolated_elapsed"]=result.elapsed;q["state"]="unknown";q["expired"]=result.timeout;
 double value=0;
 if(!result.timeout){
  const auto& z=result.payload;q["state"]=z["state"];q["expired"]=z["expired"];
  oracle.calls+=z["calls_delta"].get<int>();oracle.seconds+=z["seconds_delta"].get<double>();
  if(!z["expired"].get<bool>())r07_completed_times.push_back(result.elapsed);
  if(z.contains("certificate")){
   auto c=z["certificate"];Certificate cert{mpz_class(c["lower_numerator"].get<std::string>()),mpz_class(c["upper_numerator"].get<std::string>()),mpz_class(c["denominator"].get<std::string>()),c["bins"].get<int>(),c["certificate_seconds"].get<double>()};
   q["certificate"]=c;
   if(z["state"]=="accepted"){value=accept(s,source,cert);r07_epsilon=std::max(r07_epsilon,std::max(.001,.99-private_p));}
   else if(z["state"]=="infeasible"){infeasible_proofs.insert_or_assign(s,cert);value=decisions[s]=cert.probability();}
  }
 }
 if(result.timeout||q["expired"].get<bool>())r07["watchdog_timeouts"]=r07.value("watchdog_timeouts",0)+1;
 const double used=now()-begin;q["elapsed"]=used;q["finish"]=now()-started;q["epsilon_after"]=r07_epsilon;
 q["best_cost_after"]=best?Json(best->cost):Json(nullptr);r07_calls.push_back(q);
 r07["timing"][stage]=r07["timing"].value(stage,0.)+used;
 return value;
}

Json Search::r07_run(){
 r07={{"model","R07_state_adaptive_dual_surrogate_empirical_chance_hybrid"},{"historical_solution_inputs",false},{"generator_LSS_calls",0},
  {"private_cache_isolated",true},{"private_FFT_is_certificate",false},{"nearest_rounding_is_unbiased_claim",false},{"precision_damping",12},
  {"watchdog_timeouts",0},{"timing",Json::object()},{"parent_pool",Json::array()}};
 for(const char*k:{"load_and_model","stage1_es95_mip","stage1_es95_cdf","stage2_entropic_mip_fft","stage2_entropic_cdf","stage3a_12opt","stage3a_cdf","stage3b_local_mckp_mip","stage3b_cdf","stage4_fallback_mip","stage4_cdf","final_lss","save_and_fsync","unaccounted_overhead"})r07["timing"][k]=0.;
 r07_fft=std::make_unique<PolishFFT>(instance.samples,instance.groups,options.capacity);r07["timing"]["load_and_model"]=now()-started;
 try{
  if(!calibrated->mean_infeasible&&calibrated->gamma_max>0){
   auto i=calibrated_register(calibrated->initial,calibrated->gamma_max,calibrated->initial_theta,"R02_self_generated_gamma_max_anchor");
   r07_native(calibrated->initial,"R02_self_generated_gamma_max_anchor","stage1_es95_cdf");
   calibrated->proposals[i]["native_state"]=pool.count(calibrated->initial)?"accepted":infeasible_proofs.count(calibrated->initial)?"infeasible":"unknown";
  }
  phase_records.push_back({{"phase","initialization"},{"own_raw_sample_initialization",true},{"best_before",nullptr},{"best_after",best?Json(best->cost):Json(nullptr)},{"elapsed",now()-started},{"candidates_added",pool.size()}});
  r07_budget_search();
 }catch(const BudgetExpired&){r07["es95_partial"]=true;}
 if(phase_records.empty())phase_records.push_back({{"phase","initialization"},{"own_raw_sample_initialization",true},{"best_before",nullptr},{"best_after",best?Json(best->cost):Json(nullptr)},{"elapsed",now()-started},{"candidates_added",pool.size()}});
 r07["es95_only_best_cost"]=best?Json(best->cost):Json(nullptr);r07["timing"]["stage1_es95_mip"]=calibrated->solver_seconds;r07["ES95_finished_seconds"]=now()-started;
 for(auto&q:calibrated->proposals){auto s=q["selection"].get<Selection>();q["native_state"]=pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown";q["native_evaluation_completed"]=pool.count(s)||infeasible_proofs.count(s);}
 r07["ES95_pool"]=Json::array();for(const auto&q:pool)r07["ES95_pool"].push_back(q.second.json());
 const double eb=now(),ec=r07["timing"]["stage2_entropic_cdf"].get<double>();
 try{r07_entropic();}catch(const BudgetExpired&){r07["entropic_partial"]=true;}
 r07["timing"]["stage2_entropic_mip_fft"]=now()-eb-(r07["timing"]["stage2_entropic_cdf"].get<double>()-ec);
 r07["mother_only_best_cost"]=best?Json(best->cost):Json(nullptr);r07["mother_finished_seconds"]=now()-started;
 for(const auto&q:pool)r07["parent_pool"].push_back(q.second.json());
 try{r07_polish();}catch(const BudgetExpired&){r07["polish_partial"]=true;r07["polish_stop_reason"]="global_search_deadline";}
 // No unguarded redundant recount: complete native certificates are immutable.
 return save("completed");
}

void Search::r07_entropic(){
 check_budget();auto&e=*entropic;e.eta_floor=mpq_class(3,5);e.metadata["eta_floor"]=e.eta_floor.get_str();
 Selection ref=best?best->selection:minimum(instance.mean);double variance=0;for(int j:ref)variance+=instance.variance[j];double sigma=std::sqrt(std::max(0.,variance));
 r07["sigma_ref_used"]=sigma;r07["sigma_reference_selection"]=ref;e.tilts.clear();r07["entropic_t_values_used"]=Json::array();r07["entropic_t_exact"]=Json::array();
 for(double c:{2.,1.,.5,3.}){double t=sigma>0?std::max(.001,std::min(50.,c/sigma)):50.;e.tilts.push_back(mpq_class(t));r07["entropic_t_values_used"].push_back(t);r07["entropic_t_exact"].push_back(e.tilts.back().get_str());}
 for(int k=0;k<4;++k){
  check_budget();const auto&tab=e.prepare(k);mpq_class lo(3,5),hi=std::min(tab.eta_max,mpq_class(921,200)),span=hi-lo;if(hi<lo)continue;
  std::set<Selection> all;
  auto query=[&](const mpq_class&eta,bool fine){
   check_budget();Vector weights;for(const auto&w:tab.upper)weights.push_back(BudgetRO::outward(w,true));auto rhs=e.bound_rhs(tab,eta);
   std::vector<LinearRow> rows{{weights,-INFINITY,BudgetRO::outward(rhs,false)}};
   if(fine&&best)rows.push_back({instance.costs,-INFINITY,BudgetRO::outward(e.exact_cost(best->selection)-mpq_class(1,1000000),false)});
   const double b=now();r07_launches.push_back({{"stage","stage2_entropic"},{"kind","MIP"},{"start",b-started}});Json log;
   auto found=entropic_solver->solve(instance.costs,rows,std::max(.001,std::min(2.,remaining())),fine?15:1,.02,log);e.mip_seconds+=now()-b;++e.mips;
   Json q={{"table_index",k},{"eta",eta.get_str()},{"private_only_localization",!fine},{"solver",log},{"returned",Json::array()}};Groups good;
   for(const auto&s:found){check_budget();auto w=e.witness(s,k,eta,"R07_entropic_model");if(!w["entropic_upper_feasible"].get<bool>())continue;
    auto i=entropic_register(s,k,eta,"R07_entropic_model");double p=r07_fft->probability(s);q["returned"].push_back({{"record_index",i},{"private_probability",p}});good.push_back(s);if(fine)all.insert(s);
    r07_private.push_back({{"selection",s},{"probability",p},{"stage","entropic"},{"table",k},{"record_index",i}});
   }e.queries.push_back(q);return good;
  };
  while(span>0&&(hi-lo)/span>mpq_class(1,100)){
   auto mid=mpq_class((lo+hi)/2);auto found=query(mid,false);if(found.empty())break;
   auto s=*std::min_element(found.begin(),found.end(),[&](const Selection&a,const Selection&b){return std::make_pair(instance.cost_of(a),a)<std::make_pair(instance.cost_of(b),b);});
   if(r07_fft->probability(s)>=r07_gate())hi=mid;else lo=mid;
  }
  e.metadata["R07_eta_brackets"].push_back({{"table_index",k},{"lo",lo.get_str()},{"hi",hi.get_str()},{"initial_span",span.get_str()}});
  std::set<mpq_class> fine{hi,std::max(e.eta_floor,mpq_class(hi-(hi-lo)))};for(const auto&eta:fine)query(eta,true);
  for(const auto&s:cost_order(all)){check_budget();if(r07_attempted.count(s)||pool.count(s))continue;if(best&&e.exact_cost(s)>e.exact_cost(best->selection)-mpq_class(1,1000000))continue;
   if(r07_fft->probability(s)<r07_gate())continue;r07_native(s,"R07_entropic","stage2_entropic_cdf");auto i=e.records.at(s);e.proposals[i]["native_state"]=pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown";e.proposals[i]["native_evaluation_completed"]=pool.count(s)||infeasible_proofs.count(s);
  }
 }
}
void Search::r07_save_fields(Json&data){
 if(options.search_flow!="adaptive_dual_gated")return;
 r07["certified_pool"]=Json::array();std::set<Selection> keys;for(const auto&q:pool){keys.insert(q.first);r07["certified_pool"].push_back(q.second.json());}
 r07["low_cost_certified_ladder_top5"]=Json::array();for(const auto&s:cost_order(keys)){if(r07["low_cost_certified_ladder_top5"].size()==5)break;r07["low_cost_certified_ladder_top5"].push_back(pool.at(s).json());}
 r07["epsilon_fft_final"]=r07_epsilon;r07["completed_native_times"]=r07_completed_times;r07["final_best_internal_cost"]=best?Json(best->cost):Json(nullptr);
 data["config"]["LSS_reserve_seconds"]=std::min(120.,options.seconds*.3);data["R07_model"]=r07;data["r07_native_calls"]=r07_calls;data["r07_private_history"]=r07_private;data["r07_local_MIP"]=r07_mips;data["r07_MIP_launches"]=r07_launches;data["r07_timing_breakdown_sec"]=r07["timing"];
}
}
