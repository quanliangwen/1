#pragma once
#include "ellipsoid.hpp"
namespace s10 {
// This constraint restricts proposals, never certifies the LSS chance constraint.
class RiskDominanceMaster {
public:
    RiskDominanceMaster(const Instance&, int seed, double gamma, const Selection& own_start, bool cost_primary = false, const std::string& necessary_mean_capacity = "");
    ~RiskDominanceMaster();
    void set_cost_bound(double bound);
    bool exclude_processed(const Selection&);
    bool add_dominance_cut(const Groups& worse_sets);
    bool add_core_cut(const Groups& worse_sets, const Selection& core_groups);
    int core_cut_count() const;
    int dominance_cut_count() const;
    Json necessary_mean_bound_specification() const;
    EllipsoidQuery next_candidate(double seconds);
private:
    struct Impl;
    std::unique_ptr<Impl> impl;
};
}
