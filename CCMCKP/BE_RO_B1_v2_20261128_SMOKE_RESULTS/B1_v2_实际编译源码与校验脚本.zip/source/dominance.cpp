#include "dominance.hpp"
#include <algorithm>
namespace s10 {
DominanceTable::DominanceTable(const Instance& instance):data(instance),sets(instance.n()) {
    std::vector<std::vector<mpq_class>> ordered(data.n());
    for(int j=0;j<data.n();++j) {
        check_budget();
        for(const auto& value:data.decimals[j])ordered[j].push_back(rational_decimal(value));
        std::sort(ordered[j].begin(),ordered[j].end());
    }
    for(const auto& group:data.groups)for(int anchor:group) {
        check_budget();
        for(int j:group) {
            bool larger=true;
            for(int k=0;k<data.sample_count;++k)if(ordered[j][k]<ordered[anchor][k]){larger=false;break;}
            if(larger)sets[anchor].push_back(j);
        }
        if(std::find(sets[anchor].begin(),sets[anchor].end(),anchor)==sets[anchor].end())
            throw std::logic_error("Empirical dominance lost reflexivity");
    }
}
Groups DominanceTable::worse_sets(const Selection& selection) const {
    data.validate(selection);Groups out;
    for(int j:selection)out.push_back(sets[j]);
    return out;
}
}
