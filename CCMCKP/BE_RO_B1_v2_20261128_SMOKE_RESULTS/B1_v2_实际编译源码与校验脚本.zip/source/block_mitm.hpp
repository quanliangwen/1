#pragma once
#include "fft.hpp"
#include <numeric>
// Reference/system BLAS is single threaded; controller also pins thread envs.
extern "C" void dgemm_(const char*,const char*,const int*,const int*,const int*,const double*,const double*,const int*,const double*,const int*,const double*,double*,const int*);
namespace s10 {
struct BlockHalf {Selection items;double cost;Vector pdf;};
struct BlockPair {int left,right;double probability,cost;};
inline std::vector<BlockHalf> block_half(const Instance& d,const Selection& groups,const std::vector<Vector>& hist) {
    Vector unit(hist.front().size());unit[0]=1;
    std::vector<BlockHalf> out{{{},0,unit}};
    for(int g:groups) {
        std::vector<BlockHalf> next;
        for(const auto& a:out)for(int j:d.groups[g]) {
            check_budget();auto items=a.items;items.push_back(j);
            next.push_back({std::move(items),a.cost+d.costs[j],groups.size()==1?hist[j]:convolve(a.pdf,hist[j])});
        }
        out=std::move(next);
    }
    return out;
}
inline std::vector<BlockPair> block_scores(const std::vector<BlockHalf>& a,const std::vector<BlockHalf>& b,const Vector& outside) {
    int na=a.size(),nb=b.size(),k=outside.size();
    Vector left(na*k),right(nb*k),scores(na*nb);
    for(int i=0;i<na;++i)for(int t=0;t<k;++t)left[i+t*na]=a[i].pdf[t];
    for(int j=0;j<nb;++j) {
        auto row=convolve(outside,b[j].pdf);double cdf=0;
        for(int t=0;t<k;++t) {cdf+=row[t];right[k-1-t+j*k]=cdf;}
    }
    const char n='N';const double one=1,zero=0;
    check_budget();dgemm_(&n,&n,&na,&nb,&k,&one,left.data(),&na,right.data(),&k,&zero,scores.data(),&na);check_budget();
    std::vector<BlockPair> out;
    for(int j=0;j<nb;++j)for(int i=0;i<na;++i)out.push_back({i,j,scores[i+j*na],a[i].cost+b[j].cost});
    return out;
}
}
