#include "search.hpp"
#include "polish_fft.hpp"
#include <numeric>
namespace s10 {
namespace {
int group_distance(const Selection&a,const Selection&b){int k=0;for(std::size_t g=0;g<a.size();++g)k+=a[g]!=b[g];return k;}
}
void Search::r04_snapshot_parent(){
 Json parent=Json::array();double maximum=0;
 for(const auto& q:pool){parent.push_back(q.second.json());maximum=std::max(maximum,q.second.certificate.probability());}
 // A completed CDF result can precede an interrupted periodic save. Recover
 // bookkeeping only from its complete certificate, never from a partial FFT.
 for(auto& p:calibrated->proposals){auto s=p["selection"].get<Selection>();
  if(pool.count(s)){p["native_state"]="accepted";p["native_evaluation_completed"]=true;}
  else if(infeasible_proofs.count(s)){p["native_state"]="infeasible";p["native_evaluation_completed"]=true;}
 }
 r04["parent_pool"]=parent;r04["parent_best_cost"]=best?Json(best->cost):Json(nullptr);
 r04["parent_max_native_probability"]=pool.empty()?Json(nullptr):Json(maximum);
 r04["parent_snapshot_seconds"]=now()-started;
}
Json Search::r04_run(){
 const double full_deadline=deadline,full_phase=phase_deadline;
 const double parent_allowance=std::min(120.,(full_deadline-started)*.28);
 r04={{"model","R04_budget_RO_guided_empirical_chance_polish"},{"parent","R02_empirical_ES95_calibrated_budget_RO"},
  {"historical_solution_inputs",false},{"external_MIPstarts",false},{"generator_LSS_calls",0},
  {"polish_preserves_parent_RO_guarantee",false},{"FFT_is_probability_certificate",false},
  {"parent_absolute_allowance_seconds",parent_allowance},{"proposal_slice_cap_seconds",60},
  {"native_CDF_reserve_fraction",.44},{"private_bins",8192},{"damping",12},
  {"repair_buffer",.0002},{"borderline_native_gate",.9895},{"max_seeds",6},{"rounds",3},
  {"one_opt_steps_per_round",6},{"cheap_moves",20},{"safety_moves",25},{"pair_scores",40},
  {"trust_group_radius",5},{"trust_binary_Hamming_radius",10},{"trust_risk_slack",.0002},
  {"trust_PoolSolutions",10},{"trust_MIP_seconds",2},{"max_new_native_checks",24},
  {"private_score_cache_not_original_guide_cache",true},{"seeds",Json::array()}};
 const double initial_begin=now();const std::size_t initial_pool=pool.size();
 deadline=std::min(full_deadline,started+parent_allowance);phase_deadline=std::min(full_phase,deadline);
 bool interrupted=false;
 try{calibrated_initialization();}catch(const BudgetExpired&){interrupted=true;}
 phase_records.push_back({{"phase","initialization"},{"own_raw_sample_initialization",true},{"elapsed",now()-initial_begin},
  {"best_before",nullptr},{"best_after",best?Json(best->cost):Json(nullptr)},{"candidates_added",pool.size()-initial_pool},{"slice_expired",interrupted}});
 const double search_begin=now();auto prior=best?Json(best->cost):Json(nullptr);const auto count=pool.size();
 if(!interrupted)try{calibrated_search();}catch(const BudgetExpired&){interrupted=true;}
 phase_records.push_back({{"phase","R02_parent_fixed_slice"},{"elapsed",now()-search_begin},{"best_before",prior},
  {"best_after",best?Json(best->cost):Json(nullptr)},{"candidates_added",pool.size()-count},{"slice_expired",interrupted},{"LSS_calls",0}});
 deadline=full_deadline;phase_deadline=full_phase;r04["parent_slice_expired"]=interrupted;r04_snapshot_parent();
 const double polish_begin=now();prior=best?Json(best->cost):Json(nullptr);const auto parent_count=pool.size();
 try{r04_polish();}catch(const BudgetExpired&){r04["native_adjudication_slice_expired"]=true;}
 phase_deadline=full_phase;deadline=full_deadline;r04["polish_whole_seconds"]=now()-polish_begin;
 phase_records.push_back({{"phase","R04_private_FFT_and_original_CDF"},{"elapsed",now()-polish_begin},{"best_before",prior},
  {"best_after",best?Json(best->cost):Json(nullptr)},{"candidates_added",pool.size()-parent_count},{"LSS_calls",0}});
 if(best&&remaining()>2)final_check();return save("completed");
}
void Search::r04_polish(){
 auto& c=*calibrated;const double original_phase=phase_deadline,begin=now();
 // Bound proposal work separately, leaving time for original integer CDF.
 const double reserve=(deadline-started)*.44;
 phase_deadline=std::min(original_phase-reserve,begin+60);
 std::unique_ptr<PolishFFT> fft;
 struct Seed{Selection current;std::size_t parent;};std::vector<Seed> seeds;
 std::set<Selection> visited;
 auto exact_cost=[&](const Selection& s){return c.exact_cost(s);};
 auto append=[&](const Selection& anchor,const Selection& s,double probability,const char* action,std::size_t seed,Json extra=Json::object()){
  instance.validate(s);instance.validate(anchor);
  Json log={{"anchor",anchor},{"selection",s},{"seed_index",seed},{"action",action},
   {"approx_probability",probability},{"cost",instance.cost_of(s)},{"group_distance",group_distance(anchor,s)},
   {"elapsed",now()-started},{"FFT_is_certificate",false},{"extra",extra}};
  auto hi=polish_history.size();polish_history.push_back(log);
  if(probability>=.9895&&!polish_index.count(s)){
   auto index=polish_proposals.size();polish_index[s]=index;
   polish_proposals.push_back({{"selection",s},{"history_index",hi},{"seed_index",seed},{"source","R04_"+std::string(action)},
    {"approx_probability",probability},{"native_state","not_assessed"},{"native_evaluation_completed",false},
    {"not_a_budget_RO_certificate",true},{"own_run_RO_seed",true}});
  }
  return hi;
 };
 try{
  check_budget();fft=std::make_unique<PolishFFT>(instance.samples,instance.groups,options.capacity);
  auto all=cost_order(c.generated);std::set<Selection> deck;
  for(std::size_t i=0;i<std::min<std::size_t>(16,all.size());++i)deck.insert(all[i]);
  if(!all.empty())for(int k=0;k<32;++k)deck.insert(all[std::size_t(k)*(all.size()-1)/31]);
  int added=0;for(const auto& s:cost_order([&]{std::set<Selection> p;for(const auto&q:pool)p.insert(q.first);return p;}())){if(added++==8)break;deck.insert(s);}
  struct Rated{Selection selection;double p,cost;};std::vector<Rated> ranked;
  for(const auto& s:deck){check_budget();ranked.push_back({s,fft->probability(s),instance.cost_of(s)});}
  std::stable_sort(ranked.begin(),ranked.end(),[](const Rated&a,const Rated&b){return std::make_tuple(std::abs(a.p-.99),a.cost,a.selection)<std::make_tuple(std::abs(b.p-.99),b.cost,b.selection);});
  // A cheap already-certified seed plus near-boundary same-run RO vectors.
  if(best){seeds.push_back({best->selection,c.record_index.at(best->selection)});visited.insert(best->selection);}
  for(const auto& s:ranked)if(seeds.size()<6&&visited.insert(s.selection).second)seeds.push_back({s.selection,c.record_index.at(s.selection)});
  for(const auto& seed:seeds)r04["seeds"].push_back({{"selection",seed.current},{"parent_proposal_index",seed.parent},{"source","current_run_R02_model"}});
  for(int round=0;round<3;++round)for(std::size_t si=0;si<seeds.size();++si){
   auto& x=seeds[si].current;check_budget();
   for(int step=0;step<6;++step){
    const auto [p,values]=fft->marginals(x);struct Move{int g,j;double dp,dc,prob;};std::vector<Move> moves;
    for(int g=0;g<instance.m();++g)for(int j:instance.groups[g])if(j!=x[g])moves.push_back({g,j,values[j]-p,instance.costs[j]-instance.costs[x[g]],values[j]});
    auto cheap=moves;std::stable_sort(cheap.begin(),cheap.end(),[](const Move&a,const Move&b){return std::tie(a.dc,a.g,a.j)<std::tie(b.dc,b.g,b.j);});
    int border=0;for(const auto& mv:cheap)if(mv.dc< -1e-8&&mv.prob>=.9895&&border<8){auto y=x;y[mv.g]=mv.j;append(x,y,mv.prob,"one_borderline",si);++border;}
    std::optional<Move> chosen;
    if(p<.9902){
     double score=-1;for(const auto& mv:moves)if(mv.dp>1e-9){auto y=x;y[mv.g]=mv.j;if(visited.count(y))continue;double rate=mv.dp/std::max(.01,mv.dc);
      if(rate>score){score=rate;chosen=mv;}}
    }else for(const auto& mv:cheap)if(mv.dc< -1e-8&&mv.prob>=.9902){auto y=x;y[mv.g]=mv.j;if(!visited.count(y)){chosen=mv;break;}}
    if(!chosen)break;auto y=x;y[chosen->g]=chosen->j;append(x,y,chosen->prob,p<.9902?"one_repair":"one_descent",si);visited.insert(y);x=y;
   }
   const auto [p,values]=fft->marginals(x);
   struct Move{int g,j;double dp,dc;};std::vector<Move> cheaper,safer;
   for(int g=0;g<instance.m();++g)for(int j:instance.groups[g])if(j!=x[g]){
    Move mv{g,j,values[j]-p,instance.costs[j]-instance.costs[x[g]]};
    if(mv.dc< -1e-8&&values[j]>=.94)cheaper.push_back(mv);if(mv.dp>1e-4)safer.push_back(mv);
   }
   std::stable_sort(cheaper.begin(),cheaper.end(),[](const Move&a,const Move&b){return std::tie(a.dc,a.g,a.j)<std::tie(b.dc,b.g,b.j);});
   std::stable_sort(safer.begin(),safer.end(),[](const Move&a,const Move&b){return std::make_tuple(a.dc/a.dp,a.g,a.j)<std::make_tuple(b.dc/b.dp,b.g,b.j);});
   if(cheaper.size()>20)cheaper.resize(20);if(safer.size()>25)safer.resize(25);
   struct Pair{Move a,b;};std::vector<Pair> pairs;
   for(const auto&a:cheaper)for(const auto&b:safer)if(a.g!=b.g&&a.dc+b.dc< -1e-8&&p+a.dp+b.dp>=.975)pairs.push_back({a,b});
   std::stable_sort(pairs.begin(),pairs.end(),[](const Pair&a,const Pair&b){return std::make_tuple(a.a.dc+a.b.dc,a.a.g,a.a.j,a.b.g,a.b.j)<std::make_tuple(b.a.dc+b.b.dc,b.a.g,b.a.j,b.b.g,b.b.j);});
   bool improved=false;int checked=0;
   for(const auto& pair:pairs){if(checked++>=40)break;check_budget();auto y=x;y[pair.a.g]=pair.a.j;y[pair.b.g]=pair.b.j;if(visited.count(y))continue;
    double py=fft->probability(y);append(x,y,py,"two_proposal",si);
    if(py>=.9902&&exact_cost(y)<exact_cost(x)){visited.insert(y);x=y;improved=true;break;}
   }
   if(improved)continue;
   Vector risk(instance.n());for(int j=0;j<instance.n();++j)risk[j]=p-values[j];
   Vector trust(instance.n());for(int j:x)trust[j]=1;
   auto cap=exact_cost(x);std::vector<LinearRow> rows{{risk,-std::numeric_limits<double>::infinity(),p-.99+.0002},
    {trust,double(instance.m()-std::min(5,instance.m())),std::numeric_limits<double>::infinity()},
    {instance.costs,-std::numeric_limits<double>::infinity(),BudgetRO::outward(cap,true)}};
   Json excluded=Json::array();for(const auto& q:infeasible_proofs){Vector row(instance.n());for(int j:q.first)row[j]=1;rows.push_back({row,-std::numeric_limits<double>::infinity(),double(instance.m()-1)});excluded.push_back(q.first);}
   Json task;const double qb=now();auto out=calibration_solver->solve(instance.costs,rows,std::min(2.,budget_left()-.1),10,.02,task);
   task["anchor"]=x;task["seed_index"]=si;task["round"]=round;task["risk"]=risk;task["risk_rhs"]=p-.99+.0002;
   task["anchor_approx_probability"]=p;task["group_radius"]=std::min(5,instance.m());task["exact_anchor_cost"]=cap.get_str();
   task["excluded_complete_native_rejections"]=excluded;task["heuristic_linearization_not_valid_chance_cut"]=true;task["seconds"]=now()-qb;task["returned"]=Json::array();
   task["raw_returned"]=out.size();task["complete"]=false;
   const std::size_t task_index=polish_mips.size();polish_mips.push_back(task);std::optional<Selection> preferred;double preferred_cost=std::numeric_limits<double>::infinity();
   for(const auto& y:out){check_budget();double lhs=0;for(int j:y)lhs+=risk[j];
    if(group_distance(x,y)>std::min(5,instance.m())||!(exact_cost(y)<cap)||lhs>p-.99+.0002+1e-7)continue;
    double py=fft->probability(y);auto hi=append(x,y,py,"trust_MCKP",si,{{"MIP_index",task_index}});polish_mips[task_index]["returned"].push_back(hi);
    if(py>=.9902&&!visited.count(y)&&instance.cost_of(y)<preferred_cost){preferred=y;preferred_cost=instance.cost_of(y);}
   }
   polish_mips[task_index]["complete"]=true;if(preferred){visited.insert(*preferred);x=*preferred;}
  }
 }catch(const BudgetExpired&){r04["private_proposal_slice_expired"]=true;}
 phase_deadline=original_phase;
 r04["proposal_seconds"]=now()-begin;
 if(fft){r04["private_FFT_seconds"]=fft->seconds;r04["private_FFT_scores"]=fft->scores;r04["private_marginal_tables"]=fft->marginal_tables;}
 std::vector<std::size_t> ordered;for(std::size_t i=0;i<polish_proposals.size();++i){const auto s=polish_proposals[i]["selection"].get<Selection>();
  if(!best||instance.cost_of(s)<=best->cost*1.02+1e-8)ordered.push_back(i);
 }
 std::stable_sort(ordered.begin(),ordered.end(),[&](std::size_t a,std::size_t b){auto x=polish_proposals[a]["selection"].get<Selection>(),y=polish_proposals[b]["selection"].get<Selection>();return std::make_tuple(instance.cost_of(x),x)<std::make_tuple(instance.cost_of(y),y);});
 std::vector<std::size_t> queue;std::set<std::size_t> kept;
 auto enqueue=[&](std::size_t i){if(kept.insert(i).second)queue.push_back(i);};
 if(!ordered.empty())enqueue(ordered.front());
 for(double level:{.9902,.9905,.991,.992,.995})for(auto i:ordered)if(polish_proposals[i]["approx_probability"].get<double>()>=level){enqueue(i);break;}
 for(auto i:ordered)enqueue(i);
 r04["native_queue"]=queue;int new_checks=0;r04["new_native_queries"]=0;
 for(auto i:queue){if(remaining()<8||new_checks>=24)break;auto& p=polish_proposals[i];auto s=p["selection"].get<Selection>();
  bool fresh=!pool.count(s)&&!decisions.count(s);if(fresh)++new_checks;r04["new_native_queries"]=new_checks;
  native_check(s,p["source"].get<std::string>());
  p["native_state"]=pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown";
  p["native_evaluation_completed"]=true;p["native_finished_seconds"]=now()-started;
 }
 r04["new_native_queries"]=new_checks;
}
void Search::r04_save_fields(Json& data){
 if(options.search_flow!="cvar_budget_polish")return;
 std::size_t polished=0;Json best_cost=nullptr;
 for(auto& p:polish_proposals){auto s=p["selection"].get<Selection>();
  if(pool.count(s)){p["native_state"]="accepted";p["native_evaluation_completed"]=true;p["native_certificate"]=pool.at(s).certificate.json(s);p["native_found_seconds"]=pool.at(s).found_seconds;}
  else if(infeasible_proofs.count(s)){p["native_state"]="infeasible";p["native_evaluation_completed"]=true;p["native_certificate"]=infeasible_proofs.at(s).json(s);}
 }
 for(const auto& q:pool)if(q.second.source.rfind("R04_",0)==0){++polished;if(best_cost.is_null()||q.second.cost<best_cost.get<double>())best_cost=q.second.cost;}
 data["R04_model"]=r04;data["polish_history"]=polish_history;data["polish_proposals"]=polish_proposals;data["polish_MIP_queries"]=polish_mips;
 data["stage3_internal_cdf_and_polish"]={{"ro_passed_native_cdf_count",r04.contains("parent_pool")?r04["parent_pool"].size():pool.size()},
  {"best_ro_native_cdf_cost",r04.value("parent_best_cost",Json(nullptr))},{"max_ro_native_cdf_prob",r04.value("parent_max_native_probability",Json(nullptr))},
  {"polish_seeds_used",r04.value("seeds",Json::array()).size()},{"polish_seconds",r04.value("polish_whole_seconds",0.)},
  {"post_polish_passed_native_cdf_count",polished},{"best_post_polish_native_cdf_cost",best_cost}};
}
}
