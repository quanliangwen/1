#pragma once
#include "model.hpp"
#include <algorithm>
#include <numeric>
#include <set>
namespace s10 {
// Fixed engineering policy: 24 pairs, 16 triples, 12 quadruples per anchor.
// Pareto-saving/risk-repair moves only rank groups; no option is deleted.
inline Groups block_schedule(const Instance& d,const Selection& anchor,const Vector& gradient) {
    int m=d.m();Vector saving(m),repair(m);
    for(int g=0;g<m;++g)for(int j:d.groups[g]) {
        double dc=d.costs[j]-d.costs[anchor[g]],dp=gradient[j]-gradient[anchor[g]];bool dominated=false;
        for(int h:d.groups[g])if(d.costs[h]-d.costs[anchor[g]]<=dc && gradient[h]-gradient[anchor[g]]>=dp && (d.costs[h]<d.costs[j]||gradient[h]>gradient[j]))dominated=true;
        if(!dominated){saving[g]=std::max(saving[g],-dc);repair[g]=std::max(repair[g],dp);}
    }
    Selection cheap(m),safe(m);std::iota(cheap.begin(),cheap.end(),0);safe=cheap;
    std::stable_sort(cheap.begin(),cheap.end(),[&](int a,int b){return saving[a]>saving[b];});
    std::stable_sort(safe.begin(),safe.end(),[&](int a,int b){return repair[a]>repair[b];});
    Groups result;std::set<Selection> seen;
    const auto add=[&](Selection s,int size,int& used,int quota){std::sort(s.begin(),s.end());s.erase(std::unique(s.begin(),s.end()),s.end());if(int(s.size())==size&&used<quota&&seen.insert(s).second){result.push_back(s);++used;}};
    for(int size=2;size<=4;++size) {
        int used=0,quota=size==2?24:size==3?16:12;
        for(int depth=0;depth<m && used<quota;++depth)for(int r=0;r<std::min(m,6)&&used<quota;++r) {
            Selection s{cheap[depth],safe[r]};
            for(int z=1;int(s.size())<size&&z<=m;++z) {
                int candidate=(z%2)?cheap[(depth+(z+1)/2)%m]:safe[(r+z/2)%m];
                if(std::find(s.begin(),s.end(),candidate)==s.end())s.push_back(candidate);
            }
            add(s,size,used,quota);
        }
    }
    return result;
}
}
