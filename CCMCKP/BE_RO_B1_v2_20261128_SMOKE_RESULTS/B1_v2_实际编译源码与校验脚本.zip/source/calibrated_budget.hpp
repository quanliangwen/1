#pragma once
#include "budget_ro.hpp"
#include <map>

namespace s10 {
// Empirical ES95-based RO proxy. Neither Gamma localization nor the proxy
// uncertainty set is a population probability guarantee.
class CalibratedBudget : public BudgetRO {
public:
    std::vector<mpq_class> min_sums;
    Groups min_choices;
    std::vector<std::size_t> coarse;
    mpq_class gamma_max=0, gamma_floor=mpq_class(1,20);
    Selection initial;
    mpq_class initial_theta=0;
    bool mean_infeasible=false;
    Json queries=Json::array(), cost_cuts=Json::array();
    Json incumbents=Json::array();
    std::set<Selection> incumbent_recorded;
    std::map<Selection,std::size_t> record_index;
    int raw_returned=0, rational_returned=0, mip_count=0, exact_cuts=0;
    double solver_seconds=0;
    static mpq_class tail_mean(std::vector<mpq_class> values,mpq_class mass) {
        if(values.empty()||mass<=0||mass>values.size())throw std::logic_error("Invalid ES mass");
        std::sort(values.begin(),values.end(),std::greater<mpq_class>());
        mpq_class left=mass,total=0;
        for(const auto& v:values){if(left<=0)break;mpq_class take=left<1?left:mpq_class(1);total+=take*v;left-=take;}
        total/=mass;total.canonicalize();return total;
    }
    CalibratedBudget(const Instance& d,const std::string& cap):BudgetRO(d,cap) {
        const double begin=now();deviations.clear();upper.clear();thresholds.clear();gammas.clear();
        std::set<mpq_class> ts{mpq_class(0)};Json items=Json::array();
        for(int j=0;j<d.n();++j){check_budget();std::vector<mpq_class> values;
            for(const auto& text:d.decimals[j])values.push_back(rational_decimal(text));
            mpq_class mass=mpq_class(d.sample_count,20);mass.canonicalize();
            auto es=tail_mean(values,mass);mpq_class delta=es-means[j];delta.canonicalize();
            if(delta<0)throw std::logic_error("ES below mean");
            upper.push_back(es);deviations.push_back(delta);ts.insert(delta);
            items.push_back({{"item",j},{"mean",means[j].get_str()},{"ES95",es.get_str()},{"deviation",delta.get_str()},{"tail_mass",mass.get_str()}});
        }
        thresholds.assign(ts.begin(),ts.end());
        for(const auto& theta:thresholds){check_budget();Selection sel;mpq_class total=0;
            for(const auto& group:d.groups){int best=group.front();
                auto weight=[&](int j){mpq_class value=means[j];if(deviations[j]>theta)value+=deviations[j]-theta;return value;};
                for(int j:group)if(weight(j)<weight(best)||(weight(j)==weight(best)&&j<best))best=j;
                sel.push_back(best);total+=weight(best);
            }total.canonicalize();min_sums.push_back(total);min_choices.push_back(sel);
        }
        mpq_class nominal_min=0;for(const auto& group:d.groups){mpq_class v=means[group.front()];for(int j:group)if(means[j]<v)v=means[j];nominal_min+=v;}
        mean_infeasible=nominal_min>capacity-margin;
        if(!mean_infeasible){
            for(std::size_t k=0;k<thresholds.size();++k){
                const auto& theta=thresholds[k];
                if(theta==0){if(min_sums[k]<=capacity-margin)gamma_max=d.m();continue;}
                mpq_class bound=(capacity-margin-min_sums[k])/theta;
                if(bound>gamma_max)gamma_max=bound;
            }
            if(gamma_max>d.m())gamma_max=d.m();gamma_max.canonicalize();
        }
        if(gamma_max>0){
            auto k=minimum_resource(gamma_max);initial=min_choices[k];initial_theta=thresholds[k];
            if(gamma_max<gamma_floor)gamma_floor=gamma_max/2;
            gamma_floor.canonicalize();
        }
        auto sorted=deviations;std::sort(sorted.begin(),sorted.end());std::set<std::size_t> ci{0};
        for(int k=0;k<15;++k){auto value=sorted[std::size_t(k)*(sorted.size()-1)/14];ci.insert(std::lower_bound(thresholds.begin(),thresholds.end(),value)-thresholds.begin());}
        coarse.assign(ci.begin(),ci.end());Json resource=Json::array();for(std::size_t k=0;k<thresholds.size();++k)resource.push_back({{"theta",thresholds[k].get_str()},{"group_min_sum",min_sums[k].get_str()}});
        preparation_seconds+=now()-begin;
        metadata={{"model","R02_empirical_ES95_calibrated_budget_RO"},{"items",items},{"all_original_samples",true},{"samples_per_item",d.sample_count},
            {"ES_beta","19/20"},{"uncertainty_set","a=mean+d*z; 0<=z<=1; sum z<=Gamma"},{"deviation_rule","fractional empirical upper 5 percent mean minus full sample mean"},
            {"threshold_count",thresholds.size()},{"resource_table",resource},{"gamma_max_exact",gamma_max.get_str()},{"gamma_max_method","exact max of affine threshold feasibility ratios; not finite-step bisection"},
            {"positive_gamma_floor",gamma_floor.get_str()},{"mean_infeasible",mean_infeasible},{"nominal_zero_budget_fallback",false},
            {"robust_guard",margin.get_str()},{"coarse_threshold_indices",coarse},{"localization_rounds",9},{"localization_is_heuristic",true},{"CDF_solution_probability_monotonicity_claim",false},
            {"safe_cost_pruning","exact rational Lagrangian dual lower bound >= exact incumbent cost"},{"cost_cutoff","incumbent exact cost, outward upper, retains every strict exact-cost improvement"},
            {"coarse_MIP_slice_seconds",.25},{"fine_MIP_slice_seconds",1.},{"pool_search_mode",2},{"pool_solutions",25},{"pool_gap",.02},{"fine_threshold_limit_per_gamma",5},
            {"global_optimality_claim",false},{"probability_coverage_claim",false},{"Gamma_is_probability_level",false},{"historical_solution_inputs",false},{"external_MIPstarts",false},
            {"original_CDF_gate_preserved",true},{"final_acceptance","unchanged original LSS"},{"preparation_seconds",preparation_seconds}};
    }
    std::size_t minimum_resource(const mpq_class& gamma)const {
        std::size_t best=0;mpq_class value=gamma*thresholds[0]+min_sums[0];
        for(std::size_t k=1;k<thresholds.size();++k){mpq_class q=gamma*thresholds[k]+min_sums[k];if(q<value){value=q;best=k;}}
        return best;
    }
    mpq_class exact_cost(const Selection& s)const {mpq_class out=0;for(int j:s)out+=mpq_class(data.costs[j]);out.canonicalize();return out;}
    struct Bound {mpq_class value,lambda;};
    Bound dual_bound(const mpq_class& gamma,std::size_t index)const {
        const auto& theta=thresholds[index];auto weights=row(theta);double right=rhs(gamma,theta);
        auto eval=[&](double lambda){double value=-lambda*right,weight=0;
            for(const auto& group:data.groups){int best=group.front();for(int j:group)if(data.costs[j]+lambda*weights[j]<data.costs[best]+lambda*weights[best])best=j;
                value+=data.costs[best]+lambda*weights[best];weight+=weights[best];}
            return std::make_pair(value,weight);};
        double lo=0,hi=1,chosen=0,score=eval(0).first;
        for(int k=0;k<24&&eval(hi).second>right;++k)hi*=2;
        for(int k=0;k<32;++k){double middle=(lo+hi)/2;auto e=eval(middle);if(e.first>score){score=e.first;chosen=middle;}if(e.second>right)lo=middle;else hi=middle;}
        mpq_class lambda(chosen),exact_rhs=capacity-margin-gamma*theta,lb=-lambda*exact_rhs;
        for(const auto& group:data.groups){mpq_class best;bool first=true;for(int j:group){mpq_class w=means[j];if(deviations[j]>theta)w+=deviations[j]-theta;mpq_class v=mpq_class(data.costs[j])+lambda*w;if(first||v<best){best=v;first=false;}}lb+=best;}
        lb.canonicalize();return {lb,lambda};
    }
    Json statistics()const {return {{"preparation_seconds",preparation_seconds},{"MIP_seconds",solver_seconds},{"mip_subproblems_solved",mip_count},
        {"mip_pruned_by_safe_lb",exact_cuts},{"raw_solver_candidates",raw_returned},{"rational_verified_returned",rational_returned},{"rational_verified_unique",generated.size()},
        {"no_LSS_calls_in_generator",true}};}
};
}
