#pragma once
#include "evaluation.hpp"
#include <algorithm>
namespace s10 {
// Directed fixed-point enclosures. All divisions that own a bound use GMP
// floor/ceiling; ordinary floating exp/log never owns a feasibility decision.
struct FixedInterval {mpz_class lower,upper;};
class EntropicMath {
public:
 static constexpr int bits=192,exp_terms=40,log_terms=70;
 static const mpz_class& scale(){static const mpz_class q=mpz_class(1)<<bits;return q;}
 static mpz_class down(const mpz_class& a,const mpz_class& b){mpz_class q;mpz_fdiv_q(q.get_mpz_t(),a.get_mpz_t(),b.get_mpz_t());return q;}
 static mpz_class up(const mpz_class& a,const mpz_class& b){mpz_class q;mpz_cdiv_q(q.get_mpz_t(),a.get_mpz_t(),b.get_mpz_t());return q;}
 static mpz_class ceil_q(mpq_class x){x.canonicalize();return up(x.get_num(),x.get_den());}
 static FixedInterval exp_positive(mpq_class x){
  x.canonicalize();
  if(x<0)throw std::logic_error("exp_positive domain");
  const auto& q=scale();if(x==0)return {q,q};
  int k=0;while(x>mpq_class(1,2)){x/=2;++k;check_budget();}
  x.canonicalize();mpz_class low=q,high=q,term_low=q,term_high=q;
  for(int n=1;n<=exp_terms;++n){
   mpz_class den=x.get_den()*n;
   term_low=down(mpz_class(term_low*x.get_num()),den);term_high=up(mpz_class(term_high*x.get_num()),den);
   low+=term_low;high+=term_high;
  }
  // Remaining Taylor terms are bounded by the next term and a geometric tail.
  mpq_class rem=mpq_class(term_high)*x/(exp_terms+1)/(1-x/(exp_terms+2));high+=ceil_q(rem);
  for(int n=0;n<k;++n){low=down(mpz_class(low*low),q);high=up(mpz_class(high*high),q);check_budget();}
  return {low,high};
 }
 static FixedInterval exp_negative(const mpq_class& nonnegative){
  auto p=exp_positive(nonnegative);mpz_class square=scale()*scale();
  return {down(square,p.upper),up(square,p.lower)};
 }
 static FixedInterval log_unit(const mpq_class& value){
  if(value<1||value>2)throw std::logic_error("log_unit domain");
  mpq_class z=(value-1)/(value+1);z.canonicalize();mpq_class z2=z*z;z2.canonicalize();
  mpz_class pl=down(mpz_class(scale()*z.get_num()),z.get_den()),ph=up(mpz_class(scale()*z.get_num()),z.get_den()),sl=0,sh=0;
  for(int n=0;n<log_terms;++n){
   sl+=down(pl,mpz_class(2*n+1));sh+=up(ph,mpz_class(2*n+1));
   pl=down(mpz_class(pl*z2.get_num()),z2.get_den());ph=up(mpz_class(ph*z2.get_num()),z2.get_den());
  }
  mpq_class rem=2*mpq_class(ph)/(2*log_terms+1)/(1-z2);
  return {mpz_class(2*sl),mpz_class(2*sh+ceil_q(rem))};
 }
 static const FixedInterval& log_two(){static const auto value=log_unit(mpq_class(2));return value;}
 static FixedInterval log_positive(mpq_class value){
  value.canonicalize();
  if(value<=0)throw std::logic_error("log domain");int k=0;
  while(value<1){value*=2;--k;}while(value>=2){value/=2;++k;}
  auto core=log_unit(value);const auto& two=log_two();
  if(k>=0)return {mpz_class(core.lower+k*two.lower),mpz_class(core.upper+k*two.upper)};
  return {mpz_class(core.lower+k*two.upper),mpz_class(core.upper+k*two.lower)};
 }
 static std::pair<mpq_class,mpq_class> weight(const std::vector<mpq_class>& values,const mpq_class& t){
  if(values.empty()||t<=0)throw std::logic_error("Entropic weight domain");
  const auto [amin,amax]=std::minmax_element(values.begin(),values.end());
  if(*amin==*amax)return {*amin,*amax};
  mpz_class lower=0,upper=0;std::size_t counter=0;
  for(const auto& a:values){auto e=exp_negative(mpq_class(t*(*amax-a)));lower+=e.lower;upper+=e.upper;if(++counter%32==0)check_budget();}
  lower=down(lower,mpz_class(values.size()));upper=up(upper,mpz_class(values.size()));
  auto l=log_positive(mpq_class(lower,scale())),h=log_positive(mpq_class(upper,scale()));
  mpq_class lo=*amax+mpq_class(l.lower,scale())/t,hi=*amax+mpq_class(h.upper,scale())/t;lo.canonicalize();hi.canonicalize();
  return {lo,hi};
 }
};
}
