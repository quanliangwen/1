#include "search.hpp"
#include <numeric>
namespace s10 {
Groups Search::r06_budget_query(const mpq_class& gamma,bool fine){
    auto& c=*calibrated;const std::size_t qi=c.queries.size();
    c.queries.push_back({{"gamma",gamma.get_str()},{"stage",fine?"fine":"coarse"},{"solver_tasks",Json::array()},{"candidate_refs",Json::array()},
        {"safe_pruned",0},{"resource_infeasible",0},{"complete",false},{"CDF_monotonicity_claim",false}});
    struct Task{std::size_t index;CalibratedBudget::Bound bound;};std::vector<Task> tasks;std::vector<std::size_t> indices;
    if(fine){indices.resize(c.thresholds.size());std::iota(indices.begin(),indices.end(),0);}else indices=c.coarse;
    auto prune=[&](const Task& task){
        if(!fine||!best||task.bound.value<c.exact_cost(best->selection))return false;
        if(c.incumbent_recorded.insert(best->selection).second)c.incumbents.push_back(best->json());
        c.cost_cuts.push_back({{"gamma",gamma.get_str()},{"theta",c.thresholds[task.index].get_str()},{"lambda",task.bound.lambda.get_str()},
            {"dual_lower",task.bound.value.get_str()},{"incumbent_selection",best->selection},{"incumbent_exact_cost",c.exact_cost(best->selection).get_str()},
            {"current_run_integer_CDF_incumbent",true},{"strict_cheaper_exact_solution_preserved",true}});
        ++c.exact_cuts;c.queries[qi]["safe_pruned"]=c.queries[qi]["safe_pruned"].get<int>()+1;return true;
    };
    for(auto k:indices){check_budget();if(c.min_sums[k]+gamma*c.thresholds[k]>c.capacity-c.margin){c.queries[qi]["resource_infeasible"]=c.queries[qi]["resource_infeasible"].get<int>()+1;continue;}
        Task task{k,c.dual_bound(gamma,k)};if(!prune(task))tasks.push_back(task);
    }
    std::stable_sort(tasks.begin(),tasks.end(),[](const Task& a,const Task& b){return a.bound.value==b.bound.value?a.index<b.index:a.bound.value<b.bound.value;});
    std::set<Selection> unique;int solved=0,point_calls=0;
    for(const auto& task:tasks){
        if(remaining()<8||(fine&&solved>=5))break;
        if(prune(task))continue;
        const auto& theta=c.thresholds[task.index];auto weights=c.row(theta);
        std::vector<LinearRow> rows{{weights,-std::numeric_limits<double>::infinity(),c.rhs(gamma,theta)}};
        Json incumbent=nullptr;
        if(fine&&best){auto cap=c.exact_cost(best->selection);rows.push_back({instance.costs,-std::numeric_limits<double>::infinity(),BudgetRO::outward(cap,true)});incumbent={{"selection",best->selection},{"cost",cap.get_str()}};}
        // Enumerate alternatives only in fine search. Coarse localization must
        // be allowed to return an already seen optimizer and reuse its CDF state.
        Json excluded=Json::array();
        if(fine)for(const auto& q:c.record_index){
            const auto& state=c.proposals[q.second]["native_state"].get_ref<const std::string&>();
            if(state!="accepted"&&state!="infeasible")continue;
            Vector row(instance.n());for(int j:q.first)row[j]=1;
            rows.push_back({row,-std::numeric_limits<double>::infinity(),double(instance.m()-1)});excluded.push_back(q.second);
        }
        Json log;double begin=now();auto solutions=calibration_solver->solve(instance.costs,rows,std::min(fine?1.:.25,remaining()-5),fine?25:1,.02,log);
        c.solver_seconds+=now()-begin;++c.mip_count;++solved;c.raw_returned+=solutions.size();
        log["theta"]=theta.get_str();log["current_run_cost_cap"]=incumbent;log["excluded_proposal_indices"]=excluded;log["returned"]=solutions.size();
        c.queries[qi]["solver_tasks"].push_back(log);
        for(const auto& s:solutions){
            check_budget();auto witness=c.witness(s,gamma,theta,fine?"R02_fine_RO":"R02_coarse_RO");
            if(!witness["robust_feasible"].get<bool>()||!witness["fixed_theta_feasible"].get<bool>()){
                c.queries[qi]["numerical_rejections"].push_back(witness);continue;}
            ++c.rational_returned;auto index=calibrated_register(s,gamma,theta,fine?"R02_fine_RO":"R02_coarse_RO");
            c.queries[qi]["candidate_refs"].push_back(index);unique.insert(s);

        }
    }
    Groups out(unique.begin(),unique.end());std::stable_sort(out.begin(),out.end(),[&](const Selection& a,const Selection& b){return std::make_tuple(instance.cost_of(a),a)<std::make_tuple(instance.cost_of(b),b);});
    for(const auto&s:out)if(fine&&remaining()>6&&point_calls<15&&!pool.count(s)&&!decisions.count(s)){
        ++point_calls;r06_native(s,"R02_fine_RO","mother_es95_native_cdf");auto i=c.record_index.at(s);
        c.proposals[i]["native_state"]=pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown";c.proposals[i]["native_evaluation_completed"]=true;
    }
    c.queries[qi]["complete"]=true;c.queries[qi]["fresh_native_calls"]=point_calls;return out;
}
void Search::r06_budget_search(){
    auto& c=*calibrated;if(c.mean_infeasible||c.gamma_max<=0)return;
    mpq_class lo=c.gamma_floor,hi=c.gamma_max;int rounds=0;
    for(int k=0;k<9&&remaining()>10&&hi>lo;++k){
        mpq_class middle=(lo+hi)/2;middle.canonicalize();auto proposals=r06_budget_query(middle,false);++rounds;
        c.queries.back()["lo_before"]=lo.get_str();c.queries.back()["hi_before"]=hi.get_str();
        if(proposals.empty()){c.queries.back()["localization_state"]="no_solver_candidate_not_a_model_infeasibility_proof";break;}
        const auto& s=proposals.front();auto i=c.record_index.at(s);auto theta=mpq_class(c.proposals[i]["theta"].get<std::string>());
        // The original witness may use another Gamma. To classify this query,
        // find an exact minimizing threshold for this same selection and Gamma.
        mpq_class smallest=c.theta_value(s,middle,theta);
        for(const auto& t:c.thresholds){mpq_class value=c.theta_value(s,middle,t);if(value<smallest){smallest=value;theta=t;}}
        r06_native(s,"R02_coarse_RO","mother_es95_native_cdf");
        std::string state=pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown";
        c.proposals[i]["native_state"]=state;c.proposals[i]["native_evaluation_completed"]=true;
        c.queries.back()["selected_proposal_index"]=i;c.queries.back()["localization_state"]=state;
        if(state=="accepted")hi=middle;else if(state=="infeasible")lo=middle;else break;
    }
    c.metadata["gamma_bisect_lo"]=lo.get_str();c.metadata["gamma_bisect_hi"]=hi.get_str();c.metadata["gamma_bisect_rounds"]=rounds;
    r06["es95_no_improve"]=0;r06["fine_points_completed"]=0;
    mpq_class delta=c.gamma_max/10;if(delta<mpq_class(1,5))delta=mpq_class(1,5);
    std::vector<mpq_class> fine{hi,mpq_class((lo+hi)/2),mpq_class(hi+delta/20),mpq_class(lo-delta/20),mpq_class(hi+3*delta/25)};
    std::set<mpq_class> seen;Json values=Json::array();
    for(auto gamma:fine){if(gamma<c.gamma_floor)gamma=c.gamma_floor;if(gamma>c.gamma_max)gamma=c.gamma_max;gamma.canonicalize();
        if(!seen.insert(gamma).second)continue;values.push_back(gamma.get_str());if(remaining()>10){r06_budget_query(gamma,true);r06["fine_points_completed"]=r06["fine_points_completed"].get<int>()+1;}}
    c.metadata["fine_gamma_points"]=values;
}
}
