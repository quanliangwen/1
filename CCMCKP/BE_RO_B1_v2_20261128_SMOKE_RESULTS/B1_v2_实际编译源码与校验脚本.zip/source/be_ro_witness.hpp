#pragma once
#include "budget_ro.hpp"
namespace s10 {
// Exact rational data; only the final square root uses a directed 208-bit grid.
struct BEROWitness {
 static constexpr int bits=208;
 static std::pair<mpq_class,mpq_class> sqrt_interval(mpq_class v){
  v.canonicalize();if(v<0)throw std::logic_error("Negative square root");
  const mpz_class scale=mpz_class(1)<<bits;
  mpz_class a=v.get_num()*scale*scale,b=v.get_den(),floor,root;
  mpz_fdiv_q(floor.get_mpz_t(),a.get_mpz_t(),b.get_mpz_t());mpz_sqrt(root.get_mpz_t(),floor.get_mpz_t());
  mpq_class lo(root,scale),hi(root+(root*root*b<a?1:0),scale);lo.canonicalize();hi.canonicalize();return {lo,hi};
 }
 std::vector<mpq_class> mu,var,dev;
 mpq_class capacity,margin=mpq_class(1,100000000);
 int tail_count;
 Json items=Json::array();
 BEROWitness(const Instance& d,const std::string& cap):capacity(rational_decimal(cap)),tail_count(std::min(d.sample_count,std::max(3,(d.sample_count+19)/20))){
  for(int j=0;j<d.n();++j){check_budget();std::vector<mpq_class> values;mpq_class mean=0,v=0,es=0;
   for(const auto&t:d.decimals[j]){auto x=rational_decimal(t);values.push_back(x);mean+=x;}
   mean/=values.size();for(const auto&x:values)v+=(x-mean)*(x-mean);v/=values.size();
   std::sort(values.begin(),values.end(),std::greater<mpq_class>());for(int k=0;k<tail_count;++k)es+=values[k];es/=tail_count;
   mpq_class delta=es-mean;mean.canonicalize();v.canonicalize();delta.canonicalize();
   if(v<0||delta<0||(v==0&&delta!=0))throw std::logic_error("BE marginal moments");
   mu.push_back(mean);var.push_back(v);dev.push_back(delta);
   items.push_back({{"item",j},{"mu",mean.get_str()},{"variance",v.get_str()},{"deviation",delta.get_str()}});
  }
 }
 Json evaluate(const Selection& s,mpq_class omega)const{
  omega.canonicalize();if(omega<0)throw std::logic_error("Negative BE radius");
  Selection order;mpq_class nominal=0,corner=0,totaldev=0;
  for(int j:s){nominal+=mu[j];if(var[j]>0&&dev[j]>0){order.push_back(j);corner+=dev[j]*dev[j]/var[j];totaldev+=dev[j];}}
  mpq_class lo,hi,rem=0,vs=0,sat=0;int q=0;bool box=corner<=omega*omega;
  if(box){lo=hi=nominal+totaldev;q=order.size();}
  else{
   std::sort(order.begin(),order.end(),[&](int a,int b){mpq_class aa=dev[a]/var[a],bb=dev[b]/var[b];return aa==bb?a<b:aa<bb;});
   for(int j:order)vs+=var[j];rem=omega*omega;bool found=false;
   for(std::size_t k=0;k<order.size();++k){
    mpq_class squared=rem/vs,upper=dev[order[k]]/var[order[k]],lower=k?mpq_class(dev[order[k-1]]/var[order[k-1]]):mpq_class(0);
    if(rem>=0&&squared>=lower*lower&&squared<=upper*upper){auto r=sqrt_interval(mpq_class(rem*vs));lo=nominal+sat+r.first;hi=nominal+sat+r.second;q=k;found=true;break;}
    int j=order[k];rem-=dev[j]*dev[j]/var[j];vs-=var[j];sat+=dev[j];
   }
   if(!found)throw std::logic_error("BE KKT interval not found");
  }
  lo.canonicalize();hi.canonicalize();nominal.canonicalize();corner.canonicalize();rem.canonicalize();vs.canonicalize();
  return {{"selection",s},{"omega",omega.get_str()},{"bits",bits},{"box_saturated",box},{"saturated_count",q},{"order",order},
   {"nominal",nominal.get_str()},{"corner_norm_squared",corner.get_str()},{"remaining_radius_squared",rem.get_str()},{"interior_variance_sum",vs.get_str()},
   {"worst_lower",lo.get_str()},{"worst_upper",hi.get_str()},{"rhs",mpq_class(capacity-margin).get_str()},{"robust_feasible",hi<=capacity-margin}};
 }
 mpq_class cap(const Groups&groups)const{
  mpq_class v=0;for(const auto&g:groups){mpq_class z=0;for(int j:g)if(var[j]>0){mpq_class a=dev[j]*dev[j]/var[j];if(a>z)z=a;}v+=z;}
  return std::min(mpq_class(8),sqrt_interval(v).first);
 }
};
}
