#pragma once
#include "evaluation.hpp"
#include <cmath>
#include <limits>
namespace s10 {
inline double rational_round_down(const mpq_class& q){double x=q.get_d();if(!std::isfinite(x))throw std::runtime_error("Nonfinite moment coefficient");int k=0;while(mpq_class(x)>q){if(++k>8)throw std::runtime_error("Moment downward rounding failed");x=std::nextafter(x,-INFINITY);}return x;}
inline double rational_round_up(const mpq_class& q){double x=q.get_d();if(!std::isfinite(x))throw std::runtime_error("Nonfinite moment bound");int k=0;while(mpq_class(x)<q){if(++k>8)throw std::runtime_error("Moment upward rounding failed");x=std::nextafter(x,INFINITY);}return x;}
inline double rational_sqrt_round_up(const mpq_class& q){
    if(q<0)throw std::invalid_argument("Negative squared moment bound");
    mpf_class input(q,256),root(0,256);mpf_sqrt(root.get_mpf_t(),input.get_mpf_t());double x=root.get_d();
    if(!std::isfinite(x))throw std::runtime_error("Nonfinite necessary mean root");
    int k=0;
    while(mpq_class(x)*mpq_class(x)<q){if(++k>8)throw std::runtime_error("Moment sqrt rounding failed");x=std::nextafter(x,INFINITY);}return x;
}
struct NecessaryMeanBound {
    const Instance& data;Vector mean_lower;double root_upper=0,rhs=0;mpq_class vmax=0,capacity;Json proof;
    NecessaryMeanBound(const Instance& d,const std::string& text):data(d),capacity(rational_decimal(text)){
        if(capacity<=0)throw std::invalid_argument("Nonpositive moment capacity");
        std::vector<mpq_class> variance;Json exact_means=Json::array(),exact_vars=Json::array(),group_vars=Json::array();
        for(int j=0;j<d.n();++j){check_budget();mpq_class first=0,second=0;
            for(const auto& word:d.decimals[j]){mpq_class a=rational_decimal(word);first+=a;second+=a*a;}
            const auto n=static_cast<unsigned long>(d.decimals[j].size());first/=n;mpq_class v=second/n-first*first;
            if(v<0)throw std::logic_error("Negative exact empirical variance");
            mean_lower.push_back(rational_round_down(first));variance.push_back(v);exact_means.push_back(first.get_str());exact_vars.push_back(v.get_str());
        }
        for(const auto& g:d.groups){mpq_class v=0;for(int j:g)if(variance[j]>v)v=variance[j];vmax+=v;group_vars.push_back(v.get_str());}
        root_upper=rational_sqrt_round_up(vmax/99);
        rhs=rational_round_up(capacity+mpq_class(root_upper));
        proof={{"method","Cantelli_lower_tail_necessary_global_variance_envelope"},{"probability_target","99/100"},
            {"scope","independent_uniform_original_decimal_empirical_CDF_only; not final_LSS_acceptance_or_population_coverage"},
            {"capacity_exact",capacity.get_str()},{"exact_item_means",exact_means},{"exact_item_variances_ddof0",exact_vars},
            {"mean_coefficients_rounded_down",mean_lower},{"exact_group_max_variances",group_vars},{"exact_Vmax",vmax.get_str()},
            {"sqrt_Vmax_over99_rounded_up",root_upper},{"rhs_rounded_up",rhs},{"registered_proposal_row_tolerance",1e-6},
            {"adds_sufficient_ellipsoid_final_constraint",false}};
    }
    Json check(const Selection& s)const{data.validate(s);mpq_class lhs=0;for(int j:s)lhs+=mpq_class(mean_lower[j]);const mpq_class right(rhs);mpq_class slack=right-lhs;
        return {{"lhs_exact_binary_rational",lhs.get_str()},{"rhs_exact_binary_rational",right.get_str()},{"slack_exact_binary_rational",slack.get_str()},
            {"strictly_satisfies_row",lhs<=right},{"within_registered_proposal_row_tolerance",lhs<=right+mpq_class(1e-6)},{"row_tolerance",1e-6}};
    }
};
}
