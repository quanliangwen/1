#include "be_ro_solver.hpp"
#include "gurobi_budget.hpp"
#include <gurobi_c.h>
namespace s10 {
struct BEROSolver::Impl {
 const Instance&d;const BEROWitness&w;int seed;
 struct EDel{void operator()(GRBenv*p)const{GRBfreeenv(p);}};
 struct MDel{void operator()(GRBmodel*p)const{GRBfreemodel(p);}};
 std::unique_ptr<GRBenv,EDel>env;
 void check(int x,GRBenv*e){if(x)throw std::runtime_error("BE Gurobi "+std::to_string(x)+":"+(e?GRBgeterrormsg(e):"env"));}
 Groups solve(const mpq_class&omega,double seconds,int count,bool feasibility,const std::set<Selection>&excluded,double cutoff,Json&log){
  const double begin=now();check_budget();
  if(!env){GRBenv*p=nullptr;int rc=GRBemptyenv(&p);env.reset(p);check(rc,p);check(GRBsetintparam(p,"OutputFlag",0),p);check(GRBstartenv(p),p);}
  const int n=d.n(),N=3*n+1,S=3*n;Vector objective(N,0),lb(N,0),ub(N,1);std::vector<char>type(N,GRB_CONTINUOUS);ub[S]=GRB_INFINITY;
  for(int j=0;j<n;++j){type[j]=GRB_BINARY;objective[j]=feasibility?0:d.costs[j];if(w.var[j]==0)ub[n+j]=ub[2*n+j]=0;}
  GRBmodel*m=nullptr;int rc=GRBnewmodel(env.get(),&m,"BE_RO_Pure",N,objective.data(),lb.data(),ub.data(),type.data(),nullptr);std::unique_ptr<GRBmodel,MDel>model(m);check(rc,env.get());auto*e=GRBgetenv(m);auto ck=[&](int z){check(z,e);};
  ck(GRBsetcallbackfunc(m,budget_callback,nullptr));ck(GRBsetintparam(e,"Threads",1));ck(GRBsetintparam(e,"Seed",seed));
  ck(GRBsetdblparam(e,"MIPGap",1e-6));ck(GRBsetdblparam(e,"FeasibilityTol",1e-9));ck(GRBsetdblparam(e,"IntFeasTol",1e-9));ck(GRBsetintparam(e,"NonConvex",0));
  ck(GRBsetintparam(e,"PoolSearchMode",count>1?2:0));ck(GRBsetintparam(e,"PoolSolutions",count));
  ck(GRBupdatemodel(m));std::vector<int> ignore(2*n+1,1);ck(GRBsetintattrarray(m,"PoolIgnore",n,2*n+1,ignore.data()));
  auto add=[&](Selection ids,Vector v,char sense,double rhs){ck(GRBaddconstr(m,ids.size(),ids.data(),v.data(),sense,rhs,nullptr));};
  for(const auto&g:d.groups)add(g,Vector(g.size(),1),GRB_EQUAL,1);
  for(int j=0;j<n;++j)if(w.var[j]>0)add({j,n+j,2*n+j},{-1,1,1},GRB_GREATER_EQUAL,0);
  Selection ids,qi;Vector val,qv;
  for(int j=0;j<n;++j){ids.push_back(j);val.push_back(BudgetRO::outward(mpq_class(w.mu[j]/w.capacity),true));
   if(w.var[j]>0){ids.push_back(n+j);val.push_back(BudgetRO::outward(mpq_class(w.dev[j]/w.capacity),true));qi.push_back(2*n+j);qv.push_back(BudgetRO::outward(mpq_class(w.var[j]/(w.capacity*w.capacity)),true));}}
  ids.push_back(S);val.push_back(BudgetRO::outward(omega,true));add(ids,val,GRB_LESS_EQUAL,BudgetRO::outward(mpq_class((w.capacity-w.margin)/w.capacity),false));
  qi.push_back(S);qv.push_back(-1);ck(GRBaddqconstr(m,0,nullptr,nullptr,qi.size(),qi.data(),qi.data(),qv.data(),GRB_LESS_EQUAL,0,nullptr));
  for(const auto&s:excluded)add(s,Vector(s.size(),1),GRB_LESS_EQUAL,d.m()-1);
  if(std::isfinite(cutoff)){Selection js(n);std::iota(js.begin(),js.end(),0);add(js,d.costs,GRB_LESS_EQUAL,cutoff);}
  Groups result;double left=std::min(seconds-(now()-begin),budget_left());int status=0,solutions=0;
  if(left>.001){ck(GRBsetdblparam(e,"TimeLimit",left));ck(GRBoptimize(m));ck(GRBgetintattr(m,"Status",&status));ck(GRBgetintattr(m,"SolCount",&solutions));
   for(int k=0;k<solutions;++k){ck(GRBsetintparam(e,"SolutionNumber",k));Vector x(n);ck(GRBgetdblattrarray(m,"Xn",0,n,x.data()));Selection s;
    for(const auto&g:d.groups)s.push_back(*std::max_element(g.begin(),g.end(),[&](int a,int b){return x[a]<x[b];}));d.validate(s);result.push_back(s);}
  }
  std::sort(result.begin(),result.end(),[&](const Selection&a,const Selection&b){return std::make_pair(d.cost_of(a),a)<std::make_pair(d.cost_of(b),b);});result.erase(std::unique(result.begin(),result.end()),result.end());
  log={{"start_absolute",begin},{"whole_subproblem_seconds",now()-begin},{"solver_status",status},{"solutions_retained",solutions},{"distinct_returned",result.size()},{"PoolSearchMode",count>1?2:0},{"PoolSolutions",count},{"time_limit",seconds},{"external_MIPstarts",false},{"feasibility_objective",feasibility},{"radius",omega.get_str()},{"no_good_count",excluded.size()},{"cost_cutoff",std::isfinite(cutoff)?Json(cutoff):Json(nullptr)},{"proven_infeasible",status==GRB_INFEASIBLE}};
  return result;
 }
};
BEROSolver::BEROSolver(const Instance&d,const BEROWitness&w,int seed):impl(new Impl{d,w,seed,{}}){}
BEROSolver::~BEROSolver()=default;
Groups BEROSolver::solve(const mpq_class&o,double t,int k,bool f,const std::set<Selection>&e,double c,Json&l){return impl->solve(o,t,k,f,e,c,l);}
}
