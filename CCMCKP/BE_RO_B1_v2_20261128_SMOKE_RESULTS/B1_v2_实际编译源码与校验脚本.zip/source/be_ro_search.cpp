#include "search.hpp"
#include "be_ro_linear.hpp"
#include "isolated_native.hpp"
#include <tuple>

namespace s10 {
Json Search::be_ro_run(){
 BEROWitness w(instance,options.capacity_text);BELinearMath math(instance,w);BELinearSolver solver(instance,options.seed);
 PolishFFT fft(instance.samples,instance.groups,options.capacity,8192,12);
 const double fft_setup_seconds=fft.seconds;
 double epsilon=.0015,mipseconds=0,resource_seconds=0,nativeseconds=0;
 std::set<Selection>tried;
 struct Entry{Selection s;mpq_class omega,lambda;std::string kind;Json proof;double score;Json origins;};
 std::map<Selection,Entry>archive;
 be_ro_log={{"model","BE_RO_Pure_B1_v2"},{"beta","19/20"},{"K",5},{"tail_count",w.tail_count},
  {"samples_per_item",instance.sample_count},{"items",w.items},{"radius_is_probability_guarantee",false},
  {"radius_localization_is_heuristic",true},{"CDF_solution_probability_monotonicity_claim",false},
  {"finite_lambda_grid_is_exact_optimizer",false},{"omega_max_is_exact_claim",false},
  {"external_MIPstarts",false},{"historical_solution_inputs",false},{"local_search_enabled",false},
  {"private_FFT_is_certificate",false},{"initialization","own raw samples; fixed-lambda linear BE rows only"},
  {"sigma_min",math.sigma_min.get_str()},{"sigma_max",math.sigma_max.get_str()},
  {"queries",Json::array()},{"candidates",Json::array()},{"native_calls",Json::array()},
  {"calibration",Json::array()},{"resource_probes",Json::array()},{"escape",Json::array()},
  {"timing",{{"load_and_model",now()-started}}}};
 auto kth=[&]()->double{
  if(pool.size()<5)return INFINITY;
  std::set<Selection>keys;for(const auto&q:pool)keys.insert(q.first);
  return pool.at(cost_order(keys)[4]).cost;
 };
 auto query=[&](const BELinearRow&row,int count,const std::string&phase,bool exclude){
  check_budget();const double begin=now();if(begin>=deadline)throw BudgetExpired();
  Json log;auto found=solver.solve(row,1.,count,exclude?tried:std::set<Selection>{},kth()-1e-6,log);
  mipseconds+=now()-begin;if(row.feasible)++models;
  log["start"]=begin-started;log["finish"]=now()-started;log["phase"]=phase;
  log["returned"]=Json::array();log["archive_processing_complete"]=false;Groups good;
  for(const auto&s:found){
   auto proof=w.evaluate(s,row.omega);log["returned"].push_back(proof);
   if(!proof["robust_feasible"].get<bool>())continue;
   good.push_back(s);
  }
  const std::size_t qi=be_ro_log["queries"].size();be_ro_log["queries"].push_back(log);
  for(const auto&s:good){
   Json origin={{"query_index",qi},{"phase",phase},{"omega",row.omega.get_str()},
    {"lambda",row.lambda.get_str()},{"kind",row.kind},{"row",row.proof(s)}};
   auto it=archive.find(s);
   if(it==archive.end()){
    auto proof=w.evaluate(s,row.omega);
    archive.emplace(s,Entry{s,row.omega,row.lambda,row.kind,proof,-1,Json::array({origin})});
   }else it->second.origins.push_back(origin);
  }
  for(const auto&s:good){auto&a=archive.at(s);if(a.score<0){check_budget();a.score=fft.probability(s);}}
  be_ro_log["queries"][qi]["archive_processing_complete"]=true;return good;
 };
 auto radius_query=[&](const mpq_class&omega,int count,const std::string&phase,bool exclude){
  std::set<Selection>keys;
  for(const auto&lambda:math.grid(omega,10)){
   check_budget();auto row=math.row(omega,lambda);
   auto found=query(row,count,phase,exclude);keys.insert(found.begin(),found.end());
  }
  return cost_order(keys);
 };
 // No final LSS decision is read or used to calibrate the search.
 auto certify=[&](const Entry&a,const std::string&mode,double gate){
  const auto&s=a.s;if(a.score<0||tried.count(s)||pool.count(s))return;
  double current_kth=kth();
  Json rec={{"selection",s},{"cost",instance.cost_of(s)},{"omega",a.omega.get_str()},
   {"lambda",a.lambda.get_str()},{"kind",a.kind},{"witness",a.proof},{"private_probability",a.score},
   {"epsilon_before",epsilon},{"mode",mode},{"gate",std::isfinite(gate)?Json(gate):Json(nullptr)},
   {"Kth_cost_before",std::isfinite(current_kth)?Json(current_kth):Json(nullptr)},{"start",now()-started}};
  if(instance.cost_of(s)>=current_kth-1e-6){rec["decision"]="dynamic_cost_cutoff";be_ro_log["candidates"].push_back(rec);return;}
  if(a.score<gate){rec["decision"]="private_FFT_rejected";be_ro_log["candidates"].push_back(rec);return;}
  if(!a.proof["robust_feasible"].get<bool>())throw std::logic_error("Uncertified BE candidate");
  check_budget();const double begin=now();if(begin>=deadline)throw BudgetExpired();tried.insert(s);
  const double end=std::min(begin+90.,started+options.seconds-30.);
  const int oldcalls=oracle.calls;const double oldseconds=oracle.seconds;
  auto child=isolated_native(end,[&](){
   deadline=started+options.seconds-30.;phase_deadline=end;last_save=now()+1e9;
   bool expired=false;double value=0;try{value=native_check(s,"BE_RO_Pure");}catch(const BudgetExpired&){expired=true;}
   Json z={{"expired",expired},{"value",value},{"calls_delta",oracle.calls-oldcalls},{"seconds_delta",oracle.seconds-oldseconds},
    {"state",pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown"}};
   if(pool.count(s))z["certificate"]=pool.at(s).certificate.json(s);
   else if(infeasible_proofs.count(s))z["certificate"]=infeasible_proofs.at(s).json(s);return z;
  });
  Json call={{"selection",s},{"cost",instance.cost_of(s)},{"start",begin-started},{"finish",now()-started},
   {"hard_timeout",child.timeout},{"elapsed",child.elapsed},{"state","unknown"},{"omega",a.omega.get_str()},
   {"lambda",a.lambda.get_str()},{"private_probability",a.score},{"epsilon_before",epsilon},
   {"mode",mode},{"gate",std::isfinite(gate)?Json(gate):Json(nullptr)},{"slice_deadline",end-started}};
  if(!child.timeout){auto&z=child.payload;call["state"]=z["state"];call["expired"]=z["expired"];
   oracle.calls+=z["calls_delta"].get<int>();oracle.seconds+=z["seconds_delta"].get<double>();
   if(z.contains("certificate")){auto c=z["certificate"];call["certificate"]=c;
    Certificate cert{mpz_class(c["lower_numerator"].get<std::string>()),mpz_class(c["upper_numerator"].get<std::string>()),
     mpz_class(c["denominator"].get<std::string>()),c["bins"].get<int>(),c["certificate_seconds"].get<double>()};
    if(z["state"]=="accepted"){accept(s,"BE_RO_Pure",cert);epsilon=std::max(epsilon,std::max(.001,.99-a.score));}
    else if(z["state"]=="infeasible"){infeasible_proofs.insert_or_assign(s,cert);decisions[s]=cert.probability();}
   }
  }
  nativeseconds+=now()-begin;call["epsilon_after"]=epsilon;be_ro_log["native_calls"].push_back(call);
  rec["decision"]=call["state"];rec["finish"]=now()-started;be_ro_log["candidates"].push_back(rec);
 };
 auto certify_ordered=[&](bool escape){
  std::vector<const Entry*>order;for(const auto&q:archive)if(q.second.score>=0&&!tried.count(q.first)&&!pool.count(q.first))order.push_back(&q.second);
  if(escape&&pool.empty()){
   std::sort(order.begin(),order.end(),[&](const Entry*a,const Entry*b){
    return a->score==b->score?std::make_pair(instance.cost_of(a->s),a->s)<std::make_pair(instance.cost_of(b->s),b->s):a->score>b->score;});
   int attempted=0;
   for(const auto*a:order){if(!pool.empty()||attempted==10)break;check_budget();certify(*a,"escape_empty",-INFINITY);++attempted;}
   if(pool.empty())return;
  }
  std::sort(order.begin(),order.end(),[&](const Entry*a,const Entry*b){
   return std::make_tuple(instance.cost_of(a->s),-a->score,a->s)<std::make_tuple(instance.cost_of(b->s),-b->score,b->s);});
  // An accepted CDF may widen epsilon. Revisit earlier cheap FFT rejections,
  // but never repeat a vector whose original CDF was already attempted.
  bool widened;
  do{double oldepsilon=epsilon;
   for(const auto*a:order){check_budget();if(instance.cost_of(a->s)>=kth()-1e-6)break;
    certify(*a,escape?"escape_nonempty":"archive_cost_order",escape?.985:.99-epsilon);}
   widened=!escape&&epsilon>oldepsilon;
  }while(widened);
 };
 try{
  const double rbegin=now();const mpq_class cap=w.cap(instance.groups);mpq_class lo=0,hi=cap;
  be_ro_log["omega_cap"]=cap.get_str();be_ro_log["resource_grid_count"]=12;
  for(int k=0;k<12&&hi>lo;++k){
   check_budget();mpq_class mid=(lo+hi)/2;mid.canonicalize();bool yes=math.feasible_at(mid,12);
   be_ro_log["resource_probes"].push_back({{"omega",mid.get_str()},{"grid_feasible",yes},
    {"full_model_infeasibility_claim",false}});
   if(yes)lo=mid;else hi=mid;
  }
  const mpq_class maximum=lo;resource_seconds=now()-rbegin;
  be_ro_log["omega_resource_lower"]=lo.get_str();be_ro_log["omega_resource_upper"]=hi.get_str();
  be_ro_log["resource_search_unknown"]=true;be_ro_log["resource_positive_feasible_found"]=maximum>0;
  be_ro_log["resource_note"]="Feasible grid radius only; failed probes do not prove BE infeasibility or exact maximum";
  lo=0;hi=maximum;Selection prevlo,prevhi;
  while(hi>lo&&maximum>0&&(hi-lo)/maximum>mpq_class(1,100)){
   mpq_class mid=(lo+hi)/2;mid.canonicalize();auto found=radius_query(mid,1,"private_calibration",false);
   if(found.empty()){
    hi=mid;be_ro_log["calibration"].push_back({{"omega",mid.get_str()},{"no_returned_candidate",true},
     {"update","heuristic_hi"},{"original_CDF_calls",0},{"infeasibility_claim",false}});continue;
   }
   const auto&s=found.front();double p=archive.at(s).score;
   be_ro_log["calibration"].push_back({{"omega",mid.get_str()},{"selection",s},
    {"private_probability",p},{"original_CDF_calls",0}});
   if(p>=.99){hi=mid;prevhi=s;}else{lo=mid;prevlo=s;}
   if(!prevlo.empty()&&prevlo==prevhi)break;
  }
  const mpq_class star=hi;
  be_ro_log["omega_resource_used"]=maximum.get_str();be_ro_log["omega_star"]=star.get_str();
  auto clip=[&](mpq_class x){x.canonicalize();return std::min(maximum,std::max(mpq_class(0),x));};
  std::vector<mpq_class>points;
  for(mpq_class p:{clip(std::max(mpq_class(1,20),mpq_class(star*9/10))),
                   clip(std::max(mpq_class(1,20),mpq_class(star*24/25))),clip(star),clip(mpq_class(star*26/25))})
   if(std::find(points.begin(),points.end(),p)==points.end())points.push_back(p);
  be_ro_log["critical_points"]=Json::array();
  for(const auto&omega:points){be_ro_log["critical_points"].push_back(omega.get_str());radius_query(omega,10,"critical_pool",false);}
  auto box=math.row(maximum,0,true);be_ro_log["box_array_feasible"]=box.feasible;
  if(box.feasible)query(box,10,"box_corner_pool",false);
  certify_ordered(false);
  mpq_class esc=star;
  for(int k=0;k<3&&pool.size()<5;++k){
   check_budget();esc=k==2?maximum:mpq_class(esc+(maximum-esc)/4);esc.canonicalize();
   auto before=pool.size();radius_query(esc,10,"escape_pool",true);certify_ordered(true);
   be_ro_log["escape"].push_back({{"round",k+1},{"omega",esc.get_str()},{"certified_before",before},{"certified_after",pool.size()}});
   if(esc==maximum)break;
  }
 }catch(const BudgetExpired&){be_ro_log["partial"]="global_new_call_deadline";}
 be_ro_log["archive"]=Json::array();
 for(const auto&q:archive){const auto&a=q.second;be_ro_log["archive"].push_back({{"selection",a.s},
  {"cost",instance.cost_of(a.s)},{"omega",a.omega.get_str()},{"lambda",a.lambda.get_str()},
  {"kind",a.kind},{"witness",a.proof},{"private_probability",a.score>=0?Json(a.score):Json(nullptr)},
  {"private_probability_complete",a.score>=0},{"origins",a.origins}});}
 phase_records.push_back({{"phase","initialization"},{"own_raw_sample_initialization",true},{"best_before",nullptr},
  {"best_after",best?Json(best->cost):Json(nullptr)},{"elapsed",now()-started},{"candidates_added",pool.size()}});
 be_ro_log["epsilon_fft_final"]=epsilon;be_ro_log["timing"]["bero_resource_arrays"]=resource_seconds;
 be_ro_log["timing"]["bero_linear_mckp"]=mipseconds;be_ro_log["timing"]["bero_native_cdf"]=nativeseconds;
 // FFT setup was already included in load_and_model; count scoring only here.
 be_ro_log["timing"]["bero_private_fft"]=fft.seconds-fft_setup_seconds;
 be_ro_log["private_fft_seconds"]=fft.seconds;be_ro_log["stop_seconds"]=now()-started;model_seconds=mipseconds;
 return save("completed");
}
void Search::be_ro_save_fields(Json&data){
 if(options.search_flow!="be_ro_pure")return;
 be_ro_log["certified_pool"]=Json::array();for(const auto&q:pool)be_ro_log["certified_pool"].push_back(q.second.json());
 data["BE_RO_model"]=be_ro_log;data["config"]["LSS_reserve_seconds"]=120.;data["config"]["search_launch_deadline_seconds"]=480.;
 data["config"]["maximum_started_native_finish_seconds"]=570.;data["config"]["native_single_call_seconds"]=90.;
}
}
