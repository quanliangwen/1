#include "riskmaster.hpp"
#include "canonical.hpp"
#include "moment_bound.hpp"
#include "gurobi_budget.hpp"
#include <cmath>
#include <set>
#include <numeric>
namespace s10 {
struct RiskDominanceMaster::Impl {
    const Instance& data;
    bool costfirst;
    std::unique_ptr<NecessaryMeanBound> moment;
    double gamma, bound=std::numeric_limits<double>::infinity();
    GRBenv* env=nullptr;
    GRBmodel* model=nullptr;
    std::set<Selection> excluded, dominance;
    std::set<std::pair<Selection,int>> core_rows;
    void check(int c) { if(c)throw std::runtime_error("Costfront Gurobi: "+std::to_string(c)+":"+(env?GRBgeterrormsg(env):"no env")); }
    Impl(const Instance& d,int seed,double g,const Selection& start,bool cp,const std::string& capacity):data(d),costfirst(cp),moment(capacity.empty()?nullptr:new NecessaryMeanBound(d,capacity)),gamma(g) {
        if(!(g>=0 && std::isfinite(g)))throw std::invalid_argument("Invalid risk parameters");
        check(GRBemptyenv(&env));check(GRBsetintparam(env,"OutputFlag",0));check(GRBstartenv(env));
        const int vars=2*d.n()+1;
        Vector obj=costfirst?d.costs:d.mean;obj.push_back(costfirst?0:gamma);obj.resize(vars,0);
        Vector lo(vars,0),hi(vars,GRB_INFINITY);
        std::vector<char> types(vars,GRB_CONTINUOUS);
        for(int j=0;j<d.n();++j){hi[j]=1;types[j]=GRB_BINARY;}
        check(GRBnewmodel(env,&model,"EGS_native_risk_FOSD",vars,obj.data(),lo.data(),hi.data(),types.data(),nullptr));
        auto* p=GRBgetenv(model);
        check(GRBsetintparam(p,"Threads",1));check(GRBsetintparam(p,"Seed",seed));
        check(GRBsetintparam(p,"NonConvex",0));check(GRBsetdblparam(p,"MIPGap",0));
        // Disaggregated rotated-cone presolve retains convex recognition after
        // no-good cuts fix binary variables (Gurobi 11 otherwise rejects a
        // degenerate presolved SOC). This does not enable nonconvex solving.
        check(GRBsetintparam(p,"PreMIQCPForm",2));
        check(GRBsetdblparam(p,"FeasibilityTol",1e-9));check(GRBsetdblparam(p,"IntFeasTol",1e-9));
        check(GRBsetcallbackfunc(model,budget_callback,nullptr));
        for(auto group:d.groups) {
            Vector v(group.size(),1);
            check(GRBaddconstr(model,int(group.size()),group.data(),v.data(),GRB_EQUAL,1,nullptr));
        }
        Selection idx(d.n());std::iota(idx.begin(),idx.end(),0);auto cost=d.costs;
        check(GRBaddconstr(model,d.n(),idx.data(),cost.data(),GRB_LESS_EQUAL,GRB_INFINITY,"improving_cost"));
        if(moment) {
            check(GRBaddconstr(model,d.n(),idx.data(),moment->mean_lower.data(),GRB_LESS_EQUAL,moment->rhs,"necessary_Cantelli_mean_relaxation"));
            if(!start.empty()&&!moment->check(start).at("strictly_satisfies_row").get<bool>())throw std::logic_error("Native-certified own initializer violates necessary moment envelope");
        }
        // Lift u=diag(sd)x; keep the SOC entirely continuous so presolve does not
        // replace binary squares by linear terms and obscure convexity.
        Selection cone;Vector q;
        if(gamma>0) {
        for(int j=0;j<d.n();++j) {
            int link[]={j,d.n()+1+j};double v[]={-std::sqrt(d.variance[j]),1};
            check(GRBaddconstr(model,2,link,v,GRB_EQUAL,0,nullptr));
            cone.push_back(d.n()+1+j);q.push_back(1);
        }
        cone.push_back(d.n());q.push_back(-1);
        check(GRBaddqconstr(model,0,nullptr,nullptr,d.n()+1,cone.data(),cone.data(),q.data(),GRB_LESS_EQUAL,0,"native_SOC"));
        }
        check(GRBupdatemodel(model));
        if(costfirst) {
            Selection indices(d.n()+1);std::iota(indices.begin(),indices.end(),0);
            Vector c=d.costs;c.push_back(0);Vector risk=d.mean;risk.push_back(gamma);
            check(GRBsetobjectiven(model,0,2,1,0,0,"primary_cost",0,int(c.size()),indices.data(),c.data()));
            check(GRBsetobjectiven(model,1,1,1,0,0,"secondary_ellipsoid_risk",0,int(risk.size()),indices.data(),risk.data()));
            check(GRBupdatemodel(model));
            for(int i=0;i<2;++i){auto* e=GRBgetmultiobjenv(model,i);if(!e)throw std::runtime_error("Missing objective environment");
                check(GRBsetintparam(e,"Threads",1));check(GRBsetintparam(e,"Seed",seed));
                check(GRBsetintparam(e,"NonConvex",0));check(GRBsetintparam(e,"PreMIQCPForm",2));
                check(GRBsetdblparam(e,"MIPGap",0));check(GRBsetdblparam(e,"FeasibilityTol",1e-9));check(GRBsetdblparam(e,"IntFeasTol",1e-9));}
        }
        if(!start.empty()) {
            d.validate(start);Vector x(vars,0);
            for(int j:start){x[j]=1;x[d.n()+1+j]=std::sqrt(d.variance[j]);}
            x[d.n()]=canonical_soc_witness(d,start).at("canonical_t").get<double>();
            check(GRBsetdblattrarray(model,"Start",0,vars,x.data()));
        }
    }
    ~Impl(){if(model)GRBfreemodel(model);if(env)GRBfreeenv(env);}
};
RiskDominanceMaster::RiskDominanceMaster(const Instance& d,int s,double g,const Selection& start,bool cp,const std::string& capacity):impl(new Impl(d,s,g,start,cp,capacity)){}
RiskDominanceMaster::~RiskDominanceMaster()=default;
void RiskDominanceMaster::set_cost_bound(double b) {
    if(!std::isfinite(b)||b>impl->bound)throw std::invalid_argument("Cost bound may only tighten");
    impl->check(GRBsetdblattrelement(impl->model,"RHS",impl->data.m(),b));impl->bound=b;
}
bool RiskDominanceMaster::exclude_processed(const Selection& s) {
    impl->data.validate(s);if(!impl->excluded.insert(s).second)return false;
    auto i=s;Vector v(s.size(),1);
    impl->check(GRBaddconstr(impl->model,int(s.size()),i.data(),v.data(),GRB_LESS_EQUAL,impl->data.m()-1,nullptr));return true;
}
bool RiskDominanceMaster::add_dominance_cut(const Groups& worse) {
    if(worse.size()!=impl->data.groups.size())throw std::invalid_argument("Dominance cut group count");
    Selection columns;
    for(std::size_t g=0;g<worse.size();++g) {
        if(worse[g].empty())throw std::invalid_argument("Empty dominance cut group");
        for(int j:worse[g]) {
            const auto& allowed=impl->data.groups[g];
            if(std::find(allowed.begin(),allowed.end(),j)==allowed.end())throw std::invalid_argument("Wrong dominance-cut group");
            columns.push_back(j);
        }
    }
    std::sort(columns.begin(),columns.end());
    if(std::adjacent_find(columns.begin(),columns.end())!=columns.end())throw std::invalid_argument("Duplicate dominance-cut coefficient");
    if(!impl->dominance.insert(columns).second)return false;
    Vector coefficients(columns.size(),1);
    impl->check(GRBaddconstr(impl->model,int(columns.size()),columns.data(),coefficients.data(),GRB_LESS_EQUAL,impl->data.m()-1,"empirical_FOSD_feasibility_cut"));
    return true;
}
bool RiskDominanceMaster::add_core_cut(const Groups& worse,const Selection& active) {
    if(worse.size()!=impl->data.groups.size())throw std::invalid_argument("Core group count");
    Selection cols;std::set<int> seen;
    for(int g:active) {
        if(g<0||g>=impl->data.m()||!seen.insert(g).second||worse[g].empty())throw std::invalid_argument("Invalid core group");
        for(int j:worse[g]) {
            const auto& allowed=impl->data.groups[g];if(std::find(allowed.begin(),allowed.end(),j)==allowed.end())throw std::invalid_argument("Wrong core-cut item");cols.push_back(j);
        }
    }
    std::sort(cols.begin(),cols.end());if(std::adjacent_find(cols.begin(),cols.end())!=cols.end())throw std::invalid_argument("Repeated core item");
    int rhs=int(active.size())-1;if(!impl->core_rows.insert({cols,rhs}).second)return false;
    Vector values(cols.size(),1);impl->check(GRBaddconstr(impl->model,int(cols.size()),cols.data(),values.data(),GRB_LESS_EQUAL,rhs,"certified_empirical_infeasible_core"));return true;
}
int RiskDominanceMaster::core_cut_count() const {return int(impl->core_rows.size());}
Json RiskDominanceMaster::necessary_mean_bound_specification() const {return impl->moment?impl->moment->proof:Json(nullptr);}
int RiskDominanceMaster::dominance_cut_count() const { return int(impl->dominance.size()); }
EllipsoidQuery RiskDominanceMaster::next_candidate(double seconds) {
    check_budget();EllipsoidQuery q;q.objective_bound_available=!impl->costfirst;const double started=now();auto* m=impl->model;auto* p=GRBgetenv(m);
    impl->check(GRBsetdblparam(p,"TimeLimit",std::max(.001,std::min(seconds,budget_left()))));
    if(impl->costfirst)for(int i=0;i<2;++i)impl->check(GRBsetdblparam(GRBgetmultiobjenv(m,i),"TimeLimit",std::max(.001,std::min(seconds,budget_left()))));
    impl->check(GRBoptimize(m));check_budget();q.optimize_calls=1;
    int count=0;impl->check(GRBgetintattr(m,"Status",&q.status));impl->check(GRBgetintattr(m,"SolCount",&count));
    q.exhausted=q.status==GRB_INFEASIBLE;
    if(count) {
        Vector x(impl->data.n()+1);impl->check(GRBgetdblattrarray(m,"X",0,int(x.size()),x.data()));
        const double solver_t=x.back();x.pop_back();
        Json guard=validate_discrete_proposal(impl->data,x,impl->bound,impl->excluded,impl->dominance);
        int core_violations=0;
        for(const auto& row:impl->core_rows){int hit=0;for(int j:row.first)hit+=x[j]>1-1e-6;core_violations+=hit>row.second;}
        guard["violating_core_rows"]=core_violations;
        if(core_violations)throw std::runtime_error("Candidate violates certified core cut");
        guard["solver_epigraph"]=solver_t;
        if(!guard.at("valid").get<bool>())throw std::runtime_error("SOC discrete proposal validation failed: "+guard.dump());
        q.selection=guard.at("selection").get<Selection>();
        q.canonical_witness=canonical_soc_witness(impl->data,q.selection);
        if(impl->moment){auto mcheck=impl->moment->check(q.selection);q.canonical_witness["necessary_mean_bound_check"]=mcheck;
            if(!mcheck.at("within_registered_proposal_row_tolerance").get<bool>())throw std::runtime_error("Necessary mean proposal row violation: "+mcheck.dump());}

        q.cost=impl->data.cost_of(q.selection);q.norm=q.canonical_witness.at("canonical_t").get<double>();
        Vector means;for(int j:q.selection)means.push_back(impl->data.mean[j]);
        q.risk=sum(means)+impl->gamma*q.norm;q.epigraph=q.norm;
        q.canonical_witness["raw_solver_epigraph"]=solver_t;
        q.canonical_witness["legacy_epigraph_guard_would_reject"]=impl->gamma>0&&solver_t+1e-6<ellipsoid_norm(impl->data,q.selection);
        q.canonical_witness["discrete_proposal_guard"]=guard;
        q.has_candidate=true;q.cone_converged=true;
        q.canonical_witness["objective_order"]=impl->costfirst?"cost_then_ellipsoid_risk":"ellipsoid_risk_only";
        if(impl->costfirst){
            q.objective_bound_available=false;q.proxy_optimal=false;
            q.canonical_witness["bound_disclosure"]="Gurobi multi-objective ObjBound unavailable; no CCMCKP global bound claimed";
            q.canonical_witness["higher_priority_objective_abs_tol"]=0;
            q.canonical_witness["higher_priority_objective_rel_tol"]=0;
        }else{
            impl->check(GRBgetdblattr(m,"ObjBound",&q.objective_bound));
            q.proxy_optimal=q.status==GRB_OPTIMAL&&std::abs(q.risk-q.objective_bound)<=1e-7;
            q.canonical_witness["canonical_risk_minus_solver_bound"]=q.risk-q.objective_bound;
        }


    }
    q.seconds=now()-started;return q;
}
}
