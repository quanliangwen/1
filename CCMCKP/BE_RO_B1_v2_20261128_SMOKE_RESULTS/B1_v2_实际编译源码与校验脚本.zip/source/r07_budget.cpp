#include "search.hpp"
#include <numeric>
namespace s10 {
Groups Search::r07_budget_query(const mpq_class&gamma,bool fine){
 auto&c=*calibrated;const std::size_t qi=c.queries.size();c.queries.push_back({{"gamma",gamma.get_str()},{"stage",fine?"fine":"coarse"},{"solver_tasks",Json::array()},{"candidate_refs",Json::array()},{"safe_pruned",0},{"resource_infeasible",0},{"complete",false},{"CDF_monotonicity_claim",false}});
 struct Task{std::size_t index;CalibratedBudget::Bound bound;};std::vector<Task> tasks;std::vector<std::size_t> indices;
 if(fine){indices.resize(c.thresholds.size());std::iota(indices.begin(),indices.end(),0);}else indices=c.coarse;
 auto prune=[&](const Task&t){
  if(!fine||!best||t.bound.value<c.exact_cost(best->selection))return false;
  if(c.incumbent_recorded.insert(best->selection).second)c.incumbents.push_back(best->json());
  c.cost_cuts.push_back({{"gamma",gamma.get_str()},{"theta",c.thresholds[t.index].get_str()},{"lambda",t.bound.lambda.get_str()},{"dual_lower",t.bound.value.get_str()},{"incumbent_selection",best->selection},{"incumbent_exact_cost",c.exact_cost(best->selection).get_str()},{"current_run_integer_CDF_incumbent",true},{"strict_cheaper_exact_solution_preserved",true}});
  ++c.exact_cuts;c.queries[qi]["safe_pruned"]=c.queries[qi]["safe_pruned"].get<int>()+1;return true;
 };
 for(auto k:indices){check_budget();if(c.min_sums[k]+gamma*c.thresholds[k]>c.capacity-c.margin){c.queries[qi]["resource_infeasible"]=c.queries[qi]["resource_infeasible"].get<int>()+1;continue;}Task t{k,c.dual_bound(gamma,k)};if(!prune(t))tasks.push_back(t);}
 std::stable_sort(tasks.begin(),tasks.end(),[](const Task&a,const Task&b){return a.bound.value==b.bound.value?a.index<b.index:a.bound.value<b.bound.value;});
 std::set<Selection> unique;
 for(const auto&t:tasks){
  check_budget();if(prune(t))continue;const auto&theta=c.thresholds[t.index];auto weights=c.row(theta);std::vector<LinearRow> rows{{weights,-INFINITY,c.rhs(gamma,theta)}};Json incumbent=nullptr;
  if(fine&&best){mpq_class cap=c.exact_cost(best->selection)-mpq_class(1,1000000);rows.push_back({instance.costs,-INFINITY,BudgetRO::outward(cap,false)});incumbent={{"selection",best->selection},{"cost",c.exact_cost(best->selection).get_str()},{"strict_cap",cap.get_str()}};}
  Json excluded=Json::array();if(fine)for(const auto&q:c.record_index){const auto&state=c.proposals[q.second]["native_state"].get_ref<const std::string&>();if(state!="accepted"&&state!="infeasible")continue;Vector ng(instance.n());for(int j:q.first)ng[j]=1;rows.push_back({ng,-INFINITY,double(instance.m()-1)});excluded.push_back(q.second);}
  const double b=now();r07_launches.push_back({{"stage","stage1_es95"},{"kind","MIP"},{"start",b-started}});Json log;auto found=calibration_solver->solve(instance.costs,rows,std::max(.001,std::min(2.,remaining())),fine?15:1,.02,log);
  c.solver_seconds+=now()-b;++c.mip_count;c.raw_returned+=found.size();log["theta"]=theta.get_str();log["current_run_cost_cap"]=incumbent;log["excluded_proposal_indices"]=excluded;log["returned"]=found.size();c.queries[qi]["solver_tasks"].push_back(log);
  for(const auto&s:found){check_budget();auto w=c.witness(s,gamma,theta,fine?"R02_fine_RO":"R02_coarse_RO");if(!w["robust_feasible"].get<bool>()||!w["fixed_theta_feasible"].get<bool>()){c.queries[qi]["numerical_rejections"].push_back(w);continue;}++c.rational_returned;auto i=calibrated_register(s,gamma,theta,fine?"R02_fine_RO":"R02_coarse_RO");c.queries[qi]["candidate_refs"].push_back(i);unique.insert(s);}
 }
 auto out=cost_order(unique);int calls=0;
 if(fine)for(const auto&s:out){check_budget();if(r07_attempted.count(s)||pool.count(s))continue;if(best&&c.exact_cost(s)>c.exact_cost(best->selection)-mpq_class(1,1000000))continue;if(r07_fft->probability(s)<r07_gate())continue;
  ++calls;r07_native(s,"R02_fine_RO","stage1_es95_cdf");auto i=c.record_index.at(s);c.proposals[i]["native_state"]=pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown";c.proposals[i]["native_evaluation_completed"]=pool.count(s)||infeasible_proofs.count(s);
 }
 c.queries[qi]["complete"]=true;c.queries[qi]["fresh_native_calls"]=calls;return out;
}
void Search::r07_budget_search(){
 auto&c=*calibrated;c.metadata["localization_rounds"]=nullptr;c.metadata["relative_interval_tolerance"]="1/100";c.metadata["fine_threshold_limit_per_gamma"]=nullptr;c.metadata["pool_solutions"]=15;c.metadata["coarse_MIP_slice_seconds"]=2;c.metadata["fine_MIP_slice_seconds"]=2;
 if(c.mean_infeasible||c.gamma_max<=0)return;
 mpq_class lo=0,hi=c.gamma_max;int rounds=0;Selection lowvec,highvec=c.initial;
 while((hi-lo)/c.gamma_max>mpq_class(1,100)){
  auto mid=mpq_class((lo+hi)/2);auto found=r07_budget_query(mid,false);++rounds;c.queries.back()["lo_before"]=lo.get_str();c.queries.back()["hi_before"]=hi.get_str();
  if(found.empty()){c.queries.back()["localization_state"]="no_solver_candidate_not_infeasibility_proof";break;}
  const auto&s=found.front();r07_native(s,"R02_coarse_RO","stage1_es95_cdf");std::string state=pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown";auto i=c.record_index.at(s);c.proposals[i]["native_state"]=state;c.proposals[i]["native_evaluation_completed"]=state!="unknown";c.queries.back()["selected_proposal_index"]=i;c.queries.back()["localization_state"]=state;
  if(state=="accepted"){hi=mid;highvec=s;}else if(state=="infeasible"){lo=mid;lowvec=s;}else break;
  if(!lowvec.empty()&&lowvec==highvec){r07["gamma_stop_reason"]="same_bound_selection";break;}
 }
 c.metadata["gamma_bisect_lo"]=lo.get_str();c.metadata["gamma_bisect_hi"]=hi.get_str();c.metadata["gamma_bisect_rounds"]=rounds;
 mpq_class delta=std::max(mpq_class(hi-lo),mpq_class(c.gamma_max/50));std::vector<mpq_class> points{hi,mpq_class((lo+hi)/2),mpq_class(hi+delta),mpq_class(lo-delta),mpq_class(hi+2*delta)};std::set<mpq_class> seen;Json values=Json::array();r07["fine_points_completed"]=0;
 for(auto g:points){g=std::min(c.gamma_max,g);if(g<=0)continue;g.canonicalize();if(!seen.insert(g).second)continue;values.push_back(g.get_str());check_budget();r07_budget_query(g,true);r07["fine_points_completed"]=r07["fine_points_completed"].get<int>()+1;}
 c.metadata["fine_gamma_points"]=values;
}
}
