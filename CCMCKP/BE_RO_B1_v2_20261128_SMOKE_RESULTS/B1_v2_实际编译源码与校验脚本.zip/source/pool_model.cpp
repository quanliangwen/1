#include "pool_model.hpp"
#include "gurobi_budget.hpp"
#include <gurobi_c.h>
#include <cmath>
namespace s10 {
struct PoolModel::Impl {
 const Instance& d;int seed;
 struct FreeEnv{void operator()(GRBenv* p)const{GRBfreeenv(p);}};
 struct FreeModel{void operator()(GRBmodel* p)const{GRBfreemodel(p);}};
 std::unique_ptr<GRBenv,FreeEnv> env;
 void check(int rc,GRBenv* e){if(rc)throw std::runtime_error("PoolModel Gurobi "+std::to_string(rc)+":"+(e?GRBgeterrormsg(e):"environment"));}
 Groups solve(const Vector& obj,const std::vector<LinearRow>& rows,double seconds,int count,double gap,Json& log){
  double begin=now();check_budget();
  if(!env){GRBenv* p=nullptr;int rc=GRBemptyenv(&p);env.reset(p);check(rc,p);check(GRBsetintparam(p,"OutputFlag",0),p);check(GRBstartenv(p),p);}
  GRBmodel* raw=nullptr;auto costs=obj;std::vector<char> types(d.n(),GRB_BINARY);
  int rc=GRBnewmodel(env.get(),&raw,"calibrated_RO",d.n(),costs.data(),nullptr,nullptr,types.data(),nullptr);std::unique_ptr<GRBmodel,FreeModel> model(raw);check(rc,env.get());
  auto e=GRBgetenv(raw);auto ck=[&](int code){check(code,e);};
  ck(GRBsetcallbackfunc(raw,budget_callback,nullptr));ck(GRBsetintparam(e,"Threads",1));ck(GRBsetintparam(e,"Seed",seed));ck(GRBsetdblparam(e,"MIPGap",0));
  ck(GRBsetintparam(e,"PoolSearchMode",count>1?2:0));ck(GRBsetintparam(e,"PoolSolutions",count));ck(GRBsetdblparam(e,"PoolGap",gap));
  auto add=[&](const Selection& ids,const Vector& values,char sense,double rhs){ck(GRBaddconstr(raw,ids.size(),const_cast<int*>(ids.data()),const_cast<double*>(values.data()),sense,rhs,nullptr));};
  for(const auto& group:d.groups)add(group,Vector(group.size(),1),GRB_EQUAL,1);
  for(const auto& row:rows){Selection ids;Vector values;for(int j=0;j<d.n();++j)if(row.coefficients[j]){ids.push_back(j);values.push_back(row.coefficients[j]);}
   if(std::isfinite(row.lower))add(ids,values,GRB_GREATER_EQUAL,row.lower);if(std::isfinite(row.upper))add(ids,values,GRB_LESS_EQUAL,row.upper);}
  double allowance=std::min(seconds-(now()-begin),budget_left());Groups result;
  if(allowance>.001){ck(GRBsetdblparam(e,"TimeLimit",allowance));ck(GRBoptimize(raw));check_budget();
   int solutions=0,status=0;ck(GRBgetintattr(raw,"SolCount",&solutions));ck(GRBgetintattr(raw,"Status",&status));
   log={{"solver_status",status},{"solutions_retained",solutions},{"PoolSearchMode",count>1?2:0},{"PoolSolutions",count},{"PoolGap",gap},{"external_MIPstarts",false}};
   for(int k=0;k<solutions;++k){ck(GRBsetintparam(e,"SolutionNumber",k));Vector x(d.n());ck(GRBgetdblattrarray(raw,"Xn",0,d.n(),x.data()));Selection s;
    for(const auto& group:d.groups)s.push_back(*std::max_element(group.begin(),group.end(),[&](int a,int b){return x[a]<x[b];}));d.validate(s);result.push_back(s);}
  }else log={{"model_setup_exhausted_slice",true}};
  log["whole_subproblem_seconds"]=now()-begin;return result;
 }
};
PoolModel::PoolModel(const Instance& d,int seed):impl(new Impl{d,seed,{}}){}
PoolModel::~PoolModel()=default;
Groups PoolModel::solve(const Vector& o,const std::vector<LinearRow>& r,double seconds,int count,double gap,Json& log){return impl->solve(o,r,seconds,count,gap,log);}
}
