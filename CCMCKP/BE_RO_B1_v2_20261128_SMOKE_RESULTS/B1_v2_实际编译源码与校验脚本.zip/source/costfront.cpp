#include "costfront.hpp"
#include "gurobi_budget.hpp"
#include <cmath>
#include <set>
#include <numeric>
namespace s10 {
struct CostFrontMaster::Impl {
    const Instance& data;
    double gamma, cap, bound=std::numeric_limits<double>::infinity();
    GRBenv* env=nullptr;
    GRBmodel* model=nullptr;
    std::set<Selection> excluded;
    void check(int c) { if(c)throw std::runtime_error("Costfront Gurobi: "+std::to_string(c)+":"+(env?GRBgeterrormsg(env):"no env")); }
    Impl(const Instance& d,int seed,double g,double r,const Selection& start):data(d),gamma(g),cap(r) {
        if(!(g>=0 && std::isfinite(g) && std::isfinite(r)))throw std::invalid_argument("Invalid risk parameters");
        check(GRBemptyenv(&env));check(GRBsetintparam(env,"OutputFlag",0));check(GRBstartenv(env));
        const int vars=2*d.n()+1;
        Vector obj=d.costs;obj.resize(vars,0);
        Vector lo(vars,0),hi(vars,GRB_INFINITY);
        std::vector<char> types(vars,GRB_CONTINUOUS);
        for(int j=0;j<d.n();++j){hi[j]=1;types[j]=GRB_BINARY;}
        check(GRBnewmodel(env,&model,"EGS_cost_first_SOC",vars,obj.data(),lo.data(),hi.data(),types.data(),nullptr));
        auto* p=GRBgetenv(model);
        check(GRBsetintparam(p,"Threads",1));check(GRBsetintparam(p,"Seed",seed));
        check(GRBsetintparam(p,"NonConvex",0));check(GRBsetdblparam(p,"MIPGap",0));
        // Disaggregated rotated-cone presolve retains convex recognition after
        // no-good cuts fix binary variables (Gurobi 11 otherwise rejects a
        // degenerate presolved SOC). This does not enable nonconvex solving.
        check(GRBsetintparam(p,"PreMIQCPForm",2));
        check(GRBsetdblparam(p,"FeasibilityTol",1e-9));check(GRBsetdblparam(p,"IntFeasTol",1e-9));
        check(GRBsetcallbackfunc(model,budget_callback,nullptr));
        for(auto group:d.groups) {
            Vector v(group.size(),1);
            check(GRBaddconstr(model,int(group.size()),group.data(),v.data(),GRB_EQUAL,1,nullptr));
        }
        Selection idx(d.n());std::iota(idx.begin(),idx.end(),0);auto cost=d.costs;
        check(GRBaddconstr(model,d.n(),idx.data(),cost.data(),GRB_LESS_EQUAL,GRB_INFINITY,"improving_cost"));
        idx.push_back(d.n());auto risk=d.mean;risk.push_back(gamma);
        check(GRBaddconstr(model,d.n()+1,idx.data(),risk.data(),GRB_LESS_EQUAL,cap,"proposal_risk_cap"));
        // Lift u=diag(sd)x; keep the SOC entirely continuous so presolve does not
        // replace binary squares by linear terms and obscure convexity.
        Selection cone;Vector q;
        if(gamma>0) {
        for(int j=0;j<d.n();++j) {
            int link[]={j,d.n()+1+j};double v[]={-std::sqrt(d.variance[j]),1};
            check(GRBaddconstr(model,2,link,v,GRB_EQUAL,0,nullptr));
            cone.push_back(d.n()+1+j);q.push_back(1);
        }
        cone.push_back(d.n());q.push_back(-1);
        check(GRBaddqconstr(model,0,nullptr,nullptr,d.n()+1,cone.data(),cone.data(),q.data(),GRB_LESS_EQUAL,0,"native_SOC"));
        }
        check(GRBupdatemodel(model));
        if(!start.empty()) {
            d.validate(start);Vector x(vars,0);
            for(int j:start){x[j]=1;x[d.n()+1+j]=std::sqrt(d.variance[j]);}
            x[d.n()]=ellipsoid_norm(d,start);
            check(GRBsetdblattrarray(model,"Start",0,vars,x.data()));
        }
    }
    ~Impl(){if(model)GRBfreemodel(model);if(env)GRBfreeenv(env);}
};
CostFrontMaster::CostFrontMaster(const Instance& d,int s,double g,double cap,const Selection& start):impl(new Impl(d,s,g,cap,start)){}
CostFrontMaster::~CostFrontMaster()=default;
void CostFrontMaster::set_cost_bound(double b) {
    if(!std::isfinite(b)||b>impl->bound)throw std::invalid_argument("Cost bound may only tighten");
    impl->check(GRBsetdblattrelement(impl->model,"RHS",impl->data.m(),b));impl->bound=b;
}
bool CostFrontMaster::exclude_processed(const Selection& s) {
    impl->data.validate(s);if(!impl->excluded.insert(s).second)return false;
    auto i=s;Vector v(s.size(),1);
    impl->check(GRBaddconstr(impl->model,int(s.size()),i.data(),v.data(),GRB_LESS_EQUAL,impl->data.m()-1,nullptr));return true;
}
EllipsoidQuery CostFrontMaster::next_candidate(double seconds) {
    check_budget();EllipsoidQuery q;const double started=now();auto* m=impl->model;auto* p=GRBgetenv(m);
    impl->check(GRBsetdblparam(p,"TimeLimit",std::max(.001,std::min(seconds,budget_left()))));
    impl->check(GRBoptimize(m));check_budget();q.optimize_calls=1;
    int count=0;impl->check(GRBgetintattr(m,"Status",&q.status));impl->check(GRBgetintattr(m,"SolCount",&count));
    q.exhausted=q.status==GRB_INFEASIBLE;
    if(count) {
        Vector x(impl->data.n()+1);impl->check(GRBgetdblattrarray(m,"X",0,int(x.size()),x.data()));
        for(const auto& group:impl->data.groups) {
            int j=*std::max_element(group.begin(),group.end(),[&](int a,int b){return x[a]<x[b];});
            if(x[j]<1-1e-6)throw std::runtime_error("Nonintegral SOC candidate");
            q.selection.push_back(j);
        }
        q.cost=impl->data.cost_of(q.selection);q.norm=ellipsoid_norm(impl->data,q.selection);
        q.risk=ellipsoid_risk(impl->data,q.selection,impl->gamma);q.epigraph=x.back();
        if(q.risk>impl->cap+1e-6 || q.cost>impl->bound+1e-6 || impl->excluded.count(q.selection))
            throw std::runtime_error("SOC candidate violates checked proposal constraints");
        q.has_candidate=true;q.cone_converged=true;q.proxy_optimal=q.status==GRB_OPTIMAL;
        impl->check(GRBgetdblattr(m,"ObjBound",&q.objective_bound));
    }
    q.seconds=now()-started;return q;
}
}
