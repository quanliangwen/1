#pragma once
#include "be_ro_witness.hpp"
#include <memory>
namespace s10 {
class BEROSolver {
 struct Impl;std::unique_ptr<Impl> impl;
public:
 BEROSolver(const Instance&,const BEROWitness&,int);
 ~BEROSolver();
 Groups solve(const mpq_class& omega,double seconds,int count,bool feasibility,const std::set<Selection>& excluded,double cutoff,Json& log);
};
}
