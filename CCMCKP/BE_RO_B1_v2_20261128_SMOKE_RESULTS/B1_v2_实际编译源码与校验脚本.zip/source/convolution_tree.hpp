#pragma once
#include "fft.hpp"
#include <set>
namespace s10 {
// Nominal, floor-quantized ranking distributions. Overflow is discarded, never
// renormalized. FFT values are NOT probability certificates or pruning bounds.
class ConvolutionTree {
    const std::vector<Vector>& hist;
    Selection anchor;
    std::vector<Vector> nodes;
    int m, bins;
    bool valid=true;
    void build(int v,int l,int r) {
        check_budget();
        if(r-l==1) nodes[v]=hist[anchor[l]];
        else {int h=(l+r)/2;build(v*2,l,h);build(v*2+1,h,r);nodes[v]=convolve(nodes[v*2],nodes[v*2+1]);}
    }
    bool refresh(int v,int l,int r,const Selection& next) {
        if(r-l==1) {if(anchor[l]==next[l])return false;nodes[v]=hist[next[l]];return true;}
        int h=(l+r)/2;bool a=refresh(v*2,l,h,next),b=refresh(v*2+1,h,r,next);
        if(a||b)nodes[v]=convolve(nodes[v*2],nodes[v*2+1]);
        return a||b;
    }
    void collect(int v,int l,int r,const Selection& excluded,Vector& out,int& count) const {
        auto i=std::lower_bound(excluded.begin(),excluded.end(),l);
        if(i==excluded.end()||*i>=r) {out=count++?convolve(out,nodes[v]):nodes[v];return;}
        if(r-l==1)return;
        int h=(l+r)/2;collect(v*2,l,h,excluded,out,count);collect(v*2+1,h,r,excluded,out,count);
    }
public:
    ConvolutionTree(const std::vector<Vector>& h,Selection s):hist(h),anchor(std::move(s)),m(anchor.size()),bins(h.front().size()) {
        nodes.resize(4*m);build(1,0,m);
    }
    void update(const Selection& next) {
        if(next.size()!=anchor.size())throw std::logic_error("Tree anchor mismatch");
        try {
            if(valid)refresh(1,0,m,next);
            else {anchor=next;build(1,0,m);}
            anchor=next;valid=true;
        }catch(...){valid=false;throw;}
    }
    Vector complement(Selection block) const {
        check_budget();
        if(!valid)throw std::logic_error("Interrupted tree must be rebuilt");
        std::sort(block.begin(),block.end());
        if(std::adjacent_find(block.begin(),block.end())!=block.end()||(!block.empty()&&(block.front()<0||block.back()>=m)))throw std::logic_error("Invalid block");
        Vector out(bins);out[0]=1;int count=0;collect(1,0,m,block,out,count);return out;
    }
    const Selection& state()const{return anchor;}
};
}
