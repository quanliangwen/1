#include "be_ro_linear.hpp"
#include "gurobi_budget.hpp"
#include <gurobi_c.h>

namespace s10 {
struct BELinearSolver::Impl {
 const Instance&d;int seed;
 struct EDel{void operator()(GRBenv*p)const{GRBfreeenv(p);}};
 struct MDel{void operator()(GRBmodel*p)const{GRBfreemodel(p);}};
 std::unique_ptr<GRBenv,EDel>env;
 static void check(int rc,GRBenv*e){if(rc)throw std::runtime_error("BE linear Gurobi "+std::to_string(rc)+":"+(e?GRBgeterrormsg(e):"env"));}
 Groups solve(const BELinearRow&r,double seconds,int count,const std::set<Selection>&excluded,double cutoff,Json&log){
  const double begin=now();check_budget();
  log={{"model","BE_Linear_MCKP"},{"radius",r.omega.get_str()},{"lambda",r.lambda.get_str()},
   {"kind",r.kind},{"PoolSearchMode",count>1?2:0},{"PoolSolutions",count},{"time_limit",seconds},
   {"external_MIPstarts",false},{"no_good_count",excluded.size()},
   {"cost_cutoff",std::isfinite(cutoff)?Json(cutoff):Json(nullptr)},
   {"array_feasible",r.feasible},{"minimum_rounded_sum",r.minimum_rounded_sum.get_str()},
   {"rounded_rhs",mpq_class(r.rounded_rhs).get_str()},{"returned_rows",Json::array()}};
  if(!r.feasible){log["skipped"]="row_array_infeasible";return {};}
  if(!env){GRBenv*p=nullptr;int rc=GRBemptyenv(&p);env.reset(p);check(rc,p);check(GRBsetintparam(p,"OutputFlag",0),p);check(GRBstartenv(p),p);}
  const int n=d.n();Vector lb(n,0),ub(n,1),objective=d.costs;std::vector<char>type(n,GRB_BINARY);
  GRBmodel*m=nullptr;int rc=GRBnewmodel(env.get(),&m,"BE_Linear_MCKP",n,objective.data(),lb.data(),ub.data(),type.data(),nullptr);
  std::unique_ptr<GRBmodel,MDel>model(m);check(rc,env.get());auto*e=GRBgetenv(m);auto ck=[&](int z){check(z,e);};
  ck(GRBsetcallbackfunc(m,budget_callback,nullptr));ck(GRBsetintparam(e,"Threads",1));ck(GRBsetintparam(e,"Seed",seed));
  ck(GRBsetdblparam(e,"MIPGap",0));ck(GRBsetdblparam(e,"MIPGapAbs",0));
  ck(GRBsetdblparam(e,"FeasibilityTol",1e-9));ck(GRBsetdblparam(e,"IntFeasTol",1e-9));
  ck(GRBsetintparam(e,"PoolSearchMode",count>1?2:0));ck(GRBsetintparam(e,"PoolSolutions",count));
  ck(GRBsetdblparam(e,"PoolGap",GRB_INFINITY));
  auto add=[&](Selection ids,Vector v,char sense,double rhs){ck(GRBaddconstr(m,ids.size(),ids.data(),v.data(),sense,rhs,nullptr));};
  for(const auto&g:d.groups)add(g,Vector(g.size(),1),GRB_EQUAL,1);
  Selection ids(n);std::iota(ids.begin(),ids.end(),0);add(ids,r.rounded,GRB_LESS_EQUAL,r.rounded_rhs);
  for(const auto&s:excluded)add(s,Vector(s.size(),1),GRB_LESS_EQUAL,d.m()-1);
  if(std::isfinite(cutoff))add(ids,d.costs,GRB_LESS_EQUAL,cutoff);
  Groups result;int status=0,solutions=0,rejected=0;double bound=0;bool has_bound=false;
  double left=std::min(seconds-(now()-begin),budget_left());
  if(left>.001){
   ck(GRBsetdblparam(e,"TimeLimit",left));ck(GRBoptimize(m));
   ck(GRBgetintattr(m,"Status",&status));ck(GRBgetintattr(m,"SolCount",&solutions));
   has_bound=GRBgetdblattr(m,"ObjBound",&bound)==0&&std::isfinite(bound);
   for(int k=0;k<solutions;++k){
    ck(GRBsetintparam(e,"SolutionNumber",k));Vector x(n);ck(GRBgetdblattrarray(m,"Xn",0,n,x.data()));Selection s;
    for(const auto&g:d.groups)s.push_back(*std::max_element(g.begin(),g.end(),[&](int a,int b){return x[a]<x[b];}));
    d.validate(s);auto p=r.proof(s);p["selection"]=s;
    bool clean=p["row_feasible"].get<bool>()&&!excluded.count(s)&&(!std::isfinite(cutoff)||d.cost_of(s)<=cutoff);
    p["kept"]=clean;log["returned_rows"].push_back(p);
    if(clean)result.push_back(s);else ++rejected;
   }
  }
  std::sort(result.begin(),result.end(),[&](const Selection&a,const Selection&b){return std::make_pair(d.cost_of(a),a)<std::make_pair(d.cost_of(b),b);});
  result.erase(std::unique(result.begin(),result.end()),result.end());
  log["start_absolute"]=begin;log["whole_subproblem_seconds"]=now()-begin;
  log["solver_status"]=status;log["solutions_retained"]=solutions;log["distinct_returned"]=result.size();
  log["row_rejected"]=rejected;log["proven_row_infeasible"]=status==GRB_INFEASIBLE;
  log["optimal_status"]=status==GRB_OPTIMAL;log["objective_bound"]=has_bound?Json(bound):Json(nullptr);
  return result;
 }
};
BELinearSolver::BELinearSolver(const Instance&d,int seed):impl(new Impl{d,seed,{}}){}
BELinearSolver::~BELinearSolver()=default;
Groups BELinearSolver::solve(const BELinearRow&r,double t,int k,const std::set<Selection>&e,double c,Json&l){return impl->solve(r,t,k,e,c,l);}
}
