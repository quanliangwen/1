#pragma once
#include "evaluation.hpp"
#include <algorithm>
namespace s10 {
// Cost-conditioned stochastic optimistic envelopes. Each independent envelope
// may use the whole slack, so collectively overspending choices are allowed in
// the relaxation. Only a completed exact integer upper proof can prune a block.
class BlockBounds {
    const Instance& data;
    Instance virtual_data;
    std::vector<std::vector<std::pair<mpq_class,std::string>>> ordered;
    std::string capacity;
public:
    double spent=0;
    explicit BlockBounds(const Instance& d,std::string cap):data(d),virtual_data(d),capacity(std::move(cap)) {
        ordered.resize(d.n());
        for(int j=0;j<d.n();++j) {
            check_budget();for(const auto& x:d.decimals[j])ordered[j].push_back({rational_decimal(x),x});
            std::sort(ordered[j].begin(),ordered[j].end(),[](const auto&a,const auto&b){return a.first<b.first;});
        }
        virtual_data.decimals.resize(d.n()+d.m());
    }
    Json prove(const Selection& anchor,const Selection& block,double cost_cap) {
        Json out={{"status","unknown"},{"block",block},{"anchor",anchor},{"cost_cap",cost_cap}};
        if(spent>=3||budget_left()<5)return out;
        double start=now(),old=phase_deadline;
        struct Restore {double old;~Restore(){phase_deadline=old;}}restore{old};
        phase_deadline=std::min(old-1,start+.15);
        try {
            double outside=data.cost_of(anchor);Vector minima;
            for(int g:block){outside-=data.costs[anchor[g]];double c=std::numeric_limits<double>::infinity();for(int j:data.groups[g])c=std::min(c,data.costs[j]);minima.push_back(c);}
            double slack=cost_cap-outside-sum(minima);
            if(slack < -1e-7){out["status"]="cost_infeasible";return out;}
            Selection mixed=anchor;
            for(std::size_t h=0;h<block.size();++h) {
                check_budget();int g=block[h];Selection eligible;
                for(int j:data.groups[g])if(data.costs[j]-minima[h]<=slack+1e-7)eligible.push_back(j);
                if(eligible.empty())throw std::logic_error("Empty relaxed domain");
                auto& row=virtual_data.decimals[data.n()+g];row.clear();
                for(int k=0;k<data.sample_count;++k) {
                    auto value=ordered[eligible[0]][k];for(int j:eligible)if(ordered[j][k].first<value.first)value=ordered[j][k];row.push_back(value.second);
                }
                mixed[g]=data.n()+g;
            }
            ExactOracle oracle(virtual_data,capacity);auto count=oracle.count(mixed,128,false);
            out["upper"]=count.first.get_str();out["denominator"]=count.second.get_str();out["bins"]=128;
            out["status"]=count.first*100<count.second*99?"integer_probability_infeasible":"not_pruned";
        }catch(const BudgetExpired&){out["status"]="timeout_unknown";}
        spent+=now()-start;out["seconds"]=now()-start;return out;
    }
};
}
