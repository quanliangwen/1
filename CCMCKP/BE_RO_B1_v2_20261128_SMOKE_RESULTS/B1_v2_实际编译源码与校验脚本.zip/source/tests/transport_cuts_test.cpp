#include "transport_cuts.hpp"
#include "winf_product.hpp"
#include <functional>
#include <iostream>
using namespace s10;
int main(int argc,char**argv) {
 if(argc!=5)return 2;int checks=0,hits=0,compensated=0;
 auto require=[&](bool value){++checks;if(!value)throw std::runtime_error("D02 check "+std::to_string(checks));};
 for(int fi=1;fi<=3;++fi) {
  Instance d(argv[fi]);WinfProduct w(d,"1");ExactOracle oracle(w.shifted,"1");Groups selections;
  std::function<void(int,Selection)> enumerate=[&](int g,Selection s){if(g==d.m()){selections.push_back(s);return;}for(int j:d.groups[g]){auto q=s;q.push_back(j);enumerate(g+1,q);}};enumerate(0,{});
  auto exact=[&](const Selection& s){long good=0,total=0;std::function<void(int,mpq_class)> f=[&](int g,mpq_class v){if(g==d.m()){++total;if(v<1)++good;return;}for(auto& t:w.shifted.decimals[s[g]])f(g+1,v+rational_decimal(t));};f(0,0);mpq_class p(good,total);p.canonicalize();return p;};
  TransportCuts empty(w.shifted,4);for(const auto& s:selections)require(!empty.excludes(s,"cold_empty"));
  for(const auto& witness:selections) {
   const auto cert=oracle.certify(witness,65536);const auto py=exact(witness);
   require(mpq_class(cert.lower,cert.denominator)<=py&&mpq_class(cert.upper,cert.denominator)>=py);
   if(!cert.infeasible())continue;
   TransportCuts bank(w.shifted,4);bank.add_native(witness,cert);
   for(const auto& target:selections) {
    auto px=exact(target);bool excluded=bank.excludes(target,"enumerated_target");
    if(excluded){++hits;require(px<=py);require(px*100<99);auto proof=bank.evidence().back();mpz_class sum(proof["sum_floor_lower_units"].get<std::string>());require(sum>=0);
     bool negative=false;for(const auto& pair:proof["changed_pairs"]){mpz_class units(pair["floor_lower_units"].get<std::string>());negative|=units<0;}
     if(negative)++compensated;
    } else require(px>=0);
   }
  }
  // Mixed safe/unsafe rank distributions must not be ordered using means alone.
  if(fi==3){TransportCuts bank(w.shifted);auto c=oracle.certify({0},65536);require(c.infeasible());bank.add_native({0},c);require(!bank.excludes({1},"mean_is_not_order"));require(exact({1})==mpq_class(1,2));}
 }
 require(hits>0);require(compensated>0);
 // Out-of-int64 pair bounds become UNKNOWN, never an unsound cut.
 {Instance d(argv[4]);TransportCuts bank(d);Certificate c{0,0,2,64,0};bank.add_native({0},c);require(!bank.excludes({1},"overflow_unknown"));require(bank.statistics()["overflow_pairs_unknown"].get<int>()>0);}
 std::cout<<Json({{"status","PASS"},{"checks",checks},{"sound_inferred_exclusions",hits},{"aggregate_compensation_cases",compensated},{"no_probability_sampling",true},{"old_solution_inputs",false}}).dump()<<'\n';
}
