#include "corecuts.hpp"
#include "dominance.hpp"
#include "riskmaster.hpp"
#include <iostream>
#include <functional>
#include <set>
using namespace s10;
void need(bool b,const char* s){if(!b)throw std::runtime_error(s);}
int main(int argc,char**argv){try{
    need(argc==2,"fixture required");Instance d(argv[1]);ExactOracle o(d,"1");DominanceTable dt(d);CoreExtractor e(d,"1");
    Groups all;Selection v;std::function<void(int)> rec=[&](int g){if(g==d.m()){all.push_back(v);return;}for(int j:d.groups[g]){v.push_back(j);rec(g+1);v.pop_back();}};rec(0);
    Selection bad={0,2,4,6};auto proof=o.certify(bad,1000);need(proof.infeasible(),"bad vector should fail");auto c=e.reduce(bad,proof);
    need(c.groups==Selection({0,1})&&c.certificate.infeasible(),"expected irreducible pair core");
    auto worse=dt.worse_sets(bad);int preserved=0,removed=0;Groups safe;
    for(auto s:all){auto p=o.certify(s,1000);int brute=0;for(int mask=0;mask<16;++mask){mpq_class total=0;for(int g=0;g<4;++g)total+=rational_decimal(d.decimals[s[g]][(mask>>g)&1]);brute+=total<1;}need(p.lower==brute&&p.upper==brute&&p.denominator==16,"exact independent Cartesian count mismatch");int hit=0;for(int g:c.groups)hit+=std::find(worse[g].begin(),worse[g].end(),s[g])!=worse[g].end();
        if(hit==int(c.groups.size())){need(p.infeasible(),"false core cut");++removed;}if(p.accepted()){need(hit<int(c.groups.size()),"feasible vector lost");safe.push_back(s);++preserved;}}
    need(removed==4&&preserved>0,"expected many-vector coverage");
    RiskDominanceMaster m(d,960001,2.4,{},true,"1");m.set_cost_bound(100);need(m.add_core_cut(worse,c.groups),"new cut missing");need(!m.add_core_cut(worse,c.groups),"duplicate core");
    std::set<Selection> used;int rankings=0;
    for(;;){double best=1e100,risk=1e100;for(auto s:safe)if(!used.count(s)){double cc=d.cost_of(s),rr=ellipsoid_risk(d,s,2.4);if(cc<best-1e-8){best=cc;risk=rr;}else if(std::abs(cc-best)<1e-8)risk=std::min(risk,rr);}
        auto q=m.next_candidate(10);if(best==1e100){need(q.exhausted&&!q.has_candidate,"not exhausted");break;}
        need(q.has_candidate&&std::abs(q.cost-best)<1e-7&&std::abs(q.risk-risk)<1e-7,"wrong core-MIQCP projection");used.insert(q.selection);m.exclude_processed(q.selection);++rankings;}
    // Unsafe individual samples are never enough to justify a core: only the full upper count.
    bool refused=false;try{e.reduce(safe.front(),o.certify(safe.front(),1000));}catch(const std::logic_error&){refused=true;}need(refused,"accepted input not refused");
    // Timeout keeps a proved full-core fallback and restores caller's clock.
    double before=phase_deadline;e.spent=40;auto fallback=e.reduce(bad,proof);need(fallback.groups.size()==4&&phase_deadline==before,"fallback clock or proof lost");
    std::cout<<Json({{"status","PASS"},{"enumerated_vectors",all.size()},{"independent_sum_states",all.size()*16},{"feasible_vectors_preserved",preserved},{"vectors_removed_by_pair_core",removed},{"real_MIQCP_rankings",rankings},{"safe_certificate_refused",refused},{"budget_fallback",true}}).dump()<<'\n';return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
