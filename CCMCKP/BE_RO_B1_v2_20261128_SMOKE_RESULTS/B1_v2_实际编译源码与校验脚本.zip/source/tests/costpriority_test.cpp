#include "riskmaster.hpp"
#include "canonical.hpp"
#include "dominance.hpp"
#include <iostream>
using namespace s10;
void need(bool b,const char* e){if(!b)throw std::runtime_error(e);}
int main(int argc,char**argv){try{
 need(argc==2,"fixture");Instance d(argv[1]);Groups all;for(int a:d.groups[0])for(int b:d.groups[1])for(int c:d.groups[2])all.push_back({a,b,c});
 DominanceTable table(d);ExactOracle oracle(d,"1.5");std::map<Selection,bool> valid;for(auto s:all)valid[s]=oracle.certify(s,3072).accepted();
 bool distinguishing=false;for(auto a:all)for(auto b:all)if(d.cost_of(a)==d.cost_of(b)&&std::abs(ellipsoid_risk(d,a,2.4)-ellipsoid_risk(d,b,2.4))>1e-6)distinguishing=true;need(distinguishing,"fixture does not distinguish secondary objective");
 int checked=0;
 for(bool cuts:{false,true}){
  RiskDominanceMaster m(d,960001,2.4,{},true);m.set_cost_bound(100);std::set<Selection> used;
  if(cuts)for(auto s:all)if(!valid[s])m.add_dominance_cut(table.worse_sets(s));
  for(;;){double best=1e100,risk=1e100;for(auto s:all)if(!used.count(s)&&(!cuts||valid[s])){double c=d.cost_of(s),v=ellipsoid_risk(d,s,2.4);if(c<best-1e-9){best=c;risk=v;}else if(std::abs(c-best)<1e-9)risk=std::min(risk,v);}
   auto q=m.next_candidate(10);if(best==1e100){need(q.exhausted&&!q.has_candidate,"not exhausted");break;}
   need(q.has_candidate&&q.status==2,"hierarchical solve failed");need(std::abs(q.cost-best)<1e-7,"primary cost not minimum");need(std::abs(q.risk-risk)<1e-7,"secondary risk priority mismatch");
   need(!q.objective_bound_available&&!q.proxy_optimal,"unavailable bound misrepresented");need(q.canonical_witness.at("exact_canonical_SOC_feasible"),"invalid cone lift");used.insert(q.selection);m.exclude_processed(q.selection);++checked;
  }
 }
 std::cout<<Json({{"status","PASS"},{"native_lexicographic_rankings_with_and_without_CDF_cuts",checked},{"cost_is_primary",true},{"risk_is_secondary",true},{"no_objective_degradation_tolerance",true},{"no_unavailable_ObjBound_claim",true},{"new_probability_sampling",0}}).dump()<<'\n';return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
