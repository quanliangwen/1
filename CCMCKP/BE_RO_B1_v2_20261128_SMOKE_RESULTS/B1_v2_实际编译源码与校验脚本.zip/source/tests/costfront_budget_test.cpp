#include "costfront.hpp"
#include "report.hpp"
#include "evaluation.hpp"
#include <iostream>
#include <cmath>
#include <set>
using namespace s10;
void require(bool ok,const char* s){if(!ok)throw std::runtime_error(s);}
int main(int argc,char** argv) {
 try {
    if(argc!=3)throw std::runtime_error("fixture and output required");
    Instance d(argv[1]);require(d.m()==3 && d.n()==6,"wrong fixture");
    const auto original_costs=d.costs,original_mean=d.mean,original_var=d.variance;
    d.mean={.8,1.3,.6,1.8,.5,1.0};d.variance={.09,.001,.16,.002,.25,.003};d.costs={7,2,6,1,5,3};
    Groups all;for(int a:d.groups[0])for(int b:d.groups[1])for(int c:d.groups[2])all.push_back({a,b,c});
    int cases=0;
    for(double gamma:{0.,2.4,8.})for(double cap:{2.4,3.,4.,7.}) {
        CostFrontMaster m(d,960001,gamma,cap,{});m.set_cost_bound(100);std::set<Selection> used;
        for(;;) {
            double best=1e100;
            for(const auto& s:all)if(!used.count(s) && ellipsoid_risk(d,s,gamma)<=cap+1e-9)best=std::min(best,d.cost_of(s));
            EllipsoidQuery q;
            try { q=m.next_candidate(10); }
            catch(const std::exception& e) { throw std::runtime_error(std::string(e.what())+" gamma="+std::to_string(gamma)+" cap="+std::to_string(cap)+" used="+std::to_string(used.size())); }
            if(best==1e100) {require(q.exhausted&&!q.has_candidate,"wrong exhaustion");break;}
            require(q.has_candidate&&q.proxy_optimal&&q.cone_converged,"SOC not solved");
            require(std::abs(q.cost-best)<1e-6,"SOC optimum differs from exhaustive enumeration");
            require(ellipsoid_risk(d,q.selection,gamma)<=cap+1e-7,"risk cap violation");
            used.insert(q.selection);require(m.exclude_processed(q.selection),"exclusion missing");
            require(!m.exclude_processed(q.selection),"duplicate exclusion");++cases;
        }
    }
    { CostFrontMaster m(d,1,2.4,4.,all.front());m.set_cost_bound(7);auto q=m.next_candidate(10);
      if(q.has_candidate)require(q.cost<=7,"cost bound");
      bool fail=false;
      try{m.set_cost_bound(8);}catch(const std::invalid_argument&){fail=true;}require(fail,"cost loosened"); }
    d.costs=original_costs;d.mean=original_mean;d.variance=original_var;
    // Exact same LSS formula, cancelled evaluation must never return partial probability.
    LssEvaluator full(d,.5,7,100000);
    require(std::abs(full.evaluate(all.front())-.99803)<1e-12,"full-sample RNG/evaluator changed");
    LssEvaluator evaluator(d,.5,960001);phase_deadline=now()+.001;bool cancelled=false;
    try{evaluator.evaluate(all.front());}catch(const BudgetExpired&){cancelled=true;}
    require(cancelled,"LSS MC deadline did not cancel");phase_deadline=std::numeric_limits<double>::infinity();
    // A cancelled repeat neither overwrites the last complete verdict nor retries.
    fs::path out(argv[2]);fs::create_directories(out);int calls=0;
    Json shortlist=Json::array({{{"selection",all.front()}}});
    auto result=test_report(d,.5,960001,1,shortlist,[&](const Selection&){if(++calls==2)throw BudgetExpired();return .999;},out,now());
    require(calls==2 && result["evaluation_times"]==1,"censored evaluation was retried or counted complete");
    require(result["original_LSS_confidence"]==.999,"last completed verdict lost");
    const auto trace=read_json(out/"ORIGINAL_LSS_DECISION_TRACE.json");
    require(std::any_of(trace.begin(),trace.end(),[](const Json& e){return e["stage"]=="LSS_budget_censored";}),"missing censorship trace");
    std::cout<<Json({{"status","PASS"},{"SOC_exhaustive_cost_queries",cases},
      {"cancelled_LSS_has_no_probability",true},{"no_retry_on_censor",true},{"last_completed_LSS_retained",true}}).dump()<<'\n';return 0;
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
