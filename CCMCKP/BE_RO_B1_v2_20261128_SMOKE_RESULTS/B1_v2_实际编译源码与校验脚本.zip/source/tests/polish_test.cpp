#include "polish_fft.hpp"
#include "pool_model.hpp"
#include <iostream>
#include <functional>
using namespace s10;
int main(int argc,char**argv){
 int checks=0,mips=0;double maximum=0;
 auto require=[&](bool value){++checks;if(!value)throw std::runtime_error("R04 small mathematical check "+std::to_string(checks));};
 auto close=[&](double a,double b){maximum=std::max(maximum,std::abs(a-b));require(std::abs(a-b)<1e-6);};
 std::vector<Vector> rows(9);Groups groups{{0,1,2},{3,4,5},{6,7,8}};
 for(int j=0;j<9;++j)for(int k=0;k<5;++k)rows[j].push_back((j*2+k*3)%12);
 PolishFFT fft(rows,groups,32,32);
 auto direct=[&](const Selection&s){Vector distribution(1,1);
  for(int j:s){Vector next(distribution.size()+32);for(std::size_t i=0;i<distribution.size();++i)for(double a:rows[j])next[i+int(a)]+=distribution[i]/rows[j].size();distribution=next;}
  double total=0;for(int k=0;k<32&&k<int(distribution.size());++k)total+=distribution[k];return total;
 };
 for(int a:groups[0])for(int b:groups[1])for(int c:groups[2]){Selection s{a,b,c};close(fft.probability(s),direct(s));auto [p,m]=fft.marginals(s);close(p,direct(s));
  for(int g=0;g<3;++g)for(int j:groups[g]){auto x=s;x[g]=j;close(m[j],direct(x));}
  auto reverse=s;std::reverse(reverse.begin(),reverse.end());close(fft.probability(reverse),p);
 }
 {
  std::vector<Vector> raw(4,Vector{90});Groups g{{0},{1},{2},{3}};PolishFFT q(raw,g,128,128);
  double probability=q.probability({0,1,2,3});require(probability<1e-8);require(probability>=0); // Undamped circular convolution would wrap 360 to 104.
 }
 {
  PolishFFT q({Vector{0,33},Vector{0,33}},Groups{{0},{1}},32,32);close(q.probability({0,1}),.25);
  PolishFFT zero({Vector{0,16},Vector{0,16},Vector{0,16}},Groups{{0},{1},{2}},32,32);auto z=zero.marginals({0,1,2});close(z.first,.5);for(double p:z.second)close(p,.5);
 }
 bool rejected=false;try{PolishFFT q({Vector{-1}},Groups{{0}},32,32);}catch(const std::invalid_argument&){rejected=true;}require(rejected);
 if(argc!=2)throw std::runtime_error("Supply a tiny fixture directory");
 Instance d(argv[1]);PoolModel solver(d,1040001);Selection center;for(const auto&g:d.groups)center.push_back(g.front());
 for(int test=0;test<12;++test){
  Vector risk(d.n());for(int j=0;j<d.n();++j)risk[j]=((j+test)%5-2)*.01;
  int radius=1+test%int(d.groups.size());double rhs=(test%4-1)*.015;Vector trust(d.n());for(int j:center)trust[j]=1;
  std::vector<LinearRow> constraints{{risk,-std::numeric_limits<double>::infinity(),rhs},{trust,double(d.m()-radius),std::numeric_limits<double>::infinity()}};
  double best=std::numeric_limits<double>::infinity();Selection s;
  std::function<void(int)> enumerate=[&](int g){if(g==d.m()){double r=0;int dist=0;for(int k=0;k<d.m();++k){r+=risk[s[k]];dist+=s[k]!=center[k];}
    if(r<=rhs+1e-12&&dist<=radius)best=std::min(best,d.cost_of(s));return;}
   for(int j:d.groups[g]){s.push_back(j);enumerate(g+1);s.pop_back();}};enumerate(0);
  Json log;auto solutions=solver.solve(d.costs,constraints,5,10,1,log);++mips;
  if(!std::isfinite(best))require(solutions.empty());else{require(!solutions.empty());double found=std::numeric_limits<double>::infinity();
   for(const auto&x:solutions){double r=0;int dist=0;for(int k=0;k<d.m();++k){r+=risk[x[k]];dist+=x[k]!=center[k];}require(dist<=radius);require(r<=rhs+1e-7);found=std::min(found,d.cost_of(x));}close(found,best);}
 }
 std::cout<<Json({{"status","PASS"},{"checks",checks},{"actual_tiny_MIP",mips},{"max_FFT_direct_lattice_absolute_error",maximum},{"FFT_is_acceptance",false}}).dump()<<'\n';
}
