#include "convolution_tree.hpp"
#include "block_mitm.hpp"
#include "block_bounds.hpp"
#include "block_schedule.hpp"
#include <iostream>
#include <functional>
#include <cmath>
using namespace s10;
int main(int argc,char**argv) {
 if(argc!=2)return 2;
 Instance d(argv[1]);int checks=0;const int bins=32;
 auto ensure=[&](bool value){++checks;if(!value)throw std::runtime_error("B01 regression failed at "+std::to_string(checks));};
 std::vector<Vector> h(d.n(),Vector(bins));ExactOracle oracle(d,"1");
 for(int j=0;j<d.n();++j)for(int k:oracle.quantized(j,bins,false))if(k<bins)h[j][k]+=1./d.sample_count;
 Selection anchor;for(const auto&g:d.groups)anchor.push_back(g.front());
 ConvolutionTree tree(h,anchor);BlockBounds bound(d,"1");
 const auto probability=[&](const Selection&s){long good=0,total=0;std::function<void(int,double)>go=[&](int g,double x){if(g==d.m()){++total;if(x<1)++good;return;}for(double v:d.samples[s[g]])go(g+1,x+v);};go(0,0);return double(good)/total;};
 // Every nonadjacent complement, two incremental updates, all block pairs.
 for(int turn=0;turn<3;++turn) {
  if(turn){anchor[turn]=d.groups[turn].back();anchor[4]=d.groups[4][turn%2];tree.update(anchor);}
  for(int mask=0;mask<(1<<d.m());++mask) {
   Selection block;for(int g=0;g<d.m();++g)if(mask>>g&1)block.push_back(g);
   auto outside=tree.complement(block);Vector direct(bins);direct[0]=1;
   for(int g=0;g<d.m();++g)if(!(mask>>g&1))direct=convolve(direct,h[anchor[g]]);
   for(int k=0;k<bins;++k)ensure(std::abs(direct[k]-outside[k])<1e-11);
   if(block.size()<2||block.size()>4)continue;
   int cut=block.size()/2;Selection left(block.begin(),block.begin()+cut),right(block.begin()+cut,block.end());
   auto a=block_half(d,left,h);auto b=block_half(d,right,h);auto pairs=block_scores(a,b,outside);
   ensure(pairs.size()==std::size_t(1<<block.size()));
   for(const auto&p:pairs){Selection q=anchor;for(int i=0;i<int(left.size());++i)q[left[i]]=a[p.left].items[i];for(int i=0;i<int(right.size());++i)q[right[i]]=b[p.right].items[i];ensure(std::abs(p.probability-probability(q))<1e-10);}
   auto result=bound.prove(anchor,block,11);
   if(result["status"]=="integer_probability_infeasible"||result["status"]=="cost_infeasible") {
    for(const auto&p:pairs){Selection q=anchor;for(int i=0;i<int(left.size());++i)q[left[i]]=a[p.left].items[i];for(int i=0;i<int(right.size());++i)q[right[i]]=b[p.right].items[i];if(d.cost_of(q)<11-1e-8)ensure(probability(q)<.99);}
   }
  }
 }
 Vector gradient(d.n());for(int j=0;j<d.n();++j)gradient[j]=(j%3)*.01;
 auto schedule=block_schedule(d,anchor,gradient);std::set<Selection> unique;
 for(const auto&s:schedule){ensure(s.size()>=2&&s.size()<=4);ensure(unique.insert(s).second);}
 // Truncation must not wrap overflow back into the feasible region or normalize.
 Vector x(bins);x[24]=1;auto overflow=convolve(x,x);ensure(std::abs(sum(overflow))<1e-10);
 // Strict sum=T is unsafe, including mass in the final discretization bin.
 Selection boundary{1,3,4,6,8};ensure(probability(boundary)==0);
 // Floor <= original <= ceil stochastic bounds, exact integer certificates.
 for(int mask=0;mask<(1<<d.m());++mask){Selection q;for(int g=0;g<d.m();++g)q.push_back(d.groups[g][mask>>g&1]);auto lo=oracle.count(q,7,true),hi=oracle.count(q,7,false);double p=probability(q);ensure(mpq_class(lo.first,lo.second).get_d()<=p+1e-12);ensure(mpq_class(hi.first,hi.second).get_d()+1e-12>=p);}
 double old=phase_deadline;phase_deadline=now()-1;bool expired=false;try{tree.complement({1,3});}catch(const BudgetExpired&){expired=true;}phase_deadline=old;ensure(expired);
 // An interrupted incremental refresh invalidates the cache until a rebuild.
 auto changed=anchor;changed[0]=d.groups[0].back();phase_deadline=now()-1;
 expired=false;try{tree.update(changed);}catch(const BudgetExpired&){expired=true;}phase_deadline=old;ensure(expired);
 tree.update(anchor);auto rebuilt=tree.complement({1,3});Vector direct(bins);direct[0]=1;
 for(int g:{0,2,4})direct=convolve(direct,h[anchor[g]]);
 for(int k=0;k<bins;++k)ensure(std::abs(rebuilt[k]-direct[k])<1e-11);
 std::cout<<Json({{"status","PASS"},{"checks",checks},{"no_new_MC",true},{"exhaustive_atomic_distribution",true}}).dump()<<'\n';
}
