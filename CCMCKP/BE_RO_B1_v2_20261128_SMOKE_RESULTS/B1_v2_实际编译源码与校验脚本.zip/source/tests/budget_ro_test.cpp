#include "budget_ro.hpp"
#include "mip.hpp"
#include <functional>
#include <iostream>
#include <cmath>
using namespace s10;
int main(int argc,char**argv) {
    if(argc!=2)return 2;
    int checks=0,mips=0;
    auto require=[&](bool value){++checks;if(!value)throw std::runtime_error("R01 math check "+std::to_string(checks));};
    require(BudgetRO::protection({3,2,1},mpq_class(3,2))==4);
    require(BudgetRO::protection({3,2,1},mpq_class(0))==0);
    require(BudgetRO::protection({3,2,1},mpq_class(30))==6);
    for(auto q:{mpq_class(1,3),mpq_class(-1,3),mpq_class(0),mpq_class(1000000001L,7)}) {
        require(mpq_class(BudgetRO::outward(q,true))>=q);
        require(mpq_class(BudgetRO::outward(q,false))<=q);
    }
    Instance d(argv[1]);BudgetRO b(d,"1.25");Groups ss;
    std::function<void(int,Selection)> enumerate=[&](int g,Selection s){if(g==d.m()){ss.push_back(s);return;}for(int j:d.groups[g]){auto v=s;v.push_back(j);enumerate(g+1,v);}};enumerate(0,{});
    for(const auto& s:ss)for(auto gamma:{mpq_class(0),mpq_class(1,2),mpq_class(1),mpq_class(3,2),mpq_class(d.m())}) {
        auto w=b.worst(s,gamma);mpq_class best;bool first=true;
        for(const auto& theta:b.thresholds){auto v=b.theta_value(s,gamma,theta);require(v>=w);if(first||v<best){best=v;first=false;}}
        require(best==w); // exact finite-threshold equivalence, including fractional Gamma
        std::vector<mpq_class> ds;for(int j:s)ds.push_back(b.deviations[j]);
        // Independent adversarial vertex enumeration: floor(Gamma) full z,
        // one fractional z. Extra unused coefficients have zero objective.
        mpq_class vertex=-1;
        for(int mask=0;mask<(1<<d.m());++mask)for(int f=-1;f<d.m();++f) {
            int full=__builtin_popcount((unsigned)mask);if(full>gamma.get_d())continue;
            mpq_class frac=gamma-full;if(frac>1)frac=1;
            if(f>=0&&(mask>>f&1))continue;
            mpq_class val=0;for(int i=0;i<d.m();++i)if(mask>>i&1)val+=ds[i];
            if(f>=0)val+=frac*ds[f];
            if(val>vertex)vertex=val;
        }
        require(vertex==w-b.nominal(s));
    }
    // Real Gurobi fixed-threshold subproblems vs full tiny enumeration.
    BinaryModel model(d,1010001);
    for(const auto& gamma:b.gammas)for(const auto& theta:b.thresholds) {
        auto weights=b.row(theta);double rhs=b.rhs(gamma,theta);double exact_best=INFINITY;
        for(int j=0;j<d.n();++j){mpq_class exact=b.means[j];if(b.deviations[j]>theta)exact+=b.deviations[j]-theta;require(mpq_class(weights[j])>=exact);}
        require(mpq_class(rhs)<=b.capacity-b.margin-gamma*theta);
        for(const auto& s:ss)if(b.theta_value(s,gamma,theta)<=b.capacity-b.margin)exact_best=std::min(exact_best,d.cost_of(s));
        auto found=model.solve(d.costs,{{weights,-INFINITY,rhs}},2,1);++mips;
        require(found.empty()==!std::isfinite(exact_best));
        if(!found.empty()){require(std::abs(d.cost_of(found[0])-exact_best)<1e-10);require(b.worst(found[0],gamma)<=b.capacity-b.margin);}
        if(std::isfinite(exact_best))require(BudgetRO::rank(d,weights,rhs)<=exact_best+1e-7);
    }
    require(b.proposals.empty()&&b.generated.empty());
    require(!b.metadata["probability_coverage_claim"].get<bool>());
    std::cout<<Json({{"status","PASS"},{"checks",checks},{"real_tiny_MIP_subproblems",mips},{"independent_adversarial_vertex_enumeration",true},{"probability_sampling",false}}).dump()<<'\n';
}
