#include "canonical.hpp"
#include "riskmaster.hpp"
#include <iostream>
using namespace s10;
void need(bool b,const char* s){if(!b)throw std::runtime_error(s);}
int main(int argc,char** argv){try{
 need(argc==3,"fixtures");Instance d(argv[1]),z(argv[2]);Groups all;
 for(int a:d.groups[0])for(int b:d.groups[1])for(int c:d.groups[2])all.push_back({a,b,c});
 int exact=0;for(const auto& s:all){auto w=canonical_soc_witness(d,s);mpq_class v(w.at("sum_squared_sd_binary_rational").get<std::string>()),t(w.at("canonical_t").get<double>());need(t*t>=v,"inexact canonical cone");++exact;}
 auto w=canonical_soc_witness(z,{0,2,4});need(w.at("canonical_t")==0,"zero witness");
 Vector x(d.n(),0);Selection s={0,2,4};for(int j:s)x[j]=1;
 std::set<Selection> no,cuts;
 need(validate_discrete_proposal(d,x,100,no,cuts).at("valid"),"valid x rejected");
 // A fictitious solver auxiliary t=0 cannot invalidate this cap-free projected x.
 auto canon=canonical_soc_witness(d,s);need(canon.at("canonical_t").get<double>()>1e-6,"test not discriminating");
 need(!validate_discrete_proposal(d,x,1,no,cuts).at("valid").get<bool>(),"cost violation accepted");
 no.insert(s);need(!validate_discrete_proposal(d,x,100,no,cuts).at("valid").get<bool>(),"excluded accepted");no.clear();
 cuts.insert(s);need(!validate_discrete_proposal(d,x,100,no,cuts).at("valid").get<bool>(),"cut accepted");cuts.clear();
 x[1]=1;need(!validate_discrete_proposal(d,x,100,no,cuts).at("valid").get<bool>(),"onehot accepted");x[1]=.2;
 need(!validate_discrete_proposal(d,x,100,no,cuts).at("valid").get<bool>(),"fractional accepted");
 RiskDominanceMaster m(d,960001,2.4,{});m.set_cost_bound(100);std::set<Selection> used;int queries=0;
 for(;;){double best=1e100;for(const auto& a:all)if(!used.count(a))best=std::min(best,ellipsoid_risk(d,a,2.4));auto q=m.next_candidate(10);
 if(best==1e100){need(q.exhausted&&!q.has_candidate,"not exhausted");break;}
 need(q.has_candidate&&q.proxy_optimal&&std::abs(q.risk-best)<1e-6,"native optimum mismatch");
 need(q.canonical_witness.at("exact_canonical_SOC_feasible"),"missing exact witness");used.insert(q.selection);m.exclude_processed(q.selection);++queries;}
 std::cout<<Json({{"status","PASS"},{"exact_witnesses",exact},{"zero_variance",true},{"invalid_structure_checks",5},{"underreported_auxiliary_does_not_reject_valid_projection",true},{"native_projected_rankings",queries},{"no_probability_sampling",true}}).dump()<<'\n';return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
