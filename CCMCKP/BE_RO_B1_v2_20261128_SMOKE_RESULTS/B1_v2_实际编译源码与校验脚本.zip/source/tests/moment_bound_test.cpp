#include "moment_bound.hpp"
#include "riskmaster.hpp"
#include "dominance.hpp"
#include <iostream>
#include <set>
using namespace s10;
void need(bool b,const char* e){if(!b)throw std::runtime_error(e);}
int main(int argc,char**argv){try{
 need(argc==4,"priority, rare, decimal fixtures");Instance d(argv[1]);NecessaryMeanBound b(d,"1.5");Groups all;
 for(int a:d.groups[0])for(int c:d.groups[1])for(int e:d.groups[2])all.push_back({a,c,e});
 std::map<Selection,bool> feasible;int preserved=0,excluded=0;
 for(auto s:all){int count=0;for(double a:d.samples[s[0]])for(double c:d.samples[s[1]])for(double e:d.samples[s[2]])count+=(a+c+e<1.5);feasible[s]=count==8;
  bool valid=b.check(s).at("strictly_satisfies_row");if(feasible[s]){need(valid,"removed empirical99 feasible vector");++preserved;}excluded+=!valid;}
 need(preserved&&excluded,"test not discriminating");
 int queries=0;DominanceTable table(d);
 for(bool cuts:{false,true}){RiskDominanceMaster m(d,960001,2.4,{},true,"1.5");m.set_cost_bound(100);std::set<Selection> used;
  if(cuts)for(auto s:all)if(!feasible[s])m.add_dominance_cut(table.worse_sets(s));
  for(;;){double cost=1e100,risk=1e100;for(auto s:all)if(!used.count(s)&&b.check(s).at("strictly_satisfies_row").get<bool>()&&(!cuts||feasible[s])){double c=d.cost_of(s),r=ellipsoid_risk(d,s,2.4);if(c<cost-1e-9){cost=c;risk=r;}else if(std::abs(c-cost)<1e-9)risk=std::min(risk,r);}
   auto q=m.next_candidate(10);if(cost==1e100){need(q.exhausted&&!q.has_candidate,"not exhausted");break;}
   need(q.has_candidate&&q.status==2&&std::abs(q.cost-cost)<1e-7&&std::abs(q.risk-risk)<1e-7,"MIQCP projection enumeration mismatch");
   need(q.canonical_witness.at("necessary_mean_bound_check").at("strictly_satisfies_row"),"proposal violates exact mean row");used.insert(q.selection);m.exclude_processed(q.selection);++queries;}
 }
 Instance rare(argv[2]);NecessaryMeanBound rb(rare,".5");need(rare.mean[0]>.5,"rare test does not exceed capacity mean");need(rb.check({0}).at("strictly_satisfies_row"),"wrongly imposed mean<=T");int success=0;for(double x:rare.samples[0])success+=x<.5;need(success==99&&rare.sample_count==100,"rare test must be99/100");
 {RiskDominanceMaster m(rare,1,2.4,{},true,".5");m.set_cost_bound(100);auto q=m.next_candidate(10);need(q.has_candidate&&q.selection==Selection{0},"lost rare-tail feasible cheapest vector");++queries;}
 Instance near(argv[3]);NecessaryMeanBound nb(near,"1.00000000000000001");need(nb.vmax==0,"zero variance lost");need(mpq_class(nb.rhs)>=rational_decimal("1.00000000000000001"),"capacity rounded inward");
 for(auto q:{mpq_class(1,10),mpq_class(-1,10),mpq_class(1,3)}){need(mpq_class(rational_round_down(q))<=q,"inward mean coefficient");need(mpq_class(rational_round_up(q))>=q,"inward RHS");}
 const auto tiny=rational_decimal("1e-400");double small=rational_sqrt_round_up(tiny);need(small>0&&mpq_class(small)*mpq_class(small)>=tiny,"underflowed exact square root");
 need(mpq_class(b.root_upper)*mpq_class(b.root_upper)>=b.vmax/99,"sqrt upper not exact");
 std::cout<<Json({{"status","PASS"},{"empirical99_vectors_preserved",preserved},{"obviously_infeasible_vectors_removed",excluded},{"real_hierarchical_MIQCP_rankings",queries},{"rare_tail99_with_mean_above_T_preserved",true},{"zero_variance",true},{"exact_decimal_and_signed_rounding",true},{"new_MC_evaluations",0}}).dump()<<'\n';return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
