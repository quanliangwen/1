#include "dominance.hpp"
#include "riskmaster.hpp"
#include <cmath>
#include <iostream>
#include <set>
using namespace s10;
void need(bool b,const char* reason){if(!b)throw std::runtime_error(reason);}
int main(int argc,char** argv) {
 try {
    need(argc==3,"Need finite and exact-decimal fixtures");Instance d(argv[1]);DominanceTable table(d);
    need(d.m()==3&&d.n()==6&&d.sample_count==2,"wrong tiny fixture");
    Groups all;for(int a:d.groups[0])for(int b:d.groups[1])for(int c:d.groups[2])all.push_back({a,b,c});
    std::map<Selection,int> counts;std::map<Selection,Certificate> bad;ExactOracle oracle(d,"1.5");
    for(const auto& s:all) {
        int count=0;for(double a:d.samples[s[0]])for(double b:d.samples[s[1]])for(double c:d.samples[s[2]])count+=(a+b+c<1.5);
        // 3072 is divisible by 6, aligning quarter samples / capacity1.5 exactly.
        counts[s]=count;const auto proof=oracle.certify(s,3072);
        need(proof.lower==count&&proof.upper==count&&proof.denominator==8,"CDF bound mismatch with exhaustive raw sums");
        if(proof.infeasible())bad.emplace(s,proof);
    }
    int checked=0,strong=0;
    for(const auto& entry:bad) {
        const auto groups=table.worse_sets(entry.first);int covered=0;
        for(const auto& s:all) {
            bool all_worse=true;
            for(int g=0;g<3;++g)all_worse &= std::find(groups[g].begin(),groups[g].end(),s[g])!=groups[g].end();
            if(all_worse){need(counts[s]*100<8*99,"FOSD cut removed an empirically feasible vector");++covered;}
            ++checked;
        }
        strong+=covered>1;
    }
    need(strong>0,"No cut was stronger than a single-vector exclusion");
    int rankings=0;
    for(bool cuts:{false,true}) {
        RiskDominanceMaster master(d,960001,2.4,{});master.set_cost_bound(100);std::set<Selection> used;
        if(cuts)for(const auto& entry:bad)master.add_dominance_cut(table.worse_sets(entry.first));
        for(;;) {
            double best=1e100;
            for(const auto& s:all)if(!used.count(s)&&(!cuts||counts[s]==8))best=std::min(best,ellipsoid_risk(d,s,2.4));
            const auto q=master.next_candidate(10);
            if(best==1e100){need(q.exhausted&&!q.has_candidate,"domain did not exhaust");break;}
            need(q.has_candidate&&q.proxy_optimal&&q.cone_converged,"SOC did not solve tiny proxy");
            need(std::abs(q.risk-best)<1e-6,"native risk objective differs from exhaustive enumeration");
            need(!cuts || counts[q.selection]==8,"master violated a dominance cut");
            need(q.epigraph+1e-7>=q.norm,"SOC epigraph invalid");used.insert(q.selection);master.exclude_processed(q.selection);++rankings;
        }
    }
    Instance near(argv[2]);DominanceTable exact(near);
    need(std::stod(near.decimals[0][0])==std::stod(near.decimals[1][0]),"fixture should round to the same double");
    need(rational_decimal(near.decimals[0][0])>rational_decimal(near.decimals[1][0]),"exact decimal comparison lost distinction");
    need(std::find(exact.worse(0).begin(),exact.worse(0).end(),1)==exact.worse(0).end(),"rounded-double false dominance");
    need(std::find(exact.worse(1).begin(),exact.worse(1).end(),0)!=exact.worse(1).end(),"missing exact dominance");
    {RiskDominanceMaster zero(near,1,2.4,{});zero.set_cost_bound(100);auto q=zero.next_candidate(10);need(q.has_candidate&&q.norm==0,"zero-variance SOC failed");}
    std::cout<<Json({{"status","PASS"},{"exact_empirical_sums_checked",64},{"proof_vector_cut_checks",checked},
        {"stronger_than_single_vector_cuts",strong},{"native_risk_rank_queries",rankings},
        {"decimal_rounding_safety",true},{"zero_variance",true},{"no_Monte_Carlo_in_cut_test",true}}).dump()<<'\n';
    return 0;
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
