#include "winf_product.hpp"
#include <iostream>
#include <functional>
using namespace s10;
int main(int argc,char**argv) {
 if(argc!=2)return 2;
 Instance d(argv[1]);WinfProduct w(d,"1");int checks=0;
 auto require=[&](bool v){++checks;if(!v)throw std::runtime_error("D01 math check failed "+std::to_string(checks));};
 mpz_class scale("1000000000000");
 for(int j=0;j<d.n();++j) {
  mpq_class square=w.variances[j]*scale*scale/(10000L*d.sample_count);mpz_class u=w.radius_units[j];
  require(mpq_class(u*u)>=square);
  require(u==0?square==0:mpq_class((u-1)*(u-1))<square);
  for(int k=0;k<d.sample_count;++k) {
   mpq_class old=rational_decimal(d.decimals[j][k]),shifted=rational_decimal(w.shifted.decimals[j][k]);
   mpq_class expected(u,scale);expected.canonicalize();
   if(shifted-old!=expected)std::cerr<<"shift mismatch: "<<mpq_class(shifted-old).get_str()<<" vs "<<expected.get_str()<<'\n';
   require(shifted-old==expected);
  }
 }
 auto exact=[&](const Selection&s,bool shifted) {
  long good=0,total=0;
  std::function<void(int,mpq_class)>go=[&](int g,mpq_class sum) {
   if(g==d.m()){++total;if(sum<1)++good;return;}
   for(const auto& text:(shifted?w.shifted:d).decimals[s[g]])go(g+1,sum+rational_decimal(text));
  };go(0,0);mpq_class result(good,total);result.canonicalize();return result;
 };
 std::vector<Selection> selections;
 std::function<void(int,Selection)>enumerate=[&](int g,Selection s){if(g==d.m()){selections.push_back(s);return;}for(int j:d.groups[g]){auto next=s;next.push_back(j);enumerate(g+1,next);}};enumerate(0,{});
 double nominal_best=1e30,dro_best=1e30;int changed=0;
 for(const auto& s:selections) {
  auto p=exact(s,false),worst=exact(s,true);require(worst<=p);if(worst<p)++changed;
  if(p*100>=99)nominal_best=std::min(nominal_best,d.cost_of(s));
  if(worst*100>=99)dro_best=std::min(dro_best,d.cost_of(s));
  // Independent finite transport witness: every base product atom may choose
  // any corner of its coordinate box. The all-up corner attains max violation.
  long max_unsafe=0,atoms=0;
  std::function<void(int,mpq_class)>base=[&](int g,mpq_class total) {
   if(g==d.m()) {
    ++atoms;bool reachable=false;
    for(int mask=0;mask<(1<<d.m());++mask) {
     mpq_class value=total;
     for(int h=0;h<d.m();++h){mpq_class radius(w.radius_units[s[h]],scale);radius.canonicalize();value+=(mask>>h&1?1:-1)*radius;}
     if(value>=1)reachable=true;
     require(value<=total+w.shift(s));
    }
    if(reachable)++max_unsafe;
    return;
   }
   for(const auto& text:d.decimals[s[g]])base(g+1,total+rational_decimal(text));
  };base(0,0);mpq_class fraction(max_unsafe,atoms);fraction.canonicalize();require(1-fraction==worst);
  for(int bins:{64,4096,65536}) {
   auto cert=w.oracle->certify(s,bins);
   require(mpq_class(cert.lower,cert.denominator)<=worst);
   require(mpq_class(cert.upper,cert.denominator)>=worst);
   if(cert.accepted())require(worst*100>=99);
   if(cert.infeasible())require(worst*100<99);
  }
 }
 require(changed>0);require(nominal_best==3);require(dro_best==4);
 // The adversary is allowed outside the observed support, unlike a fixed-atom
 // reweighting model. Verify the declared translated mass reaches that region.
 require(rational_decimal(w.shifted.decimals[0].back())>rational_decimal(d.decimals[0].back()));
 Selection s{0,2,4};mpq_class boundary=rational_decimal(d.decimals[0].back())+rational_decimal(d.decimals[2][0])+rational_decimal(d.decimals[4][0])+w.shift(s);
 std::string cap=WinfProduct::finite_decimal(boundary);require(rational_decimal(cap)==boundary);
 ExactOracle at_boundary(w.shifted,cap);auto cert=at_boundary.certify(s,65536);
 // A floor grid can include exact-boundary atoms in its upper bound. Unknown
 // is legitimate; the required property is never to ACCEPT the unsafe atom.
 require(!cert.accepted());
 require(mpq_class(cert.lower,cert.denominator)<=mpq_class(1,2));
 require(mpq_class(cert.upper,cert.denominator)>=mpq_class(1,2));
 std::cout<<Json({{"status","PASS"},{"checks",checks},{"nominal_best",nominal_best},{"DRO_best",dro_best},{"feasibility_changed",true},{"closed_unsafe_boundary_checked",true},{"new_MC_calls",0}}).dump()<<'\n';
}
