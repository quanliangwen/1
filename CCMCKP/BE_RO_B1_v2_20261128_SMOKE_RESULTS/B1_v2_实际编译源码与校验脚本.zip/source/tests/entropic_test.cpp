#include "entropic_model.hpp"
#include "pool_model.hpp"
#include <functional>
#include <iostream>
#include <cmath>
using namespace s10;
int main(int argc,char**argv){
 if(argc!=2)return 2;int checks=0,mips=0;Json scalar=Json::array(),weights=Json::array();
 auto need=[&](bool v){++checks;if(!v)throw std::runtime_error("R03b check "+std::to_string(checks));};
 const auto& Q=EntropicMath::scale();
 for(const char* text:{"0","1/10","1/2","1","3","30","70"}){
  mpq_class x(text);auto y=EntropicMath::exp_negative(x);need(y.lower>=0&&y.upper>=y.lower&&y.upper<=Q);
  if(x==0)need(y.lower==Q&&y.upper==Q);
  scalar.push_back({{"function","exp_negative"},{"x",x.get_str()},{"lower_units",y.lower.get_str()},{"upper_units",y.upper.get_str()}});
 }
 for(const char* text:{"1/500","1/3","1","2","100"}){
  mpq_class x(text);auto y=EntropicMath::log_positive(x);need(y.lower<=y.upper);if(x==1)need(y.lower==0&&y.upper==0);
  scalar.push_back({{"function","log"},{"x",x.get_str()},{"lower_units",y.lower.get_str()},{"upper_units",y.upper.get_str()}});
 }
 for(const auto& values:std::vector<std::vector<mpq_class>>{{0,0},{1,1},{0,1},{mpq_class(1,10),mpq_class(7,10)},{0,10}}){
  mpq_class previous=-1;
  for(const auto& t:std::vector<mpq_class>{mpq_class(1,10),mpq_class(4,25),mpq_class(1,4),mpq_class(2,5),mpq_class(3,5),mpq_class(17,20)}){
   auto w=EntropicMath::weight(values,t);need(w.first<=w.second);need(w.second>=previous);need(w.first>=*std::min_element(values.begin(),values.end()));need(w.second<=*std::max_element(values.begin(),values.end()));previous=w.first;
   Json a=Json::array();for(const auto& v:values)a.push_back(v.get_str());weights.push_back({{"values",a},{"t",t.get_str()},{"lower",w.first.get_str()},{"upper",w.second.get_str()}});
  }
 }
 Instance d(argv[1]);EntropicModel e(d,"3");Groups all;
 std::function<void(int,Selection)> en=[&](int g,Selection s){if(g==d.m()){all.push_back(s);return;}for(int j:d.groups[g]){auto a=s;a.push_back(j);en(g+1,a);}};en(0,{});
 PoolModel solver(d,1030001);
 for(int k=0;k<6;++k){const auto& tab=e.prepare(k);need(tab.index==k&&tab.upper.size()==std::size_t(d.n()));
  for(int j=0;j<d.n();++j){need(tab.lower[j]<=tab.upper[j]);mpq_class mean=0;for(const auto& a:e.samples[j])mean+=a;mean/=d.sample_count;need(tab.upper[j]>=mean);}
  if(tab.eta_max<e.eta_floor)continue;
  need(e.witness(tab.initial,k,tab.eta_max,"test")["entropic_upper_feasible"].get<bool>());
  for(auto eta:std::vector<mpq_class>{e.eta_floor,tab.eta_max,mpq_class((e.eta_floor+tab.eta_max)/2)}){
   eta.canonicalize();auto rhs=e.bound_rhs(tab,eta);auto bound=e.dual_bound(tab,eta);Vector row;for(const auto& w:tab.upper)row.push_back(BudgetRO::outward(w,true));
   Json log;auto got=solver.solve(d.costs,{{row,-INFINITY,BudgetRO::outward(rhs,false)}},2,25,10,log);++mips;
   std::set<Selection> exact,verified;
   for(const auto& s:all)if(e.witness(s,k,eta,"test")["entropic_upper_feasible"].get<bool>()){exact.insert(s);need(bound.value<=e.exact_cost(s));}
   for(const auto& s:got)if(e.witness(s,k,eta,"test")["entropic_upper_feasible"].get<bool>())verified.insert(s);
   need(exact==verified);need(log["external_MIPstarts"]==false);
  }
 }
 need(!e.metadata["fixed_radius_KL_ball_claim"].get<bool>()&& !e.metadata["population_probability_coverage_claim"].get<bool>());
 need(e.proposals.empty()&&e.generated.empty());double saved=phase_deadline;phase_deadline=now()-1;bool caught=false;
 try{check_budget();}catch(const BudgetExpired&){caught=true;}phase_deadline=saved;need(caught);
 std::cout<<Json({{"status","PASS"},{"checks",checks},{"real_tiny_MIP",mips},{"precision_bits",EntropicMath::bits},{"scalar_cases",scalar},{"weight_cases",weights},{"eta_cap",e.eta_cap.get_str()},{"extra_probability_sampling",false}}).dump()<<'\n';
}
