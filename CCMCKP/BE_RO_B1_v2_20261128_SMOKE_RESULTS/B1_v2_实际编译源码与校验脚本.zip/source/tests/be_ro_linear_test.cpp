// PREPARED ONLY: not compiled or executed in the 2026-11-28 code-only task.
#include "be_ro_linear.hpp"
#include <iostream>
using namespace s10;
int main(int argc,char**argv){
 try{
  if(argc!=3)return 2;
  phase_deadline=now()+90;Instance d(argv[1]);BEROWitness w(d,argv[2]);BELinearMath math(d,w);BELinearSolver solver(d,1289901);
  Groups combinations{{}};
  for(const auto&g:d.groups){
   if(combinations.size()*g.size()>4096)throw std::runtime_error("Tiny enumeration only");
   Groups next;for(const auto&s:combinations)for(int j:g){auto a=s;a.push_back(j);next.push_back(a);}combinations=next;
  }
  // Known one-atom Huber identities, including zero variance/deviation.
  if(BELinearMath::huber(4,1,1)!=mpq_class(3,4)||BELinearMath::huber(4,1,mpq_class(1,4))!=mpq_class(15,16))
   throw std::logic_error("Huber identity");
  if(BELinearMath::huber(0,0,1)!=0||BELinearMath::huber(1,0,1)!=0)throw std::logic_error("Zero variance/deviation");
  Json tests=Json::array();
  for(const char*t:{"0","1/2","1","2","8"}){
   mpq_class omega(t);auto lambdas=math.grid(omega,10);
   std::vector<BELinearRow>rows;for(const auto&lambda:lambdas)rows.push_back(math.row(omega,lambda));rows.push_back(math.row(omega,0,true));
   for(const auto&r:rows){
    double exhaustive=INFINITY;Json enumeration=Json::array();
    for(const auto&s:combinations){
     auto p=r.proof(s);auto kkt=w.evaluate(s,omega);
     // Identity is an upper bound for every fixed positive lambda, even when
     // the row is infeasible. Directed KKT width is at most one 208-bit unit.
     mpq_class lhs(p["exact_lhs"].get<std::string>());
     mpq_class support_upper=lhs+(r.kind=="lambda_huber"?mpq_class(r.lambda*omega*omega):mpq_class(0));
     if(support_upper<mpq_class(kkt["worst_lower"].get<std::string>()))throw std::logic_error("Invalid dual bound");
     if(p["row_feasible"].get<bool>()){
      if(!kkt["robust_feasible"].get<bool>())throw std::logic_error("Row is not conservative");
      exhaustive=std::min(exhaustive,d.cost_of(s));
     }
     enumeration.push_back({{"selection",s},{"row",p},{"witness",kkt}});
    }
    Json log;auto found=solver.solve(r,2.,10,{},INFINITY,log);double best=INFINITY;
    for(const auto&s:found)best=std::min(best,d.cost_of(s));
    if(std::isfinite(exhaustive)!=std::isfinite(best)||(std::isfinite(best)&&std::abs(exhaustive-best)>1e-10))
     throw std::logic_error("Fixed-row MILP versus enumeration mismatch");
    // Deliberately do not require a finite grid to reproduce the full BE optimum.
    tests.push_back({{"kind",r.kind},{"omega",omega.get_str()},{"lambda",r.lambda.get_str()},
     {"enumeration",enumeration},{"solver",log},{"best",std::isfinite(best)?Json(best):Json(nullptr)}});
   }
  }
  std::cout<<Json({{"status","PASS"},{"tests",tests},{"finite_grid_exactness_claim",false}}).dump()<<'\n';return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}
}
