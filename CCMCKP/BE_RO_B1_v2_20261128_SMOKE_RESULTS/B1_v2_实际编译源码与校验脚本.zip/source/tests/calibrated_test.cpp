#include "calibrated_budget.hpp"
#include "pool_model.hpp"
#include <functional>
#include <iostream>
#include <cmath>
using namespace s10;
int main(int argc,char** argv){
 if(argc!=2)return 2;int checks=0,mips=0;
 auto need=[&](bool v){++checks;if(!v)throw std::runtime_error("R02 check "+std::to_string(checks));};
 need(CalibratedBudget::tail_mean({1,2,3,4},mpq_class(3,2))==mpq_class(11,3));
 need(CalibratedBudget::tail_mean({1,2,3,4},mpq_class(4))==mpq_class(5,2));
 need(CalibratedBudget::tail_mean({1,2,3,4},mpq_class(1,5))==4);
 Instance d(argv[1]);Groups all;
 std::function<void(int,Selection)> en=[&](int g,Selection s){if(g==d.m()){all.push_back(s);return;}for(int j:d.groups[g]){auto a=s;a.push_back(j);en(g+1,a);}};en(0,{});
 for(const auto& cap:{"0.01","0.6","0.600000011","1.25","3"}){
  CalibratedBudget c(d,cap);mpq_class independently_max=0;bool feasible=false;
  for(const auto& s:all){
   mpq_class nominal=0;std::vector<mpq_class> dev;
   for(int j:s){nominal+=c.means[j];dev.push_back(c.deviations[j]);}
   std::sort(dev.begin(),dev.end(),std::greater<mpq_class>());
   mpq_class remain=c.capacity-c.margin-nominal,g=0;
   if(remain<0)continue;feasible=true;
   for(auto v:dev){if(v==0){g+=1;continue;}if(remain>=v){remain-=v;g+=1;}else{g+=remain/v;break;}}
   if(g>independently_max)independently_max=g;
  }
  independently_max.canonicalize();need(c.mean_infeasible==!feasible);need(c.gamma_max==independently_max);
  if(c.gamma_max>0){need(c.worst(c.initial,c.gamma_max)<=c.capacity-c.margin);need(c.theta_value(c.initial,c.gamma_max,c.initial_theta)<=c.capacity-c.margin);need(c.gamma_floor>0&&c.gamma_floor<=c.gamma_max);}
  for(const auto& gamma:{mpq_class(0),mpq_class(1,2),mpq_class(1),mpq_class(3,2),mpq_class(2)})for(std::size_t k=0;k<c.thresholds.size();++k){
   auto bound=c.dual_bound(gamma,k);need(bound.lambda>=0);
   for(const auto& s:all){
    auto worst=c.worst(s,gamma);mpq_class least=c.theta_value(s,gamma,0);
    for(const auto& t:c.thresholds)least=std::min(least,c.theta_value(s,gamma,t));need(least==worst);
    if(c.theta_value(s,gamma,c.thresholds[k])<=c.capacity-c.margin)need(bound.value<=c.exact_cost(s));
   }
  }
 }
 CalibratedBudget c(d,"1.25");PoolModel solver(d,1020001);
 for(const auto& gamma:{mpq_class(1,2),mpq_class(1),mpq_class(3,2)})for(const auto& theta:c.thresholds){
  Json log;auto found=solver.solve(d.costs,{{c.row(theta),-INFINITY,c.rhs(gamma,theta)}},2,25,10,log);++mips;
  std::set<Selection> unique(found.begin(),found.end());need(unique.size()==found.size());
  // Gurobi's feasibility tolerance can admit a vector within 1e-6 of a row.
  // Production applies the exact rational guard before any CDF evaluation.
  for(auto it=unique.begin();it!=unique.end();){if(c.theta_value(*it,gamma,theta)>c.capacity-c.margin)it=unique.erase(it);else ++it;}
  std::set<Selection> exact;for(const auto& s:all)if(c.theta_value(s,gamma,theta)<=c.capacity-c.margin)exact.insert(s);
  if(unique!=exact)std::cerr<<Json({{"gamma",gamma.get_str()},{"theta",theta.get_str()},{"found",found},{"expected",Groups(exact.begin(),exact.end())},{"log",log}}).dump()<<'\n';
  need(unique==exact);need(log["PoolSearchMode"]==2);need(log["external_MIPstarts"]==false);
  if(!unique.empty()){
   auto excluded=*unique.begin();Vector ng(d.n());for(int j:excluded)ng[j]=1;
   auto other=solver.solve(d.costs,{{c.row(theta),-INFINITY,c.rhs(gamma,theta)},{ng,-INFINITY,double(d.m()-1)}},2,25,10,log);++mips;
   exact.erase(excluded);std::set<Selection> verified;for(const auto& s:other)if(c.theta_value(s,gamma,theta)<=c.capacity-c.margin)verified.insert(s);need(verified==exact);
  }
 }
 std::cout<<Json({{"status","PASS"},{"checks",checks},{"real_tiny_MIP",mips},{"extra_probability_sampling",false}}).dump()<<'\n';
}
