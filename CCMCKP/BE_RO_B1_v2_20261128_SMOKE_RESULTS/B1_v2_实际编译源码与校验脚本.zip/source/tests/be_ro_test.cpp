#include "be_ro_solver.hpp"
#include <iostream>
using namespace s10;
int main(int argc,char**argv){
 try{
  if(argc!=3)return 2;phase_deadline=now()+90;Instance d(argv[1]);BEROWitness w(d,argv[2]);BEROSolver solver(d,w,1289001);Groups combinations{{}};
  for(const auto&g:d.groups){Groups next;for(const auto&s:combinations)for(int j:g){auto v=s;v.push_back(j);next.push_back(v);}combinations=next;}
  Json tests=Json::array();
  for(const char*t:{"0","1/2","1","2","8"}){
   mpq_class omega(t);double optimum=INFINITY;Json witnesses=Json::array();
   for(const auto&s:combinations){auto proof=w.evaluate(s,omega);if(proof["robust_feasible"].get<bool>())optimum=std::min(optimum,d.cost_of(s));witnesses.push_back(proof);}
   Json log;auto found=solver.solve(omega,3.,25,false,{},INFINITY,log);double best=INFINITY;
   for(const auto&s:found){if(!w.evaluate(s,omega)["robust_feasible"].get<bool>())throw std::logic_error("MISOCP returned nonrobust selection");best=std::min(best,d.cost_of(s));}
   if(std::isfinite(optimum)!=std::isfinite(best)||(std::isfinite(best)&&std::abs(best-optimum)>1e-10))throw std::logic_error("MISOCP versus exhaustive objective mismatch");
   tests.push_back({{"omega",t},{"exhaustive_best",std::isfinite(optimum)?Json(optimum):Json(nullptr)},{"solver_best",std::isfinite(best)?Json(best):Json(nullptr)},{"witnesses",witnesses},{"solver",log}});
  }
  std::cout<<Json({{"status","PASS"},{"items",w.items},{"groups",d.groups},{"tail_count",w.tail_count},{"combinations",combinations.size()},{"tests",tests}}).dump()<<'\n';return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}
}
