from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent;S=Path('E:/codex/CCMCKP_BE_RO_B2_20261128')
a=(S/'audit_reader.py').read_text(encoding='utf-8')
a=a.replace('from lb_reader import verify_lb','from linear_reader import verify_v2')
a=a.replace("REPS=int(os.environ.get('BE_AUDIT_REPS','30'));pilot=REPS!=30", "REPS=int(os.environ.get('BE_AUDIT_REPS',str(P['repetitions'])));pilot=REPS!=P['repetitions']")
i=a.index(" stage1=read(root/'BE_RO_STAGE1.json')");j=a.index("  if 'certificate' not in call:continue",i)
a=a[:i]+" v=verify_v2(raw,groups,costs,samples,capacity);math_proofs+=sum(len(q['returned']) for q in raw['BE_RO_model']['queries'])\n for call in raw['BE_RO_model']['native_calls']:\n"+a[j:]
a=a.replace("path=B/'benchmark'/case['instance']", "path=B/P.get('input_prefix','benchmark')/case['instance']")
a=a.replace("'benchmark/'+case['instance']+'/'+n", "P.get('input_prefix','benchmark')+'/'+case['instance']+'/'+n")
a=a.replace("if (root/'S10_search.json').exists() and (root/'BE_RO_STAGE1.json').exists():", "if (root/'S10_search.json').exists():")
a=a.replace("'be_ro_lb'", "'be_ro_pure'").replace("['BE_RO_LB_model']", "['BE_RO_model']")
a=a.replace(",stage1_best_cost=raw['BE_RO_model']['stage1_milestone']['stage1_bero_best_cost'],LB_rounds=len(raw['BE_RO_model']['rounds'])", "")
a=a.replace('BE_RO_LB_B2_independent_full40_audit','BE_RO_B1_v2_independent_record_audit')
assert 'verify_lb' not in a and 'BE_RO_STAGE1' not in a and 'stage1_milestone' not in a
(R/'audit_reader.py').write_text(a,encoding='utf-8')
controller=(S/'controller.py').read_text(encoding='utf-8').replace('pilot_verified=False',"pilot_verified=P['first_wave_runs']==0")
(R/'controller.py').write_text(controller,encoding='utf-8')
P=json.loads((S/'PROTOCOL_TEMPLATE.json').read_text(encoding='utf-8'))
for k in list(P):
 if k.startswith(('LB_','stage1_','stage2_')):del P[k]
P.update(schema='BE_RO_B1_v2_single_model_linear_huber_v1',arms=[{'name':'BE_RO_B1_V2','flow':'be_ro_pure','gamma':None}],
 scope='Fresh cold-start fixed-lambda BE rows, archive and certified escalation; no LB or external solutions',
 model='B1-v2 beta=.95,K=5,finite lambda grid10; radius grid12; fixed-row1s pool10',
 user_design_sha256=hashlib.sha256((R/'USER_DESIGN.md').read_bytes()).hexdigest(),
 finite_grid_exact_optimizer_claim=False,exact_resource_max_claim=False)
smoke=dict(P);smoke.update(cases=[c for c in P['cases'] if c['index'] in [8,18,28,35,36,38,39]],repetitions=5,total_runs=35,
 seed_base=1283100,seeds=list(range(1283101,1283106)),first_wave_runs=0,first_wave_reps=5,
 first40_included_in_registered1200=False,first_wave_gate='No expansion in smoke controller; externally assess all35 before full40 launch')
smoke['pre_registered_quality_gate']={
 'all35_independently_valid':True,'global_errors_empty':True,'TIME_LIMIT_zero_solution_queries':0,
 'max_final_cost_per_run':{'8':11.18515,'18':142.27125,'28':16.42365,'35':194.09625,'36':159.28105,'38':196.27715,'39':322.27507372082596},
 'threshold_basis':'Design rounded targets with upper half-unit in fourth decimal for8/18/28/35/36/38; unspecified low-cost39 fixed before testing at prior R07 official Avg322.27507372082596; no historical solution vector inputs',
 'max_whole_seconds_per_run':600,'no_after_result_relaxation':True}
full=dict(P);full.update(seed_base=1283200,seeds=list(range(1283201,1283231)),repetitions=30,total_runs=1200,first_wave_runs=40,first_wave_reps=1)
(R/'SMOKE_PROTOCOL_TEMPLATE.json').write_text(json.dumps(smoke,ensure_ascii=False,indent=2),encoding='utf-8')
(R/'FULL_PROTOCOL_TEMPLATE.json').write_text(json.dumps(full,ensure_ascii=False,indent=2),encoding='utf-8')
print('Prepared B1-v2 read-only auditor, controller, smoke/full pre-registrations')
