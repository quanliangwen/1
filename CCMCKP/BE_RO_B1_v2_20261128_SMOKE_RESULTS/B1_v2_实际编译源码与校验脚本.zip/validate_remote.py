from pathlib import Path
from fractions import Fraction as F
import json,subprocess,sys,os,time,hashlib,pickle,copy,itertools
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b1_v2_20261128'
assert Path.cwd()==B and not (H/'smoke').exists()
sys.path.insert(0,str(H));from linear_reader import verify_v2,verify_row
from be_reader import moments,verify_proof
from native_reader import selected_model_count,integer_polynomial_count,grid_row
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
for n,h in read(H/'SOURCE_MANIFEST_SHA256.json')['files'].items():assert sha(H/'source'/n)==h,n
base=B/'work/be_ro_b1_20261128/source'
for n in ['main.cpp','search.cpp','evaluation.cpp','evaluation.hpp','report.cpp','report.hpp','rng.cpp','rng.hpp','be_ro_witness.hpp','polish_fft.hpp','isolated_native.hpp']:
 assert sha(H/'source'/n)==sha(base/n),n
def dataset(path):
 g=pickle.loads((path/'node_to_factor.pkl').read_bytes());groups=[g[k] for k in sorted(g)] if isinstance(g,dict) else g
 costs=[float(x) for line in (path/'cost.txt').read_text().splitlines() for x in line.split('#')[0].split()]
 samples=[(path/('%d_sample.txt'%j)).read_text().split() for j in range(len(costs))]
 return groups,costs,samples
checks=[];rows_checked=0;proofs=0;tamper=0;certificates=0
for name,cap in [('LAB_3_2_500_','.5'),('LAB_2_2_500_','1.25'),('LAB_2_2_30_','1.25'),('LAB_2_2_ZERO30_','1.25')]:
 path=H/'fixtures'/name;groups,costs,samples=dataset(path);params=moments(samples)
 mathlog=H/('linear_math_'+name+'.log')
 if not mathlog.exists():
  p=subprocess.run([str(H/'build/be_ro_linear_test'),str(path),cap],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=150)
  mathlog.write_bytes(p.stdout);assert p.returncode==0,p.stdout.decode(errors='replace')[-1600:]
 report=json.loads(mathlog.read_bytes());assert report['status']=='PASS' and not report['finite_grid_exactness_claim']
 for t in report['tests']:
  for e in t['enumeration']:
   good=verify_row(e['row'],e['selection'],params,cap);robust=verify_proof(e['witness'],params,cap)
   assert not good or robust;rows_checked+=1;proofs+=1
 out=H/'integration'/name;receipt=H/('integration_'+name+'_launch.json')
 if not out.exists():
  start=time.monotonic();env=dict(os.environ,CCMCKP_LAUNCH_MONOTONIC=str(start),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
  p=subprocess.run([str(H/'build/ccmckp_s10'),'--instance',str(path),'--capacity',cap,'--seed','1289901','--seconds','600','--out',str(out),'--search-flow','be_ro_pure'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180,env=env)
  wall=time.monotonic()-start;(H/('integration_'+name+'.log')).write_bytes(p.stdout)
  receipt.write_text(json.dumps({'rc':p.returncode,'whole_seconds':wall,'binary_sha256':sha(H/'build/ccmckp_s10')}))
 launch=read(receipt);assert launch['rc']==0 and launch['binary_sha256']==sha(H/'build/ccmckp_s10');wall=launch['whole_seconds']
 raw=read(out/'S10_search.json');result=read(out/'RESULT.json');v=verify_v2(raw,groups,costs,samples,cap)
 assert result['original_LSS_confidence']>=.99 and result['acceptance_evaluator']=='LSS' and result['lss_sample_index_max']==len(samples[0])-1 and wall<600
 d={'path':path,'groups':groups,'costs':costs,'ordered':{},'cache':{}}
 for q in raw['BE_RO_model']['native_calls']:
  if 'certificate' not in q:continue
  c=q['certificate'];s=q['selection'];lo,den=selected_model_count(d,s,c['bins'],cap,False)
  hi,den2=integer_polynomial_count([grid_row(d,j,c['bins'],F(cap),False,False) for j in s],c['bins'])
  assert lo==int(c['lower_numerator']) and hi==int(c['upper_numerator']) and den==den2==int(c['denominator']);certificates+=1
 def reject(bad):
  global tamper
  try:verify_v2(bad,groups,costs,samples,cap)
  except (AssertionError,KeyError,IndexError):tamper+=1
  else:raise AssertionError('Reader accepted altered record')
 for key,value in [('historical_solution_inputs',True),('external_MIPstarts',True),('finite_lambda_grid_is_exact_optimizer',True),('omega_max_is_exact_claim',True),('K',6),('beta','9/10')]:
  bad=copy.deepcopy(raw);bad['BE_RO_model'][key]=value;reject(bad)
 if raw['BE_RO_model']['archive']:
  bad=copy.deepcopy(raw);bad['BE_RO_model']['archive'].pop();reject(bad)
  bad=copy.deepcopy(raw);bad['BE_RO_model']['archive'][0]['witness']['worst_upper']='999999';reject(bad)
 if raw['BE_RO_model']['native_calls']:
  bad=copy.deepcopy(raw);bad['BE_RO_model']['native_calls'][0]['start']=481;reject(bad)
 checks.append({'fixture':name,'full_seconds':wall,'cost':result['cost'],'independent':v});print(json.dumps(checks[-1]),flush=True)
report={'status':'PASS','tiny_integrations':checks,'linear_rows_and_KKT_checks':rows_checked,'reader_tamper_checks':tamper,
 'native_integer_certificates_checked':certificates,'original_LSS_components_identical':True,'no_extra_large_MC':True,
 'binary_sha256':sha(H/'build/ccmckp_s10'),'finite_grid_exactness_claim':False}
(H/'VALIDATION.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
