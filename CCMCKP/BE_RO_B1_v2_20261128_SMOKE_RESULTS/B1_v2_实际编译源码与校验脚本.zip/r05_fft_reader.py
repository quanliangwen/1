import math
from fractions import Fraction as F
_private_fft_cache={}
def r05_private_tools(groups,costs,samples,capacity):
 import numpy as np
 from scipy.fft import rfft,irfft
 b=8192;key=(id(groups),float(capacity));cache=_private_fft_cache.get(key)
 if cache is None:
  hist=np.zeros((len(costs),b),dtype=np.longdouble)
  for j,row in enumerate(samples):
   values=np.array([float(v) for v in row],dtype=np.longdouble);assert np.isfinite(values).all() and (values>=0).all()
   # Same binary64 input interpretation, independently grouped and transformed.
   ids=np.floor(values*np.longdouble(b)/np.longdouble(float(capacity))+np.longdouble('.5')).astype(np.int64);valid=ids<b
   for k in ids[valid]:hist[j,int(k)]+=np.longdouble(1)/len(row)
  undo=np.exp(np.longdouble(12)*np.arange(b,dtype=np.longdouble)/b)
  freq=rfft(hist/undo,n=2*b,axis=1,workers=1)
  cache={'hist':hist,'freq':freq,'undo':undo,'prob':{},'marginals':{}};_private_fft_cache[key]=cache
 def selection(s):assert len(s)==len(groups) and all(j in g for j,g in zip(s,groups))
 def cost(s):return sum((F.from_float(costs[j]) for j in s),F())
 def probability(s):
  k=tuple(s)
  if k not in cache['prob']:
   product=np.prod(cache['freq'][list(s)],axis=0);pdf=irfft(product,n=2*b,workers=1)[:b]
   cache['prob'][k]=float(np.clip(np.sum(np.maximum(pdf,0)*cache['undo']),0,1))
  return cache['prob'][k]
 def marginals(s):
  k=tuple(s)
  if k not in cache['marginals']:
   p=probability(s);result=np.zeros(len(costs));m=len(s)
   left=np.ones((m+1,b+1),dtype=cache['freq'].dtype);right=left.copy()
   for g,j in enumerate(s):left[g+1]=left[g]*cache['freq'][j]
   for g in range(m-1,-1,-1):right[g]=right[g+1]*cache['freq'][s[g]]
   for g in range(m):
    pdf=irfft(left[g]*right[g+1],n=2*b,workers=1)[:b];cdf=np.cumsum(np.maximum(pdf,0)*cache['undo'])
    for j in groups[g]:result[j]=float(np.clip(np.dot(cache['hist'][j],cdf[::-1]),0,1))
    result[s[g]]=p
   cache['marginals'][k]=(p,result)
  return cache['marginals'][k]
 def near(a,b):assert math.isfinite(float(a)) and abs(float(a)-float(b))<1e-6,'independent_private_FFT_score'
 return selection,cost,probability,marginals,near
