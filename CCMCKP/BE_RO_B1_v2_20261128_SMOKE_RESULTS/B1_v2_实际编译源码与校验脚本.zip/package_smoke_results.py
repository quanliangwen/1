from pathlib import Path
from collections import Counter
import json,hashlib,statistics,zipfile,tarfile,shutil,csv
R=Path(__file__).resolve().parent;E=R/'execution_evidence';X=R/'smoke_results_20261128';D=X/'delivery';D.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
A=read(E/'smoke/FINAL_INDEPENDENT_AUDIT.json');G=read(E/'smoke/SMOKE_EXPANSION_DECISION.json');P=read(E/'smoke/PROTOCOL.json');C=read(E/'smoke/COMPLETED.json');diag=read(E/'smoke/SMOKE_DIAGNOSTICS.json')
assert A['terminal']==35 and not A['global_errors'] and not G['pass']
groups=[]
for g in G['groups']:
 rr=[r for r in A['rows'] if r['case_index']==g['case_index']];vv=[r for r in rr if r['valid']];cost=[r['cost'] for r in vv];best=min(cost) if cost else None
 hits=[r for r in vv if r['cost']==best]
 z=dict(g,whole_mean=statistics.mean(r['process_wall_seconds'] for r in rr),best_hit_count=len(hits),
 first_Best_mean=statistics.mean(r['first_found_seconds'] for r in hits) if hits and len(vv)==5 else None)
 groups.append(z)
fmt=lambda x,n=6:'—' if x is None else f'{x:.{n}f}'
lines=['# B1-v2编译与7例35次冒烟测试总结','',
f'编译与tiny技术检查通过，35次冒烟全部终末，{A["independent_valid"]}/35独立有效，global_errors=[]。但预注册成本门槛未通过，**未启动40×30全量测试**。没有放宽门槛、替换seed或补跑已结束记录。', '',
'## 本轮执行结果','',
'- 在独立新目录编译，原B1/B2运行和结果未覆盖。原LSS≥0.99、完整样本索引、native_check/shortlist/final_check、KKT见证和600秒完整时钟保持。',
'- 主程序编译成功；新tiny目标遗漏链接依赖和Python3.8读者nextafter兼容问题在冻结前修复并留日志。',
'- 4个tiny完整集成、920项线性行/KKT核对、36项篡改检查、11份原整数CDF证书核算、4次生产审核器回放通过。',
f'- 冒烟7例×5次，seed1283101—1283105，最多60并行，实际峰值{C["max_active_observed"]}。无资源保护事件，TIME_LIMIT且SolCount0查询为0。',
f'- 最长完整运行{max(r["process_wall_seconds"] for r in A["rows"]):.6f}秒，均未超过600秒。批次历时{C["elapsed_seconds"]:.3f}秒，之后单独进行只读独立审计。', '',
'## 逐例统计与事前门槛','',
'|编号|算例|T|有效|Best|Avg|样本Std|命中Best次数|首次达Best均时(s)|完整均时(s)|最终成本上限|门槛|',
'|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|']
for g in groups:
 lines.append(f'|{g["case_index"]}|{g["instance"].rstrip("_")}|{g["capacity"]:g}|{g["valid"]}/5|{fmt(g["best"])}|{fmt(g["avg"])}|{fmt(g["sample_std"])}|{g["best_hit_count"]}|{fmt(g["first_Best_mean"])}|{fmt(g["whole_mean"])}|{g["max_cost_limit"]:.8f}|{"通过" if g["cost_gate_pass"] else "未通过"}|')
lines+=['','首次达Best均时只在命中该例本批最低最终成本的运行间，平均最终输出解首次通过内部CDF认证的时刻；同时给出命中次数。样本Std为ddof=1。5次冒烟不是30次正式均值，Best未宣称全局最优。', '',
'前6项上限取设计文档四位小数目标的上舍入边界；文档未明确编号39的“低成本”数值，本轮在结果产生前固定为历史R07官方Avg322.27507372082596。即使不考虑39这一补充门槛，8、28、35也未达到原设计目标，18也有一次超出。', '',
'## 关键收获与限制','',
'线性子问题在本批35次中均可产出候选，全部形成最终LSS接受输出，未观察到原3秒锥模型的零解限时瓶颈。该现象只适用于这7例各5次，不足以宣称全部1200次失败已消除。', '',
'编号8和28的目标成本向量根本没有出现在归档中。以重复1为例，编号8归档最低成本为12.9491534872，高于目标11.1851；编号28归档最低成本为16.6231963821，高于目标16.4236。候选归档解决了“已经生成却被丢弃”的问题，不能补足从未生成的候选。', '',
'编号35、39存在成本低于门槛的归档候选，但在私人FFT门控或原CDF认证阶段未通过。不能绕过原评价器或降低验收阈值来制造门槛通过。编号18的5次中有一次最终成本142.3902334862，其余4次为142.2712139209；波动仍需披露。', '',
'连续λ对偶支持函数表达与有限网格求解不是同一个结论：有限10点λ网格只提供保守候选子集；半径二分按#1的私人FFT作启发式定位，没有全局覆盖或单调性保证。后续若修改，需要重新审视网格、半径定位和解池覆盖，而不是把这35次结果外推为全量改善。此次没有追加新机制或事后调参。', '',
'## 未扩展原因','',
'用户要求“通过后再进行全部40例”。本轮技术有效性通过，但质量恢复未通过，所以未启动1200次新运行，也未把5次冒烟包装成30次正式结论。全部35次、源码、审计和失败门槛证据完整保留。', '',
'## 审计与来源','',
f'- 协议SHA256：`{sha(E/"smoke/PROTOCOL.json")}`。',f'- 最终独立审计SHA256：`{sha(E/"smoke/FINAL_INDEPENDENT_AUDIT.json")}`。',
f'- 二进制SHA256：`{read(E/"VALIDATION.json")["binary_sha256"]}`。',
f'- 输出SHA核验{A["files_sha_checked"]}项、KKT见证{A["KKT_witnesses_checked"]}项、整数CDF证书{A["native_integer_certificates_checked"]}份；未新增概率重抽样。',
'- 原B2统计已另行交付：CCMCKP/BE_RO_B2_20261128_FULL40_RESULTS，提交4f8968db178a3c6989545d76c4eb3d5d9fb681ee。',
'- 本目录含35次统计CSV、最终审核与质量门槛、全部紧凑记录归档及本轮源码包。旧“未运行”交付是历史快照，本文是后续实际执行记录。']
(D/'B1_v2_编译与35次冒烟_未通过扩展门槛_总结.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
with (D/'B1_v2_7例35次冒烟统计.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(groups[0]));w.writeheader();w.writerows(groups)
(D/'B1_v2_35次审计明细.json').write_text(json.dumps({'groups':groups,'rows':A['rows'],'gate':G},ensure_ascii=False,indent=2),encoding='utf-8')
for n in ['PROTOCOL.json','FROZEN.json','COMPLETED.json','SMOKE_EXPANSION_DECISION.json','SMOKE_DIAGNOSTICS.json','FINAL_INDEPENDENT_AUDIT.json']:shutil.copy2(E/'smoke'/n,D/n)
for n in ['VALIDATION.json','READER_VALIDATION.json','SOURCE_MANIFEST_SHA256.json']:shutil.copy2(E/n,D/n)
for p in E.glob('*.tar.gz'):shutil.copy2(p,D/p.name)
with zipfile.ZipFile(D/'B1_v2_实际编译源码与校验脚本.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in (R/'source').rglob('*'):
  if p.is_file():
   name=p.relative_to(R/'source').as_posix();assert sha(p)==read(E/'SOURCE_MANIFEST_SHA256.json')['files'][name];z.write(p,'source/'+name)
 for n in ['linear_reader.py','be_reader.py','native_reader.py','r05_fft_reader.py','audit_reader.py','controller.py','validate_remote.py','replay_reader_remote.py','prepare_campaign_support.py','freeze_smoke_remote.py','launch_smoke_remote.py','decide_smoke_remote.py','diagnose_smoke_remote.py','collect_smoke_remote.py','download_smoke.py','package_smoke_results.py','EXECUTION_NOTES.md','USER_DESIGN.md']:z.write(R/n,n)
manifest=None;actual={}
full=next(p for p in D.glob('*.tar.gz') if '全部紧凑' in p.name)
with tarfile.open(full) as tar:
 for member in tar:
  data=tar.extractfile(member).read()
  if member.name=='SMOKE_ALL_FILES_SHA256.json':manifest=json.loads(data)
  else:
   assert member.name.startswith('smoke/');actual[member.name[6:]]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
assert actual==manifest
status={'stage':'B1_V2_SMOKE_COMPLETE_QUALITY_GATE_FAILED_NO_FULL40','compiled':True,'tiny_validation':'PASS',
 'terminal_smoke':35,'independent_valid':A['independent_valid'],'global_errors':A['global_errors'],'smoke_quality_gate_pass':False,
 'full40_started':False,'no_gate_relaxation':True,'all_records_retained':True,'server_processes_finished':True}
(R/'CURRENT_STATUS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8');(D/'CURRENT_STATUS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
qa={'status':'PASS','stage':'FORMAL_COMPLETE','publication_scope':'Complete smoke result and failed quality gate; full40 not started',
 'all_files_sha_verified':True,'smoke_quality_gate_pass':False,'source_zip_matches_smoke_freeze':True,'full_evidence_files_sha_verified':len(actual)}
(X/'DELIVERY_LOCAL_VERIFIED.json').write_text(json.dumps(qa,indent=2),encoding='utf-8');(D/'DELIVERY_QA.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
checks={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in D.iterdir() if p.is_file() and p.name!='CHECKSUMS_SHA256.json'}
(D/'CHECKSUMS_SHA256.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
pub=(R/'publish_code.py').read_text(encoding='utf-8').replace("FOLDER='BE_RO_B1_v2_20261128_CODE_ONLY'","FOLDER='BE_RO_B1_v2_20261128_SMOKE_RESULTS'").replace('Prepare B1-v2 lambda-Huber source without compiling or running; wait for B2','Publish B1-v2 compiled source and35 valid smoke results; cost gate failed, no full40 launch')
(X/'publish_results.py').write_text(pub,encoding='utf-8')
print(json.dumps({'status':'PACKAGED_SMOKE_GATE_FAILED','groups':groups,'delivery_files':len(checks),'evidence_files':len(actual)},ensure_ascii=False))
