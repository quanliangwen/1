from pathlib import Path
import json,hashlib,tarfile
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b1_v2_20261128';F=H/'smoke';X=H/'exports'
assert Path.cwd()==B
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (F/'SMOKE_EXPANSION_DECISION.json').exists() and read(F/'FINAL_AUDIT_PROCESS.json')['rc']==0
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  args=(proc/'cmdline').read_bytes().split(b'\0')
  assert not any(str(F).encode() in a and any(k in a for k in [b'controller.py',b'ccmckp_s10',b'audit_reader.py']) for a in args),'Smoke process still active'
 except OSError:pass
X.mkdir(exist_ok=True)
files={}
for name in ['PROTOCOL.json','FROZEN.json','LAUNCH.json','COMPLETED.json','FINAL_INDEPENDENT_AUDIT.json','SMOKE_EXPANSION_DECISION.json','SMOKE_DIAGNOSTICS.json','FINAL_AUDIT_PROCESS.json']:
 files['smoke/'+name]=F/name
for name in ['VALIDATION.json','READER_VALIDATION.json','SOURCE_MANIFEST_SHA256.json','build_0.log','build_1.log','build_fix1.log','validation_fix1.log']:
 if (H/name).exists():files[name]=H/name
small=X/'B1_v2_编译与35次冒烟_审计证据.tar.gz'
if not small.exists():
 with tarfile.open(small,'w:gz') as tar:
  for name,path in files.items():tar.add(path,arcname=name)
full=X/'B1_v2_35次冒烟_全部紧凑记录.tar.gz'
paths=[p for p in F.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
manifest={p.relative_to(F).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size} for p in paths}
mp=X/'SMOKE_ALL_FILES_SHA256.json';mp.write_text(json.dumps(manifest,indent=2))
if not full.exists():
 with tarfile.open(full,'w:gz') as tar:
  for p in paths:tar.add(p,arcname='smoke/'+p.relative_to(F).as_posix())
  tar.add(mp,arcname='SMOKE_ALL_FILES_SHA256.json')
report={'status':'PASS','small_archive':str(small),'small_bytes':small.stat().st_size,'small_sha256':sha(small),
 'full_archive':str(full),'full_bytes':full.stat().st_size,'full_sha256':sha(full),
 'files':{name:{'sha256':sha(path),'bytes':path.stat().st_size} for name,path in files.items()},
 'smoke_files':len(paths),'gate_pass':read(F/'SMOKE_EXPANSION_DECISION.json')['pass']}
(X/'EXPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='files'},ensure_ascii=False))
