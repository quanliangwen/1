from pathlib import Path
from collections import Counter
import json
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b1_v2_20261128';F=H/'smoke'
assert Path.cwd()==B
read=lambda p:json.loads(p.read_text())
P=read(F/'PROTOCOL.json');diag=[]
for o in sorted((read(p) for p in (F/'outcomes').glob('*.json')),key=lambda x:(x['case_index'],x['rep'])):
 raw=read(F/'runs'/o['identity']/'S10_search.json');m=raw['BE_RO_model'];limit=P['pre_registered_quality_gate']['max_final_cost_per_run'][str(o['case_index'])]
 a=sorted(m['archive'],key=lambda x:x['cost']);cheap=[q for q in a if q['cost']<=limit]
 decisions={tuple(q['selection']):q['decision'] for q in m['candidates']}
 result=read(F/'runs'/o['identity']/'RESULT.json')
 diag.append({'identity':o['identity'],'case_index':o['case_index'],'rep':o['rep'],'final_cost':result['cost'],'LSS':result['original_LSS_confidence'],
 'whole_seconds':o['process_wall_seconds'],'omega_star':m['omega_star'],'omega_resource_used':m['omega_resource_used'],
 'archive_count':len(a),'archive_min_cost':min((q['cost'] for q in a),default=None),'under_cost_limit_archive_count':len(cheap),
 'under_cost_limit_decisions':dict(Counter(decisions.get(tuple(q['selection']),'not_attempted_or_FFT_not_scored') for q in cheap)),
 'candidate_decisions':dict(Counter(q['decision'] for q in m['candidates'])),
 'native_states':dict(Counter(q['state'] for q in m['native_calls'])),
 'escape_rounds':m['escape'],'lowest_cost_archive_entries':[{'cost':q['cost'],'private_probability':q['private_probability'],'omega':q['omega'],'decision':decisions.get(tuple(q['selection']))} for q in a[:5]]})
out=F/'SMOKE_DIAGNOSTICS.json'
data=json.dumps(diag,ensure_ascii=False,indent=2)
if out.exists():assert out.read_text()==data
else:out.write_text(data)
print(json.dumps([{'identity':d['identity'],'final_cost':d['final_cost'],'archive':d['archive_count'],'min_archive':d['archive_min_cost'],'under_target_count':d['under_cost_limit_archive_count'],'under_target_decisions':d['under_cost_limit_decisions']} for d in diag if d['rep']==1]))
