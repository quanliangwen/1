from pathlib import Path
import subprocess,json,hashlib,tarfile,sys
R=Path(__file__).resolve().parent;E=R/'execution_evidence';E.mkdir(exist_ok=True)
remote='/home/junhao/quan/parallel_test_solver/CCMKCP/work/be_ro_b1_v2_20261128/exports'
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60','cat '+remote+'/EXPORT.json'],capture_output=True,timeout=60)
assert p.returncode==0,p.stderr.decode(errors='replace');m=json.loads(p.stdout);(E/'EXPORT.json').write_bytes(p.stdout)
for prefix in ['small','full']:
 target=E/Path(m[prefix+'_archive']).name
 if not target.exists():
  p=subprocess.run(['scp','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60:'+m[prefix+'_archive'],str(target)],capture_output=True,timeout=180)
  assert p.returncode==0,p.stderr.decode(errors='replace')
 assert target.stat().st_size==m[prefix+'_bytes'] and hashlib.sha256(target.read_bytes()).hexdigest()==m[prefix+'_sha256']
 if prefix=='small':
  with tarfile.open(target) as t:
   for member in t.getmembers():
    out=(E/member.name).resolve();assert E.resolve() in out.parents and member.isfile()
    out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(t.extractfile(member).read())
for n,q in m['files'].items():assert hashlib.sha256((E/n).read_bytes()).hexdigest()==q['sha256'] and (E/n).stat().st_size==q['bytes']
print(json.dumps({'status':'PASS','smoke_gate_pass':m['gate_pass'],'small_bytes':m['small_bytes'],'full_bytes':m['full_bytes']}))
