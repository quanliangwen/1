"""Saved proposals: audit A01 float64 convolution against B half-PDF arithmetic.

No optimization, native call, parameter selection or acceptance changes.
"""
import hashlib,json,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'sources/GEPS'))
import solver as sm
from instance import load_instance
from run_task import atomic,verify
freeze=verify();cases=json.loads((ROOT/'cases.json').read_text());rows=[]
for index in [17,38,39,40,25,18,14]:
    case=next(x for x in cases if x['index']==index)
    inst=load_instance(ROOT/'inputs/benchmark'/case['instance'])
    detail=json.loads((ROOT/'functional'/('c%d.json.gz.detail.json'%index)).read_text())
    hist=np.asarray([sm.worst_cdf_hist(a[:-1],case['tmax'],4096,.00025) for a in inst.samples])
    fft=np.fft.rfft(hist,8192,axis=1);checks=[]
    for a in detail['gamma']['attempts']:
        for q in a['proposals']:
            if 'original_CDF_delta00025' not in q:continue
            ids=q['selection']
            halves=[]
            for groups in [range(0,inst.m,2),range(1,inst.m,2)]:
                pdf=np.zeros((1,4096),np.float32);pdf[0,0]=1.
                for g in groups:
                    freq=np.fft.rfft(pdf,8192,axis=1)*fft[ids[g]][None,:]
                    pdf=np.maximum(0.,np.fft.irfft(freq,8192,axis=1)[:,:4096]).astype(np.float32)
                halves.append(pdf[0])
            b=float(np.clip((halves[0][None,:]@np.ascontiguousarray(np.cumsum(halves[1][None,:],axis=1,dtype=np.float64)[:,::-1].T))[0,0],0.,1.))
            current=q['original_CDF_delta00025']
            checks.append(dict(gamma=a['gamma'],A01_score=current,B_half_PDF_score=b,
                absolute_difference=abs(current-b),same_gate=(current>=.975)==(b>=.975)))
    root=detail['gamma']['original_initial_gamma_load']
    statuses={}
    for a in detail['gamma']['attempts']:statuses[str(a['status'])]=statuses.get(str(a['status']),0)+1
    rows.append(dict(case=index,checks=checks,max_abs_difference=max((q['absolute_difference'] for q in checks),default=0.),
        all_observed_gates_same=all(q['same_gate'] for q in checks),all_milp_status_counts=statuses,
        initial_nominal_load=root[0],initial_Gamma1_load=root[1],capacity=case['tmax']))
atomic(ROOT/'SCORE_ALIGNMENT_AUDIT_V2.json',dict(passed=all(q['max_abs_difference']==0. for q in rows),source_freeze=freeze,rows=rows,
    exact_floating_path_equal=True,
    scope='GEPS saved proposal scores compared with independent reconstruction of original B half-PDF float32 cast and reverse-CDF arithmetic.',
    formal_admission=False,
    required_before_formal='Need separately registered full-run quality pilot; no statistical performance claim from this diagnostic.'))
assert all(q['max_abs_difference']==0. and q['all_observed_gates_same'] for q in rows)
print(json.dumps({'rows':[{k:v for k,v in r.items() if k!='checks'} for r in rows],'formal_admission':False}))
