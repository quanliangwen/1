"""Unique detached prechecks -> admission -> PILOT ONLY. Never resumes old waves."""
import fcntl,json,os,subprocess,sys,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent;os.chdir(ROOT)
from common import read,atomic,sha,check_freeze,process_table,mem_available
ENV=dict(os.environ,OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')

def step(script,result):
    if (ROOT/result).exists():
        d=read(ROOT/result);assert d.get('passed') and d.get('freeze_sha',d.get('source_freeze'))==check_freeze()
        return
    with (ROOT/(script+'.log')).open('x') as log:
        p=subprocess.run([sys.executable,'-B',str(ROOT/script)],stdout=log,stderr=subprocess.STDOUT,env=ENV)
    if p.returncode:raise RuntimeError('Precheck failed '+script)

def main():
    lock=(ROOT/'advance.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    with (ROOT/'ADVANCE_UNIQUE_CLAIM').open('x') as f:f.write(str(os.getpid()))
    freeze=check_freeze();reg=read(ROOT/'PROTOCOL.json')
    step('epsilon_precheck.py','EPSILON_MATH_PREFLIGHT.json')
    step('run_precheck.py','PRECHECK_RESULT.json')
    step('run_synthetic_precheck.py','SYNTHETIC_RESULT.json')
    step('score_alignment_audit.py','SCORE_ALIGNMENT_AUDIT_V2.json')
    real=read(ROOT/'PRECHECK_RESULT.json');synthetic=read(ROOT/'SYNTHETIC_RESULT.json')
    assert real['passed'] and synthetic['passed'] and len(synthetic['rows'])==30
    assert synthetic['exact_processes']==15 and synthetic['MC_processes']==15
    focus=[]
    for index in [38,39]:
        row=next(x for x in real['cases'] if x['case']==index)
        d=read(ROOT/'functional'/('c%d.json.gz.detail.json'%index))
        proposals=[q for a in d['gamma']['attempts'] for q in a['proposals']]
        accepted=[q for q in proposals if q.get('probability') is not None and q['probability']>=.99 and q['cost']<row['initial_cost']-1e-8]
        focus.append(dict(index=index,initial_cost=row['initial_cost'],final_cost=row['final_cost'],accepted_proposals=len(accepted),CDF_passed=sum(q.get('original_CDF_delta00025',0)>=.975 for q in proposals)))
    admission=all(x['accepted_proposals']>0 and x['final_cost']<x['initial_cost']-1e-8 for x in focus)
    atomic(ROOT/'PRECHECK_ADMISSION.json',dict(passed=admission,freeze_sha=freeze,focus=focus,
        note='Functional admission only; not a cost performance gate. Same firstseed and old suite; exploratory selection disclosed.'))
    if not admission:
        atomic(ROOT/'STATE.json',dict(status='precheck_focus_admission_failed_NO_PILOT',goal_achieved=False,freeze_sha=freeze));return
    from audit_campaign import audit_wave
    refs=read(ROOT/'REFERENCE_REGISTRY.json');counts={}
    for case in reg['cases']:
        rows=audit_wave(Path(refs['waves'][str(case['index'])]['directory']),case,'B')
        assert len(rows)==30 and all(q['valid'] for q in rows);counts[str(case['index'])]=30
    atomic(ROOT/'REUSED_B_AUDIT.json',dict(passed=True,freeze_sha=freeze,counts=counts,new_B_executions=0))
    atomic(ROOT/'PREFLIGHT.json',dict(passed=True,freeze_sha=freeze,math=sha(ROOT/'EPSILON_MATH_PREFLIGHT.json'),functional=sha(ROOT/'PRECHECK_RESULT.json'),synthetic=sha(ROOT/'SYNTHETIC_RESULT.json'),CDF_alignment=sha(ROOT/'SCORE_ALIGNMENT_AUDIT_V2.json'),admission=sha(ROOT/'PRECHECK_ADMISSION.json')))
    check_freeze()
    from controller import Controller
    controller=Controller();controller.run()
    # Mandatory compact terminal packet even if the pilot failed. No native calls.
    p=subprocess.run([sys.executable,'-B',str(ROOT/'terminal_export.py')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=ENV,text=True)
    atomic(ROOT/'TERMINAL_EXPORT_PROCESS.json',dict(returncode=p.returncode,stdout=p.stdout));p.check_returncode()

if __name__=='__main__':
    try:main()
    except Exception as e:
        atomic(ROOT/'ADVANCE_FAILURE.json',dict(error=repr(e),utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),goal_complete=False))
        traceback.print_exc();raise
