"""Independent exhaustive oracle for new epsilon-cap/risk objective."""
import itertools,json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'sources/GEPS'))
import numpy as np,gurobipy as gp
from gamma_math import robust_load
from common import atomic,check_freeze

def main():
    freeze=check_freeze();rng=np.random.default_rng(832273);checks=0
    for trial in range(15):
        groups=[[0,1],[2,3],[4,5]];mu=rng.integers(0,5,6).astype(float);d=rng.integers(0,6,6).astype(float);cost=rng.integers(1,20,6).astype(float)
        selections=list(itertools.product(*groups))
        for gamma in [0.,.5,1.,1.5,2.,2.5,3.]:
            for cap in [0.,8.,15.,25.,40.,100.]:
                T=15.;valid=[s for s in selections if cost[list(s)].sum()<=cap and robust_load(mu,d,s,gamma)<=T]
                expected=min((robust_load(mu,d,s,gamma) for s in valid),default=None)
                model=gp.Model();model.Params.OutputFlag=0;model.Params.Threads=1;model.Params.MIPGap=0.
                x=model.addMVar(6,vtype=gp.GRB.BINARY);theta=model.addVar(lb=0.,ub=float(d.max()));q=model.addMVar(6,lb=0.)
                for group in groups:model.addConstr(x[group].sum()==1)
                model.addConstr(q+theta>=d*x);risk=mu@x+float(gamma)*theta+q.sum()
                model.addConstr(risk<=T);model.addConstr(cost@x<=cap);model.setObjective(risk);model.optimize()
                actual=float(model.ObjVal) if model.SolCount else None
                assert actual is None if expected is None else actual is not None and abs(actual-expected)<1e-8,(trial,gamma,cap,actual,expected)
                model.dispose();checks+=1
    atomic(ROOT/'EPSILON_MATH_PREFLIGHT.json',dict(passed=True,freeze_sha=freeze,exhaustive_risk_objective_checks=checks,
        cases='15x7 Gamma including fractional endpoints x6 cost caps, infeasible/zero/tie cases',native_calls=0,
        theory='Conventional epsilon-constraint weak efficiency only with exact solves; no finite-time native/Pareto/global guarantee.'))
    print(json.dumps({'passed':True,'checks':checks}))
if __name__=='__main__':main()
