"""One post-terminal timing/state diagnostic; no probability evaluator calls."""
import argparse,gzip,json,statistics
from pathlib import Path
from common import ROOT,read,atomic
def main(index):
    refs=read(ROOT/'REFERENCE_REGISTRY.json');ptr=read(ROOT/'WAVE_POINTERS'/('GEPS_pilot_c%02d.json'%index))
    result={'case':index,'scope':'Offline saved records only; time decomposition is descriptive, not an isolated same-load causal experiment','arms':{}}
    for arm,path in [('B',Path(refs['waves'][str(index)]['directory'])),('GEPS',ROOT/ptr['relative_dir'])]:
        assert read(path/'WAVE.json')['status']=='valid_complete'
        rows=[]
        for rep in range(1,31):
            d=json.loads(gzip.decompress((path/('r%02d.json.gz'%rep)).read_bytes()));matches=[h for h in d['match_history'] if 'left' in h]
            g=next((h for h in d['match_history'] if h.get('engine')=='Gamma_epsilon_risk_frontier'),None)
            initial=next((o['elapsed'] for o in d['native_observations'] if o['source']=='current_run_V50_original_low_risk_initialization' and o['probability']>=.99),None)
            first=matches[0] if matches else None
            prefix='robust_mitm_delta'+str(first['delta'])+'_left'+','.join(map(str,first['left'])) if first else None
            obs=[o for o in d['native_observations'] if o['source']==prefix]
            rows.append(dict(rep=rep,native_seconds=d['native_seconds'],native_calls=d['native_probability_calls'],
                first_left_states=first['left_states'] if first else None,first_right_states=first['right_states'] if first else None,
                first_pair_count=first['pair_count'] if first else None,first_shortlist=first['shortlist'] if first else None,
                first_original_native_elapsed=obs[0]['elapsed'] if obs else None,
                before_first_original_native_minus_init_and_Gamma=obs[0]['elapsed']-initial-(g['seconds'] if g else 0) if obs and initial is not None else None,
                original_first_end=585-first['remaining'] if first else None,
                first_stage_native_calls=len(obs),first_stage_zero_returns=sum(o['probability']==0 for o in obs)))
        result['arms'][arm]={'means':{k:statistics.mean(v[k] for v in rows if v[k] is not None) if any(v[k] is not None for v in rows) else None for k in rows[0] if k!='rep'},'rows':rows}
    out=ROOT/'reporting'/('CASE%02d_TIMING_COMPONENTS.json'%index);assert not out.exists();atomic(out,result)
    print(json.dumps({'case':index,'arms':{a:x['means'] for a,x in result['arms'].items()}}))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--case',type=int,required=True);main(ap.parse_args().case)
