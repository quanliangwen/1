"""Post-terminal saved-trajectory diagnostics, no new probability or search."""
import argparse,gzip,json,statistics,sys
from pathlib import Path
from common import ROOT,read,atomic,sha

def main(index):
    ref=read(ROOT/'REFERENCE_REGISTRY.json')['waves'][str(index)]
    pointer=read(ROOT/'WAVE_POINTERS'/('GEPS_pilot_c%02d.json'%index));candidate=ROOT/pointer['relative_dir']
    assert read(candidate/'WAVE.json')['status'] in ('valid_complete','ordinary_failure_complete')
    paths={'B':Path(ref['directory']),'GEPS':candidate};raw={}
    for arm,path in paths.items():raw[arm]=[json.loads(gzip.decompress((path/('r%02d.json.gz'%r)).read_bytes())) for r in range(1,31)]
    best=min(x['selected']['cost'] for x in raw['B'] if x['selected'])
    result={'case':index,'scope':'Saved terminal trajectories only; original B sample best is diagnostic, never worker input','B_sample_best':best,'arms':{}}
    for arm,records in raw.items():
        stage=[];first_end=[];native=[];visits=0;visiting=0;gamma=[];models=[];rootcost=[];accepted=[];cdf=[]
        for d in records:
            matches=[x for x in d['match_history'] if 'left' in x and 'delta' in x];stage.append(len(matches))
            if matches:first_end.append(585.-matches[0]['remaining'])
            obs=d['native_observations'];native.append(len(obs));n=sum(abs(o['cost']-best)<=1e-8 for o in obs);visits+=n;visiting+=n>0
            for g in d['match_history']:
                if g.get('engine')!='Gamma_epsilon_risk_frontier':continue
                gamma.append(g['seconds']);models.append(len(g['attempts']));rootcost.append(g['final_cost'])
                proposals=[p for a in g['attempts'] for p in a['proposals']]
                accepted.append(sum(p.get('probability') is not None and p['probability']>=.99 for p in proposals))
                cdf.append(sum(p.get('original_CDF_delta00025',0)>=.975 for p in proposals))
        result['arms'][arm]=dict(original_stages_mean=statistics.mean(stage),first_original_stage_end_mean=statistics.mean(first_end) if first_end else None,
            native_calls_mean=statistics.mean(native),B_sample_best_native_visits=visits,B_sample_best_native_visiting_runs=visiting,
            Gamma_seconds_mean=statistics.mean(gamma) if gamma else None,Gamma_seconds_max=max(gamma) if gamma else None,
            Gamma_models_mean=statistics.mean(models) if models else None,Gamma_models_min=min(models) if models else None,
            after_Gamma_mean_cost=statistics.mean(rootcost) if rootcost else None,
            Gamma_native_accepted_mean=statistics.mean(accepted) if accepted else None,Gamma_CDF_pass_mean=statistics.mean(cdf) if cdf else None)
    out=ROOT/'reporting'/('CASE%02d_TRAJECTORY_DIAGNOSIS.json'%index);assert not out.exists();atomic(out,result);print(json.dumps(result))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--case',type=int,required=True);main(ap.parse_args().case)
