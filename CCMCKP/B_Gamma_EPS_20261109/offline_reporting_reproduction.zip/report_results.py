"""Read-only terminal analysis and delivery assembly. Never invokes Solver/native."""
import pathlib,json,zipfile,gzip,statistics,hashlib,shutil,datetime,xml.etree.ElementTree as ET
R=pathlib.Path(__file__).resolve().parent;D=json.loads((R/'statistics_snapshot.json').read_text());G=D['stage_gate'];A=json.loads((R/'DEEP_TIME_AND_NATIVE_RECORD_AUDIT.json').read_text());Z=zipfile.ZipFile(R/'results_complete.zip')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
def f(x,n=6):return '—' if x is None else f'{x:.{n}f}'
def table(headers,rows):return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(map(str,x))+' |' for x in rows])
assert sha(R/'statistics_snapshot.json')=='d093097ecc3d2800a1c026a6e30d9e0841ad88af12c69c8564624d7b0ebb61fc'
assert A['passed'] and A['valid_runs_checked']==420 and all(x['valid']==30 for x in D['summaries'])
gamma=[]
for idx in [17,38,39,40,25,18,14]:
 rows=[]
 for rep in range(1,31):
  raw=json.loads(gzip.decompress(Z.read(f'waves/GEPS_pilot_c{idx:02d}_a01/r{rep:02d}.json.gz')))
  x=next(x for x in raw['match_history'] if x.get('engine')=='Gamma_epsilon_risk_frontier')
  proposals=[y for attempt in x['attempts'] for y in attempt['proposals']]
  rows.append(dict(rep=rep,seconds=x['seconds'],models=len(x['attempts']),after_Gamma_cost=x['final_cost'],initial_cost=x['initial_cost'],CDF_pass=sum((y.get('original_CDF_delta00025') or -1)>=.975 for y in proposals),native_returned=sum(y.get('decision')=='original_native_returned' and isinstance(y.get('probability'),(int,float)) for y in proposals),wrapper_none=sum(y.get('decision')=='original_native_returned' and y.get('probability') is None for y in proposals),native_calls=sum(y.get('native_calls',0) for y in proposals),native_accepted=sum(y.get('decision')=='original_native_returned' and (y.get('probability') or 0)>=.99 for y in proposals)))
 gamma.append(dict(index=idx,runs=30,means={k:statistics.mean(x[k] for x in rows) for k in ('seconds','models','after_Gamma_cost','initial_cost','CDF_pass','native_returned','native_calls','native_accepted')},native_accepted_min=min(x['native_accepted'] for x in rows),runs_with_accepted=sum(x['native_accepted']>0 for x in rows),rows=rows))
dump(R/'diagnostics'/'GAMMA_PILOT_SUMMARY.json',{'scope':'Saved records only; no optimization or oracle replay','cases':gamma})
events=[json.loads(x) for x in Z.read('control/EVENTS.jsonl').decode().splitlines()];obs=[x for x in events if x['event']=='resource_observation']
resource={'scope':'Frozen controller resource logs; anonymous aggregate only. Load average includes runnable and uninterruptible tasks, not a precise CPU-utilization estimate.','logical_CPUs':256,'first':obs[0],'last':obs[-1],'observations':len(obs),'maximum_load1':max(x['loadavg'][0] for x in obs),'minimum_available_GiB':min(x['available_bytes'] for x in obs)/2**30,'by_wave':[]}
for wave in sorted({x['wave'] for x in obs}):
 rows=[x for x in obs if x['wave']==wave]
 resource['by_wave'].append({'wave':wave,'observations':len(rows),'load1_min':min(x['loadavg'][0] for x in rows),'load1_max':max(x['loadavg'][0] for x in rows),'load1_mean':statistics.mean(x['loadavg'][0] for x in rows),'available_GiB_min':min(x['available_bytes'] for x in rows)/2**30})
dump(R/'diagnostics'/'RESOURCE_LOAD_CONTEXT.json',resource)
means={a:statistics.mean(s['avg'] for s in D['summaries'] if s['arm']==a) for a in ('B','GEPS')}
rel=statistics.mean(c['relative_mean_difference'] for c in D['comparisons'])
costrows=[[x['index'],x['arm'],str(x['valid'])+'/30',f(x['best']),f(x['avg']),f(x['std']),f(x['CV']*100,4)+'%'] for x in D['summaries']]
timerows=[[x['index'],x['arm'],f(x['mean_final_best_first_seconds'],3),x['best_hits'],f(x['conditional_best_hit_seconds'],3),f(x['mean_actual_runtime'],3),f(x['target_cost']),x['target_hits'],f(x['conditional_target_seconds'],3),f(x['restricted_target_seconds'],3)] for x in D['summaries']]
pairrows=[[x['index'],f(x['mean_difference']),f(x['relative_mean_difference']*100,4)+'%',f(x['paired_dz'],4),'['+f(x['paired_bootstrap_95'][0])+', '+f(x['paired_bootstrap_95'][1])+']',f(x['p'],5),f(x['holm_p'],5)] for x in D['comparisons']]
qualityrows=[]
for x in G['reference_quality_times']:
 b=x['arms']['B'];c=x['arms']['GEPS'];qualityrows.append([x['index'],f(x['fixed_reference_mean_cost_target']),b['hits'],c['hits'],f(b['conditional_seconds'],3),f(c['conditional_seconds'],3),f(b['restricted_seconds'],3),f(c['restricted_seconds'],3)])
gammarows=[[x['index'],f(x['means']['seconds'],3),f(x['means']['models'],2),f(x['means']['CDF_pass'],2),f(x['means']['native_returned'],2),f(x['means']['native_accepted'],2),f(x['means']['after_Gamma_cost']),str(x['runs_with_accepted'])+'/30'] for x in gamma]
groups=[]
for label,lo,hi in [('小组',1,5),('中组',6,20),('大组',21,10000)]:
 ids=[x['index'] for x in D['summaries'] if x['arm']=='B' and lo<=x['m']<=hi];cs=[x for x in D['comparisons'] if x['index'] in ids]
 groups.append([label,','.join(map(str,ids)),len(ids),f(statistics.mean(x['mean_difference'] for x in cs)),f(statistics.mean(x['relative_mean_difference'] for x in cs)*100,4)+'%'])
report=f'''Γ风险优先ε约束算子（GEPS）七例先导：终末报告

本轮未通过预登记性能验收，不扩展40例或新1200次。功能层面，38、39“提案全部被拒”的问题已解决；效果层面，38例均成本显著退化，不能用总体均值或40例的单例改善抵消。原问题目标、每组恰选一项、容量、原生评价器和预算保持不变。

冻结运行在北京时间2026-11-09 16:29:35完成最后一波，16:29:49进入pilot_failed_requires_diagnosis；16:29:56生成独立终末快照。候选210/210有效，比较范围B210+GEPS210；数据ZIP另保留全部40例1200次有效B记录。无新B运行、无有效波重跑、无普通失败补跑，七波均为a01、30并行。登记失败、无解、原生不达标、数值错误、超时和资源中断均为0。它是先导完成，不是完整优化目标完成。

七例各自avg再平均：B={f(means['B'])}，GEPS={f(means['GEPS'])}，差={f(means['GEPS']-means['B'])}（{f((means['GEPS']/means['B']-1)*100,4)}%）；每例除以B均成本后等权平均的变化为{f(rel*100,4)}%。5例均成本改善、1例退化、1例持平，覆盖7/40，未作全40推断。各例std平均从{f(G['mean_case_std']['B'])}到{f(G['mean_case_std']['GEPS'])}，CV平均从{f(G['mean_case_CV']['B']*100,4)}%到{f(G['mean_case_CV']['GEPS']*100,4)}%；共同B均成本目标限制均时从{f(G['mean_restricted_common_target_seconds']['B'],3)}到{f(G['mean_restricted_common_target_seconds']['GEPS'],3)}秒。稳定性/共同目标时间两项门槛通过，逐例成本门槛失败，总性能门槛失败。

决策依据与单一改动

1. 先用A02已保存数据定位：38例Γ=1的最低成本池CDF=.959809406—.960758614，39例=.972302571—.972680270，低于原.975门槛；各自Γ=0/1的八个提案全部拒绝，而Γ≥2的成本截断模型不可行。这只支持“成本优先的有限提案池可能错过风险/成本前沿”，不支持降低概率门槛。
2. 采用Mavrotas(2009)普通ε约束式(2)，把辅助模型从min c'x, RΓ(x)≤T变为min RΓ(x), c'x≤ε, RΓ(x)≤T；每组恰选一项。ε=本次运行当前原生可行最好成本×(1−f)−1e−8，f完全复用B的(.02,.01,.03,.005,.05,.08)。收到改善只更新本次运行上限，不读历史解、不跨种子迁移。
3. Γ整数0…m、经验μ/观测最大偏差d、45秒、单模型.75秒、池4均与A02相同。RΓ(x)=μ'x+max{{Σd_jx_jz_j:0≤z_j≤1,Σz_j≤Γ}}，紧凑形式min{{μ'x+Γθ+Σq_j:q_j≥d_jx_j−θ,q≥0,θ≥0}}。候选仍须原B同构float32逐层半区卷积/反向CDF矩阵评分≥.975，再用原生native_check；辅助阶段后仍执行原B三种分区×三种半径的九阶段。唯一官方对照为上传B，不把A02当成官方对照，也不继承R04/R08F/R09其他求解算子。
4. 在看到本轮先导前冻结43个运行文件、PROTOCOL、全部输入SHA和验收门槛；通过数学、原生/随机流回放和实数据功能检查才启动。冻结后未改运行源码或参数，失败后也未改门槛或种子。此次后处理仅读取保存记录，不重新运行原生评价。

原始文献与适用边界

George Mavrotas (2009), Effective implementation of the ε-constraint method in Multi-Objective Mathematical Programming problems, Applied Mathematics and Computation 213:455–465. DOI https://doi.org/10.1016/j.amc.2009.03.037 。已阅读全文相关第2节式(1)(2)、3.1词典序与表1/2反例、3.2式(3)—(6)及命题完整证明、3.3不可行早退论证，并核对第456/460页。实际采用第2节普通ε约束转换，未实现AUGMECON加权剩余变量，不借用其强Pareto保证。精确求解时有限二进制域上的代理目标点可为弱有效；本轮有限成本网格与限时MILP不保证完整前沿或全局最优。

Dimitris Bertsimas and Melvyn Sim (2003), Robust discrete optimization and network flows, Mathematical Programming 98:49–71. DOI https://doi.org/10.1007/s10107-003-0396-4 。沿用已阅读Theorem1式(4)—(7)、Theorem3式(17)—(19)及完整证明的预算不确定集LP对偶结构。假定d有限非负；本题d来自经验有效支撑最大值减均值，MC按原规则排除末样本。Γ集合是辅助负载代理，不是原有限边际CDF分布集合，观测最大值不是真实支撑界，Γ未经.99统计覆盖校准。风险代理下降不能推出原生概率单调上升；失败点不能证明整个成本区间不可行，未使用此类二分剪枝。新旧Γ集合及约束强度相同，仅改变辅助目标/成本截断，未缩小半径或降低置信要求；原B的CDF扰动评分本身也不构成未知真分布覆盖保证。

功能预检

630项新ε风险MILP与独立穷举对照，覆盖15个小实例、7种Γ（含分数及端点）、6种成本上限；原Γ代数1120恒等式/560可行并集/560MILP检查复用原有效证据，不重复运行。30次完整合成运行覆盖15精确/15MC、全部九原阶段、独立初始化、逐调用私有随机流回放、正缓存和负缓存重评；七个实算例规定首种子各一次，仅原初始化加算子。新评分与B半区矩阵数值对齐。事前功能准入要求38和39各至少一个严格降成本且原生≥.99的提案，已通过；功能通过没有代替30次成本验收。详情见preflight_evidence.zip和PRECHECK_ADMISSION.json。

正式先导成本（样本std，CV为百分比）

{table(['例','版本','有效/登记','best','avg','std','CV'],costrows)}

所有版本/例登记30、终末30、失败0、待完成0。17和14候选的极小std是浮点均值舍入残差，原始数值保留JSON/Excel，不据此声称总体方差为零。

正式时间（秒）

“最终最好首次均时”是每次自己的最终最好解第一次到达时间的平均；“best命中条件均时”只对命中该版本该例30次best的运行求平均，不混为一项。未证明全局最优，因此这里的best不称全局最优。

{table(['例','版本','最终最好首次均时','best命中数','best命中条件均时','实际均时','原定目标成本','目标命中数','目标条件均时','目标限制均时'],timerows)}

总预算600秒并共同预留15秒收尾；保留原B自然完成语义，25例均提前完成全部九阶段。没有通过等待凑满600秒，亦没有截去加载/初始化/保存时间。未命中目标的限制时间按600计，仅用于时间分析，不为失败填虚假成本。

配对成本检验与效应

均差定义GEPS−B，负为改善。双侧配对均差符号翻转检验（非零差≤20时精确，否则99999随机翻转加观察值），固定统计种子20261101+例号；Holm校正家族为这七项。19999次按种子对重抽样的95%百分位区间是描述性、非同时区间。

{table(['例','配对均差','相对均差','dz','95%配对区间','原p','Holm p'],pairrows)}

38例校正后显著退化；39例区间跨零、Holm p=.27132，不能下“确定有效/等效/无用”的结论。25例仅少数重复改善，std/CV上升，不能依据更好的best宣称稳定提升。40、18、14在本已探索范围内有明显成本改善证据，但不能抵消预登记38例逐例门槛失败。17的30对成本相同，只描述此样本观察。

共同质量目标时间（固定历史B均成本，仅离线统计）

{table(['例','共同目标成本','B命中','GEPS命中','B条件均时','GEPS条件均时','B限制均时','GEPS限制均时'],qualityrows)}

38例共同目标命中从15/30降至2/30，限制均时489.667→597.146秒；39例20/30→19/30，443.477→519.047秒。自身最终最好到得早不一定意味着同质量解更快；整体时间均值改善不能遮蔽这些退化。

Γ阶段实际提案情况（正式30次均值）

{table(['例','Γ阶段秒','模型数','CDF通过数','原生返回数','原生≥.99数','Γ后最好成本','有原生通过的运行'],gammarows)}

38/39每次都有原生可行改善，已经不再是全部提案被拒。38例Γ后成本平均204.552723，仍高于B最终均成本196.150879；提案成功只是搜索入口改善，不是最终成功。39例Γ后平均332.011231，也仍依赖后续B搜索。

38/39退化诊断及限制

38：保存轨迹中原B阶段完成均数3.2，GEPS1.1；首阶段结束均时144.825→512.795秒。B样本best被原生访问的运行从30/30降至3/30（此向量仅终末诊断读取，未反馈给运行）。Γ额外阶段平均37.601秒，单靠这段预算解释不了全部阶段膨胀。配对半区状态数约1020×1020对1020×1022基本相同；首阶段shortlist1252→3020，原生调用99→251.533，全程native秒228.025→299.148。这支持“改变最好解/成本层后增加首阶段候选评价负担并减少后续覆盖”的机制性线索，尚未证明其独立因果效应。

39：原阶段均数2.6→1.0，首阶段结束均时168.969→582.862；Γ平均37.313秒。B样本best在候选30/30运行都被原生访问，但最终best命中只有2/30，对照5/30。评价器/私有随机流推进规则未变，新增Γ原生调用改变了后续流位置；匹配种子不等于每个相同向量使用同一组MC数，不能把该现象归为换评价器，也不能补抽概率来挑选接受。

共享服务器负载是实质混杂因素：冻结日志第一条资源观察loadavg={obs[0]['loadavg']}，末条={obs[-1]['loadavg']}，逻辑CPU256；本轮观察load1最大{f(resource['maximum_load1'],2)}，可用内存最低{f(resource['minimum_available_GiB'],2)}GiB。另曾只读观察到外部活跃CPU任务增加，但未影响任何外部任务、未公布其命令/身份。原守卫约束未来内存而非CPU负载，未触发，故按既定规则完成有效波，不事后改成资源中断或重跑。复用B来自历史执行，负载不完全一致；时间及限时成本差不能纯归因于Γ算子。完整匿名资源证据见diagnostic_evidence.zip/RESOURCE_LOAD_CONTEXT.json。

覆盖范围内分组（非全部40例验收）

{table(['分组','本轮例号','覆盖例数','均成本差','归一均差'],groups)}

独立完整性与时间审计

DEEP_TIME_AND_NATIVE_RECORD_AUDIT通过：420条有效终末记录、{A['native_observations_checked']}条已保存原生观察、{A['raw_input_SHA_files_verified']}项输入SHA；核对每组选择、成本、容量配置、M/P0/.975、种子、源冻结及五段时间链。最大实际保存后时长{f(A['max_actual_elapsed'],6)}秒，小于600；原生调用截止585秒、结果/worker/终末fsync顺序由冻结审计核验。没有重新采样或更换评价器来认证结果。正式运行随机流证据来自原依赖字节相同加功能回放，不虚称重新模拟了全部正式MC流。

统计假设与探索选择

符号翻转依赖零假设下配对差符号对称/可交换，bootstrap将30种子对视为独立抽样；同一服务器共享负载可能削弱这些假设。指定旧40例与固定种子已在前序候选和本轮首种子功能预检中查看，GEPS由A02负结果启发，七例先导不是未见数据确认。Holm七项不校正所有历史候选选择，置信区间也未作选择校正；应按探索性、条件性证据解读，不外推未覆盖33例。

失败记录保留在前序 https://github.com/quanliangwen/1/tree/c4d546f706c509d6f0b09475cb306b737d49f3d2/CCMCKP/B_Gamma_flow_20261109 。本轮没有通过先导，不运行全40；下一单一机制若继续，应先验证Γ后最好解变化怎样影响B首阶段候选层/评价负担，再独立登记，不能直接增减Γ半径或删掉38例。本轮未实现下一机制。

冻结、文件与复核

事前登记提交9b9ef15f5e31c198cb234674495f47472494dc1c，早于07:25:42Z唯一启动；预检证据提交397d92a39a43488a2609c53e3a9e2c30de307500。FREEZE.json SHA=c969e4718976853ee3ffabcff160bb2ab63ceea11208dc6e4c37a002f59cf4dc，43个文件逐项核对。source_frozen.zip SHA={sha(R/'source_frozen.zip')}；results_complete.zip SHA={sha(R/'results_complete.zip')}。全量文件SHA和远端核验以FILE_MANIFEST.json/SHA256SUMS及上传收据为准。

source_frozen.zip包含原B完整14成员、候选、驱动、统计及独立审计源码；results_complete.zip保留所有本轮尝试、控制日志、全部复用B、输入SHA登记、原生记录和终末快照；preflight_evidence.zip保留所有预检。原始输入继续复用已交付的CCMCKP/B_CDF_DRO_MITM_R04_20261102/inputs_frozen.zip，SHA=e5ebd0a26ff4a3d6d8e66cd2c3e0a342d8268dcf831315bb9fe657d9b4fb88b7，来源未改，不含热启动。statistics.xlsx全部14组汇总、420次记录、7对比较及共同目标与源JSON逐字段核对，公式错误0，8个工作表已视觉检查。离线复核/依赖及已结束入口说明见RUN_COMMANDS.txt。

本地暂存环境曾出现E:\\codex\\CCMCKP…目录不可见，原因未确认。运行时与冻结件始终在服务器、事前材料已在GitHub，未重启实验或改运行源码；当前交付从服务器及GitHub恢复、逐文件SHA校验。完整性证据以服务器冻结和远端实际文件为准，恢复过程不作为算法改善证据。
'''
(R/'RESULTS_中文.md').write_text(report,encoding='utf8')
dump(R/'TASK_OUTCOME.json',{'scope':'fixed7 pilot, not full40','candidate_valid':210,'B_reused_comparison':210,'B_reused_archive':1200,'cost_gate':G['cost_gate'],'stability_gate':G['stability_gate'],'time_gate':G['time_gate'],'performance_gate':G['performance_gate'],'full_started':False,'goal_achieved':False,'mean_case_relative_difference':rel,'improved':5,'degraded':[38],'tied':[17],'no_valid_waves_repeated':True})
# Official workbook authored with artifact-tool; this step merely stages identical bytes.
book=R/'outputs/GEPS_pilot_20261109/GEPS_pilot_20261109.xlsx';shutil.copyfile(book,R/'statistics.xlsx')
dump(R/'SPREADSHEET_QA.json',{'passed':True,'source_snapshot_SHA':sha(R/'statistics_snapshot.json'),'workbook_SHA':sha(R/'statistics.xlsx'),'artifact_tool_authoring':True,'saved_XML_reconciled':True,'summaries':14,'raw_terminal_rows':420,'paired_cases':7,'sheets':8,'formula_errors':0,'visual_reviews':13,'all_sheets_visually_reviewed':True,'required_cost_time_pair_quality_fields_reconciled':True,'scope':'Visual review plus full saved XML field comparison; not an Excel desktop engine run.'})
diag=R/'diagnostics'
with zipfile.ZipFile(R/'diagnostic_evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 m={}
 for p in sorted(diag.iterdir()):
  if p.is_file():z.write(p,p.name);m[p.name]={'sha256':sha(p),'bytes':p.stat().st_size}
 z.writestr('MEMBER_SHA.json',json.dumps(m,indent=2))
print(json.dumps({'relative':rel,'means':means,'Gamma':[{k:v for k,v in x.items() if k!='rows'} for x in gamma],'resource':{k:v for k,v in resource.items() if k!='by_wave'}},ensure_ascii=False,indent=1))
