import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const input=path.resolve(process.argv[2]);
const sourceText=await fs.readFile(input,'utf8');const d=JSON.parse(sourceText);const sourceHash=createHash('sha256').update(sourceText).digest('hex');
const candidate=[...new Set(d.summaries.map(x=>x.arm))].filter(x=>x!=='B').join('/');
const which=d.which??'pilot';const stamp=d.snapshot_utc;
const iso=`${stamp.slice(0,4)}-${stamp.slice(4,6)}-${stamp.slice(6,8)}T${stamp.slice(9,11)}:${stamp.slice(11,13)}:${stamp.slice(13,15)}Z`;
const dated=new Date(iso).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false});
const outdir=path.join(root,'outputs','GEPS_pilot_20261109');await fs.mkdir(outdir,{recursive:true});
const name=process.argv[3]??`${candidate}_${which==='pilot'?'先导':'全量'}统计_${stamp}`;
const w=Workbook.create();
function table(tab,title,headers,rows,widths=[]){
 const s=w.worksheets.add(tab);s.showGridLines=false;
 const all=s.getRangeByIndexes(0,0,Math.max(rows.length+9,23),headers.length);all.format={font:{name:'Microsoft YaHei',size:10},columnWidth:16,rowHeight:23,verticalAlignment:'center'};
 s.getRange('A2').values=[[title]];s.getRange('A2').format.font={name:'Microsoft YaHei',size:14,bold:true};
 s.getRange('A3').values=[[`${dated} 北京时间；只统计终末记录，缺30次有效的官方avg/std/CV留空。`]];
 s.getRangeByIndexes(4,0,1,headers.length).values=[headers];s.getRangeByIndexes(4,0,1,headers.length).format={fill:'#243B53',font:{name:'Microsoft YaHei',size:10,bold:true,color:'#FFFFFF'},horizontalAlignment:'center',rowHeight:27};
 if(rows.length)s.getRangeByIndexes(5,0,rows.length,headers.length).values=rows;
 for(const [col,width] of widths)s.getRange(`${col}5:${col}${Math.max(6,rows.length+5)}`).format.columnWidth=width;
 s.freezePanes.freezeRows(5);return s;
}
const ss=d.summaries;const last=ss.length+5;
const mean=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:null;
const per=arm=>ss.filter(x=>x.arm===arm);
const B=per('B'),C=per(candidate);const ready=ss.every(x=>x.valid===30);
const bm=ready?mean(B.map(x=>x.avg)):null,cm=ready?mean(C.map(x=>x.avg)):null;
const quality=d.stage_gate?.reference_quality_times??[];
const qmean=(arm,key)=>quality.length?mean(quality.map(x=>x.arms[arm][key])):null;
const qhits=arm=>quality.reduce((n,x)=>n+x.arms[arm].hits,0);
const comps=d.comparisons;
const summaryRows=[
 ['覆盖算例',B.length,C.length,null,which==='full'?'要求完整40例':'固定7例先导；不外推全部40例'],
 ['有效次数',B.reduce((n,x)=>n+x.valid,0),C.reduce((n,x)=>n+x.valid,0),null,'每例30次；先导不计入候选全量'],
 ['各例avg再平均',bm,cm,ready?cm-bm:null,'不同规模原成本的等权均值；非全局最优成本'],
 ['归一化均成本指数',ready?1:null,ready?1+mean(comps.map(x=>x.relative_mean_difference)):null,ready?mean(comps.map(x=>x.relative_mean_difference)):null,'每例先除B均成本，再等权平均'],
 ['改善/退化例数',null,null,null,ready?`${comps.filter(x=>x.relative_mean_difference< -1e-10).length}改善 / ${comps.filter(x=>x.relative_mean_difference>1e-10).length}退化 / ${comps.filter(x=>Math.abs(x.relative_mean_difference)<=1e-10).length}持平`:'未完整有效，暂不能验收'],
 ['各例样本std再平均',ready?mean(B.map(x=>x.std)):null,ready?mean(C.map(x=>x.std)):null,null,'原成本单位；分规模明细见成本表'],
 ['各例CV再平均',ready?mean(B.map(x=>x.CV)):null,ready?mean(C.map(x=>x.CV)):null,null,'均值归一的描述性波动，不隐去上升例'],
 ['最终最好首次达到均秒',ready?mean(B.map(x=>x.mean_final_best_first_seconds)):null,ready?mean(C.map(x=>x.mean_final_best_first_seconds)):null,null,'每次自身最终最好；不同质量，不能单独认定搜索效率'],
 ['同B均成本目标限制均秒',qmean('B','restricted_seconds'),qmean(candidate,'restricted_seconds'),quality.length?qmean(candidate,'restricted_seconds')-qmean('B','restricted_seconds'):null,'未命中按600秒计，只填时间，不填失败成本'],
 ['同B均成本目标命中次数',quality.length?qhits('B'):null,quality.length?qhits(candidate):null,null,'共同质量目标不进入worker输入'],
 ['实际运行均秒',ready?mean(B.map(x=>x.mean_actual_runtime)):null,ready?mean(C.map(x=>x.mean_actual_runtime)):null,null,'含Popen前起钟、加载/初始化/评价/保存/fsync'],
 ['已登记性能门槛',null,null,null,String(which==='full'?d.full_gate?.performance_gates_passed:d.stage_gate?.performance_gate)],
 ['成本门槛',null,null,null,String(d.stage_gate?.cost_gate)],
 ['std/CV门槛',null,null,null,String(d.stage_gate?.stability_gate)],
 ['共同目标时间门槛',null,null,null,String(d.stage_gate?.time_gate)],
 ['完整目标状态',null,null,null,which==='full'?'还须核对全部目标、独立审计和GitHub远端SHA收据':'先导未通过，完整目标未完成；未扩展全量']
];
for(const row of summaryRows){if(row[3]==null&&typeof row[1]==='number'&&typeof row[2]==='number')row[3]=row[2]-row[1];}
const overviewSummary=table('验收汇总',`${candidate}对上传B：${which==='full'?'40例全量':'七例先导'}`,['指标','B','候选','候选减B','含义与限制'],summaryRows,[['A',32],['B',24],['C',24],['D',24],['E',100]]);
overviewSummary.getRange('B6:D18').setNumberFormat('0.000000');overviewSummary.getRange('D9').setNumberFormat('0.00%');overviewSummary.getRange('B12:D12').setNumberFormat('0.00%');for(const row of [6,7,15])overviewSummary.getRange(`B${row}:D${row}`).setNumberFormat('0');
const state={valid_complete:'30次有效完成',running:'运行中',unstarted:'未启动',ordinary_failure_complete:'终末含失败',resource_interrupted:'资源中断，保留证据',infrastructure_incomplete:'基础设施未完成'};
const overview=table('成本与有效率',`B与${candidate}：${which==='pilot'?'七例先导':'40例全量'}`,
 ['版本','编号','算例','组数','登记','终末','有效','失败','待终末','best','avg','样本std','CV','波状态','失败原因'],
 ss.map(x=>[x.arm,x.index,x.instance,x.m,x.registered,x.terminal,x.valid,x.failed,x.pending,x.best,x.avg,x.std,x.CV,state[x.wave_status]??x.wave_status,JSON.stringify(x.failure_reasons)]),
 [['A',9],['B',8],['C',28],['D',8],['E',9],['F',9],['G',9],['H',9],['I',10],['N',26],['O',35]]);
overview.getRange(`J6:L${last}`).setNumberFormat('0.000000');overview.getRange(`M6:M${last}`).setNumberFormat('0.00%');
overview.getRange(`A${last+3}`).values=[['终末记录']];overview.getRange(`B${last+3}`).formulas=[[`=SUM(F6:F${last})`]];
overview.getRange(`D${last+3}`).values=[['有效记录']];overview.getRange(`E${last+3}`).formulas=[[`=SUM(G6:G${last})`]];
const timing=table('时间与目标',`实际时间、最终最好首次达到及固定目标`,
 ['版本','编号','有效','最终最好首次均秒','命中30次best次数','命中best条件均秒','实际运行均秒','实际最短秒','实际最长秒','原定目标成本','目标命中数','目标条件均秒','目标限制均秒'],
 ss.map(x=>{const r=d.terminal_records.filter(r=>r.arm===x.arm&&r.index===x.index).map(r=>r.elapsed_upper).filter(t=>t!=null);return[x.arm,x.index,x.valid,x.mean_final_best_first_seconds,x.best_hits,x.conditional_best_hit_seconds,x.mean_actual_runtime,r.length?Math.min(...r):null,r.length?Math.max(...r):null,x.target_cost,x.target_hits,x.conditional_target_seconds,x.restricted_target_seconds];}),
 [['A',9],['B',8],['C',9],['D',25],['E',23],['F',27],['G',24],['H',20],['I',20],['J',23],['K',17],['L',26],['M',26]]);
timing.getRange(`D6:M${last}`).setNumberFormat('0.000000');
timing.getRange(`E6:E${last}`).setNumberFormat('0');timing.getRange(`K6:K${last}`).setNumberFormat('0');
const cc=d.comparisons;const clast=cc.length+5;
const pair=table('配对比较',`${candidate}−B：负值表示候选成本更低`,
 ['编号','完整30对可检验','均成本差','相对均成本差','差中位数','配对dz','描述性区间下限','描述性区间上限','符号翻转p','Holm p','仅B有效','仅候选有效','配对有效率精确p'],
 cc.map(c=>[c.index,c.assessable,c.mean_difference??null,c.relative_mean_difference??null,c.median_difference??null,c.paired_dz??null,c.paired_bootstrap_95?.[0]??null,c.paired_bootstrap_95?.[1]??null,c.p??null,c.holm_p??null,c.reference_only_valid,c.candidate_only_valid,c.paired_validity_p??null]),
 [['A',8],['B',22],['C',22],['D',23],['E',21],['F',18],['G',25],['H',25]]);
pair.getRange(`C6:J${clast}`).setNumberFormat('0.000000');pair.getRange(`D6:D${clast}`).setNumberFormat('0.00%');
pair.getRange(`M6:M${clast}`).setNumberFormat('0.000000');
pair.getRange(`C6:D${clast}`).conditionalFormats.add('cellIs',{operator:'greaterThan',formula:1e-8,format:{fill:'#FDE8E7',font:{color:'#9C1C20'}}});
pair.getRange(`C6:D${clast}`).conditionalFormats.add('cellIs',{operator:'lessThan',formula:-1e-8,format:{fill:'#E3F2E7',font:{color:'#176B3B'}}});
const rr=d.terminal_records;
const raw=table('逐次终末',`终末记录：失败不填成本`,
 ['版本','编号','重复','种子','有效','原因','成本','原生返回','最终最好首次秒','保存后实际秒','原定目标达到秒','原生调用','原生评价秒','阶段数'],
 rr.map(r=>[r.arm,r.index,r.rep,832272+r.rep,r.valid,r.reason,r.cost,r.probability??null,r.found_seconds??null,r.elapsed_upper,r.target_time??null,r.native_calls??null,r.native_seconds??null,r.stages??null]),
 [['A',9],['B',8],['C',8],['D',15],['E',9],['F',32],['G',22],['H',20],['I',25],['J',23],['K',26]]);
raw.getRange('A3').values=[[`来源：${path.basename(input)}；SHA256 ${sourceHash}。每行一条原始终末观察。`]];
if(rr.length)raw.getRange(`G6:M${rr.length+5}`).setNumberFormat('0.000000');
if(rr.length)raw.getRange(`L6:L${rr.length+5}`).setNumberFormat('0');
const attempts=d.own_attempts??[];
table('运行波与资源','本候选任务目录的全部尝试；外部固定对照由冻结登记另列',
 ['阶段','编号','版本','尝试','状态','登记重复数','派发并发上限','终末数','有效数','派发可用GiB','派发需求GiB','单进程未来界GiB','观察峰值GiB','目录'],
 attempts.map(x=>[x.phase,x.index,x.arm,x.attempt,x.status,x.workers,x.parallel_limit??x.workers,x.terminal??null,x.valid??null,x.resources_at_dispatch?.available_bytes/2**30||null,x.resources_at_dispatch?.required_bytes/2**30||null,x.resources_at_dispatch?.worker_future_bound/2**30||null,x.peak_worker_rss/2**30||null,path.basename(x.directory)]),
 [['A',24],['B',8],['C',9],['D',8],['E',32],['F',19],['G',22],['N',90]]);
const aux=d.stage_gate?.reference_quality_times??[];
table('共同质量目标时间','预登记辅助指标：达到固定B均成本；只用于离线统计',
 ['编号','固定B均成本目标','B命中数','候选命中数','B命中条件均秒','候选命中条件均秒','B限制均秒','候选限制均秒'],
 aux.map(x=>[x.index,x.fixed_reference_mean_cost_target,x.arms.B.hits,x.arms[candidate].hits,x.arms.B.conditional_seconds,x.arms[candidate].conditional_seconds,x.arms.B.restricted_seconds,x.arms[candidate].restricted_seconds]),
 [['A',8],['B',27],['C',17],['D',20],['E',25],['F',29],['G',22],['H',25]]);
if(which==='full'){
 const groups=[['全部',1,Infinity],['小组',1,5],['中组',6,20],['大组',21,Infinity]];
 const grouped=groups.map(([label,lo,hi])=>{
  const indices=[...new Set(ss.filter(s=>s.m>=lo&&s.m<=hi).map(s=>s.index))];
  const comps=cc.filter(c=>indices.includes(c.index)&&c.assessable);
  const ready=comps.length===indices.length&&indices.length>0;
  const mean=v=>v.reduce((a,b)=>a+b,0)/v.length;
  const ba=ready?mean(indices.map(i=>ss.find(s=>s.arm==='B'&&s.index===i).avg)):null;
  const ca=ready?mean(indices.map(i=>ss.find(s=>s.arm===candidate&&s.index===i).avg)):null;
  return [label,indices.length,comps.length,ready,ba,ca,ready?mean(comps.map(c=>c.mean_difference)):null,ready?mean(comps.map(c=>c.relative_mean_difference)):null,ready?comps.filter(c=>c.relative_mean_difference< -1e-10).length:null,ready?comps.filter(c=>c.relative_mean_difference>1e-10).length:null,ready?comps.filter(c=>Math.abs(c.relative_mean_difference)<=1e-10).length:null];
 });
 const gs=table('全量分组门槛','仅完整覆盖后形成官方总体/分组统计；未完成不能据覆盖子集判全目标通过',
  ['范围','所需算例','完整有效对数','全范围可判','B算例均成本均值','候选算例均成本均值','原成本均差','归一化均差','改善例数','退化例数','持平例数'],grouped,
  [['A',12],['B',15],['C',20],['D',19],['E',29],['F',32],['G',22],['H',22],['I',16],['J',16],['K',16]]);
 gs.getRange('E6:G9').setNumberFormat('0.000000');gs.getRange('H6:H9').setNumberFormat('0.00%');
}
const notes=[
 [
  "源数据快照",
  "statistics_snapshot.json：冻结控制器结束后的独立终末重算；数据ZIP包含210次候选及复用的全部1200次B对照。"
 ],
 [
  "唯一对照",
  "本次上传B；候选只增加Γ风险优先ε约束提案，不继承R04/R08F/R09其他搜索算子。"
 ],
 [
  "单一机制",
  "Mavrotas(2009)普通ε约束式(2)：在原B六种降成本上限下最小化同一个Γ最坏负载。不是AUGMECON，不声称强Pareto保证。DOI10.1016/j.amc.2009.03.037。"
 ],
 [
  "Γ集合",
  "Bertsimas–Sim预算集紧凑对偶；Γ0…m、经验均值/观测最大偏差、45秒、单模型.75秒、池4均保持A02；不缩小半径。DOI10.1007/s10107-003-0396-4。"
 ],
 [
  "提案门槛",
  "原B首分区float32逐层卷积及反向CDF矩阵评分δ=.00025，≥.975才原生核验；M=1000000、P0=.99，精确/MC、索引、快速拒绝、缓存和随机流推进不变。"
 ],
 [
  "独立起点",
  "种子832273—832302，每次由原B初始化，不读历史解，不跨种子迁移权重。七例顺序17/38/39/40/25/18/14事前固定。"
 ],
 [
  "执行状态",
  "210次候选全部有效；七例先导性能门槛未通过；未启动40例或全新1200次。有效B全部复用，无有效波重跑。"
 ],
 [
  "官方统计",
  "每版本每例必须30有效才填avg/std/CV；std为ddof=1；失败原因独立列，不填虚假成本。"
 ],
 [
  "时间",
  "Popen前起钟，含导入、屏障、SHA、加载、独立初始化、模型/评分/原生评价及保存fsync；总预算600秒，预留15秒。保留原B自然完成，25例允许提前结束。"
 ],
 [
  "最好时间",
  "最终最好首次均秒按各次自己的最终最好定义；best命中条件均秒只对命中该版本30次best的运行平均。两种指标不混用。"
 ],
 [
  "共同目标",
  "原定raw目标保持；另以历史B固定均成本作为事前登记的共同质量目标，仅离线统计，未命中限制时间600，不填失败成本。"
 ],
 [
  "统计检验",
  "配对均差双侧符号翻转：≤20非零差精确，否则99999随机翻转加观察值；先导Holm七项校正，报告配对dz效应量。"
 ],
 [
  "区间限制",
  "19999配对bootstrap百分位95%是描述性非同时区间，未校正多轮候选探索；不显著不能解释为等效或无用。"
 ],
 [
  "检验假设",
  "符号翻转依赖零假设下符号对称/可交换；bootstrap按30种子对独立抽样。共享负载和复用历史B使因果解释受限。"
 ],
 [
  "实际负载",
  "运行中外部CPU任务增多，14例末段loadavg约369而逻辑CPU256；未触发原RAM守卫。不得将该混杂因素事后删除或据此重跑有效波。"
 ],
 [
  "资源",
  "上限30，原未来内存包络、峰值×1.25、外部增长、至少5GiB余量、磁盘守卫；另加256MiB Γ模型余量。七波实际均30。"
 ],
 [
  "失败证据",
  "A01/A02成本优先提案在38/39全部CDF拒绝的证据保留旧GitHub目录；本轮解决提案通过不代表最终性能通过。"
 ],
 [
  "38例诊断",
  "平均成本退化约.431%；原生通过的Γ提案仍改变起点与原B阶段覆盖。首阶段shortlist3020对1252、原生调用约252对99；同期CPU负载变化阻止纯因果归因。"
 ],
 [
  "探索选择",
  "固定旧算例/强制种子已用于前序探索及首种子功能预检，不是未见数据确认；本轮完整七例全报，Holm不覆盖历次方案选择。"
 ],
 [
  "保证边界",
  "Γ代理不是原CDF分布集合，观测最大值不是真实支撑界；CDF扰动半径未校准覆盖率。原生返回≥.99不等于未知分布覆盖、总体置信证书或全局最优。"
 ],
 [
  "验收",
  "逐例均成本不劣且整体严格改善，std/CV跨例平均和共同目标限制均时均不劣；任一不满足禁止扩展。覆盖7/40，不能报告全40目标完成。"
 ],
 [
  "来源",
  "原始终末、评价记录、输入SHA及时间日志见results_complete.zip；冻结43文件见source_frozen.zip/FREEZE.json；事前登记提交9b9ef15。"
 ]
];
const noteSheet=table('口径与局限','证据范围与判断限制',['项目','说明'],notes,[['A',27],['B',135]]);
noteSheet.getRange(`B6:B${notes.length+5}`).format.wrapText=true;noteSheet.getRange(`A6:B${notes.length+5}`).format.autofitRows();
w.recalculate();
const errors=await w.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:30},summary:'formula error scan'});
await fs.writeFile(path.join(outdir,name+'_checks.ndjson'),errors.ndjson);
const img=await w.render({sheetName:'成本与有效率',range:`A1:N${Math.min(last+3,19)}`,scale:1.2,format:'png'});
await fs.writeFile(path.join(outdir,name+'_preview.png'),new Uint8Array(await img.arrayBuffer()));
for(const sheet of ['验收汇总','时间与目标','配对比较','逐次终末','运行波与资源','共同质量目标时间','口径与局限',...(which==='full'?['全量分组门槛']:[])]){const im=await w.render({sheetName:sheet,range:sheet==='口径与局限'?`A1:B${notes.length+5}`:sheet==='验收汇总'?`A1:E${summaryRows.length+5}`:sheet==='全量分组门槛'?'A1:K9':'A1:H10',scale:1,format:'png'});await fs.writeFile(path.join(outdir,name+'_'+sheet+'.png'),new Uint8Array(await im.arrayBuffer()));}
// Inspect every official cost/time/comparison row, including all deteriorations.
// Raw 420/2400-row numeric reconciliation is done on saved XML, not screenshots.
for(const [sheet,endColumn,count] of [['成本与有效率','O',ss.length],['时间与目标','M',ss.length],['配对比较','M',cc.length],['共同质量目标时间','H',aux.length],['运行波与资源','N',attempts.length]]){
 for(let first=6,page=1;first<=count+5;first+=20,page++){
  const end=Math.min(first+19,count+5);const im=await w.render({sheetName:sheet,range:`A${first}:${endColumn}${end}`,scale:1,format:'png'});
  await fs.writeFile(path.join(outdir,`${name}_QA_${sheet}_${page}.png`),new Uint8Array(await im.arrayBuffer()));
 }
}
const book=await SpreadsheetFile.exportXlsx(w);await book.save(path.join(outdir,name+'.xlsx'));
console.log(JSON.stringify({output:path.join(outdir,name+'.xlsx'),terminal:rr.length,candidate,which}));console.log(errors.ndjson);
