import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,json,hashlib,itertools
import numpy as np
H=Path(__file__).parent;I=H/'iterations/I011_robust_block_mitm';sys.path[:0]=[str(I/'candidate'),str(I/'vendor313')]
from block_exchange import block_states,score_batches,lowest_cost_indices
from pair_exchange import tilted_fourier
rng=np.random.default_rng(1011);checks=0;largest=0.;records=[]
for m in [6,7]:
 for trial in range(4):
  B=16 if trial%2==0 else 64;groups=[np.array([g,g+m]) for g in range(m)];cost=rng.uniform(1.,10.,2*m);hist=rng.uniform(0.,1.,(2*m,B));hist/=hist.sum(axis=1)[:,None];hist*=rng.uniform(.95,1.,(2*m,1));F,W=tilted_fourier(hist);center=[int(g[0]) for g in groups]
  for size in [2,3,4,6]:
   free=tuple(reversed(rng.choice(m,size,replace=False).tolist()));left,right,LF,RF,lc,rc=block_states(F,cost,groups,free);rest=np.prod(F[[center[g] for g in range(m) if g not in free]],axis=0) if size<m else np.ones(F.shape[1],complex);fixed=sum(cost[center[g]] for g in range(m) if g not in free);expected=np.zeros((len(left),len(right)))
   for i,l in enumerate(left):
    for j,r in enumerate(right):
     q=center.copy()
     for g,item in zip(free,tuple(l)+tuple(r)):q[g]=int(item)
     p=np.array([1.])
     for item in q:p=np.convolve(p,hist[item])[:B]
     expected[i,j]=p.sum();assert abs(fixed+lc[i]+rc[j]-sum(cost[q]))<1e-12;checks+=1
   for batch in [1,3,64]:
    actual=np.empty_like(expected);covered=0
    for a,b,scores in score_batches(LF,RF,rest,W,batch):actual[:,a:b]=scores;covered+=len(left)*(b-a)
    err=float(np.max(np.abs(actual-expected)));largest=max(largest,err);assert covered==len(left)*len(right) and err<3e-12;checks+=actual.size
   records.append(dict(groups=m,trial=trial,bins=B,free=list(free),combinations=expected.size))
for trial in range(100):
 costs=rng.integers(0,20,(7,13)).astype(float);scores=rng.uniform(0,1,costs.shape);mask=rng.uniform(0,1,costs.shape)>.3
 idx=lowest_cost_indices(costs,scores,mask,3);allidx=np.flatnonzero(mask);assert len(idx)==min(3,len(allidx)) and all(mask.flat[j] for j in idx)
 if len(idx):assert np.all(np.diff(costs.ravel()[idx])>=0) and costs.ravel()[idx].max()<=np.sort(costs.ravel()[allidx])[len(idx)-1]
 checks+=1
d=dict(passed=True,checks=checks,largest_absolute_CDF_error=largest,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')},scope='2/3/4/6-free-group MITM scores for every choice compared with independent full positive convolution; noncontiguous item groups, arbitrary free order,3batchsizes, exact cost assembly and masked cheapest proposals. Floating scores only; unchanged integer acceptance must certify every new vector.',records=records)
with (I/'MATH_CHECK.json').open('x') as f:json.dump(d,f,indent=2)
print(json.dumps({k:v for k,v in d.items() if k!='records'}))
