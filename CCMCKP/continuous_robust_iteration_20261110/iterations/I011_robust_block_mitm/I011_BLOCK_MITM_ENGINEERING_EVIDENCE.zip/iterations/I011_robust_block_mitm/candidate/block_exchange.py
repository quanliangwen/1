"""Four/six-group meet-in-the-middle robust-CDF proposal neighborhoods.

All scores are guidance only. Every accepted vector needs the unchanged raw
integer .99 certificate. Batch boundaries limit uninterruptible matrix work.
"""
import itertools,time,math
import numpy as np
from engine import worst_cdf_hist
from pair_exchange import tilted_fourier
from risk_models import RiskProposals

def block_states(F,cost,groups,free):
 free=tuple(map(int,free));cut=len(free)//2
 if len(free)<2 or len(set(free))!=len(free):raise ValueError('Distinct free groups required')
 left=np.asarray(list(itertools.product(*(groups[g] for g in free[:cut]))),dtype=int)
 right=np.asarray(list(itertools.product(*(groups[g] for g in free[cut:]))),dtype=int)
 LF=np.prod(F[left],axis=1);RF=np.prod(F[right],axis=1)
 return left,right,LF,RF,np.sum(cost[left],axis=1),np.sum(cost[right],axis=1)

def score_batches(LF,RF,rest,W,batch=64):
 weighted=LF*(rest*W)
 for start in range(0,len(RF),batch):
  stop=min(len(RF),start+batch)
  yield start,stop,np.real(weighted@RF[start:stop].T)

def lowest_cost_indices(costs,scores,mask,take=3):
 idx=np.flatnonzero(mask)
 if len(idx)>take:
  positions=np.argpartition(costs.ravel()[idx],take-1)[:take];idx=idx[positions]
 if len(idx):idx=idx[np.lexsort((idx,-scores.ravel()[idx],costs.ravel()[idx]))]
 return idx

class RobustBlocks(RiskProposals):
 def run(self):
  B=4096;m=len(self.s.groups);groups=self.s.groups;rng=np.random.default_rng(self.s.seed+110011)
  records=sorted(self.s.pool.values(),key=lambda r:(r['cost'],r['selection']));centers=[];seen=set()
  def add(r):
   q=tuple(r['selection'])
   if q not in seen:seen.add(q);centers.append(q)
  for level in [.995,.992,.999,.9901,.997,.993,.9995,.991]:
   eligible=[r for r in records if r['certificate']['lower']>=level]
   if eligible:add(eligible[0])
  for k in np.linspace(0,len(records)-1,min(5,len(records)),dtype=int):add(records[int(k)])
  if not centers:return
  transforms={};executed={};blocks=0
  for delta in [0.,.00025,.0005]:
   if self.remaining()<15:break
   hist=np.asarray([worst_cdf_hist(a,self.s.T,B,delta) for a in self.s.inst.samples]);transforms[delta]=tilted_fourier(hist);executed[delta]=0
  if not transforms:return
  # Interleave uncertainty levels within each block/center, so the first level
  # cannot consume the entire extension before robust levels are exercised.
  for sweep in range(6):
   for center in centers:
    if self.remaining()<15:break
    size=6 if sweep%3==2 and m>=6 and self.remaining()>45 else 4
    size=min(size,m);free=tuple(sorted(map(int,rng.choice(m,size,replace=False))))
    if math.prod(len(groups[g]) for g in free)>1000000:free=free[:4];size=len(free)
    cap=self.s.cost_of(center);fixed_cost=cap-sum(self.s.cost[center[g]] for g in free)
    for delta,(F,W) in transforms.items():
     if self.remaining()<12:break
     started=time.monotonic();rest=np.ones(F.shape[1],complex)
     for g in range(m):
      if g not in free:rest*=F[center[g]]
     center_score=float(np.real(np.prod(F[list(center)],axis=0)@W));floor=max(.985 if delta==0. else .95,center_score-.005)
     left,right,LF,RF,lc,rc=block_states(F,self.s.cost,groups,free);proposals={};processed=0;matrix_seconds=0.
     iterator=score_batches(LF,RF,rest,W,64)
     while self.remaining()>9:
      before=time.monotonic()
      try:a,b,probs=next(iterator)
      except StopIteration:break
      matrix_seconds+=time.monotonic()-before;processed=b;costs=fixed_cost+lc[:,None]+rc[None,a:b]
      eligible=(costs<cap-1e-7)
      for target in [center_score,max(floor,center_score-.0005),max(floor,center_score-.002),floor,min(.99999,center_score+.002)]:
       for idx in lowest_cost_indices(costs,probs,eligible&(probs>=target),3):
        i,j=np.unravel_index(idx,costs.shape);q=list(center)
        for g,item in zip(free,tuple(left[i])+tuple(right[a+j])):q[g]=int(item)
        q=tuple(q)
        if q not in self.s.decisions:proposals[q]=(float(costs[i,j]),float(probs[i,j]))
     chosen=[];chosen_set=set()
     for target in [center_score,max(floor,center_score-.0005),max(floor,center_score-.002),floor,min(.99999,center_score+.002)]:
      qs=sorted((q for q in proposals if proposals[q][1]>=target),key=lambda q:(proposals[q][0],-proposals[q][1],q))[:3]
      for q in qs:
       if q not in chosen_set:chosen_set.add(q);chosen.append(q)
     checked=[]
     for q in chosen:
      if self.remaining()<6:break
      self.proposed.add(q);self.s.native_check(q,f'robust_block_{size}_delta{delta}',True);decision=self.s.decisions.get(q,{})
      checked.append(dict(selection=list(q),cost=proposals[q][0],guide_probability=proposals[q][1],certified=q in self.s.pool,outcome='certified' if q in self.s.pool else 'refuted' if decision.get('infeasible') else 'unresolved',decision=decision))
     blocks+=1;executed[delta]+=1
     self.records.append(dict(kind='robust_block_mitm',center=list(center),center_cost=cap,free_groups=list(free),block_size=size,delta=delta,center_guide=center_score,bins=B,total_combinations=len(left)*len(right),evaluated_combinations=len(left)*processed,complete_block_scan=processed==len(right),eligible_proposals=len(proposals),matrix_seconds=matrix_seconds,seconds=time.monotonic()-started,checked=checked,score_role='floating robust CDF proposal order only; original raw integer acceptance unchanged'))
   if self.remaining()<15:break
  self.records.append(dict(kind='robust_block_total',centers=len(centers),blocks=blocks,uncertainty_levels_executed={str(k):v for k,v in executed.items()},bins=B,all_existing_raw_candidates_retained=True,external_data_used=False,final_hard_gate_added=False))
