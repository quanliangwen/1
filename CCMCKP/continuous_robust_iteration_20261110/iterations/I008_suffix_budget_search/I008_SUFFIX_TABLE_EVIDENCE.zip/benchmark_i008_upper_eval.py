"""Exact-kernel engineering microbenchmark, no solver/qualification claim."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
from functools import lru_cache
import sys,json,pickle,hashlib,gzip,random,time
H=Path(__file__).parent;I=H/'iterations/I008_suffix_budget_search';sys.path[:0]=[str(I/'candidate'),str(I/'vendor313')]
from budget_cdf import exact_upper
from flint import fmpz_poly
P=I/'probe35_old/tree.json';d=json.load(open(P));B=d['time_bins'];K=d['cost_bins'];T=F(d['capacity']);C=F(d['cost_limit']);p=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/d['instance']
cost=[F(x) for x in (p/'cost.txt').read_text().split()];groups=pickle.load(open(p/'node_to_factor.pkl','rb'));groups=[groups[k] for k in sorted(groups,key=int)] if isinstance(groups,dict) else groups;samples=[[F(x) for x in (p/f'{j}_sample.txt').read_text().split()] for j in range(len(cost))]
start=time.monotonic();table=exact_upper(groups,cost,samples,T,C,B,K,d['probability_bits'],reverse=True,collect_stages=True);matrices=table['matrices'];items={}
for j,a in enumerate(samples):
 counts=Counter(int(x*B//T) for x in a);items[j]=fmpz_poly([counts[t] for t in range(B+1)])
rng=random.Random(1009);nodes=[];seen=0;raw_bins=Counter()
with gzip.open(str(P)+'.proof.jsonl.gz','rt') as f:
 for line in f:
  r=json.loads(line)
  if r['kind']=='raw_refuted':raw_bins[r['certificate']['bins']]+=1
  if r['kind']!='budget_cdf':continue
  seen+=1
  if len(nodes)<1000:nodes.append(r)
  else:
   k=rng.randrange(seen)
   if k<len(nodes):nodes[k]=r
@lru_cache(maxsize=4096)
def polynomial(prefix):return (polynomial(prefix[:-1])*items[prefix[-1]]).truncate(B+1) if prefix else fmpz_poly([1])
inputs=[];cdfpolys={};diffpolys={}
for r in nodes:
 prefix=tuple(r['prefix']);key=(len(prefix),r['cost_state']);row=matrices[key[0]][key[1]]
 if key not in cdfpolys:
  cdfpolys[key]=fmpz_poly(list(row));diffpolys[key]=fmpz_poly([row[0]]+[row[t]-row[t-1] for t in range(1,B+1)])
 inputs.append((polynomial(prefix),row,cdfpolys[key],diffpolys[key],int(r['upper_numerator'])))
preparation=time.monotonic()-start;times={}
for tag in ['python_dot','integer_CDF_product','integer_mass_product']:
 start=time.perf_counter()
 for repeat in range(3):
  for poly,row,cdf,mass,expected in inputs:
   if tag=='python_dot':value=sum(int(poly[r])*row[B-r] for r in range(B+1))
   elif tag=='integer_CDF_product':value=int((poly*cdf).truncate(B+1)[B])
   else:value=int((poly*mass).truncate(B+1)(1))
   if value!=expected:raise RuntimeError('Integer kernel mismatch')
 times[tag]=time.perf_counter()-start
result=dict(scope='same fixed exact numerators on1000 deterministic reservoir-sampled own proof nodes,3repetitions; concurrency not controlled, not end-to-end solver speed or cost improvement',all_equal=True,comparisons=len(inputs)*9,proof_nodes_seen=seen,preparation_seconds=preparation,seconds=times,raw_refutation_bins=dict(raw_bins),tree_sha256=hashlib.sha256(P.read_bytes()).hexdigest(),source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(I/'UPPER_KERNEL_DIAGNOSTIC.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
