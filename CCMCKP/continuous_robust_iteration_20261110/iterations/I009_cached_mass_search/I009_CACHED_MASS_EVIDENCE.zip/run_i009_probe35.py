from pathlib import Path
import json,hashlib,subprocess,time
H=Path(__file__).parent;I=H/'iterations/I009_cached_mass_search';J=I/'probe35_old';J.mkdir(exist_ok=True);out=J/'tree.json'
if (J/'REGISTRATION.json').exists() or out.exists():raise RuntimeError('No duplicate engineering trial')
mathcheck=json.load(open(I/'MATH_CHECK.json'));source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')}
if not mathcheck['passed'] or source!=mathcheck['source_sha256']:raise RuntimeError('Math/source verification required')
c=next(c for c in json.load(open(H/'CASES.json')) if c['index']==35);baseline=next(r for r in json.load(open(H/'BASELINE_S10.json'))['rows'] if r['index']==35)
reg=dict(time=time.time(),source_sha256=source,index=35,instance=c['instance'],capacity=str(c['tmax']),cost_limit=str(baseline['old_best']),time_bins=512,cost_bins=256,probability_bits=48,seconds=120,watchdog=170,scope='whole-root bounded engineering feasibility-bound search; no qualification or global exclusion unless exhausted and independently audited',only_scalar_historical_target=True,no_saved_vector_or_true_model=True,no_LSS_calls=True,formal_source_unchanged=True,math_checks=mathcheck['checks'])
(J/'REGISTRATION.json').write_text(json.dumps(reg,indent=2))
cmd=['/home/junhao/miniconda3/bin/python','-u',str(I/'candidate/run_search_bound.py'),'--instance','/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/'+reg['instance'],'--capacity',reg['capacity'],'--cost-limit',reg['cost_limit'],'--time-bins','512','--cost-bins','256','--bits','48','--seconds','120','--out',str(out)]
with (J/'probe.log').open('x') as f:
 start=time.monotonic();r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=170)
(J/'TERMINAL.json').write_text(json.dumps(dict(exit=r.returncode,wall=time.monotonic()-start,source_sha256=source),indent=2))
if r.returncode:raise RuntimeError('Engineering trial failed; records retained')
d=json.load(open(out));print(json.dumps({k:d[k] for k in ['status','visited_nodes','terminal_counts','covered_combinations','remaining_combinations','raw_cost_line_excluded','DP_seconds','seconds']}))
