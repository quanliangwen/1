"""Independent suffix-DP and complete prefix-partition certificate replay."""
from pathlib import Path
from fractions import Fraction as F
from bisect import bisect_left
from collections import Counter
from functools import lru_cache
import sys,json,pickle,math,hashlib,struct,time,argparse,gzip
H=Path(__file__).parent;I=H/'iterations/I009_cached_mass_search';sys.path.insert(0,str(I/'vendor313'))
from flint import fmpz_poly
ap=argparse.ArgumentParser();ap.add_argument('--trial',required=True);a=ap.parse_args();J=I/a.trial;path=J/'tree.json';out=J/'INDEPENDENT_AUDIT.json'
if out.exists():raise RuntimeError('No audit overwrite')
start=time.monotonic();d=json.load(open(path));dp=json.load(open(str(path)+'.dp.json'));reg=json.load(open(J/'REGISTRATION.json'));meta=json.load(open(str(path)+'.run.json'));source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')}
if source!=reg['source_sha256'] or source!=meta['source_sha256']:raise RuntimeError('Registered source mismatch')
for k in ['capacity','cost_limit']:
 if F(d[k])!=F(reg[k]) or F(dp[k])!=F(reg[k]):raise RuntimeError('Cost/capacity changed')
for k in ['time_bins','cost_bins','probability_bits']:
 if d[k]!=reg[k] or dp[k]!=reg[k]:raise RuntimeError('Quantization changed')
if d['instance']!=reg['instance'] or d['DP_status']!=dp['status']:raise RuntimeError('Wrong run/table')
bench=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/d['instance'];reference=json.load(open(H/'RAW_REFERENCE.json'))
for name,sha in meta['input_sha256'].items():
 if hashlib.sha256((bench/name).read_bytes()).hexdigest()!=sha or reference[str(bench/name)]!=sha:raise RuntimeError('Original input drift')
for opened in meta['opened_task_paths']:
 p=Path(opened)
 if p.name.endswith('_dist.txt') or '/lss_cache/' in opened:raise RuntimeError('True model/cache read')
 if bench in p.parents and p.name not in meta['input_sha256']:raise RuntimeError('Unregistered input read')
groups=pickle.load(open(bench/'node_to_factor.pkl','rb'));groups=[list(map(int,groups[k])) for k in sorted(groups,key=int)] if isinstance(groups,dict) else [list(map(int,g)) for g in groups];cost=[F(s) for s in (bench/'cost.txt').read_text().split()];m=len(groups);n=len(cost)
if groups!=d['groups'] or sorted(j for g in groups for j in g)!=list(range(n)) or d['group_order']!=list(range(m)):raise RuntimeError('Invalid partition')
if set(meta['input_sha256'])!={'cost.txt','node_to_factor.pkl',*(f'{j}_sample.txt' for j in range(n))}:raise RuntimeError('Incomplete input inventory')
samples={j:sorted(F(s) for s in (bench/f'{j}_sample.txt').read_text().split()) for j in range(n)}
if any(not a or a[0]<0 for a in samples.values()):raise RuntimeError('Invalid empirical input')
B=d['time_bins'];K=d['cost_bins'];Q=2**d['probability_bits'];T=F(d['capacity']);C=F(d['cost_limit']);mins=[min(cost[j] for j in g) for g in groups];delta=C-sum(mins,F(0));suffixmin=[F(0)]*(m+1)
for g in range(m-1,-1,-1):suffixmin[g]=suffixmin[g+1]+mins[g]
if dp['prefix'] or dp['group_order']!=list(range(m-1,-1,-1)) or dp['minimal_cost']!=str(suffixmin[0]) or dp['remaining_excess']!=str(delta) or dp['Q']!=str(Q):raise RuntimeError('Invalid suffix table model')
hist={};units={}
for g,group in enumerate(groups):
 for j in group:
  cdf=[bisect_left(samples[j],F(t+1)*T/B) for t in range(B+1)];hist[j]=fmpz_poly([cdf[0]]+[cdf[t]-cdf[t-1] for t in range(1,B+1)])
  if delta>=0:
   ratio=(cost[j]-mins[g])*K/delta if delta else None;units[j]=ratio.numerator//ratio.denominator if ratio is not None else (0 if cost[j]==mins[g] else K+1)
def matrix_sha(rows):
 h=hashlib.sha256();h.update(struct.pack('<II',K+1,B+1))
 for row in rows:h.update(struct.pack('<%dQ'%(B+1),*row))
 return h.hexdigest()
U=[(Q,)*(B+1)]*(K+1);matrices={m:U};replayed=[];convs=0
expected=m if delta>=0 and dp['status']=='completed' else len(dp['stages'])
if len(dp['stages'])!=expected:raise RuntimeError('Incomplete claimed table')
for stage,g in enumerate(list(range(m-1,-1,-1))[:expected]):
 diffpolys={row:fmpz_poly([row[0]]+[row[t]-row[t-1] for t in range(1,B+1)]) for row in set(U)};cache={};new=[None]*(K+1)
 for c in range(K,-1,-1):
  values=[0]*(B+1)
  for j in reversed(groups[g]):
   r=units[j]
   if r>c:continue
   key=(j,U[c-r])
   if key not in cache:
    product=(diffpolys[U[c-r]]*hist[j]).truncate(B+1);running=0;row=[]
    for t in range(B+1):
     running+=int(product[t]);quotient,remainder=divmod(running,len(samples[j]));row.append(min(Q,quotient+(remainder>0)))
    cache[key]=tuple(row);convs+=1
   values=[max(x,y) for x,y in zip(values,cache[key])]
  new[c]=tuple(values)
 if any(new[c][t]<new[c][t-1] for c in range(K+1) for t in range(1,B+1)) or any(new[c][t]<new[c-1][t] for c in range(1,K+1) for t in range(B+1)):raise RuntimeError('Nonmonotone DP state')
 U=new;sha=matrix_sha(U)
 if dp['stages'][stage]['group']!=g or dp['stages'][stage]['matrix_sha256']!=sha:raise RuntimeError('DP matrix mismatch')
 matrices[g]=U;replayed.append(dict(group=g,matrix_sha256=sha))
if dp['status']=='completed':
 upper=U[K][B] if delta>=0 else 0
 if str(upper)!=dp['upper_numerator'] or str(Q)!=dp['denominator']:raise RuntimeError('Root table bound mismatch')
@lru_cache(maxsize=2048)
def prefix_poly(prefix):
 return (prefix_poly(prefix[:-1])*hist[prefix[-1]]).truncate(B+1) if prefix else fmpz_poly([1])
def shifted_product(histograms,limit):
 offset=0;polys=[]
 for h in histograms:
  positive=[k for k,v in enumerate(h) if v]
  if not positive:return 0
  first=positive[0];offset+=first;polys.append(fmpz_poly(h[first:]))
 cut=limit-offset+1
 if cut<=0:return 0
 while len(polys)>1:polys=[(polys[k]*polys[k+1]).truncate(cut) if k+1<len(polys) else polys[k] for k in range(0,len(polys),2)]
 return int(polys[0].truncate(cut)(1))
def strict_recount(selection,bins,up):
 hs=[];den=1
 for j in selection:
  q=[]
  for x in samples[j]:
   v=x*bins/T;q.append(-(-v.numerator//v.denominator) if up else v.numerator//v.denominator)
  c=Counter(q);h=[0]*(min(bins,max(q))+1)
  for k,v in c.items():
   if k<len(h):h[k]=v
  hs.append(h);den*=len(q)
 return shifted_product(hs,bins-1),den
def verify_certificate(prefix,cert,accepted):
 num,den=strict_recount(prefix,cert['bins'],accepted);key='lower_numerator' if accepted else 'upper_numerator'
 if str(num)!=cert[key] or str(den)!=cert['denominator']:raise RuntimeError('Raw leaf recount differs')
 if accepted and 100*num<99*den or not accepted and 100*num>=99*den:raise RuntimeError('False raw leaf decision')
trie={};trie_nodes=1;covered=0;counts=dict(cost=0,budget_cdf=0,raw_refuted=0,raw_accepted=0,unresolved=0);tree_certs=0
def add(prefix):
 global trie_nodes
 if len(prefix)>m or any(j not in groups[g] for g,j in enumerate(prefix)):raise RuntimeError('Invalid tree prefix')
 node=trie
 for j in prefix:
  if '_end' in node:raise RuntimeError('Prefix overlaps ancestor')
  if j not in node:node[j]={};trie_nodes+=1
  node=node[j]
 if node:raise RuntimeError('Duplicate prefix/descendant overlap')
 node['_end']=True
with gzip.open(str(path)+'.proof.jsonl.gz','rt') as f:
 for line in f:
  r=json.loads(line);prefix=r['prefix'];add(prefix);depth=len(prefix);kind=r['kind'];counts[kind]+=1;cover=math.prod(len(g) for g in groups[depth:])
  if str(cover)!=r['cover']:raise RuntimeError('Wrong subtree size')
  covered+=cover;paid=sum((cost[j] for j in prefix),F(0));residual=C-paid-suffixmin[depth]
  if kind=='cost':
   if residual>=0 or str(paid+suffixmin[depth])!=r['minimum_completion_cost']:raise RuntimeError('False cost prune')
  elif kind=='budget_cdf':
   if dp['status']!='completed' or residual<0:raise RuntimeError('Invalid budget bound application')
   ratio=residual*K/delta if delta else None;c=ratio.numerator//ratio.denominator if ratio is not None else K;row=matrices[depth][c];mass=fmpz_poly([row[0]]+[row[t]-row[t-1] for t in range(1,B+1)])
   num=int((prefix_poly(tuple(prefix))*mass).truncate(B+1)(1));den=Q*math.prod(len(samples[j]) for j in prefix)
   if c!=r['cost_state'] or str(num)!=r['upper_numerator'] or str(den)!=r['denominator'] or 100*num>=99*den:raise RuntimeError('False suffix-DP subtree exclusion')
   tree_certs+=1
  elif kind=='raw_refuted':verify_certificate(prefix,r['certificate'],False);tree_certs+=1
  elif kind=='raw_accepted':
   if depth!=m or paid>C or r['candidate']['selection']!=prefix or F(r['candidate']['cost_decimal'])!=paid:raise RuntimeError('Raw candidate outside registered set')
   verify_certificate(prefix,r['candidate']['certificate'],True);tree_certs+=1
  elif kind=='unresolved':
   if depth!=m:raise RuntimeError('Nonleaf unresolved record')
  else:raise RuntimeError('Unknown terminal type')
remaining=0
for r in d['pending_frontier']:
 prefix=r['prefix'];add(prefix)
 if F(r['cost'])!=sum((cost[j] for j in prefix),F(0)):raise RuntimeError('Wrong pending prefix cost')
 remaining+=math.prod(len(g) for g in groups[len(prefix):])
total=math.prod(map(len,groups));visited=trie_nodes-len(d['pending_frontier']);excluded=d['status']=='exhausted' and remaining==0 and counts['raw_accepted']==0 and counts['unresolved']==0
if counts!=d['terminal_counts'] or covered+remaining!=total or str(covered)!=d['covered_combinations'] or str(remaining)!=d['remaining_combinations'] or visited!=d['visited_nodes'] or excluded!=d['raw_cost_line_excluded']:raise RuntimeError('Invalid complete-space accounting or exclusion claim')
result=dict(passed=True,instance=d['instance'],capacity=d['capacity'],cost_limit=d['cost_limit'],status=d['status'],raw_cost_line_excluded=excluded,total_combinations=str(total),covered_combinations=str(covered),pending_combinations=str(remaining),verified_visited_nodes=visited,recomputed_suffix_stages=len(replayed),independent_DP_integer_convolutions=convs,recomputed_tree_certificates=tree_certs,stages=replayed,source_sha256=source,result_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),DP_sha256=hashlib.sha256(Path(str(path)+'.dp.json').read_bytes()).hexdigest(),proof_sha256=hashlib.sha256(Path(str(path)+'.proof.jsonl.gz').read_bytes()).hexdigest(),seconds=time.monotonic()-start,scope='declared cost-line independent full-empirical model only; joint raw/LSS exclusion follows only when fully exhausted; no positive LSS feasibility claim',method='sorted thresholds, CDF-increment integer DP; prefix mass convolved with suffix-CDF increments, exact costs and prefix-free full choice-space partition')
with out.open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='stages'}))
