"""Exhaustive validation of the complete suffix-table branch bound."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,pickle,gzip,itertools,random,math,hashlib
H=Path(__file__).parent;I=H/'iterations/I009_cached_mass_search';sys.path[:0]=[str(I/'candidate'),str(I/'vendor313')]
from budget_cdf import exact_upper
from suffix_search import run_search
from instance import load_instance
root=I/(sys.argv[1] if len(sys.argv)>1 else 'math01');root.mkdir(exist_ok=False);rng=random.Random(1008);checks=0;records=[]
def rational_suffix(groups,cost,samples,T,C,B,K):
 mins=[min(cost[j] for j in g) for g in groups];delta=C-sum(mins,F(0));m=len(groups)
 if delta<0:return {}
 units={j:((0 if cost[j]==mins[g] else K+1) if delta==0 else math.floor((cost[j]-mins[g])*K/delta)) for g in range(m) for j in groups[g]};ys={j:[math.floor(x*B/T) for x in samples[j]] for j in cost}
 U=[[F(1)]*(B+1) for c in range(K+1)];matrices={m:U}
 for g in range(m-1,-1,-1):
  new=[[F(0)]*(B+1) for c in range(K+1)]
  for c in range(K+1):
   for t in range(B+1):
    for j in groups[g]:
     r=units[j]
     if r<=c:new[c][t]=max(new[c][t],sum((U[c-r][t-y] for y in ys[j] if y<=t),F(0))/len(ys[j]))
  U=new;matrices[g]=U
 return matrices
for m in [2,3,4]:
 for trial in range(4):
  folder=root/f'm{m}_t{trial}';folder.mkdir();groups=[list(range(3*g,3*g+3)) for g in range(m)];cost={};samples={}
  for g in range(m):
   for k,j in enumerate(groups[g]):
    cost[j]=F(rng.randrange(k*4,k*4+5),2);samples[j]=[F(rng.randrange(0,9-4*k),2) for _ in range(rng.randrange(3,6))] if k<2 else [F(0)]*rng.randrange(3,6)
  (folder/'cost.txt').write_text('\n'.join(str(float(cost[j])) for j in range(3*m)));(folder/'node_to_factor.pkl').write_bytes(pickle.dumps(groups))
  for j,values in samples.items():(folder/f'{j}_sample.txt').write_text('\n'.join(str(float(x)) for x in values))
  T=F(rng.randrange(3,9),2);truth={}
  for s in itertools.product(*groups):
   outcomes=[sum(x,F(0)) for x in itertools.product(*(samples[j] for j in s))]
   truth[s]=dict(cost=sum((cost[j] for j in s),F(0)),strict=F(sum(x<T for x in outcomes),len(outcomes)),inclusive=F(sum(x<=T for x in outcomes),len(outcomes)))
  optimum=min(v['cost'] for v in truth.values() if v['strict']>=F(99,100));inst=load_instance(folder)
  for label,C in [('below',optimum-F(1,2)),('at',optimum)]:
   out=folder/(label+'.json');d=run_search(inst,str(T),str(C),32,12,16,15,out)
   assert d['raw_cost_line_excluded']==(label=='below' and d['terminal_counts']['unresolved']==0)
   if label=='at':assert d['terminal_counts']['raw_accepted']==1
   checks+=1;prefixes=[];covered=0
   with gzip.open(str(out)+'.proof.jsonl.gz','rt') as f:
    for line in f:
     r=json.loads(line);prefix=tuple(r['prefix']);prefixes.append(prefix);covered+=int(r['cover']);matching=[v for s,v in truth.items() if s[:len(prefix)]==prefix]
     if r['kind']=='cost':assert all(v['cost']>C for v in matching);checks+=1
     elif r['kind']=='budget_cdf':
      upper=F(int(r['upper_numerator']),int(r['denominator']));assert upper<F(99,100)
      for v in matching:
       if v['cost']<=C:assert v['inclusive']<=upper;checks+=1
     elif r['kind']=='raw_refuted':assert truth[prefix]['strict']<F(99,100);checks+=1
     elif r['kind']=='raw_accepted':assert truth[prefix]['strict']>=F(99,100) and truth[prefix]['cost']<=C;checks+=1
     elif r['kind']=='unresolved':
      cert=r['last_certificate'];bins=cert['bins'];low=[];high=[]
      for j in prefix:
       ratios=[x*bins/T for x in samples[j]]
       low.append([min(bins,-(-x.numerator//x.denominator)) for x in ratios]);high.append([min(bins,x.numerator//x.denominator) for x in ratios])
      den=math.prod(len(a) for a in low);lower=sum(sum(x)<bins for x in itertools.product(*low));upper=sum(sum(x)<bins for x in itertools.product(*high))
      assert str(lower)==cert['lower_numerator'] and str(upper)==cert['upper_numerator'] and str(den)==cert['denominator'];assert 100*lower<99*den<=100*upper;checks+=1
     else:raise AssertionError('Unknown proof event')
   for r in d['pending_frontier']:prefixes.append(tuple(r['prefix']));covered+=math.prod(len(g) for g in groups[len(r['prefix']):])
   assert covered==len(truth)
   for k,p in enumerate(prefixes):
    for q in prefixes[:k]:assert p[:len(q)]!=q and q[:len(p)]!=p
   checks+=1
   table=exact_upper(groups,[cost[j] for j in range(3*m)],[samples[j] for j in range(3*m)],T,C,32,12,16,reverse=True,collect_stages=True);reference=rational_suffix(groups,cost,samples,T,C,32,12)
   for depth,rows in reference.items():
    for c in range(13):
     for t in range(33):
      upper=F(table['matrices'][depth][c][t],2**16);assert rows[c][t]<=upper<=rows[c][t]+F(m-depth,2**16);checks+=1
   records.append(dict(groups=m,trial=trial,label=label,capacity=str(T),cost_limit=str(C),true_optimum=str(optimum),status=d['status'],visited=d['visited_nodes'],terminal=d['terminal_counts']))
d=dict(passed=True,checks=checks,input_models=12,tree_runs=len(records),source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')},scope='full item/outcome enumeration verifies every cost or suffix-budget pruning subtree, original raw leaf decisions including unresolved boundary certificates and full prefix partition; independent exact Fraction DP validates every cached suffix cost/time state and rounding error',records=records)
with (I/'MATH_CHECK.json').open('x') as f:json.dump(d,f,indent=2)
print(json.dumps({k:v for k,v in d.items() if k!='records'}))
