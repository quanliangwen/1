"""Exact suffix budget-CDF upper tables guide a complete cost-line search.

Original empirical .99 is the only pruning feasibility predicate. The upper
tables relax fixed choices to adaptive choices and costs/time downwards.
"""
import time,math,json,gzip
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
from functools import lru_cache
from flint import fmpz_poly
from budget_cdf import exact_upper
from exact_oracle import ExactOracle

def run_search(inst,capacity,limit,B,K,bits,seconds,out,started=None):
 start=time.monotonic() if started is None else started;end=start+seconds;out=Path(out);T=F(capacity);C=F(limit);Q=2**bits
 groups=[list(map(int,g)) for g in inst.groups];m=len(groups);cost=[F(s) for s in (inst.path/'cost.txt').read_text().split()];oracle=ExactOracle(inst,capacity,'.99');samples=[oracle.fractions(j) for j in range(inst.n)]
 table=exact_upper(groups,cost,samples,T,C,B,K,bits,reverse=True,deadline=end-2,collect_stages=True);matrices=table.pop('matrices');dpout=Path(str(out)+'.dp.json')
 with dpout.open('x') as f:json.dump(table,f,indent=2)
 mins=[min(cost[j] for j in g) for g in groups];suffixmin=[F(0)]*(m+1)
 for g in range(m-1,-1,-1):suffixmin[g]=suffixmin[g+1]+mins[g]
 delta=C-suffixmin[0];denoms={j:len(samples[j]) for j in range(inst.n)};items={}
 for j in range(inst.n):
  counts=Counter(int(x*B//T) for x in samples[j]);items[j]=fmpz_poly([counts[k] for k in range(B+1)])
 @lru_cache(maxsize=8192)
 def suffix_mass(depth,c):
  row=matrices[depth][c]
  return fmpz_poly([row[0]]+[row[t]-row[t-1] for t in range(1,B+1)])
 counts=dict(cost=0,budget_cdf=0,raw_refuted=0,raw_accepted=0,unresolved=0);visited=0;covered=0;candidates=[];stack=[((),fmpz_poly([1]),F(0),1)];total=math.prod(map(len,groups));status='budget_exhausted'
 with gzip.open(str(out)+'.proof.jsonl.gz','xt',encoding='utf8') as log:
  def terminal(prefix,kind,**fields):
   nonlocal covered
   cover=math.prod(len(g) for g in groups[len(prefix):]);covered+=cover;counts[kind]+=1
   log.write(json.dumps(dict(prefix=list(prefix),kind=kind,cover=str(cover),**fields),separators=(',',':'))+'\n')
  while stack and time.monotonic()<end-2:
   if table['status']!='completed':break
   prefix,poly,paid,pden=stack.pop();depth=len(prefix);visited+=1;residual=C-paid-suffixmin[depth]
   if residual<0:terminal(prefix,'cost',minimum_completion_cost=str(paid+suffixmin[depth]));continue
   c=K if delta==0 else int(residual*K//delta)
   if not 0<=c<=K:raise ArithmeticError('Invalid residual cost state')
   numerator=int((poly*suffix_mass(depth,c)).truncate(B+1)(1));denominator=Q*pden
   if not 0<=numerator<=denominator:raise ArithmeticError('Invalid table upper count')
   if 100*numerator<99*denominator:terminal(prefix,'budget_cdf',cost_state=c,upper_numerator=str(numerator),denominator=str(denominator));continue
   if depth==m:
    decision=None;last=None
    for bins in [1024,4096,16384,65536,262144,1048576]:
     if time.monotonic()>=end-2:break
     if bins>=262144 and end-time.monotonic()<20:break
     last=oracle.certify(prefix,bins,True)
     if last['accepted'] or last['infeasible']:decision=last;break
    if decision is None:terminal(prefix,'unresolved',cost=str(paid),last_certificate=last);continue
    if decision['accepted']:
     candidate=dict(selection=list(prefix),cost_decimal=str(paid),certificate=decision,LSS_qualified=False);candidates.append(candidate);terminal(prefix,'raw_accepted',candidate=candidate);status='found_raw_feasible';break
    terminal(prefix,'raw_refuted',cost=str(paid),certificate=decision);continue
   for j in sorted(groups[depth],key=lambda j:(cost[j],j),reverse=True):stack.append((prefix+(j,),(poly*items[j]).truncate(B+1),paid+cost[j],pden*denoms[j]))
 if not stack and status!='found_raw_feasible':status='exhausted'
 pending=[dict(prefix=list(p),cost=str(c)) for p,_,c,_ in stack];remaining=sum(math.prod(len(g) for g in groups[len(p):]) for p,_,_,_ in stack)
 if covered+remaining!=total:raise ArithmeticError('Tree partition mismatch')
 excluded=status=='exhausted' and counts['unresolved']==0 and counts['raw_accepted']==0
 result=dict(schema='I009_cached_mass_suffix_budget_CDF_tree',status=status,instance=inst.name,capacity=str(T),cost_limit=str(C),time_bins=B,cost_bins=K,probability_bits=bits,Q=str(Q),groups=groups,group_order=list(range(m)),total_combinations=str(total),visited_nodes=visited,terminal_counts=counts,covered_combinations=str(covered),remaining_combinations=str(remaining),pending_frontier=pending,candidates=candidates,raw_cost_line_excluded=excluded,DP_status=table['status'],DP_seconds=table['seconds'],DP_file=dpout.name,seconds=time.monotonic()-start,raw_predicate='all empirical marginals independent; strict sum<T probability>=.99',upper_predicate='exact fixed prefix cost; suffix adaptive budget-CDF table with downward cost/time grids and upward probability division',all_original_samples=True,LSS_calls=0,tail_hard_gate_added=False)
 with out.open('x') as f:json.dump(result,f,indent=2)
 return result
