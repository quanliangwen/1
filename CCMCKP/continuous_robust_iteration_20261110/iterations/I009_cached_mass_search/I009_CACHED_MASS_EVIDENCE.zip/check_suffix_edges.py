from pathlib import Path
import sys,json,pickle,hashlib
H=Path(__file__).parent;I=H/'iterations'/sys.argv[1];sys.path[:0]=[str(I/'candidate'),str(I/'vendor313')]
from instance import load_instance
from suffix_search import run_search
root=I/'edge01';root.mkdir(exist_ok=False);rows=[]
models=[('zero_cost',[0,0,0,0],[0,2,0,2],0,15,False),('cost_empty',[1,1,1,1],[0,0,0,0],1,15,True),('zero_excess',[1,2,1,2],[2,0,2,0],2,15,True),('timeout',[0,0,0,0],[0,2,0,2],0,0,False)]
for name,cost,values,C,seconds,excluded in models:
 p=root/name;p.mkdir();(p/'cost.txt').write_text('\n'.join(map(str,cost)));(p/'node_to_factor.pkl').write_bytes(pickle.dumps([[0,1],[2,3]]))
 for j,v in enumerate(values):(p/f'{j}_sample.txt').write_text(str(v)+'\n')
 result=run_search(load_instance(p),'1',str(C),8,4,8,seconds,p/'tree.json')
 assert result['raw_cost_line_excluded']==excluded
 if name=='zero_cost':assert result['terminal_counts']['raw_accepted']==1
 if name=='cost_empty':assert result['terminal_counts']['cost']==1
 if name=='zero_excess':assert result['terminal_counts']['budget_cdf']==1
 if name=='timeout':assert result['status']=='budget_exhausted' and result['remaining_combinations']=='4' and result['visited_nodes']==0
 rows.append(dict(name=name,status=result['status'],excluded=result['raw_cost_line_excluded'],terminal=result['terminal_counts']))
d=dict(passed=True,models=4,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')},scope='separate deterministic checks for zero costs, cost-empty tree, zero residual increment budget and precomputation timeout; no false exclusion at timeout',rows=rows)
with (I/'MATH_EDGE_CHECK.json').open('x') as f:json.dump(d,f,indent=2)
print(json.dumps(d))
