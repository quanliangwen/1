from pathlib import Path
import json,hashlib,subprocess,time
H=Path(__file__).parent;I=H/'iterations/I005_exact_cdf_bound';out=I/'probe32_old.json'
if (I/'ENGINEERING_REGISTRY.json').exists() or out.exists():raise RuntimeError('Do not repeat an engineering trial')
source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')};case=next(c for c in json.load(open(H/'CASES.json')) if c['index']==32);row=next(r for r in json.load(open(H/'BASELINE_S10.json'))['rows'] if r['index']==32)
reg=dict(time=time.time(),stage='single engineering proof probe; not optimizer performance or formal40x30',source_sha256=source,index=32,capacity=case['tmax'],cost_limit=str(row['old_best']),cost_line_scope='literal recorded historical cost decimal; branch program receives scalar only, no historical vector',bins=256,seconds=30,watchdog=80,math_checks=649,prior_evidence='unconditioned costCDF bound too loose; depth2 floated390/400 exclusions oncase32, test exact replay',arithmetic='exact source decimals, floor quantization and integer CDF envelope convolution',formal_source_unchanged=True,no_LSS_calls=True)
(I/'ENGINEERING_REGISTRY.json').write_text(json.dumps(reg,indent=2))
cmd=['/home/junhao/miniconda3/bin/python','-u',str(I/'candidate/run_bound.py'),'--instance','/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/'+case['instance'],'--capacity',str(case['tmax']),'--cost-limit',str(row['old_best']),'--bins','256','--seconds','30','--out',str(out)]
with (I/'probe32_old.log').open('x') as f:
 start=time.monotonic();r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=80)
(I/'PROBE_TERMINAL.json').write_text(json.dumps(dict(exit=r.returncode,wall=time.monotonic()-start,source_sha256=source),indent=2))
if r.returncode:raise RuntimeError('Probe failed; retain log')
d=json.load(open(out));print(json.dumps({k:d[k] for k in ['status','cost_limit','total_combinations','visited_nodes','terminal_counts','covered_combinations','remaining_combinations','raw_cost_line_excluded','elapsed']}))
