from pathlib import Path
import json,hashlib,subprocess,time
H=Path(__file__).parent;I=H/'iterations/I005_exact_cdf_bound';parent=json.load(open(I/'ENGINEERING_REGISTRY.json'));out=I/'probe32_old_90.json'
if out.exists() or (I/'PROBE90_REGISTRY.json').exists():raise RuntimeError('Do not repeat probe90')
source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')}
if source!=parent['source_sha256']:raise RuntimeError('Frozen proof source changed')
reg=dict(parent,time=time.time(),seconds=90,watchdog=140,reason='first30s explicit budget-exhausted,0unresolved,remaining10.03%; retain it and restart same deterministic tree with larger budget, not a formal Avg attempt replacement',parent_trial='probe32_old.json',no_hidden_resume=True)
(I/'PROBE90_REGISTRY.json').write_text(json.dumps(reg,indent=2));cmd=['/home/junhao/miniconda3/bin/python','-u',str(I/'candidate/run_bound.py'),'--instance','/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/APP_10_20_500_','--capacity',str(reg['capacity']),'--cost-limit',reg['cost_limit'],'--bins','256','--seconds','90','--out',str(out)]
with (I/'probe32_old_90.log').open('x') as f:start=time.monotonic();r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=140)
(I/'PROBE90_TERMINAL.json').write_text(json.dumps(dict(exit=r.returncode,wall=time.monotonic()-start,source_sha256=source),indent=2))
if r.returncode:raise RuntimeError('Probe90 failed, retain records')
d=json.load(open(out));print(json.dumps({k:d[k] for k in ['status','cost_limit','total_combinations','visited_nodes','terminal_counts','covered_combinations','remaining_combinations','raw_cost_line_excluded','elapsed']}))
