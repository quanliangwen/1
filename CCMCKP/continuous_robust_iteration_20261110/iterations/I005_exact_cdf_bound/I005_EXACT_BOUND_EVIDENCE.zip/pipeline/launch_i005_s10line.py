from pathlib import Path
from decimal import Decimal
import json,hashlib,subprocess,time
H=Path(__file__).parent;I=H/'iterations/I005_exact_cdf_bound';audit=json.load(open(I/'probe32_old_90.json.audit.json'));parent=json.load(open(I/'ENGINEERING_REGISTRY.json'));out=I/'probe32_s10_minus_1e6.json'
if not audit['passed'] or not audit['raw_cost_line_excluded']:raise RuntimeError('Audit original cost exclusion before strengthening it')
if out.exists() or (I/'S10_LINE_REGISTRY.json').exists():raise RuntimeError('No duplicate stronger-line probe')
source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')}
if source!=parent['source_sha256']:raise RuntimeError('Frozen source changed')
row=next(r for r in json.load(open(H/'BASELINE_S10.json'))['rows'] if r['index']==32);line=str(Decimal(str(row['new_avg']))-Decimal('0.000001'))
reg=dict(parent,time=time.time(),seconds=180,watchdog=240,cost_limit=line,reason='independent old-cost exclusion audited; test whether any raw-feasible improvement of at least1e-6 below S10 exists, retain any budget/unresolved state',parent_trial='probe32_old_90.json',parent_audit_sha256=hashlib.sha256((I/'probe32_old_90.json.audit.json').read_bytes()).hexdigest(),new_raw_candidate_is_not_LSS_qualified=True)
(I/'S10_LINE_REGISTRY.json').write_text(json.dumps(reg,indent=2));cmd=['/home/junhao/miniconda3/bin/python','-u',str(I/'candidate/run_bound.py'),'--instance','/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/APP_10_20_500_','--capacity',str(reg['capacity']),'--cost-limit',line,'--bins','256','--seconds','180','--out',str(out)]
with (I/'probe32_s10_minus_1e6.log').open('x') as f:start=time.monotonic();r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=240)
(I/'S10_LINE_TERMINAL.json').write_text(json.dumps(dict(exit=r.returncode,wall=time.monotonic()-start,source_sha256=source),indent=2))
if r.returncode:raise RuntimeError('Stronger-line probe failed; retained log')
d=json.load(open(out));print(json.dumps({k:d[k] for k in ['status','cost_limit','total_combinations','visited_nodes','terminal_counts','covered_combinations','remaining_combinations','raw_cost_line_excluded','elapsed']}))
