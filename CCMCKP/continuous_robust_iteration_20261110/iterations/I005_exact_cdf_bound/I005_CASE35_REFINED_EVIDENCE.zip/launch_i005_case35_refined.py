from pathlib import Path
import json,hashlib,subprocess,time
H=Path(__file__).parent;I=H/'iterations/I005_exact_cdf_bound';J=I/'case35';out=J/'probe_old_512_120.json'
parent=json.load(open(J/'REGISTRATION.json'));source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')}
if source!=parent['source_sha256']:raise RuntimeError('Frozen source changed')
if out.exists() or (J/'REFINED_REGISTRATION.json').exists():raise RuntimeError('No overwrite or duplicate probe')
reg=dict(parent,time=time.time(),bins=512,seconds=120,watchdog=170,purpose='new complete-root refinement of preserved incomplete case35: finer optimistic grid, bounded120sec; no exclusion claim unless fully audited exhausted; no new native MC')
(J/'REFINED_REGISTRATION.json').write_text(json.dumps(reg,indent=2))
cmd=['/home/junhao/miniconda3/bin/python','-u',str(I/'candidate/run_bound.py'),'--instance','/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/'+reg['instance'],'--capacity',str(reg['capacity']),'--cost-limit',reg['cost_limit'],'--bins','512','--seconds','120','--out',str(out)]
with (J/'refined.log').open('x') as f:
 start=time.monotonic();r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=170)
(J/'REFINED_TERMINAL.json').write_text(json.dumps(dict(exit=r.returncode,wall=time.monotonic()-start,source_sha256=source),indent=2))
if r.returncode:raise RuntimeError('Probe failed; all records retained')
d=json.load(open(out));print(json.dumps({k:d[k] for k in ['status','visited_nodes','terminal_counts','covered_combinations','remaining_combinations','raw_cost_line_excluded','elapsed']}))
