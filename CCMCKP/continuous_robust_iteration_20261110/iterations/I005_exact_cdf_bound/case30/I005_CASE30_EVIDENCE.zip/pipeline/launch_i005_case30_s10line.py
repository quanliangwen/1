from pathlib import Path
from decimal import Decimal
import json,hashlib,subprocess,time
H=Path(__file__).parent;I=H/'iterations/I005_exact_cdf_bound';J=I/'case30';prior=json.load(open(J/'probe_old_30.json.audit.json'));parent=json.load(open(J/'REGISTRATION.json'));out=J/'probe_s10_minus_1e6.json'
if not prior['passed'] or not prior['raw_cost_line_excluded']:raise RuntimeError('Audit first cost line')
if out.exists() or (J/'S10_LINE_REGISTRY.json').exists():raise RuntimeError('No duplicate probe')
source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')}
if source!=parent['source_sha256']:raise RuntimeError('Source changed')
ref=next(r for r in json.load(open(H/'BASELINE_S10.json'))['rows'] if r['index']==30);line=str(Decimal(str(ref['new_avg']))-Decimal('0.000001'));reg=dict(parent,time=time.time(),cost_limit=line,seconds=60,watchdog=110,purpose='exclude any raw-feasible improvement>=1e-6 below S10 or retain incomplete state; no positive joint-feasibility claim')
(J/'S10_LINE_REGISTRY.json').write_text(json.dumps(reg,indent=2));cmd=['/home/junhao/miniconda3/bin/python','-u',str(I/'candidate/run_bound.py'),'--instance','/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/'+reg['instance'],'--capacity',str(reg['capacity']),'--cost-limit',line,'--bins','256','--seconds','60','--out',str(out)]
with (J/'probe_s10.log').open('x') as f:start=time.monotonic();r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=110)
(J/'S10_LINE_TERMINAL.json').write_text(json.dumps(dict(exit=r.returncode,wall=time.monotonic()-start,source_sha256=source),indent=2))
if r.returncode:raise RuntimeError('Probe failed; retained log')
d=json.load(open(out));print(json.dumps({k:d[k] for k in ['status','cost_limit','total_combinations','visited_nodes','terminal_counts','covered_combinations','remaining_combinations','raw_cost_line_excluded','elapsed']}))
