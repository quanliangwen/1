from pathlib import Path
import json,hashlib,subprocess,time
H=Path(__file__).parent;I=H/'iterations/I005_exact_cdf_bound';J=I/'case30';J.mkdir(exist_ok=True);out=J/'probe_old_30.json';manifest=json.load(open(I/'ARCHIVE_MANIFEST.json'))
if out.exists() or (J/'REGISTRATION.json').exists():raise RuntimeError('No duplicate case30 engineering probe')
source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')}
if source!=manifest['source_sha256']:raise RuntimeError('Frozen proof source changed')
c=next(c for c in json.load(open(H/'CASES.json')) if c['index']==30);ref=next(r for r in json.load(open(H/'BASELINE_S10.json'))['rows'] if r['index']==30)
reg=dict(time=time.time(),source_sha256=source,index=30,instance=c['instance'],capacity=c['tmax'],cost_limit=str(ref['old_best']),bins=256,seconds=30,watchdog=80,purpose='next remaining10group gap: initial bounded exact raw proof probe, not formal30run Avg; preserve unresolved/budget states',only_scalar_cost_target=True,no_historical_vector=True,no_LSS_calls=True,formal_source_unchanged=True)
(J/'REGISTRATION.json').write_text(json.dumps(reg,indent=2));cmd=['/home/junhao/miniconda3/bin/python','-u',str(I/'candidate/run_bound.py'),'--instance','/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/'+c['instance'],'--capacity',str(c['tmax']),'--cost-limit',reg['cost_limit'],'--bins','256','--seconds','30','--out',str(out)]
with (J/'probe.log').open('x') as f:start=time.monotonic();r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=80)
(J/'TERMINAL.json').write_text(json.dumps(dict(exit=r.returncode,wall=time.monotonic()-start,source_sha256=source),indent=2))
if r.returncode:raise RuntimeError('Case30 probe failed; retained log')
d=json.load(open(out));print(json.dumps({k:d[k] for k in ['status','cost_limit','total_combinations','visited_nodes','terminal_counts','covered_combinations','remaining_combinations','raw_cost_line_excluded','elapsed']}))
