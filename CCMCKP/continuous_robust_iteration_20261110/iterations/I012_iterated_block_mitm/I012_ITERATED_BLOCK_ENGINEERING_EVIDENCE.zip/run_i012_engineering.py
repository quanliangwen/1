from pathlib import Path
import json,hashlib,subprocess,time
H=Path(__file__).parent;I=H/'iterations/I012_iterated_block_mitm';J=I/'engineering40';J.mkdir(exist_ok=True);out=J/'result.json.gz'
if (J/'REGISTRATION.json').exists() or out.exists():raise RuntimeError('No duplicate engineering run')
mathcheck=json.load(open(I/'MATH_CHECK.json'));source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')}
schedule=json.load(open(I/'SCHEDULE_CHECK.json'))
if not mathcheck['passed'] or not schedule['passed'] or source!=mathcheck['source_sha256'] or source!=schedule['source_sha256']:raise RuntimeError('Verified block arithmetic/schedule/source required')
c=next(c for c in json.load(open(H/'CASES.json')) if c['index']==40)
reg=dict(iteration='I012_engineering',time=time.time(),source_sha256=source,index=40,instance=c['instance'],capacity=c['tmax'],method='block_mitm',seed=9712000,seconds=600,phase_seconds=180,watchdog=640,scope='one engineering run, raw candidates only; not qualified gain or30-run Avg',initialization='fresh own-run S10 from original samples, all its certified candidates retained',block_sizes=[4,6],mass_shifts=[0,.00025,.0005],batch_size=64,maximum_block_choices=1000000,no_historical_cost_target=True,no_saved_vector_or_true_model=True,no_LSS_calls=True,formal_source_unchanged=True,math_checks=mathcheck['checks'])
(J/'REGISTRATION.json').write_text(json.dumps(reg,indent=2))
cmd=['/home/junhao/miniconda3/bin/python','-u',str(I/'candidate/run.py'),'--instance','/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/'+c['instance'],'--capacity',str(c['tmax']),'--risk-method','block_mitm','--seed',str(reg['seed']),'--seconds','600','--phase-seconds','180','--out',str(out)]
with (J/'engineering.log').open('x') as f:
 start=time.monotonic();r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=640)
(J/'TERMINAL.json').write_text(json.dumps(dict(exit=r.returncode,wall=time.monotonic()-start,source_sha256=source),indent=2))
if r.returncode:raise RuntimeError('Engineering run failed; all logs retained')
meta=json.load(open(str(out)+'.run.json'));print(json.dumps(dict(exit=0,seconds=meta['elapsed'],within_budget=meta['within_budget'],source_matches=meta['source_sha256']==source)))
