from pathlib import Path
from fractions import Fraction as F
import json,gzip,hashlib,pickle,collections
H=Path(__file__).parent;I=H/'iterations/I012_iterated_block_mitm';J=I/'engineering40';p=J/'result.json.gz';reg=json.load(open(J/'REGISTRATION.json'));meta=json.load(open(str(p)+'.run.json'));d=json.loads(gzip.decompress(p.read_bytes()));mathcheck=json.load(open(I/'MATH_CHECK.json'));rawref=json.load(open(H/'RAW_REFERENCE.json'))
if meta['source_sha256']!=reg['source_sha256'] or meta['source_sha256']!=mathcheck['source_sha256'] or not meta['within_budget'] or d['status']!='completed':raise RuntimeError('Source/budget/completion failure')
bench=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/reg['instance'];groups=pickle.load(open(bench/'node_to_factor.pkl','rb'));groups=[groups[k] for k in sorted(groups,key=int)] if isinstance(groups,dict) else groups;cost=[F(s) for s in (bench/'cost.txt').read_text().split()]
for name,sha in meta['input_sha256'].items():
 if rawref[str(bench/name)]!=sha or hashlib.sha256((bench/name).read_bytes()).hexdigest()!=sha:raise RuntimeError('Input identity differs')
for opened in meta['opened_task_paths']:
 path=Path(opened)
 if path.name.endswith('_dist.txt') or '/lss_cache/' in opened:raise RuntimeError('Optimizer read validation data')
 if bench in path.parents and path.name not in meta['input_sha256']:raise RuntimeError('Unregistered benchmark read')
pool=d['candidate_shortlist'];seen=set()
for r in pool:
 s=tuple(r['selection']);cert=r['certificate']
 if s in seen or len(s)!=len(groups) or any(j not in groups[g] for g,j in enumerate(s)):raise RuntimeError('Invalid selection/pool duplicate')
 seen.add(s)
 if cert['selection']!=list(s) or not cert['all_original_samples'] or cert['strict_event']!='sum<T' or 100*int(cert['lower_numerator'])<99*int(cert['denominator']):raise RuntimeError('Invalid raw99 certificate')
 if abs(float(sum((cost[j] for j in s),F(0)))-r['cost'])>1e-9:raise RuntimeError('Cost report differs')
ext=d['extension'];blocks=ext['robust_blocks']
if blocks['initial_certified']+blocks['new_certified']!=blocks['final_certified'] or blocks['initial_certified']!=ext['base_pool'] or blocks['final_certified']!=len(pool):raise RuntimeError('Existing candidates were not retained')
current=json.load(open(H/'iterations/I004_robust_pair_exchange/REGISTRATION.json'))['current_qualified_costs']['40'];oldI2=json.loads(gzip.decompress((H/'iterations/I002_cdf_neighborhood/pilot/cdf_lns_40_seed970201.json.gz').read_bytes()));oldI4=json.loads(gzip.decompress((H/'iterations/I004_robust_pair_exchange/pilot/pair_exchange_40_seed970401.json.gz').read_bytes()));s2={tuple(r['selection']) for r in oldI2['candidate_shortlist']};s4={tuple(r['selection']) for r in oldI4['candidate_shortlist']};below=[r for r in pool if r['cost']<current-1e-9]
parts=[r for r in blocks['records'] if r['kind']=='robust_block_mitm'];totals=collections.Counter();levels=collections.Counter()
for r in parts:totals[r['block_size']]+=1;levels[str(r['delta'])]+=1
oldI11=json.loads(gzip.decompress((H/'iterations/I011_robust_block_mitm/engineering40/result.json.gz').read_bytes()));s11={tuple(r['selection']) for r in oldI11['candidate_shortlist']};refresh=[r for r in blocks['records'] if r['kind']=='own_center_refresh']
if any(not r['all_centers_in_current_pool'] for r in refresh):raise RuntimeError('External refresh center')
selectedI2=json.load(open(H/'iterations/I002_cdf_neighborhood/pilot_validation/cdf_lns_40_seed970201.json.gz.post.json'))['selected']
result=dict(passed=True,scope='single engineering search, raw certificates structurally checked with source/input identities; not original LSS-qualified gain or30-run Avg',source_sha256=meta['source_sha256'],search_seconds=meta['elapsed'],within_budget=True,base_seconds=ext['base_seconds'],extension_seconds=ext['extension_seconds'],initial_pool=blocks['initial_certified'],new_raw_certified=blocks['new_certified'],final_pool=len(pool),raw_min=min(r['cost'] for r in pool),current_I002_qualified_reference=current,lower_cost_raw_candidates=len(below),new_lower_vs_I002=sum(tuple(r['selection']) not in s2 for r in below),new_lower_vs_I002_and_I004=sum(tuple(r['selection']) not in s2|s4 for r in below),current_I002_vector_in_pool=tuple(selectedI2['selection']) in seen,blocks_by_size=dict(totals),blocks_by_mass_shift=dict(levels),center_refreshes=len(refresh),novel_center_refreshes=sum(r['novel_centers'] for r in refresh),new_lower_vs_I002_I004_I011=sum(tuple(r['selection']) not in s2|s4|s11 for r in below),evaluated_combinations=sum(r['evaluated_combinations'] for r in parts),complete_block_scans=sum(r['complete_block_scan'] for r in parts),partial_block_scans=sum(not r['complete_block_scan'] for r in parts),raw_acceptance_unchanged=True,all_initial_candidates_retained=True,no_LSS_calls=True,selected_input_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
with (J/'ASSESSMENT.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'}))
