"""Behavioral check: refreshed centers must arise only from this run's pool."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,json,hashlib,time
import numpy as np
H=Path(__file__).parent;I=H/'iterations/I012_iterated_block_mitm';sys.path[:0]=[str(I/'candidate'),str(I/'vendor313')]
from block_exchange import RobustBlocks,risk_centers
class TinySolver:
 def __init__(self):
  self.groups=[np.array([g,g+6]) for g in range(6)];self.cost=np.r_[np.ones(6),np.full(6,2.)];self.T=1.;self.seed=1012;self.deadline=time.monotonic()+120;self.inst=type('Input',(),dict(samples=[np.zeros(2) for _ in range(12)]))();self.pool={};self.decisions={};self.accepted=[]
  self.native_check(tuple(range(6,12)),'initial',True)
 def cost_of(self,q):return float(self.cost[list(q)].sum())
 def native_check(self,q,source,force):
  q=tuple(q);assert len(q)==6 and all(j in self.groups[g] for g,j in enumerate(q))
  # Every raw observation is zero, so its exact strict-event probability is1.
  record=dict(selection=list(q),cost=self.cost_of(q),certificate=dict(lower=1.,accepted=True,lower_numerator='64',denominator='64'))
  self.pool[q]=record;self.decisions[q]=record['certificate'];self.accepted.append(q);return 1.
s=TinySolver();initial=set(s.pool);model=RobustBlocks(s,60);model.run();refreshes=[r for r in model.records if r['kind']=='own_center_refresh'];blocks=[r for r in model.records if r['kind']=='robust_block_mitm']
assert refreshes and all(r['all_centers_in_current_pool'] for r in refreshes) and any(r['novel_centers']>0 for r in refreshes)
assert initial<=set(s.pool) and all(q in s.pool for q in risk_centers(s.pool));assert all(tuple(r['center']) in s.pool for r in blocks)
assert {r['delta'] for r in blocks}=={0.,.00025,.0005};assert {r['block_size'] for r in blocks}=={4,6}
assert model.summary()['initial_certified']+model.summary()['new_certified']==len(s.pool)
# An already expired extension cannot start a block or alter the initial pool.
e=TinySolver();before=set(e.pool);expired=RobustBlocks(e,0);expired.run();assert set(e.pool)==before and not any(r['kind']=='robust_block_mitm' for r in expired.records)
d=dict(passed=True,checks='own-center refresh origin, retained initial pool, both block sizes, all3mass levels, certified-only pool, expired-budget stop',source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')},new_own_candidates=len(s.pool)-len(initial),refreshes=len(refreshes),novel_refresh_centers=sum(r['novel_centers'] for r in refreshes),blocks=len(blocks),scope='deterministic6-group all-zero empirical test; exact raw probability1, actual scoring/selection/schedule executed; not production cost improvement')
with (I/'SCHEDULE_CHECK.json').open('x') as f:json.dump(d,f,indent=2)
print(json.dumps(d))
