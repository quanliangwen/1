from pathlib import Path
import json,hashlib,time
H=Path(__file__).resolve().parent;I=H/'iterations/I015_precision_closure';J=I/'engineering39';J.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if (J/'REGISTRATION.json').exists():raise RuntimeError('Engineering already registered, inspect actual process')
source={p.name:sha(p) for p in (I/'candidate').glob('*.py')}
if len(source)!=21:raise RuntimeError('21source required')
checks=['MATH_CHECK.json','CDF_MATH_CHECK.json','SCHEDULE_CHECK.json','HYBRID_INTEGRATION_CHECK.json','PRECISION_SCHEDULE_CHECK.json','PRECISION_INTEGRATION_CHECK.json']
for name in checks:
 d=json.load(open(I/name))
 if not d['passed'] or d['source_sha256']!=source:raise RuntimeError('Checked source identity required')
c=next(r for r in json.load(open(H/'CASES.json')) if r['index']==39)
reg=dict(iteration='I015_engineering39',time=time.time(),source_sha256=source,index=39,instance=c['instance'],capacity=c['tmax'],method='cdf_blocks_precision',seed=9715039,seconds=600,phase_seconds=180,watchdog=640,scope='one new-seed cold engineering run, not matched performance pilot or30-run Avg; no original-LSS calls during search',initialization='fresh own S10 then own CDF and blocks, then refine only own unresolved decisions',phase_policy='one180second shared CDF/block/precision phase; all respect original global deadline with45second final reserve for600second total; precision does not reset phase or total',admission_policy='coarse-first cost order then finer grids; empirical same-run certificate-time forecast; any overrun explicitly reported',no_historical_cost_target=True,no_saved_vector_or_true_model=True,no_LSS_calls=True,formal_source_unchanged=True,checks_sha256={name:sha(I/name) for name in checks},runner_sha256=sha(H/'run_i015_engineering39.py'))
with (J/'REGISTRATION.json').open('x') as f:json.dump(reg,f,indent=2)
print(json.dumps({k:v for k,v in reg.items() if k not in ['source_sha256','checks_sha256']}))
