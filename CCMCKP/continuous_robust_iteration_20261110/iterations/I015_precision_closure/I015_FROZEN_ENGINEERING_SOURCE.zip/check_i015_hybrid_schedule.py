"""Actual hybrid orchestrator with controlled clock/model behavior."""
from pathlib import Path
import sys,json,hashlib
H=Path(__file__).parent;I=H/'iterations/I015_precision_closure';sys.path[:0]=[str(I/'candidate'),str(I/'vendor313')]
import hybrid_schedule as h
class Clock:
 def __init__(self,now=0.):self.now=float(now)
 def monotonic(self):return self.now
class Solver:
 def __init__(self,deadline=600.,empty=False):
  self.deadline=deadline;self.pool={} if empty else {(0,):record(0,10.,.999)}
def record(j,cost,p):return dict(selection=[j],cost=cost,certificate=dict(lower=p,lower_numerator=str(round(p*10000)),denominator='10000'))
def execute(cdf_time=35.,block_time=100.,seconds=180.,deadline=600.,now=0.,phase_start=0.,bad_cdf=False,bad_blocks=False,empty=False):
 clock=Clock(now);events=[];s=Solver(deadline,empty);h.time=clock
 class CDF:
  def __init__(self,solver,budget):self.s=solver;self.end=min(solver.deadline-12,clock.now+budget);self.initial=set(solver.pool);events.append(dict(stage='cdf_init',budget=budget,at=clock.now))
  def run(self):
   clock.now+=min(cdf_time,max(0.,self.end-clock.now));self.s.pool[(1,)]=record(1,9.,.9901)
   if bad_cdf:self.s.pool.pop((0,),None)
   events.append(dict(stage='cdf_end',at=clock.now,end=self.end))
  def summary(self):return dict(initial_certified=len(self.initial),final_certified=len(self.s.pool))
 class Blocks:
  def __init__(self,solver,budget):self.s=solver;self.end=min(solver.deadline-12,clock.now+budget);events.append(dict(stage='blocks_init',budget=budget,at=clock.now,pool=sorted(solver.pool)))
  def run(self):
   assert (1,) in self.s.pool;clock.now+=min(block_time,max(0.,self.end-clock.now));self.s.pool[(2,)]=record(2,8.,.999)
   self.s.pool[(1,)]['certificate']['lower']=.999;self.s.pool[(1,)]['certificate']['lower_numerator']='9990'
   if bad_blocks:self.s.pool.pop((1,))
   events.append(dict(stage='blocks_end',at=clock.now,end=self.end))
  def summary(self):return dict(final_certified=len(self.s.pool))
 h.PortfolioLNS=CDF;h.RobustBlocks=Blocks;r=h.run_hybrid(s,seconds,phase_started=phase_start)
 return r,s,events
checks=[]
r,s,e=execute();assert r['cdf_executed'] and r['blocks_executed'] and r['remaining_for_blocks']==145 and r['phase_seconds_used']==135;assert e[2]['budget']==145 and e[2]['pool']==[(0,),(1,)];assert r['cdf_pool_records'][1]['certificate']['lower']==.999 or any(x['certificate']['lower']==.9901 for x in r['cdf_pool_records']);assert next(x for x in r['cdf_pool_records'] if x['selection']==[1])['certificate']['lower']==.9901;assert set(s.pool)=={(0,),(1,),(2,)};checks.append('CDF first, own pool retained, only145 remaining not180, deep snapshot independent of later strengthening')
r,s,e=execute(cdf_time=180);assert r['cdf_executed'] and not r['blocks_executed'] and r['remaining_for_blocks']==0 and len(s.pool)==2;checks.append('CDF consumes phase, blocks skipped')
r,s,e=execute(now=20);assert e[0]['budget']==160 and r['remaining_for_blocks']==125 and r['phase_seconds_used']<=180;checks.append('phase start includes20seconds prior overhead')
r,s,e=execute(deadline=60);assert r['cdf_executed'] and not r['blocks_executed'] and r['remaining_for_blocks']==13;checks.append('same global deadline with12second final reserve')
for kwargs in [dict(seconds=0),dict(deadline=5),dict(empty=True)]:
 r,s,e=execute(**kwargs);assert not r['cdf_executed'] and not r['blocks_executed'] and not e;checks.append('skip '+str(kwargs))
for kwargs in [dict(bad_cdf=True),dict(bad_blocks=True)]:
 try:execute(**kwargs)
 except ArithmeticError:checks.append('retention violation rejected '+str(kwargs))
 else:raise AssertionError('Candidate removal silently accepted')
for budget in [-1.,float('nan'),float('inf')]:
 try:execute(seconds=budget)
 except ValueError:checks.append('invalid phase rejected '+str(budget))
 else:raise AssertionError('Invalid budget silently accepted')
result=dict(passed=True,checks=len(checks),scope='production hybrid orchestrator executed with controlled clock/models; stage ordering, own-CDF origin, retention/deep copy, shared/global deadline and invalid budgets; not probability/performance simulation',records=checks,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')})
with (I/'SCHEDULE_CHECK.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
