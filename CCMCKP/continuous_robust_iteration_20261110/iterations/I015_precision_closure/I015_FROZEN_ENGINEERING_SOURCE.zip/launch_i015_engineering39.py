from pathlib import Path
import json,hashlib,subprocess,time
H=Path(__file__).resolve().parent;I=H/'iterations/I015_precision_closure';J=I/'engineering39';receipt=json.load(open(J/'PRE_REG_REMOTE_VERIFIED.json'));reg=json.load(open(J/'REGISTRATION.json'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if any((J/name).exists() for name in ['LAUNCH.json','supervisor.log','engineering.log','result.json.gz','TERMINAL.json']):raise RuntimeError('Engineering may already be running; inspect existing actual process')
if not receipt['independent_remote_verification'] or receipt['remote_registration_sha256']!=sha(J/'REGISTRATION.json') or receipt['source_sha256']!=reg['source_sha256'] or receipt['runner_sha256']!=sha(H/'run_i015_engineering39.py'):raise RuntimeError('Remote verified registration/runner differs')
source={p.name:sha(p) for p in (I/'candidate').glob('*.py')}
if source!=reg['source_sha256']:raise RuntimeError('Frozen optimizer changed')
P=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/reg['instance'];rawref=json.load(open(H/'RAW_REFERENCE.json'));files=[P/'cost.txt',P/'node_to_factor.pkl']+[p for p in P.glob('*_sample.txt') if not p.name.endswith('_big_sample.txt')]
for p in files:
 if rawref[str(p)]!=sha(p):raise RuntimeError('Original benchmark changed')
with (J/'supervisor.log').open('x') as log:p=subprocess.Popen(['/home/junhao/miniconda3/bin/python','-u',str(H/'run_i015_engineering39.py')],cwd=H,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
result=dict(time=time.time(),pid=p.pid,pre_registered_commit=receipt['pre_registered_commit'],source_files=len(source),original_raw_files_verified=len(files),registration_sha256=sha(J/'REGISTRATION.json'),command=['/home/junhao/miniconda3/bin/python','-u','run_i015_engineering39.py'],scope='actual single cold engineering launch, not30-run performance cohort')
with (J/'LAUNCH.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
