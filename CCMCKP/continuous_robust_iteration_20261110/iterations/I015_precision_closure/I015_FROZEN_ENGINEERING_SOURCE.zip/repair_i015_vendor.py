"""Repair only the observed broken new dependency symlink, no source changes."""
from pathlib import Path
import os,json
H=Path(__file__).resolve().parent;I=H/'iterations/I015_precision_closure';link=I/'vendor313';target=(H/'iterations/I002_cdf_neighborhood/vendor313').resolve();out=I/'DEPENDENCY_LINK_REPAIR.json'
if out.exists():raise RuntimeError('Repair already recorded')
if not link.is_symlink() or os.readlink(link)!='iterations/I002_cdf_neighborhood/vendor313' or link.parent.resolve()!=I.resolve() or not (target/'flint').is_dir():raise RuntimeError('Observed broken symlink/real dependency differs; no filesystem mutation')
old=os.readlink(link);link.unlink();os.symlink(target,link,target_is_directory=True)
record=dict(scope='new-iteration dependency setup failure, before probability interface imports or cold engineering;21solver source files unchanged',initial_test='check_i015_actual_precision.py',error="ModuleNotFoundError: No module named 'flint'",cause='setup script invoked by relative filename used relative __file__.parent, so symlink target was interpreted relative to link directory',old_link=old,absolute_link=str(target),resolved_target_verified=link.resolve()==target,actual_precision_toy_directory_existed_before_repair=(I/'actual_precision_toy').exists(),solver_sources_changed=False,repair='unlink only exactly verified broken symlink, recreate absolute dependency symlink; setup helper now resolves __file__ first')
with out.open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record))
