"""Run actual CDF/MILP and block kernels together on a deterministic raw model."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,time,json,hashlib
import numpy as np
H=Path(__file__).parent;I=H/'iterations/I015_precision_closure';sys.path[:0]=[str(I/'candidate'),str(I/'vendor313')]
from hybrid_schedule import run_hybrid
class Solver:
 def __init__(self):
  self.groups=[np.array([g,g+6]) for g in range(6)];self.cost=np.r_[np.ones(6),np.full(6,2.)];self.T=1.;self.seed=1014;self.deadline=time.monotonic()+120;self.inst=type('Input',(),dict(n=12,m=6,samples=[np.zeros(2) for _ in range(12)]))();self.pool={};self.decisions={};self.models=0;self.model_seconds=0.;self.native_check(tuple(range(6,12)),'initial',True)
 def remaining(self):return self.deadline-time.monotonic()
 def cost_of(self,q):return float(self.cost[list(q)].sum())
 def native_check(self,q,source,force):
  q=tuple(q);assert len(q)==6 and all(j in self.groups[g] for g,j in enumerate(q));cert=dict(selection=list(q),lower=1.,accepted=True,lower_numerator='64',denominator='64',strict_event='sum<T',all_original_samples=True)
  self.pool[q]=dict(selection=list(q),cost=self.cost_of(q),certificate=cert);self.decisions[q]=cert;return 1.
s=Solver();initial=set(s.pool);start=time.monotonic();r=run_hybrid(s,60);snapshot={tuple(x['selection']) for x in r['cdf_pool_records']}
assert r['cdf_executed'] and r['blocks_executed'] and s.models>0 and initial<=snapshot<=set(s.pool)
assert r['robust_blocks']['initial_certified']==len(snapshot) and r['final_pool']==len(s.pool) and r['all_own_cdf_retained'] and r['phase_seconds_used']<=60
assert r['robust_cdf_lns']['initial_certified']==len(initial) and r['robust_cdf_lns']['final_certified']==len(snapshot)
assert any(x['kind']=='robust_block_mitm' for x in r['robust_blocks']['records']) and all(x['certificate']['lower_numerator']=='64' for x in s.pool.values())
result=dict(passed=True,scope='actual PortfolioLNS scipyMILP +RobustBlocks +production scheduler on6groups/2options, every raw observation0 so exact rawprob1; integration evidence only, not production performance or LSS result',source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')},initial_pool=len(initial),cdf_pool=len(snapshot),final_pool=len(s.pool),actual_MIP_calls=s.models,cdf_seconds=r['cdf_seconds'],block_seconds=r['block_seconds'],shared_phase_seconds=r['phase_seconds_used'],seconds=time.monotonic()-start)
with (I/'HYBRID_INTEGRATION_CHECK.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
