"""Real production closure and ExactOracle, inclusive99 and strict-sum boundary."""
from pathlib import Path
from fractions import Fraction as F
from types import SimpleNamespace
import sys,json,hashlib,itertools,time
H=Path(__file__).parent;I=H/'iterations/I015_precision_closure';sys.path[:0]=[str(I/'candidate'),str(I/'vendor313')]
from exact_oracle import ExactOracle
from precision_closure import run_precision_closure
from s10_kernel import StrictSolver as RawSolver
J=I/'actual_precision_toy';J.mkdir(exist_ok=True);out=I/'PRECISION_INTEGRATION_CHECK.json'
if out.exists():raise RuntimeError('No precision integration overwrite')
for j in range(12):
 values=['0','0']
 if j==6:values=['0']*99+['1']
 if j==7:values=['1','1']
 if j==8:values=['0','1']
 with (J/f'{j}_sample.txt').open('x') as f:f.write('\n'.join(values)+'\n')
class Instance:
 path=J
 def validate_selection(self,q):
  if len(q)!=6 or any(j not in [g,g+6] for g,j in enumerate(q)):raise ValueError('Noncanonical six-group toy')
  return list(q)
class Solver:
 def __init__(self):
  self.inst=Instance();self.oracle=ExactOracle(self.inst,1.,'.99');self.deadline=time.monotonic()+20;self.pool={(0,1,2,3,4,5):dict(selection=[0,1,2,3,4,5],certificate=self.oracle.certify((0,1,2,3,4,5),1024,True))};self.decisions={q:dict(accepted=False,decision='unresolved',lower=0.) for q in [(6,1,2,3,4,5),(0,7,2,3,4,5),(0,1,8,3,4,5)]};self.native_cache={};self.accepted=[]
 def cost_of(self,q):return float(sum(q))
 def accept(self,q,source,c):self.pool[q]=dict(selection=list(q),certificate=c);self.decisions[q]=c;self.native_cache[q]=c['lower'];self.accepted.append(q)
s=Solver();start=time.monotonic();r=run_precision_closure(s,20.,start)
if r['accepted']!=1 or r['refuted']!=2 or not r['phase_within_budget'] or s.accepted!=[(6,1,2,3,4,5)]:raise AssertionError('Real raw closure classification failed')
records=[]
for row in r['records']:
 q=row['selection'];a=[[F(v) for v in (J/f'{j}_sample.txt').read_text().split()] for j in q];outcomes=list(itertools.product(*a));n=sum(sum(v,F(0))<1 for v in outcomes);d=len(outcomes);c=row['final_certificate']
 if int(c['lower_numerator'])*d>n*int(c['denominator']) or n*int(c['denominator'])>int(c['upper_numerator'])*d:raise AssertionError('Exact Fraction enumeration outside production integer interval')
 if (100*n>=99*d)!=(row['status']=='raw_certified'):raise AssertionError('Inclusive99/strict-sum production gate differs from full Fraction enumeration')
 records.append(dict(selection=q,exact_numerator=str(n),exact_denominator=str(d),status=row['status'],certificate=c))
# Execute the actual modified legacy method, preserving score0 while exposing
# the last unresolved exact interval. This is controlled scheduling evidence.
calls=[]
def certify(q,bins,upper):
 calls.append(bins);return dict(selection=list(q),bins=bins,accepted=False,infeasible=False,lower=.989,upper=.991,lower_numerator='989',upper_numerator='991',denominator='1000')
legacy=SimpleNamespace(inst=Instance(),pool={},decisions={},native_cache={},remaining=lambda:100.,float_bounds=lambda q,bins:(.989,.991),oracle=SimpleNamespace(certify=certify))
q=(0,1,2,3,4,5);value=RawSolver.native_check(legacy,q,'controlled-unresolved',True)
if value!=0. or calls!=[262144,1048576] or legacy.decisions[q]['last_integer_certificate']['bins']!=1048576 or legacy.decisions[q]['lower']!=0.:raise AssertionError('Legacy score or preserved last integer evidence changed')
RawSolver.native_check(legacy,q,'controlled-cached',True)
if calls!=[262144,1048576]:raise AssertionError('Legacy stage unexpectedly changed its retry schedule')
result=dict(passed=True,scope='actual production closure with original ExactOracle on a six-group toy, checked against full exact Fraction enumeration; actual legacy native_check preserves score0 and last interval; not optimizer performance',accepted=r['accepted'],refuted=r['refuted'],raw_counts_verified=3,records=records,closure=r,legacy_score_preserved=True,legacy_last_integer_bins=1048576,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')})
with out.open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k not in ['records','closure','source_sha256']}))
