"""Threshold, cache, coarse-first allocation and deadline tests of actual closure."""
from pathlib import Path
import sys,json,hashlib,copy
H=Path(__file__).parent;I=H/'iterations/I015_precision_closure';sys.path.insert(0,str(I/'candidate'))
import precision_closure as p
class Clock:
 def __init__(self,now=0.):self.now=now
 def __call__(self):return self.now
def cert(q,bins,n=99,u=100,d=100,seconds=1.):return dict(selection=list(q),bins=bins,lower_numerator=str(n),upper_numerator=str(u),denominator=str(d),lower=n/d,upper=u/d,accepted=100*n>=99*d,infeasible=100*u<99*d,method='exact_integer_upward_grid_count',all_original_samples=True,strict_event='sum<T',certificate_seconds=seconds)
class Oracle:
 def __init__(self,clock,answers):self.certificates={};self.clock=clock;self.answers=answers;self.calls=[]
 def certify(self,q,bins,upper):
  key=(q,bins,upper)
  if key in self.certificates:return self.certificates[key]
  self.calls.append(key);c=copy.deepcopy(self.answers.get((q,bins),cert(q,bins,98,100)));self.clock.now+=c['certificate_seconds'];self.certificates[key]=c;return c
class Solver:
 def __init__(self,clock,answers=None,deadline=100.,tasks=((1,),(2,))):
  self.deadline=deadline;self.pool={(0,):dict(cost=10.,certificate=cert((0,),1024))};self.decisions={q:dict(accepted=False,decision='unresolved',lower=0.) for q in tasks};self.native_cache={};self.oracle=Oracle(clock,answers or {});self.accepted=[]
 def cost_of(self,q):return float(q[0])
 def accept(self,q,source,c):
  assert 100*int(c['lower_numerator'])>=99*int(c['denominator']);self.pool[q]=dict(cost=self.cost_of(q),certificate=c);self.decisions[q]=c;self.native_cache[q]=c['lower'];self.accepted.append(q)
checks=[]
def record(name):checks.append(name)
clock=Clock();s=Solver(clock,{((1,),262144):cert((1,),262144,99,100),((2,),262144):cert((2,),262144,90,98)});r=p.run_precision_closure(s,20.,0.,clock);assert r['accepted']==1 and r['refuted']==1 and set(s.pool)=={(0,),(1,)} and r['phase_within_budget'];record('integer99 inclusive boundary accepted; strict integer upper below99 rejected; original pool retained')
clock=Clock();s=Solver(clock,{((1,),262144):cert((1,),262144,989,991,1000)},tasks=((1,),));r=p.run_precision_closure(s,6.,0.,clock);assert not s.accepted and r['unresolved_remaining']==1 and s.decisions[(1,)]['lower']==0 and s.decisions[(1,)]['last_integer_certificate']['lower_numerator']=='989';record('unresolved stays unresolved with explicit last interval and unchanged legacy score0')
clock=Clock();s=Solver(clock,tasks=((1,),));c=cert((1,),262144,98,100);s.oracle.certificates[((1,),262144,True)]=c;s.oracle.answers[((1,),1048576)]=cert((1,),1048576,99,100);r=p.run_precision_closure(s,25.,0.,clock);assert r['cached_certificates_reused']==1 and len(s.oracle.calls)==1 and s.oracle.calls[0][1]==1048576 and s.accepted==[(1,)];record('same-run unresolved interval reused without duplicate262144 count and refined to1048576')
clock=Clock(100.);s=Solver(clock,tasks=((1,),));s.oracle.certificates[((1,),262144,True)]=cert((1,),262144,99,100);r=p.run_precision_closure(s,1.,0.,clock);assert s.accepted==[(1,)] and not s.oracle.calls and not r['phase_within_budget'];record('cached integer fact reused without new work even after earlier phase has expired; overbudget phase reported')
clock=Clock();s=Solver(clock,tasks=((1,),));s.oracle.certificates[((1,),262144,True)]=cert((1,),262144,90,98);r=p.run_precision_closure(s,100.,0.,clock);assert r['refuted']==1 and not s.oracle.calls;record('cached integer refusal never retried')
clock=Clock();s=Solver(clock,tasks=((1,),));s.decisions[(1,)]=cert((1,),1024,80,90);r=p.run_precision_closure(s,100.,0.,clock);assert not r['records'] and not s.oracle.calls;record('pre-existing refuted decisions excluded from own unresolved queue')
clock=Clock();s=Solver(clock,{((2,),262144):cert((2,),262144)},tasks=((2,),(1,)));r=p.run_precision_closure(s,8.,0.,clock);assert [q for q,_,_ in s.oracle.calls]==[(1,),(2,)] and s.accepted==[(2,)];record('coarse-first cost ordering recovers second point before spending remaining time on finest work for cheapest point')
for seconds,deadline,now,phase in [(0.,100.,0.,0.),(100.,3.,0.,0.),(100.,100.,99.,0.),(10.,100.,50.,45.)]:
 clock=Clock(now);s=Solver(clock,deadline=deadline,tasks=((1,),));r=p.run_precision_closure(s,seconds,phase,clock)
 if (min(deadline,phase+seconds)-now)<4.5:assert not s.oracle.calls
 assert r['shared_deadline']==min(deadline,phase+seconds);record('shared/global deadline never reset '+str((seconds,deadline,now,phase)))
clock=Clock(50.);s=Solver(clock,tasks=((1,),));r=p.run_precision_closure(s,10.,45.,clock);assert len(s.oracle.calls)==1 and r['phase_seconds_used']==6. and r['phase_within_budget'];record('five already consumed phase seconds leave only five, not a fresh10')
clock=Clock();s=Solver(clock,{((1,),262144):cert((1,),262144,99,100,seconds=6.)},deadline=5.,tasks=((1,),));r=p.run_precision_closure(s,100.,0.,clock);assert r['budget_overrun'] and not r['phase_within_budget'] and r['status']=='completed_with_deadline_overrun';record('unforeseen single-call deadline overrun exposed rather than hidden')
clock=Clock();s=Solver(clock,tasks=((1,),));s.oracle.certificates[((9,),65536,True)]=cert((9,),65536,99,100,seconds=2.);r=p.run_precision_closure(s,11.,0.,clock);assert not s.oracle.calls and p.estimate_seconds(s.oracle,262144)==12.;record('same-run slow integer work raises forecast and prevents optimistic call admission')
for field,value in [('accepted',True),('infeasible',True),('strict_event','sum<=T'),('all_original_samples',False),('selection',[999]),('denominator','0'),('upper_numerator','97')]:
 clock=Clock();bad=cert((1,),262144,98,100);bad[field]=value;s=Solver(clock,{((1,),262144):bad},tasks=((1,),))
 try:p.run_precision_closure(s,100.,0.,clock)
 except (ArithmeticError,ZeroDivisionError):record('invalid integer identity/threshold rejected '+field)
 else:raise AssertionError('Malformed raw certificate accepted '+field)
for seconds in [-1.,float('nan'),float('inf')]:
 try:p.run_precision_closure(Solver(Clock()),seconds,0.,Clock())
 except ValueError:record('invalid phase rejected '+str(seconds))
 else:raise AssertionError('Invalid phase accepted')
result=dict(passed=True,checks=len(checks),scope='production closure with controlled clock/oracle: integer thresholds/cache/own ordering/coarse-first/deadline/no-reset/overrun evidence; not optimizer performance or new LSS',records=checks,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')})
with (I/'PRECISION_SCHEDULE_CHECK.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
