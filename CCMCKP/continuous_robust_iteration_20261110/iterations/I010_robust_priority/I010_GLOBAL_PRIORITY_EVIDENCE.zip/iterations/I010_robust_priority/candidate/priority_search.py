"""Bounded DFS ordering with a separate robust CDF guide, raw-only pruning."""
from fractions import Fraction as F
from pathlib import Path
from functools import lru_cache
import time,math,json,gzip,random
from flint import fmpz_poly
from budget_cdf import exact_upper,quantized_marginal
from exact_oracle import ExactOracle

def run_priority(inst,capacity,limit,B,K,bits,seconds,out,mass_shift=F(1,4000),max_candidates=32,seed=0,started=None):
 start=time.monotonic() if started is None else started;end=start+seconds;out=Path(out);T=F(capacity);C=F(limit);eps=F(mass_shift);Q=2**bits;rng=random.Random(seed)
 if max_candidates<1 or not 0<=eps<1:raise ValueError('Invalid candidate/guide configuration')
 groups=[list(map(int,g)) for g in inst.groups];m=len(groups);cost=[F(s) for s in (inst.path/'cost.txt').read_text().split()];oracle=ExactOracle(inst,capacity,'.99');samples=[oracle.fractions(j) for j in range(inst.n)]
 raw=exact_upper(groups,cost,samples,T,C,B,K,bits,reverse=True,deadline=end-2,collect_stages=True);rawmat=raw.pop('matrices')
 with Path(str(out)+'.dp.json').open('x') as f:json.dump(raw,f,indent=2)
 if eps and raw['status']=='completed':
  guide=exact_upper(groups,cost,samples,T,C,B,K,bits,reverse=True,deadline=end-2,collect_stages=True,mass_shift=eps);guidemat=guide.pop('matrices')
 else:guide=raw.copy();guidemat=rawmat
 with Path(str(out)+'.guide.dp.json').open('x') as f:json.dump(guide,f,indent=2)
 mins=[min(cost[j] for j in g) for g in groups];suffixmin=[F(0)]*(m+1)
 for g in range(m-1,-1,-1):suffixmin[g]=suffixmin[g+1]+mins[g]
 delta=C-suffixmin[0];items={};guideitems={};lengths={};guidelengths={}
 for j in range(inst.n):
  items[j],lengths[j]=quantized_marginal(samples[j],T,B)
  if eps:guideitems[j],guidelengths[j]=quantized_marginal(samples[j],T,B,eps)
  else:guideitems[j],guidelengths[j]=items[j],lengths[j]
 @lru_cache(maxsize=8192)
 def raw_mass(depth,c):
  row=rawmat[depth][c];return fmpz_poly([row[0]]+[row[t]-row[t-1] for t in range(1,B+1)])
 @lru_cache(maxsize=8192)
 def guide_mass(depth,c):
  row=guidemat[depth][c];return fmpz_poly([row[0]]+[row[t]-row[t-1] for t in range(1,B+1)])
 stack=[((),fmpz_poly([1]),F(0),1,fmpz_poly([1]),1,None)];total=math.prod(map(len,groups));counts=dict(cost=0,budget_cdf=0,raw_refuted=0,raw_accepted=0,unresolved=0);visited=0;covered=0;lookahead=0;pool=[];status='budget_exhausted'
 with gzip.open(str(out)+'.proof.jsonl.gz','xt',encoding='utf8') as log:
  def terminal(prefix,kind,**fields):
   nonlocal covered
   cover=math.prod(len(g) for g in groups[len(prefix):]);covered+=cover;counts[kind]+=1;log.write(json.dumps(dict(prefix=list(prefix),kind=kind,cover=str(cover),**fields),separators=(',',':'))+'\n')
  while stack and time.monotonic()<end-2:
   if raw['status']!='completed' or guide['status']!='completed':break
   prefix,poly,paid,pden,gpoly,gden,cached=stack.pop();depth=len(prefix);visited+=1;residual=C-paid-suffixmin[depth]
   if residual<0:terminal(prefix,'cost',minimum_completion_cost=str(paid+suffixmin[depth]));continue
   c=K if delta==0 else int(residual*K//delta)
   if not 0<=c<=K:raise ArithmeticError('Invalid cost state')
   numerator=int((poly*raw_mass(depth,c)).truncate(B+1)(1)) if cached is None else cached
   denominator=Q*pden
   if not 0<=numerator<=denominator:raise ArithmeticError('Invalid raw bound')
   if 100*numerator<99*denominator:terminal(prefix,'budget_cdf',cost_state=c,upper_numerator=str(numerator),denominator=str(denominator));continue
   if depth==m:
    decision=None;last=None
    for bins in [1024,4096,16384,65536,262144,1048576]:
     if time.monotonic()>=end-2:break
     if bins>=262144 and end-time.monotonic()<20:break
     last=oracle.certify(prefix,bins,True)
     if last['accepted'] or last['infeasible']:decision=last;break
    if decision is None:terminal(prefix,'unresolved',cost=str(paid),last_certificate=last);continue
    if decision['accepted']:
     candidate=dict(selection=list(prefix),cost_decimal=str(paid),cost=float(paid),certificate=decision,LSS_qualified=False);pool.append(candidate);terminal(prefix,'raw_accepted',candidate=candidate)
     if len(pool)>=max_candidates:status='candidate_limit';break
    else:terminal(prefix,'raw_refuted',cost=str(paid),certificate=decision)
    continue
   children=[]
   for j in groups[depth]:
    p=prefix+(j,);paid2=paid+cost[j];poly2=(poly*items[j]).truncate(B+1);den2=pden*lengths[j]
    if eps:gp2=(gpoly*guideitems[j]).truncate(B+1);gd2=gden*guidelengths[j]
    else:gp2=poly2;gd2=den2
    residual2=C-paid2-suffixmin[depth+1];num=None;score=-1.;rawscore=-1.
    if residual2>=0:
     c2=K if delta==0 else int(residual2*K//delta);num=int((poly2*raw_mass(depth+1,c2)).truncate(B+1)(1));rawscore=float(F(num,Q*den2))
     score=float(F(int((gp2*guide_mass(depth+1,c2)).truncate(B+1)(1)),Q*gd2)) if eps else rawscore
     lookahead+=1
    # A low GUIDE score changes order only: every child stays in the frontier.
    key=(score,rawscore,-float(paid2),rng.random());children.append((key,(p,poly2,paid2,den2,gp2,gd2,num)))
   for _,child in sorted(children,key=lambda x:x[0]):stack.append(child)
 if not stack and status!='candidate_limit':status='exhausted'
 pending=[dict(prefix=list(p),cost=str(c)) for p,_,c,_,_,_,_ in stack];remaining=sum(math.prod(len(g) for g in groups[len(p):]) for p,_,_,_,_,_,_ in stack)
 if covered+remaining!=total:raise ArithmeticError('Prefix partition mismatch')
 pool.sort(key=lambda x:(F(x['cost_decimal']),x['selection']));excluded=status=='exhausted' and counts['raw_accepted']==0 and counts['unresolved']==0
 d=dict(schema='I010_robust_CDF_priority_candidate_search',status=status,instance=inst.name,capacity=str(T),cost_limit=str(C),time_bins=B,cost_bins=K,probability_bits=bits,Q=str(Q),groups=groups,group_order=list(range(m)),seed=seed,mass_shift=str(eps),guide_mass_shift_used=guide['mass_shift'],max_candidates=max_candidates,total_combinations=str(total),visited_nodes=visited,lookahead_evaluations=lookahead,terminal_counts=counts,covered_combinations=str(covered),remaining_combinations=str(remaining),pending_frontier=pending,candidate_shortlist=pool,candidates=pool,raw_cost_line_excluded=excluded,DP_status=raw['status'],guide_DP_status=guide['status'],DP_seconds=raw['seconds'],guide_DP_seconds=guide['seconds'] if eps else 0.,seconds=time.monotonic()-start,raw_predicate='all original empirical marginals independent; strict sum<T probability>=.99',guide_role='ordering only, never probability pruning or acceptance',pruning_measure='original empirical only',original_samples_changed=False,all_original_samples=True,LSS_calls=0,tail_hard_gate_added=False)
 with out.open('x') as f:json.dump(d,f,indent=2)
 return d
