"""Exact upper relaxation of a fixed-selection empirical chance constraint.

Two optimistic relaxations: floor cost/time grids and adaptive future choices.
Probability arithmetic is integer with upward rounding. No floating probability
computation, no true distributions, no LSS selection or sample deletion.
"""
from fractions import Fraction
from collections import Counter
import time,hashlib,struct,math
from flint import fmpz_poly

def quantized_marginal(values,capacity,bins,shift=Fraction(0)):
 T=Fraction(capacity);eps=Fraction(shift)
 if not 0<=eps<1:raise ValueError('CDF shift outside[0,1)')
 L=len(values);D=math.lcm(L,eps.denominator);removed=int(eps*D)
 counts=Counter(int(Fraction(x)*bins//T) for x in values)
 running=0;previous=0;mass=[]
 for t in range(bins+1):
  running+=counts[t];cdf=max(0,running*(D//L)-removed);mass.append(cdf-previous);previous=cdf
 return fmpz_poly(mass),D

def matrix_sha(rows):
 h=hashlib.sha256();h.update(struct.pack('<II',len(rows),len(rows[0])))
 for row in rows:h.update(struct.pack('<%dQ'%len(row),*row))
 return h.hexdigest()

def exact_upper(groups,cost,samples,capacity,limit,time_bins,cost_bins,bits=48,
                prefix=(),reverse=False,deadline=None,return_matrix=False,collect_stages=False,mass_shift=Fraction(0)):
 started=time.monotonic();T=Fraction(capacity);C=Fraction(limit);B=int(time_bins);K=int(cost_bins);bits=int(bits);Q=1<<bits
 groups=[list(map(int,g)) for g in groups];m=len(groups);n=len(cost)
 if not m or any(not g for g in groups) or sorted(j for g in groups for j in g)!=list(range(n)):raise ValueError('Full item partition required')
 if len(samples)!=n or B<2 or K<1 or not 1<=bits<=63 or T<=0:raise ValueError('Invalid bound dimensions')
 cost=list(map(Fraction,cost));samples=[list(map(Fraction,a)) for a in samples]
 if any(not a or min(a)<0 for a in samples):raise ValueError('Full nonnegative empirical samples required')
 shift=Fraction(mass_shift)
 if not 0<=shift<1:raise ValueError('Invalid guidance shift')
 prefix=tuple(map(int,prefix))
 if len(prefix)>m or any(j not in groups[g] for g,j in enumerate(prefix)):raise ValueError('Invalid canonical group prefix')
 allowed=[[prefix[g]] if g<len(prefix) else group for g,group in enumerate(groups)]
 minima=[min(cost[j] for j in group) for group in allowed];delta=C-sum(minima,Fraction(0));order=list(range(m))
 if reverse:order.reverse()
 common=dict(schema='I007_exact_adaptive_budget_CDF_upper',capacity=str(T),cost_limit=str(C),time_bins=B,cost_bins=K,probability_bits=bits,Q=str(Q),prefix=list(prefix),group_order=order,minimal_cost=str(sum(minima,Fraction(0))),remaining_excess=str(delta),raw_predicate='all empirical marginals independent; strict sum<T probability>=.99',upper_predicate='cost/time downward grids; inclusive sum<=B; adaptive-choice DP; each probability division rounded upward',all_original_samples=(shift==0),all_source_observations_used=True,source_samples_changed=False,mass_shift=str(shift),gate_eligible=(shift==0),role='original_empirical_upper' if shift==0 else 'guidance_only_shifted_CDF',LSS_calls=0,tail_hard_gate_added=False)
 def finish(status,U,stages,convs):
  upper=U[K][B] if status=='completed' else None
  d=dict(common,status=status,upper_numerator=str(upper) if upper is not None else None,denominator=str(Q),prefix_cost_line_excluded=(100*upper<99*Q) if upper is not None else False,global_cost_line_excluded=(not prefix and 100*upper<99*Q) if upper is not None else False,completed_stages=len(stages),stages=stages,integer_convolutions=convs,seconds=time.monotonic()-started)
  if return_matrix:d['matrix']=U
  if collect_stages:d['matrices']=matrices
  return d
 matrices={}
 if delta<0:return finish('completed',tuple((0,)*(B+1) for _ in range(K+1)),[],0)
 units={};hist={};lengths={}
 for g,group in enumerate(allowed):
  for j in group:
   excess=cost[j]-minima[g]
   units[j]=(0 if excess==0 else K+1) if delta==0 else int(excess*K//delta)
   hist[j],lengths[j]=quantized_marginal(samples[j],T,B,shift)
 U=((Q,)*(B+1),)*(K+1);stages=[];convs=0;matrices={m:U}
 for g in order:
  before=time.monotonic();polys={row:fmpz_poly(list(row)) for row in set(U)};cache={};new=[];intern={}
  for c in range(K+1):
   if deadline is not None and time.monotonic()>=deadline:return finish('budget_exhausted',U,stages,convs)
   row=[0]*(B+1)
   for j in allowed[g]:
    r=units[j]
    if r>c:continue
    key=(j,U[c-r])
    if key not in cache:
     product=(hist[j]*polys[U[c-r]]).truncate(B+1);L=lengths[j]
     cache[key]=tuple(min(Q,(int(product[t])+L-1)//L) for t in range(B+1));convs+=1
    values=cache[key]
    for t,v in enumerate(values):
     if v>row[t]:row[t]=v
   row=tuple(row);new.append(intern.setdefault(row,row))
  U=tuple(new)
  if collect_stages:matrices[g]=U
  stages.append(dict(group=g,matrix_sha256=matrix_sha(U),unique_rows=len(intern),integer_convolutions=len(cache),seconds=time.monotonic()-before))
 return finish('completed',U,stages,convs)
