import os,sys
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT.parent/'vendor313'))
import argparse,json,hashlib,time
ap=argparse.ArgumentParser();ap.add_argument('--instance',required=True);ap.add_argument('--capacity',required=True);ap.add_argument('--cost-limit',required=True);ap.add_argument('--time-bins',type=int,default=512);ap.add_argument('--cost-bins',type=int,default=256);ap.add_argument('--bits',type=int,default=48);ap.add_argument('--seconds',type=float,default=600);ap.add_argument('--mass-shift',default='1/4000');ap.add_argument('--max-candidates',type=int,default=32);ap.add_argument('--seed',type=int,required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
bench=Path(a.instance).resolve();out=Path(a.out).resolve();out.parent.mkdir(parents=True,exist_ok=True);own={str(out),str(out)+'.run.json',str(out)+'.dp.json',str(out)+'.guide.dp.json',str(out)+'.proof.jsonl.gz',str(out.parent)}
if any(Path(p).exists() for p in own if p!=str(out.parent)):raise RuntimeError('No output overwrite')
sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')};inputs=[bench/'cost.txt',bench/'node_to_factor.pkl']+[p for p in bench.glob('*_sample.txt') if not p.name.endswith('_big_sample.txt')];input_sha={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs};reads=set();work=ROOT.parents[3];protected=bench.parent.parent;vendor=(ROOT.parent/'vendor313').resolve()
def guard(event,args):
 if event!='open' or not isinstance(args[0],(str,bytes,os.PathLike)):return
 p=Path(os.fsdecode(args[0])).resolve()
 if p.name.endswith('_dist.txt'):raise PermissionError('No true distribution in candidate search')
 if p==protected or protected in p.parents:
  if p!=bench and (p.parent!=bench or p.name not in input_sha):raise PermissionError('Unregistered benchmark input')
  reads.add(str(p))
 if p==work or work in p.parents:
  if p!=ROOT and ROOT not in p.parents and p!=vendor and vendor not in p.parents and str(p) not in own:raise PermissionError('No history/vector/cache input')
  reads.add(str(p))
sys.addaudithook(guard)
from fractions import Fraction
from instance import load_instance
from priority_search import run_priority
started=time.monotonic();inst=load_instance(bench);d=run_priority(inst,a.capacity,a.cost_limit,a.time_bins,a.cost_bins,a.bits,a.seconds,out,Fraction(a.mass_shift),a.max_candidates,a.seed,started)
with Path(str(out)+'.run.json').open('x') as f:json.dump(dict(source_sha256=sources,input_sha256=input_sha,opened_task_paths=sorted(reads),seconds=time.monotonic()-started,budget=a.seconds,python=sys.version,seed=a.seed,mass_shift=a.mass_shift,no_true_distribution=True,no_history_vector_or_cache_input=True,external_scalar_cost_target=True),f,indent=2)
print(json.dumps({k:v for k,v in d.items() if k not in ['pending_frontier','candidates','candidate_shortlist','groups']}),flush=True)
