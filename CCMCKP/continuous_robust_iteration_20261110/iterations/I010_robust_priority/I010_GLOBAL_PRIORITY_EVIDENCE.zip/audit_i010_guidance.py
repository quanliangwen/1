"""Independent shifted-CDF DP replay; never imports optimization code."""
from fractions import Fraction as F
from bisect import bisect_left
import math,struct,hashlib,time
from flint import fmpz_poly

def replay_guide(groups,cost,samples,T,C,B,K,bits,guide,raw,requested):
 start=time.monotonic();eps=F(guide['mass_shift']);Q=2**bits;m=len(groups)
 if raw['status']=='completed' and eps!=F(requested):raise RuntimeError('Requested robust guide was changed')
 if not eps:
  if guide!=raw:raise RuntimeError('Zero-shift guide differs from verified raw table')
  return dict(alias_of_verified_raw=True,recomputed_stages=0,independent_convolutions=0,seconds=time.monotonic()-start)
 if guide['gate_eligible'] or guide['role']!='guidance_only_shifted_CDF' or guide['source_samples_changed']:raise RuntimeError('Guidance role incorrectly labelled')
 for key,expected in [('capacity',T),('cost_limit',C)]:
  if F(guide[key])!=expected:raise RuntimeError('Guide target differs')
 if guide['time_bins']!=B or guide['cost_bins']!=K or guide['probability_bits']!=bits or guide['prefix'] or guide['group_order']!=list(range(m-1,-1,-1)):raise RuntimeError('Guide state space differs')
 mins=[min(cost[j] for j in g) for g in groups];delta=C-sum(mins,F(0));hist={};norm={};units={}
 for g,group in enumerate(groups):
  for j in group:
   D=math.lcm(len(samples[j]),eps.denominator);norm[j]=D;removed=eps.numerator*(D//eps.denominator)
   cdf=[max(0,bisect_left(samples[j],F(t+1)*T/B)*(D//len(samples[j]))-removed) for t in range(B+1)];hist[j]=fmpz_poly([cdf[0]]+[cdf[t]-cdf[t-1] for t in range(1,B+1)])
   if delta>=0:
    ratio=(cost[j]-mins[g])*K/delta if delta else None;units[j]=ratio.numerator//ratio.denominator if ratio is not None else (0 if cost[j]==mins[g] else K+1)
 U=[(Q,)*(B+1)]*(K+1);digests=[];convs=0;expected=m if delta>=0 and guide['status']=='completed' else len(guide['stages'])
 if len(guide['stages'])!=expected:raise RuntimeError('Incomplete guide claimed complete')
 for stage,g in enumerate(list(range(m-1,-1,-1))[:expected]):
  diff={row:fmpz_poly([row[0]]+[row[t]-row[t-1] for t in range(1,B+1)]) for row in set(U)};cache={};new=[None]*(K+1)
  for c in range(K,-1,-1):
   values=[0]*(B+1)
   for j in reversed(groups[g]):
    r=units[j]
    if r>c:continue
    key=(j,U[c-r])
    if key not in cache:
     product=(diff[U[c-r]]*hist[j]).truncate(B+1);running=0;row=[]
     for t in range(B+1):
      running+=int(product[t]);quotient,remainder=divmod(running,norm[j]);row.append(min(Q,quotient+(remainder>0)))
     cache[key]=tuple(row);convs+=1
    values=[max(x,y) for x,y in zip(values,cache[key])]
   new[c]=tuple(values)
  U=new;h=hashlib.sha256();h.update(struct.pack('<II',K+1,B+1))
  for row in U:h.update(struct.pack('<%dQ'%(B+1),*row))
  sha=h.hexdigest()
  if guide['stages'][stage]['group']!=g or guide['stages'][stage]['matrix_sha256']!=sha:raise RuntimeError('Robust guide matrix differs')
  digests.append(dict(group=g,matrix_sha256=sha))
 if guide['status']=='completed':
  upper=U[K][B] if delta>=0 else 0
  if str(upper)!=guide['upper_numerator'] or str(Q)!=guide['denominator']:raise RuntimeError('Robust guide bound differs')
 return dict(alias_of_verified_raw=False,recomputed_stages=len(digests),independent_convolutions=convs,stages=digests,seconds=time.monotonic()-start)
