from pathlib import Path
import sys,json,pickle,hashlib
from fractions import Fraction as F
H=Path(__file__).parent;I=H/'iterations/I010_robust_priority';sys.path[:0]=[str(I/'candidate'),str(I/'vendor313')]
from instance import load_instance
from priority_search import run_priority
root=I/'edge01';root.mkdir(exist_ok=False);rows=[]
models=[('zero_cost',[0,0,0,0],[0,0,0,0],0,15,8,False),('cost_empty',[1,1,1,1],[0,0,0,0],1,15,8,True),('zero_excess',[1,2,1,2],[2,0,2,0],2,15,8,True),('timeout',[0,0,0,0],[0,2,0,2],0,0,8,False),('candidate_limit',[0,0,0,0],[0,0,0,0],0,15,2,False)]
for name,cost,values,C,seconds,cap,excluded in models:
 p=root/name;p.mkdir();(p/'cost.txt').write_text('\n'.join(map(str,cost)));(p/'node_to_factor.pkl').write_bytes(pickle.dumps([[0,1],[2,3]]))
 for j,v in enumerate(values):(p/f'{j}_sample.txt').write_text(str(v)+'\n')
 d=run_priority(load_instance(p),'1',str(C),8,4,8,seconds,p/'tree.json',F(1,3),cap,101001)
 assert d['raw_cost_line_excluded']==excluded
 if name=='zero_cost':assert len(d['candidate_shortlist'])==4
 if name=='cost_empty':assert d['terminal_counts']['cost']==1
 if name=='zero_excess':assert d['terminal_counts']['budget_cdf']==1
 if name=='timeout':assert d['status']=='budget_exhausted' and d['remaining_combinations']=='4' and d['visited_nodes']==0 and not d['candidate_shortlist']
 if name=='candidate_limit':assert d['status']=='candidate_limit' and len(d['candidate_shortlist'])==2 and d['covered_combinations']=='2' and d['remaining_combinations']=='2'
 rows.append(dict(name=name,status=d['status'],raw_candidates=len(d['candidate_shortlist']),excluded=d['raw_cost_line_excluded'],terminal=d['terminal_counts']))
result=dict(passed=True,models=len(models),source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')},scope='zero costs, cost-empty, zero excess, timeout, and early multiple-candidate limit with retained complete frontier; guide shift1/3 never used as feasibility gate',rows=rows)
with (I/'MATH_EDGE_CHECK.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
