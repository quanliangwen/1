from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import sys,json,itertools,math,random,pickle,gzip,hashlib
H=Path(__file__).parent;I=H/'iterations/I010_robust_priority';sys.path[:0]=[str(I/'candidate'),str(I/'vendor313')]
from budget_cdf import exact_upper,quantized_marginal
from instance import load_instance
from priority_search import run_priority
root=I/'math01';root.mkdir(exist_ok=False);rng=random.Random(1010);checks=0;records=[]
def shifted_measure(values,T,eps):
 weights={x:F(n,len(values)) for x,n in Counter(values).items()};left=eps
 for x in sorted(weights):
  removed=min(left,weights[x]);weights[x]-=removed;left-=removed
 assert left==0
 far=max(max(values),T)+1;weights[far]=weights.get(far,F(0))+eps
 return [(x,p) for x,p in weights.items() if p]
def rational_dp(groups,cost,distributions,T,C,B,K):
 mins=[min(cost[j] for j in g) for g in groups];delta=C-sum(mins,F(0));m=len(groups)
 if delta<0:return [[F(0)]*(B+1) for c in range(K+1)]
 units={j:((0 if cost[j]==mins[g] else K+1) if delta==0 else math.floor((cost[j]-mins[g])*K/delta)) for g in range(m) for j in groups[g]};ys={j:[(math.floor(x*B/T),p) for x,p in distributions[j]] for j in cost};U=[[F(1)]*(B+1) for c in range(K+1)]
 for g in range(m-1,-1,-1):
  new=[[F(0)]*(B+1) for c in range(K+1)]
  for c in range(K+1):
   for t in range(B+1):
    for j in groups[g]:
     r=units[j]
     if r<=c:new[c][t]=max(new[c][t],sum((p*U[c-r][t-y] for y,p in ys[j] if y<=t),F(0)))
  U=new
 return U
for m in [2,3,4]:
 for trial in range(4):
  folder=root/f'm{m}_t{trial}';folder.mkdir();groups=[list(range(3*g,3*g+3)) for g in range(m)];cost={};samples={}
  for g in range(m):
   for k,j in enumerate(groups[g]):
    cost[j]=F(rng.randrange(k*4,k*4+5),2);samples[j]=[F(rng.randrange(0,9-4*k),2) for _ in range(rng.randrange(3,6))] if k<2 else [F(0)]*rng.randrange(3,6)
  (folder/'cost.txt').write_text('\n'.join(str(float(cost[j])) for j in range(3*m)));(folder/'node_to_factor.pkl').write_bytes(pickle.dumps(groups))
  for j,a in samples.items():(folder/f'{j}_sample.txt').write_text('\n'.join(str(float(x)) for x in a))
  T=F(rng.randrange(3,9),2);truth={}
  for s in itertools.product(*groups):
   outcomes=[sum(x,F(0)) for x in itertools.product(*(samples[j] for j in s))];truth[s]=dict(cost=sum((cost[j] for j in s),F(0)),strict=F(sum(x<T for x in outcomes),len(outcomes)),inclusive=F(sum(x<=T for x in outcomes),len(outcomes)))
  optimum=min(v['cost'] for v in truth.values() if v['strict']>=F(99,100));inst=load_instance(folder)
  for eindex,eps in enumerate([F(0),F(1,4000),F(1,2000),F(1,3)]):
   distributions={j:shifted_measure(samples[j],T,eps) for j in cost}
   for j in cost:
    h,D=quantized_marginal(samples[j],T,12,eps);running=0
    for t in range(13):
     running+=int(h[t]);expected=sum((p for x,p in distributions[j] if math.floor(x*12/T)<=t),F(0));assert F(running,D)==expected;checks+=1
   reference=rational_dp(groups,cost,distributions,T,optimum,12,6);table=exact_upper(groups,[cost[j] for j in cost],[samples[j] for j in cost],T,optimum,12,6,12,reverse=True,mass_shift=eps,return_matrix=True)
   for c in range(7):
    for t in range(13):
     v=F(table['matrix'][c][t],2**12);assert reference[c][t]<=v<=reference[c][t]+F(m,2**12);checks+=1
   for label,C in [('below',optimum-F(1,2)),('at',optimum)]:
    out=folder/f'e{eindex}_{label}.json';d=run_priority(inst,str(T),str(C),32,12,16,15,out,eps,200,101001)
    expected={s for s,v in truth.items() if v['cost']<=C and v['strict']>=F(99,100)};actual={tuple(c['selection']) for c in d['candidate_shortlist']};assert actual==expected;checks+=1
    assert d['raw_cost_line_excluded']==(not actual and d['terminal_counts']['unresolved']==0);prefixes=[];covered=0
    for row in d['candidate_shortlist']:assert row['cost_decimal']==str(truth[tuple(row['selection'])]['cost']);checks+=1
    assert d['candidate_shortlist']==sorted(d['candidate_shortlist'],key=lambda x:(F(x['cost_decimal']),x['selection']));checks+=1
    with gzip.open(str(out)+'.proof.jsonl.gz','rt') as f:
     for line in f:
      r=json.loads(line);prefix=tuple(r['prefix']);prefixes.append(prefix);covered+=int(r['cover']);matching=[v for s,v in truth.items() if s[:len(prefix)]==prefix]
      if r['kind']=='cost':assert all(v['cost']>C for v in matching);checks+=1
      elif r['kind']=='budget_cdf':
       upper=F(int(r['upper_numerator']),int(r['denominator']));assert upper<F(99,100)
       for v in matching:
        if v['cost']<=C:assert v['inclusive']<=upper;checks+=1
      elif r['kind']=='raw_accepted':assert truth[prefix]['strict']>=F(99,100) and truth[prefix]['cost']<=C;checks+=1
      elif r['kind']=='raw_refuted':assert truth[prefix]['strict']<F(99,100);checks+=1
      elif r['kind']=='unresolved':assert not d['raw_cost_line_excluded'];checks+=1
      else:raise AssertionError('Unknown terminal')
    for r in d['pending_frontier']:prefixes.append(tuple(r['prefix']));covered+=math.prod(len(g) for g in groups[len(r['prefix']):])
    assert covered==len(truth)
    for k,p in enumerate(prefixes):
     for q in prefixes[:k]:assert p[:len(q)]!=q and q[:len(p)]!=p
    checks+=1;records.append(dict(groups=m,trial=trial,shift=str(eps),label=label,candidates=len(actual),unresolved=d['terminal_counts']['unresolved'],visited=d['visited_nodes'],lookahead=d['lookahead_evaluations']))
# Critical regression: guide probability4/9<.99 must retain all4raw-feasible vectors.
p=root/'guide_not_gate';p.mkdir();(p/'cost.txt').write_text('0\n0\n0\n0\n');(p/'node_to_factor.pkl').write_bytes(pickle.dumps([[0,1],[2,3]]))
for j in range(4):(p/f'{j}_sample.txt').write_text('0\n')
d=run_priority(load_instance(p),'1','0',8,4,16,15,p/'tree.json',F(1,3),8,101001)
assert len(d['candidate_shortlist'])==4 and d['status']=='exhausted' and not d['raw_cost_line_excluded'];checks+=1
guide=json.load(open(p/'tree.json.guide.dp.json'));assert F(int(guide['upper_numerator']),int(guide['denominator']))<F(99,100) and not guide['gate_eligible'];checks+=1
result=dict(passed=True,checks=checks,input_models=12,tree_runs=len(records),guide_not_gate_regression_passed=True,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')},scope='full choices/joint raw outcomes; all true feasible choices retained under4guide shifts, every cost/raw upper prune verified, full partition, pool/cost order; independent weighted-mass Fraction DP at every state; guide below.99 cannot reject original feasible selections',records=records)
with (I/'MATH_CHECK.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='records'}))
