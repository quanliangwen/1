from pathlib import Path
from decimal import Decimal
import json,hashlib,subprocess,time
H=Path(__file__).parent;I=H/'iterations/I010_robust_priority';J=I/'engineering40';J.mkdir(exist_ok=True);out=J/'tree.json'
if (J/'REGISTRATION.json').exists() or out.exists():raise RuntimeError('No duplicate engineering run')
mathcheck=json.load(open(I/'MATH_CHECK.json'));source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')}
if not mathcheck['passed'] or source!=mathcheck['source_sha256']:raise RuntimeError('Math/source check required')
c=next(c for c in json.load(open(H/'CASES.json')) if c['index']==40);prior=json.load(open(H/'iterations/I004_robust_pair_exchange/REGISTRATION.json'));current=str(prior['current_qualified_costs']['40']);target=str(Decimal(current)-Decimal('0.1'))
reg=dict(iteration='I010_engineering',time=time.time(),source_sha256=source,index=40,instance=c['instance'],capacity=str(c['tmax']),cost_limit=target,current_qualified_reference=current,scalar_target_reduction='0.1',time_bins=512,cost_bins=256,probability_bits=48,mass_shift='1/4000',max_candidates=8,seed=9710000,seconds=120,watchdog=170,scope='bounded engineering exercise, raw candidates only, not LSS-qualified gain or30-run statistics',target_information='historical qualified COST SCALAR only, openly disclosed; no saved vector/native data in optimizer',no_LSS_calls=True,formal_source_unchanged=True)
(J/'REGISTRATION.json').write_text(json.dumps(reg,indent=2))
cmd=['/home/junhao/miniconda3/bin/python','-u',str(I/'candidate/run_priority.py'),'--instance','/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/'+reg['instance'],'--capacity',reg['capacity'],'--cost-limit',target,'--time-bins','512','--cost-bins','256','--bits','48','--mass-shift','1/4000','--max-candidates','8','--seed',str(reg['seed']),'--seconds','120','--out',str(out)]
with (J/'engineering.log').open('x') as f:
 start=time.monotonic();r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=170)
(J/'TERMINAL.json').write_text(json.dumps(dict(exit=r.returncode,wall=time.monotonic()-start,source_sha256=source),indent=2))
if r.returncode:raise RuntimeError('Engineering run failed; record retained')
d=json.load(open(out));print(json.dumps({k:v for k,v in d.items() if k not in ['groups','pending_frontier','candidates','candidate_shortlist']}));print(json.dumps(dict(raw_candidates=len(d['candidate_shortlist']),raw_costs=[c['cost'] for c in d['candidate_shortlist']])))
