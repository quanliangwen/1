"""Independent replay with sorted thresholds and CDF differences.

Does not import the solver. Convolves probability masses with successive CDF
increments then sums them, unlike the solver's direct CDF convolution.
"""
from pathlib import Path
from fractions import Fraction as F
from bisect import bisect_left
import sys,json,pickle,math,hashlib,struct,time,argparse
H=Path(__file__).parent;I=H/'iterations/I007_integer_budget_cdf';sys.path.insert(0,str(I/'vendor313'))
from flint import fmpz_poly
ap=argparse.ArgumentParser();ap.add_argument('--trial',required=True);a=ap.parse_args();J=I/a.trial;path=J/'bound.json';out=J/'INDEPENDENT_AUDIT.json'
if out.exists():raise RuntimeError('No audit overwrite')
start=time.monotonic();d=json.load(open(path));reg=json.load(open(J/'REGISTRATION.json'));meta=json.load(open(str(path)+'.run.json'));source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')}
if source!=meta['source_sha256'] or source!=reg['source_sha256']:raise RuntimeError('Solver source mismatch')
for k in ['capacity','cost_limit']:
 if F(d[k])!=F(reg[k]):raise RuntimeError('Cost/capacity target changed')
for k in ['prefix','time_bins','cost_bins','probability_bits']:
 if d[k]!=reg[k]:raise RuntimeError('Registered bound dimensions changed')
if d['instance']!=reg['instance']:raise RuntimeError('Wrong instance')
bench=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/d['instance'];raw=json.load(open(H/'RAW_REFERENCE.json'))
for name,sha in meta['input_sha256'].items():
 if hashlib.sha256((bench/name).read_bytes()).hexdigest()!=sha or raw[str(bench/name)]!=sha:raise RuntimeError('Original input changed')
for opened in meta['opened_task_paths']:
 p=Path(opened)
 if p.name.endswith('_dist.txt') or '/lss_cache/' in opened:raise RuntimeError('True model/cache accessed')
 if bench in p.parents and p.name not in meta['input_sha256']:raise RuntimeError('Unregistered benchmark input read')
groups=pickle.load(open(bench/'node_to_factor.pkl','rb'));groups=[list(map(int,groups[k])) for k in sorted(groups,key=int)] if isinstance(groups,dict) else [list(map(int,g)) for g in groups]
cost=[F(x) for x in (bench/'cost.txt').read_text().split()];n=len(cost);m=len(groups)
if sorted(j for group in groups for j in group)!=list(range(n)):raise RuntimeError('Input partition invalid')
if set(meta['input_sha256'])!={'cost.txt','node_to_factor.pkl',*(f'{j}_sample.txt' for j in range(n))}:raise RuntimeError('Incomplete input inventory')
samples={j:sorted(F(x) for x in (bench/f'{j}_sample.txt').read_text().split()) for j in range(n)}
if any(not v or v[0]<0 for v in samples.values()):raise RuntimeError('Invalid empirical samples')
B=d['time_bins'];K=d['cost_bins'];Q=2**d['probability_bits'];T=F(d['capacity']);C=F(d['cost_limit']);prefix=d['prefix']
if len(prefix)>m or any(j not in groups[g] for g,j in enumerate(prefix)):raise RuntimeError('Invalid canonical prefix')
allowed=[[prefix[g]] if g<len(prefix) else group for g,group in enumerate(groups)];mins=[min(cost[j] for j in group) for group in allowed];delta=C-sum(mins,F(0));order=list(range(m))
if reg['reverse']:order.reverse()
if order!=d['group_order'] or str(sum(mins,F(0)))!=d['minimal_cost'] or str(delta)!=d['remaining_excess'] or str(Q)!=d['Q']:raise RuntimeError('Wrong state model')
hist={};units={};plain=[];plain_den=1
for g,group in enumerate(allowed):
 D=math.lcm(*(len(samples[j]) for j in group));plain_den*=D;cdfvalues=[]
 for j in group:
  # q=floor(B*x/T)<=t iff x<(t+1)T/B, constructed without per-sample floor.
  counts=[bisect_left(samples[j],F(t+1)*T/B) for t in range(B+1)]
  mass=[counts[0]]+[counts[t]-counts[t-1] for t in range(1,B+1)];hist[j]=fmpz_poly(mass)
  cdfvalues.append([v*(D//len(samples[j])) for v in counts])
  if delta>=0:
   ratio=(cost[j]-mins[g])*K/delta if delta else None;units[j]=(ratio.numerator//ratio.denominator) if ratio is not None else (0 if cost[j]==mins[g] else K+1)
 envelope=[max(v[t] for v in cdfvalues) for t in range(B+1)]
 plain.append(fmpz_poly([envelope[0]]+[envelope[t]-envelope[t-1] for t in range(1,B+1)]))
polys=plain
while len(polys)>1:polys=[(polys[k]*polys[k+1]).truncate(B+1) if k+1<len(polys) else polys[k] for k in range(0,len(polys),2)]
plain_num=int(polys[0].truncate(B+1)(1))
def digest(rows):
 h=hashlib.sha256();h.update(struct.pack('<II',K+1,B+1))
 for row in rows:h.update(struct.pack('<%dQ'%(B+1),*row))
 return h.hexdigest()
U=[(Q,)*(B+1)]*(K+1) if delta>=0 else [(0,)*(B+1)]*(K+1);replayed=[];calls=0
expected_stages=m if d['status']=='completed' and delta>=0 else len(d['stages'])
if len(d['stages'])!=expected_stages:raise RuntimeError('Incomplete claimed DP')
for stage,g in enumerate(order[:expected_stages]):
 masspolys={}
 for row in set(U):
  if any(row[t]<row[t-1] for t in range(1,B+1)):raise RuntimeError('Non-CDF state')
  masspolys[row]=fmpz_poly([row[0]]+[row[t]-row[t-1] for t in range(1,B+1)])
 cache={};new=[None]*(K+1)
 for c in range(K,-1,-1):
  values=[0]*(B+1)
  for j in reversed(allowed[g]):
   r=units[j]
   if r>c:continue
   key=(j,U[c-r])
   if key not in cache:
    p=(masspolys[U[c-r]]*hist[j]).truncate(B+1);running=0;row=[]
    for t in range(B+1):
     running+=int(p[t]);quotient,remainder=divmod(running,len(samples[j]));row.append(min(Q,quotient+(remainder>0)))
    cache[key]=tuple(row);calls+=1
   values=[max(x,y) for x,y in zip(values,cache[key])]
  new[c]=tuple(values)
 if any(new[c][t]<new[c-1][t] for c in range(1,K+1) for t in range(B+1)):raise RuntimeError('Nonmonotone cost states')
 U=new;actual=digest(U)
 if d['stages'][stage]['group']!=g or actual!=d['stages'][stage]['matrix_sha256']:raise RuntimeError('Intermediate DP matrix differs')
 replayed.append(dict(group=g,matrix_sha256=actual,independent_convolutions=len(cache)))
upper=U[K][B] if d['status']=='completed' else None;excluded=upper is not None and 100*upper<99*Q
if (str(upper) if upper is not None else None)!=d['upper_numerator'] or str(Q)!=d['denominator'] or excluded!=d['prefix_cost_line_excluded'] or (excluded and not prefix)!=d['global_cost_line_excluded']:raise RuntimeError('False exclusion decision')
result=dict(passed=True,instance=d['instance'],prefix=prefix,cost_limit=d['cost_limit'],capacity=d['capacity'],status=d['status'],upper_numerator=str(upper) if upper is not None else None,denominator=str(Q),upper_float=float(F(upper,Q)) if upper is not None else None,prefix_cost_line_excluded=excluded,global_cost_line_excluded=excluded and not prefix,plain_CDF_upper_numerator=str(plain_num),plain_CDF_denominator=str(plain_den),plain_CDF_upper_float=float(F(plain_num,plain_den)),newly_excludes_vs_plain_CDF=excluded and 100*plain_num>=99*plain_den,recomputed_stages=len(replayed),independent_integer_convolutions=calls,stages=replayed,source_sha256=source,result_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),seconds=time.monotonic()-start,scope='only the registered prefix/cost-line finite empirical set; no positive feasibility claim, no original LSS calls or global exclusion unless prefix empty',method='sorted-threshold empirical masses; independent CDF-increment integer DP; every intermediate matrix digest recounted')
with out.open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='stages'}))
