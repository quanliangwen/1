from pathlib import Path
import json,hashlib,subprocess,time
H=Path(__file__).parent;I=H/'iterations/I007_integer_budget_cdf';J=I/'probe35_prefix30_121';J.mkdir(exist_ok=True);out=J/'bound.json';P=H/'iterations/I005_exact_cdf_bound/case35/probe_old_512_120.json'
if (J/'REGISTRATION.json').exists() or out.exists():raise RuntimeError('No duplicate engineering run')
previous=json.load(open(P));audit=json.load(open(str(P)+'.audit.json'));prefix=[30,121]
if not audit['passed'] or not any(n['prefix']==prefix for n in previous['pending_frontier']):raise RuntimeError('Prefix must belong to verified unfinished tree')
mathcheck=json.load(open(I/'MATH_CHECK.json'));source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')}
if not mathcheck['passed'] or source!=mathcheck['source_sha256']:raise RuntimeError('Exact small-model checks required')
reg=dict(time=time.time(),source_sha256=source,instance=previous['instance'],capacity=previous['capacity'],cost_limit=previous['cost_limit'],prefix=prefix,time_bins=512,cost_bins=256,probability_bits=48,reverse=False,seconds=120,watchdog=170,prior_tree_sha256=hashlib.sha256(P.read_bytes()).hexdigest(),prior_tree_independent_audit_sha256=hashlib.sha256(Path(str(P)+'.audit.json').read_bytes()).hexdigest(),scope='bounded integer upper-bound engineering check of a single pending subtree; not new feasible cost or global exclusion',no_LSS_calls=True,no_true_model_input=True,only_own_search_prefix=True,formal_source_unchanged=True)
(J/'REGISTRATION.json').write_text(json.dumps(reg,indent=2))
cmd=['/home/junhao/miniconda3/bin/python','-u',str(I/'candidate/run_budget_bound.py'),'--instance','/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/'+reg['instance'],'--capacity',reg['capacity'],'--cost-limit',reg['cost_limit'],'--prefix',json.dumps(prefix),'--time-bins','512','--cost-bins','256','--bits','48','--seconds','120','--out',str(out)]
with (J/'probe.log').open('x') as f:
 start=time.monotonic();r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=170)
(J/'TERMINAL.json').write_text(json.dumps(dict(exit=r.returncode,wall=time.monotonic()-start,source_sha256=source),indent=2))
if r.returncode:raise RuntimeError('Engineering run failed; retained logs')
d=json.load(open(out));print(json.dumps({k:v for k,v in d.items() if k!='stages'}))
