"""Independent full-outcome and exact-Fraction recurrence checks."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,itertools,random,hashlib,math
H=Path(__file__).parent;I=H/'iterations/I007_integer_budget_cdf';sys.path[:0]=[str(I/'candidate'),str(I/'vendor313')]
from budget_cdf import exact_upper
rng=random.Random(1007);records=[];checks=0;max_rounding=F(0)
def rational_dp(groups,cost,samples,T,C,B,K,prefix,reverse):
 allowed=[[prefix[g]] if g<len(prefix) else group for g,group in enumerate(groups)];mins=[min(cost[j] for j in group) for group in allowed];delta=C-sum(mins,F(0))
 if delta<0:return [[F(0)]*(B+1) for _ in range(K+1)]
 units={j:((0 if cost[j]==mins[g] else K+1) if delta==0 else math.floor((cost[j]-mins[g])*K/delta)) for g,group in enumerate(allowed) for j in group}
 ys={j:[math.floor(x*B/T) for x in samples[j]] for group in allowed for j in group};U=[[F(1)]*(B+1) for _ in range(K+1)]
 for g in (range(len(groups)-1,-1,-1) if reverse else range(len(groups))):
  new=[[F(0)]*(B+1) for _ in range(K+1)]
  for c in range(K+1):
   for t in range(B+1):
    for j in allowed[g]:
     r=units[j]
     if r>c:continue
     value=sum((U[c-r][t-y] for y in ys[j] if y<=t),F(0))/len(ys[j])
     new[c][t]=max(new[c][t],value)
  U=new
 return U
for m in [2,3,4]:
 for trial in range(4):
  groups=[[2*g,2*g+1] for g in range(m)];cost=[F(rng.randrange(0,19),10) for _ in range(2*m)];samples=[[F(rng.randrange(0,12),3) for _ in range(rng.randrange(3,6))] for _ in cost];T=F(rng.randrange(5,13),2)
  choices=[]
  for s in itertools.product(*groups):
   outcomes=[sum(xs,F(0)) for xs in itertools.product(*(samples[j] for j in s))];choices.append((s,sum((cost[j] for j in s),F(0)),F(sum(x<T for x in outcomes),len(outcomes))))
  minimum=sum((min(cost[j] for j in g) for g in groups),F(0));maximum=sum((max(cost[j] for j in g) for g in groups),F(0))
  for prefix in [(),(groups[0][1],)]:
   for C in [minimum-F(1,10),minimum,(minimum+maximum)/2,maximum]:
    actual=max((p for s,c,p in choices if c<=C and s[:len(prefix)]==prefix),default=F(0))
    for B,K,bits in [(6,3,8),(12,7,16)]:
     for reverse in [False,True]:
      d=exact_upper(groups,cost,samples,T,C,B,K,bits,prefix,reverse,return_matrix=True);Q=1<<bits;upper=F(int(d['upper_numerator']),Q);assert actual<=upper;checks+=1
      reference=rational_dp(groups,cost,samples,T,C,B,K,prefix,reverse)
      for c in range(K+1):
       for t in range(B+1):
        v=F(d['matrix'][c][t],Q);assert reference[c][t]<=v<=reference[c][t]+F(m,Q);assert 0<=v<=1
        if t:assert d['matrix'][c][t]>=d['matrix'][c][t-1]
        if c:assert d['matrix'][c][t]>=d['matrix'][c-1][t]
        checks+=1;max_rounding=max(max_rounding,v-reference[c][t])
      assert not d['prefix_cost_line_excluded'] or actual<F(99,100);checks+=1
      records.append(dict(groups=m,trial=trial,prefix=list(prefix),cost_limit=str(C),capacity=str(T),time_bins=B,cost_bins=K,bits=bits,reverse=reverse,actual_best_fixed_probability=str(actual),exact_relaxed_probability=str(reference[K][B]),integer_upper=str(upper),stages=len(d['stages'])))
d=dict(passed=True,checks=checks,input_models=12,recurrence_runs=len(records),max_rounding_excess=str(max_rounding),source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')},scope='every item selection and every joint outcome enumerated; independent direct-per-observation Fraction DP compared at every cost/time state; tests prefix restrictions, both orders, cost-empty and zero-excess cases, nonuniform sample lengths, upward rounding and monotonicity',records=records)
out=I/'MATH_CHECK.json'
with out.open('x') as f:json.dump(d,f,indent=2)
print(json.dumps({k:v for k,v in d.items() if k!='records'}))
