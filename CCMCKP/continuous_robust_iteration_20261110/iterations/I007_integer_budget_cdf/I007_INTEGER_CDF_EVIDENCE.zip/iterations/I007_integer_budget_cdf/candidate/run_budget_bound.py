import os,sys
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT.parent/'vendor313'))
import argparse,json,hashlib,time,pickle
from fractions import Fraction
ap=argparse.ArgumentParser();ap.add_argument('--instance',required=True);ap.add_argument('--capacity',required=True);ap.add_argument('--cost-limit',required=True);ap.add_argument('--prefix',default='[]');ap.add_argument('--reverse',action='store_true');ap.add_argument('--time-bins',type=int,default=512);ap.add_argument('--cost-bins',type=int,default=256);ap.add_argument('--bits',type=int,default=48);ap.add_argument('--seconds',type=float,default=120);ap.add_argument('--out',required=True);a=ap.parse_args()
bench=Path(a.instance).resolve();out=Path(a.out).resolve();out.parent.mkdir(parents=True,exist_ok=True);own={str(out),str(out)+'.run.json',str(out.parent)}
if out.exists() or Path(str(out)+'.run.json').exists():raise RuntimeError('No evidence overwrite')
sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')};inputs=[bench/'cost.txt',bench/'node_to_factor.pkl']+[p for p in bench.glob('*_sample.txt') if not p.name.endswith('_big_sample.txt')];input_sha={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs};reads=set();work=ROOT.parents[3];protected=bench.parent.parent;vendor=(ROOT.parent/'vendor313').resolve()
def guard(event,args):
 if event!='open' or not isinstance(args[0],(str,bytes,os.PathLike)):return
 p=Path(os.fsdecode(args[0])).resolve()
 if p.name.endswith('_dist.txt'):raise PermissionError('No true distribution in bound')
 if p==protected or protected in p.parents:
  if p!=bench and (p.parent!=bench or p.name not in input_sha):raise PermissionError('Unregistered benchmark input')
  reads.add(str(p))
 if p==work or work in p.parents:
  if p!=ROOT and ROOT not in p.parents and p!=vendor and vendor not in p.parents and str(p) not in own:raise PermissionError('No history or cache input')
  reads.add(str(p))
sys.addaudithook(guard)
from budget_cdf import exact_upper
started=time.monotonic();cost=[Fraction(s) for s in (bench/'cost.txt').read_text().split()];groups=pickle.load(open(bench/'node_to_factor.pkl','rb'));groups=[groups[k] for k in sorted(groups,key=int)] if isinstance(groups,dict) else groups
samples=[[Fraction(s) for s in (bench/f'{j}_sample.txt').read_text().split()] for j in range(len(cost))]
result=exact_upper(groups,cost,samples,Fraction(a.capacity),Fraction(a.cost_limit),a.time_bins,a.cost_bins,a.bits,json.loads(a.prefix),a.reverse,started+a.seconds);result['instance']=bench.name
with out.open('x') as f:json.dump(result,f,indent=2)
with Path(str(out)+'.run.json').open('x') as f:json.dump(dict(source_sha256=sources,input_sha256=input_sha,opened_task_paths=sorted(reads),seconds=time.monotonic()-started,budget=a.seconds,python=sys.version,no_true_distribution=True,no_history_or_cache=True),f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='stages'}),flush=True)
