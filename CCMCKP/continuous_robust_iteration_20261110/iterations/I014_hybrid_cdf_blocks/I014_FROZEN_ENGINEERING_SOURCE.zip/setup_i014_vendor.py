from pathlib import Path
import os
H=Path(__file__).parent;I=H/'iterations/I014_hybrid_cdf_blocks';link=I/'vendor313';target=H/'iterations/I002_cdf_neighborhood/vendor313'
if link.exists() or link.is_symlink():
 if link.resolve()!=target.resolve():raise RuntimeError('Unexpected existing vendor link')
else:os.symlink(target,link,target_is_directory=True)
print('I014 uses the same validated vendor313 dependencies')
