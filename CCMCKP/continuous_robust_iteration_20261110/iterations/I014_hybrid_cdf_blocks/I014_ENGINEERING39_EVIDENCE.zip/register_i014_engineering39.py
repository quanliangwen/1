from pathlib import Path
import json,hashlib,time
H=Path(__file__).parent;I=H/'iterations/I014_hybrid_cdf_blocks';J=I/'engineering39';J.mkdir(exist_ok=True)
if (J/'REGISTRATION.json').exists():raise RuntimeError('Engineering already registered')
source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')}
for name in ['MATH_CHECK.json','CDF_MATH_CHECK.json','SCHEDULE_CHECK.json','HYBRID_INTEGRATION_CHECK.json']:
 d=json.load(open(I/name))
 if not d['passed'] or d['source_sha256']!=source:raise RuntimeError('All numeric/schedule/integration checks must match source')
c=next(r for r in json.load(open(H/'CASES.json')) if r['index']==39)
reg=dict(iteration='I014_engineering39',time=time.time(),source_sha256=source,index=39,instance=c['instance'],capacity=c['tmax'],method='cdf_blocks',seed=9714039,seconds=600,phase_seconds=180,watchdog=640,scope='one cold engineering run, not matched performance pilot or30-run Avg; no new LSS calls',initialization='fresh own S10 then own CDF pool, retained whole before leftover-budget block phase',phase_policy='one180second shared phase and one600second total, existing12second final reserve; no reset for blocks',cdf_pool_snapshot_saved=True,no_historical_cost_target=True,no_saved_vector_or_true_model=True,no_LSS_calls=True,formal_source_unchanged=True)
with (J/'REGISTRATION.json').open('x') as f:json.dump(reg,f,indent=2)
print(json.dumps({k:v for k,v in reg.items() if k!='source_sha256'}))
