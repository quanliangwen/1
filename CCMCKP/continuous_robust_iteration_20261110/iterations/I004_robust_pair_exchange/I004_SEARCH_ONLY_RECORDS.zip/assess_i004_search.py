"""Analyze the frozen raw pools; never call native LSS or feed back to search."""
from pathlib import Path
import json,gzip,hashlib
H=Path(__file__).parent;I=H/'iterations/I004_robust_pair_exchange';reg=json.load(open(I/'REGISTRATION.json'));rows=[]
for index in reg['pilot_cases']:
 old=json.loads(gzip.decompress((H/f'iterations/I002_cdf_neighborhood/pilot/cdf_lns_{index:02d}_seed970201.json.gz').read_bytes()));oldset={tuple(c['selection']) for c in old['candidate_shortlist']}
 for method in reg['methods']:
  p=I/f'pilot/{method}_{index:02d}_seed{reg["seed"]}.json.gz';d=json.loads(gzip.decompress(p.read_bytes()));meta=json.load(open(str(p)+'.run.json'));terminal=json.load(open(str(p)+'.terminal.json'))
  if terminal['exit']!=0 or meta['source_sha256']!=reg['source_sha256'] or not meta['within_budget']:raise RuntimeError('Frozen search integrity/budget failure')
  pool=d['candidate_shortlist'];reference=reg['current_qualified_costs'][str(index)];lower=[c for c in pool if c['cost']<reference-1e-9]
  rows.append(dict(index=index,method=method,raw_min=min(c['cost'] for c in pool),current_I002_qualified_cost=reference,raw_pool=len(pool),lower_cost_candidates=len(lower),new_lower_cost_vectors_vs_I002=sum(tuple(c['selection']) not in oldset for c in lower),search_seconds=meta['elapsed'],LSS_qualification_pending=True,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
d=dict(scope='all10development searches finished; raw pools only, not LSS-qualified costs or30-runAvg; lower-cost comparison tolerance1e-9 is for objective bookkeeping only, never probability acceptance',no_native_MC_calls=True,rows=rows,conclusion='35/37/38 generated pools contain no cost improvement over current qualified I002.39/40 retain potential cheaper vectors requiring original LSS postselection; no new gain claimed before validation.')
(I/'SEARCH_ASSESSMENT.json').write_text(json.dumps(d,indent=2));print(json.dumps(d))
