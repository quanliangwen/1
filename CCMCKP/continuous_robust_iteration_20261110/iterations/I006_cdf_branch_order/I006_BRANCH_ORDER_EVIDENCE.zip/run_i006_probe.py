from pathlib import Path
import json,hashlib,subprocess,time
H=Path(__file__).parent;I=H/'iterations/I006_cdf_branch_order';J=I/'case35';J.mkdir(exist_ok=True);out=J/'probe_old_512_120.json'
if out.exists() or (J/'REGISTRATION.json').exists():raise RuntimeError('No duplicate engineering probe')
mathcheck=json.load(open(H/'I006_EXACT_BOUND_MATH_CHECK.json'));source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')}
if not mathcheck['passed'] or source!=mathcheck['source_sha256']:raise RuntimeError('Math/source check required')
c=next(c for c in json.load(open(H/'CASES.json')) if c['index']==35);ref=next(r for r in json.load(open(H/'BASELINE_S10.json'))['rows'] if r['index']==35)
reg=dict(time=time.time(),source_sha256=source,index=35,instance=c['instance'],capacity=c['tmax'],cost_limit=str(ref['old_best']),bins=512,seconds=120,watchdog=170,purpose='engineering feasibility-bound test with input-only exact CDF-ranked group permutation; not a cost improvement/30-run statistical claim',no_LSS_calls=True,only_scalar_cost_target=True,no_historical_vector=True,formal_source_unchanged=True,math_checks=mathcheck['checks'])
(J/'REGISTRATION.json').write_text(json.dumps(reg,indent=2))
cmd=['/home/junhao/miniconda3/bin/python','-u',str(I/'candidate/run_bound.py'),'--instance','/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/'+reg['instance'],'--capacity',str(reg['capacity']),'--cost-limit',reg['cost_limit'],'--bins','512','--seconds','120','--out',str(out)]
with (J/'probe.log').open('x') as f:
 start=time.monotonic();r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=170)
(J/'TERMINAL.json').write_text(json.dumps(dict(exit=r.returncode,wall=time.monotonic()-start,source_sha256=source),indent=2))
if r.returncode:raise RuntimeError('Probe failed; retained logs')
d=json.load(open(out));print(json.dumps({k:d[k] for k in ['status','group_order','visited_nodes','terminal_counts','covered_combinations','remaining_combinations','raw_cost_line_excluded','elapsed']}))
