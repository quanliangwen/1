"""Numerical exploration of input-only branch ordering; no pruning proof.

Rank a group's choices by how many optimistic chance bounds are below .99
when all other groups remain enveloped. Rankings are proposal-only.
"""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import json,pickle,time,hashlib
import numpy as np
from cdf_cost_bound import item_cdfs
H=Path(__file__).parent;rows=[];start=time.monotonic();B=512
for index in [35,37,38,39,40]:
 c=next(x for x in json.load(open(H/'CASES.json')) if x['index']==index)
 p=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/c['instance'];cost=np.loadtxt(p/'cost.txt');groups=pickle.load(open(p/'node_to_factor.pkl','rb'))
 groups=[groups[k] for k in sorted(groups,key=int)] if isinstance(groups,dict) else groups
 cdf=item_cdfs([np.loadtxt(p/f'{j}_sample.txt') for j in range(len(cost))],c['tmax'],B)
 pmfs=np.diff(np.c_[np.zeros(len(cost)),cdf],axis=1);env=[np.diff(np.r_[0.,np.max(cdf[g],axis=0)]) for g in groups]
 prefix=[np.array([1.])]
 for e in env:prefix.append(np.convolve(prefix[-1],e)[:B+1])
 suffix=[None]*(len(groups)+1);suffix[-1]=np.array([1.])
 for g in range(len(groups)-1,-1,-1):suffix[g]=np.convolve(env[g],suffix[g+1])[:B+1]
 scores=[]
 for g,group in enumerate(groups):
  other=np.convolve(prefix[g],suffix[g+1])[:B+1]
  values=[float(np.convolve(other,pmfs[j])[:B+1].sum()) for j in group]
  scores.append(dict(group=g,one_level_numerically_below99=sum(x<.99 for x in values),minimum=min(values),maximum=max(values),optimistic_probability_by_item=dict(zip(map(str,group),values))))
 order=sorted(range(len(groups)),key=lambda g:(-scores[g]['one_level_numerically_below99'],scores[g]['minimum'],g))
 row=dict(index=index,instance=c['instance'],bins=B,ranked_group_order=order,scores=scores,root_optimistic_upper=float(prefix[-1].sum()))
 rows.append(row);print(json.dumps(dict(index=index,natural_first=scores[0]['one_level_numerically_below99'],ranked_first=scores[order[0]]['one_level_numerically_below99'],first_group=order[0],top3=order[:3])),flush=True)
(H/'CDF_BRANCH_ORDER_DIAGNOSTIC.json').write_text(json.dumps(dict(scope='floating diagnostic only, no global exclusion; input-only ranking never changes feasibility predicate',rows=rows,seconds=time.monotonic()-start,source_sha256={n:hashlib.sha256((H/n).read_bytes()).hexdigest() for n in [Path(__file__).name,'cdf_cost_bound.py']}),indent=2))
