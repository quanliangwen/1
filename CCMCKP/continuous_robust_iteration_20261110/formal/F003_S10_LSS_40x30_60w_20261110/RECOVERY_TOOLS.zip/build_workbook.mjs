import fs from 'node:fs/promises';
import path from 'node:path';
import { Workbook, SpreadsheetFile } from '@oai/artifact-tool';
const input=process.argv[2],out=process.argv[3];
if(!input||!out)throw new Error('Usage: builder input-directory output-directory');
const stats=JSON.parse(await fs.readFile(path.join(input,'FINAL_STATISTICS.json'),'utf8'));
const details=JSON.parse(await fs.readFile(path.join(input,'RUN_DETAILS.json'),'utf8'));
const audit=JSON.parse(await fs.readFile(path.join(input,'FINAL_AUDIT.json'),'utf8'));
if(stats.length!==40||details.length!==1200)throw new Error('Keep all 40 cases and 1200 registered records');
const wb=Workbook.create();const s=wb.worksheets.add('统计结果'),r=wb.worksheets.add('运行明细');
for(const sh of [s,r]){sh.showGridLines=false;sh.getRange(sh===s?'A1:L46':'A1:N1206').format.font={name:'Arial',size:11,color:'#1F2937'};sh.freezePanes.freezeRows(6);sh.freezePanes.freezeColumns(3);}
s.tabColor='#1F4E78';
s.getRange('A2').values=[['S10 全40算例，每例30次']];s.getRange('A2:L2').format.font={name:'Arial',size:15,bold:true,color:'#17365D'};
s.getRange('A3').values=[[`已完成 ${audit.completed}/1200 次；并行数60；统计采用 LSS 原流程的 _0 输出。`]];
s.getRange('A4').values=[['真实概率仅记录；不作额外筛选。Std 为总体标准差，Time 为原 Running Time 的30次均值（秒）。']];
if(audit.infrastructure_interrupted_attempts)s.getRange('A5').values=[[`另保留 ${audit.infrastructure_interrupted_attempts} 次磁盘故障中断记录；均按原种子重跑，未择优替换结果。`]];
s.getRange('A6:L6').values=[['编号','算例','Tmax','Best','Avg','Std','Time (s)','完成次数','Avg−Best','最小原CL','最小真实概率','最大真实概率']];
r.getRange('A2').values=[['S10 原始运行记录']];r.getRange('A2:N2').format.font={name:'Arial',size:15,bold:true,color:'#17365D'};
r.getRange('A3').values=[['Source: 每次运行由原LSS param_test及CSV写入函数生成的 _0.csv；完整原始文件见 original_LSS_CSVs 与 CASE 归档。']];
r.getRange('A4').values=[['搜索种子960001–960030；真实概率调用沿用LSS原设置：1000万次、种子832273。']];
r.getRange('A6:N6').values=[['编号','算例','Tmax','重复次数','搜索种子','状态','Cost','原CL','真实概率','Running Time (s)','S10搜索时间 (s)','总耗时 (s)','Solution','候选数']];
const ordered=[...details].sort((a,b)=>a.case_index-b.case_index||a.rep-b.rep);
r.getRange('A7:N1206').values=ordered.map(x=>[x.case_index,x.instance,x.capacity,x.rep,x.search_seed,x.status==='completed'?'完成':x.status==='pending'?'等待':'失败',x.cost??null,x.original_LSS_confidence??null,x.recorded_real_probability??null,x.original_mainflow_search_seconds??null,x.S10_worker_search_seconds??null,x.wall_seconds_including_original_realP_reporting??null,x.selection?JSON.stringify(x.selection):'',x.S10_candidates??null]);
s.getRange('A7:C46').values=stats.map(x=>[x.index,x.instance,x.capacity]);
const formulas=[];
for(let i=0;i<40;i++){
 const row=i+7,lo=i*30+7,hi=lo+29;
 const rr=c=>`'运行明细'!${c}${lo}:${c}${hi}`;
 formulas.push([`=IF(H${row}=30,MIN(${rr('G')}),"")`,`=IF(H${row}=30,AVERAGE(${rr('G')}),"")`,`=IF(H${row}=30,STDEV.P(${rr('G')}),"")`,`=IF(H${row}=30,AVERAGE(${rr('J')}),"")`,`=COUNT(${rr('G')})`,`=IF(H${row}=30,E${row}-D${row},"")`,`=IF(H${row}=30,MIN(${rr('H')}),"")`,`=IF(H${row}=30,MIN(${rr('I')}),"")`,`=IF(H${row}=30,MAX(${rr('I')}),"")`]);
}
s.getRange('D7:L46').formulas=formulas;
for(const [sh,range] of [[s,'A6:L6'],[r,'A6:N6']])sh.getRange(range).format={fill:'#1F4E78',font:{name:'Arial',size:11,bold:true,color:'#FFFFFF'},horizontalAlignment:'center',verticalAlignment:'center',rowHeight:30};
s.getRange('A7:L46').format.rowHeight=23;r.getRange('A7:N1206').format.rowHeight=22;
for(let i=0;i<40;i++){if(i%2===0)s.getRange(`A${i+7}:L${i+7}`).format.fill='#EAF2F8';if(i>0&&stats[i].instance.slice(0,3)!==stats[i-1].instance.slice(0,3))s.getRange(`A${i+7}:L${i+7}`).format.borders={top:{style:'medium',color:'#1F4E78'}};}
s.getRange('A1:A46').format.columnWidth=7;s.getRange('B1:B46').format.columnWidth=25;s.getRange('C1:C46').format.columnWidth=9;s.getRange('D1:G46').format.columnWidth=17;s.getRange('H1:H46').format.columnWidth=11;s.getRange('I1:L46').format.columnWidth=18;
s.getRange('D7:G46').setNumberFormat('0.000000');s.getRange('I7:I46').setNumberFormat('0.000000');s.getRange('J7:L46').setNumberFormat('0.0000000');s.getRange('A7:C46').setNumberFormat('0');s.getRange('H7:H46').setNumberFormat('0');
r.getRange('A1:A1206').format.columnWidth=7;r.getRange('B1:B1206').format.columnWidth=25;r.getRange('C1:F1206').format.columnWidth=13;r.getRange('G1:L1206').format.columnWidth=19;r.getRange('M1:M1206').format.columnWidth=70;r.getRange('N1:N1206').format.columnWidth=12;
r.getRange('G7:L1206').setNumberFormat('0.000000');r.getRange('H7:I1206').setNumberFormat('0.0000000');r.getRange('M7:M1206').format.wrapText=true;
for(let i=0;i<ordered.length;i++){const length=ordered[i].selection?JSON.stringify(ordered[i].selection).length:0;if(length>65)r.getRange(`A${i+7}:N${i+7}`).format.rowHeight=Math.max(36,Math.ceil(length/65)*15);}
s.getRange('H7:H46').conditionalFormats.add('cellIs',{operator:'notEqual',formula:30,format:{fill:'#FFF2CC',font:{color:'#9C6500'}}});
s.getRange('A3:L4').format.font={name:'Arial',size:10,color:'#595959'};r.getRange('A3:N4').format.font={name:'Arial',size:10,color:'#595959'};
wb.recalculate();
const vals=s.getRange('D7:L46').values;
for(let i=0;i<40;i++){
 const x=stats[i];if(vals[i][4]!==x.completed_runs)throw new Error('Run count mismatch '+x.index);
 if(x.completed_runs===30){for(const [j,k] of [[0,'Best'],[1,'Avg'],[2,'Std'],[3,'Time']])if(typeof vals[i][j]!=='number'||!Number.isFinite(vals[i][j])||Math.abs(vals[i][j]-x[k])>1e-8*Math.max(1,Math.abs(x[k])))throw new Error(`Independent statistics mismatch ${x.index} ${k}`);}
 else if(vals[i].slice(0,4).some(v=>v!==''&&v!==null))throw new Error('Incomplete case aggregate exposed');
}
await fs.mkdir(out,{recursive:true});
const inspected=await wb.inspect({kind:'table',range:'统计结果!A6:L12',include:'values,formulas',tableMaxRows:7,tableMaxCols:12,maxChars:5000});
const errors=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:40},maxChars:3000});
if(!errors.ndjson.includes('Cell search matched 0 entries'))throw new Error('Formula error scan returned matches or an unexpected result: '+errors.ndjson);
await fs.writeFile(path.join(out,'WORKBOOK_CHECK.json'),JSON.stringify({completed:audit.completed,independent_statistics_matched:true,inspected:inspected.ndjson,errors:errors.ndjson},null,2));
for(const [sheet,range,name] of [['统计结果','A2:L18','summary_preview.png'],['运行明细','A2:J14','details_preview.png']]){const png=await wb.render({sheetName:sheet,range,scale:1.3,format:'png'});await fs.writeFile(path.join(out,name),new Uint8Array(await png.arrayBuffer()));}
const file=await SpreadsheetFile.exportXlsx(wb);await file.save(path.join(out,'S10_LSS_40cases_30runs.xlsx'));
console.log(JSON.stringify({completed:audit.completed,workbook:path.join(out,'S10_LSS_40cases_30runs.xlsx'),statisticsMatched:true}));
