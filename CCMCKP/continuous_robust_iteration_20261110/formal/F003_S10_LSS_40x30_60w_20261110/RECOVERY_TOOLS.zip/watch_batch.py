"""One-batch local monitor: fetch, verify, build final workbook, publish to GitHub."""
from pathlib import Path
import json,hashlib,subprocess,time,os,shutil,traceback,sys,datetime,tarfile,io
T=Path(__file__).resolve().parent;H=Path(r'E:\codex\CCMCKP_robust_continuous_20261110')
A=H/'artifact/formal/F003_S10_LSS_40x30_60w_20261110'
D='/home/quanliangwen/work/ccmckp_robust_continuous_20261110/formal/F003_S10_LSS_40x30_60w_20261110';HOST='quanliangwen@10.112.162.60'
NODE=Path(r'C:\Program Files\WindowsApps\OpenAI.CodexPrimaryRuntime.v26-1104-2876-0_26.1104.2876.0_x64__3k8sg7r9htsxt\dependencies\node\bin\node.exe')
def atomic(p,x):
 tmp=Path(str(p)+'.tmp');tmp.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf8');os.replace(tmp,p)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def remote_status():
 script='''from pathlib import Path
import json,os,time
D=Path(%r)
x=json.load(open(D/'PROGRESS.json'));x.pop('active_tasks',None)
x['postprocess_finished']=(D/'POSTPROCESS_FINISHED').exists()
x['postprocess_error']=json.load(open(D/'POSTPROCESS_ERROR.json')) if (D/'POSTPROCESS_ERROR.json').exists() else None
x['batch_terminal']=json.load(open(D/'BATCH_TERMINAL.json')) if (D/'BATCH_TERMINAL.json').exists() else None
recovery=json.load(open(D/'RECOVERY_LAUNCH.json')) if (D/'RECOVERY_LAUNCH.json').exists() else None
x['supervisor_alive']=Path('/proc/'+str(recovery['pid'] if recovery else 1137946)).exists()
print(json.dumps(x))
'''%D
 r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=20',HOST,'python3 -'],input=script.encode(),capture_output=True,timeout=60,check=True)
 return json.loads(r.stdout)
def mirror_completed():
 M=T/'verified_live_mirror';M.mkdir(exist_ok=True)
 knownfile=T/'MIRRORED_TRIALS.json';known=json.load(open(knownfile)) if knownfile.exists() else []
 script='D='+repr(D)+'\nknown=set('+repr(known)+')\n'+r'''
from pathlib import Path
import sys,tarfile,json
D=Path(D)
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz') as z:
 for f in sorted(D.glob('runs/*/*')):
  key=f.relative_to(D).as_posix()
  if key in known or not (f/'RESULT.json').exists():continue
  try:json.load(open(f/'RESULT.json'))
  except (ValueError,OSError):continue
  for p in sorted(f.rglob('*')):
   if p.is_file() and not p.is_symlink():z.add(p,arcname=p.relative_to(D).as_posix(),recursive=False)
'''
 r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=20',HOST,'python3 -'],input=script.encode(),capture_output=True,check=True,timeout=180)
 with tarfile.open(fileobj=io.BytesIO(r.stdout),mode='r:gz') as z:
  for member in z.getmembers():
   p=(M/member.name).resolve()
   if M.resolve() not in p.parents or not member.isfile():raise RuntimeError('Unsafe mirror member')
   p.parent.mkdir(parents=True,exist_ok=True)
   with z.extractfile(member) as source,p.open('wb') as target:shutil.copyfileobj(source,target)
 verified=[]
 for p in M.glob('runs/*/*/RESULT.json'):
  x=json.load(open(p))
  for e in x['evidence']:assert sha(M/e['path'])==e['sha256'],e['path']
  verified.append(p.parent.relative_to(M).as_posix())
 atomic(knownfile,verified);return len(verified)
def deliver():
 collected=T/'collected'
 if collected.exists():raise RuntimeError('Existing collected folder: do not overwrite an incomplete prior delivery silently')
 collected.mkdir()
 subprocess.run(['scp','-q','-r',HOST+':'+D+'/delivery',str(collected)],check=True,timeout=1800)
 C=collected/'delivery';manifest=json.load(open(C/'DELIVERY_MANIFEST.json'))
 for r in manifest['files']:
  p=C/r['path'];assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],r['path']
 audit=json.load(open(C/'FINAL_AUDIT.json'))
 assert audit['registered']==1200 and audit['completed']+audit['failed']==1200
 # Original registered driver/source snapshots stay untouched.
 for p in C.rglob('*'):
  if p.is_file():q=A/'delivery'/p.relative_to(C);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
 out=T/'outputs/f003'
 r=subprocess.run([str(NODE),str(T/'build_workbook.mjs'),str(C),str(out)],capture_output=True,text=True,encoding='utf8',check=True,timeout=600)
 (T/'FINAL_WORKBOOK_BUILD.log').write_text(r.stdout+r.stderr,encoding='utf8')
 # The same workbook layout was rendered and visually reviewed on a real partial
 # snapshot; final build rechecks all 40 formula results and renders both sheets.
 for n in ['S10_LSS_40cases_30runs.xlsx','WORKBOOK_CHECK.json']:shutil.copyfile(out/n,A/'delivery'/n)
 state=dict(state='finished' if audit['all40_have30_completed'] else 'finished_with_failed_registered_runs',updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),completed=audit['completed'],failed=audit['failed'],infrastructure_interrupted_attempts=audit.get('infrastructure_interrupted_attempts',0),workers=60,all40_have30_completed=audit['all40_have30_completed'],source_commit='fc21aa3379582bdb07ec0768531abc3e46fee2a3',extra_true_probability_filter=False,statistics='original LSS output0, all30 required for case aggregates')
 atomic(A/'BATCH_STATUS.json',state)
 # Required permanent delivery uses the task's existing GitHub publisher.
 p=subprocess.run([sys.executable,'-X','utf8',str(H/'publish.py')],capture_output=True,text=True,encoding='utf8',check=True,timeout=1800)
 (T/'FINAL_PUBLICATION.log').write_text(p.stdout+p.stderr,encoding='utf8')
 commit=next(l.strip() for l in p.stdout.splitlines() if len(l.strip())==40 and all(c in '0123456789abcdef' for c in l.strip()))
 v=subprocess.run([sys.executable,'-X','utf8',str(T/'verify_published.py'),commit],capture_output=True,text=True,encoding='utf8',check=True,timeout=1800)
 (T/'FINAL_REMOTE_VERIFY.log').write_text(v.stdout+v.stderr,encoding='utf8')
 state.update(commit=commit,remote_byte_and_SHA256_verified=True,workbook_url='https://github.com/quanliangwen/1/blob/'+commit+'/CCMCKP/continuous_robust_iteration_20261110/formal/F003_S10_LSS_40x30_60w_20261110/delivery/S10_LSS_40cases_30runs.xlsx')
 atomic(T/'MONITOR_STATE.json',state);print(json.dumps(state),flush=True)
if __name__=='__main__':
 atomic(T/'MONITOR_PID.json',dict(pid=os.getpid(),started=time.time(),single_batch=True,server=D))
 last_mirror=0
 if '--once' not in sys.argv:atomic(T/'MONITOR_STATE.json',dict(state='monitoring',started=time.time()))
 try:
  while True:
   try:
    p=remote_status();atomic(T/'LATEST_PROGRESS.json',p)
   except (subprocess.SubprocessError,OSError,ValueError) as ex:
    print(json.dumps(dict(time=time.time(),transient_monitor_error=repr(ex))),flush=True)
    if '--once' in sys.argv:raise
    time.sleep(30);continue
   print(json.dumps(p),flush=True)
   if '--once' in sys.argv:break
   if p['postprocess_error']:raise RuntimeError('Remote postprocessing failed: '+repr(p['postprocess_error']))
   if p['postprocess_finished']:deliver();break
   if not p['supervisor_alive'] and p['batch_terminal'] is None:raise RuntimeError('Supervisor exited without a batch terminal record; no replacement trials launched')
   if time.time()-last_mirror>=120:
    try:print(json.dumps(dict(verified_live_mirror_trials=mirror_completed(),time=time.time())),flush=True);last_mirror=time.time()
    except (subprocess.SubprocessError,OSError,ValueError) as ex:print(json.dumps(dict(mirror_error=repr(ex),time=time.time())),flush=True)
   time.sleep(30)
 except BaseException as ex:
  atomic(T/'MONITOR_STATE.json',dict(state='needs_attention',time=time.time(),error=repr(ex),traceback=traceback.format_exc()));raise
