"""Preserve ENOSPC attempts and spool only unfinished registered trials to RAM."""
from pathlib import Path
import os,json,hashlib,shutil,time,zipfile
D=Path(__file__).resolve().parent
R=Path('/dev/shm/ccmckp_F003_recovery_20261110')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert str(D)=='/home/quanliangwen/work/ccmckp_robust_continuous_20261110/formal/F003_S10_LSS_40x30_60w_20261110'
assert not (D/'RECOVERY_REGISTRATION.json').exists()
assert not Path('/proc/1137946').exists()
reg=json.load(open(D/'REGISTRATION.json'))
for n,h in reg['driver_sha256'].items():assert sha(D/n)==h
for n,h in reg['S10_source_sha256'].items():assert sha(D/'S10_source'/n)==h
completed=[];interrupted=[];pending=[]
for c in reg['cases']:
 for rep in range(1,31):
  F=D/'runs'/('case_%02d'%c['index'])/('rep_%02d'%rep)
  if (F/'RESULT.json').exists():
   r=json.load(open(F/'RESULT.json'));assert r['registration_sha256']==sha(D/'REGISTRATION.json')
   for e in r['evidence']:assert sha(D/e['path'])==e['sha256']
   completed.append(dict(index=c['index'],rep=rep,result_sha256=sha(F/'RESULT.json')))
  elif (F/'RUN_STARTED.json').exists():interrupted.append(dict(index=c['index'],rep=rep))
  else:pending.append(dict(index=c['index'],rep=rep))
assert len(completed)==523 and len(interrupted)==26 and len(pending)==651
R.mkdir(exist_ok=False)
record=dict(created=time.time(),cause='Original supervisor exited after root filesystem ENOSPC; immutable original log retained',original_registration_sha256=sha(D/'REGISTRATION.json'),
 completed_unchanged=completed,interrupted_attempts=interrupted,previously_unstarted=pending,workers=60,RAM_spool=str(R),
 amendment='Infrastructure recovery only. Preserve every original partial attempt. Retry all 26 unfinished ENOSPC-era identities with the SAME registered seed; take the first complete rerun regardless of cost. No choice between old partial CSV costs and new results. No new seeds, no change to S10 or original LSS decision/output. Report 26 interrupted attempts separately from the 1200 registered completed outputs.',
 search_algorithm_changed=False,acceptance_changed=False,completed_results_overwritten=False)
with (D/'RECOVERY_REGISTRATION.json').open('x') as f:json.dump(record,f,indent=2)
saved=D/'interrupted_attempts';saved.mkdir()
manifest=[]
for t in interrupted:
 F=D/'runs'/('case_%02d'%t['index'])/('rep_%02d'%t['rep']);dest=saved/F.relative_to(D/'runs')
 assert F.resolve()==F and D in F.parents and D in dest.parents and not dest.exists()
 before={p.relative_to(F).as_posix():sha(p) for p in F.rglob('*') if p.is_file()}
 dest.parent.mkdir(parents=True,exist_ok=True);os.rename(F,dest)
 assert before=={p.relative_to(dest).as_posix():sha(p) for p in dest.rglob('*') if p.is_file()}
 manifest.append(dict(index=t['index'],rep=t['rep'],path=dest.relative_to(D).as_posix(),files=before))
with (D/'INTERRUPTED_ATTEMPTS_MANIFEST.json').open('x') as f:json.dump(manifest,f,indent=2)
zpath=D/'INFRASTRUCTURE_INTERRUPTED_ATTEMPTS.zip'
with zipfile.ZipFile(zpath,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(saved.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(D).as_posix())
 z.write(D/'RECOVERY_REGISTRATION.json','RECOVERY_REGISTRATION.json');z.write(D/'INTERRUPTED_ATTEMPTS_MANIFEST.json','INTERRUPTED_ATTEMPTS_MANIFEST.json');z.write(D/'supervisor.stdout.log','original_supervisor.stdout.log')
with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
for t in interrupted+pending:
 F=D/'runs'/('case_%02d'%t['index'])/('rep_%02d'%t['rep']);ram=R/'runs'/('case_%02d'%t['index'])/('rep_%02d'%t['rep'])
 assert not F.exists() and not F.is_symlink(),str(F)
 ram.mkdir(parents=True);F.parent.mkdir(parents=True,exist_ok=True);os.symlink(str(ram),F,target_is_directory=True)
# Preserve the initial snapshot and expose RAM progress at the existing path.
os.rename(D/'PROGRESS.json',D/'ORIGINAL_PROGRESS_BEFORE_RECOVERY.json')
initial=dict(time=time.time(),started=time.time(),total_registered=1200,workers=60,completed=523,succeeded=523,failed=0,active=0,active_tasks=[],memory_available_bytes=0,disk_available_to_user_bytes=0,infrastructure_interrupted_attempts=26,recovery=True)
(R/'PROGRESS.json').write_text(json.dumps(initial));os.symlink(str(R/'PROGRESS.json'),D/'PROGRESS.json')
print(json.dumps(dict(completed_preserved=523,interrupted_preserved=26,registered_trials_to_run=677,RAM_spool=str(R),archive_bytes=zpath.stat().st_size,archive_sha256=sha(zpath))))
