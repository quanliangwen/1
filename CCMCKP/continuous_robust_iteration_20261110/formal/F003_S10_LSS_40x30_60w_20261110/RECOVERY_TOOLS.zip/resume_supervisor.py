"""60-way continuation of unchanged original worker; RAM progress and trial I/O."""
from pathlib import Path
import os,json,time,threading,subprocess,signal,concurrent.futures,fcntl,hashlib
D=Path(__file__).resolve().parent;R=Path('/dev/shm/ccmckp_F003_recovery_20261110')
def atomic(p,x):
 t=Path(str(p)+'.tmp');t.write_text(json.dumps(x,indent=2));os.replace(t,p)
def mem():return int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
def space(p):s=os.statvfs(p);return s.f_bavail*s.f_frsize
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=(R/'resume.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not (D/'RECOVERY_LAUNCH.json').exists()
reg=json.load(open(D/'REGISTRATION.json'));recovery=json.load(open(D/'RECOVERY_REGISTRATION.json'))
for n,h in reg['driver_sha256'].items():assert sha(D/n)==h
assert (D/'RECOVERY_REMOTE_VERIFIED.json').exists()
active={};done={};mutex=threading.Lock();start=time.time();stop=threading.Event()
def snapshot():
 with mutex:values=list(done.values());running=list(active.values())
 atomic(R/'PROGRESS.json',dict(time=time.time(),started=start,total_registered=1200,workers=60,completed=len(values),succeeded=sum(r['status']=='completed' for r in values),failed=sum(r['status']!='completed' for r in values),active=len(running),active_tasks=running,memory_available_bytes=mem(),disk_available_to_user_bytes=space(D),RAM_available_bytes=space(R),wall_seconds=time.time()-start,infrastructure_interrupted_attempts=26,recovery=True))
def beat():
 while not stop.wait(10):snapshot()
def run(t):
 i,rep=t;key='%02d_%02d'%(i,rep);F=D/'runs'/('case_%02d'%i)/('rep_%02d'%rep)
 if (F/'RESULT.json').exists():
  r=json.load(open(F/'RESULT.json'));assert r['registration_sha256']==sha(D/'REGISTRATION.json')
  result=dict(case_index=i,rep=rep,status='completed',cost=r['cost'],preserved_existing=True)
  with mutex:done[key]=result
  return result
 assert not (F/'RUN_STARTED.json').exists(),'Do not overwrite an attempt'
 assert F.resolve().parent.parent==R/'runs' and F.is_symlink()
 while mem()<16*1024**3 or space(R)<2*1024**3:time.sleep(5)
 with mutex:active[key]=dict(case_index=i,rep=rep,pid=None,started=time.time())
 p=None;began=time.time()
 try:
  with (F/'worker.stdout.log').open('x') as log:
   p=subprocess.Popen(['/usr/bin/python3','-u',str(D/'worker.py'),'--index',str(i),'--rep',str(rep)],cwd=D,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1'))
   with mutex:active[key]['pid']=p.pid
   try:code=p.wait(timeout=14400)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();code='outer_watchdog'
  if code==0 and (F/'RESULT.json').exists():
   r=json.load(open(F/'RESULT.json'));result=dict(case_index=i,rep=rep,status='completed',cost=r['cost'],exit=0,wall_seconds=time.time()-began)
  else:result=dict(case_index=i,rep=rep,status='failed',exit=code,wall_seconds=time.time()-began)
 finally:
  if p is not None and p.poll() is None:os.killpg(p.pid,signal.SIGKILL);p.wait()
  with mutex:active.pop(key,None)
 with mutex:done[key]=result
 atomic(F/'TERMINAL.json',result);print(json.dumps(result),flush=True);return result
atomic(D/'RECOVERY_LAUNCH.json',dict(time=start,pid=os.getpid(),workers=60,registered=1200,interrupted_attempts=26,RAM_spool=str(R)))
threading.Thread(target=beat,daemon=True).start()
tasks=[]
for rep in range(1,31):
 cases=reg['cases'];order=cases[(rep-1)%40:]+cases[:(rep-1)%40];tasks.extend((c['index'],rep) for c in order)
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=60) as pool:results=list(pool.map(run,tasks))
 atomic(R/'DISPATCH_RESULTS.json',results);snapshot()
 terminal=dict(time=time.time(),total=1200,succeeded=sum(r['status']=='completed' for r in results),failed=sum(r['status']!='completed' for r in results),workers=60,infrastructure_interrupted_attempts=26)
 atomic(R/'BATCH_TERMINAL.json',terminal)
 # The RAM terminal record remains authoritative if root is briefly unavailable.
 while True:
  try:atomic(D/'BATCH_TERMINAL.json',terminal);(D/'FINISHED').write_text('all registered recovery trials terminal\n');break
  except OSError:time.sleep(10)
finally:stop.set()
