"""Fetch and byte/SHA verify every remote blob in this batch's published folder."""
from pathlib import Path
import subprocess,json,hashlib,sys
T=Path(__file__).resolve().parent;H=Path(r'E:\codex\CCMCKP_robust_continuous_20261110');R=H/'verify.git'
commit=sys.argv[1];prefix='CCMCKP/continuous_robust_iteration_20261110/formal/F003_S10_LSS_40x30_60w_20261110';A=H/'artifact/formal/F003_S10_LSS_40x30_60w_20261110'
def g(args,**kw):return subprocess.check_output(['git','--git-dir',str(R)]+args,**kw)
g(['fetch','--filter=blob:none','--depth=1','origin',commit])
entries=[e for e in g(['ls-tree','-r','-z',commit+':'+prefix]).split(b'\0') if e];refs=[]
for e in entries:
 h,n=e.split(b'\t',1);refs.append((n.decode('utf8'),h.split()[2].decode()))
shas=list(dict.fromkeys(s for n,s in refs))
for i in range(0,len(shas),250):g(['fetch','--no-tags','--no-write-fetch-head','origin']+shas[i:i+250])
result=[]
for n,s in refs:
 remote=g(['cat-file','blob',s]);assert remote==(A/n).read_bytes(),n
 result.append(dict(path=n,bytes=len(remote),sha256=hashlib.sha256(remote).hexdigest(),git_blob=s))
assert {r['path'] for r in result}=={p.relative_to(A).as_posix() for p in A.rglob('*') if p.is_file()}
record=dict(commit=commit,prefix=prefix,verified_files=len(result),verified_bytes=sum(r['bytes'] for r in result),byte_and_SHA256_verified=True,files=result)
(T/'LAST_REMOTE_VERIFICATION.json').write_text(json.dumps(record,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in record.items() if k!='files'}))
