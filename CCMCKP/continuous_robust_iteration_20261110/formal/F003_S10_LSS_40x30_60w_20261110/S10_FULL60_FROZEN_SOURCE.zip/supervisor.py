"""60 simultaneous registered trials, including search and unchanged LSS flow."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
from pathlib import Path
import json,hashlib,time,subprocess,concurrent.futures,threading,signal,fcntl,traceback
D=Path(__file__).resolve().parent
def atomic(p,x):
 t=Path(str(p)+'.tmp');t.write_text(json.dumps(x,indent=2));os.replace(t,p)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
reg=json.load(open(D/'REGISTRATION.json'))
lock=(D/'supervisor.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
if (D/'LAUNCH.json').exists():raise RuntimeError('No automatic relaunch of registered batch')
for n,h in reg['driver_sha256'].items():
 if sha(D/n)!=h:raise RuntimeError('Frozen driver changed')
if not (D/'SOURCE_REMOTE_VERIFIED.json').exists():raise RuntimeError('Frozen source must be remotely verified before full batch')
active={};completed={};mutex=threading.Lock();stop=threading.Event();start=time.time()
def memavail():return int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
def available():
 s=os.statvfs(D);return s.f_bavail*s.f_frsize
def progress():
 with mutex:
  vals=list(completed.values());running=list(active.values())
 p=dict(time=time.time(),started=start,total_registered=1200,workers=60,completed=len(vals),succeeded=sum(r['status']=='completed' for r in vals),failed=sum(r['status']!='completed' for r in vals),active=len(running),active_tasks=running,memory_available_bytes=memavail(),disk_available_to_user_bytes=available(),wall_seconds=time.time()-start)
 atomic(D/'PROGRESS.json',p)
def heartbeat():
 while not stop.wait(10):progress()
def task(index,rep):
 key='%02d_%02d'%(index,rep);O=D/'runs'/('case_%02d'%index)/('rep_%02d'%rep)
 if (O/'RESULT.json').exists():
  r=json.load(open(O/'RESULT.json'))
  if r['registration_sha256']!=sha(D/'REGISTRATION.json'):raise RuntimeError('Existing run registration mismatch')
  result=dict(case_index=index,rep=rep,status='completed',cost=r['cost'],preflight_run_already_counted=True)
  with mutex:completed[key]=result
  return result
 if (O/'RUN_STARTED.json').exists():
  result=dict(case_index=index,rep=rep,status='failed',error='Existing registered failed/incomplete attempt; never replaced')
  with mutex:completed[key]=result
  return result
 # Capacity is 60. Admission only waits if server resources later become scarce.
 while memavail()<12*1024**3 or available()<2*1024**3:time.sleep(5)
 O.mkdir(parents=True,exist_ok=True);started=time.time();p=None
 with mutex:active[key]=dict(case_index=index,rep=rep,pid=None,started=started)
 try:
  with (O/'worker.stdout.log').open('x') as log:
   p=subprocess.Popen(['/usr/bin/python3','-u',str(D/'worker.py'),'--index',str(index),'--rep',str(rep)],cwd=D,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   with mutex:active[key]['pid']=p.pid
   try:code=p.wait(timeout=14400)
   except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGKILL);p.wait();code='outer_watchdog_14400s'
  if code==0 and (O/'RESULT.json').exists():
   r=json.load(open(O/'RESULT.json'));result=dict(case_index=index,rep=rep,status='completed',cost=r['cost'],exit=code,wall_seconds=time.time()-started)
  else:result=dict(case_index=index,rep=rep,status='failed',exit=code,wall_seconds=time.time()-started,error='See retained worker stdout/FAILED.json; original seed not replaced')
 except BaseException as ex:
  result=dict(case_index=index,rep=rep,status='failed',error=repr(ex),traceback=traceback.format_exc())
 finally:
  if p is not None and p.poll() is None:os.killpg(p.pid,signal.SIGKILL);p.wait()
  with mutex:active.pop(key,None);completed[key]=result
 atomic(O/'TERMINAL.json',result)
 print(json.dumps(result),flush=True)
 return result
atomic(D/'LAUNCH.json',dict(time=start,pid=os.getpid(),workers=60,registered_trials=1200,source_remote_verified=json.load(open(D/'SOURCE_REMOTE_VERIFIED.json'))))
threading.Thread(target=heartbeat,daemon=True).start()
tasks=[]
for rep in range(1,31):
 cases=reg['cases'];order=cases[(rep-1)%40:]+cases[:(rep-1)%40];tasks.extend((c['index'],rep) for c in order)
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=60) as pool:results=list(pool.map(lambda t:task(*t),tasks))
 atomic(D/'DISPATCH_RESULTS.json',results);progress()
 atomic(D/'BATCH_TERMINAL.json',dict(time=time.time(),total=1200,succeeded=sum(r['status']=='completed' for r in results),failed=sum(r['status']!='completed' for r in results),workers=60))
 (D/'FINISHED').write_text('all registered trials terminal; inspect failures before claiming success\n')
finally:stop.set()
