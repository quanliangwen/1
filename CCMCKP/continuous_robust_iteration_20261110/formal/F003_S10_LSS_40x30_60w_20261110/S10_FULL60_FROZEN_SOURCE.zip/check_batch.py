"""Read-only independent progress and completed-run integrity audit."""
from pathlib import Path
import json,hashlib,statistics,sys,os
D=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
reg=json.load(open(D/'REGISTRATION.json'));regsha=sha(D/'REGISTRATION.json');rows=[];errors=[];started=0;failed=[]
for case in reg['cases']:
 for rep in range(1,31):
  O=D/'runs'/('case_%02d'%case['index'])/('rep_%02d'%rep)
  started+=int((O/'RUN_STARTED.json').exists())
  if (O/'FAILED.json').exists():failed.append(json.load(open(O/'FAILED.json')))
  if not (O/'RESULT.json').exists():continue
  r=json.load(open(O/'RESULT.json'))
  assert r['registration_sha256']==regsha and r['search_seed']==960000+rep and r['case_index']==case['index']
  assert r['S10_source_sha256']==reg['S10_source_sha256'] and r['extra_real_probability_hard_filter'] is False
  if '--full' in sys.argv:
   for e in r['evidence']:
    if sha(D/e['path'])!=e['sha256']:errors.append(e['path'])
  rows.append(r)
stats=[]
for case in reg['cases']:
 rs=[r for r in rows if r['case_index']==case['index']];costs=[r['cost'] for r in rs]
 stats.append(dict(index=case['index'],instance=case['instance'],capacity=case['tmax'],completed=len(rs),Best=min(costs) if costs else None,Avg=statistics.mean(costs) if len(rs)==30 else None,Std=statistics.pstdev(costs) if len(rs)==30 else None,mean_time=statistics.mean(r['original_mainflow_search_seconds'] for r in rs) if len(rs)==30 else None))
p=json.load(open(D/'PROGRESS.json')) if (D/'PROGRESS.json').exists() else None
print(json.dumps(dict(batch=reg['batch'],registered=1200,workers=60,started=started,completed=len(rows),failed=len(failed),errors=errors,progress=p,statistics=stats),indent=2))
