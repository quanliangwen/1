"""One registered S10 search; unchanged LSS decision, output tail and CSV writers."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
from pathlib import Path
import json,hashlib,time,random,importlib,csv,contextlib,argparse,re,traceback,resource
D=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write_new(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2)

def run(index,rep):
 reg=json.load(open(D/'REGISTRATION.json'))
 if index not in range(1,41) or rep not in range(1,31):raise ValueError('Unregistered index/repetition')
 case=next(c for c in reg['cases'] if c['index']==index);seed=reg['search_seeds'][rep-1]
 O=D/'runs'/('case_%02d'%index)/('rep_%02d'%rep);O.mkdir(parents=True,exist_ok=True)
 if (O/'RUN_STARTED.json').exists():raise RuntimeError('No replacement or overwrite of registered run')
 for n,h in reg['driver_sha256'].items():
  if sha(D/n)!=h:raise RuntimeError('Frozen driver changed: '+n)
 expected=reg['S10_source_sha256']
 if {p.name:sha(p) for p in (D/'S10_source').glob('*.py')}!=expected:raise RuntimeError('S10 source identity changed')
 write_new(O/'RUN_STARTED.json',dict(time=time.time(),pid=os.getpid(),index=index,rep=rep,seed=seed,registration_sha256=sha(D/'REGISTRATION.json')))
 try:
  from reference_loader import manifest,estimator
  import numpy as np,scipy
  from s10_lss_bridge import bind
  if np.__version__!='1.24.4' or scipy.__version__!='1.10.1':raise RuntimeError('Original LSS Python numerical environment required')
  exp=importlib.import_module('src.exp_Result_Localsearch');original=importlib.import_module('src.functions.func_localsearch');factors=importlib.import_module('src.functions.func_solution_factor')
  bench=reg['benchmark_root']+'/'+case['instance'];capacity=int(case['tmax']);param=re.findall(r'\d+',case['instance']);sign=case['instance'][:3].lower()
  bindreg=dict(reg,search_seed=seed,benchmark=bench)
  state=bind(exp,original,D,D,O,capacity,bindreg)
  if state['original_output_tail_AST_sha256']!=reg['original_LSS_output_tail_AST_sha256']:raise RuntimeError('Original LSS output tail changed')
  exp.my_file.REPO_DIR=str(O);(O/'result/Localsearch').mkdir(parents=True,exist_ok=True)
  stem='LocalSearch_%s_%s_%s_%s_%s'%(sign,*param,capacity)
  names=[stem+'_'+str(i)+'.csv' for i in range(4)];record=stem+'_record.csv'
  random.seed(seed);np.random.seed(seed)
  quick=estimator.factorization_list(int(param[2]),int(param[0]),.99,10,50)
  Evaluation=estimator.advanced_exact_evaluation if int(param[2])**int(param[0])<10**7 else estimator.advanced_monte_carlo
  started=time.monotonic()
  with (O/'mainflow.log').open('x') as log,contextlib.redirect_stdout(log):
   exp.create_csv(*names,record)
   Aw,Au,Av,fi=factors.Statistic_factor(param,5,bench)
   exp.param_test(Aw,Au,Av,fi,param,capacity,.99,1000000,Evaluation,30,*names,record,832273,quick,bench,sign,rep-1)
  output_rows={}
  for i in range(3):
   with (O/'result/Localsearch'/names[i]).open() as f:rows=list(csv.DictReader(f))
   if len(rows)!=1:raise RuntimeError('Original output variant missing row '+str(i))
   output_rows[str(i)]=rows[0]
  r=output_rows['0'];q=json.loads(r['Solution']);data=state['data'];meta=state['meta']
  if tuple(q) not in {tuple(v['selection']) for v in data['candidate_shortlist']}:raise RuntimeError('Output vector not from this fresh S10 run')
  for n,h in expected.items():
   if sha(D/'S10_source'/n)!=h:raise RuntimeError('S10 changed during run')
  for f in manifest['files']:
   if sha(D/'reference'/f['path'])!=f['sha256']:raise RuntimeError('Original LSS changed during run')
  write_new(O/'ORIGINAL_LSS_DECISION_TRACE.json',state['probability_trace'])
  outputs=[O/'result/Localsearch'/n for n in names+[record]]
  result=dict(status='completed',case_index=index,instance=case['instance'],capacity=capacity,rep=rep,search_seed=seed,
   cost=float(r['Cost']),selection=q,original_LSS_confidence=float(r['Confidence Level']),recorded_real_probability=float(r['Real Confidence Level']),
   original_mainflow_search_seconds=float(r['Running Time']),S10_worker_search_seconds=meta['elapsed'],
   wall_seconds_including_original_realP_reporting=time.monotonic()-started,S10_peak_rss_kib=meta['peak_rss_kib'],
   LSS_parent_peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
   S10_source_sha256=meta['source_sha256'],S10_input_sha256=meta['input_sha256'],
   original_LSS_evaluation=Evaluation.__name__,original_LSS_output_tail_AST_sha256=state['original_output_tail_AST_sha256'],
   extra_real_probability_hard_filter=False,old_S10_real_probability_postselector_called=False,search_algorithm_replaced_by_I017=False,
   original_LSS_param_test_and_CSV_writers_unchanged=True,original_LSS_times=rep-1,
   S10_schema=data['schema'],S10_candidates=len(data['candidate_shortlist']),S10_exhaustive=data.get('exhaustive'),
   original_output_variants=output_rows,registration_sha256=sha(D/'REGISTRATION.json'),
   evidence=[dict(path=p.relative_to(D).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in outputs+[state['result_file'],Path(str(state['result_file'])+'.run.json'),O/'ORIGINAL_LSS_DECISION_TRACE.json']])
  write_new(O/'RESULT.json',result)
  print(json.dumps({k:result[k] for k in ['status','case_index','rep','cost','original_LSS_confidence','recorded_real_probability','S10_worker_search_seconds','wall_seconds_including_original_realP_reporting']}),flush=True)
 except BaseException as ex:
  if not (O/'FAILED.json').exists():write_new(O/'FAILED.json',dict(status='failed',time=time.time(),case_index=index,rep=rep,seed=seed,error=repr(ex),traceback=traceback.format_exc()))
  raise
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--index',type=int,required=True);p.add_argument('--rep',type=int,required=True);a=p.parse_args();run(a.index,a.rep)
