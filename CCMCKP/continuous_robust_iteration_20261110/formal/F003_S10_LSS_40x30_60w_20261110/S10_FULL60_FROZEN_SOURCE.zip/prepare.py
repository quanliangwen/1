"""Freeze exact S10 and original LSS sources, register all 1200 trials."""
from pathlib import Path
import json,hashlib,shutil,os,zipfile,datetime,ast
D=Path(__file__).resolve().parent;H=D.parents[1];W=H.parent;old=W/'cdf_lss_S10_20261109'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
if (D/'REGISTRATION.json').exists():raise RuntimeError('Already registered; no overwrite')
expected=json.load(open(H/'BASELINE_S10.json'))['source_sha256']
source=old/'frozen_candidate'
assert len(expected)==12 and {p.name:sha(p) for p in source.glob('*.py')}==expected
S=D/'S10_source';S.mkdir()
for p in source.glob('*.py'):shutil.copy2(p,S/p.name)
os.symlink(str(old/'vendor313'),D/'vendor313',target_is_directory=True)
for n in ['s10_lss_bridge.py','reference_loader.py','REFERENCE_SHA256.json','CASES.json']:
 shutil.copy2(H/n,D/n)
reference=json.load(open(H/'REFERENCE_SHA256.json'))
for item in reference['files']:
 p=H/'reference'/item['path'];assert sha(p)==item['sha256'];q=D/'reference'/item['path'];q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
tree=ast.parse((D/'reference/src/functions/func_localsearch.py').read_text())
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='Local_Search_DD')
i=next(i for i,n in enumerate(fn.body) if isinstance(n,ast.Assign) and isinstance(n.value,ast.Call) and getattr(n.value.func,'id','')=='UpdateFeasibleSolutionList')
tail=hashlib.sha256(ast.dump(ast.Module(body=fn.body[i:],type_ignores=[]),include_attributes=False).encode()).hexdigest()
assert tail=='00a03fc080f643b052d8b4bfda19cab87a3f8e82c323a937148e48395d3357ed'
cases=json.load(open(D/'CASES.json'));assert len(cases)==40 and [c['index'] for c in cases]==list(range(1,41))
drivers=['worker.py','supervisor.py','check_batch.py','prepare.py','s10_lss_bridge.py','reference_loader.py']
reg=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),batch='F003_S10_LSS_40x30_60w_20261110',root=str(D),
 cases=cases,repetitions=list(range(1,31)),search_seeds=list(range(960001,960031)),registered_trials=1200,concurrent_trials=60,
 search_seconds=600,search_watchdog_seconds=640,outer_trial_watchdog_seconds=14400,BLAS_threads=1,
 S10_original_frozen_directory=str(source),S10_source_sha256=expected,driver_sha256={n:sha(D/n) for n in drivers},
 original_LSS_sources=reference,original_LSS_output_tail_AST_sha256=tail,
 benchmark_root='/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark',
 search_algorithm='Original S10 byte-identical 12 files; original old formal campaign seeds; no I002/I016/I017 search substitution',
 acceptance='Original unchanged LSS Solution_Evaluation and Local_Search_DD output tail, CL=.99; original param_test and CSV writers',
 original_LSS_MC_samples=1000000,original_LSS_maxiter_parameter=30,original_LSS_lambda=5,
 true_probability='Original real_P_test 10,000,000 draws/seed832273; recorded only, no additional acceptance cutoff',
 extra_true_probability_hard_filter=False,old_validate_portfolio_not_called=True,
 outputs='Original variants0/1/2; main reported statistics from original _0 minimum-cost output; original top10/trace only rep1 (times==0)',
 failure_policy='Keep every registered repetition including failures/timeouts; no replacement seeds, no successful-subset 30-run averages',
 statistics='Best=min30, Avg=mean30, Std=population std ddof0, Time=mean original Running Time; retain per-run original real probability',
 preflight='First run cases21/22 rep1 belongs to the 1200, must output9.034717/7.250013 before full dispatch',
 independent_search='Every registered trial executes fresh original S10 search, no historical candidate/solution cache input')
(D/'REGISTRATION.json').write_text(json.dumps(reg,indent=2))
inputs={}
root=Path(reg['benchmark_root'])
for name in sorted({c['instance'] for c in cases}):
 B=root/name;files=[B/'cost.txt',B/'node_to_factor.pkl']+[p for p in B.glob('*_sample.txt') if not p.name.endswith('_big_sample.txt')]+list(B.glob('*_dist.txt'))
 assert (B/'cost.txt').is_file() and (B/'node_to_factor.pkl').is_file()
 inputs[name]={p.name:sha(p) for p in files}
(D/'BENCHMARK_MANIFEST.json').write_text(json.dumps(inputs,indent=2))
files=[D/n for n in drivers+['REGISTRATION.json','BENCHMARK_MANIFEST.json','REFERENCE_SHA256.json','CASES.json']]+list(S.glob('*.py'))+[D/'reference'/r['path'] for r in reference['files']]
out=D/'S10_FULL60_FROZEN_SOURCE.zip'
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,p.relative_to(D).as_posix())
with zipfile.ZipFile(out) as z:assert z.testzip() is None
manifest=dict(source_zip=out.name,bytes=out.stat().st_size,sha256=sha(out),original_S10_source_files=12,original_LSS_source_files=len(reference['files']),source_files=[dict(path=p.relative_to(D).as_posix(),sha256=sha(p),bytes=p.stat().st_size) for p in files])
(D/'SOURCE_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(dict(batch=reg['batch'],trials=1200,workers=60,source_zip_bytes=out.stat().st_size,source_zip_sha256=sha(out),benchmark_manifest_sha256=sha(D/'BENCHMARK_MANIFEST.json'))))
