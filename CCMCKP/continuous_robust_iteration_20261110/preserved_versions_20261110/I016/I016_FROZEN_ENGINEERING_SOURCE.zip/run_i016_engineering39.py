from pathlib import Path
import json,hashlib,subprocess,time
H=Path(__file__).resolve().parent;I=H/'iterations/I016_cdf_pair_cover';J=I/'engineering39';reg=json.load(open(J/'REGISTRATION.json'));out=J/'result.json.gz'
if out.exists() or (J/'engineering.log').exists() or (J/'TERMINAL.json').exists():raise RuntimeError('Do not repeat registered engineering run; inspect actual process/results')
source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')}
if source!=reg['source_sha256']:raise RuntimeError('Registered source changed')
for name in ['MATH_CHECK.json','CDF_MATH_CHECK.json','PAIR_MATH_CHECK.json','PAIR_COVER_SCHEDULE_CHECK.json','PAIR_COVER_INTEGRATION_CHECK.json','PRECISION_SCHEDULE_CHECK.json','PRECISION_INTEGRATION_CHECK.json']:
 d=json.load(open(I/name))
 if not d['passed'] or d['source_sha256']!=source:raise RuntimeError('Source/check drift')
cmd=['/home/junhao/miniconda3/bin/python','-u',str(I/'candidate/run.py'),'--instance','/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/'+reg['instance'],'--capacity',str(reg['capacity']),'--risk-method',reg['method'],'--seed',str(reg['seed']),'--seconds',str(reg['seconds']),'--phase-seconds',str(reg['phase_seconds']),'--out',str(out)]
start=time.monotonic()
with (J/'engineering.log').open('x') as log:
 try:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=reg['watchdog']);code=r.returncode
 except subprocess.TimeoutExpired:code='watchdog_timeout'
with (J/'TERMINAL.json').open('x') as f:json.dump(dict(exit=code,wall=time.monotonic()-start,source_sha256=source),f,indent=2)
if code!=0:raise RuntimeError('Engineering failed; source/log/terminal retained')
meta=json.load(open(str(out)+'.run.json'));print(json.dumps(dict(exit=code,seconds=meta['elapsed'],within_budget=meta['within_budget'],source_matches=meta['source_sha256']==source)))
