"""Production scheduler controlled-clock evidence, not probability evidence."""
from pathlib import Path
import sys,json,hashlib
H=Path(__file__).resolve().parent;I=H/'iterations/I016_cdf_pair_cover';sys.path[:0]=[str(I/'candidate'),str(I/'vendor313')]
import pair_cover_schedule as h
class Clock:
 def __init__(self,now):self.now=float(now)
 def monotonic(self):return self.now
def row(j):return dict(selection=[j],cost=10.-j,certificate=dict(lower=.991+j*.001))
def execute(durations=(35,100,20),seconds=180,now=0,start=0,deadline=600,empty=False,bad=None,init_time=0):
 clock=Clock(now);h.time=clock;events=[];s=type('Solver',(),{})();s.deadline=deadline;s.pool={} if empty else {(0,):row(0)}
 def cls(k):
  class Model:
   def __init__(self,solver,budget):
    self.s=solver;self.end=clock.now+budget;events.append(dict(kind='init',stage=k,budget=budget,at=clock.now));clock.now+=init_time
   def run(self):
    events.append(dict(kind='run',stage=k,end=self.end));clock.now+=min(durations[k],max(0,self.end-clock.now));self.s.pool[(k+1,)]=row(k+1)
    if k:self.s.pool[(k,)]['certificate']['lower']=.99999
    if bad==k:self.s.pool.pop((k,),None)
   def summary(self):return dict(final_pool=len(self.s.pool))
  return Model
 h.PortfolioLNS=cls(0);h.RobustPairs=cls(1);h.RobustBlocks=cls(2)
 return h.run_pair_cover(s,seconds,phase_started=start),s,events
checks=[]
r,s,e=execute();assert [x['stage'] for x in e if x['kind']=='run']==[0,1,2] and [x['budget'] for x in e if x['kind']=='init']==[180,145,45] and r['phase_seconds_used']==155 and set(s.pool)=={(0,),(1,),(2,),(3,)};checks.append('CDF/pair/block order with shared remaining180/145/45; all own stages retained')
assert next(x for x in r['cdf_pool_records'] if x['selection']==[1])['certificate']['lower']<.99999 and next(x for x in r['pair_pool_records'] if x['selection']==[2])['certificate']['lower']<.99999;checks.append('CDF and pair evidence deep copies survive later mutation')
r,s,e=execute(durations=(35,150,100));assert r['pairs_executed'] and not r['blocks_executed'] and r['phase_seconds_used']==180;checks.append('pair exhaustion skips blocks without phase reset')
r,s,e=execute(durations=(180,1,1));assert not r['pairs_executed'] and not r['blocks_executed'];checks.append('CDF exhaustion stops next stages')
r,s,e=execute(now=20);assert e[0]['budget']==160 and r['phase_seconds_used']<=180;checks.append('phase overhead included')
r,s,e=execute(deadline=65);assert r['pairs_executed'] and not r['blocks_executed'] and r['phase_seconds_used']==53;checks.append('global deadline with12-second reserve clamps every model')
r,s,e=execute(init_time=7);assert all(x['end']<=180 for x in e if x['kind']=='run') and r['phase_seconds_used']<=180;checks.append('constructor setup charged inside same deadline')
for kwargs in [dict(empty=True),dict(seconds=0),dict(deadline=5)]:
 r,s,e=execute(**kwargs);assert not e and not r['cdf_executed'];checks.append('empty/expired skip '+str(kwargs))
for k in [0,1,2]:
 try:execute(bad=k)
 except ArithmeticError:checks.append('retention violation detected stage'+str(k))
 else:raise AssertionError('Removal silently accepted')
for x in [-1,float('nan'),float('inf')]:
 try:execute(seconds=x)
 except ValueError:checks.append('invalid budget rejected '+str(x))
 else:raise AssertionError('Invalid budget accepted')
result=dict(passed=True,checks=len(checks),records=checks,scope=__doc__,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')})
with (I/'PAIR_COVER_SCHEDULE_CHECK.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'}))
