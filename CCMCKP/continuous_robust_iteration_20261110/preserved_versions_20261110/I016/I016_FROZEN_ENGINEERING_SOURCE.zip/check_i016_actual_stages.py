"""Actual CDF/scipyMILP, pair, block and ExactOracle integration, six groups."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,time,json,hashlib
import numpy as np
H=Path(__file__).resolve().parent;I=H/'iterations/I016_cdf_pair_cover';sys.path[:0]=[str(I/'candidate'),str(I/'vendor313')]
from pair_cover_schedule import run_pair_cover
from exact_oracle import ExactOracle
J=I/'actual_pair_cover_toy';J.mkdir(exist_ok=True)
for j in range(12):
 with (J/(str(j)+'_sample.txt')).open('x') as f:f.write('0\n0\n')
class Input:
 path=J;n=12;m=6;samples=[np.zeros(2) for _ in range(12)]
 def validate_selection(self,q):
  if len(q)!=6 or any(j not in [g,g+6] for g,j in enumerate(q)):raise ValueError('Invalid canonical toy')
  return list(q)
class Solver:
 def __init__(self):
  self.inst=Input();self.oracle=ExactOracle(self.inst,1.,'.99');self.groups=[np.array([g,g+6]) for g in range(6)];self.cost=np.r_[np.ones(6),np.full(6,2.)];self.T=1.;self.seed=1016;self.deadline=time.monotonic()+120;self.pool={};self.decisions={};self.models=0;self.model_seconds=0.;self.native_check(tuple(range(6,12)),'initial',True)
 def remaining(self):return self.deadline-time.monotonic()
 def cost_of(self,q):return float(self.cost[list(q)].sum())
 def native_check(self,q,source,force):
  q=tuple(q);self.inst.validate_selection(q);c=self.oracle.certify(q,1024,True)
  if not c['accepted'] or c['lower_numerator']!='64' or c['denominator']!='64':raise AssertionError('Real integer count differs from enumerated all64zero combinations')
  self.pool[q]=dict(selection=list(q),cost=self.cost_of(q),certificate=c);self.decisions[q]=c;return c['lower']
s=Solver();initial=set(s.pool);start=time.monotonic();r=run_pair_cover(s,60,phase_started=start);cdf={tuple(x['selection']) for x in r['cdf_pool_records']};pair={tuple(x['selection']) for x in r['pair_pool_records']}
assert r['cdf_executed'] and r['pairs_executed'] and r['blocks_executed'] and s.models>0 and initial<=cdf<=pair<=set(s.pool) and r['phase_seconds_used']<=60
pairrows=[x for x in r['robust_pairs']['records'] if x['kind']=='joint_pair_neighborhood']
assert pairrows and all(x['pairs_checked']==15 and x['complete_pair_scan'] for x in pairrows) and any(x['kind']=='robust_block_mitm' for x in r['robust_blocks']['records'])
assert r['robust_pairs']['initial_certified']==len(cdf) and r['robust_blocks']['initial_certified']==len(pair)
result=dict(passed=True,scope=__doc__+'; all64 original zero outcomes exactly checked per accepted member; not production performance/LSS probability',source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (I/'candidate').glob('*.py')},initial_pool=len(initial),cdf_pool=len(cdf),pair_pool=len(pair),final_pool=len(s.pool),actual_MIP_calls=s.models,complete_pair_scans=len(pairrows),cdf_seconds=r['cdf_seconds'],pair_seconds=r['pair_seconds'],block_seconds=r['block_seconds'],shared_phase_seconds=r['phase_seconds_used'],all_accepted_original_integer_counts_64of64=True)
with (I/'PAIR_COVER_INTEGRATION_CHECK.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'}))
