from pathlib import Path
import json,time,subprocess
from isolated_original_lss import sha
H=Path(__file__).resolve().parent;S=H/'breadth/I016_priority_four';reg=json.load(open(S/'REGISTRATION.json'));v=json.load(open(S/'PRE_REG_REMOTE_VERIFIED.json'))
if any((S/n).exists() for n in ['LAUNCH.json','study.log','SEARCH_FINISHED','SEARCH_RESULT.json']):raise RuntimeError('Breadth study may already run; inspect actual state')
if not v['independent_remote_verification'] or v['registration_sha256']!=sha(S/'REGISTRATION.json') or sha(H/'run_i016_priority_breadth.py')!=reg['runner_sha256']:raise RuntimeError('Actual remote source/registration verification required')
for label,info in reg['sources'].items():
 if {p.name:sha(p) for p in (H/info['candidate']).glob('*.py')}!=info['source_sha256']:raise RuntimeError('Frozen source changed')
for c in reg['cases']:
 for n,d in c['input_sha256'].items():
  if sha(Path(c['benchmark'])/n)!=d:raise RuntimeError('Original breadth inputs changed')
with (S/'study.log').open('x') as log:p=subprocess.Popen(['python3','-u',str(H/'run_i016_priority_breadth.py')],cwd=H,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
row=dict(time=time.time(),pid=p.pid,pre_registered_commit=v['commit'],registration_sha256=sha(S/'REGISTRATION.json'),required_searches=8,workers=2,scope=reg['scope'])
with (S/'LAUNCH.json').open('x') as f:json.dump(row,f,indent=2)
print(json.dumps(row))
