"""Four remaining priority cases, one NEW paired seed each, frozen parent/new."""
from pathlib import Path
import json,time,os
from isolated_original_lss import sha
H=Path(__file__).resolve().parent;S=H/'breadth/I016_priority_four';D=H/'research/D004_I016_full_prefix'
if (S/'REGISTRATION.json').exists():raise RuntimeError('Breadth study already registered')
proof=json.load(open(D/'INDEPENDENT_FINAL_AUDIT.json'))
if not proof['passed'] or proof['result_sha256']!=sha(D/'RESULT.json') or proof['pools']['I016']['original_native_point']<.985:raise RuntimeError('Actual I016 complete cold qualified prefix required')
sources={}
for label,iteration,method in [('I015_parent','I015_precision_closure','cdf_blocks_precision'),('I016_pair_cover','I016_cdf_pair_cover','cdf_pair_cover')]:
 I=H/'iterations'/iteration;root=I/'candidate';source={p.name:sha(p) for p in root.glob('*.py')};e=json.load(open(I/'engineering39/REGISTRATION.json'))
 if source!=e['source_sha256']:raise RuntimeError('Frozen parent/new source changed')
 for n,digest in e['checks_sha256'].items():
  check=json.load(open(I/n))
  if sha(I/n)!=digest or not check['passed'] or check['source_sha256']!=source:raise RuntimeError('Checked source identity differs')
 sources[label]=dict(candidate=root.relative_to(H).as_posix(),method=method,source_sha256=source)
indices=[35,37,38,40];seeds=[9716400+i for i in indices];used=set();inspected=0
for folder in ['iterations','stability','formal','research','breadth']:
 for file in (H/folder).rglob('REGISTRATION.json'):
  r=json.load(open(file));used.update(r.get('seeds',[]))
  if isinstance(r.get('seed'),int):used.add(r['seed'])
  inspected+=1
for folder in ['iterations','stability','formal','breadth']:
 for file in (H/folder).rglob('*.run.json'):
  r=json.load(open(file))
  if isinstance(r.get('seed'),int):used.add(r['seed'])
  inspected+=1
if set(seeds)&used:raise RuntimeError('Breadth search seeds already registered or used')
casebook={r['index']:r for r in json.load(open(H/'CASES.json'))};rawref=json.load(open(H/'RAW_REFERENCE.json'));cases=[]
for i,seed in zip(indices,seeds):
 c=casebook[i];P=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/c['instance'];inputs={}
 for file in [P/'cost.txt',P/'node_to_factor.pkl']+[p for p in P.glob('*_sample.txt') if not p.name.endswith('_big_sample.txt')]:
  if sha(file)!=rawref[str(file)]:raise RuntimeError('Original raw input changed')
  inputs[file.name]=sha(file)
 cases.append(dict(index=i,seed=seed,instance=c['instance'],capacity=c['tmax'],benchmark=str(P),input_sha256=inputs,pair_launch_order=list(sources) if i%2 else list(reversed(sources))))
mem={line.split(':')[0]:int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')};resources=dict(time=time.time(),available_cpus=len(os.sched_getaffinity(0)),available_memory_kib=mem['MemAvailable'])
if resources['available_cpus']<4 or resources['available_memory_kib']<24*1024*1024:raise RuntimeError('Insufficient resources for two extra breadth workers alongside paired stability')
active=H/'stability/I016_pair_cover_case39';launch=json.load(open(active/'LAUNCH.json'));pidfile=Path('/proc')/str(launch['pid'])/'cmdline';paired_live=pidfile.exists() and b'run_i016_pair_stability39.py' in pidfile.read_bytes()
S.mkdir(parents=True,exist_ok=True);reg=dict(time=time.time(),cases=cases,seeds=seeds,sources=sources,required_searches=8,workers=2,seconds=600,phase_seconds=180,watchdog=640,runner_sha256=sha(H/'run_i016_priority_breadth.py'),resources=resources,concurrent_stability_observation=dict(pid=launch['pid'],confirmed_live=paired_live),resource_policy='only2breadthworkers plus2registered stability workers, at most4own large cold searches; all numeric threads1; other original registered queues may continue on shared host',fresh_seed_inventory_records_checked=inspected,prior_joint_gain_audit_sha256=sha(D/'INDEPENDENT_FINAL_AUDIT.json'),pair_policy='one new matched seed per case, source variants submitted together; whole pair terminal before nextcase, predetermined case order35/37/38/40; every failure/timeout retained/no replacement',initialization='fresh own original raw sample search; no reference costs/old vectors/true distribution/cache into optimizer',native_policy='all8searches frozen and full independent all-source/raw audit before separately registering private original-LSS complete cost prefixes',acceptance='all original strictsum<T integer lower>=.99 and full unchanged original LSS real_P_test10m/832273/sum<=Tpoint>=.985',scope='development breadth: FOUR distinct cases, one paired seed each; per-case costs only; no cross-case costAvg, no per-case3or30Avg, not replacement for all40x30',no_native_MC_during_this_controller=True)
with (S/'REGISTRATION.json').open('x') as f:json.dump(reg,f,indent=2)
print(json.dumps(dict(registration_sha256=sha(S/'REGISTRATION.json'),cases=[{k:r[k] for k in ['index','instance','capacity','seed']} for r in cases],required_searches=8,original_input_observations=sum(len(c['input_sha256']) for c in cases),fresh_seed_inventory_records_checked=inspected,resources=resources)))
