"""Four cases x frozen two methods, independent cold pairs, no native calls."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,time,os,gzip,subprocess
from isolated_original_lss import sha
H=Path(__file__).resolve().parent;S=H/'breadth/I016_priority_four';reg=json.load(open(S/'REGISTRATION.json'));P=S/'search';P.mkdir(exist_ok=True)
if (S/'SEARCH_FINISHED').exists() or any(P.iterdir()):raise RuntimeError('Study may already run; do not repeat')
def identities():
 if sha(H/'run_i016_priority_breadth.py')!=reg['runner_sha256']:raise RuntimeError('Registered breadth controller changed')
 for label,info in reg['sources'].items():
  if {p.name:sha(p) for p in (H/info['candidate']).glob('*.py')}!=info['source_sha256']:raise RuntimeError('Frozen '+label+' source changed')
def run_one(label,c):
 identities();info=reg['sources'][label];seed=c['seed'];base=P/(label+'_case'+str(c['index'])+'_seed'+str(seed));out=Path(str(base)+'.json.gz');start=time.monotonic();error=None;code=None;pid=None
 command=['/home/junhao/miniconda3/bin/python','-u',str(H/info['candidate']/'run.py'),'--instance',c['benchmark'],'--capacity',str(c['capacity']),'--risk-method',info['method'],'--seed',str(seed),'--seconds','600','--phase-seconds','180','--out',str(out)]
 try:
  for n,digest in c['input_sha256'].items():
   if sha(Path(c['benchmark'])/n)!=digest:raise RuntimeError('Original case raw input changed')
  with Path(str(base)+'.log').open('x') as log:
   process=subprocess.Popen(command,cwd=H,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT);pid=process.pid
   with Path(str(base)+'.started.json').open('x') as f:json.dump(dict(pid=pid,label=label,index=c['index'],seed=seed,time=time.time(),command=command),f,indent=2)
   try:code=process.wait(timeout=reg['watchdog'])
   except subprocess.TimeoutExpired:process.kill();process.wait();code='watchdog_timeout'
 except Exception as ex:error=str(ex);code='setup_error'
 row=dict(label=label,index=c['index'],seed=seed,pid=pid,exit=code,error=error,actual_wall=time.monotonic()-start,output=out.relative_to(H).as_posix(),registration_sha256=sha(S/'REGISTRATION.json'))
 if code==0:
  try:
   meta=json.load(open(str(out)+'.run.json'));data=json.loads(gzip.decompress(out.read_bytes()))
   if meta['source_sha256']!=info['source_sha256'] or meta['input_sha256']!=c['input_sha256'] or meta['seed']!=seed or data['seed']!=seed or data['instance']!=c['instance'] or data['capacity']!=c['capacity'] or data['status']!='completed':raise RuntimeError('Actual breadth cold output identity differs')
   row.update(elapsed=meta['elapsed'],within_budget=meta['within_budget'],raw_candidates=len(data['candidate_shortlist']),extension_seconds=data['extension']['extension_seconds'],phase_within_budget=data['extension']['extension_seconds']<=180)
  except Exception as ex:row['error']=str(ex)
 with Path(str(base)+'.terminal.json').open('x') as f:json.dump(row,f,indent=2)
 return row
identities();start=time.monotonic();rows=[]
with ThreadPoolExecutor(max_workers=2) as executor:
 for c in reg['cases']:
  identities();(S/'STATE.json').write_text(json.dumps(dict(stage='paired_breadth_cold_search',index=c['index'],seed=c['seed'],time=time.time())));futures=[executor.submit(run_one,label,c) for label in c['pair_launch_order']]
  for future in as_completed(futures):
   row=future.result();rows.append(row);(S/'SEARCH_PROGRESS.json').write_text(json.dumps(dict(finished=len(rows),required=8,rows=rows,actual_wall=time.monotonic()-start,scope='search outcomes only, no original-native qualification/percaseAvg'),indent=2));print(json.dumps(row),flush=True)
result=dict(rows=rows,required=8,actual_wall=time.monotonic()-start,errors=[r for r in rows if r['exit']!=0 or r['error'] or not r.get('within_budget') or not r.get('phase_within_budget')],scope='all8registered breadth cold attempts; one paired seed per case, native qualification still required, no per-caseAvg')
with (S/'SEARCH_RESULT.json').open('x') as f:json.dump(result,f,indent=2)
(S/'SEARCH_FINISHED').write_text('all8actual search attempts terminal; retain errors before validation\n');(S/'STATE.json').write_text(json.dumps(dict(stage='search_attempts_finished',time=time.time(),errors=len(result['errors']))));print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
