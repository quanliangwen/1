"""Measure cheaper-grid recovery costs for posthoc diagnostic points, no search."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,time
from raw_grid_bounds import grid_count
H=Path(__file__).parent;D=H/'research/raw_precision';out=D/'GRID_COST_DIAGNOSTIC.json';registration=D/'GRID_COST_REGISTRATION.json';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if out.exists() or registration.exists():raise RuntimeError('Inspect registered diagnostic instead of rerun')
p=json.load(open(D/'REFINEMENT_PROBE.json'));math=json.load(open(H/'RAW_GRID_BOUNDS_MATH_CHECK.json'));ref=json.load(open(H/'RAW_REFERENCE.json'))
if not math['passed'] or math['source_sha256']!=sha(H/'raw_grid_bounds.py'):raise RuntimeError('Checked bounds source required')
reg=dict(scope='posthoc raw computation-cost diagnosis on four previously refined points, no solver/native/Avg claim',time=time.time(),probe_sha256=sha(D/'REFINEMENT_PROBE.json'),source_sha256={n:sha(H/n) for n in ['diagnose_refined_grid_cost.py','raw_grid_bounds.py']},bins=[65536,262144,1048576],seconds=180)
with registration.open('x') as f:json.dump(reg,f,indent=2)
start=time.monotonic();rows=[]
for r in p['rows']:
 if r['decision']!='raw_certified':continue
 P=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/r['instance'];a=[]
 for j in r['selection']:
  file=P/(str(j)+'_sample.txt')
  if sha(file)!=ref[str(file)]:raise RuntimeError('Original sample changed')
  a.append([F(s) for s in file.read_text().split()])
 bounds=[]
 for bins in reg['bins']:
  if time.monotonic()-start>160:break
  tick=time.monotonic();n,d=grid_count(a,r['capacity'],bins,True);bounds.append(dict(bins=bins,lower_numerator=str(n),denominator=str(d),lower=float(F(n,d)),raw99_certified=100*n>=99*d,seconds=time.monotonic()-tick))
 row=dict(index=r['index'],cost=r['cost'],selection=r['selection'],bounds=bounds,minimum_tested_sufficient_bins=min((c['bins'] for c in bounds if c['raw99_certified']),default=None));rows.append(row)
 print(json.dumps({k:v for k,v in row.items() if k!='selection'}),flush=True)
result=dict(scope=reg['scope'],registration_sha256=sha(registration),rows=rows,completed_grid_counts=sum(len(r['bounds']) for r in rows),required_grid_counts=12,new_MC_calls=0,seconds=time.monotonic()-start)
with out.open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
