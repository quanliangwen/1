"""Original native evaluator/cache only, source/data/role checked on every use."""
from pathlib import Path
import json,hashlib,subprocess,fcntl
class OriginalNative:
 def __init__(self,H):
  self.H=Path(H);self.C=self.H/'lss_cache';self.reference=json.load(open(self.H/'REFERENCE_SHA256.json'));self.dist=json.load(open(self.H/'LSS_DATA_REFERENCE.json'))['dataset_sha256'];self.checked=set()
  for r in self.reference['files']:
   if self.sha(self.H/'reference'/r['path'])!=r['sha256']:raise RuntimeError('Original LSS source changed')
 def sha(self,p):return hashlib.sha256(p.read_bytes()).hexdigest()
 def evaluate(self,instance,capacity,selection):
  identity=dict(instance=instance,capacity=float(capacity),selection=list(selection),seed=832273,draws=10000000,event='sum<=T');key=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest();out=self.C/(key+'.json');new=False;P=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/instance
  with (self.C/(key+'.lock')).open('a') as lock:
   fcntl.flock(lock,fcntl.LOCK_EX)
   if not out.exists():
    with (self.C/(key+'.log')).open('x') as log:r=subprocess.run(['python3',str(self.H/'native_lss_eval.py'),'--instance',str(P),'--capacity',str(capacity),'--selection',json.dumps(list(selection)),'--out',str(out)],stdout=log,stderr=subprocess.STDOUT,timeout=2400)
    if r.returncode:raise RuntimeError('Original native call failed '+key)
    new=True
   v=json.load(open(out))
   if any(v[k]!=x for k,x in identity.items()) or v['source_sha256']!=self.reference['files'] or v['reference_zip_sha256']!=self.reference['zip_sha256'] or v['numpy']!='1.24.4' or v['scipy']!='1.10.1' or v['passed']!=(v['real_probability']>=.985) or v['search_feedback'] or not all(v[k] for k in ['original_full_module','original_sources_unmodified','aliases_only']):raise RuntimeError('Original native identity/source/role differs')
   if set(v['distribution_sha256'])!={f'{j}_dist.txt' for j in selection}:raise RuntimeError('Incomplete original native dataset')
   for name,digest in v['distribution_sha256'].items():
    if (instance,name,digest) not in self.checked:
     if self.dist[instance+'/'+name]!=digest or self.sha(P/name)!=digest:raise RuntimeError('Original native distribution changed')
     self.checked.add((instance,name,digest))
  return key,v,new
