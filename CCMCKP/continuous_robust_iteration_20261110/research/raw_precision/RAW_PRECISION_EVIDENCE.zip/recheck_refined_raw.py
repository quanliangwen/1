"""Second implementation recount for four external high-grid diagnostic points."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time,pickle
from independent_raw_recount import upward_grid_count
H=Path(__file__).parent;D=H/'research/raw_precision';out=D/'INDEPENDENT_REFINED_RAW_RECHECK.json'
if out.exists():raise RuntimeError('No independent evidence overwrite')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
math=json.load(open(H/'INDEPENDENT_RAW_RECOUNT_MATH_CHECK.json'))
if not math['passed'] or sha(H/'independent_raw_recount.py')!=math['source_sha256']:raise RuntimeError('Independent verifier not the checked source')
p=json.load(open(D/'REFINEMENT_PROBE.json'));ref=json.load(open(H/'RAW_REFERENCE.json'));rows=[];start=time.monotonic()
for r in p['rows']:
 if r['decision']!='raw_certified':continue
 P=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/r['instance'];q=r['selection'];inputs={}
 for name in ['cost.txt','node_to_factor.pkl']+[str(j)+'_sample.txt' for j in q]:
  f=P/name;v=sha(f)
  if ref[str(f)]!=v:raise RuntimeError('Original raw input changed')
  inputs[name]=v
 groups=pickle.load(open(P/'node_to_factor.pkl','rb'));groups=[groups[k] for k in sorted(groups,key=int)] if isinstance(groups,dict) else groups
 if len(q)!=len(groups) or any(j not in groups[g] for g,j in enumerate(q)):raise RuntimeError('Noncanonical diagnostic selection')
 costs=[F(s) for s in (P/'cost.txt').read_text().split()]
 if abs(float(sum((costs[j] for j in q),F(0)))-r['cost'])>1e-9:raise RuntimeError('Diagnostic cost mismatch')
 a=[[F(s) for s in (P/(str(j)+'_sample.txt')).read_text().split()] for j in q];c=r['intervals'][-1];tick=time.monotonic();n,d=upward_grid_count(a,F(str(r['capacity'])),c['bins'])
 if str(n)!=c['lower_numerator'] or str(d)!=c['denominator'] or 100*n<99*d:raise RuntimeError('Second implementation raw99 recount disagreed')
 rows.append(dict(index=r['index'],cost=r['cost'],selection=q,bins=c['bins'],lower_numerator=str(n),denominator=str(d),lower=float(F(n,d)),input_sha256=inputs,seconds=time.monotonic()-tick))
 print(json.dumps(dict(recounted=len(rows),cost=r['cost'],seconds=time.monotonic()-start)),flush=True)
result=dict(passed=True,scope='second independent integer ceil-grid implementation for four posthoc diagnostic points; not cold solver performance, original-LSS qualification or30-run Avg',probe_sha256=sha(D/'REFINEMENT_PROBE.json'),verifier_sha256=math['source_sha256'],all_four_original_raw99_passed=len(rows)==4,rows=rows,new_MC_calls=0,seconds=time.monotonic()-start)
if len(rows)!=4:raise RuntimeError('Expected four independently certified diagnostic points')
with out.open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
