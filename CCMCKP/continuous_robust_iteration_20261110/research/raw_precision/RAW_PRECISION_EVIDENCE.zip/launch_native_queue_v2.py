from pathlib import Path
import argparse,json,hashlib,subprocess,time
H=Path(__file__).parent;ap=argparse.ArgumentParser();ap.add_argument('--job',required=True);a=ap.parse_args();J=(H/a.job).resolve()
if H.resolve() not in J.parents:raise RuntimeError('Job outside task workspace')
if any((J/name).exists() for name in ['NATIVE_LAUNCH.json','native.log','POSTSELECTION.json','FINISHED']):raise RuntimeError('Job may already be running/terminal; inspect actual PID')
reg=json.load(open(J/'NATIVE_REGISTRATION.json'))
for name,digest in reg['driver_sha256'].items():
 if hashlib.sha256((H/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('Registered native driver changed')
with (J/'native.log').open('x') as log:p=subprocess.Popen(['python3','-u',str(H/'run_native_queue_v2.py'),'--job',a.job],cwd=H,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
result=dict(time=time.time(),pid=p.pid,job=a.job,wait_for=reg['wait_for'],registration_sha256=hashlib.sha256((J/'NATIVE_REGISTRATION.json').read_bytes()).hexdigest(),no_native_calls_before_all_dependencies=True)
with (J/'NATIVE_LAUNCH.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
