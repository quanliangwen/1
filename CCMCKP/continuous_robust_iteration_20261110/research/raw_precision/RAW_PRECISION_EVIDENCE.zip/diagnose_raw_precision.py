"""Read-only diagnosis of saved proposal certificates; never reads true data."""
from pathlib import Path
import json,gzip,hashlib,collections,time
H=Path(__file__).parent;D=H/'research/raw_precision';D.mkdir(parents=True,exist_ok=True);out=D/'DIAGNOSTIC.json'
if out.exists():raise RuntimeError('No precision diagnostic overwrite')
jobs=[]
for i in [35,37,38,39,40]:
 jobs.append((f'I002_{i}',H/f'iterations/I002_cdf_neighborhood/pilot/cdf_lns_{i:02d}_seed970201.json.gz'))
 jobs.append((f'I004_{i}',H/f'iterations/I004_robust_pair_exchange/pilot/pair_exchange_{i:02d}_seed970401.json.gz'))
for i in [39,40]:jobs.append((f'I012_{i}',H/f'iterations/I012_iterated_block_mitm/engineering{i}/result.json.gz'))
def checked(obj):
 if isinstance(obj,dict):
  if isinstance(obj.get('checked'),list):
   for r in obj['checked']:
    if isinstance(r,dict) and 'selection' in r and 'cost' in r:yield r
  for k,v in obj.items():
   if k!='checked':yield from checked(v)
 elif isinstance(obj,list):
  for v in obj:yield from checked(v)
rows=[]
for label,file in jobs:
 data=json.loads(gzip.decompress(file.read_bytes()));meta=json.load(open(str(file)+'.run.json'))
 if data['status']!='completed':raise RuntimeError('Only frozen completed searches may be diagnosed')
 pool={tuple(r['selection']):r for r in data['candidate_shortlist']};raw_min=min(r['cost'] for r in pool.values());decisions={}
 for r in checked(data.get('extension',{})):
  q=tuple(r['selection']);c=r.get('decision') or {}
  if c.get('selection',list(q))!=list(q):raise RuntimeError('Proposal certificate selection differs')
  old=decisions.get(q)
  if old is None or c.get('bins',0)>=(old.get('decision') or {}).get('bins',0):decisions[q]=r
 counts=collections.Counter();cheap=collections.Counter();unresolved=[]
 for q,r in decisions.items():
  c=r.get('decision') or {};lower=c.get('lower_numerator');upper=c.get('upper_numerator');den=c.get('denominator')
  if q in pool:kind='certified_final_pool'
  elif lower is not None and den is not None and 100*int(lower)>=99*int(den):kind='lower99_missing_from_final_pool'
  elif upper is not None and den is not None and 100*int(upper)<99*int(den):kind='integer_raw_refuted'
  elif lower is not None and upper is not None and den is not None:kind='unresolved_integer_interval'
  elif c.get('infeasible'):kind='refuted_without_integer_fields'
  else:kind='unresolved_no_complete_certificate'
  counts[kind]+=1
  if r['cost']<raw_min-1e-9:cheap[kind]+=1
  if kind.startswith('unresolved') or kind=='lower99_missing_from_final_pool':unresolved.append(dict(selection=list(q),cost=r['cost'],bins=c.get('bins'),classification=kind,lower_numerator=lower,upper_numerator=upper,denominator=den,cheaper_than_final_raw_min=r['cost']<raw_min-1e-9))
 rows.append(dict(label=label,instance=data['instance'],capacity=data['capacity'],seed=data['seed'],result_sha256=hashlib.sha256(file.read_bytes()).hexdigest(),source_sha256=meta['source_sha256'],unique_saved_extension_proposals=len(decisions),final_raw_min=raw_min,counts=dict(counts),cheaper_than_raw_min_counts=dict(cheap),unresolved=unresolved))
result=dict(time=time.time(),scope='saved extension proposal raw-certificate diagnosis only; full integer numerator tests; no new optimizer run, raw probability computation, original-LSS call or Avg/Std',rows=rows,new_MC_calls=0,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
with out.open('x') as f:json.dump(result,f,indent=2)
print(json.dumps([{k:v for k,v in r.items() if k not in ['source_sha256','unresolved']} for r in rows]))
