"""External high-grid diagnosis of frozen unresolved proposals, never optimizer."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time,pickle
from raw_grid_bounds import grid_count
H=Path(__file__).parent;D=H/'research/raw_precision';out=D/'REFINEMENT_PROBE.json'
if out.exists() or (D/'REFINEMENT_REGISTRATION.json').exists():raise RuntimeError('Probe registered, inspect progress/result instead of rerunning')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();check=json.load(open(H/'RAW_GRID_BOUNDS_MATH_CHECK.json'))
if not check['passed'] or check['source_sha256']!=sha(H/'raw_grid_bounds.py'):raise RuntimeError('Validated exact bounds required')
diag=json.load(open(D/'DIAGNOSTIC.json'));refs=json.load(open(H/'iterations/I004_robust_pair_exchange/REGISTRATION.json'))['current_qualified_costs'];rawref=json.load(open(H/'RAW_REFERENCE.json'));tasks={}
for r in diag['rows']:
 i=int(r['label'].split('_')[-1])
 for c in r['unresolved']:
  if c['cost']<refs[str(i)]-1e-9:tasks[(i,tuple(c['selection']))]=dict(index=i,instance=r['instance'],capacity=r['capacity'],cost=c['cost'],selection=c['selection'],origin=r['label'],joint_reference=refs[str(i)])
reg=dict(scope='external precision diagnosis on already frozen proposals, selected using disclosed existing qualified cost scalar; NOT independent cold search or new MC, no optimizer feedback',time=time.time(),tasks=list(tasks.values()),bins=[2097152,4194304],seconds=300,source_sha256={n:sha(H/n) for n in ['probe_unresolved_precision.py','raw_grid_bounds.py']},diagnostic_sha256=sha(D/'DIAGNOSTIC.json'),math_sha256=sha(H/'RAW_GRID_BOUNDS_MATH_CHECK.json'))
with (D/'REFINEMENT_REGISTRATION.json').open('x') as f:json.dump(reg,f,indent=2)
start=time.monotonic();rows=[];models={}
for task in tasks.values():
 if time.monotonic()-start>280:break
 P=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/task['instance'];groups=pickle.load(open(P/'node_to_factor.pkl','rb'));groups=[groups[k] for k in sorted(groups,key=int)] if isinstance(groups,dict) else groups
 if any(j not in groups[g] for g,j in enumerate(task['selection'])):raise RuntimeError('Noncanonical selection')
 arrays=[]
 for j in task['selection']:
  p=P/f'{j}_sample.txt'
  if sha(p)!=rawref[str(p)]:raise RuntimeError('Original observations changed')
  arrays.append([F(x) for x in p.read_text().split()])
 intervals=[];decision='unresolved';began=time.monotonic()
 for bins in reg['bins']:
  if time.monotonic()-start>280:break
  lo,den=grid_count(arrays,task['capacity'],bins,True);hi,d=grid_count(arrays,task['capacity'],bins,False)
  if d!=den or lo>hi:raise RuntimeError('Invalid exact interval')
  decision='raw_certified' if 100*lo>=99*den else 'raw_refuted' if 100*hi<99*den else 'unresolved'
  intervals.append(dict(bins=bins,lower_numerator=str(lo),upper_numerator=str(hi),denominator=str(den),lower=float(F(lo,den)),upper=float(F(hi,den)),decision=decision))
  if decision!='unresolved':break
 row=dict(task,decision=decision,intervals=intervals,seconds=time.monotonic()-began);rows.append(row);(D/'REFINEMENT_PROGRESS.json').write_text(json.dumps(dict(done=len(rows),required=len(tasks),last=row,seconds=time.monotonic()-start),indent=2));print(json.dumps({k:v for k,v in row.items() if k not in ['selection','intervals']})+' '+json.dumps([{k:v for k,v in x.items() if k not in ['lower_numerator','upper_numerator','denominator']} for x in intervals]),flush=True)
result=dict(scope=reg['scope'],completed_tasks=len(rows),required_tasks=len(tasks),rows=rows,new_MC_calls=0,registration_sha256=sha(D/'REFINEMENT_REGISTRATION.json'),seconds=time.monotonic()-start)
with out.open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
