"""Registered external engineering/diagnostic native tasks, no optimizer feedback."""
from pathlib import Path
from fractions import Fraction as F
import argparse,json,gzip,hashlib,time,pickle
from native_cached_original_v2 import OriginalNative
H=Path(__file__).parent;ap=argparse.ArgumentParser();ap.add_argument('--job',required=True);a=ap.parse_args();J=(H/a.job).resolve()
if H.resolve() not in J.parents:raise RuntimeError('Job must stay in task workspace')
R=J/'NATIVE_REGISTRATION.json';reg=json.load(open(R));out=J/'POSTSELECTION.json';state=J/'NATIVE_STATE.json';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if out.exists() or (J/'FINISHED').exists():raise RuntimeError('Native job already terminal')
def identities():
 for name,digest in reg['driver_sha256'].items():
  if sha(H/name)!=digest:raise RuntimeError('Registered native driver changed')
 for name,digest in reg['input_sha256'].items():
  if sha(H/name)!=digest:raise RuntimeError('Frozen candidate/audit input changed')
identities();state.write_text(json.dumps(dict(stage='waiting',wait_for=reg['wait_for'],time=time.time(),new_MC_calls=0),indent=2))
while not all((H/name).exists() for name in reg['wait_for']):time.sleep(15)
identities();native=OriginalNative(H);inventory=dict(time=time.time(),files=[dict(name=p.name,sha256=sha(p)) for p in sorted((H/'lss_cache').glob('*.json'))],logs=[p.name for p in sorted((H/'lss_cache').glob('*.log'))])
with (J/'CACHE_BEFORE.json').open('x') as f:json.dump(inventory,f,indent=2)
if reg['mode']=='engineering_pool':
 data=json.loads(gzip.decompress((H/reg['candidate_file']).read_bytes()));tasks=[dict(index=reg['index'],instance=data['instance'],capacity=data['capacity'],seed=data['seed'],candidates=data['candidate_shortlist'])]
elif reg['mode']=='precision_points':
 probe=json.load(open(H/reg['candidate_file']));tasks=[]
 for r in probe['rows']:
  if r['decision']!='raw_certified':continue
  c=r['intervals'][-1];cert=dict(c,selection=r['selection'],all_original_samples=True,strict_event='sum<T',method='exact_integer_upward_grid_count',accepted=True)
  tasks.append(dict(index=r['index'],instance=r['instance'],capacity=r['capacity'],origin=r['origin'],candidates=[dict(selection=r['selection'],cost=r['cost'],certificate=cert)]))
else:raise RuntimeError('Unsupported registered native mode')
started=time.monotonic();rows=[];state.write_text(json.dumps(dict(stage='native',time=time.time(),tasks=len(tasks)),indent=2))
for task in tasks:
 begin=time.monotonic();tested=[];selected=None;error=None
 try:
  P=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/task['instance'];cost=[F(s) for s in (P/'cost.txt').read_text().split()];groups=pickle.load(open(P/'node_to_factor.pkl','rb'));groups=[groups[k] for k in sorted(groups,key=int)] if isinstance(groups,dict) else groups;pool=task['candidates']
  if pool!=sorted(pool,key=lambda r:(r['cost'],r['selection'])):raise RuntimeError('Frozen pool not cost ordered')
  for candidate in pool:
   q=candidate['selection'];c=candidate['certificate']
   if len(q)!=len(groups) or any(j not in groups[g] for g,j in enumerate(q)) or c['selection']!=q or not c['all_original_samples'] or c['strict_event']!='sum<T' or 100*int(c['lower_numerator'])<99*int(c['denominator']) or abs(candidate['cost']-float(sum((cost[j] for j in q),F(0))))>1e-9:raise RuntimeError('Invalid canonical raw-certified candidate')
   key,v,new=native.evaluate(task['instance'],task['capacity'],q);tested.append(dict(key=key,selection=q,cost=candidate['cost'],real_probability=v['real_probability'],passed=v['passed'],new_call_for_this_task=new,call_seconds=v['seconds'],native_receipt_sha256=sha(H/'lss_cache'/(key+'.json'))))
   if v['passed']:selected=dict(candidate,LSS_key=key,real_probability=v['real_probability']);break
 except Exception as ex:error=str(ex)
 row=dict(index=task['index'],instance=task['instance'],capacity=task['capacity'],search_seed=task.get('seed'),origin=task.get('origin'),accepted=selected is not None,selected=selected,tested=tested,error=error,logical_MC_seconds=sum(r['call_seconds'] for r in tested),new_calls=sum(r['new_call_for_this_task'] for r in tested),actual_seconds=time.monotonic()-begin);rows.append(row)
 (J/'PROGRESS.json').write_text(json.dumps(dict(done=len(rows),required=len(tasks),latest=row,seconds=time.monotonic()-started),indent=2))
result=dict(scope=reg['scope'],mode=reg['mode'],rows=rows,registration_sha256=sha(R),logical_MC_seconds=sum(r['logical_MC_seconds'] for r in rows),physical_new_calls_charged=sum(r['new_calls'] for r in rows),actual_seconds=time.monotonic()-started,errors=[r['error'] for r in rows if r['error']],no_optimizer_feedback=True,no_30run_statistics=True)
with out.open('x') as f:json.dump(result,f,indent=2)
state.write_text(json.dumps(dict(stage='finished_with_errors' if result['errors'] else 'finished',time=time.time(),accepted=sum(r['accepted'] for r in rows)),indent=2));(J/'FINISHED').write_text('terminal attempt, inspect POSTSELECTION.json qualification/errors\n');print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
