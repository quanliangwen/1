"""Exact integer lower/upper bounds on original independent empirical sums."""
from fractions import Fraction as F
from collections import Counter
from math import prod
import sys
from pathlib import Path
H=Path(__file__).parent;sys.path.insert(0,str(H/'iterations/I002_cdf_neighborhood/vendor313'))
from flint import fmpz_poly
def grid_count(arrays,capacity,bins,up):
 T=F(str(capacity));den=prod(len(a) for a in arrays);offset=0;counts=[]
 if T<=0 or bins<1 or not arrays or any(not a or min(a)<0 for a in arrays):raise ValueError('Positive capacity/grid and nonnegative nonempty marginals required')
 for a in arrays:
  values=[]
  for x in a:
   v=F(x)*bins/T;values.append(-(-v.numerator//v.denominator) if up else v.numerator//v.denominator)
  first=min(values);offset+=first;counts.append(Counter(v-first for v in values))
 cut=bins-offset
 if cut<=0:return 0,den
 polys=[]
 for c in counts:
  h=[0]*min(cut,max(c)+1)
  for k,n in c.items():
   if k<cut:h[k]=n
  polys.append(fmpz_poly(h))
 while len(polys)>1:polys=[(polys[i]*polys[i+1]).truncate(cut) if i+1<len(polys) else polys[i] for i in range(0,len(polys),2)]
 n=int(polys[0].truncate(cut)(1))
 if not 0<=n<=den:raise ArithmeticError('Invalid integer grid count')
 return n,den
