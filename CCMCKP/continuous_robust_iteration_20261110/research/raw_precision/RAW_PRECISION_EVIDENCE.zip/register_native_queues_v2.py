from pathlib import Path
import json,hashlib,time
H=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();driver={n:sha(H/n) for n in ['run_native_queue_v2.py','native_cached_original_v2.py','native_lss_eval.py','reference_loader.py']}
jobs=[dict(path='research/raw_precision/native',mode='precision_points',candidate_file='research/raw_precision/REFINEMENT_PROBE.json',wait_for=['formal/F001_I002_40x30/validation/FINISHED'],scope='original LSS on4external high-grid diagnostic points from old saved proposals; not a cold solver or30-run Avg',inputs=['research/raw_precision/REFINEMENT_PROBE.json','research/raw_precision/REFINEMENT_REGISTRATION.json','RAW_GRID_BOUNDS_MATH_CHECK.json']),dict(path='iterations/I014_hybrid_cdf_blocks/engineering39/native',mode='engineering_pool',candidate_file='iterations/I014_hybrid_cdf_blocks/engineering39/result.json.gz',wait_for=['formal/F001_I002_40x30/validation/FINISHED','iterations/I004_robust_pair_exchange/pilot_validation/FINISHED','iterations/I012_iterated_block_mitm/engineering40/result.json.gz.post.json','iterations/I012_iterated_block_mitm/engineering39/result.json.gz.post.json','research/raw_precision/native/FINISHED'],scope='one frozen I014 engineering39 full cost-order original-LSS postselection, not30-run Avg',inputs=['iterations/I014_hybrid_cdf_blocks/engineering39/result.json.gz','iterations/I014_hybrid_cdf_blocks/engineering39/INDEPENDENT_RAW_AUDIT.json','iterations/I014_hybrid_cdf_blocks/engineering39/ASSESSMENT.json'])]
for job in jobs:
 J=H/job['path'];J.mkdir(parents=True,exist_ok=True);out=J/'NATIVE_REGISTRATION.json'
 if out.exists():raise RuntimeError('Native registration exists, do not overwrite '+job['path'])
 if job['mode']=='engineering_pool':
  audit=json.load(open(H/job['inputs'][1]));assessment=json.load(open(H/job['inputs'][2]))
  if not audit['passed'] or not assessment['passed'] or not assessment['within_budget'] or not assessment['phase_within_budget'] or audit['result_sha256']!=sha(H/job['candidate_file']):raise RuntimeError('Independent complete engineering audit required')
 else:
  probe=json.load(open(H/job['candidate_file']))
  if len([r for r in probe['rows'] if r['decision']=='raw_certified'])!=4:raise RuntimeError('Expected4frozen raw-certified diagnostic points')
 reg=dict(time=time.time(),mode=job['mode'],index=39 if job['mode']=='engineering_pool' else None,candidate_file=job['candidate_file'],wait_for=job['wait_for'],scope=job['scope'],driver_sha256=driver,input_sha256={n:sha(H/n) for n in job['inputs']},point_threshold=.985,seed=832273,draws=10000000,event='sum<=T',no_search_feedback=True,registration_type='post-search validation registration, not pre-search performance registration')
 with out.open('x') as f:json.dump(reg,f,indent=2)
 print(json.dumps(dict(job=job['path'],wait_for=job['wait_for'],registration_sha256=sha(out))))
