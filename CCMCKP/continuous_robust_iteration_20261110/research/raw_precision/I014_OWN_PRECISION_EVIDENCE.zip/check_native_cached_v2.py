"""Exercise registered native receipt checks on63 real old identities, prohibit MC."""
from pathlib import Path
import json,hashlib
import native_cached_original_v2 as module
H=Path(__file__).parent;out=H/'NATIVE_CACHED_V2_REAL_CACHE_CHECK.json';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if out.exists():raise RuntimeError('No native cache check overwrite')
audit=json.load(open(H/'iterations/I014_hybrid_cdf_blocks/engineering39/INDEPENDENT_RAW_AUDIT.json'));reg=json.load(open(H/'iterations/I014_hybrid_cdf_blocks/engineering39/native/NATIVE_REGISTRATION.json'));before={r['key']:r for r in json.load(open(H/'formal/F001_I002_40x30/CACHE_BEFORE_VALIDATION.json'))['files']}
for name,digest in reg['driver_sha256'].items():
 if sha(H/name)!=digest:raise RuntimeError('Registered native helper/driver differs')
def forbidden(*a,**kw):raise RuntimeError('This real-cache check prohibits subprocess/MC')
module.subprocess.run=forbidden;checker=module.OriginalNative(H);rows=[]
for r in audit['known_records']:
 if sha(H/'lss_cache'/(r['key']+'.json'))!=before[r['key']]['sha256']:raise RuntimeError('Old receipt differs from formal preinventory')
 key,v,new=checker.evaluate('APP_50_10_500_',91.0,r['selection'])
 if key!=r['key'] or new or v['real_probability']!=r['real_probability'] or v['passed']!=r['passed']:raise RuntimeError('Registered helper did not reproduce original cached identity')
 rows.append(dict(key=key,passed=v['passed'],new_call=False,native_receipt_sha256=sha(H/'lss_cache'/(key+'.json'))))
result=dict(passed=True,scope='actual registered helper source exercised on63 known original-LSS receipts with subprocess forbidden; verifies cached branch only, not new-call timeout/error/controller integration',rows=rows,checked=len(rows),accepted=sum(r['passed'] for r in rows),rejected=sum(not r['passed'] for r in rows),new_MC_calls=0,driver_sha256=reg['driver_sha256'])
with out.open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
