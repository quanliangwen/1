"""Original-raw precision intervals for every saved own I014 unresolved proposal."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,time
from raw_grid_bounds import grid_count
H=Path(__file__).parent;D=H/'research/raw_precision';out=D/'I014_REFINEMENT_PROBE.json';rp=D/'I014_REFINEMENT_REGISTRATION.json';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if out.exists() or rp.exists():raise RuntimeError('Inspect registered I014 diagnostic instead of repeat')
diag=json.load(open(D/'I014_UNRESOLVED_DIAGNOSTIC.json'));check=json.load(open(H/'RAW_GRID_BOUNDS_MATH_CHECK.json'));rawref=json.load(open(H/'RAW_REFERENCE.json'));file=H/'iterations/I014_hybrid_cdf_blocks/engineering39/result.json.gz'
if not check['passed'] or check['source_sha256']!=sha(H/'raw_grid_bounds.py') or diag['result_sha256']!=sha(file):raise RuntimeError('Frozen own proposals and checked integer source required')
reg=dict(scope='all four saved own I014 unresolved proposals, sorted by their own cost only; post-search diagnosis, no historical scalar filtering, not a new cold solver or30-run Avg',time=time.time(),diagnostic_sha256=sha(D/'I014_UNRESOLVED_DIAGNOSTIC.json'),source_sha256={n:sha(H/n) for n in ['probe_i014_unresolved.py','raw_grid_bounds.py']},bins=[262144,1048576,2097152],seconds=180,instance='APP_50_10_500_',capacity=91.0,tasks=sorted(diag['unresolved'],key=lambda r:(r['cost'],r['selection'])))
with rp.open('x') as f:json.dump(reg,f,indent=2)
start=time.monotonic();rows=[]
for task in reg['tasks']:
 P=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/reg['instance'];arrays=[]
 for j in task['selection']:
  p=P/f'{j}_sample.txt'
  if sha(p)!=rawref[str(p)]:raise RuntimeError('Original raw input changed')
  arrays.append([F(s) for s in p.read_text().split()])
 intervals=[];decision='unresolved';tick=time.monotonic()
 for bins in reg['bins']:
  if time.monotonic()-start>155:break
  began=time.monotonic();n,d=grid_count(arrays,reg['capacity'],bins,True);u,d2=grid_count(arrays,reg['capacity'],bins,False)
  if d!=d2 or n>u:raise RuntimeError('Invalid integer enclosure')
  decision='raw_certified' if 100*n>=99*d else 'raw_refuted' if 100*u<99*d else 'unresolved'
  intervals.append(dict(bins=bins,lower_numerator=str(n),upper_numerator=str(u),denominator=str(d),lower=float(F(n,d)),upper=float(F(u,d)),decision=decision,seconds=time.monotonic()-began))
  if decision!='unresolved':break
 row=dict(index=39,instance=reg['instance'],capacity=reg['capacity'],cost=task['cost'],selection=task['selection'],intervals=intervals,decision=decision,seconds=time.monotonic()-tick);rows.append(row)
 (D/'I014_REFINEMENT_PROGRESS.json').write_text(json.dumps(dict(done=len(rows),required=len(reg['tasks']),last=row,seconds=time.monotonic()-start),indent=2))
 print(json.dumps({k:v for k,v in row.items() if k not in ['selection','intervals']})+' '+json.dumps([{k:v for k,v in c.items() if k not in ['lower_numerator','upper_numerator','denominator']} for c in intervals]),flush=True)
result=dict(scope=reg['scope'],registration_sha256=sha(rp),rows=rows,completed_tasks=len(rows),required_tasks=len(reg['tasks']),seconds=time.monotonic()-start,new_MC_calls=0)
with out.open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
