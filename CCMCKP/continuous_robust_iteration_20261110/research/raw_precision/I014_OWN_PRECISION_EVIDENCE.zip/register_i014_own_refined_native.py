"""Register two own-I014 post-search refined points; never edits frozen pool."""
from pathlib import Path
import json,hashlib,time
H=Path(__file__).parent;D=H/'research/raw_precision';J=D/'i014_own_native';J.mkdir(exist_ok=True);out=J/'NATIVE_REGISTRATION.json';points=D/'I014_REFINED_NATIVE_POINTS.json';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if out.exists() or points.exists():raise RuntimeError('Inspect existing own-point native registration, do not overwrite')
probe=D/'I014_REFINEMENT_PROBE.json';p=json.load(open(probe));v=json.load(open(D/'INDEPENDENT_I014_REFINED_RAW_RECHECK.json'));inventory=json.load(open(D/'I014_REFINED_NATIVE_INVENTORY.json'))
if p['completed_tasks']!=4 or not v['passed'] or not v['all_two_original_raw99_passed'] or v['probe_sha256']!=sha(probe) or inventory['probe_sha256']!=sha(probe) or inventory['native_unknown']!=2:raise RuntimeError('Own-point raw evidence/identity inventory required')
data=dict(scope='two independently raw-certified own I014 proposals refined after search; not members of frozen1017pool, not cold solver or30-run Avg',original_probe_sha256=sha(probe),rows=[dict(r,origin='I014_39_own_unresolved') for r in p['rows'] if r['decision']=='raw_certified'])
with points.open('x') as f:json.dump(data,f,indent=2)
drivers=['run_native_queue_v2.py','native_cached_original_v2.py','native_lss_eval.py','reference_loader.py'];inputs=[points,probe,D/'I014_REFINEMENT_REGISTRATION.json',D/'INDEPENDENT_I014_REFINED_RAW_RECHECK.json',D/'I014_REFINED_NATIVE_INVENTORY.json',H/'NATIVE_CACHED_V2_REAL_CACHE_CHECK.json']
reg=dict(time=time.time(),mode='precision_points',index=None,candidate_file=points.relative_to(H).as_posix(),wait_for=['formal/F001_I002_40x30/validation/FINISHED','research/raw_precision/native/FINISHED'],scope=data['scope'],driver_sha256={n:sha(H/n) for n in drivers},input_sha256={p.relative_to(H).as_posix():sha(p) for p in inputs},point_threshold=.985,seed=832273,draws=10000000,event='sum<=T',no_search_feedback=True,registration_type='post-search diagnostic validation registration, not pre-search performance registration')
with out.open('x') as f:json.dump(reg,f,indent=2)
print(json.dumps(dict(job=J.relative_to(H).as_posix(),registration_sha256=sha(out),points=len(data['rows']),wait_for=reg['wait_for'])))
