"""Reuse saved-proposal classification, isolated new I014 read-only snapshot."""
from pathlib import Path
import ast,json,hashlib,gzip,collections,time
H=Path(__file__).parent;out=H/'research/raw_precision/I014_UNRESOLVED_DIAGNOSTIC.json'
if out.exists():raise RuntimeError('No I014 diagnostic overwrite')
source=H/'diagnose_raw_precision.py';tree=ast.parse(source.read_text());env={}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='checked'],type_ignores=[]),str(source),'exec'),env)
file=H/'iterations/I014_hybrid_cdf_blocks/engineering39/result.json.gz';d=json.loads(gzip.decompress(file.read_bytes()));pool={tuple(r['selection']) for r in d['candidate_shortlist']};decisions={}
for r in env['checked'](d['extension']):
 q=tuple(r['selection']);c=r.get('decision') or {};old=decisions.get(q)
 if old is None or c.get('bins',0)>=(old.get('decision') or {}).get('bins',0):decisions[q]=r
counts=collections.Counter();unresolved=[]
for q,r in decisions.items():
 c=r.get('decision') or {}
 if q in pool:kind='raw_certified_in_pool'
 elif c.get('upper_numerator') is not None and 100*int(c['upper_numerator'])<99*int(c['denominator']):kind='integer_raw_refuted'
 else:kind='unresolved';unresolved.append(dict(selection=list(q),cost=r['cost'],decision=c))
 counts[kind]+=1
old=json.load(open(H/'research/raw_precision/REFINEMENT_PROBE.json'));old_points={tuple(r['selection']):r for r in old['rows'] if r['index']==39}
overlap=[dict(cost=r['cost'],old_refined_raw_decision=old_points[tuple(r['selection'])]['decision']) for r in unresolved if tuple(r['selection']) in old_points]
result=dict(scope='read-only own saved-proposal I014 engineering diagnosis; no new count, search, MC or30-run statistics',time=time.time(),result_sha256=hashlib.sha256(file.read_bytes()).hexdigest(),driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),classifier_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),counts=dict(counts),unresolved=unresolved,overlap_with_separate_old_diagnostic_points=overlap,new_MC_calls=0)
with out.open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='unresolved'}))
