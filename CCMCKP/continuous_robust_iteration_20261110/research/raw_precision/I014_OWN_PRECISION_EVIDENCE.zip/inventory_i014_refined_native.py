"""Only read existing original-LSS identities for newly exact-certified probes."""
from pathlib import Path
import ast,json,hashlib,pickle,math
from fractions import Fraction as F
H=Path(__file__).parent;D=H/'research/raw_precision';out=D/'I014_REFINED_NATIVE_INVENTORY.json'
if out.exists():raise RuntimeError('No cache-only inventory overwrite')
p=json.load(open(D/'I014_REFINEMENT_PROBE.json'));tasks=[r for r in p['rows'] if r['decision']=='raw_certified'];script=H/'audit_f001_final.py';text=script.read_text();tree=ast.parse(text);lines=text.splitlines();cases={r['index']:dict(index=r['index'],instance=r['instance'],tmax=r['capacity']) for r in tasks};before={r['key']:r for r in json.load(open(H/'formal/F001_I002_40x30/CACHE_BEFORE_VALIDATION.json'))['files']};env=dict(H=H,Path=Path,F=F,json=json,hashlib=hashlib,pickle=pickle,math=math,cases=cases,models={},input_identities={},rawref=json.load(open(H/'RAW_REFERENCE.json')),reference=json.load(open(H/'REFERENCE_SHA256.json')),distref=json.load(open(H/'LSS_DATA_REFERENCE.json'))['dataset_sha256'],native={},dist_checked=set(),used=set())
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['sha','checked_native']]+[next(n for n in tree.body if isinstance(n,ast.For) and lines[n.lineno-1].startswith('for i,c in cases.items()'))];exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(script),'exec'),env);sha=env['sha'];rows=[]
for rec in env['reference']['files']:
 if sha(H/'reference'/rec['path'])!=rec['sha256']:raise RuntimeError('Original LSS source changed')
for r in tasks:
 c=cases[r['index']];cert=r['intervals'][-1]
 if 100*int(cert['lower_numerator'])<99*int(cert['denominator']):raise RuntimeError('Raw certified flag inconsistent')
 identity=dict(instance=c['instance'],capacity=float(c['tmax']),selection=r['selection'],seed=832273,draws=10000000,event='sum<=T');key=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest();file=H/'lss_cache'/(key+'.json');row=dict(index=r['index'],cost=r['cost'],selection=r['selection'],key=key,raw_lower=cert['lower'],native_known=False)
 if file.exists():
  if key not in before or sha(file)!=before[key]['sha256']:raise RuntimeError('Unexpected changed/new native identity during frozen diagnostic')
  checked,v=env['checked_native'](c,dict(selection=r['selection']));row.update(native_known=True,passed=v['passed'],native_point=v['real_probability'],native_receipt_sha256=sha(file))
 rows.append(row)
result=dict(scope='post-freeze diagnostic points, existing original LSS cache only; not a cold optimizer gain or30-run Avg',raw_certified_points=len(rows),native_known=sum(r['native_known'] for r in rows),known_joint_pass=sum(r.get('passed',False) for r in rows),native_unknown=sum(not r['native_known'] for r in rows),new_MC_calls=0,probe_sha256=sha(D/'I014_REFINEMENT_PROBE.json'),rows=rows)
with out.open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='rows'}));print(json.dumps([{k:v for k,v in r.items() if k not in ['selection','key','native_receipt_sha256']} for r in rows]))
