"""Register full frozen I014/I015 prefixes and a fixed read-only native catalogue."""
from pathlib import Path
from fractions import Fraction as F
import json, gzip, pickle, time, os, sys
from isolated_original_lss import IsolatedOriginalLSS, sha, identity_key
from isolated_prefix_engine import ordered, describe, next_batch

H = Path(__file__).resolve().parent
D = H / 'research/D002_isolated_full_prefix'
D.mkdir(exist_ok=True)
if (D / 'REGISTRATION.json').exists():
    raise RuntimeError('Full-prefix study already registered; inspect its actual state')
check = json.load(open(D / 'PREFIX_ENGINE_CHECK.json'))
if not check['passed'] or check['source_sha256'] != sha(H / 'isolated_prefix_engine.py'):
    raise RuntimeError('Actual prefix-engine checks must match source')
memory = {line.split(':')[0]: int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith(('MemAvailable:', 'MemTotal:'))}
resources = dict(time=time.time(), available_memory_kib=memory['MemAvailable'],
                 available_cpus=len(os.sched_getaffinity(0)), python=sys.version)
if memory['MemAvailable'] < 16 * 1024 * 1024 or resources['available_cpus'] < 4:
    raise RuntimeError('Insufficient current resources for four extra native processes')

inputs = ['formal/F001_I002_40x30/CACHE_BEFORE_VALIDATION.json',
          'research/D001_isolated_precision_LSS/RESULT.json',
          'research/D001_isolated_precision_LSS/INDEPENDENT_RECEIPT_AUDIT.json',
          'REFERENCE_SHA256.json', 'LSS_DATA_REFERENCE.json', 'RAW_REFERENCE.json']
before = json.load(open(H / inputs[0]))
catalogue = {r['key']: dict(path='lss_cache/' + r['key'] + '.json', sha256=r['sha256']) for r in before['files']}
prior = json.load(open(H / inputs[1]))
if len(catalogue) != 448 or prior['errors'] or len(prior['rows']) != 6:
    raise RuntimeError('Original448 and completed private6 required')
for row in prior['rows']:
    if row['key'] in catalogue:
        raise RuntimeError('Unexpected duplicate prior catalogue identity')
    catalogue[row['key']] = dict(path=row['private_receipt'], sha256=row['receipt_sha256'])
native = IsolatedOriginalLSS(H, D / 'receipts', catalogue)
outcomes = {}
for key, row in catalogue.items():
    value = json.load(open(H / row['path']))
    identity = {k: value[k] for k in ['instance', 'capacity', 'selection', 'seed', 'draws', 'event']}
    if identity_key(identity) != key or identity['seed'] != 832273 or identity['draws'] != 10000000 or identity['event'] != 'sum<=T':
        raise RuntimeError('Read-only native catalogue identity differs')
    outcomes[key] = native.read_catalogue(key, identity)

pools = {}
pool_inputs = {}
rawref = json.load(open(H / 'RAW_REFERENCE.json'))
for label, iteration in [('I014', 'I014_hybrid_cdf_blocks'), ('I015', 'I015_precision_closure')]:
    I = H / 'iterations' / iteration
    J = I / 'engineering39'
    file = J / 'result.json.gz'
    data = json.loads(gzip.decompress(file.read_bytes()))
    meta = json.load(open(str(file) + '.run.json'))
    assessment = json.load(open(J / 'ASSESSMENT.json'))
    audit = json.load(open(J / 'INDEPENDENT_RAW_AUDIT.json'))
    source = {p.name: sha(p) for p in (I / 'candidate').glob('*.py')}
    if (not assessment['passed'] or not audit['passed']
            or not assessment['within_budget'] or not assessment['phase_within_budget']
            or meta['source_sha256'] != source or assessment['source_sha256'] != source
            or audit['result_sha256'] != sha(file) or data['status'] != 'completed'):
        raise RuntimeError('Frozen full raw/source/budget proof required for ' + label)
    P = Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark') / data['instance']
    for name, digest in meta['input_sha256'].items():
        if sha(P / name) != digest or rawref[str(P / name)] != digest:
            raise RuntimeError('Original raw benchmark changed')
    prices = [F(x) for x in (P / 'cost.txt').read_text().split()]
    groups = pickle.load(open(P / 'node_to_factor.pkl', 'rb'))
    groups = [groups[k] for k in sorted(groups, key=int)] if isinstance(groups, dict) else groups
    recounted = {(tuple(x['selection']), x['bins'], x['numerator'], x['denominator']) for x in audit['candidate_recounts']}
    records = []
    for row in data['candidate_shortlist']:
        q = row['selection']
        c = row['certificate']
        if (len(q) != len(groups) or any(j not in groups[g] for g, j in enumerate(q))
                or c['selection'] != q or not c['all_original_samples'] or c['strict_event'] != 'sum<T'
                or 100 * int(c['lower_numerator']) < 99 * int(c['denominator'])
                or abs(row['cost'] - float(sum((prices[j] for j in q), F(0)))) > 1e-9
                or (tuple(q), c['bins'], c['lower_numerator'], c['denominator']) not in recounted):
            raise RuntimeError('Pool member differs from independent exact raw proof')
        identity = dict(instance=data['instance'], capacity=float(data['capacity']), selection=q,
                        seed=832273, draws=10000000, event='sum<=T')
        records.append(dict(key=identity_key(identity), selection=q, cost=row['cost'], identity=identity))
    if records != ordered(records):
        raise RuntimeError('Frozen pool cost order changed')
    pools[label] = records
    pool_inputs[label] = dict(result_file=file.relative_to(H).as_posix(), result_sha256=sha(file),
                              seed=data['seed'], members=len(records), source_sha256=source,
                              initial_prefix=describe(records, outcomes))
    inputs.extend(p.relative_to(H).as_posix() for p in [file, Path(str(file) + '.run.json'), J / 'ASSESSMENT.json', J / 'INDEPENDENT_RAW_AUDIT.json'])

if (D / 'CATALOGUE.json').exists():
    if json.load(open(D / 'CATALOGUE.json')) != catalogue:
        raise RuntimeError('Existing unregistered catalogue differs; never overwrite')
else:
    with (D / 'CATALOGUE.json').open('x') as stream:
        json.dump(catalogue, stream, indent=2)
catalogue_check = dict(passed=True, checked=len(catalogue), new_MC_calls=0,
                      scope='actual registered helper validated all448original+6private receipts and current original distributions; cached read-only branch only',
                      helper_sha256=sha(H / 'isolated_original_lss.py'),
                      catalogue_sha256=sha(D / 'CATALOGUE.json'),
                      receipts=[dict(key=k, **r) for k, r in catalogue.items()])
if (D / 'CATALOGUE_CHECK.json').exists():
    if json.load(open(D / 'CATALOGUE_CHECK.json')) != catalogue_check:
        raise RuntimeError('Existing unregistered catalogue check differs; never overwrite')
else:
    with (D / 'CATALOGUE_CHECK.json').open('x') as stream:
        json.dump(catalogue_check, stream, indent=2)
drivers = ['run_isolated_full_prefix.py', 'isolated_prefix_engine.py', 'isolated_original_lss.py',
           'native_lss_eval.py', 'reference_loader.py']
reg = dict(time=time.time(), pools=pool_inputs, workers=4, watchdog_per_call=2400,
           source_sha256={name: sha(H / name) for name in drivers},
           input_sha256={name: sha(H / name) for name in inputs + [
               'research/D002_isolated_full_prefix/CATALOGUE.json',
               'research/D002_isolated_full_prefix/CATALOGUE_CHECK.json',
               'research/D002_isolated_full_prefix/PREFIX_ENGINE_CHECK.json']},
           resources=resources, cache_policy='only454pinned readonly old receipts; all new receipts/logs private toD002; no shared cache/formal writes',
           scope='external full cost-prefix postselection of two frozen case39engineering pools, not30-run Avg or new optimizer',
           scheduling='global increasing(cost,selection,key) batches of4unknown identities before each active pool known feasible upper; whole batch completes before decisions; errors never silently rejected/retried',
           accounting='per-pool logical original-MC seconds incl reused calls; actual private new attempts/MC seconds/speculation separate; D0016prior extra calls charged separately; later waiting-queue duplicates charged again',
           point_threshold=.985, draws=10000000, seed=832273, event='sum<=T',
           no_optimizer_feedback=True, earlier_registered_queues_unchanged=True)
with (D / 'REGISTRATION.json').open('x') as stream:
    json.dump(reg, stream, indent=2)
print(json.dumps(dict(registration_sha256=sha(D / 'REGISTRATION.json'), catalogue_checked=454,
                      resources=resources, initial_unknown_before_upper={name: len(describe(pool, outcomes)['missing_keys']) for name, pool in pools.items()},
                      first_batch=[dict(key=r['key'], cost=r['cost']) for r in next_batch(pools, outcomes, 4)])))
