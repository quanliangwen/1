"""Independent read-only formal-cache comparison, not an evaluator input."""
from pathlib import Path
import argparse, json, time
from isolated_original_lss import sha

H = Path(__file__).resolve().parent
D = H / 'research/D002_isolated_full_prefix'
parser = argparse.ArgumentParser()
parser.add_argument('--phase', choices=['before', 'after'], required=True)
args = parser.parse_args()
out = D / ('FORMAL_ISOLATION_' + args.phase.upper() + '.json')
if out.exists():
    raise RuntimeError('No isolation snapshot overwrite')
files = {p.name: sha(p) for p in sorted((H / 'lss_cache').glob('*.json'))}
logs = [p.name for p in sorted((H / 'lss_cache').glob('*.log'))]
F = H / 'formal/F001_I002_40x30'
process = Path('/proc/924526/cmdline')
result = dict(time=time.time(), scope='separate read-only isolation auditor, never search or native input',
              formal_stage=json.load(open(F / 'STAGE.json')),
              formal_controller_live=process.exists() and b'run_f001_stages.py' in process.read_bytes(),
              shared_receipt_sha256=files, shared_log_names=logs,
              shared_receipt_count=len(files), shared_log_count=len(logs))
if args.phase == 'before':
    old = {r['key'] + '.json': r['sha256'] for r in json.load(open(F / 'CACHE_BEFORE_VALIDATION.json'))['files']}
    result['matches_original448'] = files == old
    if not result['matches_original448'] or result['formal_stage']['stage'] != 'search' or not result['formal_controller_live']:
        raise RuntimeError('Expected original inventory and live formal search before new study')
else:
    before = json.load(open(D / 'FORMAL_ISOLATION_BEFORE.json'))
    result.update(original_receipts_unchanged=all(files.get(k) == v for k, v in before['shared_receipt_sha256'].items()),
                  inventory_identical_to_before=files == before['shared_receipt_sha256'],
                  log_names_identical_to_before=logs == before['shared_log_names'])
with out.open('x') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps({k: v for k, v in result.items() if k not in ['shared_receipt_sha256', 'shared_log_names']}))
