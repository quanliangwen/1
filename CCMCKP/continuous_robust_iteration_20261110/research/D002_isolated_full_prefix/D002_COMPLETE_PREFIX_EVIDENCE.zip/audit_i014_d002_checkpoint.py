"""Independent actual completed I014 prefix inside a still-running D002 study."""
from pathlib import Path
from fractions import Fraction as F
import json, gzip, hashlib, math, pickle
from independent_raw_recount import verify

H=Path(__file__).resolve().parent;D=H/'research/D002_isolated_full_prefix';out=D/'I014_PREFIX_CHECKPOINT.json';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if out.exists():raise RuntimeError('No completed I014 checkpoint overwrite')
progress=json.load(open(D/'PROGRESS.json'));reported=progress['accounting']['pools']['I014'];reg=json.load(open(D/'REGISTRATION.json'));catalogue=json.load(open(D/'CATALOGUE.json'));ref=json.load(open(H/'REFERENCE_SHA256.json'));dist=json.load(open(H/'LSS_DATA_REFERENCE.json'))['dataset_sha256']
if not reported['prefix_complete'] or not reported['accepted']:raise RuntimeError('Actual I014 controller prefix not complete')
info=reg['pools']['I014'];file=H/info['result_file']
if sha(file)!=info['result_sha256']:raise RuntimeError('Frozen I014 pool changed')
d=json.loads(gzip.decompress(file.read_bytes()));pool=sorted(d['candidate_shortlist'],key=lambda r:(r['cost'],r['selection']));P=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/d['instance'];prices=[F(s) for s in (P/'cost.txt').read_text().split()];groups=pickle.load(open(P/'node_to_factor.pkl','rb'));groups=[groups[k] for k in sorted(groups,key=int)] if isinstance(groups,dict) else groups;rows=[];selected=None
for record in ref['files']:
 if sha(H/'reference'/record['path'])!=record['sha256']:raise RuntimeError('Original21reference source differs')
for candidate in pool:
 q=candidate['selection'];identity=dict(instance=d['instance'],capacity=float(d['capacity']),selection=q,seed=832273,draws=10000000,event='sum<=T');key=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()
 if len(q)!=len(groups) or any(j not in groups[g] for g,j in enumerate(q)) or abs(candidate['cost']-float(sum((prices[j] for j in q),F(0))))>1e-9:raise RuntimeError('Canonical group/cost mismatch')
 location=H/catalogue[key]['path'] if key in catalogue else D/'receipts'/(key+'.json')
 if not location.exists():raise RuntimeError('Missing lower-cost actual native receipt '+key)
 if key in catalogue and sha(location)!=catalogue[key]['sha256']:raise RuntimeError('Pinned prior receipt changed')
 v=json.load(open(location))
 if any(v[k]!=x for k,x in identity.items()) or v['source_sha256']!=ref['files'] or v['reference_zip_sha256']!=ref['zip_sha256'] or v['numpy']!='1.24.4' or v['scipy']!='1.10.1' or not math.isfinite(v['real_probability']) or v['passed']!=(v['real_probability']>=.985) or v['search_feedback'] or v['role']!='external_validation_and_postselection' or not all(v[k] for k in ['original_full_module','original_sources_unmodified','aliases_only']):raise RuntimeError('Original native identity/env/source/threshold/role failed')
 if set(v['distribution_sha256'])!={str(j)+'_dist.txt' for j in q}:raise RuntimeError('Native true-data identity incomplete')
 for name,digest in v['distribution_sha256'].items():
  if dist[d['instance']+'/'+name]!=digest or sha(P/name)!=digest:raise RuntimeError('Original distribution changed')
 rows.append(dict(key=key,cost=candidate['cost'],passed=v['passed'],original_native_point=v['real_probability'],seconds=v['seconds'],receipt_path=location.relative_to(H).as_posix(),receipt_sha256=sha(location)))
 if v['passed']:
  selected=dict(candidate,native_key=key,original_native_point=v['real_probability']);break
if not selected or selected['native_key']!=reported['selected']['key'] or [r['key'] for r in rows]!=reported['required_keys']:raise RuntimeError('Independent direct cost scan differs from reported prefix')
raw=verify(P,selected['selection'],d['capacity'],selected['certificate']);cdf={tuple(r['selection']) for r in d['extension']['hybrid']['cdf_pool_records']};origins=[]
def inspect(value):
 if isinstance(value,dict):
  for row in value.get('checked',[]):
   if row.get('selection')==selected['selection']:origins.append({k:value[k] for k in ['kind','center','center_cost','free_groups','block_size','delta','center_guide'] if k in value})
  for k,v in value.items():
   if k!='checked':inspect(v)
 elif isinstance(value,list):
  for v in value:inspect(v)
inspect(d['extension']);baseline=json.load(open(H/'iterations/I002_cdf_neighborhood/pilot_validation/cdf_lns_39_seed970201.json.gz.post.json'))['selected'];result=dict(passed=True,scope='independent direct scan of complete ACTUAL I014 cost prefix, original-LSS receipts and independently recomputed selected raw certificate while I015 prefix may still run; one cold engineering result, not30-run Avg/global optimum',selected=selected,raw_selected_recount=raw,prefix=rows,cheaper_rejected=len(rows)-1,logical_original_MC_seconds=sum(r['seconds'] for r in rows),current_I002_reference_cost=baseline['cost'],gain_vs_I002=baseline['cost']-selected['cost'],in_own_CDF_pool=tuple(selected['selection']) in cdf,hamming_to_I002=sum(a!=b for a,b in zip(selected['selection'],baseline['selection'])),proposal_origins=origins,result_sha256=sha(file),registration_sha256=sha(D/'REGISTRATION.json'))
with out.open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k not in ['prefix','selected','proposal_origins']}));print(json.dumps(dict(cost=selected['cost'],native=selected['original_native_point'],source=selected.get('source'),raw_lower=selected['certificate']['lower'],origins=origins)))
