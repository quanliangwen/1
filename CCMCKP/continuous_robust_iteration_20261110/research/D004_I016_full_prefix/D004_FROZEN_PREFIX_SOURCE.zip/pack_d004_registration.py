from pathlib import Path
import json,zipfile,shutil
from isolated_original_lss import sha
H=Path(__file__).resolve().parent;D=H/'research/D004_I016_full_prefix';reg=json.load(open(D/'REGISTRATION.json'));out=D/'D004_FROZEN_PREFIX_SOURCE.zip';manifest=D/'SOURCE_MANIFEST.json'
if out.exists() or manifest.exists():raise RuntimeError('No D004 source freeze overwrite')
c=json.load(open(D/'CATALOGUE_CHECK.json'))
if not c['passed'] or c['checked']!=547 or c['new_MC_calls']!=0:raise RuntimeError('Actual547old receipt checks required')
files=[H/n for n in reg['source_sha256']]+[H/n for n in reg['input_sha256']]+[D/'REGISTRATION.json',D/'FORMAL_ISOLATION_BEFORE.json']
files.extend(H/n for n in ['register_d004_i016_prefix.py','launch_d004_i016_prefix.py','check_d004_prefix_engine.py','snapshot_d004_isolation.py','audit_d004_i016_prefix.py','pack_d004_registration.py','audit_i016_engineering39.py','postprocess_i016_engineering39.py','independent_raw_recount.py','INDEPENDENT_RAW_RECOUNT_MATH_CHECK.json'])
files.extend(H/'reference'/r['path'] for r in json.load(open(H/'REFERENCE_SHA256.json'))['files']);files.extend(H/r['path'] for r in json.load(open(D/'CATALOGUE.json')).values());files=sorted(set(files))
for n,digest in {**reg['source_sha256'],**reg['input_sha256']}.items():
 if sha(H/n)!=digest:raise RuntimeError('Registered native/frozen optimizer input changed')
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,p.relative_to(H).as_posix())
with zipfile.ZipFile(out) as z:
 if z.testzip() is not None:raise RuntimeError('Source ZIP CRC failed')
m=dict(file=out.name,bytes=out.stat().st_size,sha256=sha(out),zip_CRC_passed=True,scope='D004 prelaunch single frozen actual I016cold/full-raw proof, controllers/original21/547checked old native receipts; no D004MC yet',files=[dict(path=p.relative_to(H).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in files])
with manifest.open('x') as f:json.dump(m,f,indent=2)
T=H/'artifact/research/D004_I016_full_prefix';T.mkdir(parents=True,exist_ok=True)
for p in [out,manifest]+list(D.glob('*.json')):shutil.copy2(p,T/p.name)
print(json.dumps({k:v for k,v in m.items() if k!='files'}))
