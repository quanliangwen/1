from pathlib import Path
import json
import hashlib
from isolated_prefix_engine import describe, next_batch, account

H = Path(__file__).resolve().parent
D = H / 'research/D004_I016_full_prefix'
D.mkdir(exist_ok=True)
out = D / 'PREFIX_ENGINE_CHECK.json'
if out.exists():
    raise RuntimeError('No prefix-engine check overwrite')

def row(key, cost, selection=None):
    return dict(key=key, cost=cost, selection=[cost] if selection is None else selection)

def receipt(passed=False, error=None):
    return dict(passed=passed, seconds=7., error=error)

checks = []
pools = dict(a=[row('a', 1), row('b', 2), row('d', 4), row('u', 5)],
             b=[row('a', 1), row('c', 3), row('e', 4.5), row('u', 5)])
known = dict(a=receipt(), u=receipt(True))
assert [r['key'] for r in next_batch(pools, known, 4)] == ['b', 'c', 'd', 'e']
checks.append('shared rejection/known upper reused; unknown union cost ordered once')
known.update(b=receipt(True), c=receipt(True), d=receipt(), e=receipt())
r = account(pools, known, ['b', 'c', 'd', 'e'])
assert r['all_prefixes_complete'] and r['pools']['a']['selected']['key'] == 'b' and r['pools']['b']['selected']['key'] == 'c'
assert r['speculative_new_keys'] == ['d', 'e'] and r['physical_new_attempts'] == 4
assert r['pools']['a']['logical_original_MC_seconds'] == 14. and r['pools']['b']['logical_original_MC_seconds'] == 14.
checks.append('complete batch resolves separate minima; all4physical attempts charged;2speculative calls explicit; reused logical seconds retained')
assert not next_batch(pools, known, 4)
checks.append('completed pools schedule no additional expensive identities')
failed = dict(a=receipt(), u=receipt(True), b=receipt(error='timeout'), c=receipt(True))
assert describe(pools['a'], failed)['prefix_complete'] is False
assert describe(pools['a'], failed)['selected'] is None
assert describe(pools['a'], failed)['known_feasible_upper']['key'] == 'u'
assert describe(pools['b'], failed)['accepted']
assert [r['key'] for r in next_batch(pools, failed, 4)] == ['d']
failed['d'] = receipt()
assert not next_batch(pools, failed, 4)
assert not account(pools, failed, [])['all_prefixes_complete']
checks.append('failure before feasible upper remains incomplete; never retry or report success-subset minimum; other pool may finish')
ties = [row('second', 1, [1]), row('first', 1, [0])]
assert not describe(ties, {'second': receipt(True)})['prefix_complete']
assert describe(ties, {'first': receipt(True)})['selected']['key'] == 'first'
checks.append('equal cost follows canonical frozen selection order')
state = describe([row('a', 1)], {'a': receipt()})
assert state['prefix_complete'] and not state['accepted'] and state['selected'] is None
checks.append('exhausted rejection-only pool is complete but unqualified')
assert not describe([row('a', 1)], {})['prefix_complete']
checks.append('missing receipt cannot stand in for rejection')
for bad in [0, -1, 1.5]:
    try:
        next_batch(pools, {}, bad)
    except ValueError:
        checks.append('invalid worker count rejected ' + str(bad))
    else:
        raise AssertionError('Invalid worker count accepted')
try:
    describe([row('a', 1), row('a', 2)], {})
except ValueError:
    checks.append('duplicate frozen pool identity rejected')
else:
    raise AssertionError('Duplicate identity accepted')
try:
    next_batch(dict(a=[row('x', 1)], b=[row('x', 2)]), {}, 4)
except ValueError:
    checks.append('conflicting shared identity cost rejected')
else:
    raise AssertionError('Conflicting shared identity accepted')
result = dict(passed=True, checks=len(checks), records=checks,
              scope='actual pure prefix engine, shared identities, canonical ties, batch speculation, failure/unknown and cost accounting; no MC or optimizer performance',
              source_sha256=hashlib.sha256((H / 'isolated_prefix_engine.py').read_bytes()).hexdigest())
with out.open('x') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps(result))
