from pathlib import Path
import json, subprocess, time
from isolated_original_lss import sha

H = Path(__file__).resolve().parent
D = H / 'research/D004_I016_full_prefix'
reg = json.load(open(D / 'REGISTRATION.json'))
receipt = json.load(open(D / 'PRE_REG_REMOTE_VERIFIED.json'))
if any((D / name).exists() for name in ['LAUNCH.json', 'study.log', 'RESULT.json', 'FINISHED']):
    raise RuntimeError('Private prefix study may already be running; inspect its actual PID')
if not receipt['independent_remote_verification'] or receipt['registration_sha256'] != sha(D / 'REGISTRATION.json'):
    raise RuntimeError('Actual remote registration/source verification required')
for name, digest in reg['source_sha256'].items():
    if sha(H / name) != digest:
        raise RuntimeError('Registered prefix source changed')
for name, digest in reg['input_sha256'].items():
    if sha(H / name) != digest:
        raise RuntimeError('Registered prefix input changed')
with (D / 'study.log').open('x') as log:
    process = subprocess.Popen(['python3', '-u', str(H / 'run_d004_i016_prefix.py')],
        cwd=H, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
        start_new_session=True)
record = dict(time=time.time(), pid=process.pid, workers=reg['workers'],
              pre_registered_commit=receipt['commit'], registration_sha256=sha(D / 'REGISTRATION.json'),
              scope=reg['scope'], all_new_receipts_private=True)
with (D / 'LAUNCH.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record))
