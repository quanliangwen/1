"""Single I016 frozen-pool original-native prefix; only after actual raw audit."""
from pathlib import Path
from fractions import Fraction as F
import json,gzip,pickle,time,os,sys
from isolated_original_lss import IsolatedOriginalLSS,sha,identity_key
from isolated_prefix_engine import ordered,describe,next_batch
H=Path(__file__).resolve().parent;I=H/'iterations/I016_cdf_pair_cover';J=I/'engineering39';D=H/'research/D004_I016_full_prefix'
if not (J/'INDEPENDENT_RAW_AUDIT.json').exists():
 print(json.dumps(dict(ready=False,reason='actual I016 independent full raw audit missing',new_MC_calls=0)));sys.exit(0)
audit=json.load(open(J/'INDEPENDENT_RAW_AUDIT.json'));file=J/'result.json.gz';engineering=json.load(open(J/'REGISTRATION.json'));source={p.name:sha(p) for p in (I/'candidate').glob('*.py')};meta=json.load(open(str(file)+'.run.json'));data=json.loads(gzip.decompress(file.read_bytes()))
if not audit['passed'] or audit['result_sha256']!=sha(file) or audit['source_sha256']!=source or engineering['source_sha256']!=source or meta['source_sha256']!=source or not audit['phase_within_budget'] or not meta['within_budget'] or data['status']!='completed' or sha(H/audit['raw_recounts_file'])!=audit['raw_recounts_sha256'] or not json.load(open(J/'POSTPROCESS_TERMINAL.json'))['passed']:raise RuntimeError('Actual frozen I016 raw/source/budget proof required')
D.mkdir(exist_ok=True)
if (D/'REGISTRATION.json').exists():raise RuntimeError('D004 already registered; inspect actual state')
check=json.load(open(D/'PREFIX_ENGINE_CHECK.json'))
if not check['passed'] or check['source_sha256']!=sha(H/'isolated_prefix_engine.py'):raise RuntimeError('Actual matching prefix checks required')
inputs=['REFERENCE_SHA256.json','LSS_DATA_REFERENCE.json','RAW_REFERENCE.json','formal/F001_I002_40x30/CACHE_BEFORE_VALIDATION.json','research/D001_isolated_precision_LSS/RESULT.json','research/D001_isolated_precision_LSS/INDEPENDENT_RECEIPT_AUDIT.json']
old=json.load(open(H/inputs[3]));catalogue={r['key']:dict(path='lss_cache/'+r['key']+'.json',sha256=r['sha256']) for r in old['files']}
if len(catalogue)!=448:raise RuntimeError('Expected original448')
d1=json.load(open(H/inputs[4]))
if d1['errors'] or len(d1['rows'])!=6:raise RuntimeError('Actual D001 complete required')
for r in d1['rows']:
 if r['key'] in catalogue:raise RuntimeError('Duplicate native identity')
 catalogue[r['key']]=dict(path=r['private_receipt'],sha256=r['receipt_sha256'])
for folder,expected in [('D002_isolated_full_prefix',36),('D003_paired_stability_prefix',57)]:
 root=H/'research'/folder;result=json.load(open(root/'RESULT.json'));a=json.load(open(root/'INDEPENDENT_FINAL_AUDIT.json'))
 if not a['passed'] or a['result_sha256']!=sha(root/'RESULT.json') or len(result['private_new_outcomes'])!=expected:raise RuntimeError('Completed prior actual original native evidence required')
 for key,r in result['private_new_outcomes'].items():
  if key in catalogue or r['error']:raise RuntimeError('Prior duplicate/error native identity')
  catalogue[key]=dict(path=r['receipt_path'],sha256=r['receipt_sha256'])
 inputs.extend((root/n).relative_to(H).as_posix() for n in ['RESULT.json','INDEPENDENT_FINAL_AUDIT.json'])
native=IsolatedOriginalLSS(H,D/'receipts',catalogue);outcomes={}
for key,r in catalogue.items():
 v=json.load(open(H/r['path']));identity={k:v[k] for k in ['instance','capacity','selection','seed','draws','event']}
 if identity_key(identity)!=key or identity['seed']!=832273 or identity['draws']!=10000000 or identity['event']!='sum<=T':raise RuntimeError('Old native identity changed')
 outcomes[key]=native.read_catalogue(key,identity)
if len(catalogue)!=547:raise RuntimeError('Expected completed547identity catalogue')
proof=json.loads(gzip.decompress((H/audit['raw_recounts_file']).read_bytes()));recounted={(tuple(r['selection']),r['bins'],r['numerator'],r['denominator']) for r in proof};P=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/data['instance'];rawref=json.load(open(H/'RAW_REFERENCE.json'))
for n,digest in meta['input_sha256'].items():
 if sha(P/n)!=digest or rawref[str(P/n)]!=digest:raise RuntimeError('Original raw input changed')
costs=[F(x) for x in (P/'cost.txt').read_text().split()];groups=pickle.load(open(P/'node_to_factor.pkl','rb'));groups=[groups[k] for k in sorted(groups,key=int)] if isinstance(groups,dict) else groups;rows=[]
for row in data['candidate_shortlist']:
 q=row['selection'];c=row['certificate']
 if len(q)!=len(groups) or any(j not in groups[g] for g,j in enumerate(q)) or c['selection']!=q or c['strict_event']!='sum<T' or not c['all_original_samples'] or 100*int(c['lower_numerator'])<99*int(c['denominator']) or abs(row['cost']-float(sum((costs[j] for j in q),F(0))))>1e-9 or (tuple(q),c['bins'],c['lower_numerator'],c['denominator']) not in recounted:raise RuntimeError('Pool differs from independent original raw proof')
 identity=dict(instance=data['instance'],capacity=float(data['capacity']),selection=q,seed=832273,draws=10000000,event='sum<=T');rows.append(dict(key=identity_key(identity),selection=q,cost=row['cost'],identity=identity))
if rows!=ordered(rows) or len(rows)!=audit['final_pool']:raise RuntimeError('Frozen pool order/completeness changed')
inputs.extend((J/n).relative_to(H).as_posix() for n in ['REGISTRATION.json','TERMINAL.json','POSTPROCESS_TERMINAL.json','result.json.gz','result.json.gz.run.json','INDEPENDENT_RAW_AUDIT.json','RAW_CERTIFICATE_RECOUNTS.json.gz']);inputs.extend(p.relative_to(H).as_posix() for p in (I/'candidate').glob('*.py'))
with (D/'CATALOGUE.json').open('x') as f:json.dump(catalogue,f,indent=2)
with (D/'CATALOGUE_CHECK.json').open('x') as f:json.dump(dict(passed=True,checked=547,new_MC_calls=0,helper_sha256=sha(H/'isolated_original_lss.py'),catalogue_sha256=sha(D/'CATALOGUE.json'),scope='actual unchanged helper checks all448original+6D001+36D002+57D003 original-native receipts/source21/env/current true-data identity/role; no new MC'),f,indent=2)
mem={line.split(':')[0]:int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith(('MemAvailable:','MemTotal:'))};resources=dict(time=time.time(),available_cpus=len(os.sched_getaffinity(0)),available_memory_kib=mem['MemAvailable'])
if resources['available_cpus']<4 or resources['available_memory_kib']<16*1024*1024:raise RuntimeError('Insufficient four-worker resources')
drivers=['run_d004_i016_prefix.py','isolated_prefix_engine.py','isolated_original_lss.py','native_lss_eval.py','reference_loader.py'];inputs.extend((D/n).relative_to(H).as_posix() for n in ['CATALOGUE.json','CATALOGUE_CHECK.json','PREFIX_ENGINE_CHECK.json']);info=dict(result_file=file.relative_to(H).as_posix(),result_sha256=sha(file),seed=data['seed'],members=len(rows),source_sha256=source,initial_prefix=describe(rows,outcomes))
reg=dict(time=time.time(),pools=dict(I016=info),workers=4,watchdog_per_call=2400,source_sha256={n:sha(H/n) for n in drivers},input_sha256={n:sha(H/n) for n in sorted(set(inputs))},resources=resources,cache_policy='only547completed pinned readonly original native receipts; all new receipts/logs privateD004; F001/shared cache writes forbidden',scope='single ACTUAL cold I016case39 frozen-pool complete original-LSS cost-prefix validation, not matched-seed comparison/30Avg/global optimum',scheduling='checked whole batches4 global cost/selection/key, complete cheaper-prefix before first feasible; failures not rejection/retry',accounting='logical reused native time, allphysicalnew MC/speculative/errors separate; prior D001/D002/D003 costs and future duplicated shared-queue calls separate',point_threshold=.985,draws=10000000,seed=832273,event='sum<=T',no_optimizer_feedback=True,earlier_registered_queues_unchanged=True,registration_timing='AFTERsinglecoldterminal/all-raw independent audit; BEFORE D004native')
with (D/'REGISTRATION.json').open('x') as f:json.dump(reg,f,indent=2)
print(json.dumps(dict(registration_sha256=sha(D/'REGISTRATION.json'),catalogue_checked=547,initial_unknown=len(describe(rows,outcomes)['missing_keys']),initial_known_upper=(describe(rows,outcomes)['known_feasible_upper'] or {}).get('cost'),first_batch=[dict(key=r['key'],cost=r['cost']) for r in next_batch(dict(I016=rows),outcomes,4)])))
