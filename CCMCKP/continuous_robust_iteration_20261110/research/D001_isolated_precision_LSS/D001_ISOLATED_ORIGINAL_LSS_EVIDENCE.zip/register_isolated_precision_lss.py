"""Separate six-point external native study; never populates shared formal cache."""
from pathlib import Path
import json,hashlib,time
H=Path(__file__).resolve().parent;D=H/'research/D001_isolated_precision_LSS';D.mkdir(exist_ok=True);out=D/'REGISTRATION.json';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if out.exists():raise RuntimeError('Independent study already registered')
tasks=[];inputs=[]
for probe_name,recheck_name in [('research/raw_precision/REFINEMENT_PROBE.json','research/raw_precision/INDEPENDENT_REFINED_RAW_RECHECK.json'),('research/raw_precision/I014_REFINEMENT_PROBE.json','research/raw_precision/INDEPENDENT_I014_REFINED_RAW_RECHECK.json')]:
 probe=json.load(open(H/probe_name));check=json.load(open(H/recheck_name));inputs.extend([probe_name,recheck_name])
 if not check['passed'] or check['probe_sha256']!=sha(H/probe_name):raise RuntimeError('Independent original-raw certificates required')
 by_q={tuple(r['selection']):r for r in probe['rows'] if r['decision']=='raw_certified'}
 for c in check['rows']:
  r=by_q[tuple(c['selection'])];last=r['intervals'][-1]
  if c['lower_numerator']!=last['lower_numerator'] or c['denominator']!=last['denominator'] or 100*int(c['lower_numerator'])<99*int(c['denominator']):raise RuntimeError('Independent raw99 mismatch')
  identity=dict(instance=r['instance'],capacity=float(r['capacity']),selection=r['selection'],seed=832273,draws=10000000,event='sum<=T');key=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest();tasks.append(dict(index=r['index'],cost=r['cost'],identity=identity,key=key,raw_certificate=c,origin=probe_name))
tasks.sort(key=lambda r:(-r['index'],r['cost'],r['key']))
if len(tasks)!=6 or len({r['key'] for r in tasks})!=6:raise RuntimeError('Exactly six unique diagnostic identities required')
drivers=['run_isolated_precision_lss.py','native_lss_eval.py','reference_loader.py'];reg=dict(time=time.time(),scope='separate external original-LSS study on6posthoc independently raw-certified points; not any frozen solver cost-prefix or cold/30-run performance',tasks=tasks,workers=1,watchdog_per_call=2400,source_sha256={n:sha(H/n) for n in drivers},input_sha256={n:sha(H/n) for n in inputs+['REFERENCE_SHA256.json','LSS_DATA_REFERENCE.json']},point_threshold=.985,draws=10000000,seed=832273,event='sum<=T',cache_policy='all receipts/logs private under this study; NEVER read/write shared lss_cache or F001 files; no transfer during F001',accounting='all6physicalMCattempts extra research work, individually timed; no independent-seed probability-repetition or30-run Avg claim',no_optimizer_feedback=True,pre_search_sources_already_frozen=True,relationship_to_earlier_waiting_jobs='earlier native registrations/gates unchanged; this independently registered isolated study intentionally starts during formal search and is charged separately')
with out.open('x') as f:json.dump(reg,f,indent=2)
print(json.dumps(dict(study=D.name,tasks=len(tasks),registration_sha256=sha(out),workers=1,shared_cache_access=False)))
