from pathlib import Path
from fractions import Fraction as F
import json,hashlib,gzip,math
H=Path(__file__).resolve().parent;D=H/'research/D001_isolated_precision_LSS';out=D/'INDEPENDENT_RECEIPT_AUDIT.json';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if out.exists():raise RuntimeError('No isolated receipt audit overwrite')
reg=json.load(open(D/'REGISTRATION.json'));r=json.load(open(D/'RESULT.json'));ref=json.load(open(H/'REFERENCE_SHA256.json'));dist=json.load(open(H/'LSS_DATA_REFERENCE.json'))['dataset_sha256'];isolation=json.load(open(D/'FORMAL_ISOLATION_AFTER.json'));by_key={x['key']:x for x in r['rows']};pool=json.loads(gzip.decompress((H/'iterations/I015_precision_closure/engineering39/result.json.gz').read_bytes()));members={tuple(x['selection']) for x in pool['candidate_shortlist']};rows=[]
if r['registration_sha256']!=sha(D/'REGISTRATION.json') or r['errors'] or len(by_key)!=6 or r['physical_new_MC_attempts']!=6 or len(list((D/'receipts').glob('*.json')))!=6 or not isolation['shared_inventory_identical_to_before'] or not isolation['shared_log_names_identical_to_before'] or not isolation['all_original_shared_receipts_unchanged']:raise RuntimeError('Six actual attempts or formal isolation evidence differs')
for name,digest in reg['source_sha256'].items():
 if sha(H/name)!=digest:raise RuntimeError('Registered original native source differs')
for item in ref['files']:
 if sha(H/'reference'/item['path'])!=item['sha256']:raise RuntimeError('Original21reference changed')
for task in reg['tasks']:
 identity=task['identity'];key=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest();file=D/'receipts'/(key+'.json');v=json.load(open(file));row=by_key[key]
 if key!=task['key'] or sha(file)!=row['receipt_sha256'] or any(v[k]!=x for k,x in identity.items()) or v['source_sha256']!=ref['files'] or v['reference_zip_sha256']!=ref['zip_sha256'] or v['numpy']!='1.24.4' or v['scipy']!='1.10.1' or not math.isfinite(v['real_probability']) or not 0<=v['real_probability']<=1 or v['passed']!=(v['real_probability']>=.985) or row['qualified']!=v['passed'] or row['native_point']!=v['real_probability'] or v['search_feedback'] or v['role']!='external_validation_and_postselection' or not all(v[k] for k in ['original_full_module','original_sources_unmodified','aliases_only']):raise RuntimeError('Private original native identity/source/environment/point gate failed')
 raw=task['raw_certificate']
 if 100*int(raw['lower_numerator'])<99*int(raw['denominator']):raise RuntimeError('Independent raw certificate below99')
 if set(v['distribution_sha256'])!={str(j)+'_dist.txt' for j in identity['selection']}:raise RuntimeError('Incomplete true-data identity')
 for name,digest in v['distribution_sha256'].items():
  if dist[identity['instance']+'/'+name]!=digest:raise RuntimeError('Original true-data digest differs')
 if not (D/'receipts'/(key+'.log')).is_file():raise RuntimeError('Missing actual private native log')
 in_pool=identity['instance']==pool['instance'] and identity['capacity']==pool['capacity'] and tuple(identity['selection']) in members
 rows.append(dict(index=task['index'],cost=task['cost'],key=key,raw_lower=float(F(int(raw['lower_numerator']),int(raw['denominator']))),original_native_point=v['real_probability'],qualified=v['passed'],original_native_seconds=v['seconds'],receipt_sha256=sha(file),present_in_frozen_I015_pool=in_pool))
result=dict(passed=True,scope='independent identity/threshold/receipt/accounting/isolation replay of six actual extra private original-LSS calls; no new MC, no cost-prefix/cold-best/30-run Avg claim',rows=rows,actual_private_MC_attempts=6,qualified=sum(x['qualified'] for x in rows),original_MC_seconds=sum(x['original_native_seconds'] for x in rows),shared448_receipts_and68_log_names_unchanged=True,formal_cache_access_only_readonly_isolation_auditor=True,I015_members_tested=sum(x['present_in_frozen_I015_pool'] for x in rows),all_errors_retained_in_original_result=True,result_sha256=sha(D/'RESULT.json'),registration_sha256=sha(D/'REGISTRATION.json'))
if abs(result['original_MC_seconds']-r['original_MC_seconds'])>1e-9:raise RuntimeError('Physical extra native seconds accounting differs')
with out.open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='rows'}));print(json.dumps(rows))
