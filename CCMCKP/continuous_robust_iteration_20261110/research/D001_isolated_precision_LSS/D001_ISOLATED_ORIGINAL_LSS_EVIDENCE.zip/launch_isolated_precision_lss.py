from pathlib import Path
import json,hashlib,time,subprocess
H=Path(__file__).resolve().parent;D=H/'research/D001_isolated_precision_LSS';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();reg=json.load(open(D/'REGISTRATION.json'));receipt=json.load(open(D/'PRE_REG_REMOTE_VERIFIED.json'))
if any((D/n).exists() for n in ['LAUNCH.json','study.log','RESULT.json','FINISHED']):raise RuntimeError('Isolated native study may be running; inspect same actual PID')
if not receipt['independent_remote_verification'] or receipt['registration_sha256']!=sha(D/'REGISTRATION.json'):raise RuntimeError('Actual remote isolated study registration verification required')
for n,digest in reg['source_sha256'].items():
 if sha(H/n)!=digest:raise RuntimeError('Registered original-native study driver differs')
for n,digest in reg['input_sha256'].items():
 if sha(H/n)!=digest:raise RuntimeError('Registered study original inputs differ')
with (D/'study.log').open('x') as log:p=subprocess.Popen(['python3','-u',str(H/'run_isolated_precision_lss.py')],cwd=H,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
record=dict(time=time.time(),pid=p.pid,pre_registered_commit=receipt['commit'],registration_sha256=sha(D/'REGISTRATION.json'),scope=reg['scope'],all_receipts_private=True,workers=1)
with (D/'LAUNCH.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record))
