"""Separate read-only isolation audit; data never enters a solver/native call."""
from pathlib import Path
import argparse,json,hashlib,time
H=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['before','after'],required=True);a=ap.parse_args();D=H/'research/D001_isolated_precision_LSS';out=D/('FORMAL_ISOLATION_'+a.phase.upper()+'.json');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if out.exists():raise RuntimeError('No isolation audit snapshot overwrite')
files={p.name:sha(p) for p in sorted((H/'lss_cache').glob('*.json'))};logs=[p.name for p in sorted((H/'lss_cache').glob('*.log'))];F=H/'formal/F001_I002_40x30';process=Path('/proc/924526/cmdline');result=dict(scope='read-only before/after audit of shared directory, never input to private native or optimizer; private study evaluator/controller does not access these paths',time=time.time(),formal_stage=json.load(open(F/'STAGE.json')),formal_controller_pid=924526,formal_controller_live=process.exists() and b'run_f001_stages.py' in process.read_bytes(),shared_JSON_count=len(files),shared_log_count=len(logs),shared_JSON_sha256=files,shared_log_names=logs)
if a.phase=='before':
 old={r['key']+'.json':r['sha256'] for r in json.load(open(F/'CACHE_BEFORE_VALIDATION.json'))['files']};result['matches_original448_preinventory']=files==old
 if result['formal_stage']['stage']!='search' or not result['matches_original448_preinventory'] or not result['formal_controller_live']:raise RuntimeError('Expected original shared inventory and live formal search before isolated study; inspect actual state')
else:
 before=json.load(open(D/'FORMAL_ISOLATION_BEFORE.json'));result['all_original_shared_receipts_unchanged']=all(files.get(n)==digest for n,digest in before['shared_JSON_sha256'].items());result['shared_inventory_identical_to_before']=files==before['shared_JSON_sha256'];result['shared_log_names_identical_to_before']=logs==before['shared_log_names'];result['private_JSON_receipts']=len(list((D/'receipts').glob('*.json')))
with out.open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k not in ['shared_JSON_sha256','shared_log_names']}))
