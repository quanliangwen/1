"""Preserve this run's CDF pool, spend only its remaining phase on blocks."""
import time,math,copy
from portfolio_lns import PortfolioLNS
from block_exchange import RobustBlocks

def run_hybrid(solver,seconds,phase_started=None):
 seconds=float(seconds)
 if not math.isfinite(seconds) or seconds<0:raise ValueError('Finite nonnegative hybrid budget required')
 started=time.monotonic() if phase_started is None else phase_started
 phase_end=min(solver.deadline-12,started+seconds);initial=set(solver.pool)
 result=dict(method='cdf_then_own_pool_blocks',phase_budget=seconds,phase_deadline=phase_end,initial_pool=len(initial),cdf_executed=False,blocks_executed=False,cdf_seconds=0.,block_seconds=0.,robust_cdf_lns=None,robust_blocks=None,cdf_pool_records=[],no_external_data=True,no_new_hard_gate=True)
 if not initial or phase_end<=time.monotonic():
  result.update(status='skipped_empty_pool_or_expired_budget',cdf_pool=len(initial),final_pool=len(initial),all_initial_retained=True,all_own_cdf_retained=True,remaining_for_blocks=0.)
  return result
 cdf=PortfolioLNS(solver,max(0.,phase_end-time.monotonic()));cdf.end=min(cdf.end,phase_end)
 before=time.monotonic();cdf.run();result['cdf_seconds']=time.monotonic()-before;cdf_pool=set(solver.pool)
 if not initial<=cdf_pool:raise ArithmeticError('CDF stage removed an initial certified candidate')
 snapshot=copy.deepcopy(sorted(solver.pool.values(),key=lambda r:(r['cost'],r['selection'])))
 result.update(cdf_executed=True,robust_cdf_lns=cdf.summary(),cdf_pool=len(cdf_pool),cdf_pool_records=snapshot)
 remaining=max(0.,phase_end-time.monotonic());result['remaining_for_blocks']=remaining
 if remaining>=15:
  blocks=RobustBlocks(solver,remaining);blocks.end=min(blocks.end,phase_end)
  before=time.monotonic();blocks.run();result.update(block_seconds=time.monotonic()-before,blocks_executed=True,robust_blocks=blocks.summary())
 if not cdf_pool<=set(solver.pool):raise ArithmeticError('Block stage removed a CDF-certified candidate')
 result.update(status='completed',final_pool=len(solver.pool),all_initial_retained=initial<=set(solver.pool),all_own_cdf_retained=cdf_pool<=set(solver.pool),phase_seconds_used=time.monotonic()-started)
 return result
