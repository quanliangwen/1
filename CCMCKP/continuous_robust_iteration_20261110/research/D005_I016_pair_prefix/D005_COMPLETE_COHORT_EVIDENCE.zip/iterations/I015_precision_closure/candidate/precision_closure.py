"""Refine only this run's unresolved raw decisions within its existing phase."""
import copy,math,time

LEVELS=(262144,1048576,2097152)
DEFAULT_CALL_SECONDS={262144:4.5,1048576:18.,2097152:36.}

def checked_certificate(c,q):
 if c.get('selection')!=list(q) or c.get('method')!='exact_integer_upward_grid_count' or c.get('strict_event')!='sum<T' or c.get('all_original_samples') is not True:
  raise ArithmeticError('Original raw integer certificate identity required')
 n,d,u=int(c['lower_numerator']),int(c['denominator']),int(c['upper_numerator'])
 if not 0<=n<=u<=d or d<=0 or c.get('accepted')!=(100*n>=99*d) or c.get('infeasible')!=(100*u<99*d):
  raise ArithmeticError('Raw integer threshold/interval flags disagree')
 return bool(c['accepted']),bool(c['infeasible'])

def estimate_seconds(oracle,bins):
 # Admission is a conservative empirical forecast, not a hard runtime bound.
 # Only elapsed certificate work from this same run can influence it.
 history=[(key,c) for key,c in oracle.certificates.items() if key[2] and key[1]>=65536 and c.get('certificate_seconds',0)>0][-24:]
 return max([DEFAULT_CALL_SECONDS[bins]]+[1.5*c['certificate_seconds']*bins/key[1] for key,c in history])

def run_precision_closure(solver,seconds,phase_started,clock=None):
 seconds=float(seconds);now=time.monotonic if clock is None else clock
 if not math.isfinite(seconds) or seconds<0 or not math.isfinite(phase_started):raise ValueError('Finite nonnegative shared phase budget required')
 started=now();end=min(solver.deadline,phase_started+seconds);initial=set(solver.pool)
 tasks=sorted((q for q,c in solver.decisions.items() if c.get('decision')=='unresolved' and q not in solver.pool),key=lambda q:(solver.cost_of(q),q));rows={q:dict(selection=list(q),cost=solver.cost_of(q),initial_decision=copy.deepcopy(solver.decisions[q]),attempts=[],status='unresolved') for q in tasks}
 result=dict(method='own_unresolved_integer_precision_closure',phase_budget=seconds,phase_started=phase_started,shared_deadline=end,closure_started=started,unresolved_initial=len(tasks),initial_pool=len(initial),levels=list(LEVELS),queue_order='coarse grid for every own unresolved candidate in cost order, then finer grids in cost order',records=[],new_integer_calls=0,cached_certificates_reused=0,accepted=0,refuted=0,admission_skips=0,budget_overrun=False,no_external_data=True,no_new_hard_gate=True)
 highest={}
 for (q,bins,upper),c in solver.oracle.certificates.items():
  if upper and q in rows and (q not in highest or bins>highest[q]['bins']):highest[q]=c

 def apply(q,c,kind,elapsed=0.,forecast=None):
  accepted,refuted=checked_certificate(c,q);row=rows[q];row['final_certificate']=copy.deepcopy(c);row['attempts'].append(dict(kind=kind,bins=c['bins'],seconds=elapsed,forecast_seconds=forecast,accepted=accepted,infeasible=refuted));highest[q]=c
  if accepted:
   solver.accept(q,'own_unresolved_integer_precision_closure',c);row['status']='raw_certified';result['accepted']+=1
  elif refuted:
   solver.decisions[q]=c;solver.native_cache[q]=c['lower'];row['status']='integer_raw_refuted';result['refuted']+=1
  else:
   # Preserve the legacy unresolved return score; expose actual integer bounds
   # explicitly so callers cannot confuse the scheduling score with probability.
   solver.decisions[q]=dict(accepted=False,decision='unresolved',lower=0.,last_integer_certificate=copy.deepcopy(c));solver.native_cache[q]=0.
  row['last_integer_bins']=c['bins']

 # Cached results cost no new polynomial work and can be reused even if the
 # remaining phase cannot admit a new call. No old-run cache is consulted.
 for q in tasks:
  if q in highest:apply(q,highest[q],'same_run_cached_certificate');result['cached_certificates_reused']+=1
 for bins in LEVELS:
  for q in tasks:
   if rows[q]['status']!='unresolved' or highest.get(q,{}).get('bins',0)>=bins:continue
   forecast=estimate_seconds(solver.oracle,bins);remaining=end-now()
   if remaining<forecast:
    rows[q]['attempts'].append(dict(kind='not_admitted_insufficient_shared_time',bins=bins,forecast_seconds=forecast,remaining_seconds=max(0.,remaining)));result['admission_skips']+=1;continue
   tick=now();c=solver.oracle.certify(q,bins,True);elapsed=now()-tick;result['new_integer_calls']+=1;apply(q,c,'new_same_run_integer_certificate',elapsed,forecast)
   if now()>end:result['budget_overrun']=True;break
  if result['budget_overrun']:break
 if not initial<=set(solver.pool):raise ArithmeticError('Precision closure removed a previously certified candidate')
 finished=now();result.update(status='completed_with_deadline_overrun' if result['budget_overrun'] else 'completed',records=[rows[q] for q in tasks],unresolved_remaining=sum(r['status']=='unresolved' for r in rows.values()),final_pool=len(solver.pool),all_initial_retained=True,closure_seconds=finished-started,phase_seconds_used=finished-phase_started,phase_within_budget=finished<=end)
 return result
