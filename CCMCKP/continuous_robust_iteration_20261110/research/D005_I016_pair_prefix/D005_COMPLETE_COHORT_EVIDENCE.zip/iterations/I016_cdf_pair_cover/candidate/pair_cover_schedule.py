"""Own CDF proposals, generic pair cover, then blocks in the shared remainder."""
import time,math,copy
from portfolio_lns import PortfolioLNS
from pair_exchange import RobustPairs
from block_exchange import RobustBlocks

def run_pair_cover(solver,seconds,phase_started=None):
 seconds=float(seconds)
 if not math.isfinite(seconds) or seconds<0:raise ValueError('Finite nonnegative shared phase required')
 started=time.monotonic() if phase_started is None else phase_started
 if not math.isfinite(started):raise ValueError('Finite phase start required')
 end=min(solver.deadline-12,started+seconds);initial=set(solver.pool)
 result=dict(method='own_cdf_then_generic_pair_cover_then_remaining_blocks',phase_budget=seconds,phase_deadline=end,initial_pool=len(initial),cdf_executed=False,pairs_executed=False,blocks_executed=False,cdf_seconds=0.,pair_seconds=0.,block_seconds=0.,cdf_pool_records=[],pair_pool_records=[],robust_cdf_lns=None,robust_pairs=None,robust_blocks=None,no_external_data=True,no_new_hard_gate=True)
 def stage(cls,name):
  before=time.monotonic();model=cls(solver,max(0.,end-before));model.end=min(model.end,end);model.run();elapsed=time.monotonic()-before
  result[name+'_seconds']=elapsed;result[{'cdf':'robust_cdf_lns','pair':'robust_pairs','block':'robust_blocks'}[name]]=model.summary()
  return set(solver.pool)
 if not initial or end<=time.monotonic():
  result.update(status='skipped_empty_pool_or_expired_budget',cdf_pool=len(initial),pair_pool=len(initial),final_pool=len(initial),all_initial_retained=True,all_own_cdf_retained=True,all_own_pair_retained=True,remaining_for_pairs=0.,remaining_for_blocks=0.,phase_seconds_used=time.monotonic()-started)
  return result
 cdf_pool=stage(PortfolioLNS,'cdf')
 if not initial<=cdf_pool:raise ArithmeticError('CDF removed an accepted own member')
 result.update(cdf_executed=True,cdf_pool=len(cdf_pool),cdf_pool_records=copy.deepcopy(sorted(solver.pool.values(),key=lambda r:(r['cost'],r['selection']))),remaining_for_pairs=max(0.,end-time.monotonic()))
 pair_pool=cdf_pool
 if result['remaining_for_pairs']>=15:
  pair_pool=stage(RobustPairs,'pair');result['pairs_executed']=True
 if not cdf_pool<=pair_pool:raise ArithmeticError('Pairs removed an accepted CDF member')
 result.update(pair_pool=len(pair_pool),pair_pool_records=copy.deepcopy(sorted(solver.pool.values(),key=lambda r:(r['cost'],r['selection']))),remaining_for_blocks=max(0.,end-time.monotonic()))
 if result['remaining_for_blocks']>=15:
  final=stage(RobustBlocks,'block');result['blocks_executed']=True
 else:final=set(solver.pool)
 if not pair_pool<=final:raise ArithmeticError('Blocks removed an accepted pair member')
 result.update(status='completed',final_pool=len(final),all_initial_retained=initial<=final,all_own_cdf_retained=cdf_pool<=final,all_own_pair_retained=pair_pool<=final,phase_seconds_used=time.monotonic()-started)
 return result
