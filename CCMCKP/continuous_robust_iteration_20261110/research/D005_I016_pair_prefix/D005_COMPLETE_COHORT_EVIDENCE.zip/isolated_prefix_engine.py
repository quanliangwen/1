"""Cost-prefix decisions for several frozen pools sharing validation identities."""

def ordered(pool):
    keys = [r['key'] for r in pool]
    if len(keys) != len(set(keys)):
        raise ValueError('Duplicate identity inside a frozen pool')
    return sorted(pool, key=lambda r: (r['cost'], r['selection']))


def describe(pool, outcomes):
    pool = ordered(pool)
    upper_index = next((i for i, r in enumerate(pool)
                        if r['key'] in outcomes
                        and not outcomes[r['key']].get('error')
                        and outcomes[r['key']]['passed']), None)
    prefix = pool if upper_index is None else pool[:upper_index + 1]
    missing = [r['key'] for r in prefix if r['key'] not in outcomes]
    failures = [r['key'] for r in prefix
                if r['key'] in outcomes and outcomes[r['key']].get('error')]
    complete = not missing and not failures
    upper = None if upper_index is None else pool[upper_index]
    return dict(prefix_complete=complete,
                accepted=complete and upper is not None,
                selected=upper if complete else None,
                known_feasible_upper=upper,
                missing_keys=missing, failed_keys=failures,
                required_keys=[r['key'] for r in prefix])


def next_batch(pools, outcomes, workers):
    if not isinstance(workers, int) or workers < 1:
        raise ValueError('Positive integer worker count required')
    candidates = {}
    for pool in pools.values():
        state = describe(pool, outcomes)
        if state['prefix_complete']:
            continue
        by_key = {r['key']: r for r in pool}
        for key in state['missing_keys']:
            row = by_key[key]
            if key in candidates and (candidates[key]['cost'] != row['cost']
                                      or candidates[key]['selection'] != row['selection']):
                raise ValueError('Shared validation identity has conflicting cost/selection')
            candidates[key] = row
    return sorted(candidates.values(),
                  key=lambda r: (r['cost'], r['selection'], r['key']))[:workers]


def account(pools, outcomes, new_attempt_keys):
    states = {name: describe(pool, outcomes) for name, pool in pools.items()}
    required = set().union(*(set(s['required_keys']) for s in states.values()))
    rows = {}
    for name, state in states.items():
        logical = [outcomes[k] for k in state['required_keys']
                   if k in outcomes and not outcomes[k].get('error')]
        rows[name] = dict(state,
                          logical_original_MC_seconds=sum(r['seconds'] for r in logical),
                          logical_receipts=len(logical))
    return dict(pools=rows,
                unique_required_identities=len(required),
                physical_new_attempts=len(set(new_attempt_keys)),
                speculative_new_keys=sorted(set(new_attempt_keys) - required),
                all_prefixes_complete=all(s['prefix_complete'] for s in states.values()))
