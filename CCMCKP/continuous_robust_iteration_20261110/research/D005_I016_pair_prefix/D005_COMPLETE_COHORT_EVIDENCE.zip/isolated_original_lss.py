"""Original LSS with a pinned read-only catalogue and private new receipts."""
from pathlib import Path
import hashlib
import json
import math
import os
import subprocess
import time


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def identity_key(identity):
    return hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()


class IsolatedOriginalLSS:
    def __init__(self, root, private_dir, catalogue):
        self.root = Path(root).resolve()
        self.private_dir = Path(private_dir).resolve()
        if self.root / 'research' not in self.private_dir.parents:
            raise ValueError('New receipts must stay in the task research workspace')
        self.private_dir.mkdir(exist_ok=True)
        self.catalogue = catalogue
        self.reference = json.load(open(self.root / 'REFERENCE_SHA256.json'))
        self.distributions = json.load(open(self.root / 'LSS_DATA_REFERENCE.json'))['dataset_sha256']
        for row in self.reference['files']:
            if sha(self.root / 'reference' / row['path']) != row['sha256']:
                raise RuntimeError('Original LSS source changed')

    def validate(self, file, identity, expected_sha=None):
        file = Path(file)
        if expected_sha is not None and sha(file) != expected_sha:
            raise RuntimeError('Pinned read-only receipt changed')
        value = json.load(open(file))
        if (any(value[k] != x for k, x in identity.items())
                or value['source_sha256'] != self.reference['files']
                or value['reference_zip_sha256'] != self.reference['zip_sha256']
                or value['numpy'] != '1.24.4' or value['scipy'] != '1.10.1'
                or not math.isfinite(value['real_probability'])
                or not 0 <= value['real_probability'] <= 1
                or not math.isfinite(value['seconds']) or value['seconds'] < 0
                or value['passed'] != (value['real_probability'] >= .985)
                or value['search_feedback']
                or value['role'] != 'external_validation_and_postselection'
                or not all(value[k] for k in ['original_full_module',
                                               'original_sources_unmodified', 'aliases_only'])):
            raise RuntimeError('Original native identity/source/environment/role differs')
        expected = {str(j) + '_dist.txt' for j in identity['selection']}
        if set(value['distribution_sha256']) != expected:
            raise RuntimeError('Incomplete original distribution identity')
        bench = Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark') / identity['instance']
        for name, digest in value['distribution_sha256'].items():
            if (self.distributions[identity['instance'] + '/' + name] != digest
                    or sha(bench / name) != digest):
                raise RuntimeError('Original distribution changed')
        return value

    def read_catalogue(self, key, identity):
        row = self.catalogue[key]
        value = self.validate(self.root / row['path'], identity, row['sha256'])
        return dict(key=key, passed=value['passed'], probability=value['real_probability'],
                    seconds=value['seconds'], origin='pinned_readonly_catalogue',
                    receipt_path=row['path'], receipt_sha256=row['sha256'],
                    new_attempt=False, attempt_wall=0., error=None)

    def evaluate_new(self, task, watchdog):
        identity = task['identity']
        key = identity_key(identity)
        if key != task['key'] or key in self.catalogue:
            raise RuntimeError('New private task identity/catalogue classification differs')
        file = self.private_dir / (key + '.json')
        log = self.private_dir / (key + '.log')
        if file.exists() or log.exists():
            raise RuntimeError('Never repeat an existing private attempt automatically')
        started = time.monotonic()
        error = None
        value = None
        attempted = False
        try:
            with log.open('x') as stream:
                attempted = True
                result = subprocess.run(
                    ['python3', '-u', str(self.root / 'native_lss_eval.py'),
                     '--instance', '/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/' + identity['instance'],
                     '--capacity', str(identity['capacity']),
                     '--selection', json.dumps(identity['selection']), '--seed', '832273',
                     '--out', str(file)], cwd=self.root,
                    env=dict(os.environ, OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1'),
                    stdout=stream, stderr=subprocess.STDOUT, timeout=watchdog)
            if result.returncode:
                raise RuntimeError('Original native subprocess failed ' + str(result.returncode))
            value = self.validate(file, identity)
        except Exception as exception:
            error = str(exception)
        return dict(key=key, passed=value['passed'] if value is not None else False,
                    probability=value['real_probability'] if value is not None else None,
                    seconds=value['seconds'] if value is not None else 0.,
                    origin='new_private_original_MC',
                    receipt_path=file.relative_to(self.root).as_posix(),
                    receipt_sha256=sha(file) if file.exists() else None,
                    new_attempt=attempted, attempt_wall=time.monotonic() - started, error=error)
