from pathlib import Path
from fractions import Fraction
from itertools import product
import random,json,hashlib,math
from small_exact_integer_core import ExactHalfSums,decimal_integers
H=Path(__file__).parent;out=H/'SMALL_EXACT_INTEGER_CORE_MATH_CHECK.json'
if out.exists():raise RuntimeError('No math record overwrite')
rng=random.Random(9715000);checks=0
for model in range(60):
 m=1+model%5;samples=[[str(Fraction(rng.randrange(0,301),10**rng.randrange(0,4))) for k in range(1+rng.randrange(3))] for j in range(2*m)]
 # Store finite decimals, never strings such as '1/10' in production parser.
 from decimal import Decimal
 samples=[[str(Decimal(Fraction(s).numerator)/Decimal(Fraction(s).denominator)) for s in a] for a in samples];counter=ExactHalfSums(samples)
 for variant in range(4):
  selection=tuple(range(variant%2,2*m,2));thresholds=['0','0.1','1','1.001','1e2','-0.001']
  if variant%2:thresholds.reverse()
  for T in thresholds:
   n,den=counter.count(selection,T);expected=sum(sum((Fraction(s) for s in values),Fraction(0))<Fraction(T) for values in product(*(samples[j] for j in selection)))
   if n!=expected or den!=math.prod(len(samples[j]) for j in selection):raise RuntimeError('Full enumeration disagrees')
   checks+=1
# Integer observations and a threshold on a finer decimal scale exercise ceil.
c=ExactHalfSums([['0','1'],['0','1']])
for T,n in [('0',0),('0.1',1),('1',1),('1.001',3),('2',3),('2.001',4)]:
 if c.count((0,1),T)!=(n,4):raise RuntimeError('Strict event boundary mismatch')
 checks+=1
for strings in [[],['NaN'],['Infinity']]:
 try:decimal_integers(strings)
 except ValueError:checks+=1
 else:raise RuntimeError('Invalid decimal accepted')
result=dict(passed=True,models=60,checks=checks,seed=9715000,scope='exact integer cached half sums vs independent Fraction complete outcomes, nonuniform marginals, decimal exponents, reused capacities/selections, strict boundaries and invalid input',source_sha256=hashlib.sha256((H/'small_exact_integer_core.py').read_bytes()).hexdigest())
with out.open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
