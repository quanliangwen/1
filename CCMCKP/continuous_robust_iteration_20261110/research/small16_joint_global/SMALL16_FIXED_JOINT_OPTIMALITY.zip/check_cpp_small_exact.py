from pathlib import Path
from fractions import Fraction as F
from itertools import product
from decimal import Decimal
import random,json,hashlib,math,subprocess,time
from cpp_audit_codec import write_model
H=Path(__file__).parent;D=H/'research/small16_joint_global';out=D/'CPP_MATH_CHECK.json';binary=D/'small_exact_checker';input_file=D/'cpp_math.in';start=time.monotonic()
if out.exists() or input_file.exists():raise RuntimeError('No C++ math evidence overwrite')
rng=random.Random(9715001);models=[];checks=0
for k in range(60):
 m=1+k%5;samples=[[str(Decimal(rng.randrange(0,301))/Decimal(10**rng.randrange(0,4))) for _ in range(1+rng.randrange(3))] for j in range(2*m)];queries=[]
 for variant in range(4):
  selection=tuple(range(variant%2,2*m,2))
  for T in ['0','0.1','1','1.001','100','-0.001']:
   den=math.prod(len(samples[j]) for j in selection);n=sum(sum((F(x) for x in values),F(0))<F(T) for values in product(*(samples[j] for j in selection)));queries.append((T,n,den,selection));checks+=1
 models.append((samples,m,queries))
samples=[['12345678901234567890.1','0'],['12345678901234567890.2','0']];queries=[]
for T in ['0','0.1','12345678901234567890.1','24691357802469135780.3','24691357802469135780.4']:
 n=sum(F(a)+F(b)<F(T) for a,b in product(*samples));queries.append((T,n,4,(0,1)));checks+=1
models.append((samples,2,queries))
with input_file.open('x') as f:
 f.write(str(len(models))+'\n')
 for samples,m,queries in models:write_model(f,samples,m,queries)
with input_file.open() as f:r=subprocess.run([str(binary)],stdin=f,capture_output=True,text=True,timeout=30)
if r.returncode or not r.stdout.endswith(f'ALL_OK {len(models)} {checks}\n'):raise RuntimeError('C++ full Fraction enumeration mismatch '+r.stdout+r.stderr)
invalid={'parse_overflow':f'1\n1 1 0\n1 {1<<127}\n','sum_overflow':f'1\n1 1 0\n1 {(1<<126)+1}\n','trailing_input':'1\n1 1 0\n1 0\nextra\n'};failures={}
for label,text in invalid.items():
 result=subprocess.run([str(binary)],input=text,capture_output=True,text=True,timeout=10)
 if result.returncode==0:raise RuntimeError('C++ invalid input accepted '+label)
 failures[label]=dict(exit=result.returncode,stderr=result.stderr.strip());checks+=1
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result=dict(passed=True,models=len(models),checks=checks,seed=9715001,source_sha256=sha(H/'small_exact_checker.cpp'),codec_sha256=sha(H/'cpp_audit_codec.py'),binary_sha256=sha(binary),input_sha256=sha(input_file),compiler='g++9.4.0 -O2 -std=c++17',stdout=r.stdout,invalid_inputs=failures,method='C++ exact128 sort/lower_bound vs Fraction full outcomes; strict boundaries, finer decimal capacities, >64bit sample values and overflow guards',seconds=time.monotonic()-start)
with out.open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='stdout'}))
