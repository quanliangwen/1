"""Post-search registration of six frozen paired pools; no new MC here."""
from pathlib import Path
from fractions import Fraction as F
import json, gzip, pickle, time, os
from isolated_original_lss import IsolatedOriginalLSS, sha, identity_key
from isolated_prefix_engine import ordered, describe, next_batch

H=Path(__file__).resolve().parent;D=H/'research/D003_paired_stability_prefix';S=H/'stability/I015_gain_case39'
D.mkdir(exist_ok=True)
if (D/'REGISTRATION.json').exists():raise RuntimeError('Already registered; inspect existing study')
check=json.load(open(D/'PREFIX_ENGINE_CHECK.json'))
if not check['passed'] or check['source_sha256']!=sha(H/'isolated_prefix_engine.py'):raise RuntimeError('Actual engine checks required')
audit=json.load(open(S/'INDEPENDENT_SEARCH_RAW_AUDIT.json'));searchreg=json.load(open(S/'REGISTRATION.json'))
if not audit['passed'] or audit['required_searches']!=6 or audit['unique_raw_certificates']!=1646 or audit['registration_sha256']!=sha(S/'REGISTRATION.json') or not (S/'SEARCH_FINISHED').exists():raise RuntimeError('All six frozen/raw-audited searches required')
if sha(H/audit['raw_recounts_file'])!=audit['raw_recounts_sha256']:raise RuntimeError('Independent raw proof changed')
inputs=['REFERENCE_SHA256.json','LSS_DATA_REFERENCE.json','RAW_REFERENCE.json','formal/F001_I002_40x30/CACHE_BEFORE_VALIDATION.json','research/D001_isolated_precision_LSS/RESULT.json','research/D001_isolated_precision_LSS/INDEPENDENT_RECEIPT_AUDIT.json','research/D002_isolated_full_prefix/RESULT.json','research/D002_isolated_full_prefix/INDEPENDENT_FINAL_AUDIT.json']
inputs.extend((S/n).relative_to(H).as_posix() for n in ['REGISTRATION.json','SEARCH_RESULT.json','INDEPENDENT_SEARCH_RAW_AUDIT.json','RAW_CERTIFICATE_RECOUNTS.json.gz','POSTPROCESS_TERMINAL.json'])
old=json.load(open(H/inputs[3]));catalogue={r['key']:dict(path='lss_cache/'+r['key']+'.json',sha256=r['sha256']) for r in old['files']}
if len(catalogue)!=448:raise RuntimeError('Expected original448')
d1=json.load(open(H/inputs[4]));d2=json.load(open(H/inputs[6]));d2audit=json.load(open(H/inputs[7]))
if d1['errors'] or len(d1['rows'])!=6 or not d2audit['passed'] or d2audit['result_sha256']!=sha(H/inputs[6]) or len(d2['private_new_outcomes'])!=36:raise RuntimeError('Actual D001/D002 verified evidence required')
for r in d1['rows']:
 if r['key'] in catalogue:raise RuntimeError('Prior duplicate identity')
 catalogue[r['key']]=dict(path=r['private_receipt'],sha256=r['receipt_sha256'])
for key,r in d2['private_new_outcomes'].items():
 if key in catalogue or r['error']:raise RuntimeError('Prior duplicate/failed native identity')
 catalogue[key]=dict(path=r['receipt_path'],sha256=r['receipt_sha256'])
native=IsolatedOriginalLSS(H,D/'receipts',catalogue);outcomes={}
for key,r in catalogue.items():
 v=json.load(open(H/r['path']));identity={k:v[k] for k in ['instance','capacity','selection','seed','draws','event']}
 if identity_key(identity)!=key or identity['seed']!=832273 or identity['draws']!=10000000 or identity['event']!='sum<=T':raise RuntimeError('Old original native identity changed')
 outcomes[key]=native.read_catalogue(key,identity)
proof=json.loads(gzip.decompress((H/audit['raw_recounts_file']).read_bytes()));recounted={(tuple(r['selection']),r['bins'],r['numerator'],r['denominator']) for r in proof}
P=Path(searchreg['benchmark']);rawref=json.load(open(H/'RAW_REFERENCE.json'))
for name,digest in searchreg['input_sha256'].items():
 if sha(P/name)!=digest or rawref[str(P/name)]!=digest:raise RuntimeError('Original raw input changed')
prices=[F(x) for x in (P/'cost.txt').read_text().split()];groups=pickle.load(open(P/'node_to_factor.pkl','rb'));groups=[groups[k] for k in sorted(groups,key=int)] if isinstance(groups,dict) else groups
pools={};infos={}
for info in audit['pools']:
 file=H/info['result_file'];data=json.loads(gzip.decompress(file.read_bytes()));meta=json.load(open(str(file)+'.run.json'));terminal=Path(str(file).replace('.json.gz','.terminal.json'));source=searchreg['sources'][info['label']];candidate=H/source['candidate']
 if sha(file)!=info['result_sha256'] or meta['source_sha256']!=source['source_sha256'] or {p.name:sha(p) for p in candidate.glob('*.py')}!=source['source_sha256']:raise RuntimeError('Frozen paired search source/result changed')
 rows=[]
 for r in data['candidate_shortlist']:
  q=r['selection'];c=r['certificate']
  if len(q)!=len(groups) or any(j not in groups[g] for g,j in enumerate(q)) or c['selection']!=q or c['strict_event']!='sum<T' or not c['all_original_samples'] or 100*int(c['lower_numerator'])<99*int(c['denominator']) or abs(r['cost']-float(sum((prices[j] for j in q),F(0))))>1e-9 or (tuple(q),c['bins'],c['lower_numerator'],c['denominator']) not in recounted:raise RuntimeError('Pool differs from independent raw proof')
  identity=dict(instance=data['instance'],capacity=float(data['capacity']),selection=q,seed=832273,draws=10000000,event='sum<=T');rows.append(dict(key=identity_key(identity),cost=r['cost'],selection=q,identity=identity))
 if rows!=ordered(rows) or len(rows)!=info['raw_candidates']:raise RuntimeError('Frozen pool order/completeness changed')
 label=info['label']+'_seed'+str(info['seed']);pools[label]=rows;infos[label]=dict(info,seed=info['seed'],members=len(rows),initial_prefix=describe(rows,outcomes));inputs.extend(p.relative_to(H).as_posix() for p in [file,Path(str(file)+'.run.json'),terminal]);inputs.extend(p.relative_to(H).as_posix() for p in candidate.glob('*.py'))
with (D/'CATALOGUE.json').open('x') as f:json.dump(catalogue,f,indent=2)
with (D/'CATALOGUE_CHECK.json').open('x') as f:json.dump(dict(passed=True,checked=len(catalogue),new_MC_calls=0,helper_sha256=sha(H/'isolated_original_lss.py'),catalogue_sha256=sha(D/'CATALOGUE.json'),scope='actual helper validated original448+D0016+D00236 readonly receipts/source21/env/distributions/role'),f,indent=2)
mem={line.split(':')[0]:int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith(('MemAvailable:','MemTotal:'))};resources=dict(time=time.time(),available_cpus=len(os.sched_getaffinity(0)),available_memory_kib=mem['MemAvailable'])
if resources['available_cpus']<4 or resources['available_memory_kib']<16*1024*1024:raise RuntimeError('Insufficient extra four-worker resources')
drivers=['run_d003_stability_prefix.py','isolated_prefix_engine.py','isolated_original_lss.py','native_lss_eval.py','reference_loader.py'];inputs.extend((D/n).relative_to(H).as_posix() for n in ['CATALOGUE.json','CATALOGUE_CHECK.json','PREFIX_ENGINE_CHECK.json'])
reg=dict(time=time.time(),pools=infos,workers=4,watchdog_per_call=2400,source_sha256={n:sha(H/n) for n in drivers},input_sha256={n:sha(H/n) for n in sorted(set(inputs))},resources=resources,cache_policy='only490pinned readonly receipts; all new original native receipts/logs private D003; no formal/shared cache writes',scope='full original-LSS cost-prefix validation of all six frozen case39 paired searches; development3-seed statistics only after all six prefixes complete; not40x30',scheduling='same checked generic whole batches4 global(cost,selection,key); first feasible only after every cheaper member has terminal rejection; errors retain incompleteness, no automatic retry',accounting='per-pool logical native time includes reused receipts; private new MC/speculative/failed calls separately; D001/D002 and future duplicate physical calls separately billed',point_threshold=.985,draws=10000000,seed=832273,event='sum<=T',no_optimizer_feedback=True,earlier_registered_queues_unchanged=True,registration_timing='AFTERall6searches and independent raw recount, BEFORE any D003 original MC; search prior registration permitted postfreeze fixed catalogue')
with (D/'REGISTRATION.json').open('x') as f:json.dump(reg,f,indent=2)
print(json.dumps(dict(registration_sha256=sha(D/'REGISTRATION.json'),catalogue_checked=len(catalogue),resources=resources,initial_unknown={k:len(describe(v,outcomes)['missing_keys']) for k,v in pools.items()},initial_union_unknown=len({x for p in pools.values() for x in describe(p,outcomes)['missing_keys']}),first_batch=[dict(key=r['key'],cost=r['cost']) for r in next_batch(pools,outcomes,4)])))
