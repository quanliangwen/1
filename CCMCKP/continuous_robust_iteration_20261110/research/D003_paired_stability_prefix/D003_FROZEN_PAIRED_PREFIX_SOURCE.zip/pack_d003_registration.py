"""Freeze actual six searches, raw proofs, controllers and old catalogue."""
from pathlib import Path
import json,zipfile,shutil
from isolated_original_lss import sha
H=Path(__file__).resolve().parent;D=H/'research/D003_paired_stability_prefix';S=H/'stability/I015_gain_case39';reg=json.load(open(D/'REGISTRATION.json'));out=D/'D003_FROZEN_PAIRED_PREFIX_SOURCE.zip'
if out.exists() or (D/'SOURCE_MANIFEST.json').exists():raise RuntimeError('No prelaunch freeze overwrite')
check=json.load(open(D/'CATALOGUE_CHECK.json'))
if not check['passed'] or check['checked']!=490 or check['new_MC_calls']!=0:raise RuntimeError('Actual490old receipt checks required')
files=[H/n for n in reg['source_sha256']]+[H/n for n in reg['input_sha256']]
files.extend(H/n for n in ['register_d003_stability_prefix.py','launch_d003_stability_prefix.py','snapshot_d003_isolation.py','check_d003_prefix_engine.py','audit_d003_stability_prefix.py','pack_d003_registration.py','audit_i015_gain_stability39.py','postprocess_i015_gain_stability39.py','launch_i015_stability_postprocess.py','independent_raw_recount.py','INDEPENDENT_RAW_RECOUNT_MATH_CHECK.json'])
files.extend(D/n for n in ['REGISTRATION.json','FORMAL_ISOLATION_BEFORE.json'])
files.extend(H/'reference'/r['path'] for r in json.load(open(H/'REFERENCE_SHA256.json'))['files'])
files.extend(H/r['path'] for r in json.load(open(D/'CATALOGUE.json')).values())
files=sorted(set(files))
for n,digest in {**reg['source_sha256'],**reg['input_sha256']}.items():
 if sha(H/n)!=digest:raise RuntimeError('Frozen input/source changed')
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,p.relative_to(H).as_posix())
with zipfile.ZipFile(out) as z:
 if z.testzip() is not None:raise RuntimeError('ZIP CRC failed')
m=dict(file=out.name,bytes=out.stat().st_size,sha256=sha(out),zip_CRC_passed=True,scope='pre-native D003 source+actual six frozen searches/raw proofs/490actual old original-native receipts; no D003 MC executed yet',files=[dict(path=p.relative_to(H).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in files])
with (D/'SOURCE_MANIFEST.json').open('x') as f:json.dump(m,f,indent=2)
T=H/'artifact/research/D003_paired_stability_prefix';T.mkdir(parents=True,exist_ok=True)
for p in [out,D/'REGISTRATION.json',D/'SOURCE_MANIFEST.json',D/'CATALOGUE_CHECK.json',D/'PREFIX_ENGINE_CHECK.json',D/'FORMAL_ISOLATION_BEFORE.json']:shutil.copy2(p,T/p.name)
U=H/'artifact/stability/I015_gain_case39';U.mkdir(parents=True,exist_ok=True)
for n in ['SEARCH_RESULT.json','INDEPENDENT_SEARCH_RAW_AUDIT.json','POSTPROCESS_REGISTRATION.json','POSTPROCESS_LAUNCH.json','POSTPROCESS_TERMINAL.json']:
 p=S/n
 if p.exists():shutil.copy2(p,U/n)
for n in ['audit_i015_gain_stability39.py','postprocess_i015_gain_stability39.py','launch_i015_stability_postprocess.py']:shutil.copy2(H/n,U/n)
print(json.dumps({k:v for k,v in m.items() if k!='files'}))
