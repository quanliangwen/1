from pathlib import Path
import json,gzip,hashlib
from independent_raw_recount import verify
H=Path(__file__).resolve().parent;D=H/'research/cdf_pair_coverage_replay';out=D/'WITNESS_AUDIT.json';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if out.exists():raise RuntimeError('No replay witness audit overwrite')
r=json.load(open(D/'RESULT.json'));reg=json.load(open(D/'REGISTRATION.json'));prior=json.load(open(H/'research/D002_isolated_full_prefix/INDEPENDENT_FINAL_AUDIT.json'));old=json.loads(gzip.decompress((H/'iterations/I015_precision_closure/engineering39/result.json.gz').read_bytes()));cdf=old['extension']['hybrid']['cdf_pool_records'];pool={tuple(x['selection']):x for x in r['final_pool_records']};checks={}
if r['registration_sha256']!=sha(D/'REGISTRATION.json') or r['seconds']>reg['seconds'] or not {tuple(x['selection']) for x in cdf}<=set(pool) or not r['all_initial_retained']:raise RuntimeError('Replay registration/phase/retention differs')
for row in pool.values():
 c=row['certificate']
 if c['selection']!=row['selection'] or c['strict_event']!='sum<T' or not c['all_original_samples'] or 100*int(c['lower_numerator'])<99*int(c['denominator']):raise RuntimeError('Replay accepted member lacks raw99 certificate')
for label,selected in prior['selected_by_pool'].items():
 q=tuple(selected['selection'])
 if q not in pool:continue
 row=pool[q];raw=verify('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/'+old['instance'],q,old['capacity'],row['certificate']);checks[label]=dict(cost=row['cost'],raw_recount=raw,previous_original_LSS_point=selected['original_native_point'],same_validation_identity=True)
scans=[x for x in r['summary']['records'] if x['kind']=='joint_pair_neighborhood'];a=dict(passed=True,scope='external old-own-CDF replay generic pair coverage: retainedCDF, raw99 scalar gates and selected known witness independently raw-recounted; NOT a new cold solver, complete replay-pool native prefix or30-run Avg',result_sha256=sha(D/'RESULT.json'),seconds=r['seconds'],initial_pool=r['initial_pool'],final_pool=r['final_pool'],new_raw_candidates=r['new_raw_candidates'],new_original_LSS_calls=0,known_witnesses_reproduced=checks,pair_scans=len(scans),complete_group_pair_scans=sum(x['complete_pair_scan'] for x in scans),group_pairs_evaluated=sum(x['pairs_checked'] for x in scans),uncertainty_levels_executed=sorted(set(x['delta'] for x in scans)))
with out.open('x') as f:json.dump(a,f,indent=2)
print(json.dumps({k:v for k,v in a.items() if k!='known_witnesses_reproduced'}));print(json.dumps({k:dict(cost=v['cost'],native=v['previous_original_LSS_point']) for k,v in checks.items()}))
