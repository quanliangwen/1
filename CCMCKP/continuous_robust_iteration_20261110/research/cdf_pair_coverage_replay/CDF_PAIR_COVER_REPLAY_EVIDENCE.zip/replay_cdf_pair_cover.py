"""External old-own-CDF replay of generic pair coverage; not a cold solver."""
from pathlib import Path
import sys,json,gzip,time,copy,hashlib,os,random
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
import numpy as np
H=Path(__file__).resolve().parent;I=H/'iterations/I015_precision_closure';D=H/'research/cdf_pair_coverage_replay';D.mkdir(exist_ok=True);out=D/'RESULT.json';regfile=D/'REGISTRATION.json';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();sys.path[:0]=[str(I/'candidate'),str(I/'vendor313')]
from instance import load_instance
from risk_solver import StrictSolver
from pair_exchange import RobustPairs
if out.exists() or regfile.exists():raise RuntimeError('Pair replay already registered; inspect same process/evidence')
file=I/'engineering39/result.json.gz';old=json.loads(gzip.decompress(file.read_bytes()));cdf=old['extension']['hybrid']['cdf_pool_records'];meta=json.load(open(str(file)+'.run.json'));source={p.name:sha(p) for p in (I/'candidate').glob('*.py')};P=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/old['instance'];rawref=json.load(open(H/'RAW_REFERENCE.json'))
if source!=meta['source_sha256']:raise RuntimeError('Frozen actual I015 source changed')
for name,digest in meta['input_sha256'].items():
 if sha(P/name)!=digest or rawref[str(P/name)]!=digest:raise RuntimeError('Original raw input changed')
reg=dict(time=time.time(),scope='external post-search replay of generic unchanged RobustPairs on old I015 own176CDFpool; not new cold performance, stability/30Avg, or MC',old_result_sha256=sha(file),source_sha256=source,driver_sha256=sha(Path(__file__)),seconds=120,initial_pool=len(cdf),queue='all original generic group pairs/centers/risk layers; no historical vector or group IDs used to choose work',missing_old_base_rejections='replay retains CDF accepted+savedCDF rejected decisions; unsaved base refusals not recreated, so work may differ from fresh production',global_clock='simulate original elapsed base+CDF only to preserve original remaining555deadline; separate120second replay stage')
with regfile.open('x') as f:json.dump(reg,f,indent=2)
random.seed(old['seed']);np.random.seed(old['seed']);inst=load_instance(P);before=time.monotonic();base_elapsed=old['extension']['base_seconds']+old['extension']['hybrid']['cdf_seconds'];s=StrictSolver(inst,old['capacity'],old['seed'],600,D/'scratch_running.json.gz',before-base_elapsed,'B_CDF_DRO_MITM',risk_method='cdf_lns',phase_seconds=180);s.pool={tuple(r['selection']):copy.deepcopy(r) for r in cdf};s.decisions={q:r['certificate'] for q,r in s.pool.items()};s.native_cache={q:r['certificate']['lower'] for q,r in s.pool.items()};s.best=dict(min(s.pool.values(),key=lambda r:(r['cost'],r['selection'])));initial=set(s.pool)
def add_saved(value):
 if isinstance(value,dict):
  for r in value.get('checked',[]):
   q=tuple(r['selection']);decision=r.get('decision') or {}
   if q not in s.decisions and decision.get('infeasible'):s.decisions[q]=copy.deepcopy(decision)
  for key,v in value.items():
   if key!='checked':add_saved(v)
 elif isinstance(value,list):
  for v in value:add_saved(v)
add_saved(old['extension']['hybrid']['robust_cdf_lns']);start=time.monotonic();pairs=RobustPairs(s,reg['seconds']);pairs.run();elapsed=time.monotonic()-start
if not initial<=set(s.pool):raise RuntimeError('Pair replay removed prior ownCDFmember')
summary=pairs.summary();result=dict(scope=reg['scope'],registration_sha256=sha(regfile),seconds=elapsed,initial_pool=len(initial),final_pool=len(s.pool),new_raw_candidates=len(set(s.pool)-initial),all_initial_retained=True,summary=summary,final_pool_records=sorted(s.pool.values(),key=lambda r:(r['cost'],r['selection'])),new_MC_calls=0,source_sha256=source)
# Only now compare against previously validated witnesses as an external label.
validated=json.load(open(H/'research/D002_isolated_full_prefix/INDEPENDENT_FINAL_AUDIT.json'));result['posthoc_known_witness_presence']={label:dict(cost=r['cost'],present=tuple(validated['selected_by_pool'][label]['selection']) in s.pool) for label,r in validated['pools'].items()}
with out.open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k not in ['summary','final_pool_records','source_sha256']}),flush=True)
