from pathlib import Path
import json,subprocess,time
from isolated_original_lss import sha
H=Path(__file__).resolve().parent;S=H/'stability/I015_gain_case39';reg=json.load(open(S/'REGISTRATION.json'));receipt=json.load(open(S/'PRE_REG_REMOTE_VERIFIED.json'))
if any((S/n).exists() for n in ['LAUNCH.json','study.log','SEARCH_FINISHED','SEARCH_RESULT.json']):raise RuntimeError('Stability may already be running; inspect actual PID')
if not receipt['independent_remote_verification'] or receipt['registration_sha256']!=sha(S/'REGISTRATION.json') or reg['runner_sha256']!=sha(H/'run_i015_gain_stability39.py'):raise RuntimeError('Actual remote registered stability source/runner verification required')
for label,info in reg['sources'].items():
 if {p.name:sha(p) for p in (H/info['candidate']).glob('*.py')}!=info['source_sha256']:raise RuntimeError('Frozen source differs')
P=Path(reg['benchmark'])
for name,digest in reg['input_sha256'].items():
 if sha(P/name)!=digest:raise RuntimeError('Original raw input changed')
with (S/'study.log').open('x') as log:process=subprocess.Popen(['python3','-u',str(H/'run_i015_gain_stability39.py')],cwd=H,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
record=dict(time=time.time(),pid=process.pid,pre_registered_commit=receipt['commit'],registration_sha256=sha(S/'REGISTRATION.json'),workers=2,required_searches=6,source_files={k:len(v['source_sha256']) for k,v in reg['sources'].items()},scope=reg['scope'])
with (S/'LAUNCH.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record))
