from pathlib import Path
import json,time,os
from isolated_original_lss import sha
H=Path(__file__).resolve().parent;S=H/'stability/I015_gain_case39';S.mkdir(parents=True,exist_ok=True)
if (S/'REGISTRATION.json').exists():raise RuntimeError('Inspect existing stability registration instead of overwrite')
proof=json.load(open(H/'research/D002_isolated_full_prefix/INDEPENDENT_FINAL_AUDIT.json'))
if not proof['passed'] or not all(x['original_native_point']>=.985 for x in proof['pools'].values()):raise RuntimeError('Independently audited actual native gain required')
baseline=329.83616418693003
if proof['pools']['I015']['cost']>=baseline-1e-7:raise RuntimeError('Actual I015 joint gain required before fresh stability study')
sources={}
for label,iteration,method in [('I002_control','I002_cdf_neighborhood','cdf_lns'),('I015_hybrid','I015_precision_closure','cdf_blocks_precision')]:
 candidate=H/'iterations'/iteration/'candidate';fingerprint={p.name:sha(p) for p in candidate.glob('*.py')}
 expected=json.load(open(H/'formal/F001_I002_40x30/REGISTRATION.json'))['source_sha256'] if label=='I002_control' else json.load(open(H/'iterations/I015_precision_closure/engineering39/REGISTRATION.json'))['source_sha256']
 if fingerprint!=expected:raise RuntimeError('Previously frozen optimizer changed')
 sources[label]=dict(candidate=candidate.relative_to(H).as_posix(),method=method,source_sha256=fingerprint)
c=next(r for r in json.load(open(H/'CASES.json')) if r['index']==39);P=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/c['instance'];rawref=json.load(open(H/'RAW_REFERENCE.json'));inputs={}
for file in [P/'cost.txt',P/'node_to_factor.pkl']+list(p for p in P.glob('*_sample.txt') if not p.name.endswith('_big_sample.txt')):
 if sha(file)!=rawref[str(file)]:raise RuntimeError('Original benchmark changed')
 inputs[file.name]=sha(file)
memory={line.split(':')[0]:int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith(('MemAvailable:',))}
if memory['MemAvailable']<16*1024*1024 or len(os.sched_getaffinity(0))<2:raise RuntimeError('Insufficient resources for two additional cold searches')
reg=dict(time=time.time(),index=39,instance=c['instance'],benchmark=str(P),capacity=c['tmax'],sources=sources,seeds=[9715211,9715212,9715213],seconds=600,phase_seconds=180,watchdog=640,workers=2,pair_policy='same new seed/instance/capacity/budgets, two source variants start in same pair; whole pair finishes before next; all errors/timeouts retained without replacement',runner_sha256=sha(H/'run_i015_gain_stability39.py'),input_sha256=inputs,prior_joint_gain_audit_sha256=sha(H/'research/D002_isolated_full_prefix/INDEPENDENT_FINAL_AUDIT.json'),reference_costs=dict(I002_existing=baseline,I014_single_engineering=proof['pools']['I014']['cost'],I015_single_engineering=proof['pools']['I015']['cost']),initialization='fresh independent own raw-sample search; no prior vectors/scalars/true models/cache inside optimizer',validation_policy='after all6searches freeze: independent all-raw/source/input/budget/pool audit, then separately registered private full original-LSS cost-prefix on only each own pool; catalogue may be captured after all searches using fixed448+D001+D002 receipts; all reused logical seconds/new physical/speculation explicitly charged',scope='three new-seed paired development searches and later native validation; not30-run Avg or replacement of formal40x30',no_native_MC_during_this_controller=True,original_formal_queues_unchanged=True)
with (S/'REGISTRATION.json').open('x') as f:json.dump(reg,f,indent=2)
print(json.dumps(dict(registration_sha256=sha(S/'REGISTRATION.json'),seeds=reg['seeds'],required_searches=6,source_files={k:len(v['source_sha256']) for k,v in sources.items()},original_inputs=len(inputs))))
