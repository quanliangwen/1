"""Fresh matched I015/I016 DEVELOPMENT seeds, gated by audited cold native gain."""
from pathlib import Path
import json,time,os,sys
from isolated_original_lss import sha
H=Path(__file__).resolve().parent;D=H/'research/D004_I016_full_prefix';S=H/'stability/I016_pair_cover_case39'
if not (D/'INDEPENDENT_FINAL_AUDIT.json').exists():
 print(json.dumps(dict(ready=False,reason='actual D004 independent full prefix audit missing',new_searches=0)));sys.exit(0)
proof=json.load(open(D/'INDEPENDENT_FINAL_AUDIT.json'));post=json.load(open(D/'POSTPROCESS_TERMINAL.json'));prior=json.load(open(H/'research/D003_paired_stability_prefix/DEVELOPMENT_3SEED_STATISTICS.json'))
if not proof['passed'] or not post['passed'] or proof['result_sha256']!=sha(D/'RESULT.json') or set(proof['pools'])!={'I016'} or proof['pools']['I016']['original_native_point']<.985 or proof['pools']['I016']['cost']>prior['summaries']['I015_hybrid']['Best']+1e-9:raise RuntimeError('Actual cold I016 complete qualified prefix no worse than parent known Best required')
if S.exists() and (S/'REGISTRATION.json').exists():raise RuntimeError('Already registered; inspect actual study instead of overwrite')
seeds=[9716211,9716212,9716213];used=set();inspected=0
for folder in ['iterations','stability','formal','research']:
 for file in (H/folder).rglob('REGISTRATION.json'):
  r=json.load(open(file));used.update(r.get('seeds',[]))
  if isinstance(r.get('seed'),int):used.add(r['seed'])
  inspected+=1
for folder in ['iterations','stability','formal']:
 for file in (H/folder).rglob('*.run.json'):
  r=json.load(open(file))
  if isinstance(r.get('seed'),int):used.add(r['seed'])
  inspected+=1
if set(seeds)&used:raise RuntimeError('Proposed fresh search seed already registered or actually used')
sources={}
for label,iteration,method in [('I015_parent','I015_precision_closure','cdf_blocks_precision'),('I016_pair_cover','I016_cdf_pair_cover','cdf_pair_cover')]:
 I=H/'iterations'/iteration;candidate=I/'candidate';fingerprint={p.name:sha(p) for p in candidate.glob('*.py')};engineering=json.load(open(I/'engineering39/REGISTRATION.json'))
 if fingerprint!=engineering['source_sha256']:raise RuntimeError('Previously frozen optimizer changed')
 for name,digest in engineering['checks_sha256'].items():
  check=json.load(open(I/name))
  if sha(I/name)!=digest or not check['passed'] or check['source_sha256']!=fingerprint:raise RuntimeError('Matching actual source checks required')
 sources[label]=dict(candidate=candidate.relative_to(H).as_posix(),method=method,source_sha256=fingerprint)
c=next(r for r in json.load(open(H/'CASES.json')) if r['index']==39);P=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')/c['instance'];rawref=json.load(open(H/'RAW_REFERENCE.json'));inputs={}
for p in [P/'cost.txt',P/'node_to_factor.pkl']+[p for p in P.glob('*_sample.txt') if not p.name.endswith('_big_sample.txt')]:
 if sha(p)!=rawref[str(p)]:raise RuntimeError('Original raw input changed')
 inputs[p.name]=sha(p)
memory={line.split(':')[0]:int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')}
resources=dict(time=time.time(),available_cpus=len(os.sched_getaffinity(0)),available_memory_kib=memory['MemAvailable'])
if resources['available_cpus']<2 or resources['available_memory_kib']<16*1024*1024:raise RuntimeError('Insufficient two-worker resources')
S.mkdir(parents=True,exist_ok=True)
reg=dict(time=time.time(),index=39,instance=c['instance'],benchmark=str(P),capacity=c['tmax'],sources=sources,seeds=seeds,seconds=600,phase_seconds=180,watchdog=640,workers=2,pair_launch_order={str(seed):(list(sources) if seed%2 else list(reversed(sources))) for seed in seeds},pair_policy='same NEW seed/instance/capacity/shared budgets; two frozen variants within same pair, whole pair terminal before next; alternating nominal submission order; retain all failures/timeouts, no replacement',runner_sha256=sha(H/'run_i016_pair_stability39.py'),input_sha256=inputs,prior_joint_gain_audit_sha256=sha(D/'INDEPENDENT_FINAL_AUDIT.json'),prior_development_statistics_sha256=sha(H/'research/D003_paired_stability_prefix/DEVELOPMENT_3SEED_STATISTICS.json'),reference_costs_for_postanalysis_only=dict(I002_previous_3seed_Avg=prior['summaries']['I002_control']['Avg'],I015_previous_3seed_Best=prior['summaries']['I015_hybrid']['Best'],I015_previous_3seed_Avg=prior['summaries']['I015_hybrid']['Avg'],I016_single_cold=proof['pools']['I016']['cost']),fresh_seed_inventory_records_checked=inspected,resources=resources,initialization='fresh independent own raw-sample search; no prior vector/scalar/true-model/cache read by optimizer; CLI has no reference-cost or warmstart parameter',validation_policy='only after ALL6searches frozen and independently raw/source/input/budget/lineage audited: separately preregister fixed completed original-native catalogue and private full cost prefixes; every cheaper member terminal rejected before minimum confirmed; all failures retained; logical reused/native physical/speculative costs separately',scope='three NEW matched DEVELOPMENT search seeds per frozen version; inspect Avg cost AND Avg-ownBest/Std; not30formalAvg/significance/independent probability replications',native_protocol='original full real_P_test10million seed832273,sum<=Tpoint>=.985; original allsample strictsum<T integer>=.99',no_native_MC_during_this_controller=True,original_queues_unchanged=True)
with (S/'REGISTRATION.json').open('x') as f:json.dump(reg,f,indent=2)
print(json.dumps(dict(registration_sha256=sha(S/'REGISTRATION.json'),seeds=seeds,required_searches=6,source_files={k:len(v['source_sha256']) for k,v in sources.items()},original_inputs=len(inputs),fresh_seed_inventory_records_checked=inspected,resources=resources)))
