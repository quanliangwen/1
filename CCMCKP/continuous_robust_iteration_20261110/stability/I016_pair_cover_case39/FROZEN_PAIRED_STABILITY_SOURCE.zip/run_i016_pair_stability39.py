"""Three fresh matched search seeds: frozen I015 parent versus frozen I016 pair cover."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import json, subprocess, time, os, gzip
from isolated_original_lss import sha

H=Path(__file__).resolve().parent;S=H/'stability/I016_pair_cover_case39';reg=json.load(open(S/'REGISTRATION.json'));P=S/'search';P.mkdir(exist_ok=True)
if (S/'SEARCH_FINISHED').exists() or any(P.iterdir()):raise RuntimeError('Stability search may already be running/completed; never repeat')
def identities():
 if sha(H/'run_i016_pair_stability39.py')!=reg['runner_sha256']:raise RuntimeError('Registered stability controller changed')
 for name,info in reg['sources'].items():
  if {p.name:sha(p) for p in (H/info['candidate']).glob('*.py')}!=info['source_sha256']:raise RuntimeError('Frozen '+name+' optimizer changed')
identities()
def run_one(label,seed):
 identities();info=reg['sources'][label];base=P/(label+'_seed'+str(seed));out=base.with_name(base.name+'.json.gz');log=base.with_name(base.name+'.log');terminal=base.with_name(base.name+'.terminal.json');start=time.monotonic();exit_code=None;error=None;pid=None
 command=['/home/junhao/miniconda3/bin/python','-u',str(H/info['candidate']/'run.py'),'--instance',reg['benchmark'],'--capacity',str(reg['capacity']),'--risk-method',info['method'],'--seed',str(seed),'--seconds','600','--phase-seconds','180','--out',str(out)]
 try:
  with log.open('x') as stream:
   process=subprocess.Popen(command,cwd=H,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'),stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT);pid=process.pid
   with base.with_name(base.name+'.started.json').open('x') as f:json.dump(dict(pid=pid,label=label,seed=seed,time=time.time(),command=command),f,indent=2)
   try:exit_code=process.wait(timeout=reg['watchdog'])
   except subprocess.TimeoutExpired:process.kill();process.wait();exit_code='watchdog_timeout'
 except Exception as exception:error=str(exception);exit_code='setup_error'
 row=dict(label=label,seed=seed,pid=pid,exit=exit_code,error=error,actual_wall=time.monotonic()-start,output=out.relative_to(H).as_posix(),registration_sha256=sha(S/'REGISTRATION.json'))
 if exit_code==0:
  try:
   meta=json.load(open(str(out)+'.run.json'));data=json.loads(gzip.decompress(out.read_bytes()))
   if meta['source_sha256']!=info['source_sha256'] or meta['seed']!=seed or data['seed']!=seed or data['instance']!=reg['instance'] or data['capacity']!=reg['capacity'] or data['status']!='completed':raise RuntimeError('Actual search identity/status differs')
   row.update(elapsed=meta['elapsed'],within_budget=meta['within_budget'],raw_candidates=len(data['candidate_shortlist']),extension_seconds=data['extension']['extension_seconds'],phase_within_budget=data['extension']['extension_seconds']<=reg['phase_seconds'])
  except Exception as exception:row['error']=str(exception)
 with terminal.open('x') as f:json.dump(row,f,indent=2)
 return row
started=time.monotonic();rows=[]
with ThreadPoolExecutor(max_workers=2) as executor:
 for seed in reg['seeds']:
  (S/'STATE.json').write_text(json.dumps(dict(stage='paired_cold_search',seed=seed,time=time.time()),indent=2));futures=[executor.submit(run_one,label,seed) for label in reg['pair_launch_order'][str(seed)]]
  for future in as_completed(futures):
   row=future.result();rows.append(row);(S/'SEARCH_PROGRESS.json').write_text(json.dumps(dict(finished=len(rows),required=6,rows=rows,actual_wall=time.monotonic()-started,warning='raw search completion is not original-LSS qualification or30-run Avg'),indent=2));print(json.dumps(row),flush=True)
result=dict(rows=rows,required=6,actual_wall=time.monotonic()-started,errors=[r for r in rows if r['exit']!=0 or r['error'] or not r.get('within_budget') or not r.get('phase_within_budget')],scope='six real cold matched-seed searches only, native prefix validation still required; not30-run Avg')
with (S/'SEARCH_RESULT.json').open('x') as f:json.dump(result,f,indent=2)
(S/'SEARCH_FINISHED').write_text('all six search attempts terminal; inspect errors before validation\n');(S/'STATE.json').write_text(json.dumps(dict(stage='search_attempts_finished',time=time.time(),errors=len(result['errors'])),indent=2));print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
