# I002冻结开发源码

这是实际产生两项合格降本的I002开发源码，不是已完成40×30的最终性能声明。原16个Python文件与预注册一致；原LSS21个文件逐项核验、未经修改。别名兼容仅在reference_loader.py。

求解环境为Linux、Python3.13.9，requirements-search.txt列出实跑版本；原LSS验收为另一Python3.8.10环境，requirements-original-LSS.txt列出实跑依赖。benchmark数据不重复打包，使用服务器已有原始数据，逐项SHA见RAW_REFERENCE.json和LSS_DATA_REFERENCE.json。vendor313只是原服务器额外依赖搜索路径；若依赖已安装到独立Python环境，可为空目录。

单次样本搜索示例（容量100对应编号40；目标输出路径不能已有文件）：

```bash
python3.13 iterations/I002_cdf_neighborhood/candidate/run.py --instance /home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/APP_50_10_500_ --capacity 100 --seed 970211 --seconds 600 --risk-method cdf_lns --phase-seconds 180 --out output/one.json.gz
```

输出candidate_shortlist已按成本排序、每个向量有原样本整数概率下界≥0.99证书。最终结果还必须按该顺序用原LSS real_P_test逐个检验，选择首个点估计≥0.985的候选。native_lss_eval.py接受--instance、--capacity、JSON数组形式--selection及--out，并在原Python3.8环境调用；1000万次、种子832273、sum≤T。搜索与验收必须分开，求解器禁止读取真实分布参数、其他运行向量或验收缓存。

run_i002_pilot.py和validate_i002_pilot.py是实际开发试验驱动，保留原服务器路径；需本任务目录结构和原数据，不能误称跨机器直接运行的通用安装器。BASELINE_S10.json只供外部统计，求解器审计钩子禁止读取。完整开发结果、后续稳定性及未来正式统计见GitHub同任务目录。真实参数参与外部成本顺序后选择，此流程不能宣传为纯样本算法。
