from pathlib import Path
import json,ast
R=Path(__file__).resolve().parent;O=Path('E:/codex/S10_R02_R04_budget_campaign_20261127/R04')
s=(O/'audit_reader.py').read_text().replace("H=B/'work/r04_budget_fft_polish_20261127/formal'","H=Path(__file__).resolve().parent")
s=s.replace("REPS=int(os.environ.get('R04_AUDIT_REPS','30'));PILOT=REPS==5","REPS=int(os.environ.get('R05_AUDIT_REPS','5' if H.name=='smoke' else '30'));PILOT=REPS==5")
s=s.replace('def verify_models(raw,groups,costs,samples,capacity):','from r05_reader import verify_r05,verify_r05_timing\ndef verify_models(raw,groups,costs,samples,capacity):\n if raw[\'search_flow\']==\'dual_budget_gated\':return verify_r05(raw,groups,costs,samples,capacity)')
s=s.replace("['cvar_budget_calibrated','entropy_cdf_calibrated','cvar_budget_polish']","['cvar_budget_calibrated','entropy_cdf_calibrated','cvar_budget_polish','dual_budget_gated']")
s=s.replace("  transport_verified=check_transport_proofs(d,raw,flow[o['arm']])","  if flow[o['arm']]=='dual_budget_gated':verify_r05_timing(read(root/'R05_TIMING.json'),o['process_wall_seconds'])\n  transport_verified=check_transport_proofs(d,raw,flow[o['arm']])")
s=s.replace(" r.update(budget_proofs_verified=budget_verified,", " r.update(budget_proofs_verified=budget_verified,")
s=s.replace(" except Exception as e:r['errors']", "  if flow[o['arm']]=='dual_budget_gated':r['R05_funnel']={k:v for k,v in raw['R05_model'].items() if k not in ['certified_pool','parent_pool','ES95_pool','seeds','timing']};r['R05_timing']=read(root/'R05_TIMING.json')\n except Exception as e:r['errors']")
s=s.replace("'D_R04_BUDGET_FFT'","'D_R05_DUAL_GATED'").replace('R04_complete','R05_complete').replace('20261201','20261205').replace('20261202','20261206')
s=s.replace("report['formal360_started']=True","report['formal360_started']=H.name=='formal'")
s=s.replace("report['pilot_first5_counted_in_formal30']=PILOT","report['pilot_first5_counted_in_formal30']=PILOT and H.name=='formal'\nreport['separate_pre_freeze_smoke']=H.name=='smoke'")
ast.parse(s,feature_version=(3,8));(R/'audit_reader.py').write_text(s,encoding='utf-8')
s=(O/'controller.py').read_text().replace("pilot_verified=False","pilot_verified=H.name=='smoke'").replace("R04_AUDIT_REPS='5'","R05_AUDIT_REPS='5'")
s=s.replace("binary=H.parent/'bin/ccmckp_s10'","binary=H/arm.get('binary_relative','../bin/ccmckp_s10')")
ast.parse(s,feature_version=(3,8));(R/'controller.py').write_text(s,encoding='utf-8')
p=json.loads((O/'PROTOCOL_TEMPLATE.json').read_text());p['schema']='R05_dual_surrogate_gated_v1';p['seed_base']=1050000;p['seeds']=list(range(1050001,1050031));p.pop('R04',None)
p['R05']=json.loads((R/'FROZEN_PARAMETERS.json').read_text());p['R05']['stage0_adaptation_document']='冻结前适配说明.md';p['R05']['private_FFT_damping']=12
p['arms']=[{'name':'A_B01_ORIGINAL','flow':'block_mitm','gamma':None,'binary_relative':'../baseline_bin/ccmckp_s10'},{'name':'B_D02_TRANSPORT','flow':'block_winf_transport','gamma':None,'binary_relative':'../baseline_bin/ccmckp_s10'},{'name':'C_R04_BUDGET_FFT','flow':'cvar_budget_polish','gamma':None,'binary_relative':'../baseline_bin/ccmckp_s10'},{'name':'D_R05_DUAL_GATED','flow':'dual_budget_gated','gamma':None}]
p['repetitions']=30;p['total_runs']=360;p['first_wave_reps']=5;p['first_wave_runs']=60;p['source_and_binary_pins']={};p['sign_flip_seed']=20261205
p['primary_model_contrast']='R05 uniform dual surrogate certification gating versus fresh B01 D02 frozen R04; original LSS only'
p['smoke_seeds_excluded_from_formal']=list(range(1055001,1055006))
(R/'PROTOCOL_FORMAL_TEMPLATE.json').write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
p.update(schema='R05_separate15_functional_smoke_v1',seed_base=1055000,seeds=list(range(1055001,1055006)),repetitions=5,total_runs=15,first_wave_runs=15,max_workers=15,arms=[p['arms'][-1]])
p['smoke_gate']={'all15_independent_valid':True,'LAB50_all5_entropic_improved_to_observed_target':197.98645439880545,'LAB50_APP30_polish_CDF_cap_seconds':60.5,'APP30_all5_at_least2_ladder_records_cost_interval':[194.10,194.50],'APP30_safe_native_lower':.99005,'no_parameter_tuning_after_smoke':True,'fail_prevents_formal360':True}
(R/'PROTOCOL_SMOKE_TEMPLATE.json').write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
print('prepared smoke and formal protocols, controller and independent audit')
