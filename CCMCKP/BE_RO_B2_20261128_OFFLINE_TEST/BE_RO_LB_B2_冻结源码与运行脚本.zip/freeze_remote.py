from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil,os
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b2_20261128';F=H/'full40'
assert Path.cwd()==B and not F.exists()
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
V=read(H/'VALIDATION.json');RV=read(H/'READER_VALIDATION.json');P=read(H/'PROTOCOL_TEMPLATE.json')
assert V['status']==RV['status']=='PASS' and sha(H/'build/ccmckp_s10')==V['binary_sha256'] and sha(H/'audit_reader.py')==RV['production_reader_sha256']
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  argv=(p/'cmdline').read_bytes().split(b'\0')
  if any(str(B).encode() in a and (b'controller.py' in a or b'ccmckp_s10' in a or b'audit_reader.py' in a) for a in argv):active.append(int(p.name))
 except OSError:pass
assert not active,active
assert len(P['cases'])==40 and P['repetitions']==30 and len(P['arms'])==1 and P['total_runs']==1200 and P['max_workers']==60
old=read(B/'work/r07_adaptive_20261127/full40/PROTOCOL.json');assert set(P['seeds']).isdisjoint(old['seeds'])
assert sha(H/'USER_DESIGN.md')==P['user_design_sha256']
assert set(P['seeds']).isdisjoint(read(B/'work/be_ro_b1_20261128/full40/PROTOCOL.json')['seeds'])
inherit=read(H/'INHERITANCE.json')
for n,h in inherit['unchanged_files'].items():assert sha(H/'source'/n)==h,n
manifest=read(H/'source/BENCHMARK_MANIFEST.json');pins={}
for c in P['cases']:
 for n,h in manifest[c['instance']].items():
  p=B/'benchmark'/c['instance']/n;assert sha(p)==h,(c['instance'],n);pins['benchmark/'+c['instance']+'/'+n]=h
available=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
free=shutil.disk_usage(H).free
# Estimate compact output using the existing new-flow tiny records, plus a fixed margin.
estimated=max(2*2**30,1200*max(sum(p.stat().st_size for p in d.rglob('*') if p.is_file()) for d in (H/'integration').iterdir())*10)
required=max(6*2**30,2*estimated+2*2**30)
assert free>required and available>P['available_headroom_bytes']+P['worker_reserve_bytes'],(free,required,available)
(H/'bin').mkdir(exist_ok=True);shutil.copy2(H/'build/ccmckp_s10',H/'bin/ccmckp_s10')
F.mkdir()
for n in ['runs','outcomes','logs']:(F/n).mkdir()
support=['controller.py','audit_reader.py','be_reader.py','native_reader.py','r05_fft_reader.py','lb_reader.py']
for n in support:shutil.copy2(H/n,F/n)
P['source_and_binary_pins']={'../source/'+p.relative_to(H/'source').as_posix():sha(p) for p in (H/'source').rglob('*') if p.is_file()}
P['source_and_binary_pins']['../bin/ccmckp_s10']=sha(H/'bin/ccmckp_s10')
for n in ['USER_DESIGN.md','EXECUTION_NOTES.md','INHERITANCE.json','VALIDATION.json','READER_VALIDATION.json']:P['source_and_binary_pins']['../'+n]=sha(H/n)
for n in support:P['source_and_binary_pins'][n]=sha(F/n)
P['source_and_binary_pins']['../source/be_ro_lb_search.cpp']=sha(H/'source/be_ro_lb_search.cpp')
P['input_pins']=pins;P['registered_utc']=datetime.now(timezone.utc).isoformat()
(F/'PROTOCOL.json').write_text(json.dumps(P,ensure_ascii=False,indent=2))
r={'status':'FROZEN_BE_RO_LB_B2_FULL40_READY','utc':P['registered_utc'],'registered_runs':1200,'max_workers':60,'first40_technical_audit_then_remaining1160_automatic':True,'binary_sha256':sha(H/'bin/ccmckp_s10'),'protocol_sha256':sha(F/'PROTOCOL.json'),'source_pins':len(P['source_and_binary_pins']),'input_pins':len(pins),'available_GiB':available/2**30,'free_disk_GiB':free/2**30,'required_disk_GiB':required/2**30,'same_SHA_reused_B1_KKT_pretests':100,'new_LB_exhaustive_MILP_tests':V['new_LB_exhaustive_MILP_tests'],'tiny_integrations':5,'reader_tamper_checks':V['reader_tamper_checks'],'reader_full_record_replays':RV['full_record_reader_replays']}
(F/'FROZEN.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
