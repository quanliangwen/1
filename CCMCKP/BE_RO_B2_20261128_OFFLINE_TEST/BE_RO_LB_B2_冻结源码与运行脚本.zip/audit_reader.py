"""Read-only independent final audit. No solver or probability resampling."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction
from collections import Counter
import os,json,hashlib,pickle,csv,statistics,math
from be_reader import moments
from lb_reader import verify_lb
from native_reader import selected_model_count,integer_polynomial_count,grid_row
from r05_fft_reader import _private_fft_cache
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=Path(__file__).resolve().parent
assert Path.cwd()==B and B in H.parents
P=json.loads((H/'PROTOCOL.json').read_text());REPS=int(os.environ.get('BE_AUDIT_REPS','30'));pilot=REPS!=30
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
errors=[]
if sha(H/'PROTOCOL.json')!=read(H/'LAUNCH.json')['protocol_sha256']:errors.append('protocol_changed')
for n,h in P['source_and_binary_pins'].items():
 if sha(H/n)!=h:errors.append('source:'+n)
for n,h in P['input_pins'].items():
 if sha(B/n)!=h:errors.append('input:'+n)
outcomes=[read(p) for p in (H/'outcomes').glob('*.json') if read(p)['rep']<=REPS]
expected={(a['name'],c['index'],r) for a in P['arms'] for c in P['cases'] for r in range(1,REPS+1)}
if len(outcomes)!=len(expected) or {(x['arm'],x['case_index'],x['rep']) for x in outcomes}!=expected:errors.append('coverage_or_duplicates')
if not pilot:
 c=read(H/'COMPLETED.json')
 if c['terminal']!=P['total_runs'] or c['pending']!=0 or c['phase']!='completed':errors.append('not_naturally_complete')
rows=[];verified=0;math_proofs=0;native_proofs=0
def audit_model(root,raw,d,groups,costs,samples,capacity,params):
 global math_proofs,native_proofs
 stage1=read(root/'BE_RO_STAGE1.json');milestone=read(root/'BE_RO_STAGE1_MILESTONE.json')
 assert sha(root/'BE_RO_STAGE1.json')==milestone['stage1_raw_sha256'],'own_stage1_snapshot_SHA'
 v=verify_lb(raw,stage1,milestone,groups,costs,samples,capacity,params);math_proofs+=v['witnesses']
 for call in stage1['BE_RO_model']['native_calls']+raw['BE_RO_LB_model']['native_calls']:
  if 'certificate' not in call:continue
  cert=call['certificate'];s=call['selection'];lo,den=selected_model_count(d,s,cert['bins'],capacity,False)
  key=(tuple(s),cert['bins'],str(capacity));cache=d.setdefault('nominal_upper_cache',{})
  if key not in cache:cache[key]=integer_polynomial_count([grid_row(d,j,cert['bins'],Fraction(str(capacity)),False,False) for j in s],cert['bins'])
  hi,den2=cache[key]
  assert lo==int(cert['lower_numerator']) and hi==int(cert['upper_numerator']) and den==den2==int(cert['denominator']),'independent_native_integer_certificate'
  native_proofs+=1
 return v
for case in P['cases']:
 path=B/'benchmark'/case['instance'];g=pickle.loads((path/'node_to_factor.pkl').read_bytes());groups=[g[k] for k in sorted(g)] if isinstance(g,dict) else g
 costs=[float(x) for line in (path/'cost.txt').read_text().splitlines() for x in line.split('#')[0].split()]
 samples=[(path/('%d_sample.txt'%j)).read_text().split() for j in range(len(costs))];params=moments(samples)
 d={'path':path,'groups':groups,'costs':costs,'ordered':{},'cache':{}}
 for o in sorted((x for x in outcomes if x['case_index']==case['index']),key=lambda x:x['rep']):
  root=H/'runs'/o['identity'];r={k:o[k] for k in ['identity','case_index','instance','capacity','rep','seed','arm','rc','process_wall_seconds','termination_reason']};r.update(valid=False,errors=[])
  try:
   assert o['seed']==P['seed_base']+o['rep'] and o['instance']==case['instance'] and o['capacity']==case['tmax'],'identity'
   for n,h in o['output_files'].items():assert sha(root/n)==h['sha256'] and (root/n).stat().st_size==h['bytes'],n;verified+=1
   assert 0<o['process_wall_seconds']<=600 and o['wall_clock_source']=='dedicated_wait_thread_from_before_Popen','whole600'
   if o['rc'] or o['termination_reason'] is not None:
    if (root/'S10_search.json').exists() and (root/'BE_RO_STAGE1.json').exists():
     failed_raw=read(root/'S10_search.json')
     if failed_raw['status']=='completed':r['BE_statistics']=audit_model(root,failed_raw,d,groups,costs,samples,case['tmax'],params)
    if o['termination_reason'] is None:
     e=read(root/'FAILED.json')['error'];assert e in ['No completed LSS-accepted candidate before the wall deadline','No candidate passes final LSS acceptance (P >= 0.99)','phase wall deadline reached'],'unexpected_process_failure:'+e
    r['failure_class']='resource_or_wall_guard' if o['termination_reason'] else 'no_final_LSS_output';raise AssertionError('process_failure:'+r['failure_class'])
   raw=read(root/'S10_search.json');result=read(root/'RESULT.json');meta=read(root/'S10_search.run.json');complete=read(root/'COMPLETION.json');trace=read(root/'ORIGINAL_LSS_DECISION_TRACE.json');timing=read(root/'BE_RO_TIMING.json')
   assert raw['status']==result['status']=='completed' and raw['seed']==result['search_seed']==o['seed'] and raw['search_flow']==result['search_flow']=='be_ro_lb','status_seed_flow'
   assert raw['config']['no_cross_run_solutions'] and raw['config']['sampling_population']=='all_L_samples' and not raw['config']['real_probability_reporting'],'isolation'
   assert result['acceptance_evaluator']=='LSS' and result['acceptance_threshold']==.99 and result['final_lss_enforced'] and not result['real_probability_reporting'],'LSS_policy'
   assert result['lss_sample_index_min']==0 and result['lss_sample_index_max']==len(samples[0])-1,'sampling_indices'
   assert meta['elapsed']<=result['wall_seconds_including_LSS']<=complete['elapsed_before_completion_save']<=o['process_wall_seconds'] and complete['all_output_files_fsynced'] and complete['budget']==600 and complete['start_includes_process_launch'],'clock'
   assert meta['input_sha256']=={n:h for n,h in meta['input_sha256'].items() if h==P['input_pins']['benchmark/'+case['instance']+'/'+n]},'input_source'
   v=audit_model(root,raw,d,groups,costs,samples,case['tmax'],params)
   latest={};final={};evaluations=[]
   for q in trace:
    if 'evaluation' in q:
     assert 0<=q['probability']<=1 and 0<=q['elapsed_start']<=q['elapsed_end']<=590.1,'LSS_clock';latest[tuple(q['selection'])]=q;evaluations.append(q['evaluation'])
    if q['stage']=='LSS_final_acceptance':final[tuple(q['selection'])]=q
   assert evaluations==list(range(1,result['evaluation_times']+1)),'LSS_sequence'
   variants=result['original_output_variants'];assert len(variants)==3
   for q in variants:
    s=q['selection'];key=tuple(s);assert len(s)==len(groups) and all(j in g for j,g in zip(s,groups)),'selection'
    assert sum(costs[j] for j in s)==q['cost'] and q['probability']>=.99 and q['probability']==latest[key]['probability'] and final[key]['accepted'] and final[key]['source_evaluation']==latest[key]['evaluation'],'final_LSS_cost'
   assert result['selection']==variants[0]['selection'] and result['cost']==variants[0]['cost'] and result['original_LSS_confidence']==variants[0]['probability'],'main_output'
   candidates=[q for q in raw['BE_RO_LB_model']['certified_pool'] if q['selection']==result['selection']];assert candidates,'own_BE_pool'
   for q in raw['candidate_shortlist']:assert tuple(q['selection']) in {tuple(c['selection']) for c in raw['BE_RO_LB_model']['certified_pool']},'shortlist_source'
   t=timing['timing'];assert all(value>=-1e-6 for value in t.values()) and abs(sum(t.values())-timing['elapsed_before_timing_save'])<1e-5,'mutually_exclusive_timing'
   assert timing['elapsed_before_timing_save']<=complete['elapsed_before_completion_save'],'timing_clock'
   r.update(valid=True,cost=result['cost'],LSS=result['original_LSS_confidence'],selection=result['selection'],first_found_seconds=min(c['found_seconds'] for c in candidates),raw_best_cost=raw['selected']['cost'],BE_statistics=v,whole_seconds=o['process_wall_seconds'],timing=t,stage1_best_cost=raw['BE_RO_LB_model']['stage1_milestone']['stage1_bero_best_cost'],LB_rounds=len(raw['BE_RO_LB_model']['rounds']))
  except Exception as e:r['errors'].append(type(e).__name__+':'+str(e))
  rows.append(r)
  print(json.dumps({'identity':o['identity'],'valid':r['valid'],'errors':r['errors']}),flush=True)
 _private_fft_cache.clear()
groups_out=[]
for c in P['cases']:
 rr=[r for r in rows if r['case_index']==c['index']];vv=[r for r in rr if r['valid']];costs=[r['cost'] for r in vv];official=len(vv)==REPS and len(rr)==REPS
 best=min(costs) if costs else None;hit=[r for r in vv if r['cost']==best]
 groups_out.append({'case_index':c['index'],'instance':c['instance'],'capacity':c['tmax'],'terminal':len(rr),'valid':len(vv),'best_diagnostic':best,'official_best':best if official else None,'official_avg':statistics.mean(costs) if official else None,'official_std':statistics.stdev(costs) if official and len(vv)>1 else None,'valid_only_avg':statistics.mean(costs) if costs else None,'valid_only_std':statistics.stdev(costs) if len(costs)>1 else None,'best_hit_count':len(hit),'best_hit_first_mean_seconds':statistics.mean(r['first_found_seconds'] for r in hit) if official and hit else None,'whole_mean':statistics.mean(r['whole_seconds'] for r in vv) if official else None,'whole_max':max((r['process_wall_seconds'] for r in rr),default=None)})
report={'schema':'BE_RO_LB_B2_independent_full40_audit','utc':datetime.now(timezone.utc).isoformat(),'pilot':pilot,'terminal':len(rows),'independent_valid':sum(r['valid'] for r in rows),'global_errors':errors,'rows':rows,'groups':groups_out,'source_and_input_pins_unchanged':not errors,'files_sha_checked':verified,'KKT_witnesses_checked':math_proofs,'native_integer_certificates_checked':native_proofs,'sample_std_ddof':1,'probability_resampling':False,'final_gate':'unchanged original LSS >=.99'}
name='PILOT_INDEPENDENT_AUDIT.json' if pilot else 'FINAL_INDEPENDENT_AUDIT.json'
(H/name).write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:report[k] for k in ['terminal','independent_valid','global_errors','KKT_witnesses_checked','native_integer_certificates_checked']}),flush=True)
