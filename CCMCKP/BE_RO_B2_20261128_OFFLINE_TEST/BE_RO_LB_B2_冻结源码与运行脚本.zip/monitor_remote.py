from pathlib import Path
import os,json,hashlib,base64
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b2_20261128';F=H/'full40';assert Path.cwd()==B
read=lambda p:json.loads(p.read_text())
state=read(F/'STATE.json') if (F/'STATE.json').exists() else None
launch=read(F/'LAUNCH.json');pid=launch['pid'];p=Path('/proc/%d'%pid)
live=p.exists();proc={}
if live:
 proc={'pid':pid,'argv':[x.decode() for x in (p/'cmdline').read_bytes().split(b'\0') if x],'session':os.getsid(pid),'stdin':os.readlink(p/'fd/0'),'stdout':os.readlink(p/'fd/1'),'parent':int(next(x.split()[1] for x in (p/'status').read_text().splitlines() if x.startswith('PPid:')))}
outcomes=[read(x) for x in (F/'outcomes').glob('*.json')]
errors=[]
for o in outcomes:
 if o['rc']:
  f=F/'runs'/o['identity']/'FAILED.json';errors.append({'identity':o['identity'],'rc':o['rc'],'reason':o.get('termination_reason'),'failure':read(f) if f.exists() else None})
small={}
for name in ['FROZEN.json','LAUNCH.json','LAUNCH_REQUEST.json','STATE.json','COMPLETED.json','PILOT_CONTINUATION_DECISION.json','CONTROLLER_ERROR.json','FINAL_AUDIT_PROCESS.json']:
 if (F/name).exists():small[name]=read(F/name)
if (F/'PILOT_INDEPENDENT_AUDIT.json').exists():
 a=read(F/'PILOT_INDEPENDENT_AUDIT.json');small['pilot_summary']={k:a[k] for k in ['terminal','independent_valid','global_errors']};small['pilot_technical_errors']=[{'identity':r['identity'],'errors':r['errors']} for r in a['rows'] if any(not e.startswith('AssertionError:process_failure:') for e in r['errors'])]
files={}
for name in ['full40/PROTOCOL.json','full40/FROZEN.json','full40/LAUNCH.json','VALIDATION.json','READER_VALIDATION.json','READER_VALIDATION.log','INHERITANCE.json']:
 data=(H/name).read_bytes();files[name]={'base64':base64.b64encode(data).decode(),'sha256':hashlib.sha256(data).hexdigest()}
if (F/'PILOT_CONTINUATION_DECISION.json').exists():
 data=(F/'PILOT_CONTINUATION_DECISION.json').read_bytes();files['full40/PILOT_CONTINUATION_DECISION.json']={'base64':base64.b64encode(data).decode(),'sha256':hashlib.sha256(data).hexdigest()}
print(json.dumps({'controller_live':live,'process':proc,'state':state,'terminal':len(outcomes),'rc0':sum(x['rc']==0 for x in outcomes),'failures':errors,'metadata':small,'files':files,'controller_log_tail':(F/'controller.log').read_text()[-2000:]}))
