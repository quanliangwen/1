"""Independent B2 lineage, changed-group radius, risk-row and native ledger audit."""
from be_reader import verify_be
from r05_fft_reader import r05_private_tools
import math
def verify_lb(raw,stage1,milestone,groups,costs,samples,capacity,parameters=None):
 v=verify_be(stage1,groups,costs,samples,capacity,parameters)
 assert raw['search_flow']=='be_ro_lb' and raw['seed']==stage1['seed'] and raw['BE_RO_model']==stage1['BE_RO_model']
 m=raw['BE_RO_LB_model'];assert m['model']=='BE_RO_LB_B2' and m['K']==5 and m['k_changed_groups']==5 and m['binary_Hamming_upper']==10
 assert not m['historical_solution_inputs'] and not m['external_MIPstarts'] and not m['stage2_retains_BE_radius_constraint'] and not m['stage2_row_is_probability_certificate'] and not m['stage1_no_anchor_fallback']
 assert m['generator_LSS_calls']==0 and m['private_probability_cache_isolated'] and m['stage1_milestone']==milestone
 assert milestone['source_seed']==raw['seed'] and milestone['stage1_source']=='unchanged_B1_own_run_function'
 initial={tuple(q['selection']):q for q in stage1['BE_RO_model']['certified_pool']}
 assert len(initial)==milestone['stage1_certified_pool_size']
 expected=sorted(initial.values(),key=lambda q:(q['cost'],q['selection']))[:5];assert milestone['stage1_bero_topK']==expected
 assert milestone['stage1_bero_best_cost']==(stage1['selected']['cost'] if initial else None)
 final={tuple(q['selection']):q for q in m['certified_pool']}
 for key,q in initial.items():assert final[key]==q
 if not initial:
  assert m['stop_reason']=='no_own_stage1_certified_incumbent' and not m['queries'] and not m['native_calls'] and not m['candidates'] and not final
  return dict(v,LB_queries=0,LB_native_calls=0,LB_certified=0)
 selection,cost,prob,marginals,near=r05_private_tools(groups,costs,samples,capacity)
 accepted=dict(initial);best=tuple(stage1['selected']['selection']);epsilon=stage1['BE_RO_model']['epsilon_fft_final'];stall=0
 excluded={tuple(q['selection']) for q in stage1['BE_RO_model']['candidates']}|{tuple(q['selection']) for q in stage1['BE_RO_model']['native_calls']}|set(initial)
 initial_native={tuple(q['selection']) for q in stage1['BE_RO_model']['native_calls']};attempted=set(initial_native)
 calls={tuple(q['selection']):q for q in m['native_calls']};assert len(calls)==len(m['native_calls'])
 rounds={r['round']:r for r in m['rounds']};assert len(rounds)==len(m['rounds'])
 native_checked=0
 for index,q in enumerate(m['queries'],1):
  assert q['round']==index and stall<2 and q['anchor']==list(best) and q['best_before']==accepted[best]['cost']
  assert 0<=q['start']<=480 and q['start']<=q['finish']<=570 and not q['solver']['external_MIPstarts']
  assert q['solver']['PoolSearchMode']==2 and q['solver']['PoolSolutions']==20 and q['solver']['PoolGap']==1e100
  assert set(map(tuple,q['excluded']))==excluded and len(q['excluded'])==len(excluded)
  assert q['epsilon_before']==epsilon
  kth=sorted(r['cost'] for r in accepted.values())[4] if len(accepted)>=5 else None
  assert q['Kth_before']==kth and q['cutoff']==(kth-1e-6 if kth is not None else None)
  p,replacement=marginals(q['anchor']);near(q['anchor_probability'],p)
  assert len(q['risk'])==len(costs)
  for j,x in enumerate(q['risk']):near(x,p-replacement[j])
  assert abs(q['rhs']-(q['anchor_probability']-(.99-epsilon)))<1e-12
  raw_vectors=set(map(tuple,q['raw_solutions']));assert len(raw_vectors)==len(q['raw_solutions']) and not raw_vectors&excluded
  records=[r for r in m['candidates'] if r['round']==index]
  assert len({tuple(r['selection']) for r in records})==len(records) and {tuple(r['selection']) for r in records}<=raw_vectors
  before=accepted[best]['cost'];previous_cost=-math.inf
  for r in records:
   s=r['selection'];key=tuple(s);selection(s);assert key not in excluded;excluded.add(key)
   assert abs(r['cost']-float(cost(s)))<1e-8 and r['cost']>=previous_cost-1e-8;previous_cost=r['cost']
   distance=sum(a!=b for a,b in zip(s,q['anchor']));assert distance==r['distance_changed_groups']
   lhs=sum(q['risk'][j] for j in s);bad=distance<1 or distance>5 or lhs>q['rhs']+1e-8 or (q['cutoff'] is not None and r['cost']>q['cutoff']+1e-8)
   if r['decision']=='rounded_MIP_row_rejected':assert bad;continue
   assert not bad;near(r['private_probability'],prob(s));assert r['epsilon_before']==epsilon
   kth=sorted(x['cost'] for x in accepted.values())[4] if len(accepted)>=5 else None
   assert r['Kth_before']==kth
   if r['decision']=='dynamic_cost_cutoff':assert kth is not None and r['cost']>=kth-1e-6;continue
   if r['decision']=='private_FFT_rejected':assert r['private_probability']<.99-epsilon;continue
   assert r['decision']!='already_attempted' and key not in attempted and r['private_probability']>=.99-epsilon and (kth is None or r['cost']<kth-1e-6)
   attempted.add(key);c=calls[key];native_checked+=1
   assert c['round']==index and c['state']==r['decision'] and c['epsilon_before']==epsilon and c['private_probability']==r['private_probability']
   assert 0<=c['start']<=480 and c['start']<=c['finish']<=570.1 and c['slice_deadline']<=min(c['start']+90,570)+1e-5
   if c['hard_timeout']:assert c['state']=='unknown' and 'certificate' not in c
   if c['state']=='accepted':
    cert=c['certificate'];assert int(cert['lower_numerator'])*100>=99*int(cert['denominator'])
    assert key in final and final[key]['source']=='BE_RO_LB' and final[key]['certificate']==cert and final[key]['cost']==r['cost']
    assert c['start']<=final[key]['found_seconds']<=r['finish']
    accepted[key]=final[key]
    if r['cost']<accepted[best]['cost']-1e-8:best=key
    epsilon=max(epsilon,.001,.99-r['private_probability'])
   assert c['epsilon_after']==epsilon
  if index in rounds:
   closed=rounds[index];assert {tuple(r['selection']) for r in records}==raw_vectors
   assert closed['best_before']==before and closed['best_after']==accepted[best]['cost'] and closed['raw_empty']==(not raw_vectors)
   improved=accepted[best]['cost']<before-1e-8;stall=0 if improved else stall+1
   assert closed['improved']==improved and closed['stall_after']==stall
  else:assert m['stop_reason'] in ['global_new_call_deadline','new_call_deadline_after_MIP'] and index==len(m['queries'])
 if m['stop_reason']=='two_rounds_without_best_improvement':assert stall==2
 if m['stop_reason']=='no_MIP_candidate_not_infeasibility_proof':assert not m['queries'][-1]['raw_solutions']
 assert native_checked==len(calls) and set(final)==set(accepted) and epsilon==m['epsilon_fft_final']
 assert raw['selected']['selection']==list(best) and raw['selected']['cost']==accepted[best]['cost']
 assert not raw['match_history'] and not raw['local_history'] and not raw['block_history']
 return dict(v,LB_queries=len(m['queries']),LB_native_calls=native_checked,LB_certified=len(final)-len(initial))
