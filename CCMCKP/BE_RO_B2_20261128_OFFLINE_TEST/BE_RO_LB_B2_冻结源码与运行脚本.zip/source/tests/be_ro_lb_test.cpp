#include "be_ro_lb_rows.hpp"
#include "pool_model.hpp"
#include <iostream>
using namespace s10;
int main(int argc,char**argv){try{
 if(argc!=2)return 2;phase_deadline=now()+60;Instance d(argv[1]);if(d.m()!=6||d.n()!=12)throw std::runtime_error("6x2 fixture required");
 Selection anchor;for(const auto&g:d.groups)anchor.push_back(g[0]);Groups all{{}};for(const auto&g:d.groups){Groups next;for(const auto&s:all)for(int j:g){auto t=s;t.push_back(j);next.push_back(t);}all=next;}
 PoolModel solver(d,1289901);Json tests=Json::array();std::set<Selection> allseven;for(const auto&s:all)if(d.cost_of(s)==7)allseven.insert(s);
 for(int k=0;k<5;++k){Vector replacement(d.n(),1.);if(k==3)replacement[d.groups[0][1]]=.98;
  std::set<Selection>excluded;if(k==1)excluded.insert(*allseven.begin());if(k==4)excluded=allseven;
  double cutoff=k==2?6.5:k==4?7.5:INFINITY;BELBRows r(d,anchor,1.,replacement,.0015,5,excluded,cutoff);
  auto feasible=[&](const Selection&s){for(const auto&row:r.rows){double a=0;for(int j:s)a+=row.coefficients[j];if(a<row.lower-1e-9||a>row.upper+1e-9)return false;}return true;};
  double expected=INFINITY;int count=0;for(const auto&s:all)if(feasible(s)){expected=std::min(expected,d.cost_of(s));++count;}
  Json log;auto found=solver.solve(d.costs,r.rows,2.,20,1e100,log);double best=INFINITY;
  for(const auto&s:found){if(!feasible(s))throw std::runtime_error("LB row violation");best=std::min(best,d.cost_of(s));}
  if(std::isfinite(expected)!=std::isfinite(best)||(std::isfinite(best)&&std::abs(best-expected)>1e-10))throw std::runtime_error("Enumeration versus real LB MILP mismatch");
  tests.push_back({{"test",k},{"enumerated_feasible",count},{"best",std::isfinite(best)?Json(best):Json(nullptr)},{"solver",log}});
 }
 std::cout<<Json({{"status","PASS"},{"full_selections_enumerated",all.size()},{"tests",tests},{"radius_is_changed_groups_not_binary_bit_distance",true}}).dump()<<'\n';return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
