#pragma once
#include "mip.hpp"
#include <set>
#include <cmath>
namespace s10 {
struct BELBRows {
 Vector risk,trust;
 double rhs;
 std::vector<LinearRow> rows;
 BELBRows(const Instance&d,const Selection&anchor,double p,const Vector&replacement,double epsilon,int k,const std::set<Selection>&excluded,double cutoff)
 :risk(d.n()),trust(d.n()),rhs(p-(.99-epsilon)){
  d.validate(anchor);if(replacement.size()!=std::size_t(d.n())||k<1)throw std::logic_error("LB dimensions");
  for(int j=0;j<d.n();++j)risk[j]=p-replacement[j];
  for(int j:anchor)trust[j]=1;
  rows.push_back({risk,-INFINITY,rhs});
  // One option per group: changed_groups=G-sum(anchor x); binary Hamming=2*changed_groups.
  rows.push_back({trust,double(d.m()-k),double(d.m()-1)});
  if(std::isfinite(cutoff))rows.push_back({d.costs,-INFINITY,cutoff});
  for(const auto&s:excluded){d.validate(s);Vector a(d.n());for(int j:s)a[j]=1;rows.push_back({a,-INFINITY,double(d.m()-1)});}
 }
};
}
