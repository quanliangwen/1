#include "report.hpp"
#include "search.hpp"
#include <cmath>
#include <iostream>
#include <limits>
#include <sstream>
#include <cstdlib>
#include <fcntl.h>
#include <unistd.h>

namespace {
using namespace s10;

void usage() {
    std::cout <<
        "ccmckp_s10 --instance DIR --capacity T --seed N --out NEW_DIR [--rep N]\n"
        "ccmckp_s10 --index 1..40 --rep 1..30 --benchmark-root DIR --out NEW_DIR\n"
        "Options: --seconds 600 --local-phases none|pre|post|both\n"
        "         --search-flow ellipsoid_dominance|frontier_mitm|ellipsoid_costfront|ellipsoid_oa --ellipsoid-gamma 2.4\n"
        "         --ellipsoid-slice 5\n"
        "         --search-only [--cases CASES.json] [--manifest BENCHMARK_MANIFEST.json]\n"
        "Evaluation: --instance DIR --capacity T --seed N --evaluate ID,ID,...\n"
        "            [--bins 4096] [--draws N] [--lss-repeats N]\n";
}

unsigned long long natural(const std::string& text) {
    std::size_t used = 0;
    const auto value = std::stoull(text, &used);
    if (used != text.size() || text.empty() || text[0] == '-') throw std::runtime_error("Invalid integer " + text);
    return value;
}

double number(const std::string& text) {
    std::size_t used = 0;
    const auto value = std::stod(text, &used);
    if (used != text.size() || !std::isfinite(value)) throw std::runtime_error("Invalid number " + text);
    return value;
}

Selection selection(const std::string& text) {
    Selection result;
    std::istringstream in(text);
    for (std::string s; std::getline(in, s, ',');) {
        const auto id = natural(s);
        if (id > std::numeric_limits<int>::max()) throw std::runtime_error("Invalid item ID");
        result.push_back(static_cast<int>(id));
    }
    return result;
}

Json verify_inputs(const Instance& instance, const fs::path& manifest) {
    Json hashes = Json::object();
    const auto record = [&](const std::string& name) { hashes[name] = sha256(instance.path / name); };
    record("cost.txt");
    record("node_to_factor.pkl");
    for (int i = 0; i < instance.n(); ++i) record(std::to_string(i) + "_sample.txt");
    if (!manifest.empty()) {
        const auto baseline = read_json(manifest).at(instance.name);
        for (const auto& [file, hash] : hashes.items())
            if (baseline.at(file) != hash) throw std::runtime_error("Frozen input SHA256 mismatch: " + file);
    }
    return hashes;
}
} // namespace

int main(int argc, char** argv) {
    using namespace s10;
    const double entered=now();
    double process_started=entered;
    if (const char* p=std::getenv("CCMCKP_LAUNCH_MONOTONIC")) {
        process_started=std::stod(p);
        if (!(process_started<=entered && entered-process_started<10)) return 2;
    }
    fs::path failure_dir;
    try {
        std::map<std::string, std::string> args;
        std::set<std::string> flags;
        const std::set<std::string> keys{"instance", "capacity", "seed", "out", "index", "rep", "benchmark-root",
            "seconds", "local-phases", "cases", "manifest", "evaluate", "bins", "draws", "lss-repeats",
            "search-flow", "ellipsoid-gamma", "ellipsoid-slice"};
        for (int i = 1; i < argc; ++i) {
            const std::string option = argv[i];
            if (option == "--help") { usage(); return 0; }
            if (option == "--search-only") { flags.insert(option); continue; }
            if (option.rfind("--", 0) != 0 || !keys.count(option.substr(2)) || i + 1 == argc)
                throw std::runtime_error("Unknown or incomplete option " + option);
            if (!args.emplace(option.substr(2), argv[i + 1]).second)
                throw std::runtime_error("Duplicate option " + option);
            ++i;
        }
        const auto arg = [&](const std::string& key, const std::string& default_value = "") {
            auto it = args.find(key);
            return it == args.end() ? default_value : it->second;
        };
        const auto rep = natural(arg("rep", "1"));
        if (rep < 1 || rep > 30) throw std::runtime_error("rep must be 1..30");
        fs::path path = fs::u8path(arg("instance")), manifest = fs::u8path(arg("manifest"));
        std::string cap = arg("capacity"), seed_arg = arg("seed");
        const auto local = arg("local-phases", "none");
        if (local != "none" && local != "pre" && local != "post" && local != "both")
            throw std::runtime_error("Invalid local phase option");
        const std::string search_flow = arg("search-flow", "ellipsoid_dominance");
        if (search_flow != "be_ro_lb" && search_flow != "be_ro_pure" && search_flow != "adaptive_dual_gated" && search_flow != "quality_dual_gated" && search_flow != "dual_budget_gated" && search_flow != "cvar_budget_polish" && search_flow != "entropy_cdf_calibrated" && search_flow != "cvar_budget_calibrated" && search_flow != "budget_robust" && search_flow != "block_winf_transport" && search_flow != "block_insurance" && search_flow != "block_winf_dro" && search_flow != "block_mitm" && search_flow != "frontier_mitm_zero" && search_flow != "ellipsoid_oa" && search_flow != "frontier_mitm" && search_flow != "ellipsoid_costfront" && (search_flow != "ellipsoid_dominance" && search_flow != "ellipsoid_costpriority" && search_flow != "ellipsoid_momentbound" && search_flow != "ellipsoid_corecuts"))
            throw std::runtime_error("Invalid search flow");
        const double gamma = number(arg("ellipsoid-gamma", "2.4"));
        const double slice = number(arg("ellipsoid-slice", "5"));
        if (gamma < 0 || gamma > 100) throw std::runtime_error("ellipsoid-gamma must be 0..100");
        if (slice < .1 || slice > 30) throw std::runtime_error("ellipsoid-slice must be .1..30 seconds");
        const auto seconds = number(arg("seconds", "600"));
        if (seconds < 30 || seconds > 600) throw std::runtime_error("seconds must be 30..600");

        unsigned long long index = 0;
        if (args.count("index")) {
            if (!path.empty() || !cap.empty() || !seed_arg.empty() || arg("benchmark-root").empty())
                throw std::runtime_error("Use --index with --benchmark-root, or use explicit instance, capacity and seed");
            index = natural(arg("index"));
            if (index < 1 || index > 40) throw std::runtime_error("index must be 1..40");
            auto directory = fs::absolute(fs::u8path(argv[0])).parent_path();
            const auto cases = read_json(fs::u8path(arg("cases", (directory / "CASES.json").u8string())));
            const auto found = std::find_if(cases.begin(), cases.end(), [&](const Json& c) { return c.at("index") == index; });
            if (found == cases.end()) throw std::runtime_error("Case index missing");
            path = fs::u8path(arg("benchmark-root")) / found->at("instance").get<std::string>();
            cap = found->at("tmax").dump();
            seed_arg = std::to_string(960000 + rep);
            if (manifest.empty()) manifest = directory / "BENCHMARK_MANIFEST.json";
        }
        if (path.empty() || cap.empty() || seed_arg.empty()) { usage(); return 2; }
        const double capacity = number(cap);
        if (capacity <= 0) throw std::runtime_error("Capacity must be positive");
        cap = Json(capacity).dump(); // Match Fraction(str(parsed_float)) in the frozen runner.
        const auto seed_number = natural(seed_arg);
        if (seed_number > 2000000000ULL)
            throw std::runtime_error("Seed exceeds Gurobi's supported range");
        const auto seed = static_cast<std::uint32_t>(seed_number);

        if (args.count("evaluate")) {
            Instance instance(path);
            const auto s = selection(arg("evaluate"));
            instance.validate(s);
            const auto bins = natural(arg("bins", "4096"));
            if (bins < 2 || bins > 1048576) throw std::runtime_error("bins must be 2..1048576");
            const auto draws = natural(arg("draws", "1000000"));
            const auto repeats = natural(arg("lss-repeats", "1"));
            if (!draws || !repeats) throw std::runtime_error("Draw and repetition counts must be positive");
            LssEvaluator lss(instance, capacity, seed, draws);
            ExactOracle oracle(instance, cap);
            Search probe(instance, {capacity, cap, seed, seconds, local, {}}, now());
            const auto& idx = probe.screen_indices();
            const auto preview_end = idx.begin() + std::min<std::size_t>(64, idx.size());
            Json samples = Json::array();
            for (unsigned long long i = 0; i < repeats; ++i) samples.push_back(lss.evaluate(s));
            Json out = {{"grid", oracle.certify(s, static_cast<int>(bins)).json(s)},
                        {"lss", samples}, {"lss_quick", lss.quick_checks()}, {"native_quick", probe.quick_checks()},
                        {"pcg_int16_first_64", std::vector<std::uint16_t>(idx.begin(), preview_end)}};
            std::cout << out.dump() << '\n';
            return 0;
        }

        const auto output = fs::u8path(arg("out"));
        if (output.empty() || fs::exists(output)) throw std::runtime_error("--out must be a new directory");
        if (!fs::create_directories(output)) throw std::runtime_error("Cannot reserve output directory");
        failure_dir = output;

        const double started=process_started;
        setenv("CCMCKP_TOTAL_WALL_POLICY","launch_to_exit_600",1);
        phase_deadline=started+seconds-std::min((search_flow=="be_ro_lb"||search_flow=="be_ro_pure"||search_flow=="quality_dual_gated"||search_flow=="adaptive_dual_gated")?120.:170.,seconds*.3);
        const double load_started = now();
        Instance instance(path);
        const double load_seconds = now() - load_started;
        const auto input_hashes = verify_inputs(instance, manifest);
        std::optional<LssEvaluator> lss;
        if (!flags.count("--search-only")) lss.emplace(instance, capacity, seed);
        const double search_started = now();
        check_budget();
        Options search_options{capacity, cap, seed, seconds, local, output / "S10_search.json"};
        search_options.search_flow = search_flow;
        search_options.ellipsoid_gamma = gamma;
        search_options.ellipsoid_slice = slice;
        Search search(instance, search_options, started);
        const auto raw = search.run();
        const double elapsed = now() - started;
        Json metadata = {{"schema", "S10_raw_constraint_portfolio_worker"}, {"elapsed", elapsed},
            {"load_seconds",load_seconds},{"startup_until_search_seconds",search_started-started},
            {"within_budget", elapsed <= seconds}, {"selected", raw.at("selected")},
            {"seed", seed}, {"budget", seconds}, {"backend", "gurobi"}, {"local_phases", local},
            {"search_flow", search_flow}, {"ellipsoid_gamma", gamma}, {"ellipsoid_slice", slice},
            {"phase_records", search.phase_records}, {"input_sha256", input_hashes}};
        write_json(output / "S10_search.run.json", metadata);

        if (!metadata.at("within_budget").get<bool>()) throw std::runtime_error("S10 search exceeded its wall-clock budget");
        if (lss) {
            phase_deadline=started+seconds-std::min(10.,seconds*.1);
            const double lss_started=now();
            auto result = report(instance, capacity, seed, static_cast<int>(rep), raw.at("candidate_shortlist"),
                                 *lss, output, started);
            result["LSS_finalization_seconds"]=now()-lss_started;
            result["clock_policy"]="launch_to_exit_total_wall";
            result["total_budget_seconds"]=seconds;
            result["backend"] = "gurobi";
            result["local_phases"] = local;
            result["arm"] = search_flow == "frontier_mitm" ?
                (local == "none" ? "G_NONE" : "gurobi_" + local) : "EGS_OA_" + local;
            if(search_flow=="adaptive_dual_gated"||search_flow=="quality_dual_gated"||search_flow=="dual_budget_gated"||search_flow=="cvar_budget_polish"||search_flow=="entropy_cdf_calibrated"||search_flow=="cvar_budget_calibrated"||search_flow=="budget_robust"||search_flow=="block_mitm"||search_flow=="frontier_mitm_zero"||search_flow=="block_insurance"||search_flow=="block_winf_dro"||search_flow=="block_winf_transport")result["arm"]=search_flow;
            if(search_flow=="be_ro_pure")result["arm"]="BE_RO_PURE";
            if(search_flow=="be_ro_lb")result["arm"]="BE_RO_LB";
            result["search_flow"] = search_flow;
            result["ellipsoid_gamma"] = gamma;
            result["ellipsoid_slice"] = slice;
            if (index) result["case_index"] = index;
            result["phase_records"] = search.phase_records;
            result["raw_best_cost"] = raw.at("selected").at("cost");
            result["S10_worker_search_seconds"] = elapsed;
            result["S10_candidates"] = raw.at("candidate_shortlist").size();
            result["S10_exhaustive"] = raw.at("exhaustive");
            if(search_flow=="adaptive_dual_gated"||search_flow=="quality_dual_gated"||search_flow=="dual_budget_gated"||search_flow=="cvar_budget_polish"||search_flow=="cvar_budget_calibrated"||search_flow=="entropy_cdf_calibrated") {
                std::set<Selection> accepted;
                for(const auto& q:read_json(output/"ORIGINAL_LSS_DECISION_TRACE.json"))
                    if(q.value("stage",std::string())=="LSS_final_acceptance"&&q.value("accepted",false))accepted.insert(q.at("selection").get<Selection>());
                result["stage4_lss_final"]={{"shortlist_submitted",raw.at("candidate_shortlist").size()},{"lss_accepted_count",accepted.size()},
                    {"lss_seconds",result["LSS_finalization_seconds"]},{"final_best_cost",result["cost"]},{"generator_observed_LSS",false}};
            }
            const double save_started=now();
            result["wall_seconds_including_LSS"] = now() - started;
            write_json(output / "RESULT.json", result);
            // Persist every output before recording successful completion.
            for(const auto& entry:fs::recursive_directory_iterator(output)) if(entry.is_regular_file()) {
                const int fd=::open(entry.path().c_str(),O_RDONLY);
                if(fd<0 || ::fsync(fd)!=0) throw std::runtime_error("Output fsync failed");
                ::close(fd);
            }
            if(search_flow=="adaptive_dual_gated"||search_flow=="quality_dual_gated"||search_flow=="dual_budget_gated") {
                auto timing=raw.at(search_flow=="adaptive_dual_gated"?"r07_timing_breakdown_sec":search_flow=="quality_dual_gated"?"r06_timing_breakdown_sec":"r05_timing_breakdown_sec");
                timing["final_lss"]=result["LSS_finalization_seconds"];
                timing["save_and_fsync"]=now()-save_started;
                const double t=now()-started;double accounted=0;
                for(const auto& z:timing.items())if(z.key()!="unaccounted_overhead")accounted+=z.value().get<double>();
                timing["unaccounted_overhead"]=t-accounted;
                const std::string timing_name=search_flow=="adaptive_dual_gated"?"R07_TIMING.json":search_flow=="quality_dual_gated"?"R06_TIMING.json":"R05_TIMING.json";
                write_json(output/timing_name,{{"timing",timing},{"elapsed_before_timing_save",t},{"elapsed_includes_launch",true}});
                const int tf=::open((output/timing_name).c_str(),O_RDONLY);::fsync(tf);::close(tf);
            }
            if(search_flow=="be_ro_pure") {
                auto timing=raw.at("BE_RO_model").at("timing");
                timing["final_lss"]=result["LSS_finalization_seconds"];
                timing["save_and_fsync"]=now()-save_started;
                const double t=now()-started;double accounted=0;
                for(const auto& z:timing.items())accounted+=z.value().get<double>();
                timing["unaccounted_overhead"]=t-accounted;
                write_json(output/"BE_RO_TIMING.json",{{"timing",timing},{"elapsed_before_timing_save",t},{"elapsed_includes_launch",true}});
                const int tf=::open((output/"BE_RO_TIMING.json").c_str(),O_RDONLY);::fsync(tf);::close(tf);
            }
            if(search_flow=="be_ro_lb") {
                auto timing=raw.at("BE_RO_LB_model").at("timing");
                timing["final_lss"]=result["LSS_finalization_seconds"];
                timing["save_and_fsync"]=now()-save_started;
                const double t=now()-started;double accounted=0;
                for(const auto& z:timing.items())accounted+=z.value().get<double>();
                timing["unaccounted_overhead"]=t-accounted;
                write_json(output/"BE_RO_TIMING.json",{{"timing",timing},{"elapsed_before_timing_save",t},{"elapsed_includes_launch",true}});
                const int tf=::open((output/"BE_RO_TIMING.json").c_str(),O_RDONLY);::fsync(tf);::close(tf);
            }
            const double full_elapsed=now()-started;
            if(full_elapsed>=seconds-1) throw std::runtime_error("Full pipeline exceeded guarded total wall allowance");
            write_json(output/"COMPLETION.json", {{"elapsed_before_completion_save",full_elapsed},
                {"budget",seconds},{"all_output_files_fsynced",true},{"start_includes_process_launch",true},
                {"clock_policy","launch_to_exit_total_wall"}});
            const int fd=::open((output/"COMPLETION.json").c_str(),O_RDONLY);::fsync(fd);::close(fd);
            const int dfd=::open(output.c_str(),O_RDONLY|O_DIRECTORY);::fsync(dfd);::close(dfd);
            std::cout << Json({{"status","completed"},{"cost",result["cost"]},
                {"elapsed",now()-started}}).dump() << '\n';
        } else std::cout << metadata.dump() << '\n';
        return 0;
    } catch (const std::exception& error) {
        if (!failure_dir.empty()) {
            try { write_json(failure_dir / "FAILED.json", {{"status", "failed"}, {"error", error.what()}}); }
            catch (...) {}
        }
        std::cerr << "S10: " << error.what() << '\n';
        return 1;
    }
}
