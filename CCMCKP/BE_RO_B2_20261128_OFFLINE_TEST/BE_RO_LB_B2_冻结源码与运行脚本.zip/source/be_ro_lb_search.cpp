#include "search.hpp"
#include "be_ro_lb_rows.hpp"
#include "isolated_native.hpp"
namespace s10 {
namespace {int be_distance(const Selection&a,const Selection&b){int k=0;for(std::size_t g=0;g<a.size();++g)k+=a[g]!=b[g];return k;}}
Json Search::be_ro_lb_run(){
 // The exact unchanged B1 entry point runs on THIS run's fresh model and pool.
 options.search_flow="be_ro_pure";Json stage1;
 try{stage1=be_ro_run();}catch(...){options.search_flow="be_ro_lb";throw;}
 options.search_flow="be_ro_lb";
 const auto directory=options.output.parent_path();
 write_json(directory/"BE_RO_STAGE1.json",stage1);
 std::set<Selection> keys;for(const auto&q:pool)keys.insert(q.first);
 Json top=Json::array();for(const auto&s:cost_order(keys)){if(top.size()==5)break;top.push_back(pool.at(s).json());}
 Json milestone={{"stage1_bero_best_cost",best?Json(best->cost):Json(nullptr)},{"stage1_bero_topK",top},{"stage1_certified_pool_size",pool.size()},{"elapsed_before_LB",now()-started},{"source_seed",options.seed},{"stage1_source","unchanged_B1_own_run_function"},{"stage1_raw_sha256",sha256(directory/"BE_RO_STAGE1.json")}};
 write_json(directory/"BE_RO_STAGE1_MILESTONE.json",milestone);
 for(const char*n:{"BE_RO_STAGE1.json","BE_RO_STAGE1_MILESTONE.json"}){int fd=::open((directory/n).c_str(),O_RDONLY);if(fd<0||::fsync(fd))throw std::runtime_error("Stage1 fsync failed");::close(fd);}
 be_ro_lb_log={{"model","BE_RO_LB_B2"},{"K",5},{"k_changed_groups",5},{"binary_Hamming_upper",10},{"historical_solution_inputs",false},{"external_MIPstarts",false},{"stage1_milestone",milestone},{"stage2_retains_BE_radius_constraint",false},{"stage2_row_is_probability_certificate",false},{"generator_LSS_calls",0},{"private_probability_cache_isolated",true},{"stage1_no_anchor_fallback",false},{"queries",Json::array()},{"candidates",Json::array()},{"native_calls",Json::array()},{"rounds",Json::array()},{"timing",stage1.at("BE_RO_model").at("timing")}};
 be_ro_lb_log["timing"]["lb_mip_fft"]=0.;be_ro_lb_log["timing"]["lb_native_cdf"]=0.;
 if(!best){be_ro_lb_log["stop_reason"]="no_own_stage1_certified_incumbent";be_ro_lb_log["stop_seconds"]=now()-started;return save("completed");}
 double epsilon=be_ro_log.at("epsilon_fft_final").get<double>();
 std::set<Selection> excluded,native_attempted;
 for(const auto&q:be_ro_log.at("candidates"))excluded.insert(q.at("selection").get<Selection>());
 for(const auto&q:be_ro_log.at("native_calls")){auto s=q.at("selection").get<Selection>();excluded.insert(s);native_attempted.insert(s);}
 for(const auto&q:pool)excluded.insert(q.first);
 const double begin=now();double native_seconds=0;
 auto kth=[&]()->double{if(pool.size()<5)return INFINITY;std::set<Selection>s;for(const auto&q:pool)s.insert(q.first);return pool.at(cost_order(s)[4]).cost;};
 auto native=[&](const Selection&s,double probability,int round){
  check_budget();const double b=now();if(b>=deadline)throw BudgetExpired();native_attempted.insert(s);
  const double end=std::min(b+90.,started+options.seconds-30.);const int oldcalls=oracle.calls;const double oldseconds=oracle.seconds;
  auto child=isolated_native(end,[&](){
   deadline=started+options.seconds-30.;phase_deadline=end;last_save=now()+1e9;
   bool expired=false;try{native_check(s,"BE_RO_LB");}catch(const BudgetExpired&){expired=true;}
   Json z={{"expired",expired},{"state",pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown"},{"calls_delta",oracle.calls-oldcalls},{"seconds_delta",oracle.seconds-oldseconds}};
   if(pool.count(s))z["certificate"]=pool.at(s).certificate.json(s);else if(infeasible_proofs.count(s))z["certificate"]=infeasible_proofs.at(s).json(s);return z;
  });
  Json call={{"selection",s},{"cost",instance.cost_of(s)},{"round",round},{"start",b-started},{"finish",now()-started},{"slice_deadline",end-started},{"hard_timeout",child.timeout},{"elapsed",child.elapsed},{"state","unknown"},{"epsilon_before",epsilon},{"private_probability",probability}};
  if(!child.timeout){auto&z=child.payload;call["state"]=z["state"];call["expired"]=z["expired"];oracle.calls+=z["calls_delta"].get<int>();oracle.seconds+=z["seconds_delta"].get<double>();
   if(z.contains("certificate")){auto c=z["certificate"];call["certificate"]=c;Certificate cert{mpz_class(c["lower_numerator"].get<std::string>()),mpz_class(c["upper_numerator"].get<std::string>()),mpz_class(c["denominator"].get<std::string>()),c["bins"].get<int>(),c["certificate_seconds"].get<double>()};
    if(z["state"]=="accepted"){accept(s,"BE_RO_LB",cert);epsilon=std::max(epsilon,std::max(.001,.99-probability));}
    else if(z["state"]=="infeasible"){infeasible_proofs.insert_or_assign(s,cert);decisions[s]=cert.probability();}
   }
  }
  native_seconds+=now()-b;call["epsilon_after"]=epsilon;be_ro_lb_log["native_calls"].push_back(call);return call.at("state").get<std::string>();
 };
 int stall=0,round=0;
 try{
  check_budget();PolishFFT fft(instance.samples,instance.groups,options.capacity,8192,12);PoolModel lb(instance,options.seed);
  while(now()<deadline&&stall<2){
   check_budget();const Selection anchor=best->selection;const double before=best->cost;auto p=fft.marginals(anchor);
   const double cap=kth(),cut=std::isfinite(cap)?cap-1e-6:INFINITY;BELBRows row(instance,anchor,p.first,p.second,epsilon,5,excluded,cut);
   check_budget();const double b=now();if(b>=deadline)throw BudgetExpired();++round;
   Json q={{"round",round},{"start",b-started},{"anchor",anchor},{"best_before",before},{"Kth_before",std::isfinite(cap)?Json(cap):Json(nullptr)},{"cutoff",std::isfinite(cut)?Json(cut):Json(nullptr)},{"anchor_probability",p.first},{"epsilon_before",epsilon},{"risk",row.risk},{"rhs",row.rhs},{"excluded",Json::array()},{"raw_solutions",Json::array()}};
   for(const auto&s:excluded)q["excluded"].push_back(s);
   // A call already launched before 480 may finish its registered 2s slice.
   const double prior=phase_deadline;phase_deadline=started+options.seconds-30.;Json solverlog;Groups all;
   try{all=lb.solve(instance.costs,row.rows,2.,20,1e100,solverlog);}catch(...){phase_deadline=prior;throw;}
   phase_deadline=prior;++models;model_seconds+=now()-b;
   q["finish"]=now()-started;q["solver"]=solverlog;q["raw_solutions"]=all;be_ro_lb_log["queries"].push_back(q);
   if(now()>=deadline){be_ro_lb_log["stop_reason"]="new_call_deadline_after_MIP";break;}
   std::set<Selection> distinct(all.begin(),all.end());Groups ordered=cost_order(distinct);
   for(const auto&s:ordered){
    check_budget();if(excluded.count(s))continue;excluded.insert(s);const int distance=be_distance(s,anchor);double lhs=0;for(int j:s)lhs+=row.risk[j];
    if(distance<1||distance>5||lhs>row.rhs+1e-8||(std::isfinite(cut)&&instance.cost_of(s)>cut+1e-8)){
     be_ro_lb_log["candidates"].push_back({{"selection",s},{"round",round},{"cost",instance.cost_of(s)},{"decision","rounded_MIP_row_rejected"},{"distance_changed_groups",distance},{"risk_lhs",lhs},{"epsilon_before",epsilon}});continue;
    }
    const double score=fft.probability(s),current=kth();
    Json r={{"selection",s},{"cost",instance.cost_of(s)},{"round",round},{"distance_changed_groups",distance},{"private_probability",score},{"epsilon_before",epsilon},{"Kth_before",std::isfinite(current)?Json(current):Json(nullptr)},{"start",now()-started}};
    if(std::isfinite(current)&&instance.cost_of(s)>=current-1e-6)r["decision"]="dynamic_cost_cutoff";
    else if(score<.99-epsilon)r["decision"]="private_FFT_rejected";
    else if(pool.count(s)||native_attempted.count(s))r["decision"]="already_attempted";
    else r["decision"]=native(s,score,round);
    r["finish"]=now()-started;be_ro_lb_log["candidates"].push_back(r);
   }
   const bool improved=best->cost<before-1e-8;stall=improved?0:stall+1;
   be_ro_lb_log["rounds"].push_back({{"round",round},{"best_before",before},{"best_after",best->cost},{"improved",improved},{"stall_after",stall},{"raw_empty",all.empty()}});
   if(all.empty()){be_ro_lb_log["stop_reason"]="no_MIP_candidate_not_infeasibility_proof";break;}
  }
  if(!be_ro_lb_log.contains("stop_reason"))be_ro_lb_log["stop_reason"]=stall>=2?"two_rounds_without_best_improvement":"new_call_deadline";
 }catch(const BudgetExpired&){be_ro_lb_log["stop_reason"]="global_new_call_deadline";be_ro_lb_log["partial"]=true;}
 be_ro_lb_log["epsilon_fft_final"]=epsilon;be_ro_lb_log["stop_seconds"]=now()-started;be_ro_lb_log["timing"]["lb_mip_fft"]=now()-begin-native_seconds;be_ro_lb_log["timing"]["lb_native_cdf"]=native_seconds;
 return save("completed");
}
void Search::be_ro_lb_save_fields(Json&data){
 if(options.search_flow!="be_ro_lb")return;
 be_ro_lb_log["certified_pool"]=Json::array();for(const auto&q:pool)be_ro_lb_log["certified_pool"].push_back(q.second.json());
 data["BE_RO_model"]=be_ro_log;data["BE_RO_LB_model"]=be_ro_lb_log;
 data["config"]["LSS_reserve_seconds"]=120.;data["config"]["search_launch_deadline_seconds"]=480.;data["config"]["maximum_started_native_finish_seconds"]=570.;data["config"]["native_single_call_seconds"]=90.;
}
}
