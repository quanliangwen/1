from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import subprocess,json,time,os,sys,copy,hashlib,pickle
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b2_20261128';OLD=B/'work/be_ro_b1_20261128';assert Path.cwd()==B and not (H/'full40').exists()
sys.path.insert(0,str(H));from lb_reader import verify_lb
from be_reader import moments
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inherit=read(H/'INHERITANCE.json')
for n,h in inherit['unchanged_files'].items():assert sha(H/'source'/n)==h,n
assert sha(H/'source/be_ro_search.cpp')==inherit['B1_stage1_file_sha256']==sha(OLD/'source/be_ro_search.cpp')
for n in ['be_ro_solver.cpp','be_ro_witness.hpp','isolated_native.hpp','pool_model.cpp','polish_fft.hpp']:assert sha(H/'source'/n)==sha(OLD/'source'/n)
assert read(OLD/'VALIDATION.json')['status']=='PASS'
old=(OLD/'source/search.cpp').read_text();new=(H/'source/search.cpp').read_text()
for key in ['double Search::native_check','Json Search::shortlist','void Search::final_check']:
 def span(s):i=s.index(key);return s[i:s.index('\n}',i)+2]
 assert span(old)==span(new),key
heavy=H/'fixtures/LAB_6_2_500_';heavy.mkdir(exist_ok=True)
(heavy/'node_to_factor.pkl').write_bytes(pickle.dumps({g:[g,g+6] for g in range(6)},protocol=2));(heavy/'cost.txt').write_text('\n'.join(['2']*6+['1']*6)+'\n')
for j in range(12):(heavy/('%d_sample.txt'%j)).write_text(('0.01\n'*500) if j<6 else ('0\n'*499+'1000\n'))
none=H/'fixtures/LAB_2_2_NONE30_';none.mkdir(exist_ok=True)
for p in (H/'fixtures/LAB_2_2_30_').iterdir():
 if p.is_file():(none/p.name).write_text('2\n'*30) if p.name.endswith('_sample.txt') else (none/p.name).write_bytes(p.read_bytes())
p=subprocess.run([str(H/'build/be_ro_lb_math_test'),str(heavy)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90);(H/'LB_MATH.log').write_bytes(p.stdout);assert p.returncode==0,p.stdout.decode(errors='replace')[-2500:]
math_result=json.loads(p.stdout);assert math_result['status']=='PASS' and math_result['full_selections_enumerated']==64
checks=[];tamper=0;certificates=0
for name,cap in [('LAB_3_2_500_','.5'),('LAB_2_2_500_','1.25'),('LAB_2_2_30_','1.25'),('LAB_6_2_500_','1'),('LAB_2_2_NONE30_','1.25')]:
 D=H/'fixtures'/name;out=H/'integration'/name;assert not out.exists()
 gr=pickle.loads((D/'node_to_factor.pkl').read_bytes());groups=[gr[k] for k in sorted(gr)] if isinstance(gr,dict) else gr;costs=[float(x) for x in (D/'cost.txt').read_text().split()];samples=[(D/('%d_sample.txt'%j)).read_text().split() for j in range(len(costs))]
 start=time.monotonic();env=dict(os.environ,CCMCKP_LAUNCH_MONOTONIC=str(start),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
 p=subprocess.run([str(H/'build/ccmckp_s10'),'--instance',str(D),'--capacity',cap,'--seed','1289901','--rep','1','--seconds','600','--out',str(out),'--search-flow','be_ro_lb'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=100,env=env)
 wall=time.monotonic()-start;(H/('integration_'+name+'.log')).write_bytes(p.stdout)
 assert p.returncode==(1 if 'NONE' in name else 0),p.stdout.decode(errors='replace')[-1800:]
 raw=read(out/'S10_search.json');stage1=read(out/'BE_RO_STAGE1.json');milestone=read(out/'BE_RO_STAGE1_MILESTONE.json');params=moments(samples)
 assert milestone['stage1_raw_sha256']==sha(out/'BE_RO_STAGE1.json')
 v=verify_lb(raw,stage1,milestone,groups,costs,samples,cap,params)
 if 'NONE' in name:
  assert not raw['BE_RO_LB_model']['queries'] and raw['BE_RO_LB_model']['stop_reason']=='no_own_stage1_certified_incumbent' and raw['selected'] is None
 else:
  res=read(out/'RESULT.json');assert res['original_LSS_confidence']>=.99 and res['acceptance_evaluator']=='LSS' and res['lss_sample_index_max']==len(samples[0])-1 and wall<600
 if name=='LAB_6_2_500_':assert milestone['stage1_bero_best_cost']==12 and raw['selected']['cost']==7 and v['LB_native_calls']>0 and v['LB_certified']>0
 def sparse(s,bins,up):
  poly={0:1}
  for j in s:
   counts=Counter()
   for a in samples[j]:
    f=F(a)*bins/F(cap);k=-((-f.numerator)//f.denominator) if up else f.numerator//f.denominator
    if k<bins:counts[k]+=1
   nxt={}
   for a,x in poly.items():
    for b,y in counts.items():
     if a+b<bins:nxt[a+b]=nxt.get(a+b,0)+x*y
   poly=nxt
  return sum(poly.values())
 for q in stage1['BE_RO_model']['native_calls']+raw['BE_RO_LB_model']['native_calls']:
  if 'certificate' not in q:continue
  c=q['certificate'];assert sparse(q['selection'],c['bins'],True)==int(c['lower_numerator']) and sparse(q['selection'],c['bins'],False)==int(c['upper_numerator']);certificates+=1
 def reject(bad):
  global tamper
  try:verify_lb(bad,stage1,milestone,groups,costs,samples,cap,params)
  except (AssertionError,KeyError,IndexError):tamper+=1
  else:raise AssertionError('Reader accepted B2 mutation')
 for key,value in [('historical_solution_inputs',True),('external_MIPstarts',True),('K',6),('k_changed_groups',6),('binary_Hamming_upper',5),('stage2_retains_BE_radius_constraint',True),('generator_LSS_calls',1),('private_probability_cache_isolated',False)]:
  bad=copy.deepcopy(raw);bad['BE_RO_LB_model'][key]=value;reject(bad)
 if raw['BE_RO_LB_model']['queries']:
  bad=copy.deepcopy(raw);bad['BE_RO_LB_model']['queries'][0]['rhs']+=.1;reject(bad)
  bad=copy.deepcopy(raw);bad['BE_RO_LB_model']['queries'][0]['excluded']=[];reject(bad)
 if raw['BE_RO_LB_model']['native_calls']:
  bad=copy.deepcopy(raw);bad['BE_RO_LB_model']['native_calls'][0]['start']=481;reject(bad)
 checks.append({'fixture':name,'whole_seconds':wall,'rc':p.returncode,'cost':read(out/'RESULT.json')['cost'] if (out/'RESULT.json').exists() else None,'stage1_best':milestone['stage1_bero_best_cost'],'independent':v});print(json.dumps(checks[-1]),flush=True)
result={'status':'PASS','tiny_integrations':checks,'new_LB_exhaustive_MILP_tests':5,'each_test_enumerates_selections':64,'reader_tamper_checks':tamper,'native_sparse_integer_certificates':certificates,'positive_LB_improves_own_stage1_12_to7_verified':True,'no_stage1_anchor_no_fallback_verified':True,'B1_stage1_byte_identical':True,'original_native_functions_identical':True,'unchanged_inherited_files':len(inherit['unchanged_files']),'B1_100_KKT_tests_limited_same_SHA_reuse':True,'no_extra_large_case_MC':True,'binary_sha256':sha(H/'build/ccmckp_s10')}
(H/'VALIDATION.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
