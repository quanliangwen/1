# EGS-DC：原生椭球锥模型与CDF随机占优排除割

本版默认`ellipsoid_dominance`。对照`frontier_mitm`。两条流程共用完整600秒和唯一最终LSS验收。

```
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DS10_GUROBI_ROOT=/path/to/gurobi
cmake --build build --parallel 4
build/ccmckp_s10 --instance /data/APP_50_10_500_ --capacity 91 --seed 960001 --rep 1 --seconds 600 --out NEW_DIR --search-flow ellipsoid_dominance --ellipsoid-gamma 2.4
```

依赖GCC/Clang、GMP/GMPXX和Gurobi。原生SOC使用连续提升和PreMIQCPForm=2，NonConvex=0。源码包不附许可证或SDK。

每次从原始样本自行初始化，不读旧解。主模型在改进成本界内最小化椭球风险，不设硬椭球容量阈值。候选经原公共CDF/整数证书搜索判据处理。

只有完整CDF上界证书证明P<.99时才生成随机占优排除割。对每组，精确有理数比较所有原始样本的排序值，识别随机消耗更大的项；按独立分位数耦合，其组合不可能优于已证不可行方案，因此可整体排除。不能用LSS抽样失败或未决证书代替这个证明。

最终仍仅由原LSS精确或百万抽样分支验收，严格事件sum<T，完整索引0…L-1，阈值P>=.99。不计算额外生成分布真实概率。

完整600秒包括加载、初始化、占优表、模型、全部原生评价和LSS、保存与fsync。430秒协作搜索截止、590秒LSS截止、595秒父级保护。需配套controller执行严格进程墙钟保护；C++单独调用的协作截止不能替代外部硬超时。未完成LSS没有概率、不重抽选优，以最后完整LSS值为准。

不宣称椭球概率保证或CCMCKP全局最优。Dcut只适用于本题算法内部统一独立经验边际分布，不对未知真实总体套覆盖结论。论文依据和完整量词证明见本任务模型说明。
