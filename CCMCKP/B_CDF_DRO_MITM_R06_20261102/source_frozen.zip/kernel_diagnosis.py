"""Read-only kernel diagnosis: fresh samples + deterministic within-instance centre; no optimizer/native calls/history inputs."""
import os
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import sys,time,json,inspect,textwrap,hashlib,cProfile,pstats,io,types
from pathlib import Path
import numpy as np
old=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/work/codex_B_DRO_R04_20261101')
sys.path.insert(0,str(old/'sources/B'))
import solver
from instance import load_instance
here=Path(__file__).resolve().parent
case=next(x for x in json.loads((old/'PROTOCOL.json').read_text())['cases'] if x['index']==39)
inst=load_instance(old.parents[1]/'benchmark'/case['instance'])
s=solver.Solver.__new__(solver.Solver);s.inst=inst;s.T=case['tmax'];s.bins=4096;s.groups=[np.array(g,int) for g in inst.groups];s.cost=np.asarray(inst.costs,float);s.half_width=1024;s.arm='B_CDF_DRO_MITM'
s.remaining=lambda:1e6
center=tuple(min(g,key=lambda j:inst.samples[j].mean()+3*inst.samples[j].std(ddof=1)) for g in inst.groups)
s.best={'cost':float(s.cost[list(center)].sum()),'selection':list(center)}
s.native_func=type('F',(),{'__name__':'advanced_monte_carlo'})
hist=np.asarray([solver.worst_cdf_hist(a[:-1],s.T,4096,.00025) for a in inst.samples]);fft=np.fft.rfft(hist,8192,axis=1)
left=list(range(0,inst.m,2));right=list(range(1,inst.m,2));original=solver.Solver.build_half
tree=__import__('ast').parse((here/'sources/R06/solver.py').read_text())
cl=next(x for x in tree.body if isinstance(x,__import__('ast').ClassDef) and x.name=='Solver')
node=next(x for x in cl.body if isinstance(x,__import__('ast').FunctionDef) and x.name=='build_half')
src=__import__('ast').get_source_segment((here/'sources/R06/solver.py').read_text(),node)
from scipy.fft import next_fast_len
ns=dict(vars(solver));ns['next_fast_len']=next_fast_len;exec(compile(src,'<R06_SUPPORT_FFT>','exec'),ns);opt=ns['build_half'];rows=[];ref=None
for i,fn in enumerate((original,opt,opt,original)):
 pr=cProfile.Profile();t=time.monotonic();pr.enable();a=fn(s,left,right,hist,fft,[center]);pr.disable();elapsed=time.monotonic()-t
 hashes=[hashlib.sha256(x.tobytes()).hexdigest() for x in a]
 if ref is None:ref=tuple(x.copy() for x in a)
 lookup={tuple(row):i for i,row in enumerate(ref[2])};matches=[(i,lookup[tuple(row)]) for i,row in enumerate(a[2]) if tuple(row) in lookup]
 fraction=len(matches)/len(a[2]);maxl1=max(float(np.abs(a[1][i].astype(float)-ref[1][j].astype(float)).sum()) for i,j in matches)
 assert fraction>=.99 and maxl1<=1e-5,(fraction,maxl1)
 for i,j in matches:assert a[0][i]==ref[0][j]
 ss=io.StringIO();pstats.Stats(pr,stream=ss).sort_stats('cumtime').print_stats(14)
 row={'order':i,'mechanism':'B' if fn is original else 'R06','elapsed':elapsed,'output_sha':hashes,'retained_overlap_fraction':fraction,'max_matched_pdf_L1':maxl1,'profile':ss.getvalue()};rows.append(row);print(json.dumps(row),flush=True)
(here/'KERNEL_DIAGNOSIS.json').write_text(json.dumps({'case':39,'threads':1,'formal_performance_runs':0,'source_only':'uploadedB','load':os.getloadavg(),'rows':rows},indent=2))
