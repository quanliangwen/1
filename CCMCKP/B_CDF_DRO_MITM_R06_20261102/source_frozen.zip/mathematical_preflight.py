"""Post-freeze mathematical and boundary preflight, no optimization/history inputs."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
import sys,json,time,ast,hashlib
import numpy as np
from scipy.fft import next_fast_len
from common import ROOT,read,sha,atomic,check_freeze

def main():
 f=check_freeze();assert not (ROOT/'MATH_PREFLIGHT.json').exists();rng=np.random.default_rng(20261102);rows=[]
 for B in (1,2,3,8,16,4096):
  for q in sorted(set((0,max(0,B//2),B-1))):
   for mode in ('positive','zeros','boundary'):
    a=rng.random(B);b=np.zeros(B);b[:q+1]=rng.random(q+1)
    if mode=='zeros':b[:]=0
    if mode=='boundary':a[:]=0;a[-1]=1;b[:]=0;b[q]=1
    nz=np.flatnonzero(b!=0);last=int(nz[-1]) if len(nz) else 0;N=min(2*B,next_fast_len(B+last,real=True));assert N>=B+last
    c=np.maximum(0,np.fft.irfft(np.fft.rfft(a,N)*np.fft.rfft(b,N),N)[:B]);expected=np.convolve(a,b)[:B]
    err=float(np.max(abs(c-expected)));assert err<=1e-12
    rows.append({'B':B,'q':q,'mode':mode,'N':N,'max_abs_error':err})
 # All frozen native methods and module risk helpers equal uploaded B; R04 auxiliary unchanged.
 def tree(p):return ast.parse(p.read_text())
 tb=tree(ROOT/'sources/B/solver.py');tc=tree(ROOT/'sources/R06/solver.py');cb=next(x for x in tb.body if isinstance(x,ast.ClassDef) and x.name=='Solver');cc=next(x for x in tc.body if isinstance(x,ast.ClassDef) and x.name=='Solver');bm={x.name:ast.dump(x,include_attributes=False) for x in cb.body if isinstance(x,ast.FunctionDef)};cm={x.name:ast.dump(x,include_attributes=False) for x in cc.body if isinstance(x,ast.FunctionDef)}
 unchanged=[k for k in bm if bm[k]==cm[k]];assert set(bm)-set(unchanged)=={'build_half','run'}
 fb={x.name:ast.dump(x,include_attributes=False) for x in tb.body if isinstance(x,ast.FunctionDef)};fc={x.name:ast.dump(x,include_attributes=False) for x in tc.body if isinstance(x,ast.FunctionDef)};assert fb==fc
 atomic(ROOT/'MATH_PREFLIGHT.json',{'passed':True,'freeze_sha':f,'cases':rows,'unchanged_B_methods':unchanged,'all_B_module_functions_identical':True,'formal_optimization_runs':0,'scope':'Exact linear-convolution algebra including zero/overflow/strict-B boundary; frozen original risk modules/native AST intact. Float64 tolerance is numeric verification, not formal rounding certificate.'});print('math and AST preflight passed',len(rows),flush=True)
if __name__=='__main__':main()
