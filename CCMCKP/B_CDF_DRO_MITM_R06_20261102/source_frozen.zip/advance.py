"""Sole post-freeze entry: synthetic functional preflight, independent check, then guarded campaign."""
import os,sys,subprocess,json,fcntl,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
os.chdir(ROOT)
from common import read,sha,atomic,check_freeze,process_table
ENV=dict(os.environ,OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
def main():
 lock=(ROOT/'advance.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);lock.seek(0);lock.truncate();lock.write(str(os.getpid()));lock.flush();os.fsync(lock.fileno())
 f=check_freeze();assert read(ROOT/'KERNEL_PREFLIGHT_DECISION.json')['passed']
 for name,result in [('mathematical_preflight.py','MATH_PREFLIGHT.json'),('functional_preflight.py','FUNCTIONAL_PREFLIGHT.json')]:
  if not (ROOT/result).exists():
   with (ROOT/(name+'.log')).open('x') as log:
    p=subprocess.run([sys.executable,'-B',str(ROOT/name)],env=ENV,stdout=log,stderr=subprocess.STDOUT)
   if p.returncode:raise RuntimeError('preflight failed '+name)
  assert read(ROOT/result)['passed'] and read(ROOT/result)['freeze_sha']==f
 check_freeze();atomic(ROOT/'PREFLIGHT.json',{'passed':True,'freeze_sha':f,'math':sha(ROOT/'MATH_PREFLIGHT.json'),'functional':sha(ROOT/'FUNCTIONAL_PREFLIGHT.json'),'kernel':sha(ROOT/'KERNEL_PREFLIGHT_DECISION.json'),'independent_processes':True})
 # Re-audit all40 pinnedB before starting, no oracle redraw or worker call.
 from audit_campaign import audit_wave
 reg=read(ROOT/'PROTOCOL.json');refs=read(ROOT/'REFERENCE_REGISTRY.json');counts={}
 for c in reg['cases']:
  rows=audit_wave(Path(refs['waves'][str(c['index'])]['directory']),c,'B');assert len(rows)==30 and all(r['valid'] for r in rows);counts[str(c['index'])]=30
 atomic(ROOT/'REUSED_B_AUDIT.json',{'passed':True,'freeze_sha':f,'counts':counts,'new_B_executions':0})
 from controller import Controller
 c=Controller();c.run()
if __name__=='__main__':
 try:main()
 except Exception as e:atomic(ROOT/'ADVANCE_FAILURE.json',{'error':repr(e),'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'goal_complete':False});raise
