B_CDF_DRO_MITM 原始冻结源码包

一、内容
根目录solver.py为原始五组消融共享实现，未抽取或改写其中B分支。
run_b_cdf_dro_mitm.py为本次新增便携入口，固定选择B_CDF_DRO_MITM。
instance.py、native_evaluator.py、native_support.py、lss_vendor.py为必要原始依赖。
original_experiment/保留原worker及登记协议/算例/完整冻结清单，仅作正式实验溯源。
SOURCE_MANIFEST.json逐项给出源码SHA256。原六文件与登记冻结清单一致。
本包不包含I01/I02-I07实现、不包含历史解、不附带大型原始样本或结果数组。

二、环境与数据
正式实验实际环境：Linux、Python3.8.10，numpy1.24.4，scipy1.10.1，gurobipy11.0.3。
原保存逻辑使用Linux目录fsync；此包按原Linux环境运行，不承诺未经修改直接在Windows运行。
需要可用Gurobi许可证，初始化依赖该求解器。requirements.txt按该实际环境记录。
输入算例目录必须含cost.txt、node_to_factor.pkl、所有物品的<ID>_sample.txt。
node_to_factor.pkl使用Python pickle，只读取你信任的原始基准数据。
大样本文件<ID>_big_sample.txt在本B流程中不主动加载。
数据请使用已有CCMCKP原始benchmark；本源码包不携带样本。

三、便携运行示例
在解压目录使用已配置依赖和许可证的Python运行：
python run_b_cdf_dro_mitm.py --instance "/path/to/benchmark/LAB_3_5_30_" --capacity 11 --seed 832273 --seconds 600 --out "results/B_01_r01.json.gz"

每次自行构造初始解。无需也不接受历史解输入。现有结果或启动标记不会覆盖，失败不自动重试。
便携入口只便于运行原算法，不等同原worker的全路径隔离、登记全部输入SHA和调度资源保护。
若要严格重现正式6000次协议，应使用保留的原实验目录与完整benchmark及冻结清单；不要把本便携入口的新结果直接当成既有正式实验记录。
本次只做源码打包/字节校验/语法及--help检查，未额外启动求解或MC实验。

四、关键参数与缩写
目标：每组恰选一项，最小化总成本；原生P>=0.99才接受。
总时间600秒，工作截止585秒，15秒保存预留。导入和旁证文件写入在搜索时钟之外。
B=4096；W为按组数m计算的固定半区束宽，范围1024..4096；成本桶512个。
delta按(0.00025,0,0.0005)顺序执行，每个半径三种分区，总计最多九阶段，不循环加宽。
F=(0.02,0.01,0.03,0.005,0.05,0.08)为成本下降比例。
SelEval：沿原规则在advanced_exact_evaluation和advanced_monte_carlo间选择。
LRInit：本run的mean+3sampleSD、3秒Gurobi、最多8候选池，并经原生验收。
WCDF：向上离散并将低端概率质量移至最大观测支撑的边际直方图。
HBeam：半区束搜索，含乐观补全CDF评分、成本界剪枝和512成本桶保留。
MITMTop：左右半区卷积拼接，每64个左状态分块、每降本档最多48对，合并去重。
Sort(Q,-p,c)：按卷积评分降序、成本升序遍历，最多检查1800对。
ChkUpd：先要求卷积评分>=0.975，再60000次预筛>=0.975；原生评价>=0.99且成本改善才更新。
原生评价可能快速拒绝而直接返回0，不是每次调用均完成百万次MC。
Rem：距工作截止的剩余秒数；Save保存所有正负观测及当前最好解。
20行伪代码为整体框架，函数缩写对应上述定义与原源码函数，不是另一个算法。

五、解释边界
本B是有限支撑CDF扰动评分结合有限束宽MITM搜索，不是I03以后的Wasserstein机会约束MILP。
半径未作统计覆盖校准，不能声称未知真分布严格DRO覆盖或全局最优。
