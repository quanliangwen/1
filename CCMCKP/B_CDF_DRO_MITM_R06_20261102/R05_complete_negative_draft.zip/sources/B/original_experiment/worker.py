"""A single frozen ablation run; historical solution files are inaccessible."""
import argparse,hashlib,json,os,random,sys,time
from pathlib import Path
H=Path(__file__).resolve().parent
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP').resolve()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--arm',required=True);ap.add_argument('--index',required=True,type=int);ap.add_argument('--rep',required=True,type=int);a=ap.parse_args()
    protocol=json.loads((H/'PROTOCOL.json').read_text());assert a.arm in protocol['arms'] and 1<=a.rep<=30
    cases=json.loads((H/'cases.json').read_text());case=next(c for c in cases if c['index']==a.index)
    benchmark=(B/'benchmark'/case['instance']).resolve();seed=832272+a.rep
    registry=json.loads((H/'source_inputs.json').read_text())
    for raw,expected in registry.items():
        p=Path(raw) if raw.startswith('/') else H/raw
        if raw.startswith('/') and benchmark not in p.parents:continue
        if p.is_symlink() or sha(p)!=expected:raise RuntimeError('freeze changed: '+raw)
    stem=f'{a.arm}_{a.index:02d}_r{a.rep:02d}'
    output=H/'results'/(stem+'.json.gz');sidecar=H/'results'/(stem+'.worker.json')
    if output.exists() or sidecar.exists() or output.with_name(output.name+'.tmp').exists():raise RuntimeError('run overwrite refused')
    reads=set();allowed={str((H/k).resolve()) for k in registry if not k.startswith('/')}
    allowed.add(str(H/'source_inputs.json'))
    own={str(output),str(sidecar),str(output)+'.tmp',str(sidecar)+'.tmp',str(H/'results')}
    def io_guard(event,args):
        if event!='open' or not isinstance(args[0],(str,bytes,os.PathLike)):return
        p=Path(os.fsdecode(args[0])).resolve()
        if p==B or B in p.parents:
            if str(p) not in allowed and str(p) not in own and benchmark not in p.parents:
                raise PermissionError('unregistered/historical/cross-run path: '+str(p))
            reads.add(str(p))
    sys.addaudithook(io_guard)
    import numpy as np
    from instance import load_instance
    from solver import Solver,atomic_json
    random.seed(seed);np.random.seed(seed)
    started=time.monotonic()
    inst=load_instance(benchmark)
    solver=Solver(inst,case['tmax'],seed,600,output,started,a.arm)
    solver.run()
    elapsed=time.monotonic()-started
    record_sha=sha(output)
    # Sidecar I/O is outside the algorithm clock and disclosed separately.
    d=dict(schema='V50_independent_ablation_worker_v1',arm=a.arm,index=a.index,rep=a.rep,seed=seed,pid=os.getpid(),
        elapsed=elapsed,search_clock_includes='instance loading, constructor, all initialization, all native/scoring calls, every solver save/fsync, run return',
        imports_and_freeze_outside_search=True,sidecar_outside_search=True,no_history_inputs=True,no_cross_run_inputs=True,
        solver_record_sha256=record_sha,registry_sha256=sha(H/'source_inputs.json'),protocol_sha256=sha(H/'PROTOCOL.json'),
        opened_campaign_paths=sorted(reads),selected=solver.best)
    atomic_json(sidecar,d)
    print(json.dumps(dict(event='run_terminal',arm=a.arm,index=a.index,rep=a.rep,elapsed=elapsed,has_solution=solver.best is not None)),flush=True)
if __name__=='__main__':main()
