"""Portable convenience entry for unchanged frozen B solver. No historical starts."""
from pathlib import Path
import argparse,hashlib,json,random,time

def main():
    ap=argparse.ArgumentParser(description='Run frozen B_CDF_DRO_MITM on original raw benchmark data.')
    ap.add_argument('--instance',required=True,help='Benchmark directory with cost.txt, node_to_factor.pkl and *_sample.txt')
    ap.add_argument('--capacity',required=True,type=float)
    ap.add_argument('--seed',type=int,default=832273)
    ap.add_argument('--seconds',type=float,default=600)
    ap.add_argument('--out',required=True,help='New .json.gz output; existing outputs are refused')
    args=ap.parse_args()
    if not 30<=args.seconds<=600:ap.error('--seconds must be in [30,600]')
    if args.capacity<=0:ap.error('--capacity must be positive')
    out=Path(args.out).expanduser().resolve()
    if not out.name.endswith('.json.gz'):ap.error('--out must end in .json.gz')
    if out.exists() or out.with_name(out.name+'.tmp').exists():ap.error('Refusing existing output or temporary record')
    root=Path(__file__).resolve().parent
    manifest=json.loads((root/'SOURCE_MANIFEST.json').read_text(encoding='utf8'))
    for name,expected in manifest['original_source_sha256'].items():
        if hashlib.sha256((root/name).read_bytes()).hexdigest()!=expected:raise RuntimeError('Source changed: '+name)
    # Imports precede the recorded search clock, as in the frozen experiment.
    import numpy as np
    from instance import load_instance
    from solver import Solver,atomic_json
    random.seed(args.seed);np.random.seed(args.seed)
    out.parent.mkdir(parents=True,exist_ok=True)
    # Reserve the output name exclusively before a run. Do not remove others' files.
    lock=out.with_name(out.name+'.launch.lock')
    with lock.open('x',encoding='utf8') as f:f.write('No implicit restart or overwrite\n')
    started=time.monotonic()
    inst=load_instance(Path(args.instance))
    sol=Solver(inst,args.capacity,args.seed,args.seconds,out,started,'B_CDF_DRO_MITM')
    sol.run()
    elapsed=time.monotonic()-started
    # Portable sidecar is outside the algorithm clock, like the original worker.
    atomic_json(out.with_name(out.name+'.run.json'),dict(arm='B_CDF_DRO_MITM',seed=args.seed,elapsed=elapsed,within_600=elapsed<=600,selected=sol.best,source=manifest,portable_runner=True,formal_frozen_worker=False))
    print(json.dumps(dict(elapsed=elapsed,within_600=elapsed<=600,selected=sol.best),ensure_ascii=False))

if __name__=='__main__':main()
