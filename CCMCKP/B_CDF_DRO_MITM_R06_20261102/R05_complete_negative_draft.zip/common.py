"""Frozen campaign utilities. No historical solution loader."""
import gzip,hashlib,json,os,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PROJECT=Path('/home/junhao/quan/parallel_test_solver/CCMKCP')
def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def atomic(p,d):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    b=json.dumps(d,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()
    tmp=p.with_name(p.name+'.tmp')
    with tmp.open('wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
    os.replace(str(tmp),str(p));fd=os.open(str(p.parent),os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)
def event(kind,**kwargs):
    d=dict(event=kind,utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),monotonic=time.monotonic(),**kwargs)
    with (ROOT/'EVENTS.jsonl').open('a',encoding='utf8') as f:f.write(json.dumps(d,ensure_ascii=False)+'\n');f.flush();os.fsync(f.fileno())
    print(json.dumps(d,ensure_ascii=False),flush=True)
def check_freeze():
    f=read(ROOT/'FREEZE.json')
    for p,h in f['files'].items():
        if sha(ROOT/p)!=h:raise RuntimeError('frozen file changed: '+p)
    return sha(ROOT/'FREEZE.json')
def mem_available():
    return int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
def process_table():
    rows={}
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            txt=(p/'stat').read_text();parts=txt[txt.rfind(')')+2:].split()
            rows[int(p.name)]={'ppid':int(parts[1]),'rss':int(parts[21])*os.sysconf('SC_PAGE_SIZE'),'start_ticks':int(parts[19]),'cmd':(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')}
        except (OSError,ValueError,IndexError):pass
    return rows
def descendants_rss(pids,table):
    selected=set(pids)
    while True:
        more={pid for pid,row in table.items() if row['ppid'] in selected}
        if more<=selected:break
        selected|=more
    return sum(table[p]['rss'] for p in selected if p in table)
def envelope(case):
    """Worst later beam expansion, rather than current RSS. Bytes per worker."""
    m=case['m'];K=case['max_group'];B=4096;W=max(1024,min(4096,(40960//m)//512*512))
    parents=min(W,K**max(0,(m+1)//2-1));children=parents*K
    # Two complete child-PDF copies, parent FFT, retained halves, FFT block
    # temporaries, join CDF, histograms and fixed Python/native headroom.
    q=2*4*children*B + 16*W*(B+1)+2*4*W*B
    q+=4*16*64*K*(B+1)+8*W*B+case['n']*(8*B+16*(B+1))
    q+=512*2**20
    return max(1*2**30,q)
