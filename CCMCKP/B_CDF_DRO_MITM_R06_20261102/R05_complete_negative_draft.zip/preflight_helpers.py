"""Functional validation helpers; not imported by a formal worker or solver."""
import ast,hashlib,json,pickle,time
from pathlib import Path
from common import ROOT,read,process_table

def previous_live():
    r=read(ROOT/'REFERENCE_REGISTRY.json')['old_controller'];t=process_table();p=t.get(r['pid'])
    return bool(p and p['start_ticks']==r['start_ticks']) or any('worker.py' in v['cmd'] and r['root'] in v['cmd'] for v in t.values())

def fixture_for(rep):
    if rep%3==0:return 'large_L30',3.75,35.,True
    T=3.5 if rep%2 else 1.
    return ('small_L30' if rep%3==1 else 'small_L500'),T,(15. if T==3.5 else 30.),False

def state_digest(state):return hashlib.sha256(pickle.dumps(state,protocol=4)).hexdigest()

def original_native_check(np):
    tree=ast.parse((ROOT/'sources/B/solver.py').read_text())
    cls=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='Solver')
    cls.body=[x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='native_check']
    env={'np':np,'time':time,'json':json};exec(compile(ast.Module(body=[cls],type_ignores=[]),'original_uploaded_native_wrapper','exec'),env)
    return env['Solver'].native_check
