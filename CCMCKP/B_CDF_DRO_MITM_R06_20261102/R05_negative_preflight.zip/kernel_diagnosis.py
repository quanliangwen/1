"""Read-only kernel diagnosis: fresh samples + deterministic within-instance centre; no optimizer/native calls/history inputs."""
import os
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import sys,time,json,inspect,textwrap,hashlib,cProfile,pstats,io,types
from pathlib import Path
import numpy as np
old=Path('/home/junhao/quan/parallel_test_solver/CCMKCP/work/codex_B_DRO_R04_20261101')
sys.path.insert(0,str(old/'sources/B'))
import solver
from instance import load_instance
here=Path(__file__).resolve().parent
case=next(x for x in json.loads((old/'PROTOCOL.json').read_text())['cases'] if x['index']==39)
inst=load_instance(old.parents[1]/'benchmark'/case['instance'])
s=solver.Solver.__new__(solver.Solver);s.inst=inst;s.T=case['tmax'];s.bins=4096;s.groups=[np.array(g,int) for g in inst.groups];s.cost=np.asarray(inst.costs,float);s.half_width=1024;s.arm='B_CDF_DRO_MITM'
s.remaining=lambda:1e6
center=tuple(min(g,key=lambda j:inst.samples[j].mean()+3*inst.samples[j].std(ddof=1)) for g in inst.groups)
s.best={'cost':float(s.cost[list(center)].sum()),'selection':list(center)}
s.native_func=type('F',(),{'__name__':'advanced_monte_carlo'})
hist=np.asarray([solver.worst_cdf_hist(a[:-1],s.T,4096,.00025) for a in inst.samples]);fft=np.fft.rfft(hist,8192,axis=1)
left=list(range(0,inst.m,2));right=list(range(1,inst.m,2));original=solver.Solver.build_half
src=textwrap.dedent(inspect.getsource(original));src=src.replace('cdf1=np.cumsum(truncated_convolution(suffix[depth+1],completed[-1],B))[::-1]','cdf1=cdf0 if completed[0] is completed[-1] else np.cumsum(truncated_convolution(suffix[depth+1],completed[-1],B))[::-1]')
src=src.replace('p0rows.append(np.clip(pp@cdf0,0,1));p1rows.append(np.clip(pp@cdf1,0,1))','p0rows.append(np.clip(pp@cdf0,0,1));p1rows.append(p0rows[-1] if cdf1 is cdf0 else np.clip(pp@cdf1,0,1))')
ns=dict(vars(solver));exec(compile(src,'<CSE_DRAFT>','exec'),ns);opt=ns['build_half'];rows=[];ref=None
for i,fn in enumerate((original,opt,opt,original)):
 pr=cProfile.Profile();t=time.monotonic();pr.enable();a=fn(s,left,right,hist,fft,[center]);pr.disable();elapsed=time.monotonic()-t
 hashes=[hashlib.sha256(x.tobytes()).hexdigest() for x in a]
 if ref is None:ref=hashes
 assert hashes==ref
 ss=io.StringIO();pstats.Stats(pr,stream=ss).sort_stats('cumtime').print_stats(14)
 row={'order':i,'mechanism':'B' if fn is original else 'CSE','elapsed':elapsed,'output_sha':hashes,'profile':ss.getvalue()};rows.append(row);print(json.dumps(row),flush=True)
(here/'KERNEL_DIAGNOSIS.json').write_text(json.dumps({'case':39,'threads':1,'formal_performance_runs':0,'source_only':'uploadedB','load':os.getloadavg(),'rows':rows},indent=2))
