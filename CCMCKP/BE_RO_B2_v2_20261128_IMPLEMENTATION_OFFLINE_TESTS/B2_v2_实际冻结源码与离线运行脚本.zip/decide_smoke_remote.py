from pathlib import Path
from datetime import datetime,timezone
import json,statistics,hashlib
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b2_v2_20261128';F=H/'smoke'
assert Path.cwd()==B
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert read(F/'FINAL_AUDIT_PROCESS.json')['rc']==0
A=read(F/'FINAL_INDEPENDENT_AUDIT.json');C=read(F/'COMPLETED.json');P=read(F/'PROTOCOL.json');gate=P['pre_registered_quality_gate']
assert C['terminal']==40 and C['pending']==0
for n,h in P['source_and_binary_pins'].items():assert sha(F/n)==h,n
zeros=[]
for o in (read(p) for p in (F/'outcomes').glob('*.json')):
 p=F/'runs'/o['identity']/'S10_search.json'
 if not p.exists():continue
 raw=read(p)
 for stage,key in [('stage1','BE_RO_model'),('stage2','BE_RO_LB_model')]:
  for i,q in enumerate(raw.get(key,{}).get('queries',[])):
   s=q['solver'] if stage=='stage2' else q
   if s.get('solver_status')==9 and s.get('solutions_retained')==0:zeros.append({'identity':o['identity'],'stage':stage,'query':i})
groups=[]
for c in P['cases']:
 rr=[r for r in A['rows'] if r['case_index']==c['index']];vv=[r for r in rr if r['valid']];values=[r['cost'] for r in vv]
 best=min(values) if values else None;avg=statistics.mean(values) if len(vv)==5 else None;key=str(c['index'])
 whole=statistics.mean(r['process_wall_seconds'] for r in rr);bl=gate['best_cost_max'][key];al=gate['avg_cost_max'][key];tl=gate['whole_mean_seconds_max'].get(key)
 okay=len(vv)==5 and best<=bl and avg<=al and (tl is None or whole<=tl)
 hit=[r for r in vv if r['cost']==best]
 groups.append({'case_index':c['index'],'instance':c['instance'],'capacity':c['tmax'],'terminal':len(rr),'valid':len(vv),'best':best,'avg':avg,
  'sample_std':statistics.stdev(values) if len(vv)==5 else None,'best_hit_count':len(hit),
  'first_Best_mean':statistics.mean(r['first_found_seconds'] for r in hit) if len(vv)==5 and hit else None,
  'whole_mean':whole,'whole_max':max(r['process_wall_seconds'] for r in rr),'best_limit':bl,'avg_limit':al,'whole_mean_limit':tl,'quality_gate_pass':okay})
passed=A['terminal']==A['independent_valid']==40 and not A['global_errors'] and not zeros and all(g['quality_gate_pass'] for g in groups) and max(r['process_wall_seconds'] for r in A['rows'])<=600
result={'utc':datetime.now(timezone.utc).isoformat(),'pass':passed,'can_launch_full40':passed,'terminal':40,'independent_valid':A['independent_valid'],
 'global_errors':A['global_errors'],'TIME_LIMIT_zero_solution_queries':zeros,'groups':groups,'quality_gate':gate,
 'protocol_sha256':sha(F/'PROTOCOL.json'),'audit_sha256':sha(F/'FINAL_INDEPENDENT_AUDIT.json'),
 'old_B1_smoke_gate_not_amended':True,'no_after_result_relaxation':True,'failed_repeats_rerun':False}
p=F/'SMOKE_EXPANSION_DECISION.json'
if p.exists():
 prev=read(p);assert {k:v for k,v in prev.items() if k!='utc'}=={k:v for k,v in result.items() if k!='utc'};result=prev
else:p.write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
