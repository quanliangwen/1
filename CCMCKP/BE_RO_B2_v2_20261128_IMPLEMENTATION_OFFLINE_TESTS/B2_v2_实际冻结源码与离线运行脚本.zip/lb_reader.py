"""Independent B2-v2 replay. No solver/writer imports, no probability sampling."""
from fractions import Fraction as F
from linear_reader import verify_v2,model_cost
from r05_fft_reader import r05_private_tools
import math

def verify_lb(raw,stage1,milestone,groups,costs,samples,capacity,parameters=None):
 v=verify_v2(stage1,groups,costs,samples,capacity)
 v['witnesses']=sum(len(q['returned']) for q in stage1['BE_RO_model']['queries'])
 assert raw['search_flow']=='be_ro_lb' and raw['algorithm_version']=='B2-v2' and raw['seed']==stage1['seed']
 assert raw['BE_RO_model']==stage1['BE_RO_model']
 m=raw['BE_RO_LB_model'];assert m['model']=='BE_RO_LB_B2' and m['algorithm_version']=='B2-v2'
 assert m['K']==5 and m['k_changed_groups']==5 and m['binary_Hamming_upper']==10
 for flag in ['historical_solution_inputs','external_MIPstarts','stage2_retains_BE_radius_constraint','stage2_row_is_probability_certificate','stage1_no_anchor_fallback']:assert m[flag] is False,flag
 assert m['generator_LSS_calls']==0 and m['private_probability_cache_isolated'] and m['stage1_FFT_spectra_reused'] and m['round_entry_stall_frozen']
 assert m['cost_exactness']=='rational sum of unchanged binary64 item costs'
 assert m['stage1_milestone']==milestone and milestone['source_seed']==raw['seed'] and milestone['stage1_source']=='unchanged_B1_v22_own_run_function'
 selection,cost,prob,marginals,near=r05_private_tools(groups,costs,samples,capacity)
 initial={tuple(q['selection']):q for q in stage1['BE_RO_model']['certified_pool']}
 order=lambda pool:sorted(pool,key=lambda s:(cost(s),s))
 assert len(initial)==milestone['stage1_certified_pool_size']==milestone['stage1_bero_certified_count']
 top=[initial[s] for s in order(initial)[:5]]
 assert milestone['stage1_bero_topK']==top and milestone['stage1_bero_topK_costs']==[r['cost'] for r in top]
 assert milestone['stage1_bero_best_cost']==(stage1['selected']['cost'] if initial else None)
 assert milestone['stage1_eps_fft']==stage1['BE_RO_model']['epsilon_fft_final']
 for n in ['stage1_bero_certified_count','stage1_bero_best_cost','stage1_bero_topK_costs','stage1_eps_fft']:assert raw[n]==milestone[n]
 final={tuple(q['selection']):q for q in m['certified_pool']}
 for s,r in initial.items():assert final[s]==r
 assert m['stage2_events']==m['native_calls']
 assert m['stage2_lb_rounds']==len(m['queries']) and m['stage2_cutoff_mode_per_round']==[q['cutoff_mode'] for q in m['queries']]
 zeros=sum(q['solver'].get('solver_status')==9 and q['solver'].get('solutions_retained')==0 for q in m['queries'])
 assert m['stage2_mip_solcount0_timelimit_count']==zeros
 assert m['stage2_native_calls']==len(m['native_calls']) and m['stage2_native_accepted']==sum(c['state']=='accepted' for c in m['native_calls'])
 if not m['stage2_entered']:
  assert m['stage2_stop_reason']==m['stop_reason']=='not_entered' and (not initial or m['stop_seconds']>=480)
  assert not m['queries'] and not m['candidates'] and not m['native_calls'] and final==initial
  assert m['epsilon_fft_final']==milestone['stage1_eps_fft']
  return dict(v,LB_queries=0,LB_native_calls=0,LB_certified=0)
 assert initial
 accepted=dict(initial);epsilon=milestone['stage1_eps_fft'];stall=0
 probabilities={tuple(r['selection']):r['private_probability'] for r in stage1['BE_RO_model']['archive'] if r['private_probability'] is not None}
 excluded={tuple(r['selection']) for r in stage1['BE_RO_model']['native_calls']}|set(initial)
 attempted={tuple(r['selection']) for r in stage1['BE_RO_model']['native_calls']}
 calls={tuple(c['selection']):c for c in m['native_calls']};assert len(calls)==len(m['native_calls'])
 rounds={r['round']:r for r in m['rounds']};assert len(rounds)==len(m['rounds'])
 count=0;last_native_finish=0
 def compute(entry):
  ordered=order(accepted);best=ordered[0];p=probabilities[best]
  mode='strict_best' if p>=.992 or entry>=1 else 'topk_guard'
  ref=ordered[0 if mode=='strict_best' else 4] if mode=='strict_best' or len(ordered)>=5 else None
  return {'mode':mode,'has_upper_bound':ref is not None,'reference_selection':list(ref) if ref is not None else [],
   'c_ref':model_cost(ref,costs) if ref is not None else None,'c_cut':model_cost(ref,costs)-1e-6 if ref is not None else None,
   'c_ref_exact':cost(ref) if ref is not None else None,'c_cut_exact':cost(ref)-F(1,1000000) if ref is not None else None}
 def check_cut(record,expected):
  for n,value in expected.items():
   if n.endswith('_exact') and value is not None:assert F(record[n])==value,'exact_'+n
   else:assert record[n]==value,'cutoff_'+n
 def permitted(s,c):return not c['has_upper_bound'] or cost(s)<=c['c_cut_exact']
 for index,q in enumerate(m['queries'],1):
  best=order(accepted)[0];before=cost(best);entry=stall
  assert q['round']==index and stall<2 and q['entry_stall']==entry and q['anchor']==list(best)
  assert q['best_before']==accepted[best]['cost'] and q['epsilon_before']==epsilon
  assert 0<=q['start']<=480 and q['start']<=q['finish']<=570
  solver=q['solver'];assert not solver.get('external_MIPstarts',False)
  if not solver.get('model_setup_exhausted_slice',False):assert solver['PoolSearchMode']==2 and solver['PoolSolutions']==20 and solver['PoolGap']==1e100
  assert set(map(tuple,q['excluded']))==excluded and len(q['excluded'])==len(excluded)
  p,replacement=marginals(q['anchor']);near(q['anchor_probability'],p);near(q['anchor_probability'],probabilities[best]);probabilities[best]=q['anchor_probability']
  cut=compute(entry);check_cut(q['cutoff_decision'],cut);assert q['cutoff_mode']==cut['mode'] and q['cutoff']==cut['c_cut']
  assert q['Kth_before']==(accepted[order(accepted)[4]]['cost'] if len(accepted)>=5 else None)
  assert len(q['risk'])==len(costs)
  for j,x in enumerate(q['risk']):near(x,p-replacement[j])
  assert abs(q['rhs']-max(0,q['anchor_probability']-(.99-epsilon)))<1e-12
  raw_vectors=set(map(tuple,q['raw_solutions']));assert len(raw_vectors)==len(q['raw_solutions']) and not raw_vectors&excluded
  excluded|=raw_vectors
  initial_records=[r for r in m['candidates'] if r['round']==index and r['filter_stage']=='initial']
  assert [tuple(r['selection']) for r in initial_records]==sorted(raw_vectors)[:len(initial_records)]
  queue=[]
  for r in initial_records:
   s=r['selection'];key=tuple(s);selection(s);assert F(r['cost_exact'])==cost(s) and r['cost']==model_cost(s,costs)
   distance=sum(a!=b for a,b in zip(s,q['anchor']));lhs=sum(q['risk'][j] for j in s)
   assert r['distance_changed_groups']==distance and abs(r['risk_lhs']-lhs)<1e-12
   if r['decision']=='already_attempted':assert key in attempted;continue
   if r['decision']=='rounded_MIP_row_rejected':assert distance<1 or distance>5 or lhs>q['rhs']+1e-8;continue
   assert 1<=distance<=5 and lhs<=q['rhs']+1e-8
   near(r['private_probability'],prob(s));probabilities[key]=r['private_probability'];assert r['epsilon_before']==epsilon
   if r['decision']=='private_FFT_rejected':assert r['private_probability']<.99-epsilon;continue
   assert r['private_probability']>=.99-epsilon
   if r['decision']=='exact_initial_cutoff_rejected':assert not permitted(s,cut);continue
   assert r['decision']=='queued' and permitted(s,cut);queue.append(r)
  queue.sort(key=lambda r:(cost(r['selection']),-r['private_probability'],tuple(r['selection'])))
  dynamic=[r for r in m['candidates'] if r['round']==index and r['filter_stage']=='dynamic']
  assert [r['selection'] for r in dynamic]==[r['selection'] for r in queue[:len(dynamic)]]
  dynamic_stopped=False
  for r in dynamic:
   s=r['selection'];key=tuple(s);current=compute(entry);check_cut(r['cutoff_decision'],current)
   best=order(accepted)[0];assert r['entry_stall']==entry and r['best_selection_before']==list(best) and r['p_fft_best']==probabilities[best]
   assert F(r['cost_exact'])==cost(s) and r['cost']==model_cost(s,costs) and r['epsilon_before']==epsilon
   assert r['private_probability']==probabilities[key]
   if r['decision']=='dynamic_exact_cutoff_stop':assert not permitted(s,current) and r is dynamic[-1];dynamic_stopped=True;continue
   assert permitted(s,current) and key not in attempted and r['private_probability']>=.99-epsilon,'actual_native_exact_admission'
   attempted.add(key);c=calls[key];count+=1;check_cut(c['cutoff_decision'],current)
   assert c['mode']==current['mode'] and c['c_ref']==current['c_ref'] and c['c_cut']==current['c_cut']
   assert c['round']==index and c['entry_stall']==entry and c['state']==r['decision'] and c['epsilon_before']==epsilon
   assert c['best_selection_before']==list(best) and c['best_cost_before']==accepted[best]['cost'] and c['p_fft_best']==probabilities[best]
   assert c['cand_x']==s and c['cand_cost']==r['cost'] and F(c['cand_cost_exact'])==cost(s) and c['cand_p_fft']==c['private_probability']==r['private_probability']
   assert 0<=c['start']<=480 and c['start']>=last_native_finish and c['start']<=c['finish']<=570.1
   assert c['slice_deadline']<=min(c['start']+90,570)+1e-5 and c['launch_t_sec']==c['start'] and abs(c['finish_t_sec']-c['finish'])<1e-3
   last_native_finish=c['finish']
   if c['hard_timeout']:assert c['state']=='unknown' and 'certificate' not in c
   assert c['passed_099']==(c['state']=='accepted')
   if c['state']=='accepted':
    cert=c['certificate'];assert int(cert['lower_numerator'])*100>=99*int(cert['denominator'])
    assert key in final and final[key]['source']=='BE_RO_LB' and final[key]['certificate']==cert and final[key]['cost']==r['cost']
    assert c['start']<=final[key]['found_seconds']<=r['finish'];accepted[key]=final[key]
    epsilon=max(epsilon,.001,.99-r['private_probability'])
   assert c['epsilon_after']==epsilon
  if not raw_vectors:
   assert index==len(m['queries']) and m['stage2_stop_reason']=='mip_infeasible_or_empty' and not initial_records and not dynamic
  elif index in rounds:
   closed=rounds[index];assert len(initial_records)==len(raw_vectors)
   assert dynamic_stopped or len(dynamic)==len(queue) or m['stage2_stop_reason']=='launch_guard_480s'
   improved=cost(order(accepted)[0])<before;stall=0 if improved else stall+1
   assert closed['entry_stall']==entry and closed['best_before']==q['best_before'] and closed['best_after']==accepted[order(accepted)[0]]['cost']
   assert closed['improved']==improved and closed['stall_after']==stall and closed['raw_empty'] is False
  else:assert index==len(m['queries']) and m['stage2_stop_reason']=='launch_guard_480s'
 assert count==len(calls) and set(final)==set(accepted) and m['epsilon_fft_final']==epsilon
 if m['stage2_stop_reason']=='stall_converged_2_rounds':assert stall==2
 assert m['stop_reason']==m['stage2_stop_reason'] and m['stage2_stop_reason'] in ['mip_infeasible_or_empty','stall_converged_2_rounds','launch_guard_480s']
 best=order(accepted)[0];assert raw['selected']['selection']==list(best) and raw['selected']['cost']==accepted[best]['cost']
 assert m['stage2_best_improved_over_stage1']==(accepted[best]['cost']<milestone['stage1_bero_best_cost']-1e-8)
 assert not raw['match_history'] and not raw['local_history'] and not raw['block_history']
 return dict(v,LB_queries=len(m['queries']),LB_native_calls=count,LB_certified=len(final)-len(initial),exact_actual_native_admissions=count)
