from pathlib import Path
from datetime import datetime,timezone
import json,shutil,hashlib
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b2_v2_20261128';S=H/'smoke';F=H/'full40'
assert Path.cwd()==B and not F.exists()
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
G=read(S/'SMOKE_EXPANSION_DECISION.json');assert G['pass'] and G['independent_valid']==40 and not G['global_errors']
assert sha(S/'FINAL_INDEPENDENT_AUDIT.json')==G['audit_sha256']
old=read(S/'PROTOCOL.json')
for n,h in old['source_and_binary_pins'].items():assert sha(S/n)==h,n
P=read(H/'FULL_PROTOCOL_TEMPLATE.json');assert P['total_runs']==1200 and len(P['cases'])==40 and P['repetitions']==30
assert set(P['seeds']).isdisjoint(old['seeds'])
for p in (B/'work').glob('be_ro*/**/PROTOCOL.json'):
 try:prev=read(p)
 except (OSError,ValueError):continue
 assert set(P['seeds']).isdisjoint(prev.get('seeds',[])),str(p)
# Use observed per-instance compact volumes, with an additive worst observed LB
# overhead, rather than pretending all40 cases are as large as the largest one.
A=B/'work/be_ro_b1_v22_full_20261128/full40';assert read(A/'COMPLETED.json')['terminal']==1200
sizes={}
for c in P['cases']:
 roots=list((A/'runs').glob('*_i%02d_r01'%c['index']));assert len(roots)==1
 sizes[c['index']]=sum(p.stat().st_size for p in roots[0].rglob('*') if p.is_file())
overheads=[]
for c in old['cases']:
 roots=list((S/'runs').glob('*_i%02d_r*'%c['index']));assert len(roots)==5
 overheads.extend(max(0,sum(p.stat().st_size for p in r.rglob('*') if p.is_file())-2*sizes[c['index']]) for r in roots)
estimate=30*sum(2*sizes[c['index']]+max(overheads,default=0) for c in P['cases'])
need=max(6*2**30,int(estimate*1.5)+2*2**30);free=shutil.disk_usage(H).free
assert free>need,('fresh_capacity',free,need,estimate)
F.mkdir()
for n in ['runs','outcomes','logs']:(F/n).mkdir()
support=['controller.py','audit_reader.py','lb_reader.py','linear_reader.py','be_reader.py','native_reader.py','r05_fft_reader.py']
for n in support:shutil.copy2(H/n,F/n)
P['source_and_binary_pins']={'../source/'+p.relative_to(H/'source').as_posix():sha(p) for p in (H/'source').rglob('*') if p.is_file()}
for n in ['bin/ccmckp_s10','USER_DESIGN.md','STATIC_REVIEW.json','SOURCE_MANIFEST_SHA256.json','VALIDATION.json','READER_VALIDATION.json','EXECUTION_NOTES.md','smoke/SMOKE_EXPANSION_DECISION.json']:P['source_and_binary_pins']['../'+n]=sha(H/n)
for n in support:P['source_and_binary_pins'][n]=sha(F/n)
manifest=read(H/'source/BENCHMARK_MANIFEST.json');pins={}
for c in P['cases']:
 for n,h in manifest[c['instance']].items():assert sha(B/'benchmark'/c['instance']/n)==h;pins['benchmark/'+c['instance']+'/'+n]=h
P['input_pins']=pins;P['registered_utc']=datetime.now(timezone.utc).isoformat()
(F/'PROTOCOL.json').write_text(json.dumps(P,ensure_ascii=False,indent=2));r={'status':'FROZEN_B2_V2_FULL40_READY','registered_runs':1200,'max_workers':60,
 'protocol_sha256':sha(F/'PROTOCOL.json'),'binary_sha256':sha(H/'bin/ccmckp_s10'),'smoke_gate_pass':True,'source_pins':len(P['source_and_binary_pins']),
 'input_pins':len(pins),'free_disk_GiB':free/2**30,'required_disk_GiB':need/2**30,'estimated_compact_bytes':estimate,'capacity_estimate_basis':'each of40 real Stage1 records,duplicated snapshot plus worst observed smoke LB additive overhead,1.5 safety and2GiB reserve'}
(F/'FROZEN.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
