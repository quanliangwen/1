from pathlib import Path
import json,subprocess,os,time
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b2_v2_20261128'
assert Path.cwd()==B and (H/'smoke/FROZEN.json').exists() and not (H/'WORKFLOW_REQUEST.json').exists() and not (H/'WORKFLOW_LAUNCH.json').exists()
with (H/'workflow.log').open('xb') as log:
 p=subprocess.Popen(['python3',str(H/'workflow.py')],cwd=B,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,close_fds=True)
(H/'WORKFLOW_REQUEST.json').write_text(json.dumps({'pid':p.pid,'utc_epoch':time.time()}));time.sleep(1)
assert p.poll() is None,(H/'workflow.log').read_text()
print(json.dumps({'status':'STARTED_OFFLINE_SEQUENTIAL_WORKFLOW','pid':p.pid,'session':os.getsid(p.pid),'stdin':os.readlink('/proc/%d/fd/0'%p.pid),'state':json.loads((H/'WORKFLOW_STATUS.json').read_text())}))
