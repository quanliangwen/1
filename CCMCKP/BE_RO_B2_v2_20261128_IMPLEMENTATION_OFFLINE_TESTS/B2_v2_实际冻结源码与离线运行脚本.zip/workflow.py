"""One registered offline experiment workflow; never retries a run/controller."""
from pathlib import Path
from datetime import datetime,timezone
import os,json,time,signal,subprocess,statistics,hashlib
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=Path(__file__).resolve().parent
A=B/'work/be_ro_b1_v22_full_20261128/full40';assert B in H.parents
read=lambda p:json.loads(p.read_text())
stop=False;child=None
def utc():return datetime.now(timezone.utc).isoformat()
def write(p,q):
 t=p.with_suffix(p.suffix+'.tmp')
 with t.open('w') as f:json.dump(q,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
 t.replace(p)
def state(phase,**fields):write(H/'WORKFLOW_STATUS.json',dict(phase=phase,utc=utc(),pid=os.getpid(),**fields))
def stopping(signum,frame):
 global stop
 stop=True
signal.signal(signal.SIGTERM,stopping);signal.signal(signal.SIGINT,stopping)
def check_stop():
 if stop or (H/'STOP_REQUESTED').exists():
  if child is not None and child.poll() is None:os.killpg(child.pid,signal.SIGTERM)
  raise InterruptedError('Requested stop; pending identities retained')
def execute(name):
 with (H/(name+'.execution.log')).open('xb') as f:
  p=subprocess.run(['python3',str(H/name)],cwd=B,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError(name+' failed; inspect '+name+'.execution.log')
def launch(F):
 global child
 assert (F/'FROZEN.json').exists() and not (F/'LAUNCH_REQUEST.json').exists() and not (F/'LAUNCH.json').exists()
 with (F/'controller.log').open('xb') as log:
  child=subprocess.Popen(['python3',str(F/'controller.py')],cwd=F,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,close_fds=True)
 write(F/'LAUNCH_REQUEST.json',{'pid':child.pid,'utc':utc(),'workflow_pid':os.getpid(),'session':os.getsid(child.pid),'offline':True})
 while child.poll() is None:check_stop();time.sleep(2)
 assert child.returncode==0,'Controller exited; no restart: '+str(F)
 assert read(F/'FINAL_AUDIT_PROCESS.json')['rc']==0,'Reader process failed'
def report(F,label):
 audit=read(F/'FINAL_INDEPENDENT_AUDIT.json');P=read(F/'PROTOCOL.json');fmt=lambda x:'—' if x is None else '%.6f'%x
 lines=['# '+label+'独立终末统计','',
  '终末%d/%d，独立有效%d，global_errors=%s。'%(audit['terminal'],P['total_runs'],audit['independent_valid'],json.dumps(audit['global_errors'],ensure_ascii=False)),
  '原LSS≥.99保持；初始解仅本run原始数据生成。下表只有全部登记重复独立有效才给官方Best/Avg/样本Std。时间为最终输出命中本批Best的运行，其返回向量首次内部认证时间的均值；完整耗时单列。Best不等于已证明全局最优。','',
  '|编号|算例|T|有效|Best|Avg|样本Std|首次达Best均时(s)|命中次数|完整均时(s)|完整最大(s)|',
  '|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
 for g in audit['groups']:
  lines.append('|%s|%s|%s|%s/%s|%s|%s|%s|%s|%s|%s|%s|'%(g['case_index'],g['instance'],g['capacity'],g['valid'],P['repetitions'],fmt(g['official_best']),fmt(g['official_avg']),fmt(g['official_std']),fmt(g['best_hit_first_mean_seconds']),g['best_hit_count'],fmt(g['whole_mean']),fmt(g['whole_max'])))
 if (F/'SMOKE_EXPANSION_DECISION.json').exists():
  decision=read(F/'SMOKE_EXPANSION_DECISION.json');lines+=['','本轮冻结门槛：'+('全部通过，允许独立新seed全量。' if decision['pass'] else '未全部通过，不启动B2-v2全量。')]
 lines+=['','全部普通无解、LSS失败、资源/时钟失败保留，不补跑、不赋假成本。有限半径/λ/解池无全局最优保证；LB候选不继承Stage1半径鲁棒证书，.992私人FFT护栏不是样本外置信证明。',
  '', '协议SHA256：`'+hashlib.sha256((F/'PROTOCOL.json').read_bytes()).hexdigest()+'`。',
  '审计SHA256：`'+hashlib.sha256((F/'FINAL_INDEPENDENT_AUDIT.json').read_bytes()).hexdigest()+'`。']
 (F/'FINAL_REPORT.md').write_text('\n'.join(lines)+'\n')
assert not (H/'WORKFLOW_LAUNCH.json').exists(),'No duplicate or implicit resume'
write(H/'WORKFLOW_LAUNCH.json',{'pid':os.getpid(),'utc':utc(),'session':os.getsid(0),'offline':True,'trackA':str(A)})
try:
 state('waiting_trackA_all1200_solver_exits',registered_B2_smoke=40,registered_B2_full_conditional=1200)
 while not (A/'COMPLETED.json').exists():
  check_stop()
  if (A/'CONTROLLER_ERROR.json').exists():raise RuntimeError('TrackA controller error; inspect before any continuation')
  time.sleep(10)
 complete=read(A/'COMPLETED.json');assert complete['phase']=='completed' and complete['terminal']==1200 and complete['pending']==0
 # The A controller may be running its final read-only audit, but it cannot
 # dispatch any further solver identities after this terminal marker.
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   args=(p/'cmdline').read_bytes().split(b'\0')
   assert not any(str(A).encode() in a and b'ccmckp_s10' in a for a in args),'TrackA worker remains'
  except OSError:pass
 state('B2_smoke_running_or_independent_audit',total=40);launch(H/'smoke')
 execute('decide_smoke_remote.py');report(H/'smoke','B2-v2 8例各5次冒烟')
 decision=read(H/'smoke/SMOKE_EXPANSION_DECISION.json')
 if decision['pass']:
  state('B2_smoke_passed_checking_fresh_capacity');execute('freeze_full_remote.py')
  state('B2_full40_running_or_independent_audit',total=1200);launch(H/'full40');report(H/'full40','B2-v2全40例各30次')
 else:state('B2_smoke_quality_failed_no_full40',failed_cases=[g['case_index'] for g in decision['groups'] if not g['quality_gate_pass']])
 state('B2_stage_terminal_waiting_trackA_final_audit',B2_full_started=(H/'full40/LAUNCH.json').exists())
 while not (A/'FINAL_AUDIT_PROCESS.json').exists():check_stop();time.sleep(10)
 assert read(A/'FINAL_AUDIT_PROCESS.json')['rc']==0
 report(A,'B1-v2.2独立全40例各30次')
 result={'phase':'all_registered_stages_terminal','utc':utc(),'B2_smoke_gate_pass':decision['pass'],'B2_full_started':(H/'full40/LAUNCH.json').exists(),
  'trackA_independent_valid':read(A/'FINAL_INDEPENDENT_AUDIT.json')['independent_valid'],
  'B2_last_independent_valid':read(H/('full40' if decision['pass'] else 'smoke')/'FINAL_INDEPENDENT_AUDIT.json')['independent_valid'],
  'new_model_effectiveness_not_inferred_from_launch':True}
 write(H/'WORKFLOW_COMPLETED.json',result);state(result['phase'],details=result)
except InterruptedError as e:state('requested_stop',error=str(e))
except BaseException as e:
 state('blocked_inspect_no_restart',error=repr(e));write(H/'WORKFLOW_ERROR.json',{'utc':utc(),'error':repr(e)});raise
