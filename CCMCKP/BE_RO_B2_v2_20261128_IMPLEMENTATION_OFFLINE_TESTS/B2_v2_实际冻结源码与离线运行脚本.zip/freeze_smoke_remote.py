from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b2_v2_20261128';F=H/'smoke'
assert Path.cwd()==B and not F.exists(),'No overwriting registered batch'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
V=read(H/'VALIDATION.json');RV=read(H/'READER_VALIDATION.json');P=read(H/'SMOKE_PROTOCOL_TEMPLATE.json')
assert V['status']==RV['status']=='PASS' and V['binary_sha256']==sha(H/'build/ccmckp_s10') and RV['production_reader_sha256']==sha(H/'audit_reader.py')
assert P['total_runs']==40 and P['repetitions']==5 and len(P['cases'])==8 and P['max_workers']==60
assert P['user_design_sha256']==sha(H/'USER_DESIGN.md')
for n,h in read(H/'SOURCE_MANIFEST_SHA256.json')['files'].items():assert sha(H/'source'/n)==h,n
assert sha(H/'source/be_ro_search.cpp')==P['stage1_full_file_sha256']
for q in (B/'work').glob('be_ro*/**/PROTOCOL.json'):
 try:prev=read(q)
 except (OSError,ValueError):continue
 assert set(P['seeds']).isdisjoint(prev.get('seeds',[])),str(q)
free=shutil.disk_usage(H).free;assert free>6*2**30
(H/'bin').mkdir();shutil.copy2(H/'build/ccmckp_s10',H/'bin/ccmckp_s10')
F.mkdir()
for n in ['runs','outcomes','logs']:(F/n).mkdir()
support=['controller.py','audit_reader.py','lb_reader.py','linear_reader.py','be_reader.py','native_reader.py','r05_fft_reader.py']
for n in support:shutil.copy2(H/n,F/n)
P['source_and_binary_pins']={'../source/'+p.relative_to(H/'source').as_posix():sha(p) for p in (H/'source').rglob('*') if p.is_file()}
P['source_and_binary_pins']['../bin/ccmckp_s10']=sha(H/'bin/ccmckp_s10')
for n in ['USER_DESIGN.md','STATIC_REVIEW.json','SOURCE_MANIFEST_SHA256.json','VALIDATION.json','READER_VALIDATION.json','EXECUTION_NOTES.md','FULL_PROTOCOL_TEMPLATE.json','workflow.py','freeze_full_remote.py','decide_smoke_remote.py']:P['source_and_binary_pins']['../'+n]=sha(H/n)
for n in support:P['source_and_binary_pins'][n]=sha(F/n)
manifest=read(H/'source/BENCHMARK_MANIFEST.json');pins={}
for c in P['cases']:
 for n,h in manifest[c['instance']].items():
  assert sha(B/'benchmark'/c['instance']/n)==h;pins['benchmark/'+c['instance']+'/'+n]=h
P['input_pins']=pins;P['registered_utc']=datetime.now(timezone.utc).isoformat()
(F/'PROTOCOL.json').write_text(json.dumps(P,ensure_ascii=False,indent=2))
r={'status':'FROZEN_B2_V2_SMOKE_READY','registered_runs':40,'max_workers':60,'protocol_sha256':sha(F/'PROTOCOL.json'),
 'binary_sha256':sha(H/'bin/ccmckp_s10'),'input_pins':len(pins),'source_pins':len(P['source_and_binary_pins']),
 'free_disk_GiB':free/2**30,'quality_gate':P['pre_registered_quality_gate'],'launch_after_trackA_solver_completion':True}
(F/'FROZEN.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
