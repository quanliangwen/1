#pragma once
#include <gmpxx.h>
#include <algorithm>
#include <stdexcept>
#include <utility>
#include <vector>

namespace s10 {
// Global coarse coverage plus a heuristic local bracket. Six bisections give
// exact rational resolution, not a monotonicity or optimality guarantee.
struct BERadiusGrid {
 mpq_class maximum;
 explicit BERadiusGrid(mpq_class upper):maximum(std::move(upper)){
  maximum.canonicalize();if(maximum<0)throw std::logic_error("Negative grid radius");
 }
 mpq_class coarse(int r)const{
  if(r<0||r>8)throw std::logic_error("Coarse index");
  mpq_class x=maximum*r/8;x.canonicalize();return x;
 }
 std::pair<mpq_class,mpq_class> interval(int rstar)const{
  if(rstar<1||rstar>8)throw std::logic_error("Invalid winning index");
  return {coarse(rstar-1),coarse(rstar)};
 }
 static mpq_class midpoint(const mpq_class&lo,const mpq_class&hi){
  if(lo>hi)throw std::logic_error("Reversed bracket");
  mpq_class x=(lo+hi)/2;x.canonicalize();return x;
 }
 std::vector<mpq_class> pool(mpq_class best)const{
  auto clip=[&](mpq_class x){x.canonicalize();return std::min(maximum,std::max(mpq_class(0),x));};
  std::vector<mpq_class>out;
  for(auto p:{clip(std::max(mpq_class(1,20),mpq_class(best*97/100))),
              clip(std::max(mpq_class(1,20),mpq_class(best*99/100))),clip(best),clip(mpq_class(best*51/50))})
   if(std::find(out.begin(),out.end(),p)==out.end())out.push_back(p);
  return out;
 }
};
}
