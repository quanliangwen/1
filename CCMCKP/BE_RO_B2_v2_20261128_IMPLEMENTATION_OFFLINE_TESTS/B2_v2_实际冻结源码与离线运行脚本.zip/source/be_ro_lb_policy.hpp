#pragma once
#include "model.hpp"
#include <gmpxx.h>
#include <algorithm>
#include <map>
#include <cmath>
namespace s10 {
inline mpq_class b2_exact_cost(const Instance&d,const Selection&s){
 mpq_class c=0;for(int j:s)c+=mpq_class(d.costs.at(j));c.canonicalize();return c;
}
struct B2Cutoff {
 std::string mode;bool bounded;Selection reference;mpq_class exact_reference=0;
 double reference_cost=INFINITY,cutoff=INFINITY;
 bool permits(const mpq_class&candidate)const{return !bounded||candidate<=exact_reference-mpq_class(1,1000000);}
 Json json()const{return {{"mode",mode},{"has_upper_bound",bounded},{"reference_selection",reference},
  {"c_ref",bounded?Json(reference_cost):Json(nullptr)},{"c_cut",bounded?Json(cutoff):Json(nullptr)},
  {"c_ref_exact",bounded?Json(exact_reference.get_str()):Json(nullptr)},
  {"c_cut_exact",bounded?Json(mpq_class(exact_reference-mpq_class(1,1000000)).get_str()):Json(nullptr)}};}
};
// ordered is sorted by exact sum of the unchanged binary64 input costs.
inline B2Cutoff b2_compute_cutoff(const Instance&d,const Groups&ordered,double best_p,int entry_stall){
 if(ordered.empty()||entry_stall<0)throw std::logic_error("Cutoff state");
 B2Cutoff r;r.mode=(best_p>=.992||entry_stall>=1)?"strict_best":"topk_guard";
 r.bounded=r.mode=="strict_best"||ordered.size()>=5;
 if(r.bounded){r.reference=ordered[r.mode=="strict_best"?0:4];r.exact_reference=b2_exact_cost(d,r.reference);
  r.reference_cost=d.cost_of(r.reference);r.cutoff=r.reference_cost-1e-6;}
 return r;
}
}
