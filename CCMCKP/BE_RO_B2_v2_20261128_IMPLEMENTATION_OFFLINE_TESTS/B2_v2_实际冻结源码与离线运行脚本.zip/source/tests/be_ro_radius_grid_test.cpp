#include "be_ro_radius_grid.hpp"
#include "model.hpp"
#include <iostream>
using namespace s10;
int main(){
 try{
  int checks=0;
  for(const char*raw:{"0","1/1000","1/20","1","5099/1000","599/100","8"}){
   BERadiusGrid g{mpq_class(raw)};
   for(int r=1;r<=8;++r){
    mpq_class expected=g.maximum*r/8;expected.canonicalize();
    if(g.coarse(r)!=expected)throw std::logic_error("Coarse formula");++checks;
    auto v=g.interval(r);
    for(int pattern=0;pattern<64;++pattern){
     mpq_class lo=v.first,hi=v.second;
     for(int q=0;q<6;++q){
      auto mid=BERadiusGrid::midpoint(lo,hi);mpq_class expected=(lo+hi)/2;expected.canonicalize();
      if(mid!=expected||(g.maximum>0&&!(lo<mid&&mid<hi)))throw std::logic_error("Midpoint formula");
      if(pattern&(1<<q))hi=mid;else lo=mid;++checks;
     }
     mpq_class width=hi-lo,expected=g.maximum/512;width.canonicalize();expected.canonicalize();
     if(width!=expected)throw std::logic_error("Six rounds resolution");++checks;
    }
    for(const auto&x:g.pool(g.coarse(r))){if(x<0||x>g.maximum)throw std::logic_error("Pool clipping");++checks;}
   }
  }
  std::cout<<Json({{"status","PASS"},{"grid_checks",checks},{"arbitrary_window_hit_guarantee",false}}).dump()<<'\n';return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}
}
