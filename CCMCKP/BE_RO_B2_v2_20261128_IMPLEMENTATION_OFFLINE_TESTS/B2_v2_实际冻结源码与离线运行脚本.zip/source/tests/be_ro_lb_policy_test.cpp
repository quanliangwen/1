#include "be_ro_lb_policy.hpp"
#include "b2_fft_bridge.hpp"
#include <iostream>
using namespace s10;
int main(int argc,char**argv){try{
 if(argc!=2)return 2;phase_deadline=now()+60;Instance d(argv[1]);
 Groups ordered;Selection s;for(const auto&g:d.groups)s.push_back(g[0]);
 Groups all{{}};for(const auto&g:d.groups){Groups next;for(const auto&a:all)for(int j:g){auto b=a;b.push_back(j);next.push_back(b);}all=next;}
 std::sort(all.begin(),all.end(),[&](const Selection&a,const Selection&b){auto x=b2_exact_cost(d,a),y=b2_exact_cost(d,b);return x==y?a<b:x<y;});
 int policies=0,boundaries=0;
 for(int size:{1,4,5,6})for(double p:{std::nextafter(.992,0.),.992,std::nextafter(.992,1.)})for(int stall:{0,1}){
  Groups pool(all.begin(),all.begin()+size);auto c=b2_compute_cutoff(d,pool,p,stall);bool strict=p>=.992||stall>=1;
  if(c.mode!=(strict?"strict_best":"topk_guard")||c.bounded!=(strict||size>=5))throw std::logic_error("Policy mode");
  if(c.bounded){if(c.reference!=pool[strict?0:4])throw std::logic_error("Policy reference");
   mpq_class bound=c.exact_reference-mpq_class(1,1000000),step=mpq_class(1,mpz_class(1)<<100);
   if(!c.permits(bound)||!c.permits(mpq_class(bound-step))||c.permits(mpq_class(bound+step)))throw std::logic_error("Exact cutoff boundary");boundaries+=3;}
  ++policies;
 }
 // Rounded arithmetic would erase this positive excess; rational admission must not.
 B2Cutoff c;c.mode="strict_best";c.bounded=true;c.exact_reference=100;
 mpq_class excess=mpq_class(1,mpz_class(1)<<100),bad=c.exact_reference-mpq_class(1,1000000)+excess;
 if(c.permits(bad))throw std::logic_error("Sub-ULP excess admitted");++boundaries;
 std::unique_ptr<PolishFFT> exported;const void*storage=nullptr;double before=0;
 {B2FFTExportScope scope(exported);{B2CaptureFFT f(d.samples,d.groups,1.,8192,12);before=f.probability(s);storage=f.freq.front().data();}}
 if(!exported||exported->freq.front().data()!=storage||exported->probability(s)!=before||b2_fft_export_target)throw std::logic_error("FFT move export changed data");
 std::cout<<Json({{"status","PASS"},{"cutoff_policy_cases",policies},{"exact_boundary_checks",boundaries},{"FFT_storage_moved_not_recomputed",true},{"scope_reset_no_cross_run_cache",true}}).dump()<<'\n';return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
