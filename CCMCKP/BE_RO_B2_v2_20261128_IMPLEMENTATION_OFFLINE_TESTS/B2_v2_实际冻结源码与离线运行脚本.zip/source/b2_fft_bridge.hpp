#pragma once
#include "polish_fft.hpp"
#include <memory>
namespace s10 {
// Per-thread, per-run interface only. The original FFT arithmetic and the
// complete frozen be_ro_search.cpp remain unchanged. No persistent run cache.
inline thread_local std::unique_ptr<PolishFFT>* b2_fft_export_target=nullptr;
class B2CaptureFFT:public PolishFFT {
public:
 using PolishFFT::PolishFFT;
 ~B2CaptureFFT(){
  if(b2_fft_export_target){
   if(*b2_fft_export_target)std::terminate();
   *b2_fft_export_target=std::make_unique<PolishFFT>(std::move(static_cast<PolishFFT&>(*this)));
  }
 }
};
struct B2FFTExportScope {
 explicit B2FFTExportScope(std::unique_ptr<PolishFFT>&p){
  if(b2_fft_export_target||p)throw std::logic_error("Nested FFT export");
  b2_fft_export_target=&p;
 }
 ~B2FFTExportScope(){b2_fft_export_target=nullptr;}
};
}
#ifdef S10_CAPTURE_BE_STAGE1_FFT
// Resolve the unchanged Search declaration before the local-variable type
// substitution. Only the frozen Stage1 translation unit receives this adapter.
#include "search.hpp"
#define PolishFFT B2CaptureFFT
#endif
