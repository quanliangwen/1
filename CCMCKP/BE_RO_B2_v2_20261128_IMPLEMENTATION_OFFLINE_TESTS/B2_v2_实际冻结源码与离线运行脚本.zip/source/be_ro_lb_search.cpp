#include "search.hpp"
#include "be_ro_lb_rows.hpp"
#include "be_ro_lb_policy.hpp"
#include "b2_fft_bridge.hpp"
#include "isolated_native.hpp"
namespace s10 {
namespace {int changed(const Selection&a,const Selection&b){int n=0;for(std::size_t g=0;g<a.size();++g)n+=a[g]!=b[g];return n;}}
Json Search::be_ro_lb_run(){
 std::unique_ptr<PolishFFT> shared_fft;Json stage1;
 {B2FFTExportScope capture(shared_fft);options.search_flow="be_ro_pure";
  try{stage1=be_ro_run();}catch(...){options.search_flow="be_ro_lb";throw;}}
 options.search_flow="be_ro_lb";if(!shared_fft)throw std::logic_error("Stage1 FFT not exported");
 const auto directory=options.output.parent_path();write_json(directory/"BE_RO_STAGE1.json",stage1);
 auto ordered_pool=[&](){Groups v;for(const auto&q:pool)v.push_back(q.first);
  std::sort(v.begin(),v.end(),[&](const Selection&a,const Selection&b){auto x=b2_exact_cost(instance,a),y=b2_exact_cost(instance,b);return x==y?a<b:x<y;});return v;};
 Groups initial=ordered_pool();Json top=Json::array(),topcost=Json::array();
 for(std::size_t i=0;i<std::min<std::size_t>(5,initial.size());++i){top.push_back(pool.at(initial[i]).json());topcost.push_back(pool.at(initial[i]).cost);}
 double epsilon=be_ro_log.at("epsilon_fft_final").get<double>();
 Json milestone={{"stage1_bero_best_cost",best?Json(best->cost):Json(nullptr)},{"stage1_bero_topK",top},
  {"stage1_bero_topK_costs",topcost},{"stage1_certified_pool_size",pool.size()},{"stage1_bero_certified_count",pool.size()},
  {"stage1_eps_fft",epsilon},{"elapsed_before_LB",now()-started},{"source_seed",options.seed},
  {"stage1_source","unchanged_B1_v22_own_run_function"},{"stage1_raw_sha256",sha256(directory/"BE_RO_STAGE1.json")}};
 write_json(directory/"BE_RO_STAGE1_MILESTONE.json",milestone);
 for(const char*n:{"BE_RO_STAGE1.json","BE_RO_STAGE1_MILESTONE.json"}){int fd=::open((directory/n).c_str(),O_RDONLY);if(fd<0||::fsync(fd))throw std::runtime_error("Stage1 fsync failed");::close(fd);}
 be_ro_lb_log={{"model","BE_RO_LB_B2"},{"algorithm_version","B2-v2"},{"K",5},{"k_changed_groups",5},{"binary_Hamming_upper",10},
  {"historical_solution_inputs",false},{"external_MIPstarts",false},{"stage1_milestone",milestone},
  {"stage2_retains_BE_radius_constraint",false},{"stage2_row_is_probability_certificate",false},{"generator_LSS_calls",0},
  {"private_probability_cache_isolated",true},{"stage1_no_anchor_fallback",false},{"stage1_FFT_spectra_reused",true},
  {"cost_exactness","rational sum of unchanged binary64 item costs"},{"round_entry_stall_frozen",true},
  {"queries",Json::array()},{"candidates",Json::array()},{"native_calls",Json::array()},{"rounds",Json::array()},
  {"stage2_events",Json::array()},{"timing",stage1.at("BE_RO_model").at("timing")},
  {"stage2_entered",false},{"stage2_stop_reason","not_entered"}};
 be_ro_lb_log["timing"]["lb_mip_fft"]=0.;be_ro_lb_log["timing"]["lb_native_cdf"]=0.;
 if(initial.empty()||now()>=deadline){be_ro_lb_log["stop_reason"]="not_entered";be_ro_lb_log["epsilon_fft_final"]=epsilon;be_ro_lb_log["stop_seconds"]=now()-started;return save("completed");}
 be_ro_lb_log["stage2_entered"]=true;last_save=now()+1e9;
 auto&fft=*shared_fft;std::map<Selection,double>probabilities;
 std::set<Selection> excluded,native_attempted;
 for(const auto&q:be_ro_log.at("native_calls")){auto s=q.at("selection").get<Selection>();excluded.insert(s);native_attempted.insert(s);}
 for(const auto&q:pool)excluded.insert(q.first);
 auto probability_of=[&](const Selection&s){auto p=probabilities.find(s);if(p==probabilities.end())p=probabilities.emplace(s,fft.probability(s)).first;return p->second;};
 auto cutoff=[&](int entry){auto v=ordered_pool();return b2_compute_cutoff(instance,v,probability_of(v.front()),entry);};
 const double begin=now();double native_seconds=0;int stall=0,round=0;
 auto native=[&](const Selection&s,double probability,int current_round,int entry_stall,const B2Cutoff&cut){
  check_budget();const double b=now();if(b>=deadline)throw BudgetExpired();native_attempted.insert(s);
  auto before=ordered_pool();const double bp=probability_of(before.front());
  const double end=std::min(b+90.,started+options.seconds-30.);const int oldcalls=oracle.calls;const double oldseconds=oracle.seconds;
  auto child=isolated_native(end,[&](){
   deadline=started+options.seconds-30.;phase_deadline=end;last_save=now()+1e9;
   bool expired=false;try{native_check(s,"BE_RO_LB");}catch(const BudgetExpired&){expired=true;}
   Json z={{"expired",expired},{"state",pool.count(s)?"accepted":infeasible_proofs.count(s)?"infeasible":"unknown"},{"calls_delta",oracle.calls-oldcalls},{"seconds_delta",oracle.seconds-oldseconds}};
   if(pool.count(s))z["certificate"]=pool.at(s).certificate.json(s);else if(infeasible_proofs.count(s))z["certificate"]=infeasible_proofs.at(s).json(s);return z;
  });
  Json call={{"selection",s},{"cand_x",s},{"cost",instance.cost_of(s)},{"cand_cost",instance.cost_of(s)},
   {"cand_cost_exact",b2_exact_cost(instance,s).get_str()},{"round",current_round},{"entry_stall",entry_stall},
   {"cutoff_decision",cut.json()},{"mode",cut.mode},{"c_ref",cut.json()["c_ref"]},{"c_cut",cut.json()["c_cut"]},
   {"best_selection_before",before.front()},{"best_cost_before",pool.at(before.front()).cost},{"p_fft_best",bp},
   {"start",b-started},{"finish",now()-started},{"launch_t_sec",b-started},{"finish_t_sec",now()-started},
   {"slice_deadline",end-started},{"hard_timeout",child.timeout},{"elapsed",child.elapsed},{"state","unknown"},
   {"epsilon_before",epsilon},{"private_probability",probability},{"cand_p_fft",probability}};
  if(!child.timeout){auto&z=child.payload;call["state"]=z["state"];call["expired"]=z["expired"];oracle.calls+=z["calls_delta"].get<int>();oracle.seconds+=z["seconds_delta"].get<double>();
   if(z.contains("certificate")){auto c=z["certificate"];call["certificate"]=c;Certificate cert{mpz_class(c["lower_numerator"].get<std::string>()),mpz_class(c["upper_numerator"].get<std::string>()),mpz_class(c["denominator"].get<std::string>()),c["bins"].get<int>(),c["certificate_seconds"].get<double>()};
    if(z["state"]=="accepted"){accept(s,"BE_RO_LB",cert);probabilities[s]=probability;epsilon=std::max({epsilon,.001,.99-probability});best=pool.at(ordered_pool().front());}
    else if(z["state"]=="infeasible"){infeasible_proofs.insert_or_assign(s,cert);decisions[s]=cert.probability();}
   }
  }
  native_seconds+=now()-b;call["epsilon_after"]=epsilon;call["passed_099"]=call["state"]=="accepted";
  be_ro_lb_log["native_calls"].push_back(call);be_ro_lb_log["stage2_events"].push_back(call);return call.at("state").get<std::string>();
 };
 try{
  check_budget();PoolModel lb(instance,options.seed);
  while(now()<deadline&&stall<2){
   check_budget();auto ordered=ordered_pool();const Selection anchor=ordered.front();const auto before_exact=b2_exact_cost(instance,anchor);
   best=pool.at(anchor);const double before=best->cost;const int entry_stall=stall;auto p=fft.marginals(anchor);probabilities[anchor]=p.first;
   B2Cutoff cut=cutoff(entry_stall);BELBRows row(instance,anchor,p.first,p.second,epsilon,5,excluded,cut.cutoff);
   check_budget();const double b=now();if(b>=deadline)throw BudgetExpired();++round;
   Json q={{"round",round},{"entry_stall",entry_stall},{"start",b-started},{"anchor",anchor},{"best_before",before},
    {"Kth_before",ordered.size()>=5?Json(pool.at(ordered[4]).cost):Json(nullptr)},
    {"cutoff",cut.bounded?Json(cut.cutoff):Json(nullptr)},{"cutoff_decision",cut.json()},{"cutoff_mode",cut.mode},
    {"anchor_probability",p.first},{"epsilon_before",epsilon},{"risk",row.risk},{"rhs",row.rhs},
    {"excluded",Json::array()},{"raw_solutions",Json::array()}};
   for(const auto&s:excluded)q["excluded"].push_back(s);
   const double prior=phase_deadline;phase_deadline=started+options.seconds-30.;Json solverlog;Groups all;
   try{all=lb.solve(instance.costs,row.rows,2.,20,1e100,solverlog);}catch(...){phase_deadline=prior;throw;}
   phase_deadline=prior;++models;model_seconds+=now()-b;
   q["finish"]=now()-started;q["solver"]=solverlog;q["raw_solutions"]=all;be_ro_lb_log["queries"].push_back(q);
   if(all.empty()){be_ro_lb_log["stage2_stop_reason"]="mip_infeasible_or_empty";break;}
   std::set<Selection> distinct(all.begin(),all.end());std::set<Selection> previous_excluded=excluded;excluded.insert(distinct.begin(),distinct.end());
   struct Queued{Selection s;mpq_class cost;double score;};std::vector<Queued>queue;
   for(const auto&s:distinct){
    check_budget();const int distance=changed(s,anchor);double lhs=0;for(int j:s)lhs+=row.risk[j];
    Json r={{"selection",s},{"round",round},{"cost",instance.cost_of(s)},{"cost_exact",b2_exact_cost(instance,s).get_str()},
     {"distance_changed_groups",distance},{"risk_lhs",lhs},{"filter_stage","initial"},{"start",now()-started}};
    if(previous_excluded.count(s)||native_attempted.count(s))r["decision"]="already_attempted";
    else if(distance<1||distance>5||lhs>row.rhs+1e-8)r["decision"]="rounded_MIP_row_rejected";
    else{double score=probability_of(s);r["private_probability"]=score;r["epsilon_before"]=epsilon;
     if(score<.99-epsilon)r["decision"]="private_FFT_rejected";
     else if(!cut.permits(b2_exact_cost(instance,s)))r["decision"]="exact_initial_cutoff_rejected";
     else{r["decision"]="queued";queue.push_back({s,b2_exact_cost(instance,s),score});}}
    r["finish"]=now()-started;be_ro_lb_log["candidates"].push_back(r);
   }
   std::sort(queue.begin(),queue.end(),[](const Queued&a,const Queued&b){return a.cost==b.cost?(a.score==b.score?a.s<b.s:a.score>b.score):a.cost<b.cost;});
   for(const auto&cand:queue){
    if(now()>=deadline){be_ro_lb_log["stage2_stop_reason"]="launch_guard_480s";break;}
    B2Cutoff current=cutoff(entry_stall);
    Json r={{"selection",cand.s},{"cost",instance.cost_of(cand.s)},{"cost_exact",cand.cost.get_str()},{"round",round},
     {"filter_stage","dynamic"},{"entry_stall",entry_stall},{"private_probability",cand.score},{"epsilon_before",epsilon},
     {"cutoff_decision",current.json()},{"best_selection_before",ordered_pool().front()},
     {"p_fft_best",probability_of(ordered_pool().front())},{"start",now()-started}};
    if(!current.permits(cand.cost)){r["decision"]="dynamic_exact_cutoff_stop";r["finish"]=now()-started;be_ro_lb_log["candidates"].push_back(r);break;}
    r["decision"]=native(cand.s,cand.score,round,entry_stall,current);r["finish"]=now()-started;be_ro_lb_log["candidates"].push_back(r);
   }
   const bool improved=b2_exact_cost(instance,ordered_pool().front())<before_exact;stall=improved?0:stall+1;
   be_ro_lb_log["rounds"].push_back({{"round",round},{"entry_stall",entry_stall},{"best_before",before},{"best_after",pool.at(ordered_pool().front()).cost},
    {"improved",improved},{"stall_after",stall},{"raw_empty",false}});
   if(now()>=deadline){be_ro_lb_log["stage2_stop_reason"]="launch_guard_480s";break;}
  }
  if(be_ro_lb_log["stage2_stop_reason"]=="not_entered")be_ro_lb_log["stage2_stop_reason"]=stall>=2?"stall_converged_2_rounds":"launch_guard_480s";
 }catch(const BudgetExpired&){be_ro_lb_log["stage2_stop_reason"]="launch_guard_480s";be_ro_lb_log["partial"]=true;}
 be_ro_lb_log["stop_reason"]=be_ro_lb_log["stage2_stop_reason"];be_ro_lb_log["epsilon_fft_final"]=epsilon;
 be_ro_lb_log["stop_seconds"]=now()-started;be_ro_lb_log["timing"]["lb_mip_fft"]=now()-begin-native_seconds;be_ro_lb_log["timing"]["lb_native_cdf"]=native_seconds;
 return save("completed");
}
void Search::be_ro_lb_save_fields(Json&data){
 if(options.search_flow!="be_ro_lb")return;
 be_ro_lb_log["certified_pool"]=Json::array();for(const auto&q:pool)be_ro_lb_log["certified_pool"].push_back(q.second.json());
 be_ro_lb_log["stage2_lb_rounds"]=be_ro_lb_log["queries"].size();be_ro_lb_log["stage2_cutoff_mode_per_round"]=Json::array();int zero=0,accepted=0;
 for(const auto&q:be_ro_lb_log["queries"]){be_ro_lb_log["stage2_cutoff_mode_per_round"].push_back(q["cutoff_mode"]);const auto&s=q["solver"];if(s.value("solver_status",0)==9&&s.value("solutions_retained",0)==0)++zero;}
 for(const auto&c:be_ro_lb_log["native_calls"])if(c["state"]=="accepted")++accepted;
 be_ro_lb_log["stage2_mip_solcount0_timelimit_count"]=zero;be_ro_lb_log["stage2_native_calls"]=be_ro_lb_log["native_calls"].size();be_ro_lb_log["stage2_native_accepted"]=accepted;
 const auto&mile=be_ro_lb_log["stage1_milestone"];
 be_ro_lb_log["stage2_best_improved_over_stage1"]=best&&!mile["stage1_bero_best_cost"].is_null()&&best->cost<mile["stage1_bero_best_cost"].get<double>()-1e-8;
 data["algorithm_version"]="B2-v2";data["BE_RO_model"]=be_ro_log;data["BE_RO_LB_model"]=be_ro_lb_log;
 for(const char*n:{"stage1_bero_certified_count","stage1_bero_best_cost","stage1_bero_topK_costs","stage1_eps_fft"})data[n]=mile[n];
 data["config"]["LSS_reserve_seconds"]=120.;data["config"]["search_launch_deadline_seconds"]=480.;data["config"]["maximum_started_native_finish_seconds"]=570.;data["config"]["native_single_call_seconds"]=90.;
}
}
