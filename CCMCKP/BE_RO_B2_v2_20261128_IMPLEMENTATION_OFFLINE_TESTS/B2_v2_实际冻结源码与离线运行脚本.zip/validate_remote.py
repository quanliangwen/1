from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import subprocess,json,time,os,sys,copy,hashlib,pickle,shutil
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/be_ro_b2_v2_20261128';V=B/'work/be_ro_b1_v22_20261128';assert Path.cwd()==B and not (H/'smoke').exists()
sys.path.insert(0,str(H));from lb_reader import verify_lb
from native_reader import selected_model_count,integer_polynomial_count,grid_row
from r05_fft_reader import _private_fft_cache
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert read(V/'VALIDATION.json')['status']=='PASS' and read(V/'READER_VALIDATION.json')['status']=='PASS'
assert (H/'source/be_ro_search.cpp').read_bytes()==(V/'source/be_ro_search.cpp').read_bytes()
for n in ['be_ro_linear.cpp','be_ro_linear.hpp','be_ro_radius_grid.hpp','be_ro_witness.hpp','polish_fft.hpp','pool_model.cpp','report.cpp','evaluation.cpp','rng.cpp','isolated_native.hpp']:
 assert sha(H/'source'/n)==sha(V/'source'/n),n
for n,h in read(H/'SOURCE_MANIFEST_SHA256.json')['files'].items():assert sha(H/'source'/n)==h,n
heavy=H/'fixtures/LAB_6_2_500_';heavy.mkdir(exist_ok=True)
(heavy/'node_to_factor.pkl').write_bytes(pickle.dumps({g:[g,g+6] for g in range(6)},protocol=2));(heavy/'cost.txt').write_text('\n'.join(['2']*6+['1']*6)+'\n')
for j in range(12):(heavy/('%d_sample.txt'%j)).write_text(('0.01\n'*500) if j<6 else ('0\n'*499+'1000\n'))
none=H/'fixtures/LAB_2_2_NONE30_';none.mkdir(exist_ok=True)
for p in (H/'fixtures/LAB_2_2_30_').iterdir():
 if p.is_file():
  (none/p.name).write_text('2\n'*30) if p.name.endswith('_sample.txt') else (none/p.name).write_bytes(p.read_bytes())
unit=[]
for binary,log in [('be_ro_lb_math_test','LB_MATH.json'),('be_ro_lb_policy_test','LB_POLICY.json')]:
 receipt=H/log
 if receipt.exists():q=read(receipt);assert q['binary_sha256']==sha(H/'build'/binary)
 else:
  p=subprocess.run([str(H/'build'/binary),str(heavy)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=100);(H/(binary+'.log')).write_bytes(p.stdout);assert p.returncode==0,p.stdout.decode(errors='replace')[-2200:]
  q={'report':json.loads(p.stdout),'binary_sha256':sha(H/'build'/binary)};receipt.write_text(json.dumps(q,indent=2))
 assert q['report']['status']=='PASS';unit.append(q)
checks=[];tamper=0;certificates=0
for name,cap in [('LAB_3_2_500_','.5'),('LAB_2_2_500_','1.25'),('LAB_2_2_30_','1.25'),('LAB_6_2_500_','1'),('LAB_2_2_NONE30_','1.25')]:
 D=H/'fixtures'/name;out=H/'integration'/name;receipt=H/('integration_'+name+'.receipt.json')
 g=pickle.loads((D/'node_to_factor.pkl').read_bytes());groups=[g[k] for k in sorted(g)] if isinstance(g,dict) else g
 costs=[float(x) for x in (D/'cost.txt').read_text().split()];samples=[(D/('%d_sample.txt'%j)).read_text().split() for j in range(len(costs))]
 if not receipt.exists():
  assert not out.exists(),'Never overwrite tiny output'
  start=time.monotonic();env=dict(os.environ,CCMCKP_LAUNCH_MONOTONIC=str(start),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
  p=subprocess.run([str(H/'build/ccmckp_s10'),'--instance',str(D),'--capacity',cap,'--seed','1289991','--rep','1','--seconds','600','--out',str(out),'--search-flow','be_ro_lb'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=150,env=env)
  wall=time.monotonic()-start;(H/('integration_'+name+'.log')).write_bytes(p.stdout)
  receipt.write_text(json.dumps({'rc':p.returncode,'whole_seconds':wall,'binary_sha256':sha(H/'build/ccmckp_s10')}))
 launch=read(receipt);assert launch['rc']==(1 if 'NONE' in name else 0) and launch['binary_sha256']==sha(H/'build/ccmckp_s10');wall=launch['whole_seconds']
 raw=read(out/'S10_search.json');stage1=read(out/'BE_RO_STAGE1.json');milestone=read(out/'BE_RO_STAGE1_MILESTONE.json')
 assert milestone['stage1_raw_sha256']==sha(out/'BE_RO_STAGE1.json')
 v=verify_lb(raw,stage1,milestone,groups,costs,samples,cap)
 if 'NONE' in name:assert raw['selected'] is None and not raw['BE_RO_LB_model']['queries']
 else:
  res=read(out/'RESULT.json');assert res['original_LSS_confidence']>=.99 and res['acceptance_evaluator']=='LSS' and res['lss_sample_index_max']==len(samples[0])-1 and wall<600
 if name=='LAB_6_2_500_':assert milestone['stage1_bero_best_cost']==12 and raw['selected']['cost']==7 and v['LB_native_calls']>0 and v['LB_certified']>0
 d={'path':D,'groups':groups,'costs':costs,'ordered':{},'cache':{}}
 for q in stage1['BE_RO_model']['native_calls']+raw['BE_RO_LB_model']['native_calls']:
  if 'certificate' not in q:continue
  c=q['certificate'];s=q['selection'];lo,den=selected_model_count(d,s,c['bins'],cap,False);hi,den2=integer_polynomial_count([grid_row(d,j,c['bins'],F(cap),False,False) for j in s],c['bins'])
  assert lo==int(c['lower_numerator']) and hi==int(c['upper_numerator']) and den==den2==int(c['denominator']);certificates+=1
 def reject(bad):
  global tamper
  try:verify_lb(bad,stage1,milestone,groups,costs,samples,cap)
  except (AssertionError,KeyError,IndexError):tamper+=1
  else:raise AssertionError('Reader accepted mutation')
 for key,value in [('historical_solution_inputs',True),('external_MIPstarts',True),('K',6),('k_changed_groups',6),('algorithm_version','wrong'),('stage1_FFT_spectra_reused',False),('generator_LSS_calls',1),('round_entry_stall_frozen',False),('stage2_row_is_probability_certificate',True)]:
  bad=copy.deepcopy(raw);bad['BE_RO_LB_model'][key]=value;reject(bad)
 if raw['BE_RO_LB_model']['queries']:
  for key,value in [('rhs',100),('entry_stall',99),('excluded',[]),('cutoff_mode','wrong')]:
   bad=copy.deepcopy(raw);bad['BE_RO_LB_model']['queries'][0][key]=value;reject(bad)
 if raw['BE_RO_LB_model']['native_calls']:
  for key,value in [('start',481),('entry_stall',99),('cand_cost_exact','0'),('p_fft_best',0)]:
   bad=copy.deepcopy(raw);bad['BE_RO_LB_model']['native_calls'][0][key]=value;bad['BE_RO_LB_model']['stage2_events']=bad['BE_RO_LB_model']['native_calls'];reject(bad)
 checks.append({'fixture':name,'whole_seconds':wall,'rc':launch['rc'],'cost':read(out/'RESULT.json')['cost'] if (out/'RESULT.json').exists() else None,'stage1_best':milestone['stage1_bero_best_cost'],'independent':v});print(json.dumps(checks[-1]),flush=True);_private_fft_cache.clear()
report={'status':'PASS','tiny_integrations':checks,'unit_tests':unit,'reader_tamper_checks':tamper,'native_integer_certificates':certificates,
 'positive_LB_improves_own_stage1_12_to7':True,'no_anchor_no_fallback':True,'Stage1_full_file_byte_identical':True,'FFT_core_byte_identical_and_storage_move_tested':True,
 'original_LSS_components_identical':True,'inherited_B1_mathematics_limited_same_SHA_reuse':True,'no_extra_large_case_MC':True,'binary_sha256':sha(H/'build/ccmckp_s10')}
(H/'VALIDATION.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['tiny_integrations','unit_tests']}),flush=True)
