#pragma once
#include <cmath>
#include <limits>

namespace s10 {
namespace normal_detail {
// Cephes ndtri coefficients, Stephen L. Moshier, 1984, 1987, 1989.
// From SciPy 1.10.1. See third_party/LICENSE_SCIPY.txt.
/* sqrt(2pi) */
inline constexpr double s2pi = 2.50662827463100050242E0;

/* approximation for 0 <= |y - 0.5| <= 3/8 */
inline constexpr double P0[5] = {
    -5.99633501014107895267E1,
    9.80010754185999661536E1,
    -5.66762857469070293439E1,
    1.39312609387279679503E1,
    -1.23916583867381258016E0,
};

inline constexpr double Q0[8] = {
    /* 1.00000000000000000000E0, */
    1.95448858338141759834E0,
    4.67627912898881538453E0,
    8.63602421390890590575E1,
    -2.25462687854119370527E2,
    2.00260212380060660359E2,
    -8.20372256168333339912E1,
    1.59056225126211695515E1,
    -1.18331621121330003142E0,
};

/* Approximation for interval z = sqrt(-2 log y ) between 2 and 8
 * i.e., y between exp(-2) = .135 and exp(-32) = 1.27e-14.
 */
inline constexpr double P1[9] = {
    4.05544892305962419923E0,
    3.15251094599893866154E1,
    5.71628192246421288162E1,
    4.40805073893200834700E1,
    1.46849561928858024014E1,
    2.18663306850790267539E0,
    -1.40256079171354495875E-1,
    -3.50424626827848203418E-2,
    -8.57456785154685413611E-4,
};

inline constexpr double Q1[8] = {
    /*  1.00000000000000000000E0, */
    1.57799883256466749731E1,
    4.53907635128879210584E1,
    4.13172038254672030440E1,
    1.50425385692907503408E1,
    2.50464946208309415979E0,
    -1.42182922854787788574E-1,
    -3.80806407691578277194E-2,
    -9.33259480895457427372E-4,
};

/* Approximation for interval z = sqrt(-2 log y ) between 8 and 64
 * i.e., y between exp(-32) = 1.27e-14 and exp(-2048) = 3.67e-890.
 */

inline constexpr double P2[9] = {
    3.23774891776946035970E0,
    6.91522889068984211695E0,
    3.93881025292474443415E0,
    1.33303460815807542389E0,
    2.01485389549179081538E-1,
    1.23716634817820021358E-2,
    3.01581553508235416007E-4,
    2.65806974686737550832E-6,
    6.23974539184983293730E-9,
};

inline constexpr double Q2[8] = {
    /*  1.00000000000000000000E0, */
    6.02427039364742014255E0,
    3.67983563856160859403E0,
    1.37702099489081330271E0,
    2.16236993594496635890E-1,
    1.34204006088543189037E-2,
    3.28014464682127739104E-4,
    2.89247864745380683936E-6,
    6.79019408009981274425E-9,
};


template <std::size_t N>
double polynomial(double x, const double (&coefficients)[N], bool leading_one = false) {
    double value = leading_one ? 1.0 : coefficients[0];
    for (std::size_t i = leading_one ? 0 : 1; i < N; ++i)
        value = value * x + coefficients[i];
    return value;
}

inline double inverse_left_log(double log_p) {
    if (std::isinf(log_p)) return log_p;
    const double x = log_p >= -std::numeric_limits<double>::max() / 2
        ? std::sqrt(-2 * log_p) : 1.41421356237309504880 * std::sqrt(-log_p);
    const double z = 1 / x;
    const double correction = x < 8 ? z * polynomial(z, P1) / polynomial(z, Q1, true)
                                    : z * polynomial(z, P2) / polynomial(z, Q2, true);
    return correction - (x - std::log(x) / x);
}

inline double inverse(double p) {
    constexpr double boundary = 0.13533528323661269189;
    if (p <= boundary) return inverse_left_log(std::log(p));
    if (p > 1 - boundary) return -inverse_left_log(std::log(1 - p));
    const double y = p - .5, y2 = y * y;
    return (y + y * (y2 * polynomial(y2, P0) / polynomial(y2, Q0, true))) * s2pi;
}
} // namespace normal_detail

inline double normal_inverse_log(double log_p) {
    if (log_p < -2) return normal_detail::inverse_left_log(log_p);
    if (log_p > -0.14541345786885906) return -normal_detail::inverse(-std::expm1(log_p));
    return normal_detail::inverse(std::exp(log_p));
}
} // namespace s10
