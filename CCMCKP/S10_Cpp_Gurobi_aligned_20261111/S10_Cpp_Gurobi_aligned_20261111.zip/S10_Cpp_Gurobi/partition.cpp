#include "partition.hpp"
#include "x86-simd-sort/x86simdsort-static-incl.h"

namespace s10 {

void partition_indices(std::vector<double>& scores, std::vector<std::size_t>& indices,
                       std::size_t kth) {
    // NumPy 2.4.0 ArgQSelect_X86_V3 uses this exact indirect kernel.
    x86simdsortStatic::argselect(scores.data(), indices.data(), kth, scores.size(), true);
}

} // namespace s10
