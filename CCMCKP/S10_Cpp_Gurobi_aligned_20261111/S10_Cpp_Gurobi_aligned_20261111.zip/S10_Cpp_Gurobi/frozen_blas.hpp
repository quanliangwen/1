#pragma once

// The frozen NumPy uses the LP64 OpenBLAS CBLAS interface.
// Declare the used signatures so a runtime-only installation can be linked.
extern "C" {
void openblas_set_num_threads(int);
float cblas_sdot(int, const float*, int, const float*, int);
double cblas_ddot(int, const double*, int, const double*, int);
void cblas_sgemv(int, int, int, int, float, const float*, int, const float*, int,
                 float, float*, int);
void cblas_dgemv(int, int, int, int, double, const double*, int, const double*, int,
                 double, double*, int);
void cblas_dgemm(int, int, int, int, int, int, double, const double*, int,
                 const double*, int, double, double*, int);
}

namespace s10 {
constexpr int blas_row_major = 101;
constexpr int blas_col_major = 102;
constexpr int blas_no_transpose = 111;
constexpr int blas_transpose = 112;

inline void frozen_matvec(int rows, int cols, const float* a, const float* x, float* y) {
    if (rows == 1) {
        y[0] = cblas_sdot(cols, a, 1, x, 1);
    } else {
        cblas_sgemv(blas_col_major, blas_transpose, cols, rows, 1.f, a, cols, x, 1, 0.f, y, 1);
    }
}

inline void frozen_matvec(int rows, int cols, const double* a, const double* x, double* y) {
    if (rows == 1) {
        y[0] = cblas_ddot(cols, a, 1, x, 1);
    } else {
        cblas_dgemv(blas_col_major, blas_transpose, cols, rows, 1., a, cols, x, 1, 0., y, 1);
    }
}

inline void frozen_matmul(int rows, int inner, int cols, const double* a,
                          const double* b, double* c) {
    if (cols == 1) {
        frozen_matvec(rows, inner, a, b, c);
    } else if (rows == 1) {
        cblas_dgemv(blas_row_major, blas_transpose, inner, cols, 1.,
                    b, cols, a, 1, 0., c, 1);
    } else {
        cblas_dgemm(blas_row_major, blas_no_transpose, blas_no_transpose, rows, cols, inner,
                    1., a, inner, b, cols, 0., c, cols);
    }
}
} // namespace s10
