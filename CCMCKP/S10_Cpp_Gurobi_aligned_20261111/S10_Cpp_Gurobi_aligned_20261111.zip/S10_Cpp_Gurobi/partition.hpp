#pragma once

#include <cstddef>
#include <vector>

namespace s10 {

// Return NumPy's indirect partition of the score array for a single kth.
void partition_indices(std::vector<double>& scores, std::vector<std::size_t>& indices,
                       std::size_t kth);

} // namespace s10
