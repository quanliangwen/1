#pragma once
#define POCKETFFT_NO_MULTITHREADING
#define POCKETFFT_CACHE_SIZE 16
#include <pocketfft_hdronly.h>
#include <algorithm>
#include <cmath>
#include <complex>
#include <vector>

namespace s10 {
template <class T> using Freq = std::vector<std::complex<T>>;

template <class T>
Freq<T> forward(const std::vector<T>& row) {
    const std::size_t b = row.size();
    std::vector<T> input(2 * b);
    std::copy(row.begin(), row.end(), input.begin());
    Freq<T> out(b + 1);
    pocketfft::r2c({2 * b}, {sizeof(T)}, {sizeof(std::complex<T>)}, 0,
                  true, input.data(), out.data(), T(1));
    return out;
}

template <class T>
std::vector<T> inverse(const Freq<T>& freq, bool clip) {
    const std::size_t b = freq.size() - 1;
    std::vector<T> out(2 * b);
    pocketfft::c2r({2 * b}, {sizeof(std::complex<T>)}, {sizeof(T)}, 0,
                  false, freq.data(), out.data(), T(1) / T(2 * b));
    out.resize(b);
    if (clip)
        for (T& v : out) v = std::max(T(0), v);
    return out;
}

template <class T>
void multiply(Freq<T>& left, const Freq<T>& right) {
    // NumPy's x86-v3 complex multiply rounds one product before the fused
    // operation. Reproducing that order is significant for float32 beam PDFs.
    for (std::size_t k = 0; k < left.size(); ++k) {
        const auto [a, b] = std::pair{left[k].real(), left[k].imag()};
        const auto [c, d] = std::pair{right[k].real(), right[k].imag()};
        left[k] = {std::fma(a, c, -(b * d)), std::fma(a, d, b * c)};
    }
}

template <class T>
std::vector<T> convolve(const std::vector<T>& left, const std::vector<T>& right) {
    auto product = forward(left);
    multiply(product, forward(right));
    return inverse(product, true);
}

// scipy.fft transforms each operand at its input precision. NumPy promotes
// the two spectra to complex128 only for their subsequent product.
inline Freq<double> promote_spectrum(const Freq<float>& freq) {
    return Freq<double>(freq.begin(), freq.end());
}

inline std::vector<double> convolve(const std::vector<float>& left, const std::vector<double>& right) {
    auto product = promote_spectrum(forward(left));
    multiply(product, forward(right));
    return inverse(product, true);
}

inline std::vector<double> convolve(const std::vector<double>& left, const std::vector<float>& right) {
    auto product = forward(left);
    multiply(product, promote_spectrum(forward(right)));
    return inverse(product, true);
}
} // namespace s10
