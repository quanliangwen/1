#pragma once
#include "model.hpp"
#include <limits>
#include <memory>

namespace s10 {
struct LinearRow {
    Vector coefficients;
    double lower = -std::numeric_limits<double>::infinity();
    double upper = std::numeric_limits<double>::infinity();
};

struct BudgetedCapacity {
    const Vector& deviations;
    int gamma;
    double capacity;
};

class BinaryModel {
public:
    BinaryModel(const Instance& instance, int seed);
    ~BinaryModel();
    Groups solve(const Vector& objective, const std::vector<LinearRow>& rows, double seconds, int pool,
                 const BudgetedCapacity* budget = nullptr, const Groups& excluded = {});
private:
    struct Impl;
    std::unique_ptr<Impl> impl;
};
} // namespace s10
