import concurrent.futures,subprocess,pathlib,json,os,time
H=pathlib.Path(__file__).resolve().parent
cases=json.load(open(H/'frozen/original_experiment/cases.json'))
tasks=[(mode,i) for i in [19,20,39,40] for mode in ['cached','stable']]
def run(t):
 mode,i=t;c=next(c for c in cases if c['index']==i);out=H/'pilot_highs'/f'{mode}_{i}_r1.json.gz'
 cmd=['python3','-u',str(H/'src/run.py'),'--mode',mode,'--instance','/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/'+c['instance'],'--capacity',str(c['tmax']),'--seed','832273','--seconds','600','--out',str(out)]
 with open(str(out)+'.log','x') as log:
  started=time.time()
  try:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=630);result=dict(mode=mode,index=i,exit=r.returncode,wall=time.time()-started)
  except subprocess.TimeoutExpired:result=dict(mode=mode,index=i,exit='timeout',wall=time.time()-started)
 print(json.dumps(result),flush=True)
 return result
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,tasks))
(H/'pilot_highs/dispatch_results.json').write_text(json.dumps(results))
