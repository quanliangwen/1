import pathlib,itertools,json,numpy as np
from strict_select import EmpiricalOracle
H=pathlib.Path(__file__).parent
oracle=EmpiricalOracle('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/LAB_3_5_30_',1.2,3)
oracle.samples={0:np.array([0.,.2,.7]),1:np.array([.1,.6,.9]),2:np.array([0.,.3,.5])}
exact=sum(sum(x)<oracle.T for x in itertools.product(*oracle.samples.values()))/27
records=[]
for bins in [512,16384]:
 lo,hi=oracle.bounds((0,1,2),bins);assert lo<=exact<=hi,(lo,exact,hi);records.append(dict(bins=bins,lower=lo,exact=exact,upper=hi,passed=True))
(H/'strict_test.json').write_text(json.dumps(records,indent=2));print(json.dumps(records))
