import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import pathlib,json,gzip,numpy as np
H=pathlib.Path(__file__).parent;B=pathlib.Path('/home/junhao/quan/parallel_test_solver/CCMKCP/work/codex_v50_dro_ablation_20261016/results');raw=pathlib.Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark');cases=json.load(open(H/'frozen/original_experiment/cases.json'));results=[]
for i in [11,19,20,36,38]:
 data=[json.load(gzip.open(p,'rt')) for p in B.glob(f'B_CDF_DRO_MITM_{i:02d}_r*.json.gz')];d=min(data,key=lambda d:d['selected']['cost']);c=next(c for c in cases if c['index']==i)
 arrays=[np.loadtxt(raw/c['instance']/f'{j}_sample.txt')[:-1] for j in d['selected']['selection']];bins=262144;alpha=16.;probs=[]
 for upper in [True,False]:
  freq=np.ones(bins+1,dtype=complex)
  for a in arrays:
   ix=(np.ceil(a/c['tmax']*bins) if upper else np.floor(a/c['tmax']*bins)).astype(int)
   h=np.bincount(ix[ix<bins],minlength=bins)/len(a);freq*=np.fft.rfft(h*np.exp(-alpha*np.arange(bins)/bins),2*bins)
  probs.append(float(np.dot(np.fft.irfft(freq,2*bins)[:bins],np.exp(alpha*np.arange(bins)/bins))))
 results.append(dict(index=i,historical_best=d['selected']['cost'],original_observation=d['selected']['probability'],empirical_CDF_rounding_interval=probs,numerical_guard=1e-7))
print(json.dumps(results,indent=2));(H/'historical_best_probability_audit_more.json').write_text(json.dumps(results,indent=2))
