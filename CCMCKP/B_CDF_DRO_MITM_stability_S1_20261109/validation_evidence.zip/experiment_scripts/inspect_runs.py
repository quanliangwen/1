import json,gzip,pathlib,collections,hashlib
r=pathlib.Path('/home/junhao/quan/parallel_test_solver/CCMKCP/work/codex_v50_dro_ablation_20261016')
for i in [18,19,20,36,37,38,39,40]:
 data=[json.load(gzip.open(f,'rt')) for f in (r/'results').glob(f'B_CDF_DRO_MITM_{i}_r*.json.gz')]
 print(i,collections.Counter(round(d['selected']['cost'],8) for d in data))
 for d in sorted(data,key=lambda d:d['selected']['cost'])[::29]:
  obs=d['native_observations']; print('run',d['seed'],'cost',d['selected']['cost'],'calls',len(obs),'unique',len(set(tuple(x['selection']) for x in obs)),'zero',sum(x['probability']==0 for x in obs),'first',d['events'][0]['cost'],'stage',len(d['match_history']),'source',d['selected']['source'])
manifest=json.load(open('/home/quanliangwen/work/cdf_stability_20261109/frozen/original_experiment/source_inputs.json'))
root=pathlib.Path('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark')
files=[(k,v) for k,v in manifest.items() if '/benchmark/' in k]
bad=[k for k,v in files if hashlib.sha256(pathlib.Path(k).read_bytes()).hexdigest()!=v]
print('RAW_HASHES',len(files),'MISMATCHES',len(bad))
