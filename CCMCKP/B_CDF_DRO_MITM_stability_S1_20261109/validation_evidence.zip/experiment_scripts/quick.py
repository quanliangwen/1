import concurrent.futures,subprocess,pathlib,json,time
H=pathlib.Path(__file__).resolve().parent;cases=json.load(open(H/'frozen/original_experiment/cases.json'))
def run(c):
 i=c['index'];out=H/'quick_v2'/f'stable_{i}_r1.json.gz'
 cmd=['python3','-u',str(H/'src_v2/run.py'),'--instance','/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/'+c['instance'],'--capacity',str(c['tmax']),'--seed','832273','--seconds','120','--out',str(out)]
 with open(str(out)+'.log','x') as log:
  t=time.time()
  try:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=140);status=r.returncode
  except subprocess.TimeoutExpired:status='timeout'
 print(json.dumps(dict(index=i,exit=status,wall=time.time()-t)),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as p:list(p.map(run,[c for c in cases if c['index'] in [11,12,17,18,19,20,29,30,31,32,35,36,37,38,39,40]]))
