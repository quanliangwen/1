import pathlib,json,gzip,numpy as np
H=pathlib.Path(__file__).resolve().parent
B=pathlib.Path('/home/junhao/quan/parallel_test_solver/CCMKCP/work/codex_v50_dro_ablation_20261016/results')
for d in ['full_v3','full_v4','full_v5','pilot_highs']:
 for f in sorted((H/d).glob('*.json.gz')):
  x=json.load(gzip.open(f,'rt'));i=int(f.name.split('_')[1]);rr=[json.load(gzip.open(b,'rt'))['selected']['cost'] for b in B.glob(f'B_CDF_DRO_MITM_{i:02d}_r*.json.gz')];cost=x['selected']['cost'] if x['selected'] else None
  print(d,f.name,'cost',round(cost,8) if cost else None,'oldbest',round(min(rr),8),'gap%',round((cost/min(rr)-1)*100,4) if cost else None,'time',round(x['runtime_before_save'],2),'stages',len(x['match_history']),'calls',x['native_probability_calls'])
