import pathlib,zipfile,json,hashlib,platform,sys,numpy,scipy
H=pathlib.Path(__file__).parent
with zipfile.ZipFile(H/'validation_evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for dirname in ['validation','strict_validation']:
  for p in (H/dirname).rglob('*'):
   if p.is_file():z.write(p,str(p.relative_to(H)))
 for name in ['strict_select.py','strict_batch.py','strict_test.py','strict_test.json','strict_batch.log','validation_dispatch.log','BASELINE_AUDIT.json','candidate_verification.json','historical_best_probability_audit.json','historical_best_probability_audit_more.json']:
  z.write(H/name,name)
 for p in H.glob('*.py'):z.write(p,'experiment_scripts/'+p.name)
 for p in (H/'candidate').glob('*'):
  if p.is_file():z.write(p,'registered_source/'+p.name)
with zipfile.ZipFile(H/'development_evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for dirname in ['src','src_v2','src_v3','src_v4','src_v5','src_v6','pilot','pilot_highs','quick_v2','quick_v3','full_v3','full_v4','full_v5','full_v6']:
  for p in (H/dirname).rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts:z.write(p,str(p.relative_to(H)))
env=dict(python=sys.version,numpy=numpy.__version__,scipy=scipy.__version__,platform=platform.platform(),logical_cpu=__import__('os').cpu_count())
(H/'ENVIRONMENT.json').write_text(json.dumps(env,indent=2))
for n in ['validation_evidence.zip','development_evidence.zip']:print(n,(H/n).stat().st_size,hashlib.sha256((H/n).read_bytes()).hexdigest())
