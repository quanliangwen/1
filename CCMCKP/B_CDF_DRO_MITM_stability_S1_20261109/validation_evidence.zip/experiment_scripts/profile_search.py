import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import sys,pathlib,time,cProfile,pstats
H=pathlib.Path(__file__).parent;sys.path.insert(0,str(H/'src_v4'))
from stable_solver import StableSolver
from instance import load_instance
s=StableSolver(load_instance('/home/junhao/quan/parallel_test_solver/CCMKCP/benchmark/LAB_50_10_500_'),63,832273,600,H/'profile_run.json.gz',time.monotonic(),'B_CDF_DRO_MITM')
s.init_frontier();s.bins=1024;s.deadline=time.monotonic()+25
p=cProfile.Profile();p.enable();s.matching(.00025,list(range(0,50,2)),list(range(1,50,2)));p.disable();pstats.Stats(p).sort_stats('cumtime').print_stats(25)
