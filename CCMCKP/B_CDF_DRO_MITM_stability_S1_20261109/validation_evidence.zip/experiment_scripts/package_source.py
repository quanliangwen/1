import pathlib,zipfile,json,hashlib
H=pathlib.Path(__file__).parent
with zipfile.ZipFile(H/'source_S1.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in (H/'candidate').iterdir():
  if p.is_file():z.write(p,'source/'+p.name)
 for name in ['validate.py','summarize_validation.py','audit_validation.py','verify_candidate.py','baseline_audit.py']:
  z.write(H/name,'experiment_scripts/'+name)
 for name in ['BASELINE_AUDIT.json','candidate_verification.json','historical_best_probability_audit.json','historical_best_probability_audit_more.json']:
  z.write(H/name,name)
 z.write(H/'validation/REGISTRATION.json','REGISTRATION.json')
print(hashlib.sha256((H/'source_S1.zip').read_bytes()).hexdigest())
