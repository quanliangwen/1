import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
import argparse,json,time,random,hashlib
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--instance',required=True);ap.add_argument('--capacity',required=True,type=float);ap.add_argument('--seed',type=int,default=832273);ap.add_argument('--seconds',type=float,default=600);ap.add_argument('--out',required=True);ap.add_argument('--mode',choices=['frozen','cached','stable'],default='stable');a=ap.parse_args()
import numpy as np
from instance import load_instance
if a.mode=='frozen':from frozen_solver import Solver
else:
 from stable_solver import StableSolver,CachedSolver
 Solver=StableSolver if a.mode=='stable' else CachedSolver
from frozen_solver import atomic_json
out=Path(a.out).resolve();out.parent.mkdir(parents=True,exist_ok=True)
if out.exists():raise RuntimeError('No overwrite')
with out.with_name(out.name+'.lock').open('x') as f:f.write(str(os.getpid()))
np.random.seed(a.seed);random.seed(a.seed);started=time.monotonic();inst=load_instance(a.instance)
sol=Solver(inst,a.capacity,a.seed,a.seconds,out,started,'B_CDF_DRO_MITM');sol.run();elapsed=time.monotonic()-started
atomic_json(out.with_name(out.name+'.run.json'),dict(mode=a.mode,elapsed=elapsed,within_budget=elapsed<=a.seconds,selected=sol.best,seed=a.seed,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.glob('*.py')}))
print(json.dumps(dict(mode=a.mode,elapsed=elapsed,selected=sol.best)),flush=True)
