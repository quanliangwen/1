"""Independent integer/Fraction enclosures; no C++ writer, solver or sampler import."""
from fractions import Fraction as F
class IntervalMath:
 def __init__(self,bits=208,exp_terms=50,log_terms=90):
  self.q=1<<bits;self.ne=exp_terms;self.nl=log_terms;self.ln2=self.log_unit(F(2))
 @staticmethod
 def ceil(a,b):return -((-a)//b)
 def exp_negative(self,y):
  assert y>=0
  if y==0:return self.q,self.q
  k=0
  while y>F(1,2):y/=2;k+=1
  a,b=y.numerator,y.denominator;tl=th=lo=hi=self.q
  for n in range(1,self.ne+1):
   tl=tl*a//(b*n);th=self.ceil(th*a,b*n);lo+=tl;hi+=th
  tail=F(th)*y/(self.ne+1)/(1-y/(self.ne+2));hi+=self.ceil(tail.numerator,tail.denominator)
  for _ in range(k):lo=lo*lo//self.q;hi=self.ceil(hi*hi,self.q)
  return self.q*self.q//hi,self.ceil(self.q*self.q,lo)
 def log_unit(self,x):
  assert 1<=x<=2
  z=(x-1)/(x+1);z2=z*z;pl=self.q*z.numerator//z.denominator;ph=self.ceil(self.q*z.numerator,z.denominator);sl=sh=0
  for n in range(self.nl):
   sl+=pl//(2*n+1);sh+=self.ceil(ph,2*n+1);pl=pl*z2.numerator//z2.denominator;ph=self.ceil(ph*z2.numerator,z2.denominator)
  rem=F(2*ph,2*self.nl+1)/(1-z2)
  return 2*sl,2*sh+self.ceil(rem.numerator,rem.denominator)
 def log(self,x):
  assert x>0
  k=0
  while x<1:x*=2;k-=1
  while x>=2:x/=2;k+=1
  lo,hi=self.log_unit(x);a,b=self.ln2
  return (lo+k*a,hi+k*b) if k>=0 else (lo+k*b,hi+k*a)
 def weight(self,values,t):
  top=max(values)
  if min(values)==top:return top,top
  low=high=0
  for a in values:
   l,h=self.exp_negative(t*(top-a));low+=l;high+=h
  low//=len(values);high=self.ceil(high,len(values));assert low>0
  a,_=self.log(F(low,self.q));_,b=self.log(F(high,self.q))
  return top+F(a,self.q)/t,top+F(b,self.q)/t

_cache={}
_ref=IntervalMath()
