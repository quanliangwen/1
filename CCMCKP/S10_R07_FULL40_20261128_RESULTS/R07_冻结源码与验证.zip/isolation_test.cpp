#include "isolated_native.hpp"
#include <chrono>
#include <iostream>
namespace s10 {double now(){return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();}}
int main(){using namespace s10;int parent_state=0;Json checks=Json::array();
 auto a=isolated_native(now()+1,[&](){parent_state=9;return Json({{"integer",std::string(200,'9')}});});
 if(a.timeout||a.payload["integer"]!=std::string(200,'9')||parent_state!=0)return 1;checks.push_back("exact IPC and parent memory isolation");
 for(int k=0;k<4;++k){auto r=isolated_native(now()+.05,[](){usleep(2000000);return Json({{"bad",true}});});if(!r.timeout||!r.payload.is_null()||r.elapsed>.5)return 2;}
 int status;errno=0;if(waitpid(-1,&status,WNOHANG)!=-1||errno!=ECHILD)return 3;checks.push_back("4 blocked operations hard-killed and reaped");
 bool rejected=false;try{isolated_native(now()+1,[]()->Json{throw std::runtime_error("test child failure");});}catch(const std::runtime_error&){rejected=true;}if(!rejected)return 4;checks.push_back("child exception cannot become certificate");
 std::cout<<Json({{"status","PASS"},{"checks",checks}}).dump()<<std::endl;
}
