from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import json,subprocess,os,time,pickle,hashlib,copy,sys
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/r07_adaptive_20261127';assert Path.cwd()==B and not (H/'smoke').exists()
sys.path.insert(0,str(H));from r07_reader import verify_r07,verify_r07_timing
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
unchanged=['evaluation.cpp','evaluation.hpp','rng.cpp','rng.hpp','report.cpp','report.hpp','model.cpp','model.hpp','mip.cpp','mip.hpp','fft.hpp','partition.hpp','block_mitm.hpp','block_bounds.hpp','block_schedule.hpp','convolution_tree.hpp','winf_product.hpp','transport_cuts.hpp','budget_ro.hpp','calibrated_budget.hpp','calibrated_search.cpp','pool_model.cpp','pool_model.hpp','entropic_math.hpp','entropic_model.hpp','entropic_search.cpp','polish_fft.hpp','polish_search.cpp']
for n in unchanged:assert sha(H/'source'/n)==sha(B/'work/r04_budget_fft_polish_20261127/source'/n),n
old=(B/'work/r04_budget_fft_polish_20261127/source/search.cpp').read_text();new=(H/'source/search.cpp').read_text()
for key in ['double Search::native_check','Json Search::shortlist','void Search::final_check']:
 def span(s):i=s.index(key);return s[i:s.index('\n}',i)+2]
 assert span(old)==span(new),key
checks=[];tamper=0
# New L=30 fixture checks the changed upper-tail window without a new real MC study.
src=H/'fixtures/LAB_2_2_500_';small=H/'fixtures/LAB_2_2_30_';small.mkdir(exist_ok=True)
for f in src.iterdir():
 if f.is_file():
  if f.name.endswith('_sample.txt'): (small/f.name).write_text('\n'.join([f.read_text().splitlines()[k*500//30] for k in range(30)])+'\n')
  else:(small/f.name).write_bytes(f.read_bytes())
for name,cap,expected in [('LAB_3_2_500_','.5',3),('LAB_2_2_500_','1.25',4),('LAB_2_2_30_','1.25',4)]:
 out=H/'integration_final'/name;assert not out.exists()
 start=time.monotonic();env=dict(os.environ,CCMCKP_LAUNCH_MONOTONIC=str(start),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
 p=subprocess.run([str(H/'build/ccmckp_s10'),'--instance',str(H/'fixtures'/name),'--capacity',cap,'--seed','1079001','--seconds','60','--out',str(out),'--search-flow','adaptive_dual_gated'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60,env=env)
 wall=time.monotonic()-start;(H/('integration_'+name+'.log')).write_bytes(p.stdout);assert p.returncode==0,p.stdout.decode(errors='replace')
 raw=json.loads((out/'S10_search.json').read_text());res=json.loads((out/'RESULT.json').read_text());timing=json.loads((out/'R07_TIMING.json').read_text())
 assert res['cost']==expected and res['original_LSS_confidence']>=.99 and res['lss_sample_index_max']==(29 if name.endswith('_30_') else 499)
 D=H/'fixtures'/name;g=pickle.loads((D/'node_to_factor.pkl').read_bytes());groups=[g[k] for k in sorted(g)] if isinstance(g,dict) else g
 costs=[float(x) for x in (D/'cost.txt').read_text().split()];samples=[(D/f'{j}_sample.txt').read_text().split() for j in range(len(costs))]
 ver=verify_r07(raw,groups,costs,samples,cap);verify_r07_timing(timing,wall)
 # Sparse exact integer convolution verifies each new-flow tiny native certificate.
 def sparse(s,bins,up):
  poly={0:1}
  for j in s:
   counts=Counter()
   for v in samples[j]:
    a=F(v)*bins/F(cap);k=-((-a.numerator)//a.denominator) if up else a.numerator//a.denominator
    if k<bins:counts[k]+=1
   nxt={}
   for a,va in poly.items():
    for b,vb in counts.items():
     if a+b<bins:nxt[a+b]=nxt.get(a+b,0)+va*vb
   poly=nxt
  return sum(poly.values())
 certificates=0
 for q in raw['R07_model']['certified_pool']:
  c=q['certificate'];assert sparse(q['selection'],c['bins'],True)==int(c['lower_numerator']);assert sparse(q['selection'],c['bins'],False)==int(c['upper_numerator']);certificates+=1
 def reject(bad):
  global tamper
  try:verify_r07(bad,groups,costs,samples,cap)
  except (AssertionError,KeyError,IndexError):tamper+=1
  else:raise AssertionError('reader accepted mutation')
 for k,v in [('historical_solution_inputs',True),('generator_LSS_calls',1),('private_cache_isolated',False),('nearest_rounding_is_unbiased_claim',True),('precision_damping',0),('epsilon_fft_final',.5),('watchdog_timeouts',999)]:
  bad=copy.deepcopy(raw);bad['R07_model'][k]=v;reject(bad)
 if raw['r07_private_history']:
  bad=copy.deepcopy(raw);bad['r07_private_history'][0]['probability']=-1;reject(bad)
 bad=copy.deepcopy(raw);bad['R07_model']['certified_pool'][0]['certificate']['lower_numerator']='0';reject(bad)
 bad=copy.deepcopy(timing);bad['timing']['unaccounted_overhead']+=2
 try:verify_r07_timing(bad,wall)
 except AssertionError:tamper+=1
 else:raise AssertionError('timing mutation not detected')
 checks.append({'fixture':name,'cost':res['cost'],'whole_seconds':wall,'verified':ver,'sparse_exact_certificates':certificates});print(json.dumps(checks[-1]),flush=True)
v={'status':'PASS','new_full_tiny_integrations':checks,'new_reader_tamper_checks':tamper,'unchanged_bytes':unchanged,'original_native_shortlist_final_check_byte_identical':True,'no_extra_large_case_MC':True,'binary_sha256':sha(H/'build/ccmckp_s10'),'source_sha256':{p.relative_to(H/'source').as_posix():sha(p) for p in (H/'source').rglob('*') if p.is_file()}}
v['isolation_tests']=json.loads((H/'ISOLATION_TESTS.json').read_text());(H/'VALIDATION.json').write_text(json.dumps(v,indent=2));print(json.dumps({'status':'PASS','checks':len(checks),'tamper':tamper}))
