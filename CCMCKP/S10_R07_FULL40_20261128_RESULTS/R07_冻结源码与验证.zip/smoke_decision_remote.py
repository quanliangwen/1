from pathlib import Path
from datetime import datetime,timezone
import json,statistics,sys,hashlib,os
B=Path('/home/junhao/quan/parallel_test_solver/CCMKCP');H=B/'work/r07_adaptive_20261127';F=H/'smoke';assert Path.cwd()==B
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert read(F/'COMPLETED.json')['terminal']==30 and read(F/'FINAL_AUDIT_PROCESS.json')['rc']==0
A=read(F/'PILOT_INDEPENDENT_AUDIT.json');P=read(F/'PROTOCOL.json');sys.path.insert(0,str(F));from r05_fft_reader import r05_private_tools
R={k:[] for k in [11,18,38,19,35,39]};details=[]
for x in A['rows']:
 root=F/'runs'/x['identity'];raw=read(root/'S10_search.json') if (root/'S10_search.json').exists() else None
 q=dict(identity=x['identity'],case=x['case_index'],rep=x['rep'],valid=x['valid'],errors=x['errors'],cost=x.get('cost'),wall=x['process_wall_seconds'])
 if raw:
  m=raw['R07_model'];q.update(raw_best=m['final_best_internal_cost'],mother=m.get('mother_only_best_cost'),local_rounds=m.get('local_mckp_rounds',len(m.get('local_rounds',[]))),watchdog=m['watchdog_timeouts'],polish_partial=m.get('polish_partial',False),ES95_finished=m['ES95_finished_seconds'],mother_finished=m['mother_finished_seconds'],private_proposals=len(raw['r07_private_history']))
  if x['case_index']==11:
   import pickle
   D=B/'benchmark'/x['instance'];g=pickle.loads((D/'node_to_factor.pkl').read_bytes());groups=[g[k] for k in sorted(g)] if isinstance(g,dict) else g
   costs=[float(v) for line in (D/'cost.txt').read_text().splitlines() for v in line.split('#')[0].split()];samples=[(D/(str(j)+'_sample.txt')).read_text().split() for j in range(len(costs))]
   sel,cost,prob,_,_=r05_private_tools(groups,costs,samples,x['capacity'] if 'capacity' in x else 12.)
   best=raw['selected']['selection'];eps=m['epsilon_fft_final'];level=min(prob(best),.99)-eps
   eligible=[v for v in m['certified_pool'] if v['selection']!=best and 48.2<=v['cost']<=49.2 and prob(v['selection'])>=level]
   q['case11_qualified_fallback_48_2_to49_2']=len(eligible);q['case11_fallback_costs']=sorted(v['cost'] for v in eligible)
 R[x['case_index']].append(q);details.append(q)
tests={'all30_independent_valid_source_clock_clean':len(A['rows'])==30 and A['independent_valid']==30 and not A['global_errors'],
 'case11_all5_min4_qualified_cost_range':len(R[11])==5 and all(q.get('case11_qualified_fallback_48_2_to49_2',0)>=4 for q in R[11]),
 'case11_avg5_at_most48_28':len(R[11])==5 and all(q['cost'] is not None for q in R[11]) and statistics.mean(q['cost'] for q in R[11])<=48.28+1e-9,
 'case38_all5_internal_cost_at_most196_29':len(R[38])==5 and all(q.get('raw_best') is not None and q['raw_best']<=196.29+1e-9 for q in R[38])}
for k in [19,35,39]:tests['case%d_avg5_not_higher_R06'%k]=len(R[k])==5 and all(q['cost'] is not None for q in R[k]) and statistics.mean(q['cost'] for q in R[k])<=P['smoke_gate']['cases19_35_39_avg5_not_higher_than_frozen_R06_avg30'][str(k)]+1e-9
decision={'utc':datetime.now(timezone.utc).isoformat(),'pass':all(tests.values()),'tests':tests,'details':details,'only5_descriptive_not30_or_significance':True,'historical_R06_not_fresh_paired_control':True,'full40_allowed':all(tests.values()),'no_retuning_or_failed_run_retries':True,'audit_sha256':sha(F/'PILOT_INDEPENDENT_AUDIT.json')}
assert not (F/'SMOKE_FUNCTIONAL_DECISION.json').exists();(F/'SMOKE_FUNCTIONAL_DECISION.json').write_text(json.dumps(decision,ensure_ascii=False,indent=2))
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  args=(p/'cmdline').read_bytes().split(b'\0')
  if any(str(H).encode() in a and (b'controller.py' in a or b'ccmckp_s10' in a or b'audit_reader.py' in a) for a in args):active.append(p.name)
 except OSError:pass
assert not active,active
health={'status':'PASS','all_registered_workers_terminal':True,'residual_controller_worker_audit_pids':active,'max_actual_worker_wall_seconds':max(q['wall'] for q in details),'resource_events':read(F/'COMPLETED.json')['resource_events'],'max_active':read(F/'COMPLETED.json')['max_active_observed'],'old_results_not_modified':True}
(H/'SMOKE_COMPLETION_HEALTH.json').write_text(json.dumps(health,indent=2));print(json.dumps({'pass':decision['pass'],'tests':tests,'health':health},ensure_ascii=False))
