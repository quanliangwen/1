from fractions import Fraction as F
import math
from adaptive_r07_reader import verify_adaptive_r07
from interval_reader import IntervalMath
from r05_fft_reader import r05_private_tools
_coeff={}
def verify_r07(raw,groups,costs,samples,capacity):
 m=raw['R07_model'];calls=raw['r07_native_calls'];hist=raw['r07_private_history'];assert raw['search_flow']=='adaptive_dual_gated'
 assert m['generator_LSS_calls']==0 and not m['historical_solution_inputs'] and m['private_cache_isolated'] and not m['private_FFT_is_certificate']
 assert not m['nearest_rounding_is_unbiased_claim'] and m['precision_damping']==12
 parent=dict(raw,search_flow='cvar_budget_calibrated',candidate_shortlist=m['ES95_pool'])
 budget=verify_adaptive_r07(parent,groups,costs,samples,capacity)
 select,cost,prob,marginal,near=r05_private_tools(groups,costs,samples,capacity)
 if 'sigma_reference_selection' not in m:
  assert m.get('entropic_partial') and m['mother_finished_seconds']>=479
  ent={}
 else:
  ref=m['sigma_reference_selection'];select(ref)
  variance=0.
  for j in ref:
   a=[F(v) for v in samples[j]];mu=sum(a,F())/len(a);variance+=float(sum((x*x for x in a),F())/len(a)-mu*mu)
  sigma=math.sqrt(max(0.,variance));near(sigma,m['sigma_ref_used']);tilts=[]
  for c,t,exact in zip([2,1,.5,3],m['entropic_t_values_used'],m['entropic_t_exact']):
   near(t,max(.001,min(50,c/sigma)) if sigma else 50);assert F.from_float(t)==F(exact);tilts.append(F(exact))
  em=raw['entropic_model'];assert F(em['eta_floor'])==F(3,5) and not em['historical_solution_inputs']
  cache=_coeff.setdefault((id(groups),str(capacity)),{});tabs={};interval=IntervalMath()
  for k,tab in enumerate(em['tables']):
   assert k<4 and tab['index']==k and F(tab['t'])==tilts[k]
   ck=(k,tilts[k])
   if ck not in cache:cache[ck]=[interval.weight([F(v) for v in a],tilts[k]) for a in samples]
   lower=[];upper=[]
   for j,item in enumerate(tab['items']):
    lo,hi=F(item['lower']),F(item['upper']);a,b=cache[ck][j];assert lo<=a<=b<=hi and hi-lo<F(1,10**35);lower.append(lo);upper.append(hi)
   tabs[k]=(lower,upper)
  ent={}
  for q in raw['entropic_proposals']:
   s=q['selection'];select(s);k=q['table_index'];eta=F(q['eta']);assert F(3,5)<=eta<=F(921,200) and F(q['t'])==tilts[k]
   lo,hi=tabs[k];rhs=F(str(capacity))-F(1,10**8)-eta/tilts[k]
   assert F(q['weight_sum_lower'])==sum((lo[j] for j in s),F()) and F(q['weight_sum_upper'])==sum((hi[j] for j in s),F())<=rhs==F(q['rhs_exact'])
   assert q['own_run_raw_samples'] and not q['empirical_0.99_sufficient_eta'];ent[tuple(s)]=q
 roots={tuple(q['selection']) for q in raw['adaptive_RO_proposals'] if q['robust_feasible'] and q['fixed_theta_feasible']}|set(ent)
 for x in hist:
  v=x['selection'];select(v);near(x['probability'],prob(v))
  if x['stage']=='entropic':assert tuple(v) in ent
  else:
   assert tuple(x['anchor']) in roots
   d=sum(a!=b for a,b in zip(v,x['anchor']));assert d==x['distance']
   if x['stage'].endswith('_one'):assert d==1
   elif x['stage'].endswith('_two'):assert d==2
   else:assert 1<=d<=(3 if x['stage'].startswith('B') else 5)
   roots.add(tuple(v))
 for task in raw['r07_local_MIP']:
  a=task['anchor'];p,values=marginal(a);near(p,task['anchor_probability']);near(task['rhs'],p-(.99 if task['kind']=='B' else .99-task['epsilon']))
  assert 0<=task['start']<=480.001 and task['finish']>=task['start']
  for j,v in enumerate(task['risk']):near(v,p-values[j])
  for v in task['returned']:
   select(v);assert tuple(v) not in {tuple(x) for x in task['excluded']}
   assert task['radius_min']<=sum(x!=y for x,y in zip(a,v))<=task['radius_max']
   if task['cost_upper_exact'] is not None:assert cost(v)<=F(task['cost_upper_exact'])
   assert sum(task['risk'][j] for j in v)<=task['rhs']+1e-7
 for task in raw['r07_MIP_launches']:assert 0<=task['start']<=480.001
 known={};inc=None;prior=None;epsilon=.0015;completed=[];seen=set();timeouts=0
 for q in calls:
  v=q['selection'];select(v);key=tuple(v);assert key in roots and key not in seen;seen.add(key)
  near(q['cost'],float(cost(v)));near(q['private_probability'],prob(v));near(q['epsilon_before'],epsilon)
  assert q['best_selection_before']==inc
  if inc is None:assert q['best_cost_before'] is None
  else:near(q['best_cost_before'],prior)
  assert 0<=q['start']<=480.001 and q['completed_calls_before']==len(completed)
  import statistics
  med=statistics.median(completed) if len(completed)>=3 else 2.
  near(q['median_before'],med);near(q['tau_call'],min(q['search_deadline']-q['start'],max(15,min(35,10*med))))
  near(q['slice_deadline'],q['start']+q['tau_call'])
  assert 0<=q['isolated_elapsed']<=q['tau_call']+1 and q['elapsed']>=q['isolated_elapsed']-.001
  assert q['finish']>=q['start']+q['isolated_elapsed']-.001
  stage=q['stage']
  if stage in ['stage2_entropic_cdf','stage3a_cdf','stage3b_cdf','stage4_cdf']:
   assert q['private_probability']>=.99-epsilon-1e-10
   if stage=='stage4_cdf':
    eligible=sorted([x for x in known if list(x)!=inc and prob(x)>=min(prob(inc),.99)-epsilon],key=lambda x:(cost(x),x))
    assert q['fallback_count_before']==len(eligible)
    cap=cost(eligible[3]) if len(eligible)>=4 else None
   else:cap=cost(inc) if inc is not None else None
   if stage.startswith('stage3') or stage=='stage4_cdf':assert q['admission_cap_exact']==(str(cap) if cap is not None else None)
   if cap is not None:assert cost(v)<=cap-F(1,1000000)
  if q['hard_timeout']:assert q['state']=='unknown' and 'certificate' not in q
  if q['expired']:timeouts+=1
  else:completed.append(q['isolated_elapsed'])
  if q['state'] in ['accepted','infeasible']:
   cert=q['certificate'];assert cert['selection']==v and cert['all_original_samples'] and cert['strict_event']=='sum<T'
   den=int(cert['denominator']);lo=int(cert['lower_numerator']);hi=int(cert['upper_numerator'])
   assert den==len(samples[0])**len(groups) and 0<=lo<=hi<=den
   if q['state']=='accepted':
    assert lo*100>=99*den;known[key]=cert;epsilon=max(epsilon,.001,.99-q['private_probability'])
    if inc is None or q['cost']<prior-1e-8:inc=v;prior=q['cost']
   else:assert hi*100<99*den
  near(q['epsilon_after'],epsilon)
  if inc is None:assert q['best_cost_after'] is None
  else:near(q['best_cost_after'],prior)
 near(epsilon,m['epsilon_fft_final']);assert m['watchdog_timeouts']==timeouts and m['completed_native_times']==completed
 for q in m['certified_pool']+raw['candidate_shortlist']:assert tuple(q['selection']) in known and q['certificate']==known[tuple(q['selection'])]
 rounds=m.get('local_rounds',[]);stall=0
 for k,q in enumerate(rounds,1):
  assert q['round']==k and stall<2
  improved=q['best_after']<q['best_before']-1e-6;stall=0 if improved else stall+1
  assert q['improved']==improved and q['stall_after']==stall
 assert len(m.get('fallback_rounds',[]))<=2
 return dict(budget,entropic_proofs=len(ent),polish_history=len(hist),polish_mips=len(raw['r07_local_MIP']),polish_proposals=sum(q['stage'].startswith('stage3') or q['stage']=='stage4_cdf' for q in calls),watchdog_timeouts=timeouts)

def verify_r07_timing(t,wall):
 a=t['timing'];assert all(math.isfinite(x) and x>=-.001 for x in a.values());assert abs(sum(a.values())-t['elapsed_before_timing_save'])<.001 and abs(wall-sum(a.values()))<1
