from pathlib import Path
import json,hashlib,tarfile,zipfile,io,shutil
R=Path(__file__).resolve().parent;O=R.parent;D=R/'delivery';E=O/'evidence'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Keep authoring previews and debug inspection in the temporary workspace.
for p in D.glob('*.inspect.ndjson'):p.replace(R/p.name)
p=D/'R07_全40算例1200次_最终测试总结.md';lines=p.read_text(encoding='utf-8').splitlines();out=[]
for line in lines:
 if line.startswith('- ') and out and out[-1] and not out[-1].startswith('- '):out.append('')
 out.append(line)
p.write_text('\n'.join(out)+'\n',encoding='utf-8')
manifest=json.loads((O/'COLLECTION_RECEIPT.json').read_text(encoding='utf-8'));full={n:v for n,v in manifest.items() if n.startswith('full40/')}
assert len([n for n in full if n.startswith('full40/outcomes/')])==1200
assert len({n.split('/')[2] for n in full if n.startswith('full40/runs/')})==1200
archive=R/'R07_FULL40_all_compact_evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for n,q in sorted(full.items()):
  p=E/n;assert p.stat().st_size==q['bytes'] and sha(p)==q['sha256'],n;tar.add(p,arcname=n)
 raw=json.dumps(full,ensure_ascii=False,indent=2).encode('utf-8');info=tarfile.TarInfo('FULL40_SHA256.json');info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
parts=[];total=hashlib.sha256()
with archive.open('rb') as f:
 k=0
 while True:
  b=f.read(48*2**20)
  if not b:break
  k+=1;name=f'R07_FULL40_紧凑证据.tar.gz.part{k:03d}';(D/name).write_bytes(b);total.update(b);parts.append({'name':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
assert total.hexdigest()==sha(archive)
(D/'证据分片清单.json').write_text(json.dumps({'archive':'R07_FULL40_all_compact_evidence.tar.gz','archive_sha256':total.hexdigest(),'archive_bytes':archive.stat().st_size,'full40_registered_runs':1200,'full40_files':len(full),'all_payload_files_SHA256_inside_archive':'FULL40_SHA256.json','parts':parts},ensure_ascii=False,indent=2),encoding='utf-8')
(D/'merge_evidence.py').write_text('''from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent;P=json.loads((R/'证据分片清单.json').read_text(encoding='utf-8'));out=R/P['archive'];assert not out.exists()
h=hashlib.sha256()
with out.open('xb') as f:
 for q in P['parts']:
  b=(R/q['name']).read_bytes();assert len(b)==q['bytes'] and hashlib.sha256(b).hexdigest()==q['sha256'];f.write(b);h.update(b)
assert out.stat().st_size==P['archive_bytes'] and h.hexdigest()==P['archive_sha256'];print('SHA256 verified:',h.hexdigest())
''',encoding='utf-8')
with zipfile.ZipFile(D/'R07_统计与Excel生成代码.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['prepare_statistics.py','build_excel.mjs','build_markdown.py','verify_delivery.py','package_delivery.py']:
  if (R/name).exists():z.write(R/name,name)
print(json.dumps({'archive_bytes':archive.stat().st_size,'parts':len(parts),'full40_files':len(full),'sha256':total.hexdigest()}))
