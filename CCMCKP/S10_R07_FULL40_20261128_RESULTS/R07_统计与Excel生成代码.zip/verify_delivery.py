from pathlib import Path
import json,csv,hashlib,zipfile,xml.etree.ElementTree as ET,statistics,math
R=Path(__file__).resolve().parent;O=R.parent;D=R/'delivery';E=O/'evidence'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
S=read(R/'statistics.json');A=read(D/'full40_FINAL_INDEPENDENT_AUDIT.json');P=read(D/'full40_PROTOCOL.json');g=S['groups'];rows=S['rows']
assert len(g)==40 and len(rows)==A['terminal']==A['independent_valid']==1200 and not A['global_errors']
assert len({(x['case_index'],x['rep']) for x in rows})==1200
for q in g:
 rr=[x for x in rows if x['case_index']==q['case_index']];assert len(rr)==30
 assert q['best']==min(x['cost'] for x in rr) and q['avg']==statistics.mean(x['cost'] for x in rr) and q['sample_std']==statistics.stdev(x['cost'] for x in rr)
 assert q['whole_mean_seconds']==statistics.mean(x['whole_seconds'] for x in rr)
 assert all(x['independent_valid']==1 and x['LSS']>=.99 and 0<x['whole_seconds']<=600 for x in rr)
assert len(list(csv.DictReader((D/'R07_40例统计.csv').open(encoding='utf-8-sig'))))==40
assert len(list(csv.DictReader((D/'R07_1200次明细.csv').open(encoding='utf-8-sig'))))==1200
ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def cells(xml):return {c.attrib['r']:c for c in xml.findall('.//m:sheetData/m:row/m:c',ns)}
def number(c):v=c.find('m:v',ns);assert v is not None and c.attrib.get('t','n')=='n';return float(v.text)
xlsx=D/'R07_全40算例_30次_结果汇总.xlsx'
with zipfile.ZipFile(xlsx) as z:
 assert z.testzip() is None
 wb=ET.fromstring(z.read('xl/workbook.xml'));assert [s.attrib['name'] for s in wb.find('m:sheets',ns)]==['40例汇总','1200次明细']
 ss=ET.fromstring(z.read('xl/worksheets/sheet1.xml'));dd=ET.fromstring(z.read('xl/worksheets/sheet2.xml'));c=cells(ss);d=cells(dd)
 for sh in [ss,dd]:
  pane=sh.find('.//m:pane',ns);assert pane is not None and float(pane.attrib.get('xSplit',0))==2 and float(pane.attrib.get('ySplit',0))==7
 max_delta=0.
 for i,q in enumerate(g,8):
  wants=[30,q['best'],q['avg'],q['sample_std'],q['whole_mean_seconds'],q['whole_min_seconds'],q['whole_max_seconds'],q['whole_std_seconds']]
  for col,want in zip('DEFGHIJK',wants):
   a=c[f'{col}{i}'];assert a.find('m:f',ns) is not None;delta=abs(number(a)-want);assert delta<1e-8,(i,col,number(a),want);max_delta=max(max_delta,delta)
 for i,q in enumerate(rows,8):
  for col,want in [('A',q['case_index']),('C',q['capacity']),('D',q['rep']),('E',q['seed']),('F',q['cost']),('G',q['whole_seconds']),('H',q['LSS']),('I',1)]:assert math.isclose(number(d[f'{col}{i}']),want,rel_tol=0,abs_tol=1e-10),(i,col)
 assert not any(c.attrib.get('t')=='e' for sh in [ss,dd] for c in sh.findall('.//m:c',ns))
md=(D/'R07_全40算例1200次_最终测试总结.md').read_text(encoding='utf-8')
for q in g:
 expected=f'|{q["case_index"]}|{q["instance_label"]}|{q["capacity"]:g}|30/30|{q["best"]:.9f}|{q["avg"]:.9f}|{q["sample_std"]:.9f}|{q["whole_mean_seconds"]:.3f}|{q["whole_min_seconds"]:.3f}|{q["whole_max_seconds"]:.3f}|';assert expected in md,q['case_index']
assert '494.421594' in md and '样本标准差' in md and '同批' in md
with zipfile.ZipFile(D/'R07_冻结源码与验证.zip') as z:
 for n,h in P['source_and_binary_pins'].items():
  if n.startswith('../source/'):assert hashlib.sha256(z.read(n[3:])).hexdigest()==h,n
parts=read(D/'证据分片清单.json');total=hashlib.sha256();size=0
for q in parts['parts']:
 b=(D/q['name']).read_bytes();assert len(b)==q['bytes'] and hashlib.sha256(b).hexdigest()==q['sha256'];total.update(b);size+=len(b)
assert total.hexdigest()==parts['archive_sha256'] and size==parts['archive_bytes'] and parts['full40_registered_runs']==1200
qa={'status':'PASS','stage':'FORMAL_COMPLETE','all_files_sha_verified':True,'terminal':1200,'independent_valid':1200,'per_case_valid_repetitions':30,'cases':40,'source_zip_matches_frozen_pins':True,'xlsx_author':'@oai/artifact-tool','xlsx_saved_raw_numeric_values_checked':9600,'xlsx_summary_formula_cached_results_checked':320,'xlsx_max_absolute_difference':max_delta,'all40_MD_table_rows_recomputed':True,'sample_std_ddof':1,'visual_review_both_sheets_passed':True,'evidence_archive_sha256':total.hexdigest(),'evidence_parts':len(parts['parts'])}
(D/'DELIVERY_QA.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
checks={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in D.iterdir() if p.is_file() and p.name!='CHECKSUMS_SHA256.json'}
assert all(q['bytes']<95*2**20 for q in checks.values())
(D/'CHECKSUMS_SHA256.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
(R/'DELIVERY_LOCAL_VERIFIED.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
print(json.dumps(qa))
