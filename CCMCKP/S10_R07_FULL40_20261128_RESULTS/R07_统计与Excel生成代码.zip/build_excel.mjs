import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {Workbook, SpreadsheetFile} from '@oai/artifact-tool';
const R=path.dirname(fileURLToPath(import.meta.url)),D=path.join(R,'delivery');
const data=JSON.parse(await fs.readFile(path.join(R,'statistics.json'),'utf8'));
const wb=Workbook.create(),s=wb.worksheets.add('40例汇总'),d=wb.worksheets.add('1200次明细');
const navy='#17365D',light='#F1F5F9',ink='#1F2937',muted='#536171';
for(const [sh,lastcol,lastrow] of [[s,'K',47],[d,'I',1207]]){
 sh.showGridLines=false;sh.getRange(`A1:${lastcol}${lastrow}`).format.font={name:'Arial',size:10,color:ink};
 sh.getRange(`A1:${lastcol}${lastrow}`).format.verticalAlignment='center';
 sh.getRange(`A1:${lastcol}${lastrow}`).format.rowHeight=20;
 sh.getRange('A1').format.rowHeight=9;sh.getRange('A2').format.rowHeight=28;
 sh.getRange('A2').format.font={name:'Arial',size:14,bold:true,color:navy};
 sh.getRange(`${lastcol}6:A6`.split(':').reverse().join(':')).format.borders={bottom:{style:'thin',color:'#CBD5E1'}};
 sh.freezePanes.freezeRows(7);sh.freezePanes.freezeColumns(2);
 sh.getRange(`A7:${lastcol}7`).format={fill:navy,font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},horizontalAlignment:'center',verticalAlignment:'center',wrapText:true,rowHeight:36};
 sh.getRange(`A7:${lastcol}7`).format.borders={insideVertical:{style:'thin',color:'#FFFFFF'}};
}
s.tabColor=navy;
s.getRange('A2').values=[['R07全40例测试结果']];
s.getRange('A3').values=[['有效运行']];s.getRange('B3').formulas=[["=SUM('1200次明细'!I8:I1207)"]];
s.getRange('D3').values=[['算例数']];s.getRange('E3').formulas=[['=COUNTA(A8:A47)']];
s.getRange('G3').values=[['最长完整秒']];s.getRange('H3').formulas=[["=MAX('1200次明细'!G8:G1207)"]];
s.getRange('J3').values=[['超过600秒']];s.getRange('K3').formulas=[["=COUNTIFS('1200次明细'!G8:G1207,\">600\")"]];
s.getRange('A4').values=[['Std为样本标准差(ddof=1)。完整时间含加载、求解、原LSS、保存、fsync及退出。']];
s.getRange('A5').values=[['每例30次。完整进程时间不包含排队或独立审计，单位为秒。']];
s.getRange('A4:K5').format.font={name:'Arial',size:10,italic:true,color:muted};
s.getRange('A7:K7').values=[['编号','算例','阈值T','有效次数','Best','Avg','Std\n(ddof=1)','完整均时\n(s)','最短完整\n(s)','最长完整\n(s)','耗时Std\n(s)']];
d.getRange('A2').values=[['R07逐次测试结果']];
d.getRange('A3').values=[['每行一次独立运行，成本取最终LSS验收输出。独立有效1=是。']];
d.getRange('A4').values=[['来源：同目录full40_FINAL_INDEPENDENT_AUDIT.json。协议及完整SHA256见MD总结。']];
d.getRange('A5').values=[['原始记录按算例编号、重复顺序保存。未混入先前30次试点，未补跑失败。']];
d.getRange('A3:I5').format.font={name:'Arial',size:10,italic:true,color:muted};
d.getRange('A7:I7').values=[['编号','算例','阈值T','重复','seed','最终成本','完整运行\n时间(s)','最终LSS','独立有效\n(1=是)']];
d.getRange('A8:I1207').values=data.rows.map(x=>[x.case_index,x.instance_label,x.capacity,x.rep,x.seed,x.cost,x.whole_seconds,x.LSS,x.independent_valid]);
s.getRange('A8:C47').values=data.groups.map(x=>[x.case_index,x.instance_label,x.capacity]);
const formulas=data.groups.map((g,i)=>{
 const row=i+8,lo=8+i*30,hi=lo+29,cr=`'1200次明细'!$F$${lo}:$F$${hi}`,tr=`'1200次明细'!$G$${lo}:$G$${hi}`;
 return [`=COUNTIFS('1200次明细'!$A$8:$A$1207,A${row},'1200次明细'!$I$8:$I$1207,1)`,
  `=IF(D${row}=30,MIN(${cr}),"n.a.")`,`=IF(D${row}=30,AVERAGE(${cr}),"n.a.")`,`=IF(D${row}=30,STDEV(${cr}),"n.a.")`,
  `=AVERAGE(${tr})`,`=MIN(${tr})`,`=MAX(${tr})`,`=STDEV(${tr})`];
});s.getRange('D8:K47').formulas=formulas;
for(let i=0;i<40;i++){
 if(i%2===1)s.getRange(`A${8+i}:K${8+i}`).format.fill=light;
 if(i%2===1)d.getRange(`A${8+i*30}:I${37+i*30}`).format.fill=light;
 if(i>0)d.getRange(`A${8+i*30}:I${8+i*30}`).format.borders={top:{style:'thin',color:'#CBD5E1'}};
}
s.getRange('A28:K28').format.borders={top:{style:'medium',color:navy}};
s.getRange('A8:K47').format.horizontalAlignment='right';s.getRange('B8:B47').format.horizontalAlignment='left';
d.getRange('A8:I1207').format.horizontalAlignment='right';d.getRange('B8:B1207').format.horizontalAlignment='left';
s.getRange('A8:A47').format.horizontalAlignment='center';d.getRange('A8:A1207').format.horizontalAlignment='center';
s.getRange('A8:D47').setNumberFormat('0');s.getRange('E8:G47').setNumberFormat('0.000000');s.getRange('H8:K47').setNumberFormat('0.000');
s.getRange('B3').setNumberFormat('0');s.getRange('E3').setNumberFormat('0');s.getRange('H3').setNumberFormat('0.000');s.getRange('K3').setNumberFormat('0');
d.getRange('A8:E1207').setNumberFormat('0');d.getRange('F8:F1207').setNumberFormat('0.000000');d.getRange('G8:G1207').setNumberFormat('0.000');d.getRange('H8:H1207').setNumberFormat('0.000000');d.getRange('I8:I1207').setNumberFormat('0');
s.getRange('A:A').format.columnWidth=7;s.getRange('B:B').format.columnWidth=25;s.getRange('C:D').format.columnWidth=10;s.getRange('E:G').format.columnWidth=17;s.getRange('H:K').format.columnWidth=17;
d.getRange('A:A').format.columnWidth=7;d.getRange('B:B').format.columnWidth=25;d.getRange('C:D').format.columnWidth=10;d.getRange('E:E').format.columnWidth=14;d.getRange('F:H').format.columnWidth=18;d.getRange('I:I').format.columnWidth=14;
s.getRange('D8:D47').conditionalFormats.add('cellIs',{operator:'lessThan',formula:30,format:{fill:'#FEE2E2',font:{color:'#991B1B',bold:true}}});
wb.recalculate();
const actual=s.getRange('D8:K47').values;let maxDifference=0;
for(let i=0;i<40;i++){
 const g=data.groups[i],expected=[30,g.best,g.avg,g.sample_std,g.whole_mean_seconds,g.whole_min_seconds,g.whole_max_seconds,g.whole_std_seconds];
 for(let j=0;j<8;j++){const x=actual[i][j],want=expected[j];if(typeof x!=='number'||!Number.isFinite(x)||Math.abs(x-want)>1e-8)throw new Error(`summary mismatch ${i+1}/${j}: ${x} versus ${want}`);maxDifference=Math.max(maxDifference,Math.abs(x-want));}
}
const inspection=await wb.inspect({kind:'table',range:"'40例汇总'!A7:K12",include:'values,formulas',tableMaxRows:6,tableMaxCols:11,maxChars:5000});
await fs.writeFile(path.join(R,'WORKBOOK_INSPECT.ndjson'),inspection.ndjson);
const errors=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:20},summary:'final formula error scan',maxChars:2000});
await fs.writeFile(path.join(R,'WORKBOOK_ERROR_SCAN.ndjson'),errors.ndjson);
for(const [name,range,out] of [['40例汇总','A1:K16','summary_preview.png'],['1200次明细','A1:I17','detail_preview.png'],['40例汇总','A37:K47','large_cases_preview.png']]){
 const preview=await wb.render({sheetName:name,range,scale:1.5,format:'png'});await fs.writeFile(path.join(R,out),new Uint8Array(await preview.arrayBuffer()));
}
const xlsx=await SpreadsheetFile.exportXlsx(wb);await xlsx.save(path.join(D,'R07_全40算例_30次_结果汇总.xlsx'));
await fs.writeFile(path.join(R,'WORKBOOK_QA.json'),JSON.stringify({status:'PASS',sheets:2,raw_rows:1200,summary_cases:40,max_formula_difference_vs_independent_statistics:maxDifference,summary_formula_cells_checked:320,recalculated:true,previews:['summary_preview.png','detail_preview.png'],creator:'@oai/artifact-tool'},null,2));
console.log(JSON.stringify({status:'PASS',xlsx:'R07_全40算例_30次_结果汇总.xlsx',max_formula_difference:maxDifference,error_scan:errors.ndjson}));
