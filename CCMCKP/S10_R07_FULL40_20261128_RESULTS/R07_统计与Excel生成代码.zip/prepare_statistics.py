from pathlib import Path
from datetime import datetime,timezone,timedelta
import json,statistics,hashlib,csv,collections,math
R=Path(__file__).resolve().parent;O=R.parent;E=O/'evidence';F=E/'full40';D=R/'delivery';D.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
A=read(F/'FINAL_INDEPENDENT_AUDIT.json');P=read(F/'PROTOCOL.json')
assert A['terminal']==A['independent_valid']==1200 and A['global_errors']==[]
assert P['total_runs']==1200 and len(P['cases'])==40 and len(P['arms'])==1 and P['repetitions']==30 and P['max_workers']==60
assert sha(F/'FINAL_INDEPENDENT_AUDIT.json')=='8161d76e05bd58064dbacfde7c27e9bd286e6a810835d09f9ef31c19f3bdc6da'
rows=[];groups=[]
for c in P['cases']:
 rr=sorted((x for x in A['rows'] if x['case_index']==c['index']),key=lambda x:x['rep']);assert len(rr)==30 and {x['rep'] for x in rr}==set(range(1,31))
 for x in rr:
  assert x['valid'] and x['rc']==0 and x['LSS']>=.99 and 0<x['process_wall_seconds']<=600 and x['seed']==P['seed_base']+x['rep']
  m=x['R07_funnel'];rows.append({'case_index':c['index'],'instance':c['instance'],'instance_label':c['instance'].rstrip('_'),'capacity':c['tmax'],'rep':x['rep'],'seed':x['seed'],'cost':x['cost'],'whole_seconds':x['process_wall_seconds'],'LSS':x['LSS'],'independent_valid':1,'identity':x['identity'],'selected':x['selection'],'internal_best_cost':x['raw_final_cost'],'mother_best_cost':m.get('mother_only_best_cost'),'first_output_candidate_found_seconds':x['first_found_seconds'],'LSS_seconds':x['LSS_seconds'],'raw_best_last_LSS':x['raw_best_last_LSS'],'final_above_raw_best':x['final_cost_above_raw_best'],'cost_gap_above_raw_best':x['final_cost_minus_raw_best'],'watchdog_timeouts':m['watchdog_timeouts'],'local_mckp_rounds':m.get('local_mckp_rounds',len(m.get('local_rounds',[]))),'epsilon_fft':m['epsilon_fft_final'],'timing':x['R07_timing']['timing']})
 vv=[x['cost'] for x in rr];tt=[x['process_wall_seconds'] for x in rr];best=min(vv)
 g={'case_index':c['index'],'instance':c['instance'],'instance_label':c['instance'].rstrip('_'),'capacity':c['tmax'],'n':30,'best':best,'avg':statistics.mean(vv),'sample_std':statistics.stdev(vv),'whole_mean_seconds':statistics.mean(tt),'whole_min_seconds':min(tt),'whole_max_seconds':max(tt),'whole_std_seconds':statistics.stdev(tt),'whole_median_seconds':statistics.median(tt),'whole_sum_seconds':sum(tt),'best_hit_count':sum(v==best for v in vv),'cost_unique_count':len(set(vv)),'final_above_raw_best_runs':sum(x['final_cost_above_raw_best'] for x in rr),'raw_best_final_LSS_below_threshold_runs':sum(x['raw_best_last_LSS'] is not None and x['raw_best_last_LSS']<.99 for x in rr),'mean_cost_gap_above_raw_best':statistics.mean(x['final_cost_minus_raw_best'] for x in rr),'watchdog_timeouts':sum(x['R07_funnel']['watchdog_timeouts'] for x in rr),'mean_local_mckp_rounds':statistics.mean(x['R07_funnel'].get('local_mckp_rounds',len(x['R07_funnel'].get('local_rounds',[]))) for x in rr)}
 q=next(q for q in A['groups'] if q['case_index']==c['index']);assert q['valid']==30 and g['best']==q['best_diagnostic'] and g['avg']==q['official_avg'] and math.isclose(g['sample_std'],q['official_std'],rel_tol=0,abs_tol=1e-12) and g['whole_mean_seconds']==q['whole_mean']
 groups.append(g)
assert len(rows)==1200 and len(groups)==40 and len({x['identity'] for x in rows})==1200
metrics={'terminal':1200,'independent_valid':1200,'global_errors':[],'cases':40,'repetitions':30,'max_concurrency':60,'min_LSS':min(x['LSS'] for x in rows),'max_whole_seconds':max(x['whole_seconds'] for x in rows),'mean_whole_seconds':statistics.mean(x['whole_seconds'] for x in rows),'sum_worker_whole_seconds':sum(x['whole_seconds'] for x in rows),'constant_cost_cases':sum(g['sample_std']==0 for g in groups),'varying_cost_cases':[g['case_index'] for g in groups if g['sample_std']!=0],'final_above_raw_best_runs':sum(g['final_above_raw_best_runs'] for g in groups),'watchdog_timeouts':sum(g['watchdog_timeouts'] for g in groups),'std_ddof':1,'protocol_sha256':sha(F/'PROTOCOL.json'),'audit_sha256':sha(F/'FINAL_INDEPENDENT_AUDIT.json'),'binary_sha256':P['source_and_binary_pins']['../bin/ccmckp_s10'],'previous_smoke30_excluded':True,'one_arm_no_fresh_controls':True}
summary={'metrics':metrics,'groups':groups,'rows':rows,'protocol':P}
(R/'statistics.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
(D/'R07_全40例统计与1200次明细.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
for name,data in [('R07_40例统计.csv',groups),('R07_1200次明细.csv',[{k:v for k,v in x.items() if k!='timing'} for x in rows])]:
 with (D/name).open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
print(json.dumps(metrics,ensure_ascii=False))
