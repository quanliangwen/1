from pathlib import Path
from datetime import datetime,timezone,timedelta
import json,csv,hashlib,statistics
R=Path(__file__).resolve().parent;O=R.parent;E=O/'evidence';F=E/'full40';D=R/'delivery'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
S=read(R/'statistics.json');M=S['metrics'];groups=S['groups'];rows=S['rows'];P=S['protocol'];A=read(F/'FINAL_INDEPENDENT_AUDIT.json');C=read(F/'COMPLETED.json');L=read(F/'LAUNCH.json');V=read(F/'FINAL_AUDIT_PROCESS.json');pilot=read(F/'PILOT_CONTINUATION_DECISION.json')
assert C['terminal']==C['rc0']==1200 and C['pending']==0 and C['resource_events']==0 and V['rc']==0 and pilot['pass'] and pilot['independent_valid']==200
receipt=read(O/'COLLECTION_RECEIPT.json')
for n,q in receipt.items():
 if not n.startswith('full40/'):continue
 f=E/n;assert f.stat().st_size==q['bytes'] and sha(f)==q['sha256'],n
assert all(sha(O/'source'/n[10:])==v for n,v in P['source_and_binary_pins'].items() if n.startswith('../source/'))
def bj(t):return datetime.fromisoformat(t).astimezone(timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M:%S')
audit_seconds=(datetime.fromisoformat(V['utc'])-datetime.fromisoformat(C['utc'])).total_seconds()
old_path=Path('E:/codex/S10_R06_quality_first_20261127/delivery/R06_全40例120组统计.csv')
historical=[x for x in csv.DictReader(old_path.open(encoding='utf-8-sig')) if x['arm']=='D_R06_QUALITY_DUAL']
old={int(x['case_index']):x for x in historical};by={g['case_index']:g for g in groups}
history=[]
for k in [11,18,38,19,35,39]:
 h=old[k];g=by[k];history.append({'case_index':k,'R07_avg30':g['avg'],'R07_sample_std30':g['sample_std'],'R07_mean_whole_seconds':g['whole_mean_seconds'],'R06_historical_LSS_diagnostic_avg30':float(h['LSS30_diagnostic_avg']),'R06_historical_LSS_diagnostic_std30':float(h['LSS30_diagnostic_std']),'R06_historical_whole_mean_seconds':float(h['whole_mean_seconds']),'R06_original_protocol_valid':int(h['valid']),'not_a_fresh_paired_comparison':True})
(D/'R07_六个重点算例_历史描述对照.json').write_text(json.dumps(history,ensure_ascii=False,indent=2),encoding='utf-8')
lines=['# R07全40个算例1200次测试总结','',
 '**40个算例各30次，共1200次测试已全部自然结束，1200/1200独立有效，全部通过原LSS验收，所有完整进程耗时均低于600秒。**','',
 f'最长完整运行时间为 **{M["max_whole_seconds"]:.6f}秒**。实际最高并发60，无资源保护终止，无覆盖缺失，终末审计`global_errors=[]`。本次只测试冻结R07，没有重跑B01或D02，前期30次试点未计入这1200次。','',
 '## 1. 交付文件','',
 '- [Excel结果汇总](R07_全40算例_30次_结果汇总.xlsx)：40例汇总与1200次明细两张表，汇总公式关联明细数据。',
 '- [40例统计CSV](R07_40例统计.csv)及[1200次明细CSV](R07_1200次明细.csv)：保留未四舍五入的数值。',
 '- [完整统计JSON](R07_全40例统计与1200次明细.json)：统计、选择向量、内部里程碑及耗时拆账。',
 '- 原始终末审计、冻结协议、来源校验、代码及分片证据随同发布。证据按48MiB分片，使用`merge_evidence.py`合并并校验SHA256。','',
 '## 2. 测试范围与运行口径','',
 '范围为冻结协议中的40组“实例+容量阈值”，每组30次。seed为1071001至1071030，按重复编号登记；每个run从自身原始数据生成起点，不读取历史解、跨重复输出或外部MIP start。R07源码和二进制与前期试点相同，没有根据全量成绩再调参或补跑挑选。',
 '此前6例各5次试点的性能扩展门槛未全部通过。本轮依据用户随后明确要求“R07全部算例离线运行、60并行”单独登记，保留原试点失败结论，不将其改写为通过。前200次属于正式1200次，技术完整性审计200/200通过后自动运行剩余1000次。','',
 '|阶段|北京时间（UTC+8）|','|---|---|',f'|启动控制器|{bj(L["utc"])}|',f'|前200次技术审计通过|{bj(pilot["utc"])}|',f'|全部1200次求解结束|{bj(C["utc"])}|',f'|终末独立审计结束|{bj(V["utc"])}|','',
 f'控制器批次历时{C["elapsed_seconds"]:.3f}秒，包含中途技术审计暂停，不能当作单次算法时间。1200个进程时间累计为{M["sum_worker_whole_seconds"]:.3f}秒（{M["sum_worker_whole_seconds"]/3600:.3f}进程小时），并行运行，因此该累计值也不是批次墙钟时间。终末只读审计另用{audit_seconds:.3f}秒，不新增优化运行或MC，不向生成器反馈。','',
 '最终验收保持原LSS≥0.99，使用原quick/MC/exact分支、严格事件`sum<T`与原样本索引`0..L−1`。未增加真实概率终审。搜索期整数CDF只用于原认证入池，私人FFT只用于提议、门控及排序，未写入公共概率缓存。','',
 '## 3. 统计定义','',
 '成本为最终通过原LSS终审的输出成本，目标是最小化。设同一算例的30次成本为C₁…C₃₀：',
 '- Best = min(C₁…C₃₀)，表示本批观察到的最低有效成本。',
 '- Avg = ΣCᵣ/30。',
 '- Std = sqrt[Σ(Cᵣ−Avg)²/29]，采用样本标准差，ddof=1。',
 '- 完整时间 = 进程启动前的单调时钟时间戳至独立等待线程观察到进程退出，包含启动、加载、模型/预计算、全部求解与认证、原LSS、保存、fsync及退出。',
 '- 完整均时是该算例30次完整进程时间的均值。Excel另列时间标准差、最短与最长完整耗时；这些都不是“最好解首次达到时间”。','',
 '每组均有30次独立有效记录，因此40组Avg/Std均可给出。统计使用原始未舍入数值，表中仅作显示舍入。CSV和JSON保留完整数值。没有给失败运行填充虚假成本，没有剪裁或删除负观测。','',
 '## 4. 全40例结果','',
 '|编号|算例|T|有效|Best|Avg|Std(ddof=1)|完整均时(s)|最短(s)|最长(s)|',
 '|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|']
for g in groups:lines.append(f'|{g["case_index"]}|{g["instance_label"]}|{g["capacity"]:g}|30/30|{g["best"]:.9f}|{g["avg"]:.9f}|{g["sample_std"]:.9f}|{g["whole_mean_seconds"]:.3f}|{g["whole_min_seconds"]:.3f}|{g["whole_max_seconds"]:.3f}|')
lines+=['','## 5. 稳定性与最终LSS回退','',
 f'- {M["constant_cost_cases"]}个算例的30次输出成本相同，样本Std=0。它只说明本批结果一致，不能据此证明全局最优或普遍鲁棒性。',
 '- 成本有波动的8个算例编号为：'+ '、'.join(map(str,M['varying_cost_cases']))+'。',
 f'- {M["final_above_raw_best_runs"]}次最终输出成本高于该run内部CDF认证的最低成本。这些运行仍通过统一原LSS验收；不能把内部最好成本代替最终成绩。',
 f'- 搜索内部共有{M["watchdog_timeouts"]}次单次认证超时，记为unknown并保留，没有伪造概率或重新抽seed。该数字是内部调用数，不是失败run数；本批1200个最终输出均独立有效。','',
 '|编号|Best命中次数/30|最终高于内部最好次数|Avg−Best|','|---:|---:|---:|---:|']
for g in groups:
 if g['sample_std']!=0:lines.append(f'|{g["case_index"]}|{g["best_hit_count"]}/30|{g["final_above_raw_best_runs"]}|{g["avg"]-g["best"]:.9f}|')
lines+=['','## 6. 六个重点算例的进展与限制','',
 '下面仅并列本次R07与此前R06历史汇总，**不是同批、同seed的配对对照，不提供显著性结论**。R06历史数据源为[此前全40例报告](https://github.com/quanliangwen/1/blob/d94095b2e98435fce9610cb48fe526e3fba766f9/CCMCKP/S10_R06_quality_first_20261127_RESULTS/CCMCKP_R06_质量优先运行测试总结.md)。R06编号18有8条内部阶段越界，原协议有效22/30，其历史列仅为全部30次原LSS通过的诊断统计。','',
 '|编号|R07 Avg30|R06历史LSS诊断Avg30|R07 Std30|R06历史Std30|R07完整均时(s)|R06历史均时(s)|',
 '|---:|---:|---:|---:|---:|---:|---:|']
for h in history:lines.append(f'|{h["case_index"]}|{h["R07_avg30"]:.9f}|{h["R06_historical_LSS_diagnostic_avg30"]:.9f}|{h["R07_sample_std30"]:.9f}|{h["R06_historical_LSS_diagnostic_std30"]:.9f}|{h["R07_mean_whole_seconds"]:.3f}|{h["R06_historical_whole_mean_seconds"]:.3f}|')
lines+=['',
 f'**编号11**：Avg30={by[11]["avg"]:.9f}，低于R06历史49.123167569，但仍高于原试点预设目标48.28。Std30={by[11]["sample_std"]:.9f}。内部低成本解与最终LSS回退之间仍有差距，不能将“已补充若干回退”直接等同于低成本覆盖充分。',
 f'**编号18**：本批30/30原协议独立有效，Avg30={by[18]["avg"]:.9f}、Std30=0，完整均时{by[18]["whole_mean_seconds"]:.3f}秒。只可描述其较R06历史诊断均值更低、历史耗时更短；未重现R06历史Best 142.271213921，不能声称所有质量指标都改善。',
 f'**编号38**：Best={by[38]["best"]:.9f}，Avg30={by[38]["avg"]:.9f}，低于R06历史196.949989822。与此同时Std从历史0变为{by[38]["sample_std"]:.9f}，完整均时由历史107.765秒增至{by[38]["whole_mean_seconds"]:.3f}秒。成本、波动与速度不能合并宣称全面提升。',
 f'**编号39**：本批Best={by[39]["best"]:.9f}，不同于先前5次试点的最终Best 322.531417005；正式30次并未沿用那5次。Avg30={by[39]["avg"]:.9f}，仍高于R06历史322.215894324，完整均时{by[39]["whole_mean_seconds"]:.3f}秒。全量结果支持“部分成本目标有进展，但Avg和速度尚未全面改善”。','',
 '编号19保持历史相同成本，编号35均值略低，但这些仍是跨批描述。此次没有新鲜B01/D02/R06对照，没有将历史ILS的Time（分析）当作完整进程时间，因此不作配对检验或跨算法速度排名。','',
 '## 7. 实现与审计边界','',
 'R07是ES95预算RO和无量纲熵代理引导、结合内部CDF认证与局部MIP精炼的经验机会约束混合框架。它不是同一不确定集合下的新DRO全局保证，也未证明总体概率覆盖。小样本L30的尾部窗口为3个原子（10%），不能将其说成精确5%尾部。',
 '原28个继承组件及native_check/shortlist/final_check函数体保持原字节。原native_check在本run隔离子进程执行，按已完成耗时中位数设15–35秒看门狗；超时为unknown，完整证书才导入父池。子进程量化缓存未回传父进程，可能增加转换与fork开销，本批没有单独消融其净开销。',
 'R07保留final_check原函数体，但不在主进程做不带单次看门狗的额外重复重计数。每个入池解在预算内已获得原native_check证书，终末只读读者重建已返回的整数证书，并复核模型、私人FFT、在线状态、成本准入、身份/来源、原LSS轨迹和完整时钟。审计不是新增求解，也不改变最终LSS标准。',
 '有限2秒MIP、有限解池与线性化风险行不保证枚举全部邻域，未找到池候选不证明邻域不可行；私人FFT容差也不是统一概率误差界。所有普通负观测、超时unknown和未完成阶段均按原记录保留。','',
 '## 8. 数据与复核信息','',
 f'- 覆盖：40例×30，1200个唯一身份，seed按登记推进。',
 f'- 前200次技术审计：200/200有效；终末审计：1200/1200有效，global_errors=[]。',
 '- 原协议101项源/二进制等固定项、7280项input pins在运行与终末审计中保持一致。',
 f'- 二进制SHA256：`{M["binary_sha256"]}`。',f'- 全量协议SHA256：`{M["protocol_sha256"]}`。',f'- 终末审计SHA256：`{M["audit_sha256"]}`。',
 '- Excel的320个汇总结果单元格与独立Python统计交叉核对。不同Python版本仅编号38的样本Std有1.39e−17的末位差异，不影响显示或结论；原审计未改写。',
 '- 完整原始基准数据与商业Gurobi SDK/许可证不随交付分发；源文件SHA、冻结源码、求解输出及紧凑证据用于复核。']
out=[]
for line in lines:
 if line and out and out[-1] and not line.startswith(('#','|','- ')) and not out[-1].startswith(('#','|')):out.append('')
 out.append(line)
(D/'R07_全40算例1200次_最终测试总结.md').write_text('\n'.join(out)+'\n',encoding='utf-8')
for n in ['PROTOCOL.json','FROZEN.json','LAUNCH.json','COMPLETED.json','FINAL_AUDIT_PROCESS.json','PILOT_CONTINUATION_DECISION.json','FINAL_INDEPENDENT_AUDIT.json']:(D/('full40_'+n)).write_bytes((F/n).read_bytes())
for n in ['USER_FULL40_DIRECTIVE.json','FROZEN_PARAMETERS.json','VALIDATION.json']:(D/n).write_bytes((E/n).read_bytes())
(D/'R07_冻结源码与验证.zip').write_bytes((O/'delivery/R07_冻结源码与验证.zip').read_bytes())
print(json.dumps({'MD':'R07_全40算例1200次_最终测试总结.md','all40_stats_reconciled':True,'worker_end_Beijing':bj(C['utc']),'audit_end_Beijing':bj(V['utc'])},ensure_ascii=False))
