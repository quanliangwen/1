"""Bounded own-state reporting; forwards all original decisions/actions."""
import json,hashlib
import numpy as np

class FreshOpportunityAuditMixin:
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self._fresh_opportunity_stats=dict(commitment_calls=0,expired_calls=0,refreshed=0,invalid_after=0)
    def _fresh_emit(self,kind,**data):
        print('[FRESH_OPPORTUNITY] '+json.dumps(dict(kind=kind,owner=int(self.identifier or 0),step=int(self.elapsed_timestep),wall=float(self.elapsed_walltime),**data)),flush=True)
    def _should_defer_commitment(self,loss,remaining,execution,probe,completion_value,step):
        before=int(self._coverage_model_step)
        result=super()._should_defer_commitment(loss,remaining,execution,probe,completion_value,step)
        after=int(self._coverage_model_step);stats=self._fresh_opportunity_stats
        stats['commitment_calls']+=1
        expired=not 0<=step-before<120
        if expired:stats['expired_calls']+=1
        if expired and after==step:stats['refreshed']+=1
        if not 0<=step-after<120:stats['invalid_after']+=1
        if expired and stats['expired_calls']<=24:
            model=getattr(self,'coverage_model',{})or{}
            self._fresh_emit('ACTUAL_LOCAL_MODEL_REFRESH',stamp_before=before,stamp_after=after,age_before=int(step-before),age_after=int(step-after),
                inventory=int(self.carried_bombs_count()),defer=bool(result),loss=float(loss),remaining=float(remaining),execution=float(execution),probe=float(probe),
                model_map_gap=float(model.get('map_gap',0)),model_layout_gap=float(model.get('layout_gap',0)),stats=dict(stats))
        return result
    def _submission_due(self,step):
        result=super()._submission_due(step)
        if result:self._fresh_emit('ACTUAL_SUBMISSION_DUE',remaining=float(self._remaining_steps()),inventory=int(self.carried_bombs_count()),stats=dict(self._fresh_opportunity_stats))
        return result
    def submit_exploration_map(self,image):
        a=np.asarray(image)
        self._fresh_emit('SUBMIT_IMAGE',sha256=hashlib.sha256(a.tobytes()).hexdigest(),shape=list(a.shape),dtype=str(a.dtype),inventory=int(self.carried_bombs_count()),stats=dict(self._fresh_opportunity_stats))
        return super().submit_exploration_map(image)
