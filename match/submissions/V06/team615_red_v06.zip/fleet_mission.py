"""Reviewed FleetCoverageMixin: acknowledged goal leases and exact endpoints.

Drop-in replacement for candidate/fleet_mission.py. Uses message-only state.
Keep the coordinator's pending first targets reserved until their owner reports
an inventory change, releases them, or their lease expires. Plan helper never
reassigns the same reserved disk to another agent during that interval.
"""
import cv2
import numpy as np
from swarm_rescue.solutions.greedy_mapping import GreedyMappingDrone
from swarm_rescue.solutions.team_coverage_lns import plan_team_coverage_lns


class FleetCoverageMixin:
    PLAN_START_RATIO = .30
    RETURN_RATIO = .45
    SUBMIT_RATIO = .52
    HARD_SUBMIT_RATIO = .78
    STATE_FRESH_STEPS = 120
    PLAN_FRESH_STEPS = 240
    GOAL_LEASE_STEPS = 600
    placement_arrival_radius = 12.0
    EARLY_DROP_LIMIT = 1
    RESERVE_RELEASE_RATIO = 0.46
    DEADLINE_RELEASE_WALLTIME_FRACTION = 0.60

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.fleet_states = {}
        self.fleet_plan = None
        self.last_fleet_plan_step = -1000
        self.plan_drop_count = -1
        self.assignment_goal = None
        self.assignment_since = -1000
        self.assignment_inventory = None
        self.assignment_reports = {}
        self.assignment_rejections = {}
        self.fleet_signature = None
        self.map_quality_records = {}
        self._progress_goal = None
        self._progress_inventory = None
        self._progress_best_distance = 1e30
        self._progress_since_step = -1000

    def _map_quality(self):
        step=int(self.elapsed_timestep)
        if step-getattr(self,'_quality_step',-100)<20:
            return self._quality_cache
        occupied = cv2.resize((self.memory.hits >= 3).astype(np.float32),
                              (self.memory.shape[1], self.memory.shape[0]), interpolation=cv2.INTER_AREA) > .03
        known = self.memory.free | cv2.dilate(occupied.astype(np.uint8),np.ones((3,3),np.uint8)).astype(bool)
        self._quality_step=step
        self._quality_cache=(float(known.mean()),int(np.count_nonzero(occupied)))
        return self._quality_cache

    def _own_assignment_report(self, step):
        goal = None if self.assignment_goal is None else self.assignment_goal.copy()
        return (int(step), int(self.carried_bombs_count()), goal, int(self.assignment_since))

    def define_message_for_all(self):
        message = super().define_message_for_all()
        own, step = int(self.identifier or 0), int(self.elapsed_timestep)
        states = dict(self.fleet_states)
        states[own] = (step,None if self.pose is None else self.pose.copy(),int(self.carried_bombs_count()))
        reports = dict(self.assignment_reports)
        reports[own] = self._own_assignment_report(step)
        message['fleet_states'] = states
        message['assignment_reports'] = reports
        message['assignment_rejections'] = dict(self.assignment_rejections)
        message['fleet_plan'] = self.fleet_plan
        message['map_quality'] = (step,*self._map_quality())
        return message

    def _messages(self):
        super()._messages()
        step, own = int(self.elapsed_timestep), int(self.identifier or 0)
        self.fleet_states[own] = (step,None if self.pose is None else self.pose.copy(),int(self.carried_bombs_count()))
        self.assignment_reports[own] = self._own_assignment_report(step)
        self.map_quality_records[own] = (step,*self._map_quality())
        proposals = []
        for _, message in self.communicator.received_messages:
            if not isinstance(message,dict) or message.get('kind') != 'greedy-map-v1':
                continue
            for peer,record in message.get('fleet_states',{}).items():
                peer=int(peer)
                if peer==own or len(record)!=3:
                    continue
                ts,position,inventory=record
                valid = position is None or (np.asarray(position).shape==(2,) and np.isfinite(position).all())
                if (valid and 0<=int(ts)<=step and int(inventory)>=0 and
                        int(ts)>self.fleet_states.get(peer,(-1,))[0]):
                    self.fleet_states[peer]=(int(ts),position,int(inventory))
            for peer,report in message.get('assignment_reports',{}).items():
                peer=int(peer)
                if peer==own or len(report)!=4:
                    continue
                ts,inventory,goal,since=report
                valid = goal is None or (np.asarray(goal).shape==(2,) and np.isfinite(goal).all())
                if (valid and 0<=int(ts)<=step and int(inventory)>=0 and
                        int(ts)>self.assignment_reports.get(peer,(-1,))[0]):
                    self.assignment_reports[peer]=(int(ts),int(inventory),goal,int(since))
            for peer,rejection in message.get('assignment_rejections',{}).items():
                peer=int(peer)
                if len(rejection)==4 and int(rejection[0])>self.assignment_rejections.get(peer,(-1,))[0]:
                    self.assignment_rejections[peer]=rejection
            quality=message.get('map_quality')
            if quality is not None and quality[0]>self.map_quality_records.get(int(message['id']),(-1,))[0]:
                self.map_quality_records[int(message['id'])]=quality
            if message.get('fleet_plan') is not None:
                proposals.append(message['fleet_plan'])
        active_ids=[peer for peer,(ts,position,_) in self.fleet_states.items()
                    if step-ts<self.STATE_FRESH_STEPS and position is not None]
        coordinator=min(active_ids) if active_ids else own
        for epoch,leader,plans in proposals:
            if (leader==coordinator and 0<=step-epoch<self.PLAN_FRESH_STEPS and
                    (self.fleet_plan is None or (epoch,-leader)>(self.fleet_plan[0],-self.fleet_plan[1]))):
                self.fleet_plan=(epoch,leader,plans)

    def _sync_placement(self, step):
        before=self.previous_inventory
        super()._sync_placement(step)
        if before is not None and int(self.carried_bombs_count())<before:
            self.assignment_goal=None
            self.assignment_inventory=None
            self.assignment_reports[int(self.identifier or 0)]=self._own_assignment_report(step)
            self.last_fleet_plan_step=-1000

    def _reset_assignment_progress(self):
        self._progress_goal = None
        self._progress_inventory = None
        self._progress_best_distance = 1e30
        self._progress_since_step = -1000

    def _watch_assignment_progress(self, step, inventory, target):
        if target is None or self.pose is None:
            self._reset_assignment_progress()
            return False
        target = np.asarray(target, dtype=float)
        distance = float(np.linalg.norm(self.pose - target))
        changed = (self._progress_goal is None or self._progress_inventory != inventory or
                   np.linalg.norm(target - self._progress_goal) > 1.0)
        if changed:
            self._progress_goal = target.copy()
            self._progress_inventory = int(inventory)
            self._progress_best_distance = distance
            self._progress_since_step = int(step)
            return False
        if distance + 16.0 < self._progress_best_distance:
            self._progress_best_distance = distance
            self._progress_since_step = int(step)
            return False
        if step - self._progress_since_step < 96:
            return False
        own = int(self.identifier or 0)
        self.assignment_rejections[own] = (int(step), int(inventory), target.copy(), int(step) + 240)
        self.assignment_goal = None
        self.assignment_inventory = None
        self.assignment_reports[own] = self._own_assignment_report(step)
        self.last_fleet_plan_step = -1000
        self.fleet_signature = None
        self._reset_assignment_progress()
        return True

    def _point_conflicts_with_drop(self, point):
        # A goal accepted before communication recovers must satisfy the same
        # spacing as a newly generated grid candidate once an actual drop is known.
        separation=40.0+0.71*float(self.memory.CELL)
        return (any(np.linalg.norm(np.asarray(point)-other)+1e-8<separation for other in self.drop_records.values()) or
                any(np.linalg.norm(np.asarray(point)-center)<radius
                    for center,radius in getattr(self,'_placement_forbidden',lambda:[])()) or
                (getattr(self,'_placement_forbidden_mask',lambda:None)() is not None and
                 self._placement_forbidden_mask()[self.memory.world_to_cell(point)]))

    def _reserved_first_goals(self, step, active):
        reserved={}
        old_plan=self.fleet_plan
        for peer,(_,inventory) in active.items():
            if inventory<=0:
                continue
            report=self.assignment_reports.get(peer)
            target=None
            released=False
            if report is not None:
                ts,reported_inventory,goal,since=report
                # A None predating the latest issue is not its acknowledgement.
                # A fresh None after issue, with a previously assigned goal age,
                # means release. Initial since=-1000 means no ack received yet.
                released=(step-ts<self.STATE_FRESH_STEPS and reported_inventory==inventory and
                          goal is None and since>=0 and old_plan is not None and ts>old_plan[0])
                if (step-ts<self.STATE_FRESH_STEPS and reported_inventory==inventory and
                        goal is not None and 0<=step-since<self.GOAL_LEASE_STEPS):
                    target=np.asarray(goal,float).copy()
            if target is None and not released and old_plan is not None and 0<=step-old_plan[0]<self.PLAN_FRESH_STEPS:
                # An issued but not yet acknowledged first target is also reserved.
                assignment=old_plan[2].get(peer)
                if assignment is not None:
                    original,goals=assignment
                    index=max(0,int(original)-inventory)
                    if index<len(goals): target=np.asarray(goals[index],float).copy()
            if target is not None and not self._point_conflicts_with_drop(target):
                reserved[peer]=target
        return reserved

    def _build_fleet_plan(self, step):
        active={peer:(position,inventory) for peer,(ts,position,inventory) in self.fleet_states.items()
                if step-ts<self.STATE_FRESH_STEPS and position is not None}
        if not active or int(self.identifier or 0)!=min(active):
            return
        reserved=self._reserved_first_goals(step,active)
        early_drops={int(key[0]) for key in self.drop_records
                     if isinstance(key,tuple) and len(key)==2}
        wall_pressure = float(self.elapsed_walltime) >= self.DEADLINE_RELEASE_WALLTIME_FRACTION * self.walltime_limit
        reserve_open=True
        if not reserve_open:
            reserved={peer:goal for peer,goal in reserved.items() if peer not in early_drops}
        signature=(bool(reserve_open),tuple(sorted(early_drops)),tuple(sorted((int(peer),int(rec[0]),round(float(rec[2][0]),1),round(float(rec[2][1]),1),int(rec[3])) for peer,rec in self.assignment_rejections.items() if len(rec)==4 and int(rec[0])<=step<int(rec[3]))),
                   tuple(sorted((peer,inventory) for peer,(_,inventory) in active.items())),
                   tuple(sorted(self.drop_records)),
                   tuple(sorted((peer,round(float(goal[0]),1),round(float(goal[1]),1))
                                for peer,goal in reserved.items())))
        if (self.fleet_plan is not None and signature==self.fleet_signature and
                step-self.last_fleet_plan_step<120):
            return
        remaining={}
        for peer,(position,inventory) in active.items():
            reserved_count=int(peer in reserved)
            unreserved=max(0,inventory-reserved_count)
            if reserve_open:
                quota=unreserved
            else:
                quota=max(0,self.EARLY_DROP_LIMIT-int(peer in early_drops)-reserved_count)
                quota=min(unreserved,quota)
            remaining[peer]=(reserved.get(peer,position),quota)
        # Reservations affect marginal coverage and separation for all owners.
        virtual_drops=list(self.drop_records.values())+list(reserved.values())
        for ts,_,point,until in self.assignment_rejections.values():
            if ts<=step<until and point is not None:
                virtual_drops.append(np.asarray(point,float))
        budget=max(0.,self._remaining_steps()*3.0)
        plans=plan_team_coverage_lns(self.memory,remaining,virtual_drops,self.blast_radius,
                                travel_budget=budget,quality_tolerance=.98,
                                reserved_prefixes={peer:(position,reserved[peer]) for peer,(position,_) in active.items() if peer in reserved},
                                forbidden_points=getattr(self,'_placement_forbidden',lambda:[])(),
                                forbidden_mask=getattr(self,'_placement_forbidden_mask',lambda:None)(),
                                search_seed=step,
                                deadline_pressure=float(step) / max(1.0, float(self.limit)))
        assignments={}
        for peer,(_,inventory) in active.items():
            if inventory<=0: continue
            goals=([reserved[peer].copy()] if peer in reserved else [])+list(plans.get(peer,[]))
            assignments[peer]=(inventory,goals[:inventory])
        self.fleet_plan=(step,int(self.identifier or 0),assignments)
        self.last_fleet_plan_step=step
        self.fleet_signature=signature
        self.plan_drop_count=len(self.drop_records)

    def _reject_assignment(self, step, point):
        own=int(self.identifier or 0)
        self.assignment_rejections[own]=(step,int(self.carried_bombs_count()),np.asarray(point).copy(),step+120)
        self.assignment_goal=None
        self.assignment_inventory=None
        self.assignment_reports[own]=self._own_assignment_report(step)
        self.last_fleet_plan_step=-1000

    def _plan_route(self, step, returning, peer_goals):
        self.placement_goal=None
        own,inventory=int(self.identifier or 0),int(self.carried_bombs_count())
        if step>=self.PLAN_START_RATIO*self.limit:
            self._build_fleet_plan(step)
        if inventory>0 and step>=self.PLAN_START_RATIO*self.limit:
            target=None
            if (self.assignment_goal is not None and self.assignment_inventory==inventory and
                    0<=step-self.assignment_since<self.GOAL_LEASE_STEPS):
                target=self.assignment_goal.copy()
            elif self.fleet_plan is not None and 0<=step-self.fleet_plan[0]<self.PLAN_FRESH_STEPS:
                assignment=self.fleet_plan[2].get(own)
                if assignment is not None:
                    original,goals=assignment
                    index=max(0,int(original)-inventory)
                    if index<len(goals):
                        target=np.asarray(goals[index],float).copy()
                        self.assignment_goal=target.copy()
                        self.assignment_since=step
                        self.assignment_inventory=inventory
            if target is not None and self._watch_assignment_progress(step,inventory,target):
                target=None
            rejection=self.assignment_rejections.get(own)
            if target is not None and (self._point_conflicts_with_drop(target) or
                    (rejection is not None and step<rejection[3] and np.linalg.norm(target-rejection[2])<16)):
                self._reject_assignment(step,target)
                target=None
            if target is not None:
                if np.linalg.norm(self.pose-target)<=self.placement_arrival_radius:
                    self.placement_goal=target.copy()
                    return [target.copy()],target
                route,actual=self.memory.route(self.pose,destination=target)
                if actual is not None and np.linalg.norm(actual-target)<1:
                    self.placement_goal=target.copy()
                    self.assignment_reports[own]=self._own_assignment_report(step)
                    return route or [target.copy()],target
                self._reject_assignment(step,target)
        return GreedyMappingDrone._plan_route(self,step,returning,peer_goals)

    def _placement_spacing(self,step): return 0.0 if step>=.82*self.limit else 30.0

    def _maybe_place(self,command,step,semantic):
        inventory=int(self.carried_bombs_count())
        interval=2 if step>=.72*self.limit else 8
        if (self.submitted or self.pose is None or inventory<=0 or self.pending_drop is not None or
                step-self.last_attempt_step<interval or step<self.PLAN_START_RATIO*self.limit): return
        if step<.72*self.limit and (self.placement_goal is None or
                np.linalg.norm(self.pose-self.placement_goal)>self.placement_arrival_radius): return
        if not self._placement_allowed(step,semantic): return
        command.update(forward=0.,lateral=0.,rotation=0.,grasper=0,place_bomb=1)
        self.pending_drop=(inventory,self.pose.copy(),step)
        self.last_attempt_step=step

    def _is_returning(self,step):
        if int(self.carried_bombs_count())==0 and int(self.identifier or 0) in (1,3) and step<.65*self.limit:
            stats=getattr(self.memory,'edge_stats',{})
            if any(record['missing']>3 for record in stats.values() if record['identified']):
                return False
        return int(self.carried_bombs_count())==0 and step>=self.RETURN_RATIO*self.limit

    def _submission_due(self,step):
        own=int(self.identifier or 0)
        if float(self.elapsed_walltime)>=(.88 if own==0 else .94)*self.walltime_limit: return True
        if self._all_inventory_empty() and step>=self.SUBMIT_RATIO*self.limit:
            own_quality=self._map_quality()
            better=any(step-ts<90 and (known,occupied,-peer)>(*own_quality,-own)
                       for peer,(ts,known,occupied) in self.map_quality_records.items() if peer!=own)
            stats=getattr(self.memory,'edge_stats',{})
            missing=sum(record['missing'] for record in stats.values() if record['identified'])
            bins=sum(record['bins'] for record in stats.values() if record['identified'])
            if not better and own_quality[0]>=.90 and missing<=max(3,.04*bins): return True
        return step>=(self.HARD_SUBMIT_RATIO+.004*min(10,own))*self.limit
