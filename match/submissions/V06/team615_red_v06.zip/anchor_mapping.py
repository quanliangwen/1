"""Measured-boundary pose constraints and line-regularized sensor rendering."""
import numpy as np

from swarm_rescue.solutions.boundary_anchor import ObservedBoundaryAnchor
from swarm_rescue.solutions.fast_exploration_edges_optimized import EdgeSurveyMapMemory
from swarm_rescue.solutions.line_regularization import render_with_observed_boundary
from swarm_rescue.solutions.scan_geometry import extract_scan_lines


class AnchoredMapMemory(EdgeSurveyMapMemory):
    def observe(self, *args, **kwargs):
        super().observe(*args, **kwargs)
        mask=getattr(self,'nonwall_mask',None)
        if mask is not None: self.hits[mask]=0

    def merge(self, packet):
        super().merge(packet)
        mask=getattr(self,'nonwall_mask',None)
        if mask is not None: self.hits[mask]=0

    def render(self):
        return render_with_observed_boundary(self, line_width=18, keep_raw=False,
                                             fit_band=10, duplicate_distance=8, covariance_limit=30,
                                             boundary_bin_evidence=1, boundary_hit_threshold=1)


class AnchoredMappingMixin:
    def __init__(self, identifier=None, misc_data=None, **kwargs):
        super().__init__(identifier=identifier,misc_data=misc_data,**kwargs)
        self.memory = AnchoredMapMemory(*self.size_area,identifier=int(identifier or 0),team_size=self.team_size)
        self.boundary_anchor = ObservedBoundaryAnchor(*self.size_area)

    def _update_pose(self):
        super()._update_pose()
        if self.pose is None or int(self.elapsed_timestep)%4:
            return
        lidar = self.lidar_values()
        if lidar is None:
            return
        angles = np.asarray(self.lidar_rays_angles(),float)
        excluded = self.memory.semantic_mask(np.asarray(lidar),angles,self.semantic_values())
        lines = extract_scan_lines(lidar,angles,excluded)
        self.pose,self.heading,_ = self.boundary_anchor.correct(lines,self.pose,self.heading,int(self.elapsed_timestep))
