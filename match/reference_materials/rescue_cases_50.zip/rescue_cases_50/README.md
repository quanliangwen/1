# Map Cases: Five Sizes, Fifty Layouts

| Reference size | Width x height (pixels) | Cases |
|---|---|---|
| Map01 | 1250 x 800 | 10 |
| Map02 | 1200 x 900 | 10 |
| Map03 | 1113 x 750 | 10 |
| Map04 | 1660 x 1122 | 10 |
| Map05 | 1200 x 1200 | 10 |

The reference maps supply dimensions only. These are newly generated layouts,
not copies of the five original layouts. Every layout has three connected rooms,
six rectangular obstacles, a drone start area, and one disposal center.

`maps/` contains 50 editor JSON scenes and their simulator map/walls modules.
`manifest.json` lists dimensions, seeds, class names, and relative file paths.
No bomb files, bomb placements, images, evaluation plans, or results are generated.
The generated map classes start with zero bombs and default to ten drones;
drone counts and red placement inventories can be set by the evaluator later.

To load a generated class, add this `maps/` directory to
`swarm_rescue.maps.__path__` and import the `map_module` and `map_name` listed
in the manifest. This does not require editing the simulator or original maps.

Regenerate from the project root:

```sh
.venv/bin/python examples/generate_map_cases.py --seed 1042
```

The generator checks dimensions, element bounds, and distinct layouts.
