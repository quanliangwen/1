from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,json,re,urllib.parse,urllib.request,datetime
root=Path(__file__).resolve().parent
branch=json.loads((root/'branch.json').read_text(encoding='utf-8'));rev=branch['commit']['sha']
tree=json.loads((root/'tree.json').read_text(encoding='utf-8'))['tree']
selected=[x for x in tree if x.get('type')=='blob' and (x['path'].lower().endswith(('.md','.rst','.sh','.toml')) or x['path'] in ['req.txt','src/swarm_rescue/solutions/image_ref.txt'])]
def fetch(entry):
 path=entry['path'];url='https://gitee.com/CJYLZS/swarm-eod/raw/'+rev+'/'+urllib.parse.quote(path,safe='/')
 request=urllib.request.Request(url,headers={'User-Agent':'V06-Official-Image-Doc-Audit'})
 with urllib.request.urlopen(request,timeout=25) as response:data=response.read()
 sha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 assert sha==entry['sha'],(path,'raw data does not match Git tree')
 target=root/'docs_snapshot'/path;assert target.resolve().is_relative_to((root/'docs_snapshot').resolve());target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 text=data.decode('utf-8-sig');matches=[];links=[]
 pattern=re.compile(r'镜像|Docker|tar\.gz|sha256|网盘|提取码|下载|离线|registry|ghcr\.io|dockerhub',re.I)
 lines=text.splitlines()
 for i,line in enumerate(lines,1):
  if pattern.search(line):matches.append({'line':i,'text':line})
 for i,line in enumerate(lines,1):
  for m in re.finditer(r'https?://[^\s<>"\)\]，。]+',line):links.append({'line':i,'url':m.group()})
 return {'path':path,'url':url,'git_blob_sha1':sha,'bytes':len(data),'lines':len(lines),'keyword_matches':matches,'http_links':links}
results=[];errors=[]
with ThreadPoolExecutor(max_workers=4) as pool:
 jobs={pool.submit(fetch,e):e['path'] for e in selected}
 for future in as_completed(jobs):
  try:results.append(future.result())
  except Exception as e:errors.append({'path':jobs[future],'error':str(e)})
results.sort(key=lambda x:x['path'])
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':'https://gitee.com/CJYLZS/swarm-eod','commit':rev,'checked_files':results,'errors':errors,'documentation_file_count':sum(x['path'].endswith('.md') for x in results),'official_container_verified':False,'algorithm_tests_resumed':False}
(root/'DOCUMENT_SCAN.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'commit':rev,'files_checked':len(results),'documentation_count':out['documentation_file_count'],'errors':errors,'matching_files':{x['path']:x['keyword_matches'] for x in results if x['keyword_matches']}},ensure_ascii=False,indent=2))
