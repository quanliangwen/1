"""Run INSIDE the official container only. Never starts a game or installs packages.
Before phase: stdlib inventory only, deliberately does not import NumPy.
After phase: actual NumPy ABI/SDK/controller imports and optional tiny hidden GL window.
Dependency installation and entrypoint invocation must first be confirmed from official evidence.
"""
import argparse,datetime,hashlib,importlib,importlib.metadata as md,importlib.util,json,sys,traceback,zipfile
from pathlib import Path
EXPECTED='01c9b9de5caad8f280695852e8e0461a66d26feb689339d5de8047ed3e72008c'
def main():
 p=argparse.ArgumentParser();p.add_argument('--phase',choices=['before','after'],required=True);p.add_argument('--zip',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--check-gl',action='store_true');a=p.parse_args()
 out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':a.phase,'status':'STARTED','python':sys.version,'executable':sys.executable,'algorithm_simulation_run':False,'official_image_identity_verified_by_this_script':False,'note':'Host must independently verify official image archive provenance, checksum, architecture, image ID, official installation order and SDK mounts. Running this script elsewhere is not official-container verification.'}
 try:
  out['zip_sha256']=hashlib.sha256(a.zip.read_bytes()).hexdigest();assert out['zip_sha256']==EXPECTED,'Wrong V06 ZIP'
  with zipfile.ZipFile(a.zip) as z:
   names=z.namelist();assert len(names)==len(set(names)) and all('/' not in n and '\\' not in n for n in names)
   payload={n:hashlib.sha256(z.read(n)).hexdigest() for n in names};out['payload_files_sha256']=payload;out['req_txt']=z.read('req.txt').decode('utf-8-sig')
  out['distribution_metadata']={}
  for n in ['numpy','pandas','opencv-contrib-python','opencv-python','opencv-python-headless','scipy','scikit-image','matplotlib','swarm-rescue']:
   try:
    d=md.distribution(n);out['distribution_metadata'][n]={'version':d.version,'root':str(d.locate_file('')),'metadata_path':str(getattr(d,'_path',''))}
   except md.PackageNotFoundError:out['distribution_metadata'][n]=None
  out['top_level_specs']={}
  for name in ['numpy','pandas','cv2','swarm_rescue']:
   spec=importlib.util.find_spec(name);out['top_level_specs'][name]={'origin':spec.origin,'search_locations':list(spec.submodule_search_locations or [])} if spec else None
  if a.phase=='before':out['status']='INVENTORY_ONLY_NO_ABI_TEST'
  else:
   import numpy as np,pandas as pd,cv2,numpy.random.mtrand as mt
   out['critical_module_paths']={n:m.__file__ for n,m in [('numpy',np),('pandas',pd),('cv2',cv2),('numpy.random.mtrand',mt)]}
   out['module_versions']={'numpy':np.__version__,'pandas':pd.__version__,'cv2':cv2.__version__}
   assert np.isfinite(np.random.RandomState(615).normal(size=64)).all()
   assert pd.DataFrame({'a':[1.,2.,3.]})['a'].sum()==6.
   assert cv2.filter2D(np.ones((8,8),np.float32),-1,np.ones((3,3),np.float32)).shape==(8,8)
   out['real_numeric_operations']='PASS'
   from swarm_rescue.launcher import Launcher
   from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
   from swarm_rescue.simulation.reporting.team_info import TeamInfo
   info=TeamInfo();assert type(info.team_number) is int and info.team_number==615;out['sdk_team_number']=info.team_number
   out['sdk_imports']='PASS'
   from swarm_rescue.solutions.my_drone_eval import MyDroneEval,drone_class_for_mode
   assert drone_class_for_mode('place') is MyDroneEval
   own=[]
   for name,module in list(sys.modules.items()):
    if name.startswith('swarm_rescue.solutions') and getattr(module,'__file__',None):
     path=Path(module.__file__);digest=hashlib.sha256(path.read_bytes()).hexdigest();assert payload.get(path.name)==digest,name+' is not from actual V06'
     own.append({'module':name,'path':str(path),'sha256':digest})
   out['controller_imports']=own;out['controller_factory']='PASS'
   if a.check_gl:
    import pyglet
    w=pyglet.window.Window(width=1,height=1,visible=False)
    try:out['opengl_version']=w.context.get_info().get_version();out['tiny_hidden_gl_context']='PASS'
    finally:w.close()
   out['status']='IMPORT_AND_OPTIONAL_GL_PASS_NO_SIMULATION'
 except BaseException:out.update(status='FAIL',traceback=traceback.format_exc())
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'phase':a.phase,'status':out['status'],'output':str(a.output),'error':out.get('traceback')},ensure_ascii=False))
 return 1 if out['status']=='FAIL' else 0
if __name__=='__main__':sys.exit(main())
