"""Clean Python 3.11 SDK+V06 installation. No algorithm simulation or scoring."""
from pathlib import Path
import base64,hashlib,json,subprocess,sys
root=Path(__file__).resolve().parent
archive=Path(r'E:\10.12-10.26算法对抗赛\提交版本呢\team615_red_v06.zip')
expected='01c9b9de5caad8f280695852e8e0461a66d26feb689339d5de8047ed3e72008c'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==expected
remote=r'''
from pathlib import Path
import base64,datetime,hashlib,io,json,os,shutil,subprocess,sys,tarfile,traceback,zipfile
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
C=H/'PJ01_v06_clean_env_validation_20261029';assert not C.exists(),'Refuse to overwrite an existing clean-environment audit'
C.mkdir();logs=C/'logs';logs.mkdir();reports=C/'reports';reports.mkdir()
base=R/'runtimes/cpython-3.11-linux-x86_64-gnu/bin/python3.11';venv=C/'.venv';py=venv/'bin/python';project=C/'project'
expected='01c9b9de5caad8f280695852e8e0461a66d26feb689339d5de8047ed3e72008c'
archive=C/'team615_red_v06.zip';archive.write_bytes(base64.b64decode(__ZIP_B64__));assert hashlib.sha256(archive.read_bytes()).hexdigest()==expected
out={'status':'STARTED','scope':'Fresh isolated Linux/Python3.11 environment; install SDK editable with dev dependencies, then actual V06 req.txt. NumPy ABI, SDK/controller imports, CLI --help and tiny hidden GL startup only. No map construction, control(), simulation, matches or scoring. Not official base image or official online runner.','zip_sha256':expected,'official_container_verified':False,'algorithm_simulation_run':False,'workspace':str(C),'steps':[]}
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save_state(phase,status='RUNNING'):
 (C/'STATUS.json').write_text(json.dumps({'utc':utc(),'phase':phase,'status':status,'scope':out['scope'],'official_container_verified':False,'algorithm_simulation_run':False},indent=2)+'\n')
 print(json.dumps({'utc':utc(),'phase':phase,'status':status}),flush=True)
env=os.environ.copy()
for k in list(env):
 if k.startswith('PIP_') or k in ['PYTHONPATH','PYTHONHOME','VIRTUAL_ENV','PYTHONSTARTUP','PYTHONUSERBASE']:env.pop(k,None)
env.update(PYTHONNOUSERSITE='1',PIP_CONFIG_FILE=os.devnull,PIP_CACHE_DIR=str(C/'pip_cache'),PIP_INDEX_URL='https://pypi.org/simple',PIP_DISABLE_PIP_VERSION_CHECK='1',PIP_NO_INPUT='1',PIP_DEFAULT_TIMEOUT='30',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',LP_NUM_THREADS='1',MAKEFLAGS='-j1',CARGO_BUILD_JOBS='1',MPLBACKEND='Agg',MPLCONFIGDIR=str(C/'mpl_config'),XDG_CACHE_HOME=str(C/'xdg_cache'),LIBGL_ALWAYS_SOFTWARE='1',ALSOFT_DRIVERS='null')
env['PATH']=str(venv/'bin')+':'+str(R/'system/usr/bin')+':'+env.get('PATH','')
def run(phase,args,timeout=3600,cwd=None):
 save_state(phase);log=logs/(phase+'.log');started=utc()
 with log.open('w') as f:
  p=subprocess.run([str(a) for a in args],cwd=cwd or C,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 out['steps'].append({'phase':phase,'started_utc':started,'finished_utc':utc(),'returncode':p.returncode,'command':[str(a) for a in args],'log':str(log)})
 if p.returncode:raise RuntimeError(phase+' failed, exit '+str(p.returncode)+'; see '+str(log))
 save_state(phase,'PASS')
metadata=r"""
import importlib.metadata as m,json,sys,site
from pathlib import Path
root=Path(sys.argv[1]);rows=[]
for d in m.distributions():
 path=Path(getattr(d,'_path',d.locate_file(''))).resolve();assert path.is_relative_to(root.resolve()),str(path)
 rows.append({'name':d.metadata['Name'],'version':d.version,'metadata_path':str(path)})
assert not site.ENABLE_USER_SITE
foreign=[p for p in sys.path if 'site-packages' in p and not Path(p).resolve().is_relative_to((root/'.venv').resolve())];assert not foreign,foreign
print(json.dumps({'executable':sys.executable,'prefix':sys.prefix,'base_prefix':sys.base_prefix,'sys_path':sys.path,'user_site_enabled':site.ENABLE_USER_SITE,'distributions':sorted(rows,key=lambda x:x['name'].lower())},indent=2))
"""
try:
 assert shutil.disk_usage(C).free>6*1024**3,'Less than 6GiB free disk'
 repo=H/'F32_official_sdk_20261028/source_repo';revision=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip();assert revision=='e2f022bb3832bae16bfb4e67fe8510f2b5baf586'
 out['sdk_source_revision']=revision
 git_tar=subprocess.check_output(['git','-C',str(repo),'archive','--format=tar',revision]);project.mkdir()
 with tarfile.open(fileobj=io.BytesIO(git_tar)) as tar:tar.extractall(project,filter='data')
 run('01_create_clean_venv',[base,'-I','-m','venv',venv],timeout=120)
 cfg=(venv/'pyvenv.cfg').read_text();assert 'include-system-site-packages = false' in cfg
 (reports/'pyvenv.cfg').write_text(cfg)
 run('02_upgrade_clean_pip',[py,'-I','-m','pip','install','--upgrade','pip','--report',reports/'pip_upgrade.json'],timeout=600)
 run('03_install_sdk_from_pyproject',[py,'-I','-m','pip','install','--editable','.[dev]','--report',reports/'sdk_install.json'],cwd=project,timeout=3600)
 save_state('04_inventory_before_v06')
 baseline=subprocess.check_output([str(py),'-I','-c',metadata,str(C)],cwd=project,env=env,text=True);(reports/'before_v06_packages.json').write_text(baseline)
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None;names=z.namelist();assert len(names)==len(set(names)) and all('/' not in n and '\\' not in n and n not in ['.','..'] for n in names)
  out['payload_files_sha256']={n:hashlib.sha256(z.read(n)).hexdigest() for n in names}
  assert z.read('req.txt')==b'numpy>=1.24.4\nopencv-contrib-python>=4.10.0.84\n'
  solutions=project/'src/swarm_rescue/solutions';solutions.mkdir(parents=True,exist_ok=True)
  for n in names:
   dest=project/'req.txt' if n=='req.txt' else solutions/n;dest.write_bytes(z.read(n))
 run('05_install_actual_v06_requirements',[py,'-I','-m','pip','install','-r',project/'req.txt','--report',reports/'v06_install.json'],cwd=project,timeout=900)
 after=subprocess.check_output([str(py),'-I','-c',metadata,str(C)],cwd=project,env=env,text=True);(reports/'after_v06_packages.json').write_text(after)
 b=json.loads(baseline);a=json.loads(after);bm={d['name'].lower():d['version'] for d in b['distributions']};am={d['name'].lower():d['version'] for d in a['distributions']}
 out['package_changes_by_v06']=[{'name':n,'before':bm.get(n),'after':am.get(n)} for n in sorted(set(bm)|set(am)) if bm.get(n)!=am.get(n)]
 out['v06_install_planned_packages']=[{'name':x['metadata']['name'],'version':x['metadata']['version']} for x in json.loads((reports/'v06_install.json').read_text()).get('install',[])]
 run('06_pip_check',[py,'-I','-m','pip','check'],cwd=project,timeout=120)
 probe=r"""
from pathlib import Path
import sys,site,json,hashlib,traceback,importlib.metadata as md
C=Path(sys.argv[1]);project=C/'project';out={'status':'STARTED','scope':'Import/ABI/hidden graphics startup only. No drone or map instance, no control(), no simulation.','official_container_verified':False,'algorithm_simulation_run':False,'python':sys.version,'executable':sys.executable,'sys_path':sys.path,'user_site_enabled':site.ENABLE_USER_SITE}
try:
 assert Path(sys.prefix).resolve()==(C/'.venv').resolve();assert not site.ENABLE_USER_SITE
 manifest=json.loads((C/'RESULT_INPUT.json').read_text())
 for n,sha in manifest['payload_files_sha256'].items():
  p=project/'req.txt' if n=='req.txt' else project/'src/swarm_rescue/solutions'/n;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha,n
 out['exact_v06_payload']='PASS';out['zip_sha256']=manifest['zip_sha256']
 import numpy as np,pandas as pd,cv2,numpy.random.mtrand as mt
 out['distribution_versions']={n:md.version(n) for n in ['numpy','pandas','opencv-contrib-python','scipy','scikit-image','matplotlib','arcade','pyglet','pymunk','PySide6','swarm-rescue']}
 out['critical_module_paths']={n:m.__file__ for n,m in [('numpy',np),('pandas',pd),('cv2',cv2),('numpy.random.mtrand',mt)]}
 assert all(Path(p).resolve().is_relative_to((C/'.venv').resolve()) for p in out['critical_module_paths'].values())
 assert np.isfinite(np.random.RandomState(615).normal(size=64)).all()
 assert pd.DataFrame({'a':[1.,2.,3.]})['a'].sum()==6.
 assert cv2.filter2D(np.ones((8,8),np.float32),-1,np.ones((3,3),np.float32)).shape==(8,8)
 out['real_numeric_operations']='PASS'
 from swarm_rescue.launcher import Launcher
 from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
 from swarm_rescue.simulation.reporting.team_info import TeamInfo
 import swarm_rescue
 assert Path(swarm_rescue.__file__).resolve().is_relative_to((project/'src').resolve());out['sdk_module_path']=swarm_rescue.__file__;out['sdk_import']='PASS'
 info=TeamInfo();assert type(info.team_number) is int and info.team_number==615;out['team_number']=info.team_number
 from swarm_rescue.solutions.my_drone_eval import MyDroneEval,drone_class_for_mode
 assert drone_class_for_mode('place') is MyDroneEval
 own=[]
 for n,m in list(sys.modules.items()):
  if n.startswith('swarm_rescue.solutions') and getattr(m,'__file__',None):
   p=Path(m.__file__);assert p.resolve().is_relative_to((project/'src/swarm_rescue/solutions').resolve());assert hashlib.sha256(p.read_bytes()).hexdigest()==manifest['payload_files_sha256'][p.name];own.append(n)
 out['controller_factory']='PASS';out['controller_imports']=own
 import arcade
 window=arcade.Window(width=1,height=1,visible=False,antialiasing=False)
 try:
  out['gl_context']={'version_code':window.ctx.version_code,'info':{'GL_VENDOR':str(window.ctx.info.VENDOR),'GL_RENDERER':str(window.ctx.info.RENDERER),'GL_VERSION':str(window.ctx.info.VERSION)}}
  assert window.ctx.version_code>=440,'OpenGL below SDK 4.4 requirement'
  out['hidden_arcade_window']='PASS'
 finally:window.close()
 out['status']='PASS'
except BaseException:out.update(status='FAIL',traceback=traceback.format_exc())
(C/'reports/STARTUP_PROBE.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
sys.exit(0 if out['status']=='PASS' else 1)
"""
 (C/'RESULT_INPUT.json').write_text(json.dumps(out,indent=2)+'\n');(C/'probe_startup.py').write_text(probe)
 run('07_real_abi_and_hidden_startup',[R/'system/usr/bin/xvfb-run','-a','-s','-screen 0 640x480x24',py,'-I',C/'probe_startup.py',C],cwd=project,timeout=120)
 out['startup_probe']=json.loads((reports/'STARTUP_PROBE.json').read_text())
 # Source reviewed: argparse --help exits before Launcher construction and launcher.go().
 run('08_launcher_help_no_simulation',[R/'system/usr/bin/xvfb-run','-a','-s','-screen 0 640x480x24',py,'-I','-m','swarm_rescue.launcher','--help'],cwd=project,timeout=120)
 run('09_freeze_installed_dependencies',[py,'-I','-m','pip','freeze','--all'],cwd=project,timeout=120)
 run('10_inspect_installed_dependencies',[py,'-I','-m','pip','inspect'],cwd=project,timeout=120)
 out['status']='PASS_CLEAN_SOURCE_INSTALL_STARTUP_NO_SIMULATION'
except BaseException:out.update(status='FAIL',error=traceback.format_exc())
finally:
 out['finished_utc']=utc();(C/'RESULT.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');save_state('FINISHED',out['status'])
 print(json.dumps({'status':out['status'],'result':str(C/'RESULT.json'),'error':out.get('error')}),flush=True)
 sys.exit(0 if out['status']=='PASS_CLEAN_SOURCE_INSTALL_STARTUP_NO_SIMULATION' else 1)
'''
remote=remote.replace('__ZIP_B64__',repr(base64.b64encode(archive.read_bytes()).decode('ascii')))
(root/'remote_runner.py').write_text(remote,encoding='utf-8')
print('STARTING_CLEAN_SOURCE_INSTALL_ONLY',flush=True)
with (root/'ssh_progress.log').open('wb') as output,(root/'ssh_stderr.log').open('wb') as error:
 p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/runtimes/cpython-3.11-linux-x86_64-gnu/bin/python3.11','-I','-'],input=remote.encode('utf-8'),stdout=output,stderr=error,timeout=5400)
print(json.dumps({'ssh_returncode':p.returncode,'progress_log':str(root/'ssh_progress.log')}),flush=True)
sys.exit(p.returncode)
