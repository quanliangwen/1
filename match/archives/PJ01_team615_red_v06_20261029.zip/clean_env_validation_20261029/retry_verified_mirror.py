from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
s=(root/'remote_runner.py').read_text(encoding='utf-8')
old="C=H/'PJ01_v06_clean_env_validation_20261029';assert not C.exists(),'Refuse to overwrite an existing clean-environment audit'\nC.mkdir();logs=C/'logs';logs.mkdir();reports=C/'reports';reports.mkdir()"
new="C=H/'PJ01_v06_clean_env_validation_20261029';assert C.exists()\nassert (C/'DOWNLOAD_SOURCE_SWITCH_REQUEST.json').exists()\nassert not (C/'RESULT_initial_download_attempt.json').exists()\n(C/'RESULT_initial_download_attempt.json').write_bytes((C/'RESULT.json').read_bytes())\nlogs=C/'logs_retry';logs.mkdir();reports=C/'reports_retry';reports.mkdir()"
assert old in s;s=s.replace(old,new)
s=s.replace("PIP_INDEX_URL='https://pypi.org/simple'","PIP_INDEX_URL='https://pypi.tuna.tsinghua.edu.cn/simple'")
old=" git_tar=subprocess.check_output(['git','-C',str(repo),'archive','--format=tar',revision]);project.mkdir()\n with tarfile.open(fileobj=io.BytesIO(git_tar)) as tar:tar.extractall(project,filter='data')\n run('01_create_clean_venv',[base,'-I','-m','venv',venv],timeout=120)"
new=" assert (project/'pyproject.toml').exists() and (venv/'pyvenv.cfg').exists()\n out['setup_completed_in_first_download_attempt']=json.loads((C/'RESULT_initial_download_attempt.json').read_text())['steps'][:2]\n out['download_retry_reason']=json.loads((C/'DOWNLOAD_SOURCE_SWITCH_REQUEST.json').read_text())"
assert old in s;s=s.replace(old,new)
line=" run('02_upgrade_clean_pip',[py,'-I','-m','pip','install','--upgrade','pip','--report',reports/'pip_upgrade.json'],timeout=600)\n"
assert line in s;s=s.replace(line,'')
old="  out['gl_context']={'version_code':window.ctx.version_code,'info':{'GL_VENDOR':str(window.ctx.info.VENDOR),'GL_RENDERER':str(window.ctx.info.RENDERER),'GL_VERSION':str(window.ctx.info.VERSION)}}\n  assert window.ctx.version_code>=440,'OpenGL below SDK 4.4 requirement'"
new="  gl_version=(int(window.ctx.info.MAJOR_VERSION),int(window.ctx.info.MINOR_VERSION))\n  out['gl_context']={'version':list(gl_version),'vendor':str(window.ctx.info.VENDOR),'renderer':str(window.ctx.info.RENDERER)}\n  assert gl_version>=(4,4),'OpenGL below SDK 4.4 requirement'\n  shader=window.ctx.compute_shader(source='#version 440\\nlayout(local_size_x=1) in; void main(){}')\n  shader.delete();out['glsl440_compute_shader_compile']='PASS'"
assert old in s;s=s.replace(old,new)
s=s.replace("(C/'reports/STARTUP_PROBE.json')","(C/'reports_retry/STARTUP_PROBE.json')")
insert=r'''
 save_state('03b_verify_download_hashes_against_primary_pypi')
 import urllib.parse,urllib.request
 from concurrent.futures import ThreadPoolExecutor
 entries=[]
 for report in [C/'reports/pip_upgrade.json',reports/'sdk_install.json']:
  for item in json.loads(report.read_text()).get('install',[]):
   download=item.get('download_info',{});url=download.get('url','')
   if url.startswith(('http://','https://')):entries.append(item)
 def verify_artifact(item):
  name=item['metadata']['name'];version=item['metadata']['version'];info=item['download_info'];filename=Path(urllib.parse.unquote(urllib.parse.urlsplit(info['url']).path)).name
  claimed=info.get('archive_info',{}).get('hashes',{}).get('sha256');assert claimed,(name,'No SHA256 in pip installation report')
  url='https://pypi.org/pypi/'+urllib.parse.quote(name,safe='')+'/'+urllib.parse.quote(version,safe='')+'/json'
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'V06-Clean-Install-Hash-Audit'}),timeout=30) as resp:data=json.loads(resp.read())
  matches=[f for f in data['urls'] if f['filename']==filename];assert len(matches)==1,(name,filename,'Not in official PyPI release')
  expected=matches[0]['digests']['sha256'];assert expected==claimed,(name,filename,'Artifact hash differs from official PyPI')
  return {'name':name,'version':version,'filename':filename,'sha256':claimed,'official_pypi_release_api':url,'source_download_url':info['url'],'status':'PASS'}
 with ThreadPoolExecutor(max_workers=4) as pool:verified=list(pool.map(verify_artifact,entries))
 (reports/'OFFICIAL_PYPI_HASH_VERIFICATION.json').write_text(json.dumps({'status':'PASS','artifacts':verified},indent=2)+'\n')
 out['official_pypi_artifacts_verified']=len(verified)
 save_state('03b_verify_download_hashes_against_primary_pypi','PASS')
'''
marker=" save_state('04_inventory_before_v06')"
assert marker in s;s=s.replace(marker,insert+'\n'+marker,1)
# Correct validator GL fields before it is ever run; SDK/controller code remains untouched.
(root/'remote_runner_retry.py').write_text(s,encoding='utf-8')
print('RETRYING_SAME_FRESH_ENVIRONMENT_WITH_HASH_VERIFIED_DOWNLOAD_SOURCE',flush=True)
with (root/'ssh_progress_retry.log').open('wb') as output,(root/'ssh_stderr_retry.log').open('wb') as error:
 p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/runtimes/cpython-3.11-linux-x86_64-gnu/bin/python3.11','-I','-'],input=s.encode('utf-8'),stdout=output,stderr=error,timeout=5400)
print({'ssh_returncode':p.returncode},flush=True)
sys.exit(p.returncode)
