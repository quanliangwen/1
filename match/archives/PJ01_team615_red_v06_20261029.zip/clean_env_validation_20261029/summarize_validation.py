from pathlib import Path
import datetime,hashlib,json,subprocess,zipfile
r=Path(r'E:\codex\PJ01_team615_red_v06_20261029\clean_env_validation_20261029')
x=json.loads((r/'RESULT.json').read_text(encoding='utf-8'));s=x['startup_probe'];verify=json.loads((r/'reports_retry/OFFICIAL_PYPI_HASH_VERIFICATION.json').read_text(encoding='utf-8'));source=json.loads((r/'reports_retry/SDK_SOURCE_INTEGRITY.json').read_text(encoding='utf-8'))
assert x['status']=='PASS_CLEAN_SOURCE_INSTALL_STARTUP_NO_SIMULATION'
assert all(step['returncode']==0 for step in x['steps'])
assert s['status']==verify['status']==source['status']=='PASS'
assert x['package_changes_by_v06']==[] and x['v06_install_planned_packages']==[]
archive=Path(r'E:\10.12-10.26算法对抗赛\提交版本呢\team615_red_v06.zip');sha=hashlib.sha256(archive.read_bytes()).hexdigest();assert sha==x['zip_sha256']
with zipfile.ZipFile(archive) as z:assert {n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}==x['payload_files_sha256']
summary={'checked_at_shanghai':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),'status':'PASS_CLEAN_SOURCE_INSTALL_STARTUP_NO_SIMULATION','actual_zip_path':str(archive),'actual_zip_sha256':sha,'sdk_commit':x['sdk_source_revision'],'python':s['python'],'executable':s['executable'],'critical_versions':s['distribution_versions'],'v06_install_changed_packages':x['package_changes_by_v06'],'official_pypi_download_artifacts_sha256_verified':len(verify['artifacts']),'sdk_tracked_files_byte_unchanged':source['checked_sdk_files'],'pip_check':'PASS','numeric_abi_and_operations':'PASS','sdk_and_actual_controller_imports':'PASS','sdk_read_integer_team_number':s['team_number'],'launcher_help_no_map_or_simulation':'PASS','hidden_arcade_window':'PASS','opengl':s['gl_context'],'glsl440_compute_shader_compile':'PASS','official_container_verified':False,'algorithm_simulation_run':False,'old_numeric_environments_reused':False,'note':'Fresh venv seeded from standalone Python3.11. No old site-packages paths, package symlinks or PYTHONPATH overlays. OS graphics libraries and Xvfb are shared host facilities. Official image/online installation order not reproduced.'}
(r/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
lines=[
'V06 全新源码安装环境验证结果',
'验证日期：2026-10-29（北京时间）',
'',
'结论：通过。全新Linux/Python3.11环境按仓库依赖完成安装，实际V06 ZIP的真实ABI、SDK/控制器入口、命令入口与隐藏图形初始化检查均通过；未复现NumPy二进制兼容错误。',
'本次不是官方基础镜像或官网在线任务，不代表完整比赛已经运行通过。',
'',
'一、验证对象与来源',
'实际压缩包：'+str(archive),
'SHA256：'+sha,
'官方源码：CJYLZS/swarm-eod，提交'+x['sdk_source_revision'],
'Python：'+s['python'].splitlines()[0],
'服务器工作区：'+x['workspace'],
'',
'二、安装方式与干净程度',
'1. 从已核对的官方固定提交git archive复制新的完整源码工作区，使用独立Python3.11解释器创建新的.venv；未启用system-site-packages或用户site。',
'2. 按选手安装指南执行pip install --editable .[dev]，由pyproject.toml解析完整SDK及开发依赖。',
'3. 从最终V06 ZIP提取控制器和req.txt，随后真实执行pip install -r req.txt；该步骤没有新增、升级或降级任何包。',
'4. 所有NumPy/Pandas/OpenCV/mtrand模块路径均实际位于本次新venv内；所有distribution元数据位于新工作区。没有用sys.path.insert拼接旧环境，没有复用旧数值库目录或符号链接。',
'5. 安装初次直连PyPI下载慢，主动停止时新环境中仅有pip/setuptools，尚未安装数值运行库；保留首次日志后改用清华镜像完成首次完整安装。46份下载产物的SHA256已逐一与官方PyPI对应发布文件核验一致。',
'6. 操作系统、Mesa图形库及Xvfb是已有服务器设施；本次没有修改它们，也没有修改既有比赛虚拟环境。干净范围是Python依赖环境，不是新操作系统容器。',
'',
'三、实际安装版本',
]+[k+'=='+v for k,v in s['distribution_versions'].items()]+[
'',
'四、实际检查结果',
'- pip check：通过，无依赖声明冲突。',
'- NumPy.random.mtrand导入和RandomState随机数计算：通过。',
'- Pandas DataFrame计算、OpenCV filter2D运算：通过。',
'- SDK Launcher、StatsComputation导入：通过。',
'- SDK TeamInfo读取V06的队号：整数615，通过。',
'- V06实际MyDroneEval及place工厂入口导入：通过；实际导入的控制器文件逐一与ZIP哈希一致。',
'- 在新的独立进程执行python -m swarm_rescue.launcher --help：退出码0。已审查源码，--help在Launcher实例化、地图创建与go()之前退出。',
'- 创建并关闭1x1隐藏Arcade窗口：通过。OpenGL版本4.5，Mesa/X.org，llvmpipe软件渲染。',
'- GLSL4.40最小计算着色器编译：通过，没有派发计算或运行传感器仿真。',
'- 205个SDK非solutions/req的跟踪源码文件与官方固定提交逐字节一致，没有修改框架。',
'',
'五、结论边界',
'本次提供了比旧数值库叠加检查更完整的源码安装证据：V06能够在完全重新安装的Python依赖环境中完成启动前检查，且它没有触发核心依赖替换。',
'没有获得官方镜像，因此没有复现官网预装版本、容器挂载和私有安装器顺序；不能保证官网忽略req、复用损坏环境或混用扩展时不会报错。',
'未创建比赛地图、未实例化比赛Launcher、未实例化无人机、未调用control()、未执行GUI事件循环、未进行红蓝对战或五图评分。不能据此评价算法得分或整场控制逻辑。自动迭代/心跳仍未恢复。',
'本次没有改变V06压缩包、依赖声明或36个算法源码，没有生成V07，也没有上传官网。',
'',
'六、证据文件',
'SUMMARY.json：精简结果、关键版本、实际文件哈希与检查范围。',
'RESULT.json：完整步骤和启动检查回执。',
'reports_retry/sdk_install.json：SDK真实安装来源和解析结果。',
'reports_retry/v06_install.json：实际V06依赖安装列表为空。',
'reports_retry/OFFICIAL_PYPI_HASH_VERIFICATION.json：46份下载产物的官方哈希核验。',
'reports_retry/before_v06_packages.json、after_v06_packages.json：独立环境路径与完整包清单。',
'reports_retry/STARTUP_PROBE.json：真实二进制模块路径、队号、入口、OpenGL结果。',
'logs_retry/06_pip_check.log、08_launcher_help_no_simulation.log：依赖检查与命令入口原始输出。',
'logs_retry/09_freeze_installed_dependencies.log：完整pip freeze --all，可复现版本清单。',
'RESULT_initial_download_attempt.json及DOWNLOAD_SOURCE_SWITCH_REQUEST.json：保留首次下载中止及改源原因；该中止不是NumPy或算法运行失败。',
]
(r/'干净环境安装与启动验证结果.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps({'final_status':summary['status'],'hash_verified':sha,'reports_saved':str(r),'mirror_hash_verification':len(verify['artifacts'])},ensure_ascii=False))
