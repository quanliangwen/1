from pathlib import Path
import datetime,hashlib,json,statistics
F=Path(__file__).resolve().parent;T=Path('E:/codex/PJ01_rule_refinement_20261101');C=F/'P35_continuation_after_parent_repair';OUT=F/'P35_FIVE_FINAL_ANALYSIS_FIRST.json';assert not OUT.exists()
inputs={'PJ01':T/'P37_phase_five_comparison_20261101/PJ01_A','P35':C/'P35_A'};read=lambda p:json.loads(p.read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[];groups={};binding={}
for version,G in inputs.items():
 proof=read(G/'CLIENT_FIRST_RAW_REVIEW.json');assert proof['status']=='PASS'
 matrix=read(G/'RESULT.json');assert matrix['complete']and set(matrix['jobs'])=={'Map01','Map02','Map03','Map04','Map05'}
 for n in ['RESULT.json','CLIENT_FIRST_RAW_REVIEW.json','RAW_ARCHIVE_RECEIPT.json']:binding[str(G/n)]=sha(G/n)
 items=[]
 for m,j in sorted(matrix['jobs'].items()):
  assert j['status']=='complete'and len(j['rounds'])==1;r=j['rounds'][0];p=r['phase'];b=r['blue']
  terms=dict(map=.5*p['score_map'],wall=.2*p['score_wall'],time=.1*p['score_time'],layout=r['layout_contribution']);assert abs(sum(terms.values())-r['full_score'])<1e-7
  row=dict(version=version,map=m,full=r['full_score'],map_score=p['score_map'],wall_score=p['score_wall'],time_score=p['score_time'],layout_contribution=r['layout_contribution'],placed=r['placed'],expected=r['expected'],red_steps=r['red_steps'],red_wall=r['red_walltime'],red_wall_hit=r['red_max_walltime_reached'],blue_disposed=b['disposed'],blue_expected=b['expected'],blue_steps=b['timestep'],blue_wall=b['walltime'],blue_wall_hit=b['max_walltime_reached'],blue_crashed=b['crashed'],blue_error=b['error'],weighted_terms=terms)
  items.append(row);rows.append(row)
 groups[version]=dict(mean=statistics.mean(x['full']for x in items),map_mean=statistics.mean(x['map_score']for x in items),wall_mean=statistics.mean(x['wall_score']for x in items),time_mean=statistics.mean(x['time_score']for x in items),placed=sum(x['placed']for x in items),expected=sum(x['expected']for x in items),red_wall_hits=sum(x['red_wall_hit']for x in items),blue_wall_hits=sum(x['blue_wall_hit']for x in items),evaluation_valid=all(not x['red_wall_hit']and not x['blue_wall_hit']and not x['blue_crashed']and not x['blue_error']for x in items),completion_complete=all(x['placed']==x['expected']for x in items))
delta=groups['P35']['mean']-groups['PJ01']['mean'];valid=all(g['evaluation_valid']for g in groups.values())
comparisons=[]
for m in ['Map01','Map02','Map03','Map04','Map05']:
 a=next(r for r in rows if r['map']==m and r['version']=='PJ01');b=next(r for r in rows if r['map']==m and r['version']=='P35')
 comparisons.append(dict(map=m,baseline=a['full'],candidate=b['full'],observed_delta=b['full']-a['full'],weighted_delta={k:b['weighted_terms'][k]-a['weighted_terms'][k]for k in a['weighted_terms']},stock=[a['placed'],b['placed']]))
out=dict(status='COMPLETE_REVIEWED_FIVE_COMPARISON_AFTER_ENV_REBUILD',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),groups=groups,observed_delta=delta,evaluation_valid=valid,rows=rows,comparisons=comparisons,input_metadata_sha256=binding,baseline_rerun=False,new_native_rounds=10,new_raw_byte_review_repeated=False,
    decision='NO_B_OR_AUTOMATIC_PROMOTION',reason='Original B condition requires both A50/50, retained baseline48/50 fails. If candidate below80 or not above baseline stop repeats. Otherwise still no automatic promotion.',
    descriptive_benefit_only=valid and delta>0,candidate_at_least80=groups['P35']['mean']>=80,
    environment_caveat='User required retaining completed PJ01. SDK/controller/evaluator/thread hashes matched, but environment reconstructed with missing old full dependency freeze; Python build/auxiliary deps/natural randomness/host time differ. Not a strict post-recovery same-environment causal experiment.')
OUT.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
text=['P35恢复后五图与保留PJ01对照（全部首次Windows审核完成）',json.dumps(groups,ensure_ascii=False,indent=2),f'完整均分观察差P35−PJ01={delta:+.10f}','地图 | PJ01 | P35 | 差 | 投放PJ01/P35']
for r in comparisons:text.append(f"{r['map']} | {r['baseline']:.6f} | {r['candidate']:.6f} | {r['observed_delta']:+.6f} | {r['stock'][0]}/{r['stock'][1]}")
text.extend(['逐图分项、时限和贡献分解见P35_FIVE_FINAL_ANALYSIS_FIRST.json。','判断：'+out['reason'],'比较限制：'+out['environment_caveat'],'没有重跑PJ01、没有重试原生、没有自动晋级/发布。'])
(F/'P35五图结果与分项分析.txt').write_text('\n'.join(text)+'\n',encoding='utf-8')
print(json.dumps(dict(status=out['status'],groups=groups,observed_delta=delta,evaluation_valid=valid),ensure_ascii=False))
