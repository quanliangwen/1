#!/usr/bin/env bash
set -euo pipefail
task_root=/home/junhao/quan/parallel_test_solver/match
cd "$task_root"
export PATH="$task_root/system/usr/bin:$PATH"
export LIBGL_ALWAYS_SOFTWARE=1
export LP_NUM_THREADS=4
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
export MPLBACKEND=Agg
export ALSOFT_DRIVERS=null
exec xvfb-run -a -s '-screen 0 1920x1080x24' "$task_root/.venv/bin/python" "$@"
