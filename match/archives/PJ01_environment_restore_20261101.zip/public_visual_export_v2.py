"""After-round export of public renderer trails and final disposal status.

No hooks during control/physics, no controller memories/messages, no NPZ/pickle
loads. This diagnostic stays outside all solutions packages. It cannot report
per-bomb detection, grasp or disposal time; those events are not recorded.
"""
from pathlib import Path
import json
import numpy as np
import cv2

def capture_initial_layout(arena):
    return [(bomb,tuple(float(x) for x in bomb.true_position())) for bomb in arena.bombs]

def export_after_round(arena,gui,initial,mode,out,index,submitted=None):
    out=Path(out)
    h,w=arena.explored_map._map_explo_lines.shape
    tracks=[]
    for ordinal,(drone,points) in enumerate(arena.explored_map._explo_pts.items()):
        identifier=getattr(drone,'identifier',None)
        identifier='unlabelled_'+str(ordinal) if identifier is None else int(identifier)
        tracks.append({'id':identifier,'points_pixel':[[int(x),int(y)] for x,y in points],
            'health_positive_at_export':int(drone.drone_health)>0,'health_final':int(drone.drone_health)})
    bombs=[{'id':i+1,'initial_world':list(position),'disposed':bool(bomb.disposed)} for i,(bomb,position) in enumerate(initial)]
    if mode=='rescue':assert sum(b['disposed'] for b in bombs)==int(gui.disposed_number)
    info={'mode':mode,'map':type(arena).__name__,'width':int(w),'height':int(h),
        'tracks':tracks,'bombs':bombs,'timestep':int(gui.elapsed_timestep),'walltime':float(gui.elapsed_walltime),
        'disposed_count':int(gui.disposed_number),'source':'Native ExploredMap renderer trails and public game Bomb.disposed, exported only after original summary/score finalized.',
        'controller_private_state_read':False,'historical_arrays_loaded':False,
        'per_bomb_discovery_or_disposal_times_available':False}
    path=out/('round'+str(index)+'_public_visual.json');assert not path.exists();path.write_text(json.dumps(info,separators=(',',':'))+'\n')
    if mode=='place' and submitted is not None:
        image=np.asarray(submitted)
        assert image.ndim==2 and image.shape==(h,w)
        if image.max(initial=0)<=1:image=(image*255).astype(np.uint8)
        else:image=np.clip(image,0,255).astype(np.uint8)
        assert cv2.imwrite(str(out/('round'+str(index)+'_red_submitted.png')),image)
