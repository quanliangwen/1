from pathlib import Path
import datetime,hashlib,json
F=Path(__file__).resolve().parent;R=Path('E:/codex');T=R/'PJ01_rule_refinement_20261101';C=F/'P35_continuation';OUT=F/'RECOVERY_LOCAL_MANIFEST_FIRST.json';assert not OUT.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=[F/'RUNTIME_ABI_AND_SDK_FIRST.json']+[F/('STARTUP_'+a+'_V2_FIXTURE_FIXED.json')for a in ['PJ01','P35','BLUE']]
assert all(json.loads(p.read_text())['status'].startswith('PASS')for p in checks)
OUT.write_text(json.dumps(dict(status='ENV_RESTORED_SDK_PJ01_P35_BLUE_STARTUP_PASS_P35_ONLY_CONTINUATION_LAUNCHED',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files={str(p.relative_to(F)):sha(p)for p in F.rglob('*')if p.is_file()and p.suffix in ['.json','.txt','.py']and 'SDK_frozen_e2f022b'not in p.parts},native_scheduled_max=10,PJ01_control_rerun=False,official_submission=False),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
prompt='''最新2026-11-01环境恢复与P35接续（优先于旧P40/磁盘/环境缺失状态）。用户明确要求恢复原环境，先SDK和PJ01正常启动，再只接续P35五图，绝不重跑已完成PJ01。已完成实质恢复和启动检查，详情先读E:/codex/PJ01_environment_restore_20261101/恢复依据与验证结论.txt、RECOVERY_LOCAL_MANIFEST_FIRST.json及4份ABI/STARTUP回执；仍读E:/codex/AGENTS.md。

当前唯一队列服务器H/P41_environment_restore_20261101/P35_continuation，本机E:/codex/PJ01_environment_restore_20261101/P35_continuation。R=/home/junhao/quan/parallel_test_solver/match；H=R/solver_study/framework_screen_20261016/best87_independent_20261025；SSHjunhao@10.112.162.60。Python恢复为R/.venv/bin/python；不再把旧解释器缺失/磁盘<12当现状，元数据也用新venv。
coordinator2660394/start400417630/UTC11:50:22，Windowscollector92992/UTC11:50:21，14h有限。初查live/第一资源样本clean，尚需第二60秒样本；后续务必查/proc actual cmd/start、STATUS/RESULT、global serial_evaluation.lock及heuristic_20261016.json active/current，等待也占唯一调度，不重复启动。旧2534852和95784已退出，旧P37 STATUS残留WAITING不是活动队列；旧P37/RECOVERY_CONTINUATION.json指向本阶段。只保留这一恢复续跑，不恢复match7/C7。

原SDK e2f022b124文件、原worker/evaluator/exporter/run_server和全部25原冻结引用都恢复同SHA；P35源/ZIP仍358c2656addcca17f909150020c2108c027c62346a26079ffa046f8d5f0355ac，PJ01源未改。team006上传ZIP5dbf10fc...控制器a06324...及原elkai wheel10文件同SHA。核心版本Python3.11.17/NumPy1.26.4/Pandas3.0.6/OpenCV4.11.0.86/SciPy1.17.1/Arcade2.6.17/Pymunk6.4.0/pyglet2.0.dev23/Pillow9.3.0。新venv非旧site叠加，mtrand/随机数/Pandas/OpenCV/SciPy真实运算、SDK Launcher/Stats导入、GL4.5和五机独立构造PASS；PJ01/P35/BLUE各原GUI8更新通过，pip check通过，零完整比赛/不算PJ01对照重跑。
旧venv全量freeze未保留，Python同3.11.17但新发行包编译日期/Clang及部分辅助库可能不同；完整新freeze/installreport已存。不能称环境逐字节复现，也不能把沿用恢复前PJ01作恢复后严格同环境同期因果对照。此限制已写新PREDECLARATION，用户明确不要重跑PJ01，不能自行补跑。

接续只P35_A，保持从未消耗的原标签sdk_e2f022b_p37_P35_A，原Map01-05各1RED+1BLUE，最多10new native；没有新baseline，没有B。新run_cohort/resource/acquire_when_ready/validate_frozen AST与原驱动一致，只恢复单组调度/声明/汇总。全局registry因原文件被删，先检查proc再创建带恢复说明的空active状态，保留已完成baseline标签，非偷偷清账。首native失败停链保留不重试/seed/换label救分。
原资源CPU<=60/loadcore<=.4/RAM>=8GiB/盘>=12GiB、两个60秒样本；SDK/原team006/线程/每图原时限/无外部seed均不改，旧高负载授权耗尽。P35源码运行中冻结，当前不并开P40 SDK或新科学队列。

原PJ01_A保留在H/P37.../PJ01_A，已Windows首次71raw PASS，全红均71.7795397535/48枚/双方无hit，不能重审旧raw或重跑。新P35_A只首次Windowsraw字节审一次，collector负责；每次确认其PID活着。NPZ/pickle仅不透明SHA，禁反序列化和BLUE私有console。自己的RED文本和官方公开图仅离线诊断，生产只本机公共观测/实收消息，不读真图/peer对象/BLUE私态/历史结果/地图硬码。
新STATUS完成须等CLIENT_FIRST_RAW_REVIEW及CAMPAIGN_CLIENT_REVIEW PASS才报最终均分。完整共同原五图逐图总/地图/墙/时间/难度贡献、实际投放、红蓝hit全部汇总；少投是算法低分，不自动当评测无效，native crash/wallhit另标限制。原B须两A50，基线48已不满足，不能事后放宽。P35即使单图曾76.743也不作当前五图均分，不能只看作者场景90.9。五图<80/不优于保留基线停止重复，先按证据分析。无自动维护池晋级或官网发布。

原P40新墙事件候选依旧只有源/数值检查，未SDK/native；先完成P35五图，不加新规则、不盲目全量。P18旧让点Map02完整69.673746已包含难度项，BLUE1704步10/10、难度贡献0，已淘汰不重跑。当前用户授权原PJ01规则主线一次一条、得分优先、必要绕障补墙融合可保留；新暂停立即停止后续调度。内置goal若仍BLOCKED不可用create_goal伪造active/缩小原目标，本轮人工恢复测试授权已明确；不自行完成无限迭代目标。无子代理授权不spawn。

首错/环境异常保留：SDK归档HTML未用，uv元数据旧URL404，解释器alias计数断言及smoke夹具SyntaxError均在SDK科学运行前，修工具/夹具未改候选；原环境删除导致旧coordinator/collector退出，旧记录保留。恢复说明/源码/回执写本机E:/codex和经验总账。automation90 ACTIVE，状态无变安静；只在实质完成分数/异常/可信改善/需要用户决策时通知。现阶段不是磁盘资源阻塞等待用户清理，旧pending问题已失效。
'''
(F/'WORKING_HANDOFF_RECOVERY.txt').write_text(prompt,encoding='utf-8');(F/'AUTOMATION_PROMPT.txt').write_text(prompt,encoding='utf-8')
p=R/'swarm-eod-literature-analysis/CURRENT_ACTIVE_ANALYSIS.txt';b=p.with_name(p.stem+'_BEFORE_ENV_RESTORED.txt');assert not b.exists();b.write_bytes(p.read_bytes());p.write_text(prompt,encoding='utf-8')
with(T/'本轮规则经验总账_P26起.txt').open('a',encoding='utf-8')as f:
 f.write('\n2026-11-01用户明确恢复已删除环境并只跑P35、不重跑PJ01。新venv核心固定版本/SDK124和原25冻结引用hash同、原blue/elkai同；ABI与SDK/PJ01/P35/BLUE启动及8 GUI更新/pipcheck PASS。全量旧freeze缺失，Pythonbuild/辅助库可能不同，记录新freeze并保留恢复前基线比较限制。仅新P35_A原标签/5RED5BLUE10native，恢复coordinator2660394/start400417630，Windows92992；原资源两60秒样本，旧P37baseline71.77954/48原封保留。首工具/夹具错误原样留存，非native重试，无发布。\n')
print('Recovery evidence and latest handoff recorded')
