"""One authorized, detached, finite comparison; no SDK or controller patches."""
from pathlib import Path
import ast, datetime, fcntl, hashlib, json, math, os, shutil, signal, statistics, subprocess, sys, tarfile, time, traceback

R = Path('/home/junhao/quan/parallel_test_solver/match')
S = R / 'solver_study'
H = S / 'framework_screen_20261016/best87_independent_20261025'
F = H / 'P41_environment_restore_20261101/P35_continuation_after_parent_repair'
D = json.loads((F / 'PREDECLARATION.json').read_text())
NAMES = D['selection']
BLUE = D['blue_binding']
BLUE_CONTROLLER_SHA = json.loads(Path(BLUE['staging_manifest']).read_text())['source_files']['lbbd_rescue.py']
WBLUE = Path(BLUE['blue_workspace'])
ENV = {k: v for k, v in os.environ.items() if k not in ['MATCH_PHASE_ID', 'PYGLET_HEADLESS', 'PYTHONPATH', 'MATCH_FIVE_BATCH_FD', 'MATCH_FIVE_PAYLOAD_ID']}
ENV['MATCH_HEURISTIC_ID'] = 'heuristic_20261015T2047Z'
STOP = False
STATE = {'phase': F.name, 'status': 'STARTING', 'pid': os.getpid(), 'started_utc': None, 'completed': [], 'skipped': [], 'current': None, 'first_native_failure': False, 'new_blue': BLUE['opponent_id'], 'raw_arrays_loaded': 0}


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def save(p, d):
    tmp = p.with_name(p.name + '.tmp_' + str(os.getpid()))
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=2) + '\n')
    tmp.replace(p)


def state(status, **kw):
    STATE.update(status=status, updated_utc=utc(), **kw)
    save(F / 'STATUS.json', STATE)


def stop_handler(sig, frame):
    global STOP
    STOP = True  # Current native rounds finish with their original clocks.


signal.signal(signal.SIGTERM, stop_handler)
signal.signal(signal.SIGINT, stop_handler)


def stop_requested():
    return STOP or (F / 'PAUSE_REQUESTED').exists() or (F / 'STOP_REQUESTED').exists()


def validate_frozen():
    assert sha(S / 'ACTIVE_BLUE_OPPONENT.json') == D['blue_binding_sha256'], 'Opponent binding changed'
    assert all(sha(n) == h for n, h in D['frozen_files'].items()), 'Frozen evaluator, registry or runtime source changed'
    bd = json.loads(Path(BLUE['staging_manifest']).read_text())
    for n, h in bd['source_files'].items():
        p = WBLUE / 'req.txt' if n == 'req.txt' else WBLUE / 'src/swarm_rescue/solutions' / n
        assert sha(p) == h, ('BLUE source', n)
    assert all(sha(WBLUE / 'src' / n) == h for n, h in bd['dependency_files'].items())
    assert all(sha(WBLUE / n) == h for n, h in D['sdk_files'].items())
    for v, b in D['versions'].items():
        assert sha(b['original_zip']) == b['original_zip_sha256']
        assert {p.name: sha(p) for p in Path(b['source']).iterdir()} == b['source_files']
        q = json.loads((F / 'versions' / v / 'QUALIFICATION.json').read_text())
        assert q['status'] == 'PASS' and q['payload_files_sha256'] == b['source_files']


def cpu_sample():
    data = [int(x) for x in Path('/proc/stat').read_text().splitlines()[0].split()[1:9]]
    return sum(data), data[3] + data[4]


def resource():
    a = cpu_sample()
    time.sleep(1)
    b = cpu_sample()
    busy = 100 * (1 - (b[1] - a[1]) / max(1, b[0] - a[0]))
    cpu = os.cpu_count() or 1
    load = os.getloadavg()[0]
    available = next(int(l.split()[1]) * 1024 for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:'))
    disk = shutil.disk_usage(R).free
    cfg = D['resource_gate']
    return {'utc': utc(), 'cpu_count': cpu, 'cpu_busy_percent': busy, 'load_one_min': load, 'memory_available_GiB': available / 2**30, 'disk_free_GiB': disk / 2**30, 'clean': busy <= cfg['cpu_busy_max'] and load / cpu <= cfg['load_per_cpu_max'] and available / 2**30 >= cfg['memory_available_GiB_min'] and disk / 2**30 >= cfg['disk_free_GiB_min']}


def acquire_when_ready():
    start = time.monotonic()
    clean = 0
    while time.monotonic() - start < D['resource_gate']['max_wait_seconds']:
        if stop_requested(): return None
        obs = resource()
        activity = json.loads((S / 'heuristic_20261016.json').read_text())
        clean = clean + 1 if obs['clean'] and not activity.get('active_processes') and not activity.get('current_formal_active') else 0
        obs['consecutive_clean'] = clean
        with (F / 'RESOURCE_OBSERVATIONS.jsonl').open('a') as out: out.write(json.dumps(obs) + '\n')
        state('WAITING_FOR_CAPACITY', resource=obs)
        if clean >= D['resource_gate']['consecutive_samples']:
            lock = (S / 'serial_evaluation.lock').open('a+')
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                lock.close()
                clean = 0
            else:
                again = json.loads((S / 'heuristic_20261016.json').read_text())
                if not again.get('active_processes') and not again.get('current_formal_active'): return lock
                lock.close()
                clean = 0
        for _ in range(D['resource_gate']['interval_seconds']):
            if stop_requested(): return None
            time.sleep(1)
    raise TimeoutError('Resource waiting expired; no game retry or resource override')


def activity_on(item, processes):
    p = S / 'heuristic_20261016.json'
    a = json.loads(p.read_text())
    assert not a.get('active_processes') and not a.get('current_formal_active')
    a['active_processes'] = [{'pid': proc.pid, 'kind': 'P37_RECOVERED_P35_map_worker', 'map': name} for name, proc in processes.items()]
    a['current_formal_active'] = {'phase': F.name, 'label': item['label'], 'coordinator_pid': os.getpid(), 'new_blue': BLUE['opponent_id']}
    save(p, a)


def activity_off():
    p = S / 'heuristic_20261016.json'
    a = json.loads(p.read_text())
    own = a.get('current_formal_active')
    assert isinstance(own, dict) and own.get('coordinator_pid') == os.getpid()
    a.update(active_processes=[], current_formal_active=None)
    save(p, a)


def summarize():
    groups = {v: [x for x in STATE['completed'] if x['version'] == v] for v in NAMES}
    common = min(map(len, groups.values()))
    report = {'utc': utc(), 'status': STATE['status'], 'opponent': BLUE['opponent_id'], 'opponent_zip_sha256': BLUE['uploaded_zip_sha256'], 'completed_cohorts': len(STATE['completed']), 'completed_red_blue_pairs': len(STATE['completed']) * 5, 'completed_native_rounds': len(STATE['completed']) * 10, 'common_cohorts_for_ranking': common, 'versions': {}, 'provisional_until_first_windows_archive_review': True, 'descriptive_only': D['history_delta'], 'native_failure': STATE['first_native_failure']}
    for v in NAMES:
        xs = groups[v]
        primary = xs[:common]
        observed = statistics.mean(x['mean'] for x in xs) if xs else None
        primary_mean = statistics.mean(x['mean'] for x in primary) if primary else None
        old = D['old_blue_reference'][v]
        report['versions'][v] = {'completed_cohorts': len(xs), 'cohort_means': [x['mean'] for x in xs], 'all_observed_mean': observed, 'common_cohort_mean_for_ranking': primary_mean, 'old_blue_fixed_reference': old, 'observed_new_minus_old': None if observed is None else observed - old['mean'], 'common_maps': {name: statistics.mean(x['map_scores'][name] for x in primary) for name in D['maps']} if primary else {}, 'source': D['versions'][v]['source'], 'original_zip_sha256': D['versions'][v]['original_zip_sha256']}
    rank = sorted(NAMES, key=lambda v: (-report['versions'][v]['common_cohort_mean_for_ranking'], NAMES.index(v))) if common else list(NAMES)
    report['ranking'] = rank
    report['ranking_available'] = common > 0
    save(F / 'RESULT.json', report)
    save(F / 'RETAINED_TOP3.json', {'utc': utc(), 'status': 'PROVISIONAL_SERVER_RESULTS_AWAIT_WINDOWS_REVIEW' if common else 'INITIAL_SELECTION_PENDING_NEW_BLUE_RESULTS', 'opponent': BLUE['opponent_id'], 'common_cohorts_for_ranking': common, 'retained': [{'rank': i + 1, 'version': v, **report['versions'][v]} for i, v in enumerate(rank)], 'only_performance_metric': 'Mean full RED score across the same common number of original five-map cohorts; ties retain selection order.', 'other_candidates': 'Experience TXT only for active maintenance; immutable historical evidence preserved, no deletion.', 'official_submission_recommendation': 'Unchanged; this task does not release or upload a package.'})
    lines = ['新蓝队前三版本离线测试结果（服务器暂存，待首次Windows归档校验）', '蓝队：team006_preliminary / LBBDRescue', '状态：' + STATE['status'], '完成五图组数：' + str(len(STATE['completed'])), '排名统一采用各版本共同完成的组数：' + str(common), '']
    for i, v in enumerate(rank):
        x = report['versions'][v]
        lines += [f'{i + 1}. {v}：组数{x["completed_cohorts"]}；各组{x["cohort_means"]}；所有已完成组均分{x["all_observed_mean"]}；统一组数排名均分{x["common_cohort_mean_for_ranking"]}。', f'旧蓝队固定参考均分{x["old_blue_fixed_reference"]["mean"]}，观察分差{x["observed_new_minus_old"]}。']
    lines += ['', '新旧对手测试并非相同布局、随机数或服务器负载，不可把观察分差解释为纯蓝队效应或稳定提升。', '低于80不追加B组；所有版本的A组都安排，真实失败则停止后续，保留失败、不重跑。', '此次只维护K01/PJ01/V010三个算法版本。未做官网上传；旧资料未删除。', '原始NPZ/pickle只作字节流归档与SHA，未反序列化。']
    (F / '测试汇总.txt').write_text('\n'.join(lines) + '\n')


def run_cohort(item):
    lock = acquire_when_ready()
    if lock is None: return False
    try:
        validate_frozen()
        v, c = item['version'], item['cohort']
        G = F / (v + '_' + c)
        assert not G.exists(), 'Consumed cohort cannot be repeated'
        G.mkdir()
        result = R / 'results/target90_20261012' / ('unseeded_' + item['label'])
        assert not result.exists(), 'Consumed label cannot be repeated'
        W = R / 'experiments/target90_20261012/official_workspaces' / item['label']
        assert not W.exists()
        shutil.copytree(WBLUE, W, ignore=shutil.ignore_patterns('solutions', '__pycache__', '*.pyc', '.git', '.pytest_cache'))
        sol = W / 'src/swarm_rescue/solutions'
        sol.mkdir()
        for p in Path(D['versions'][v]['source']).iterdir(): shutil.copy2(p, W / 'req.txt' if p.name == 'req.txt' else sol / p.name)
        assert all(sha(W / n) == h for n, h in D['sdk_files'].items())
        expected = D['versions'][v]['source_files']
        assert {p.name: sha(p) for p in sol.iterdir()} == {n: h for n, h in expected.items() if n != 'req.txt'}
        result.mkdir()
        save(G / 'GAME_PREDECLARATION.json', {**item, 'utc': utc(), 'maps': D['maps'], 'rounds_each': 1, 'external_seed': None, 'red_workspace': str(W), 'red_source_files': expected, 'blue': BLUE, 'source': 'Fresh original RED then real new BLUE; no retries, no clock or game changes', 'study_sha256': sha(F / 'PREDECLARATION.json')})
        processes, logs = {}, []
        for name in D['maps']:
            log = (result / (name + '_worker.log')).open('x')
            logs.append(log)
            command = [str(R / '.venv/bin/python'), '-u', BLUE['worker'], '--label', item['label'], '--red-workspace', str(W), '--worker', name]
            processes[name] = subprocess.Popen(command, cwd=R, env=ENV, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        activity_on(item, processes)
        save(G / 'LAUNCH.json', {'utc': utc(), 'workspace': str(W), 'result': str(result), 'worker_pids': {n: p.pid for n, p in processes.items()}, 'worker_sha256': BLUE['worker_sha256']})
        state('RUNNING_FIVE_MAPS', current=item, workers={n: p.pid for n, p in processes.items()})
        print(json.dumps({'started': item, 'pids': {n: p.pid for n, p in processes.items()}}), flush=True)
        started = time.monotonic()
        jobs = {}
        while any(p.poll() is None for p in processes.values()):
            jobs = {n: json.loads((result / (n + '_job.json')).read_text()) if (result / (n + '_job.json')).exists() else {'status': 'starting'} for n in D['maps']}
            state('RUNNING_FIVE_MAPS', current=item, map_status={n: j['status'] for n, j in jobs.items()})
            if time.monotonic() - started > 1800:
                # A hang beyond native limits is an error, never a new score.
                save(G / 'EXTERNAL_HANG_WATCHDOG.json', {'utc': utc(), 'seconds': time.monotonic() - started, 'error': 'Worker exceeded external 1800s envelope, no retry; coordinator remains awaiting native termination, no additional groups.'})
                STATE['first_native_failure'] = True
            time.sleep(2)
        for p in processes.values(): p.wait()
        for log in logs: log.close()
        activity_off()
        jobs = {n: json.loads((result / (n + '_job.json')).read_text()) if (result / (n + '_job.json')).exists() else {'status': 'missing_result'} for n in D['maps']}
        valid = all(p.returncode == 0 for p in processes.values()) and all(j.get('status') == 'complete' and len(j.get('rounds', [])) == 1 for j in jobs.values()) and not STATE['first_native_failure']
        validate_frozen()
        assert {p.name: sha(p) for p in sol.iterdir() if p.is_file()} == {n: h for n, h in expected.items() if n != 'req.txt'}
        assert all(sha(W / n) == h for n, h in D['sdk_files'].items())
        scores = {}
        if valid:
            for n, j in jobs.items():
                blue = json.loads((result / (n + '_blue_rd1') / 'summary.json').read_text())
                red = json.loads((result / (n + '_red') / 'summary.json').read_text())
                assert blue['controller'] == BLUE['blue_controller'] and blue['controller_sha256'] == BLUE_CONTROLLER_SHA
                assert blue['seed'] is None and red['seed'] is None
                assert blue['competition_mode'] and red['competition_mode']
                assert not blue['framework_runtime_patched'] and not red['framework_runtime_patched']
                assert not blue['rounds'][0]['crashed'] and not red['rounds'][0]['crashed']
                score = j['rounds'][0]['full_score']
                assert math.isfinite(score) and 0 <= score <= 100
                scores[n] = score
        matrix = {'utc': utc(), 'complete': valid, 'label': item['label'], 'version': v, 'cohort': c, 'seed': None, 'jobs': jobs, 'blue_opponent': BLUE['opponent_id'], 'source_hashes': {'red': expected, 'blue_zip': BLUE['uploaded_zip_sha256']}, 'payload_unchanged': True, 'raw_arrays_loaded': 0}
        save(result / 'matrix_status.json', matrix)
        save(G / 'RESULT.json', matrix)
        raw = {str(p.relative_to(result)): {'sha256': sha(p), 'bytes': p.stat().st_size} for p in sorted(result.rglob('*')) if p.is_file()}
        save(G / 'RAW_SHA256.json', raw)
        archive = G / 'raw_results.tar.gz'
        with tarfile.open(archive, 'x:gz', compresslevel=1) as tar:
            for n in raw: tar.add(result / n, arcname=n, recursive=False)
        receipt = {'utc': utc(), 'archive': str(archive), 'sha256': sha(archive), 'manifest_sha256': sha(G / 'RAW_SHA256.json'), 'files': len(raw), 'first_windows_review_pending': True, 'raw_arrays_loaded': 0}
        save(G / 'RAW_ARCHIVE_RECEIPT.json', receipt)
        if not valid:
            STATE['first_native_failure'] = True
            save(F / 'FIRST_NATIVE_ERROR.json', {'utc': utc(), 'cohort': item, 'statuses': {n: j.get('status') for n, j in jobs.items()}, 'worker_returncodes': {n: p.returncode for n, p in processes.items()}, 'no_retry': True, 'current_others_finished_original_clocks': True})
            raise RuntimeError('First actual evaluation failure; remaining cohorts cancelled')
        outcome = {**item, 'mean': statistics.mean(scores.values()), 'map_scores': scores, 'raw_archive': receipt, 'placed': {n: j['rounds'][0]['placed'] for n, j in jobs.items()}}
        STATE['completed'].append(outcome)
        state('COHORT_COMPLETE', current=None)
        summarize()
        print(json.dumps({'completed': item, 'mean': outcome['mean'], 'files': len(raw)}), flush=True)
        return True
    finally:
        lock.close()


def main():
    lease = (F / 'coordinator.lock').open('a+')
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not (F / 'RUN_ONCE.json').exists(), 'This finite schedule was already launched; no automatic replay'
    STATE['started_utc'] = utc()
    save(F / 'RUN_ONCE.json', {'utc': utc(), 'pid': os.getpid(), 'starttime_ticks': Path('/proc/self/stat').read_text().split()[21], 'driver_sha256': sha(__file__), 'study_sha256': sha(F / 'PREDECLARATION.json')})
    validate_frozen()
    summarize()
    try:
        for item in D['schedule']:
            if stop_requested():
                state('STOPPED_BEFORE_NEXT_COHORT')
                break
            if item['cohort'] == 'B':
                first = next(x for x in STATE['completed'] if x['version'] == item['version'] and x['cohort'] == 'A')
                if first['mean'] < 80:
                    STATE['skipped'].append({**item, 'reason': 'A five-map mean below frozen80 floor', 'A_mean': first['mean']})
                    state('SKIPPED_LOW_SCORE_REPEAT')
                    continue
            if not run_cohort(item):
                state('STOPPED_BEFORE_NEXT_COHORT')
                break
        else:
            state('COMPLETE_FINITE_TOP3_SCHEDULE')
        summarize()
    except Exception:
        error = {'utc': utc(), 'traceback': traceback.format_exc(), 'first_native_failure': STATE['first_native_failure'], 'no_retry': True, 'no_later_cohorts': True}
        save(F / 'FIRST_ERROR.json', error)
        state('STOPPED_FIRST_ERROR_NO_RETRY')
        summarize()
        raise



# Recovery orchestration only. run_cohort/evaluator/worker science is unchanged.
def summarize():
    baseline=json.loads(Path(D['preserved_baseline']['result']).read_text())
    br=[r for j in baseline['jobs'].values() for r in j['rounds']]
    assert len(br)==5 and baseline['complete']
    bm=statistics.mean(r['full_score'] for r in br)
    candidate=STATE['completed'][0]['mean'] if STATE['completed'] else None
    report={**STATE,'preserved_baseline_mean':bm,'preserved_baseline_placed':sum(r['placed']for r in br),
      'candidate_mean':candidate,'observed_delta':None if candidate is None else candidate-bm,
      'PJ01_control_cohort_rerun':False,'maximum_new_native_rounds':10,
      'automatic_promotion':False,'official_submission_ready':False,
      'environment_reconstruction_caveat':D['environment_reconstruction_caveat'],
      'first_windows_review_required':True}
    save(F/'RESULT.json',report)

def resumed_main():
    lease=(F/'coordinator.lock').open('a+')
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not(F/'RUN_ONCE.json').exists(),'Recovery schedule consumed; no replay'
    assert D['schedule']==[dict(version='P35',cohort='A',label='sdk_e2f022b_p37_P35_A')]
    assert not Path('/proc/2534852').exists()
    for p,h in D['preserved_baseline']['files'].items():assert sha(p)==h
    STATE.update(started_utc=utc(),decisions=[{'decision':'P35_A_ONLY_RESUME','reason':'Completed PJ01_A retained; original both-A50 condition already fails so no B groups'}])
    save(F/'RUN_ONCE.json',dict(utc=utc(),pid=os.getpid(),starttime_ticks=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],driver_sha256=sha(__file__),study_sha256=sha(F/'PREDECLARATION.json'),PJ01_rerun=False))
    try:
      validate_frozen();summarize()
      if run_cohort(D['schedule'][0]):
        state('AWAIT_FIRST_WINDOWS_REVIEW',current=None)
        started=time.monotonic();review=F/'P35_A/CLIENT_FIRST_RAW_REVIEW.json'
        while not review.exists():
          if stop_requested():raise RuntimeError('User stop before first Windows review')
          if time.monotonic()-started>7200:raise TimeoutError('First Windows review expired; no rerun')
          time.sleep(10)
        proof=json.loads(review.read_text());receipt=json.loads((F/'P35_A/RAW_ARCHIVE_RECEIPT.json').read_text())
        assert proof['status']=='PASS' and proof['archive_sha256']==receipt['sha256']
        state('COMPLETE_FINITE_STAGED_CAMPAIGN',current=None)
      else:state('STOPPED_BEFORE_NEXT_COHORT',current=None)
      summarize()
    except Exception:
      save(F/'FIRST_ERROR.json',dict(utc=utc(),traceback=traceback.format_exc(),first_native_failure=STATE['first_native_failure'],no_retry=True,PJ01_rerun=False))
      state('STOPPED_FIRST_ERROR_NO_RETRY');summarize();raise

if __name__=='__main__':resumed_main()
