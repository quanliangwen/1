from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,tarfile,zipfile
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'P41_environment_restore_20261101'
D=json.loads((H/'P37_phase_five_comparison_20261101/PREDECLARATION.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (R/'.venv').exists();assert not Path('/proc/2534852').exists()
base=H/'F32_official_sdk_20261028/updated_sdk_base';assert not base.exists();base.mkdir()
with tarfile.open(F/'frozen_sdk.tar.gz','r:gz')as t:
 for m in t:
  p=(base/m.name).resolve();assert m.isfile()and str(p).startswith(str(base.resolve())+'/')
  p.parent.mkdir(parents=True,exist_ok=True)
  with t.extractfile(m)as src:p.write_bytes(src.read())
assert all(sha(base/n)==h for n,h in D['sdk_files'].items())
pj=Path(D['versions']['PJ01']['source']);assert all(sha(pj/n)==h for n,h in D['versions']['PJ01']['source_files'].items())
canonical=R/'swarm-eod';assert not canonical.exists();shutil.copytree(base,canonical)
sol=canonical/'src/swarm_rescue/solutions';sol.mkdir()
for p in pj.iterdir():
 if p.is_file():shutil.copy2(p,canonical/'req.txt'if p.name=='req.txt'else sol/p.name)
blue=Path(D['blue_binding']['blue_workspace']);assert not blue.exists();shutil.copytree(base,blue);bs=blue/'src/swarm_rescue/solutions';bs.mkdir()
archive=F/'blue_team006_original.zip';assert sha(archive)==D['blue_binding']['uploaded_zip_sha256']
with zipfile.ZipFile(archive)as z:
 for n in z.namelist():
  assert '/'not in n and '\\'not in n
  (blue/'req.txt'if n=='req.txt'else bs/n).write_bytes(z.read(n))
assert all(sha(blue/n)==h for n,h in D['sdk_files'].items())
py=list((R/'runtimes/python').glob('*/bin/python3.11'));assert len(py)==1
subprocess.run([str(py[0]),'-m','venv',str(R/'.venv')],check=True)
pins='numpy==1.26.4\nopencv-contrib-python==4.11.0.86\npandas==3.0.6\nscipy==1.17.1\nelkai==2.0.1\narcade==2.6.17\npyglet==2.0.dev23\npymunk==6.4.0\nPillow==9.3.0\n'
(F/'constraints-recovery.txt').write_text(pins)
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='SOURCE_AND_CLEAN_VENV_CREATED_PENDING_INSTALL',SDK_files_verified=len(D['sdk_files']),sdk_commit=D['sdk_commit'],python_base=str(py[0]),python_version=subprocess.check_output([str(py[0]),'--version'],text=True).strip(),SDK_base=str(base),canonical_PJ01=str(canonical),blue_workspace=str(blue),blue_zip_sha256=sha(archive),blue_controller_sha256=sha(bs/'lbbd_rescue.py'),pins=pins,scope='Restore only. No original scientific files edited and no native game.')
(F/'SOURCE_RESTORE_FIRST.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
env=os.environ.copy();env.pop('PYTHONPATH',None);env['PYTHONNOUSERSITE']='1';env['PIP_DISABLE_PIP_VERSION_CHECK']='1'
with(F/'DEPENDENCY_INSTALL_FIRST.log').open('w')as log:
 r=subprocess.run([str(R/'.venv/bin/python'),'-m','pip','install','--report',str(F/'dependency_install_report.json'),'-c',str(F/'constraints-recovery.txt'),'-e',str(canonical),'scipy==1.17.1','elkai==2.0.1'],env=env,stdout=log,stderr=subprocess.STDOUT)
print(json.dumps(dict(install_returncode=r.returncode,log=str(F/'DEPENDENCY_INSTALL_FIRST.log'))),flush=True)
assert r.returncode==0,'Preserve first dependency install failure; no overlay workaround.'
