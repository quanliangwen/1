from public_visual_export_v2 import capture_initial_layout, export_after_round
"""External evaluator for supplied maps; never patches a framework module/class.

Use official GuiSR, team setup, bomb I/O and score managers unchanged. Truth is
read only AFTER the simulator finishes and only in this external evaluator.
This is explicitly a direct evaluator, not an official Launcher execution.
"""
import argparse,dataclasses,gc,hashlib,importlib,json,pickle,random,sys,time,traceback
from pathlib import Path
from types import SimpleNamespace

p=argparse.ArgumentParser()
p.add_argument('--workspace',required=True);p.add_argument('--map',required=True)
p.add_argument('--mode',choices=['place','rescue'],required=True)
p.add_argument('--out',required=True)
p.add_argument('--bombs');p.add_argument('--zones',default='');p.add_argument('--rounds',type=int,default=1)
a=p.parse_args();work=Path(a.workspace).resolve();out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(work/'src'))
import numpy as np
from swarm_rescue.launcher import Launcher
from swarm_rescue.simulation.gui_map.gui_sr import GuiSR
from swarm_rescue.simulation.reporting.evaluation import EvalConfig
from swarm_rescue.simulation.elements.sensor_disablers import ZoneType
from swarm_rescue.simulation.reporting.team_mode import TeamMode
from swarm_rescue.simulation.reporting.score_manager import ScoreManager
from swarm_rescue.simulation.reporting.place_score_manager import PlaceScoreManager,walls_and_boundary_grid,difficulty_from_blue_score
from swarm_rescue.simulation.reporting.bombs_io import save_placed_bombs,save_exploration_map
from swarm_rescue.solutions.my_drone_eval import drone_class_for_mode
module='map_'+a.map[3:] if a.map in ['Map01','Map02','Map03','Map04','Map05'] else 'map_rescue_case_'+a.map.removeprefix('MapRescueCase')
assert a.map in ['Map01','Map02','Map03','Map04','Map05'] or (a.map.startswith('MapRescueCase') and a.map[-3:].isdigit() and 1<=int(a.map[-3:])<=30)
map_module=importlib.import_module('swarm_rescue.maps.'+module)
map_class=getattr(map_module,a.map)
drone_class=drone_class_for_mode(a.mode)
controller_module=importlib.import_module(drone_class.__module__)
assert Path(controller_module.__file__).resolve().is_relative_to(work)
mode=TeamMode.from_string(a.mode)
zones=tuple(ZoneType[z] for z in a.zones.split(',') if z)
ec=EvalConfig(map_name=a.map,zones_config=zones,number_drones=5 if a.mode=='place' else 10,initial_bombs_per_drone=2,nb_rounds=a.rounds)
configuration=SimpleNamespace(_resolve_bombs_file=lambda config:a.bombs)
manager=PlaceScoreManager()
# Randomness is owned by the original runtime. No explicit seeding.
state={'map':a.map,'seed':None,'mode':a.mode,'evaluator':'direct official APIs; no Launcher registry modification',
 'competition_mode':True,'framework_runtime_patched':False,'official_launcher':False,
 'controller':drone_class.__module__+'.'+drone_class.__name__,
 'controller_sha256':hashlib.sha256(Path(controller_module.__file__).read_bytes()).hexdigest(),
 'map_source_sha256':hashlib.sha256(Path(map_module.__file__).read_bytes()).hexdigest(),'rounds':[]}
for index in range(1,a.rounds+1):
 gc.collect();started=time.monotonic()
 arena=map_class(drone_type=drone_class,zones_config=zones,number_drones=ec.number_drones)
 # Call the original method, with an external configuration context. No
 # replacement function, monkey-patch, custom sensor or physics is installed.
 Launcher._configure_map_for_team(configuration,arena,ec,mode)
 score_manager=ScoreManager(number_drones=arena.number_drones,max_timestep_limit=arena.max_timestep_limit,
  max_walltime_limit=arena.max_walltime_limit,total_number_bombs=arena.number_bombs)
 gui=GuiSR(the_map=arena,draw_interactive=False,filename_video_capture=None,
  filename_state_recording=(str(out/('round'+str(index)+'.npz')) if a.mode=='place' else None),manual_bomb_edit_enabled=False,
  manual_bombs_in_path=None,manual_bombs_out_path=None,headless=True,competition_mode=True)
 gui.set_state_recording_metadata({'team_mode':a.mode,'number_drones':arena.number_drones})
 arena.explored_map.reset()
 crashed=False;error=None
 initial_public_layout=capture_initial_layout(arena)
 try:gui.run()
 except Exception:
  crashed=True;error=traceback.format_exc();gui.close()
 trajectory=arena.explored_map.score()*100.
 health_returned=arena.compute_score_health_returned()*100.
 row={'round':index,'crashed':crashed,'error':error,'timestep':gui.elapsed_timestep,
  'timestep_limit':arena.max_timestep_limit,'walltime':gui.elapsed_walltime,'walltime_limit':arena.max_walltime_limit,
  'trajectory_score':trajectory,'health_returned':health_returned,'max_walltime_reached':gui.is_max_walltime_limit_reached}
 if a.mode=='place':
  wall_grid,boundary=walls_and_boundary_grid(arena.playground,truth_grid=arena.explored_map.truth_obstacle_grid())
  truth=wall_grid if wall_grid is not None else arena.explored_map.truth_obstacle_grid()
 else:Launcher._sync_rescue_bomb_total(gui,score_manager)
 arena.playground.cleanup()
 try:arena.playground.close_window()
 except Exception:pass
 if a.mode=='place':
  submitted=None
  for drone in arena.drones:
   submitted=getattr(drone,'_exploration_map_submission',None)
   if submitted is not None:break
  bomb_file=out/('round'+str(index)+'_bombs.json');save_placed_bombs(str(bomb_file),arena,ec)
  if submitted is not None:save_exploration_map(str(out/('round'+str(index)+'_exploration.npz')),submitted,elapsed_walltime=gui.elapsed_walltime)
  positions=[tuple(float(c) for c in b.true_position()) for b in (getattr(arena,'_bombs',None) or [])]
  expected=arena.number_drones*ec.initial_bombs_per_drone
  phase=manager.compute_phase1_score(truth,submitted,elapsed_walltime=gui.elapsed_walltime,
   max_walltime_limit=arena.max_walltime_limit,score_exploration_trajectory=trajectory,
   placed_count=arena.number_bombs,expected_count=expected,has_crashed=crashed,bomb_positions=positions,
   elapsed_timestep=gui.elapsed_timestep,max_timestep_limit=arena.max_timestep_limit,wall_grid=wall_grid,boundary_grid=boundary)
  row.update(phase=dataclasses.asdict(phase),placed=arena.number_bombs,expected=expected,bomb_file=str(bomb_file),
   inventory_remaining=sum(d.carried_bombs_count() for d in arena.drones))
  # A scoring-only snapshot permits reproducible checks without passing truth
  # to a controller or converting it into planner targets.
  np.savez_compressed(out/('round'+str(index)+'_scoring_only.npz'),truth=truth,wall_grid=wall_grid,boundary=boundary,
   submitted=np.zeros_like(truth) if submitted is None else submitted,positions=np.asarray(positions))
 else:
  score,disposed_percent,time_score=score_manager.compute_score(gui.disposed_number,trajectory,health_returned,gui.elapsed_timestep,crashed)
  row.update(blue_score=score,disposed=int(gui.disposed_number),expected=score_manager.total_number_bombs,
   difficulty=difficulty_from_blue_score(score),time_score=time_score)
 row['runtime_seconds']=time.monotonic()-started;state['rounds'].append(row)
 (out/'summary.json').write_text(json.dumps(state,indent=2)+'\n')
 print('DIRECT_ROUND',json.dumps(row),flush=True)
 if a.mode=='place' and not crashed:
  # These are controller-owned public-sensor/message memories, not map truth.
  # Export only after the original score and summary have been finalized.
  snapshots=[]
  for drone in arena.drones:
   memory=getattr(drone,'memory',None)
   if memory is None:continue
   snapshot={name:getattr(memory,name,None) for name in
    ('width','height','CELL','FINE','shape','hit_shape','identifier','team_size',
     'hits','free','visits','origin','step','frame_records','frame_negative','nonwall_mask')}
   snapshot['controller_diagnostics']={name:getattr(drone,name,None) for name in
    ('pose','heading','rally','goal','placement_goal','assignment_goal','assignment_inventory',
     'commitment_diagnostics','completion_certificates','fleet_states','inventory_records','drop_records')}
   snapshot['submitted']=getattr(drone,'_exploration_map_submission',None) is not None
   snapshot['inventory']=int(drone.carried_bombs_count())
   snapshots.append(snapshot)
  with (out/('round'+str(index)+'_public_memory_only.pkl')).open('wb') as handle:
   pickle.dump(snapshots,handle,protocol=4)
 if crashed:raise SystemExit(1)


 # Public rendering export is after native score/summary and controller loop.
 export_after_round(arena,gui,initial_public_layout,a.mode,out,index,submitted if a.mode=='place' else None)
