from pathlib import Path
import datetime,fcntl,hashlib,json,os,shutil,subprocess
R=Path('/home/junhao/quan/parallel_test_solver/match');S=R/'solver_study';H=S/'framework_screen_20261016/best87_independent_20261025';F=H/'P41_environment_restore_20261101';N=F/'P35_continuation';P=H/'P37_phase_five_comparison_20261101'
assert not(N/'PREDECLARATION.json').exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text());utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
lock=(S/'serial_evaluation.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
old=read(P/'PREDECLARATION.json');oldstatus=read(P/'STATUS.json');original_run=read(P/'RUN_ONCE.json')
assert [x['version']for x in oldstatus['completed']]==['PJ01']and not oldstatus.get('current')
assert not(P/'P35_A').exists()and not Path('/proc/2534852').exists()
assert not(R/'results/target90_20261012/unseeded_sdk_e2f022b_p37_P35_A').exists()
assert not(R/'experiments/target90_20261012/official_workspaces/sdk_e2f022b_p37_P35_A').exists()
assert all(sha(n)==h for n,h in old['frozen_files'].items()),'All original25 frozen references must be recovered, no silent weakening'
for n in ['RUNTIME_ABI_AND_SDK_FIRST.json','STARTUP_PJ01_V2_FIXTURE_FIXED.json','STARTUP_P35_V2_FIXTURE_FIXED.json','STARTUP_BLUE_V2_FIXTURE_FIXED.json']:
 assert read(F/n)['status'].startswith('PASS')
# Read process truth, not the erased registry. Other projects are untouched.
related=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit()or int(p.name)==os.getpid():continue
 try:
  cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
  if str(R)+'/'in cmd and any(s in cmd for s in ['run_offline.py','--worker','postscore_visual_evaluator_v2.py','unseeded_direct_v1.py','probe_controller_smoke']):related.append(dict(pid=int(p.name),cmd=cmd))
 except(FileNotFoundError,PermissionError,ProcessLookupError):pass
assert not related,related
origblue=read(F/'ORIGINAL_BLUE_STAGING.json');W=Path(old['blue_binding']['blue_workspace'])
stage=dict(origblue);stage.update(utc=utc(),status='RECOVERED_AND_REQUALIFIED',blue_workspace=str(W),sdk_original_hashes=old['sdk_files'],sdk_files_unchanged_count=len(old['sdk_files']),sdk_commit=old['sdk_commit'],recovered_from_retained_original_wheel=True,qualification_scope='Fresh original SDK eight-update startup only, not official container or score')
sp=F/'BLUE_STAGING_RECOVERED.json';sp.write_text(json.dumps(stage,ensure_ascii=False,indent=2)+'\n')
ob=old['blue_binding'];blue={k:ob[k]for k in ['opponent_id','uploaded_zip_sha256','blue_workspace','blue_controller','team_number','worker','worker_sha256','evaluator','evaluator_sha256','sdk_commit']}
blue.update(utc=utc(),status='ACTIVE',staging_manifest=str(sp),staging_manifest_sha256=sha(sp),qualification_receipt=str(F/'STARTUP_BLUE_V2_FIXTURE_FIXED.json'),qualification_receipt_sha256=sha(F/'STARTUP_BLUE_V2_FIXTURE_FIXED.json'),environment_rebuilt=True,original_binding_preserved_in=str(P/'PREDECLARATION.json'))
active=S/'ACTIVE_BLUE_OPPONENT.json';assert not active.exists();active.write_text(json.dumps(blue,ensure_ascii=False,indent=2)+'\n')
registry=S/'heuristic_20261016.json'
assert not registry.exists();registry.write_text(json.dumps(dict(heuristic_id='heuristic_20261015T2047Z',active_processes=[],current_formal_active=None,recovered_utc=utc(),recovery_note='Original registry absent after environment deletion; proc checked, preserve known PJ01_A completed; only scheduled untouched P35_A authorized',completed_preserved_labels=['sdk_e2f022b_p37_PJ01_A'],allowed_continuation_label='sdk_e2f022b_p37_P35_A'),indent=2)+'\n')
baseline_files=read(N/'CONTINUATION_SOURCE_BINDING.json')['preserved_baseline_files']
assert all(sha(p)==h for p,h in baseline_files.items());baseline=read(P/'PJ01_A/RESULT.json');assert baseline['complete']and read(P/'PJ01_A/CLIENT_FIRST_RAW_REVIEW.json')['status']=='PASS'
br=[r for j in baseline['jobs'].values()for r in j['rounds']];assert len(br)==5 and sum(r['placed']for r in br)==48
d=dict(old);d.update(phase='P37_P35_A_RECOVERED_CONTINUATION_20261101',authorization='2026-11-01 explicit user: recreate deleted test environment, verify SDK and PJ01 startup, continue P35 five, never rerun completed PJ01 control',selection=['P35'],versions={'P35':old['versions']['P35']},blue_binding=blue,blue_binding_sha256=sha(active),
 schedule=[dict(version='P35',cohort='A',label='sdk_e2f022b_p37_P35_A')],max_cohorts=1,max_native_rounds=10,PJ01_rerun=False,
 preserved_baseline=dict(result=str(P/'PJ01_A/RESULT.json'),files=baseline_files,mean=sum(r['full_score']for r in br)/5,placed=48,first_review_already_passed=True),
 old_blue_reference={'P35':dict(mean=sum(r['full_score']for r in br)/5,source=str(P/'PJ01_A/RESULT.json'))},
 history_delta='Original planned A comparison continues after deleted environment restoration; no new PJ01 control. Exact SDK/controller/evaluator/thread hashes retained, but rebuilt environment/host/random conditions can influence differences.',
 environment_reconstruction_caveat='Python3.11.17/NumPy1.26.4/Pandas3.0.6/OpenCV4.11.0.86/SciPy1.17.1/Arcade2.6.17/Pymunk6.4.0 and frozen SDK124+native evaluator/worker/wrapper25 hashes restored. CPython build and auxiliary dependency wheels may differ because no complete old environment lock survived. Fresh full freeze and ABI/startup receipts recorded. Do not claim byte-identical environment or causal stable superiority.',
 original_predeclaration_sha256=sha(P/'PREDECLARATION.json'),original_coordinator_run_once=original_run,original_schedule_B_skipped='Original criterion requires both A50/50; preserved baseline48/50 fails, no B')
d['frozen_files']={**old['frozen_files'],**{str(F/n):sha(F/n)for n in ['constraints-recovery.txt','pip_freeze_recovered.txt','RUNTIME_ABI_AND_SDK_FIRST.json','STARTUP_PJ01_V2_FIXTURE_FIXED.json','STARTUP_P35_V2_FIXTURE_FIXED.json','STARTUP_BLUE_V2_FIXTURE_FIXED.json']},str(N/'run_offline.py'):sha(N/'run_offline.py')}
(N/'PREDECLARATION.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
q=N/'versions/P35';q.mkdir(parents=True);(q/'QUALIFICATION.json').write_text(json.dumps(read(F/'STARTUP_P35_V2_FIXTURE_FIXED.json'),indent=2)+'\n')
notice=dict(utc=utc(),status='RESUMED_BY_SEPARATE_CONTINUATION_PENDING_RESOURCE_GATE',new_stage=str(N),only_version='P35',only_cohort='A',only_label='sdk_e2f022b_p37_P35_A',PJ01_preserved_no_rerun=True,old_status_retained=True)
(P/'RECOVERY_CONTINUATION.json').write_text(json.dumps(notice,indent=2)+'\n')
print(json.dumps(dict(status='DECLARED_RECOVERED_P35_ONLY_NO_GAME_STARTED',stage=str(N),frozen_original25_verified=True,maximum_new_native=10,preserved_PJ01=48,resource_gate=d['resource_gate'])),flush=True)
