"""External five-map orchestration. No framework/controller monkey-patching.

Five independent map workers run concurrently. Each worker runs one native
red session (exactly one native round for EVERY map, including Map01), then
one real LBBDRescue session per layout.
A batch lock prevents duplicate batches, not concurrency between its five maps.
"""
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

ROOT = Path('/home/junhao/quan/parallel_test_solver/match')
STUDY = ROOT / 'solver_study'
BASE = ROOT / 'experiments/target90_20261012'
MAPS = ('Map01', 'Map02', 'Map03', 'Map04', 'Map05')
BLUE_SHA = 'a063241f70ac890696108abb82647db534d58a4dab73f393151bfefa1603cdb8'
EVALUATOR = Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/unseeded_direct_v1.py')


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(path, data):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def hashes(work):
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((work / 'src/swarm_rescue/solutions').iterdir()) if p.is_file()}


def gate(jobs):
    details = {}
    for name in MAPS:
        job = jobs.get(name, {})
        rows = job.get('rounds', [])
        complete = job.get('status') == 'complete' and len(rows) == 1
        scores = [r['full_score'] for r in rows if 'full_score' in r]
        details[name] = {'status': job.get('status', 'not_started'),
                         'mean': sum(scores)/len(scores) if complete else None,
                         'minimum_round': min(scores) if scores else None,
                         'completed_rounds': len(scores)}
    return {'maps': details, 'accepted': all(d['mean'] is not None and d['mean'] >= 95 for d in details.values()),
            'scope': 'Five independent unseeded maps, exactly one native red round and one actual BLUE per map. This differs from the old Map01 two-round cohort; all five scores >=95 gates only fifty-map expansion.'}


def promotion_decision(candidate, incumbent):
    """Selection only. Partial/mismatched cohorts never replace a champion."""
    if not candidate.get('accepted'):
        return False
    if incumbent is None:
        return True
    if set(candidate['maps']) != set(incumbent['maps']):
        return False
    if any(incumbent['maps'][m].get('mean') is None for m in MAPS):
        return False
    delta = [candidate['maps'][m]['mean'] - incumbent['maps'][m]['mean'] for m in MAPS]
    return min(delta) >= 0 and sum(delta) > 0


def worker(work, result, name):
    bluework = Path('/home/junhao/quan/parallel_test_solver/match/experiments/target90_20261012/official_workspaces/blue_team006_sdk_e2f022b_20261028')
    sys.path.insert(0, str(work / 'src'))
    from swarm_rescue.simulation.reporting.place_score_manager import PlaceScoreManager, PlacePhase1Result, ReferenceBlueRun
    manager = PlaceScoreManager()
    job = {'map': name, 'seed': None, 'randomness': 'No seed set or passed',
           'status': 'red_running', 'rounds': [], 'worker_pid': os.getpid(), 'started_utc': utc()}
    state = result / (name + '_job.json')
    write(state, job)
    def run(mode, workspace, out, rounds=1, bombs=None):
        out.mkdir(exist_ok=False)
        command = ['bash', str(ROOT/'run_server.sh'), '-u', str(EVALUATOR),
                   '--workspace', str(workspace), '--map', name, '--mode', mode,
                   '--out', str(out), '--rounds', str(rounds)]
        if bombs:
            command += ['--bombs', bombs]
        if name == 'Map05':
            command += ['--zones', 'NO_GPS_ZONE,NO_COM_ZONE']
        with (out/'console.log').open('w') as log:
            process = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
            job['active_child_pid'] = process.pid
            write(state, job)
            code = process.wait()
        summary = out/'summary.json'
        return code, json.loads(summary.read_text()) if summary.exists() else None
    try:
        code, red = run('place', work, result/(name+'_red'), 1)
        if code or not red or any(r['crashed'] for r in red['rounds']):
            job.update(status='red_failed', returncode=code)
            return
        assert red['seed'] is None and red['competition_mode'] and not red['framework_runtime_patched']
        job['red_summary'] = str(result/(name+'_red')/'summary.json')
        job['status'] = 'blue_running'
        write(state, job)
        for row in red['rounds']:
            code, blue = run('rescue', bluework, result/(name+'_blue_rd'+str(row['round'])), bombs=row['bomb_file'])
            if code or not blue or blue['controller_sha256'] != BLUE_SHA or blue['rounds'][0]['crashed']:
                job.update(status='blue_failed', returncode=code)
                return
            assert blue['seed'] is None and blue['competition_mode'] and not blue['framework_runtime_patched']
            b = blue['rounds'][0]
            ref = ReferenceBlueRun(zip_name='team006_preliminary_5dbf10fc13c5', blue_score=b['blue_score'],
                                   difficulty=b['difficulty'], has_crashed=False, success=True)
            bomb = manager.compute_bomb_score([ref], placed_count=row['placed'], expected_count=row['expected'])
            merged = manager.merge_final_score(PlacePhase1Result(**row['phase']), bomb)
            job['rounds'].append({'round': row['round'], 'phase': row['phase'], 'blue': {**b, 'controller_sha256': BLUE_SHA},
                                  'placed': row['placed'], 'expected': row['expected'],
                                  'full_score': merged.round_score, 'layout_contribution': manager.config.w_bomb*bomb.score,
                                  'red_walltime': row['walltime'], 'red_walltime_limit': row['walltime_limit'],
                                  'red_steps': row['timestep'], 'red_max_walltime_reached': row['max_walltime_reached']})
            write(state, job)
        job['status'] = 'complete'
    except Exception as exc:
        job.update(status='orchestrator_failed', error=repr(exc))
        raise
    finally:
        job.update(finished_utc=utc(), active_child_pid=None)
        write(state, job)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--label', required=True)
    parser.add_argument('--red-workspace', required=True)
    parser.add_argument('--worker', choices=MAPS)
    parser.add_argument('--foreground', action='store_true')
    args = parser.parse_args()
    assert not args.foreground, 'Detached continuation requires the inherited batch-lock descriptor.'
    assert re.fullmatch(r'[A-Za-z0-9_]+', args.label)
    work = Path(args.red_workspace).resolve()
    assert work.is_relative_to(BASE/'official_workspaces') and work.is_dir()
    assert 'MATCH_PHASE_ID' not in os.environ
    assert os.environ.get('MATCH_HEURISTIC_ID') == 'heuristic_20261015T2047Z'
    result = ROOT/'results/target90_20261012'/('unseeded_'+args.label)
    if args.worker:
        worker(work, result, args.worker)
        return
    lock = (STUDY/'serial_evaluation.lock').open('a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not result.exists(), 'This label was already consumed; do not repeat a map session.'
    redhash = hashes(work)
    payload_id = hashlib.sha256(json.dumps(redhash, sort_keys=True).encode()).hexdigest()
    registry_path = STUDY/'unseeded_five_team006_once_registry.json'
    registry = json.loads(registry_path.read_text()) if registry_path.exists() else {}
    assert payload_id not in registry, 'Identical payload already tested; relabeling does not authorize a repeat.'
    result.mkdir()
    registry[payload_id] = {'label': args.label, 'reserved_utc': utc(), 'maps': list(MAPS), 'status': 'consumed'}
    write(registry_path, registry)
    if not args.foreground:
        command = [sys.executable, '-u', str(Path(__file__).resolve()), '--label', args.label,
                   '--red-workspace', str(work), '--foreground']
        # The detached parent owns the lock. A private descriptor distinguishes
        # this continuation from a second public launch, without re-reservation.
        with (result/'batch.log').open('w') as log:
            env = {**os.environ, 'MATCH_FIVE_BATCH_FD': str(lock.fileno()), 'MATCH_FIVE_PAYLOAD_ID': payload_id}
            process = subprocess.Popen(command, cwd=ROOT, stdin=subprocess.DEVNULL, stdout=log,
                                       stderr=subprocess.STDOUT, start_new_session=True,
                                       pass_fds=(lock.fileno(),), env=env)
        print(json.dumps({'batch_pid': process.pid, 'result': str(result), 'parallel_maps': 5, 'seed': None}))
        return


def continue_batch():
    """Detached execution after the single, locked reservation."""
    parser = argparse.ArgumentParser()
    parser.add_argument('--label', required=True)
    parser.add_argument('--red-workspace', required=True)
    parser.add_argument('--foreground', action='store_true')
    args = parser.parse_args()
    lock = os.fdopen(int(os.environ['MATCH_FIVE_BATCH_FD']), 'a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    work = Path(args.red_workspace)
    result = ROOT/'results/target90_20261012'/('unseeded_'+args.label)
    state = {'label': args.label, 'protocol': 'unseeded_five_parallel_one_round_each_v1', 'seed': None,
             'parallel_maps': 5, 'started_utc': utc(), 'jobs': {}, 'source_hashes': {'red': hashes(work),
             'blue': hashes(Path('/home/junhao/quan/parallel_test_solver/match/experiments/target90_20261012/official_workspaces/blue_team006_sdk_e2f022b_20261028'))},
             'evaluator_sha256': hashlib.sha256(EVALUATOR.read_bytes()).hexdigest()}
    processes = {}
    stopped = False
    def stop(signum, frame):
        nonlocal stopped
        stopped = True
        for proc in processes.values():
            if proc.poll() is None:
                os.killpg(proc.pid, signal.SIGTERM)
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    finished_normally = False
    try:
        for name in MAPS:
            command = [sys.executable, '-u', str(Path(__file__).resolve()), '--label', args.label,
                       '--red-workspace', str(work), '--worker', name]
            with (result/(name+'_worker.log')).open('w') as log:
                processes[name] = subprocess.Popen(command, cwd=ROOT, stdin=subprocess.DEVNULL,
                                                   stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        while True:
            for name, proc in processes.items():
                jobfile = result/(name+'_job.json')
                job = json.loads(jobfile.read_text()) if jobfile.exists() else {'map': name, 'status': 'starting'}
                job['worker_pid'] = proc.pid
                if proc.poll() is not None and job.get('status') not in ('complete', 'red_failed', 'blue_failed', 'orchestrator_failed'):
                    job.update(status='interrupted' if stopped else 'worker_failed', returncode=proc.returncode)
                state['jobs'][name] = job
            state['acceptance'] = gate(state['jobs'])
            state['updated_utc'] = utc()
            state['stop_requested'] = stopped
            write(result/'matrix_status.json', state)
            if stopped or all(p.poll() is not None for p in processes.values()):
                break
            time.sleep(1)
        finished_normally = True
    finally:
        if stopped or not finished_normally:
            for proc in processes.values():
                if proc.poll() is None:
                    os.killpg(proc.pid, signal.SIGTERM)
            for proc in processes.values():
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait()
        state['finished_utc'] = utc()
        state['stop_requested'] = stopped or not finished_normally
        state['payload_unchanged'] = state['source_hashes'] == {
            'red': hashes(work), 'blue': hashes(Path('/home/junhao/quan/parallel_test_solver/match/experiments/target90_20261012/official_workspaces/blue_team006_sdk_e2f022b_20261028'))}
        for name, proc in processes.items():
            jobfile = result/(name+'_job.json')
            job = json.loads(jobfile.read_text()) if jobfile.exists() else {'map':name,'status':'not_started'}
            if job.get('status') not in ('complete','red_failed','blue_failed','orchestrator_failed'):
                job.update(status='interrupted' if state['stop_requested'] else 'worker_failed', returncode=proc.returncode)
            state['jobs'][name] = job
        state['acceptance'] = gate(state['jobs'])
        if not state['payload_unchanged']:
            state['acceptance']['accepted'] = False
        write(result/'matrix_status.json', state)


if __name__ == '__main__':
    if 'MATCH_FIVE_BATCH_FD' in os.environ and '--worker' not in sys.argv:
        continue_batch()
    else:
        main()
