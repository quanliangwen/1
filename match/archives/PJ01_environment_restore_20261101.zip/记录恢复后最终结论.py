from pathlib import Path
import datetime,hashlib,json
F=Path(__file__).resolve().parent;T=Path('E:/codex/PJ01_rule_refinement_20261101');R=Path('E:/codex');C=F/'P35_continuation_after_parent_repair'
a=json.loads((F/'P35_FIVE_FINAL_ANALYSIS_FIRST.json').read_text(encoding='utf-8'));m=json.loads((F/'P35_MAP_ERROR_COMPONENTS_FIRST.json').read_text(encoding='utf-8'));p=json.loads((F/'P35_PHASE_MECHANISM_FIRST.json').read_text(encoding='utf-8'));end=json.loads((F/'FINAL_TERMINATION_AND_REVIEW.json').read_text(encoding='utf-8'));campaign=json.loads((C/'CAMPAIGN_CLIENT_REVIEW.json').read_text(encoding='utf-8'))
assert end['campaign_review']=='PASS'and a['evaluation_valid']and not campaign['native_failure']
text=f'''环境恢复和P35五图最终结论（2026-11-01北京时间20:02后核对）

用户授权的恢复任务已完成：原SDK124/原25冻结文件同SHA、原PJ01/P35/blue与elkai同SHA，新venv核心兼容约束固定，mtrand/NumPy随机数/Pandas/OpenCV/SciPy真实运算、SDK/PJ01/P35/BLUE启动与8次原GUI更新通过，pip check通过；完整41依赖锁文件已存，官网包未改。保留首工具/夹具错和遗漏results父目录的首调度错误；审计证实该次零native，补目录后原P35标签首次执行，非真实游戏失败重试。

已完成P35原Map01-05各1RED+1BLUE，共10new native，SDK/对手/线程/原限时/资源门槛不改。实际源码运行前后冻结核验通过，双方墙钟hit均0，无native错误/NumPy ABI错误。71份原始文件首次Windows不透明字节审核PASS，CAMPAIGN_CLIENT_REVIEW PASS；NPZ/pickle未反序列化，未读BLUE私有console。coordinator2664027/5workers与collector94332均已结束，registry为空。不要再轮询旧map_status最后Map05_blue_running作为未完成：最终状态、5完整job和审核优先。没有重跑PJ01、没有B、没有晋级/发布。

逐图总红分（已包含实际BLUE难度贡献）：
地图 | 保留PJ01 | P35 | P35−PJ01 | 投放PJ01/P35
'''
for x in a['comparisons']:text+=f"{x['map']} | {x['baseline']:.6f} | {x['candidate']:.6f} | {x['observed_delta']:+.6f} | {x['stock'][0]}/{x['stock'][1]}\n"
text+=f'''
平均：PJ01 {a['groups']['PJ01']['mean']:.10f}/48枚；P35 {a['groups']['P35']['mean']:.10f}/49枚；观察差{a['observed_delta']:+.10f}。
P35地图均85.650298、墙体均70.591970、时间均93.820000；保留PJ01分别93.429685/73.156686/91.860000。
少投是算法表现，不是评测无效。原collector的valid_for_performance=false包含50/50满投要求，a.evaluation_valid=true单独表明完整无wallhit/crash；原字段不重写。

为什么不保留P35为升级：均分<80且不优于保留基线，按原标准停止重复，不换seed/label救分、不追加B。单图pilot76.7432和作者地图提升不能替代完整五图。由于环境重建且没有旧完整freeze，比较不是严格恢复后同环境配对因果；不能断言全是规则或某个依赖造成，但这组结果没有支持推广P35。
实际分项：平均地图加权损失3.889694、墙体0.512943、难度0.292960，时间反而增加0.196，净−4.499597。主要退步是地图有效墙体命中，非“布局难度漏算”。地图平均credit−8.118068pp，而penalty反而减少0.338681pp，不能把这次主要损失说成误绘收费增加。
Map01地图88.0861→57.7189；credit91.3031→59.8974，penalty3.2169→2.1785，原始有效墙面命中下降是主因。红1309步85.5567秒，触发remaining<=0预算保护时2号仍带1枚，实际9枚；双方无wallhit不等于执行预算充足。当前分项不能区分未观测与观测后定位/绘图偏移，不武断归因探索不足或融合。
Map04地图92.5867→94.1205略升，实际10/10，但墙体覆盖59.4220→34.8196；该图下降应单独查布局候选价值与真实投放/急迫替代，不能全归地图或漏投。Map05投满10比基线8枚好，完整+1.4243，但不足补回其他地图。
真实规则机制：五图日志可见提前调用8/6/9/7/9共39条，均5个owner出现、outside_scope=0。证明规则接入和触发正常，不证明它提高重叠效率或得分。Map01/04/05记录预算保护退出（后两图已投完）；Map02/03是remaining>0的宽完成标签，精确非预算分支未记录。不能把模型计数/少重复等代理当提分。

下一最有价值的小诊断：保持原PJ01独立底本、一次一条。先用已审公开RED轨迹/提交图和own日志区分Map01没看到的墙与看过但没正确绘出的墙；同时将Map04实际10落点与已记录目标/时间/覆盖价值对应，区分模型候选不好与执行偏移/紧迫替代。不先叠P35/P18规则，也不盲目开五图。P40源候选仍仅小检查阶段，是否SDK闭环先看这些真实缺口，不能因为已经写好就强行测。当前没有安排下一原生队列。
'''
(F/'最终结论与下一步.txt').write_text(text,encoding='utf-8')
out=F/'RECOVERY_AND_P35_FINAL_MANIFEST.json';assert not out.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[F/n for n in ['RUNTIME_ABI_AND_SDK_FIRST.json','STARTUP_PJ01_V2_FIXTURE_FIXED.json','STARTUP_P35_V2_FIXTURE_FIXED.json','STARTUP_BLUE_V2_FIXTURE_FIXED.json','requirements-recovered-locked.txt','PRE_NATIVE_PARENT_FAILURE_AUDIT.json','P35_FIVE_FINAL_ANALYSIS_FIRST.json','P35_MAP_ERROR_COMPONENTS_FIRST.json','P35_PHASE_MECHANISM_FIRST.json','FINAL_TERMINATION_AND_REVIEW.json','最终结论与下一步.txt']]+[C/'CAMPAIGN_CLIENT_REVIEW.json',C/'P35_A/CLIENT_FIRST_RAW_REVIEW.json']
out.write_text(json.dumps(dict(status='RESTORE_AND_P35_FIVE_COMPLETE_REVIEWED_NO_PJ01_RERUN',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files={str(p):sha(p)for p in files},P35_mean=a['groups']['P35']['mean'],PJ01_preserved_mean=a['groups']['PJ01']['mean'],native_rounds=10,PJ01_rerun=False,raw_first_verified=71,active_native_processes=0,decision='STOP_P35_REPEATS_NO_PROMOTION',official_submission=False),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
old=(F/'WORKING_HANDOFF_RECOVERY_V2.txt').read_text(encoding='utf-8')
prefix='''最新完成状态2026-11-01：环境恢复及用户指定P35五图已全部完成。先读E:/codex/PJ01_environment_restore_20261101/最终结论与下一步.txt、RECOVERY_AND_P35_FINAL_MANIFEST.json、P35_FIVE_FINAL_ANALYSIS_FIRST.json、P35_MAP_ERROR_COMPONENTS_FIRST.json、P35_PHASE_MECHANISM_FIRST.json。当前无活动队列/SDK检查，coordinator2664027、5workers、collector94332都结束，registry空；V1的2660394/92992及旧P37的2534852/95784更不能重启。原STATUS map_status最后Map05blue_running是快照，最终COMPLETE+5jobs+71raw首次审PASS+CAMPAIGN PASS优先，不能反复轮询已结束队列。
P35全红均67.2799431134、49/50，保留PJ01_A均71.7795397535、48/50，观察差−4.49959664；两边红蓝wallhit0、无native failure，P35当前不是升级。逐图P35=55.032279/71.710020/74.694124/64.824196/70.139097。已含BLUE难度，不能把不高分说成尚未蓝评。没有重跑PJ01，只有10new native，完整原71raw首次Windows校验一次，旧raw未重复审核。collector valid_for_performance false是50满投附加资格标签，不等于这组评测无效；新analysis.evaluation_valid=true/completion_complete=false保留准确语义。
用户要求的环境恢复完成：Python3.11.17、核心数值/Arcade/Pymunk等固定、新venv实际mtrand/NumPy/Pandas/OpenCV/SciPy/SDK/控制器/8GUI更新及pipcheck均PASS，SDK124和原25冻结引用/蓝队及原elkai全部同SHA。全41包锁requirements-recovered-locked.txt已存，不能未来用V06宽下限覆盖此研究环境。旧Pythonbuild/全部辅助库缺完整旧freeze，故当前P35对保留基线含重建环境与自然随机/负载混杂，不可宣称严格同期同环境因果。官网V06/V07/V08不改，未发布新包。
规则实际可见提前调用8/6/9/7/9，共39条，全5机出现、scope无越界，排除未接入/完全未触发；不等于有效去重或地图改善。Map01地图57.7189 vs88.0861，credit59.8974 vs91.3031，而penalty2.1785 vs3.2169更小；平均地图credit−8.1181pp/penalty−.3387pp，主要不是误绘收费增加。平均加权退步地图−3.8897、墙−.5129、时间+.196、难度−.293。Map01预算保护时仍1枚，9/10；Map04/05预算退出已投完，不能全说缺弹。Map04地图略升但10枚墙覆盖34.8196 vs59.4220，另查候选质量与执行/急迫替代。
按原筛选<80且不优于保留基线，P35停止重复、不放宽gate、不挑图/seed/label救分、不扩B、不晋级。P40只有源/数值小检查，当前没有自动把它接入SDK或开新五图。下一持续分析应先实质用已审公开RED轨迹/提交图/own日志区分Map01未观测与观测后绘图/位姿偏差，并对Map04实际落点/目标/预算/模型价值做对应；不是再轮询COMPLETE或直接叠规则。可参考P10/P33/P38/P39已有几何/角色方法，不看真图/BLUE私态/反序列化NPZ/pickle，不把历史输入给生产。原PJ01独立底本、一次一条、先分析小SDK闭环有希望才单图和五图的用户长期授权仍有效，普通分析自主。新停止立即暂停后续。不spawn子代理，不create_goal伪造状态，不自行把持续目标标complete；用户明确恢复工作，本轮动作已授权。
SDK/测试条件未来仍原CPU<=60、loadcore<=.4、RAM8GiB、盘12GiB两60秒、SDK e2f022b、team006、原线程/每图限时/无外部seed，旧高负载一次授权耗尽。实际新native前查proc/start/global锁/registry，任何首native失败停止链不重试。当前用户恢复这一轮特别要求不重跑已完成PJ01，不得事后偷偷补基线来消除环境限制。所有首错/预运行父目录遗漏与修复审计已保留在P41，不能把零native基础设施修复叫native重跑或隐藏失败。
automation90转为分析/后续资格接续，状态无变安静，仅实质机制、完整分数、失败或需决策通知。任务仍值得继续，更新提示而不删除自动化；不再因已解决的磁盘/缺环境问题询问用户。以下旧运行信息仅历史，不当当前活队列：
'''.replace('\n+','\n')
prompt=prefix+old;(F/'WORKING_HANDOFF_COMPLETED.txt').write_text(prompt,encoding='utf-8');(F/'AUTOMATION_PROMPT.txt').write_text(prompt,encoding='utf-8')
current=R/'swarm-eod-literature-analysis/CURRENT_ACTIVE_ANALYSIS.txt';backup=current.with_name(current.stem+'_BEFORE_P35_COMPLETE.txt');assert not backup.exists();backup.write_bytes(current.read_bytes());current.write_text(prompt,encoding='utf-8')
with(T/'本轮规则经验总账_P26起.txt').open('a',encoding='utf-8')as f:f.write('\n'+text+'\n')
print(json.dumps(dict(status='FINAL_RECORDED_NO_ACTIVE_NATIVE',candidate_mean=a['groups']['P35']['mean'],baseline_mean=a['groups']['PJ01']['mean'],delta=a['observed_delta'],P35_retained_as_upgrade=False),ensure_ascii=False))
