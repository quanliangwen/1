from pathlib import Path
import ast,datetime,hashlib,json,subprocess
L=Path(__file__).resolve().parent;E=Path('E:/codex');T=E/'PJ01_rule_refinement_20261101';C=L/'P35_continuation';assert not C.exists();C.mkdir()
R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';F=H+'/P41_environment_restore_20261101';N=F+'/P35_continuation'
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((T/'P37_phase_five_comparison_20261101/PREDECLARATION.json').read_text());frozen=json.loads((L/'FROZEN_RESTORATION_LOCAL_MAP.json').read_text())
outside=R+'/solver_study/framework_screen_20261016/unseeded_direct_v1.py';p=E/'MATCH_dynamic_20261013/solver_mpc_20261015/gurobi_5h_20261015/heuristic_20261016/framework_screen_20261016/unseeded_direct_v1.py';frozen[outside]={'local':str(p),'exists':True,'match':sha(p)==old['frozen_files'][outside]};assert all(v['match']for v in frozen.values())
code='from pathlib import Path\n'+''.join('Path('+repr(n)+').parent.mkdir(parents=True,exist_ok=True)\n'for n in frozen)
subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=code,text=True,check=True)
for n,v in frozen.items():
 # All bytes checked against the pre-interruption declaration, not regenerated assertions.
 subprocess.run(['scp','-q',v['local'],'junhao@10.112.162.60:'+n],check=True)
(L/'FROZEN_RESTORATION_ALL25.json').write_text(json.dumps(frozen,indent=2)+'\n')
base=(E/'swarm-eod-literature-analysis/F27_top_three_new_blue_20261027/run_offline.py').read_text(encoding='utf-8')
base=base.replace("F = H / 'F27_top_three_new_blue_20261027'","F = H / 'P41_environment_restore_20261101/P35_continuation'").replace("'kind': 'F27_map_worker'","'kind': 'P37_RECOVERED_P35_map_worker'")
assert base.endswith("if __name__ == '__main__':\n    main()\n")
base=base[:base.rfind("if __name__ == '__main__':")]
tail='''
# Recovery orchestration only. run_cohort/evaluator/worker science is unchanged.
def summarize():
    baseline=json.loads(Path(D['preserved_baseline']['result']).read_text())
    br=[r for j in baseline['jobs'].values() for r in j['rounds']]
    assert len(br)==5 and baseline['complete']
    bm=statistics.mean(r['full_score'] for r in br)
    candidate=STATE['completed'][0]['mean'] if STATE['completed'] else None
    report={**STATE,'preserved_baseline_mean':bm,'preserved_baseline_placed':sum(r['placed']for r in br),
      'candidate_mean':candidate,'observed_delta':None if candidate is None else candidate-bm,
      'PJ01_control_cohort_rerun':False,'maximum_new_native_rounds':10,
      'automatic_promotion':False,'official_submission_ready':False,
      'environment_reconstruction_caveat':D['environment_reconstruction_caveat'],
      'first_windows_review_required':True}
    save(F/'RESULT.json',report)

def resumed_main():
    lease=(F/'coordinator.lock').open('a+')
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not(F/'RUN_ONCE.json').exists(),'Recovery schedule consumed; no replay'
    assert D['schedule']==[dict(version='P35',cohort='A',label='sdk_e2f022b_p37_P35_A')]
    assert not Path('/proc/2534852').exists()
    for p,h in D['preserved_baseline']['files'].items():assert sha(p)==h
    STATE.update(started_utc=utc(),decisions=[{'decision':'P35_A_ONLY_RESUME','reason':'Completed PJ01_A retained; original both-A50 condition already fails so no B groups'}])
    save(F/'RUN_ONCE.json',dict(utc=utc(),pid=os.getpid(),starttime_ticks=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],driver_sha256=sha(__file__),study_sha256=sha(F/'PREDECLARATION.json'),PJ01_rerun=False))
    try:
      validate_frozen();summarize()
      if run_cohort(D['schedule'][0]):
        state('AWAIT_FIRST_WINDOWS_REVIEW',current=None)
        started=time.monotonic();review=F/'P35_A/CLIENT_FIRST_RAW_REVIEW.json'
        while not review.exists():
          if stop_requested():raise RuntimeError('User stop before first Windows review')
          if time.monotonic()-started>7200:raise TimeoutError('First Windows review expired; no rerun')
          time.sleep(10)
        proof=json.loads(review.read_text());receipt=json.loads((F/'P35_A/RAW_ARCHIVE_RECEIPT.json').read_text())
        assert proof['status']=='PASS' and proof['archive_sha256']==receipt['sha256']
        state('COMPLETE_FINITE_STAGED_CAMPAIGN',current=None)
      else:state('STOPPED_BEFORE_NEXT_COHORT',current=None)
      summarize()
    except Exception:
      save(F/'FIRST_ERROR.json',dict(utc=utc(),traceback=traceback.format_exc(),first_native_failure=STATE['first_native_failure'],no_retry=True,PJ01_rerun=False))
      state('STOPPED_FIRST_ERROR_NO_RETRY');summarize();raise

if __name__=='__main__':resumed_main()
'''
driver=base+tail;ast.parse(driver);(C/'run_offline.py').write_text(driver,encoding='utf-8',newline='\n')
original=ast.parse((E/'swarm-eod-literature-analysis/F27_top_three_new_blue_20261027/run_offline.py').read_text())
recovered=ast.parse(driver)
for name in ['run_cohort','resource','acquire_when_ready','validate_frozen']:
 a=next(n for n in original.body if isinstance(n,ast.FunctionDef)and n.name==name);b=next(n for n in recovered.body if isinstance(n,ast.FunctionDef)and n.name==name);assert ast.dump(a)==ast.dump(b)
collector=(T/'P37_phase_five_comparison_20261101/collect_offline.py').read_text(encoding='utf-8');collector=collector.replace("RF=R+'/solver_study/framework_screen_20261016/best87_independent_20261025/'+F.name;RC=RF",'RF='+repr(N)+';RC=RF')
ast.parse(collector);(C/'collect_offline.py').write_text(collector,encoding='utf-8',newline='\n')
payload=dict(original_declaration_sha256=sha(T/'P37_phase_five_comparison_20261101/PREDECLARATION.json'),preserved_baseline_files={H+'/P37_phase_five_comparison_20261101/PJ01_A/'+n:sha(T/'P37_phase_five_comparison_20261101/PJ01_A'/n)for n in ['RESULT.json','CLIENT_FIRST_RAW_REVIEW.json','RAW_ARCHIVE_RECEIPT.json']},original_native_scientific_functions_AST_equal=['run_cohort','resource','acquire_when_ready','validate_frozen'],max_new_native=10,PJ01_rerun=False)
(C/'CONTINUATION_SOURCE_BINDING.json').write_text(json.dumps(payload,indent=2)+'\n')
subprocess.run(ssh+[R+'/.venv/bin/python','-'],input='from pathlib import Path\np=Path('+repr(N)+')\nassert not p.exists();p.mkdir()\n',text=True,check=True)
for p in C.iterdir():subprocess.run(['scp','-q',str(p),'junhao@10.112.162.60:'+N+'/'],check=True)
print(json.dumps(dict(status='FROZEN25_RESTORED_CONTINUATION_DRIVER_PREPARED_NOT_LAUNCHED',server=N,local=str(C),max_new_native=10,PJ01_rerun=False)))
