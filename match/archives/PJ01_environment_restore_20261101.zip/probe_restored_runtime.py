from pathlib import Path
import datetime,fcntl,hashlib,importlib.metadata as md,json,os,site,subprocess,sys,zipfile
R=Path('/home/junhao/quan/parallel_test_solver/match');S=R/'solver_study';H=S/'framework_screen_20261016/best87_independent_20261025';F=H/'P41_environment_restore_20261101';OUT=F/'RUNTIME_ABI_AND_SDK_FIRST.json';assert not OUT.exists()
lock=(S/'serial_evaluation.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
D=json.loads((H/'P37_phase_five_comparison_20261101/PREDECLARATION.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
oldblue=json.loads((F/'ORIGINAL_BLUE_STAGING.json').read_text());blue=Path(D['blue_binding']['blue_workspace'])
wheels=list(F.glob('elkai-2.0.1-*.whl'));assert len(wheels)==1 and sha(wheels[0])==oldblue['dependency_wheel_sha256']
with zipfile.ZipFile(wheels[0])as z:
 for n in z.namelist():
  if n.endswith('/'):continue
  p=(blue/'src'/n).resolve();assert str(p).startswith(str((blue/'src').resolve())+'/')
  assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
assert all(sha(blue/'src'/n)==h for n,h in oldblue['dependency_files'].items())
assert all(sha(blue/'req.txt'if n=='req.txt'else blue/'src/swarm_rescue/solutions'/n)==h for n,h in oldblue['source_files'].items())
assert all(sha(blue/n)==h for n,h in D['sdk_files'].items())
assert sys.version_info[:3]==(3,11,17)and Path(sys.prefix)==R/'.venv'and site.ENABLE_USER_SITE is False
import numpy as np,numpy.random.mtrand as mt,pandas as pd,cv2,scipy,pymunk,pyglet,yaml
assert np.__version__=='1.26.4'and pd.__version__=='3.0.6'and cv2.__version__=='4.11.0'and scipy.__version__=='1.17.1'
modules={'numpy':np,'mtrand':mt,'pandas':pd,'cv2':cv2,'scipy':scipy,'pymunk':pymunk}
paths={n:str(Path(m.__file__).resolve())for n,m in modules.items()}
assert all(p.startswith(str(R/'.venv')+'/')for p in paths.values()),paths
assert np.isfinite(np.random.RandomState(615).normal(size=16)).all()
assert np.random.default_rng(615).integers(0,20,size=10).shape==(10,)
assert pd.DataFrame({'a':[1,2]}).a.sum()==3
assert cv2.resize(np.zeros((4,4),np.uint8),(2,2)).shape==(2,2)
from scipy.optimize import milp,Bounds,LinearConstraint
answer=milp(c=[-1.,-2.],integrality=[1,1],bounds=Bounds(0,1),constraints=LinearConstraint([[1.,1.]],-np.inf,1.))
assert answer.success and abs(answer.fun+2)<1e-9
from swarm_rescue.launcher import Launcher
from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
from swarm_rescue.solutions.my_drone_eval import MyDroneEval,drone_class_for_mode
from swarm_rescue.maps.map_01 import Map01
team=yaml.safe_load((R/'swarm-eod/src/swarm_rescue/solutions/team_info.yml').read_text());assert type(team['team_number'])is int and team['team_number']==615
assert drone_class_for_mode('place')is MyDroneEval
window=pyglet.window.Window(width=1,height=1,visible=False)
arena=None
try:
 arena=Map01(drone_type=MyDroneEval,number_drones=5)
 assert len(arena.drones)==5 and len({id(d.memory.hits)for d in arena.drones})==5
 graphics=dict(version=str(window.context.get_info().get_version()),renderer=str(window.context.get_info().get_renderer()))
finally:
 if arena is not None:
  try:arena.playground.cleanup();arena.playground.close_window()
  except Exception:pass
 window.close()
versions={n:md.version(n)for n in ['numpy','pandas','opencv-contrib-python','scipy','arcade','pymunk','pyglet','Pillow','scikit-image','matplotlib','elkai']}
out=dict(status='PASS_NUMERIC_ABI_SDK_AND_PJ01_STARTUP',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),python=sys.version,executable=sys.executable,versions=versions,module_paths=paths,
    SDK_files_verified=len(D['sdk_files']),SDK_commit=D['sdk_commit'],canonical_PJ01_payload_sha256=D['versions']['PJ01']['source_files'],blue_source_files=oldblue['source_files'],blue_dependency_files=oldblue['dependency_files'],
    old_elkai_wheel_sha256=sha(wheels[0]),graphics=graphics,team_number=615,five_independent_PJ01_instances=True,numpy_random_pandas_cv_scipy_real_operations=True,SDK_Launcher_Stats_import=True,native_scored_rounds=0,PJ01_control_cohort_rerun=False,
    environment_recovery_limit='Critical versions/source/physics SDK restored. No complete old pip freeze survived; remaining resolved dependencies recorded in new full freeze, not asserted byte-identical to erased venv.')
OUT.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
