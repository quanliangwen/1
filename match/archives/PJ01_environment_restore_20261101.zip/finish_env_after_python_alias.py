from pathlib import Path
import datetime,hashlib,json,os,subprocess
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'P41_environment_restore_20261101'
D=json.loads((H/'P37_phase_five_comparison_20261101/PREDECLARATION.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=H/'F32_official_sdk_20261028/updated_sdk_base';canonical=R/'swarm-eod';blue=Path(D['blue_binding']['blue_workspace'])
assert all(sha(base/n)==h and sha(canonical/n)==h and sha(blue/n)==h for n,h in D['sdk_files'].items())
assert not (R/'.venv').exists()
py=sorted({p.resolve() for p in (R/'runtimes/python').glob('*/bin/python3.11')});assert len(py)==1
subprocess.run([str(py[0]),'-m','venv',str(R/'.venv')],check=True)
pins='numpy==1.26.4\nopencv-contrib-python==4.11.0.86\npandas==3.0.6\nscipy==1.17.1\nelkai==2.0.1\narcade==2.6.17\npyglet==2.0.dev23\npymunk==6.4.0\nPillow==9.3.0\n'
(F/'constraints-recovery.txt').write_text(pins)
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='SOURCE_AND_CLEAN_VENV_CREATED_PENDING_INSTALL',SDK_files_verified=len(D['sdk_files']),sdk_commit=D['sdk_commit'],python_base=str(py[0]),python_version=subprocess.check_output([str(py[0]),'--version'],text=True).strip(),SDK_base=str(base),canonical_PJ01=str(canonical),blue_workspace=str(blue),blue_controller_sha256=sha(blue/'src/swarm_rescue/solutions/lbbd_rescue.py'),pins=pins,first_setup_error='Same uv interpreter exposed via version alias and full version directory; initial no-venv assertion counted both. Resolved paths now deduplicated; source/constraints unchanged, not a game retry.')
(F/'SOURCE_RESTORE_AFTER_ALIAS_FIX.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
env=os.environ.copy();env.pop('PYTHONPATH',None);env['PYTHONNOUSERSITE']='1';env['PIP_DISABLE_PIP_VERSION_CHECK']='1'
with(F/'DEPENDENCY_INSTALL_FIRST.log').open('w')as log:
 r=subprocess.run([str(R/'.venv/bin/python'),'-m','pip','install','--report',str(F/'dependency_install_report.json'),'-c',str(F/'constraints-recovery.txt'),'-e',str(canonical),'scipy==1.17.1','elkai==2.0.1'],env=env,stdout=log,stderr=subprocess.STDOUT)
print(json.dumps(dict(install_returncode=r.returncode,log=str(F/'DEPENDENCY_INSTALL_FIRST.log'))),flush=True)
assert r.returncode==0,'Preserve first dependency install failure.'
