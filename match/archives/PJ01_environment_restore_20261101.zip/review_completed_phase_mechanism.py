from pathlib import Path
import json,tarfile,datetime
F=Path(__file__).resolve().parent;G=F/'P35_continuation_after_parent_repair/P35_A';OUT=F/'P35_PHASE_MECHANISM_FIRST.json';assert not OUT.exists()
proof=json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'));assert proof['status']=='PASS'
manifest=json.loads((G/'RAW_SHA256.json').read_text(encoding='utf-8'));matrix=json.loads((G/'RESULT.json').read_text(encoding='utf-8'));assert matrix['complete']
rows=[]
with tarfile.open(G/'raw_results.tar.gz','r:gz')as archive:
 for name in ['Map01','Map02','Map03','Map04','Map05']:
  n=name+'_red/console.log';assert n in manifest
  with archive.extractfile(n)as stream:text=stream.read().decode('utf-8',errors='replace')
  events=[json.loads(line.split(' ',1)[1])for line in text.splitlines()if line.startswith('[EXPLORATION_PHASE] ')]
  early=[e for e in events if e['kind']=='ACTUAL_EARLY_EXPLORATION'];submit=[e for e in events if e['kind']=='ACTUAL_SUBMISSION_DUE'];images=[e for e in events if e['kind']=='SUBMIT_IMAGE']
  result=matrix['jobs'][name]['rounds'][0]
  rows.append(dict(map=name,early_events_visible=len(early),owners_with_early=sorted({e['owner']for e in early}),early_outside_scope=sum(not e['ordinary_scope']for e in early),early_event_steps={str(owner):[e['step']for e in early if e['owner']==owner]for owner in range(5)},submission_events=submit,submission_image_metadata=images,placed=result['placed'],expected=result['expected'],red_steps=result['red_steps'],red_wall=result['red_walltime'],red_wall_hit=result['red_max_walltime_reached'],source_file=n,source_hash_from_first_review=manifest[n]['sha256']))
out=dict(status='POST_FIRST_REVIEW_OWN_PHASE_MECHANISM_ANALYZED',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),rows=rows,
 no_outside_scope_visible=all(r['early_outside_scope']==0 for r in rows),NPZ_or_pickle_loaded=False,private_BLUE_console_read=False,raw_byte_review_repeated=False,
 limitations=['Own public console only after first Windows raw review; early logging capped24 per owner, counts can be lower bounds.',
 'SUBMISSION_DUE audit labels remaining<=0 as budget exhaustion, otherwise broad completion label. No recovery of unlogged exact non-budget branch.',
 'Phase firing and no outside scope are mechanism evidence, not cause of map/coverage/score change. Restored-environment and natural randomness limits remain.'])
OUT.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(status=out['status'],summaries=[dict(map=r['map'],visible_early=r['early_events_visible'],owners=r['owners_with_early'],outside_scope=r['early_outside_scope'],placed=r['placed'],submission_reasons=[e['reason']for e in r['submission_events']])for r in rows]),ensure_ascii=False))
