from pathlib import Path
import sys,subprocess,os,json,datetime
F=Path(__file__).resolve().parent;assert not(F/'WINDOWS_COLLECTOR_LAUNCH.json').exists()
with(F/'collector.stdout.log').open('xb') as out,(F/'collector.stderr.log').open('xb') as err:
    p=subprocess.Popen([sys.executable,'-X','utf8',str(F/'collect_offline.py')],cwd=F,stdin=subprocess.DEVNULL,stdout=out,stderr=err,env=dict(os.environ,PYTHONUTF8='1'),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
r=dict(status='FINITE_PJ01_SCOPED_COLLECTOR_STARTED',pid=p.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),starts_native_games=False,finite_hours=14)
(F/'WINDOWS_COLLECTOR_LAUNCH.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8');print(json.dumps(r))
