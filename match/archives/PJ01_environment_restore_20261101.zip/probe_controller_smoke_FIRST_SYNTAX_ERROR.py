from pathlib import Path
from types import SimpleNamespace
import datetime,fcntl,hashlib,json,os,sys,time
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'P41_environment_restore_20261101'
arm=sys.argv[1];assert arm in ['PJ01','P35','BLUE'];OUT=F/('STARTUP_'+arm+'_FIRST.json');assert not OUT.exists()
lock=(R/'solver_study/serial_evaluation.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
D=json.loads((H/'P37_phase_five_comparison_20261101/PREDECLARATION.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
W={'PJ01':R/'swarm-eod','P35':F/'P35_startup_workspace','BLUE':Path(D['blue_binding']['blue_workspace'])}[arm]
assert all(sha(W/n)==h for n,h in D['sdk_files'].items())
if arm!='BLUE':
 expected=D['versions'][arm]['source_files'];assert all(sha(W/'req.txt'if n=='req.txt'else W/'src/swarm_rescue/solutions'/n)==h for n,h in expected.items())
sys.path.insert(0,str(W/'src'))
import numpy as np,pyglet,yaml
from swarm_rescue.launcher import Launcher
from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
from swarm_rescue.solutions.my_drone_eval import drone_class_for_mode
from swarm_rescue.simulation.gui_map.gui_sr import GuiSR
from swarm_rescue.simulation.reporting.evaluation import EvalConfig
from swarm_rescue.simulation.reporting.team_mode import TeamMode
from swarm_rescue.maps.map_01 import Map01
from swarm_rescue.maps.map_02 import Map02
mode='rescue'if arm=='BLUE'else'place';cls=drone_class_for_mode(mode)
assert Path(sys.modules[cls.__module__].__file__).resolve().is_relative_to(W)
info=yaml.safe_load((W/'src/swarm_rescue/solutions/team_info.yml').read_text());assert type(info['team_number'])is int and info['team_number']==(6 if arm=='BLUE'else615)
if arm=='BLUE':
 import elkai
 assert Path(elkai.__file__).resolve().is_relative_to(W)
 tour=elkai.DistanceMatrix([[0,1,3],[1,0,2],[3,2,0]]).solve_tsp(runs=1);assert set(tour)=={0,1,2}
window=pyglet.window.Window(width=1,height=1,visible=False);arena=None;gui=None
try:
 arena=(Map02 if arm=='BLUE'else Map01)(drone_type=cls,number_drones=10 if arm=='BLUE'else5)
 ec=EvalConfig(map_name='Map02'if arm=='BLUE'else'Map01',zones_config=(),number_drones=10 if arm=='BLUE'else5,initial_bombs_per_drone=2,nb_rounds=1)
 configuration=SimpleNamespace(_resolve_bombs_file=lambda config:None)
 Launcher._configure_map_for_team(configuration,arena,ec,TeamMode.from_string(mode))
 gui=GuiSR(the_map=arena,draw_interactive=False,filename_video_capture=None,filename_state_recording=None,manual_bomb_edit_enabled=False,headless=True,competition_mode=True)
 before=[d.drone_health for d in arena.drones]
 for _ in range(8):gui.on_update(1/30)
 assert gui.elapsed_timestep==8 and not gui.is_max_walltime_limit_reached
 assert all(np.isfinite(np.asarray(d.base._pm_body.position)).all()for d in arena.drones)
 assert all(d.drone_health>0 for d in arena.drones)
 out=dict(status='PASS',arm=arm,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),workspace=str(W),SDK_files_verified=len(D['sdk_files']),team_number=info['team_number'],instances=len(arena.drones),GUI_native_update_calls=8,elapsed_steps=gui.elapsed_timestep,elapsed_wall=gui.elapsed_walltime,health_before=before,health_after=[d.drone_health for d in arena.drones],controller=cls.__module__+'.'+cls.__name__,payload_files_sha256=expected if arm!='BLUE'else json.loads((F/'ORIGINAL_BLUE_STAGING.json').read_text())['source_files'],native_scored_rounds=0,score_computed=False,PJ01_cohort_rerun=False,scope='Eight original SDK GUI updates only, original limits unchanged, no score/no dataset seed/no complete native round. Restored entry and sensor/control/physics startup check.')
finally:
 if gui is not None:gui.close()
 if arena is not None:
  try:arena.playground.cleanup();arena.playground.close_window()
  except Exception:pass
 window.close()
assert all(sha(W/n)==h for n,h in D['sdk_files'].items())
OUT.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='payload_files_sha256'}),flush=True)
