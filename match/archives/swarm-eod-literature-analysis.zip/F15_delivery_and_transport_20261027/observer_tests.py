from pathlib import Path
import sys,json,types,time,traceback,ast
Q=Path(__file__).resolve().parent;W=Q/'workspace';F=Q.parent
report={'status':'STARTED','checks':[],'game_rounds':0}
def check(n,v):
 assert v,n
 report['checks'].append(n)
try:
 sys.path.insert(0,str(W/'src'))
 import numpy as np,cv2,pandas
 from swarm_rescue.solutions.greedy_mapping import MapMemory
 from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
 from swarm_rescue.solutions import trust_region_cover as trust,team_coverage_lns as current
 from swarm_rescue.solutions.layout_advisors import delivery_advice
 from swarm_rescue.solutions.diagnostic_mixin import DiagnosticMixin
 from swarm_rescue.solutions.my_drone_eval import MyDroneEval,BaseParent
 from swarm_rescue.simulation.reporting.team_info import TeamInfo
 from swarm_rescue.launcher import Launcher
 from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
 import numpy.random.mtrand
 check('native_runtime',(np.__version__,pandas.__version__,cv2.__version__)==('1.26.4','3.0.6','4.11.0'))
 check('integer615',type(TeamInfo().team_number) is int and TeamInfo().team_number==615)
 check('actual_mtrand',np.isfinite(np.random.RandomState(615).normal(size=8)).all())
 check('observer_source',Path(trust.__file__).resolve().is_relative_to(W))
 check('factory_observer_immediate',MyDroneEval.__mro__[1].__name__=='DiagnosticMixin')
 check('original_placement_ancestor',next(c.__name__ for c in MyDroneEval.__mro__ if '_maybe_place' in c.__dict__)=='ActiveCoverageMixin')
 parent=json.loads((F/'PREDECLARATION.json').read_text())['parent'];P=Path(parent['path'])/'source'
 original=types.ModuleType('original_lns_reference');exec(compile((P/'team_coverage_lns.py').read_text(),str(P/'team_coverage_lns.py'),'exec'),original.__dict__)
 oldtree=ast.parse((P/'trust_region_cover.py').read_text());newtree=ast.parse(Path(trust.__file__).read_text())
 fn=next(n for n in newtree.body if isinstance(n,ast.FunctionDef) and n.name=='refine_trust_region')
 fn.body=[n for n in fn.body if not(isinstance(n,ast.If) and any(isinstance(v,ast.Attribute) and v.attr=='_f15_live_prepared' for v in ast.walk(n)))]
 check('refiner_numerical_AST_unchanged',ast.dump(oldtree)==ast.dump(newtree))
 def same(a,b):return a.keys()==b.keys() and all(len(a[k])==len(b[k]) and all(np.array_equal(p,q) for p,q in zip(a[k],b[k])) for k in a)
 def fixture(enabled=True,prefix=False):
  m=MapMemory(1024,128);m.free[:]=True;m.identifier=2;m.step=1000;m._f15_layout_enabled=enabled
  pm=GeometryPlanningMemory(m);pm._coverage_values_cache=(32.,np.zeros(m.shape,np.float32),np.zeros(m.shape,bool));m._test_pm=pm
  base={2:[m.cell_to_world((3,36)),m.cell_to_world((3,26))]};agents={2:(m.cell_to_world((3,32)),2)}
  rally=m.cell_to_world((3,57));m._f15_rally=rally
  prefixes={2:(m.cell_to_world((3,31)),agents[2][0])} if prefix else None
  return m,pm,base,agents,rally,prefixes
 for name,prefix,cap in [('normal',False,1000.),('prefix',True,1000.),('tight_cap',False,250.)]:
  a,pa,base,agents,rally,pref=fixture(False,prefix);b,pb,baseb,agentsb,_,prefb=fixture(True,prefix)
  saved_factory=trust.GeometryPlanningMemory;saved_current=current._greedy_plan
  try:
   trust.GeometryPlanningMemory=lambda m:m._test_pm
   original._greedy_plan=lambda *a,**k:{n:[p.copy() for p in ps] for n,ps in base.items()}
   current._greedy_plan=lambda *a,**k:{n:[p.copy() for p in ps] for n,ps in baseb.items()}
   ra=original.plan_team_coverage_lns(a,agents,[],32.,travel_budget=cap,reserved_prefixes=pref)
   rb=current.plan_team_coverage_lns(b,agentsb,[],32.,travel_budget=cap,reserved_prefixes=prefb)
  finally:trust.GeometryPlanningMemory=saved_factory;current._greedy_plan=saved_current
  check('original_plan_'+name,same(ra,rb));check('original_counters_'+name,a.trust_region_diagnostics==b.trust_region_diagnostics)
  check('original_arrays_'+name,all(np.array_equal(getattr(a,k),getattr(b,k)) for k in ['hits','free','visits']))
  check('temporary_capture_cleanup_'+name,'_f15_live_prepared' not in vars(b))
 m,pm,base,agents,rally,pref=fixture();audit=delivery_advice(m,agents,[],32.,base,1000.,None,(),None,pm,time.perf_counter()+5,rally)
 check('actual_graph_delivery_positive',audit['reason']=='positive_delivery_move')
 check('actual_graph_delivery_values',audit['sum_before']==720. and audit['sum_after']==592.)
 check('actual_graph_site_set_preserved',sorted(audit['alternative']['2'])==sorted([p.tolist() for p in base[2]]))
 other=m.cell_to_world((3,50));agentsb={**agents,7:(other,0)}
 audit=delivery_advice(m,agentsb,[],32.,base,1000.,{7:(m.cell_to_world((3,10)),other)},(),None,pm,time.perf_counter()+5,rally)
 check('zero_suffix_frozen_prefix_included',audit['suffix_counts'][7]==0 and audit['prefix_costs'][7]==640.)
 # Exercise the actual new telemetry path before any simulator can call it.
 d=object.__new__(DiagnosticMixin);d._diag_core_state=lambda:{'owner':0,'step':200,'stock':0};d.fleet_states={0:(200,np.zeros(2),0)}
 d.fleet_plan=None;d.memory=types.SimpleNamespace(exploration_goal=None);d.pose=np.zeros(2);d.rally=np.zeros(2);d.coverage_ready=True
 d._seeking_fusion=False;d._sortie_state='DOCK';d.pending_drop=None;d.coverage_model={};d.completion_certificates={0:180};d.elapsed_timestep=200;d.STATE_FRESH_STEPS=120
 state=d._diag_state();check('new_snapshot_path_smoke',state['completion_origins']==[0] and state['decision_snapshot']['sortie_state']=='DOCK')
 class Parent:
  def _sortie_admit(self,step,peers):self.calls+=1;return self.original_return
 class Probe(DiagnosticMixin,Parent):F15_MODE='COURIER'
 d=object.__new__(Probe);d.calls=0;d.original_return=None;d.identifier=2;d.carried_bombs_count=lambda:0;d.submitted=False;d.pose=np.zeros(2);d.rally=np.zeros(2)
 d._sortie_state='DOCK';d.completion_certificates={0:100,2:100};d.team_size=3
 d.fleet_states={0:(200,np.zeros(2),0),1:(150,np.array([300.,0.]),1),2:(200,np.zeros(2),0)}
 d.STATE_FRESH_STEPS=120;d._sortie_docked_step=100;d.last_peer_step={0:190};d._step_seconds=.1;d._remaining_steps=lambda:500.;d.assignment_reports={};d.GOAL_LEASE_STEPS=600
 d.memory=MapMemory(640,256);d.memory.free[:]=True;d._diag_costs={};d._f15_control_started=time.perf_counter()
 result=d._sortie_admit(200,[])
 check('courier_original_result_unchanged',result is None and d.calls==1)
 check('courier_original_role_goal_unchanged',d._sortie_state=='DOCK' and d.completion_certificates=={0:100,2:100})
 check('courier_probe_executed_once',d._f15_courier_count==1)
 d.original_return=([np.array([16.,0.])],np.array([16.,0.]));result=d._sortie_admit(400,[])
 check('original_sortie_not_replaced',result is d.original_return and d.calls==2 and d._f15_courier_count==1)
 report.update(status='PASS',scope='Actual new telemetry/courier wrapper paths plus original plan/counter/array equivalence, fixed synthetic public graph, native ABI imports. No simulator/candidate/history.')
except BaseException:report.update(status='FAIL',error=traceback.format_exc());raise
finally:
 (Q/'FIRST_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'checks':len(report['checks']),'error':report.get('error')}))
