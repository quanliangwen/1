from pathlib import Path
import base64,json,subprocess,shlex
F=Path(__file__).resolve().parent
payload={n:base64.b64encode((F/n).read_bytes()).decode() for n in ['delivery_schedule.py','courier_advisor.py','transport_slack_advisor.py','helper_tests.py']}
payload['courier_advisor.py']=base64.b64encode((F/'courier_advisor_revision1.py').read_bytes()).decode()
code=r'''
from pathlib import Path
import sys,json,base64,hashlib,shutil,subprocess,ast,os
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F15_delivery_and_transport_20261027';Q=F/'helper_revision1';assert not Q.exists();Q.mkdir();S=Q/'helper_source';S.mkdir()
P=json.loads((F/'PREDECLARATION.json').read_text())['parent'];blue=Path(json.loads((H/'F07_evidence_three_directions_20261026/infrastructure/PREDECLARATION.json').read_text())['blue_workspace'])
W=Q/'workspace';shutil.copytree(blue,W,ignore=shutil.ignore_patterns('solutions','__pycache__','*.pyc','.git','.pytest_cache'));sol=W/'src/swarm_rescue/solutions';sol.mkdir()
for p in (Path(P['path'])/'source').iterdir():shutil.copy2(p,W/'req.txt' if p.name=='req.txt' else sol/p.name)
binding={}
for n,b in json.load(sys.stdin).items():
 raw=base64.b64decode(b);ast.parse(raw.decode());(Q/n if n=='helper_tests.py' else S/n).write_bytes(raw);binding[n]=hashlib.sha256(raw).hexdigest()
(Q/'SOURCE_BINDING.json').write_text(json.dumps(binding,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with (Q/'first_console.log').open('x') as log:r=subprocess.run(['bash',str(R/'run_server.sh'),'-u',str(Q/'helper_tests.py')],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
d=json.loads((Q/'FIRST_RESULT.json').read_text());print(json.dumps({'status':d['status'],'checks':len(d['checks']),'error':d.get('error')}));raise SystemExit(r.returncode)
'''
r=subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps(payload).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert not(F/'helper_revision1_console.txt').exists();(F/'helper_revision1_console.txt').write_bytes(r.stdout+r.stderr);print((r.stdout+r.stderr).decode(errors='replace'));raise SystemExit(r.returncode)
