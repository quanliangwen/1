from pathlib import Path
import ast
F=Path(__file__).resolve().parent
s=(F/'courier_advisor.py').read_text()
a="metric=np.hypot(xx-drone.pose[0],yy-drone.pose[1]);max_out=min(remaining-24.,remaining/2.)-48."
b="metric=np.hypot(xx-drone.pose[0],yy-drone.pose[1])\n    available_now=remaining-(time.perf_counter()-begun)/rate\n    max_out=min(available_now-24.,available_now/2.)-48.-float(m.CELL)"
assert s.count(a)==1;s=s.replace(a,b)
a="""        for flat in np.argsort(-rank.ravel(),kind='stable')[:8]:
            cell=tuple(map(int,np.unravel_index(int(flat),m.shape)))
            if not np.isfinite(rank[cell]):break
            candidates.append((float(rank[cell]),origin,stamp,kind,cell))"""
b="""        distinct=[]
        for flat in np.argsort(-rank.ravel(),kind='stable'):
            if time.perf_counter()>=deadline:break
            cell=tuple(map(int,np.unravel_index(int(flat),m.shape)))
            if not np.isfinite(rank[cell]):break
            if any((cell[0]-r)**2+(cell[1]-c)**2<4 for r,c in distinct):continue
            distinct.append(cell)
            candidates.append((float(rank[cell]),origin,stamp,kind,cell))
            if len(distinct)>=8:break"""
assert s.count(a)==1;s=s.replace(a,b);ast.parse(s)
p=F/'courier_advisor_revision1.py';assert not p.exists();p.write_text(s,encoding='utf-8')
s=(F/'qualify_helpers.py').read_text().replace("Q=F/'helper_qualification'","Q=F/'helper_revision1'").replace("helper_first_console.txt","helper_revision1_console.txt")
marker="payload={n:base64.b64encode((F/n).read_bytes()).decode() for n in ['delivery_schedule.py','courier_advisor.py','transport_slack_advisor.py','helper_tests.py']}"
assert s.count(marker)==1;s=s.replace(marker,marker+"\npayload['courier_advisor.py']=base64.b64encode((F/'courier_advisor_revision1.py').read_bytes()).decode()")
ast.parse(s);p=F/'qualify_helpers_revision1.py';assert not p.exists();p.write_text(s,encoding='utf-8')
print('Separate revision QA prepared; original first failure/source preserved; no game')
