from pathlib import Path
import sys,json,datetime,subprocess,shlex
from collections import Counter
F=Path(__file__).resolve().parent;name=sys.argv[1];assert name in ['PARENT_M05_DIAG','PARENT_M04_DIAG'];G=F/name
assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text())['valid'];assert not(G/'ANALYSIS.json').exists()
E=json.loads((G/'EVENTS.json').read_text());R=json.loads((G/'RESULT.json').read_text());C=E['F15_COURIER_ADVISOR'];L=E['F15_LAYOUT_ADVISOR']
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'diagnostic':name,'parent':'K01','not_for_performance_ranking':True,'raw_arrays_loaded':0,
   'game_row':R['row'],'courier_events':C,'layout_events':L,'courier_reasons':dict(Counter(x['reason'] for x in C)),
   'layout_reasons':dict(Counter(x['kind']+':'+x['reason'] for x in L)),
   'advisor_seconds_total':sum(x.get('seconds',0) for x in C+L),'advisor_seconds_max':max([x.get('seconds',0) for x in C+L],default=0),
   'scope':'Current own causal scalar opportunity logs only. No score/causal claim or arrays/history input. Gating is necessary, not proof of actual implementation or full-five benefit.'}
if name=='PARENT_M05_DIAG':d['gates']={'P02':any(x['reason']=='positive_known_courier_rendezvous' for x in C)}
else:d['gates']={'P01':any(x['reason']=='positive_delivery_move' and not x.get('deadline_reached') for x in L),
                 'P03':any(x['reason']=='positive_transport_slack' and not x.get('deadline_reached') for x in L)}
latest={}
for x in E['F15_DIAG_TICK']+E['F15_SUBMIT_DECISION']+E['F15_SUBMIT_CALL']:
 if x['owner'] not in latest or x['step']>=latest[x['owner']]['step']:latest[x['owner']]=x
d['final_own_state']=[{k:x.get(k) for k in ['owner','step','stock','remaining_steps','completion_origins','cached_map_quality','decision_snapshot']} for x in latest.values()]
p=G/'ANALYSIS.json';p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
remote="from pathlib import Path;import sys;p=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F15_delivery_and_transport_20261027')/"+repr(name)+"/'ANALYSIS.json';assert not p.exists();p.write_bytes(sys.stdin.buffer.read())"
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(remote)],input=p.read_bytes(),check=True)
print(json.dumps({k:d[k] for k in ['diagnostic','gates','courier_reasons','layout_reasons','advisor_seconds_total','advisor_seconds_max']}))
