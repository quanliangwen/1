"""Current-graph fixed-site local search with an explicit delivery endpoint."""
import math
import time


def improve_delivery(plans,starts,distances,ends,full_caps,prefix_costs,cell_size,
                     route_epsilon=32.,deadline=None):
    original={int(k):list(v) for k,v in plans.items()}
    def no(reason,tested=0):return {k:list(v) for k,v in original.items()},{'reason':reason,'tested':tested}
    points=[p for v in original.values() for p in v]
    if (not math.isfinite(cell_size) or cell_size<=0 or not math.isfinite(route_epsilon) or route_epsilon<0
            or len(original)>5 or len(points)>10 or any(len(v)>2 for v in original.values())
            or len(set(points))!=len(points)):return no('invalid_or_unsupported')
    if any(k not in starts or k not in ends or k not in full_caps for k in original):return no('missing_owner_context')
    def costs(k,v):
        old=starts[k];out=float(prefix_costs.get(k,0.))
        if not math.isfinite(out) or out<0:return math.inf,math.inf
        for node in v:
            d=float(distances[old,node])
            if not math.isfinite(d) or d<0:return math.inf,math.inf
            out+=d;old=node
        back=float(distances[old,ends[k]])
        return out,out+back if math.isfinite(back) and back>=0 else math.inf
    before={k:costs(k,v) for k,v in original.items()}
    if not before or any(not math.isfinite(a) or not math.isfinite(b) or math.isnan(float(full_caps[k]))
                         or a>float(full_caps[k])+1e-6 for k,(a,b) in before.items()):return no('invalid_incumbent_outbound_or_return')
    max_before=max(b for a,b in before.values());sum_before=sum(b for a,b in before.values())
    slots=[(k,j) for k,v in sorted(original.items()) for j in range(len(v))]
    best=None;rank0=None;tested=0
    for n,(k,i) in enumerate(slots):
        for h,j in slots[n+1:]:
            if deadline is not None and time.perf_counter()>=deadline:return no('deadline',tested)
            proposed={owner:list(v) for owner,v in original.items()}
            proposed[k][i],proposed[h][j]=proposed[h][j],proposed[k][i]
            after=dict(before)
            for owner in {k,h}:after[owner]=costs(owner,proposed[owner])
            tested+=1
            if any(not math.isfinite(after[o][1]) or after[o][0]>before[o][0]+route_epsilon+1e-6
                   or after[o][0]>float(full_caps[o])+1e-6 or after[o][1]>float(full_caps[o])+1e-6 for o in {k,h}):continue
            mx=max(b for a,b in after.values());total=sum(b for a,b in after.values())
            if mx>max_before+1e-6 or total>sum_before-cell_size+1e-6:continue
            rank=(sum_before-total,max_before-mx,-k,-i,-h,-j)
            if rank0 is None or rank>rank0:rank0=rank;best=(proposed,after,(k,i,h,j))
    if deadline is not None and time.perf_counter()>=deadline:return no('deadline',tested)
    if best is None:return no('no_qualified_delivery_move',tested)
    proposed,after,move=best
    return proposed,{'reason':'positive_delivery_move','tested':tested,'move':list(move),
        'before':{k:{'outbound':a,'with_delivery':b} for k,(a,b) in before.items()},
        'after':{k:{'outbound':a,'with_delivery':b} for k,(a,b) in after.items()},
        'sum_before':sum_before,'sum_after':sum(b for a,b in after.values()),
        'max_before':max_before,'max_after':max(b for a,b in after.values()),
        'scope':'Same sites/counts/frozen prefixes; original epsilon/caps, explicit known return endpoint.'}
