class ExtensionMethods:
    def _sortie_admit(self,step,peer_goals):
        result=super()._sortie_admit(step,peer_goals)
        if result is not None or getattr(self,'F15_MODE','NONE')!='COURIER':return result
        if (getattr(self,'_f15_courier_count',0)>=2 or step-getattr(self,'_f15_courier_last',-1000)<120
                or int(self.carried_bombs_count())!=0 or self._sortie_state!='DOCK'
                or self._remaining_steps()<120):return result
        self._f15_courier_count=getattr(self,'_f15_courier_count',0)+1;self._f15_courier_last=step
        from swarm_rescue.solutions.courier_advisor import courier_advice
        begun=time.perf_counter()
        try:route,advice=courier_advice(self,step,peer_goals,seconds=.35)
        finally:self._diag_record_cost('courier_advisor_extra',begun)
        advice.update(owner=int(self.identifier or 0),step=int(step),stock=int(self.carried_bombs_count()),
                      missing_origins=[k for k in range(self.team_size) if k not in self.completion_certificates],
                      original_sortie_admitted=False)
        import json
        print('[F15_COURIER_ADVISOR]',json.dumps(advice,separators=(',',':')),flush=True)
        return result

    def _diag_state(self):
        state=self._diag_base_state()
        state['f15_mode']=getattr(self,'F15_MODE','NONE')
        state['completion_origins']=sorted(self.completion_certificates)
        state['f15_courier_advisor_count']=getattr(self,'_f15_courier_count',0)
        state['received_state_ages']={str(k):int(self.elapsed_timestep)-int(ts) for k,(ts,p,n) in self.fleet_states.items()}
        return state
