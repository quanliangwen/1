import ast
import heapq
import inspect
import math
import time
from pathlib import Path
import numpy as np
import cv2
from swarm_rescue.solutions import trust_region_cover as trust
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
from swarm_rescue.solutions.team_coverage import observed_wall_values, path_costs
from swarm_rescue.solutions.farthest_wall_cover import owner_travel_budget

def root_memory(memory):
    while isinstance(memory, GeometryPlanningMemory):
        memory = memory._memory
    return memory

def clone_view(view):
    result = object.__new__(GeometryPlanningMemory)
    result.__dict__.update(view.__dict__)
    result.free = view.free.copy()
    result._blocked = view.blocked()
    cached = getattr(view, '_coverage_values_cache', None)
    if cached is not None:
        result._coverage_values_cache = (cached[0], cached[1].copy(), cached[2].copy())
    return result

def context(params, prepared):
    memory = params['memory']
    radius = float(params['radius'])
    pm = clone_view(prepared) if prepared is not None else GeometryPlanningMemory(memory)
    confirmed, solids = observed_wall_values(pm, radius, return_solids=True)
    confirmed = np.asarray(confirmed, np.float32).copy()
    values = np.maximum(confirmed, trust._repeat_hit_support(pm))
    walkable = pm.free & ~pm.blocked() & ~solids
    allowed = walkable.copy()
    rr, cc = np.indices(pm.shape)
    xx = (cc + 0.5) * pm.CELL - pm.width / 2
    yy = pm.height / 2 - (rr + 0.5) * pm.CELL
    mask = params.get('forbidden_mask')
    if mask is not None:
        if np.asarray(mask).shape != pm.shape:
            return None
        allowed &= ~np.asarray(mask, bool)
    for p, r in params.get('forbidden_points', ()):
        allowed[(xx - p[0]) ** 2 + (yy - p[1]) ** 2 < float(r) ** 2] = False
    separation = 40.0 + 0.71 * pm.CELL
    for p in params['drops']:
        squared = (xx - p[0]) ** 2 + (yy - p[1]) ** 2
        values[squared <= radius ** 2 + 1e-08] = 0
        confirmed[squared <= radius ** 2 + 1e-08] = 0
        allowed[squared < separation ** 2] = False

    def scores(plan):
        mask = trust._coverage_mask(pm, [p for ps in plan.values() for p in ps], radius)
        return (float(values[mask].sum()), float(confirmed[mask].sum()))
    return {'pm': pm, 'values': values, 'confirmed': confirmed, 'walkable': walkable, 'allowed': allowed, 'xx': xx, 'yy': yy, 'separation': separation, 'scores': scores}

def centre_field(pm, walkable, sources, deadline):
    costs = np.full(pm.shape, np.inf)
    tentative = np.full(pm.shape, np.inf)
    queue = []
    for r, c in zip(*np.nonzero(sources)):
        tentative[r, c] = 0.0
        heapq.heappush(queue, (0.0, int(r), int(c)))
    popped = 0
    while queue and popped < 8192:
        if time.perf_counter() >= deadline:
            return None
        distance, r, c = heapq.heappop(queue)
        if distance > tentative[r, c] or np.isfinite(costs[r, c]):
            continue
        costs[r, c] = distance
        popped += 1
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)):
            nr, nc = (r + dr, c + dc)
            if not (0 <= nr < pm.shape[0] and 0 <= nc < pm.shape[1]) or not walkable[nr, nc]:
                continue
            if dr and dc and (not walkable[r + dr, c] or not walkable[r, c + dc]):
                continue
            proposal = distance + pm.CELL * (math.sqrt(2.0) if dr and dc else 1.0)
            if proposal < tentative[nr, nc]:
                tentative[nr, nc] = proposal
                heapq.heappush(queue, (proposal, nr, nc))
    return costs

def transport_advice(params, returned, prepared, seconds=1.0, centre_override=None):
    begun = time.perf_counter()
    deadline = begun + seconds
    c = context(params, prepared)
    if c is None:
        return {'reason': 'invalid_context'}
    pm = c['pm']
    radius = float(params['radius'])
    value0, confirmed0 = c['scores'](returned)
    if value0 <= 0 or confirmed0 <= 0:
        return {'reason': 'no_supported_incumbent'}
    raw = getattr(root_memory(params['memory']), 'nonwall_mask', None)
    if centre_override is None:
        if raw is None or np.asarray(raw).ndim != 2 or (not np.asarray(raw).any()):
            return {'reason': 'no_measured_centre'}
        sources = cv2.resize(np.asarray(raw, np.float32), (pm.shape[1], pm.shape[0]), interpolation=cv2.INTER_AREA) > 0
    else:
        sources = np.asarray(centre_override, bool).copy()
    if sources.shape != pm.shape:
        return {'reason': 'invalid_centre_shape'}
    sources &= c['walkable']
    if not sources.any():
        return {'reason': 'no_known_walkable_centre'}
    centre = centre_field(pm, c['walkable'], sources, deadline)
    if centre is None:
        return {'reason': 'centre_field_deadline'}
    fields = {}

    def field(p):
        cell = pm.world_to_cell(p)
        if cell not in fields:
            if time.perf_counter() >= deadline:
                return np.full(pm.shape, np.inf)
            fields[cell] = path_costs(pm, c['walkable'], cell)
        return fields[cell]
    clean = {int(k): (np.asarray(p, float), int(n)) for k, (p, n) in params['agents'].items() if p is not None and np.asarray(p).shape == (2,) and np.isfinite(p).all() and (int(n) > 0)}
    plans = {int(k): [np.asarray(p, float).copy() for p in ps] for k, ps in returned.items()}
    if any((ps and (k not in clean or len(ps) > clean[k][1]) for k, ps in plans.items())):
        return {'reason': 'invalid_incumbent_owner_or_count'}
    all_points = [p for ps in plans.values() for p in ps]
    if any((p.shape != (2,) or not np.isfinite(p).all() or (not c['allowed'][pm.world_to_cell(p)]) for p in all_points)):
        return {'reason': 'invalid_incumbent_geometry'}
    if any((np.linalg.norm(p - q) < c['separation'] - 1e-08 for i, p in enumerate(all_points) for q in all_points[i + 1:])):
        return {'reason': 'invalid_incumbent_spacing'}

    def length(k, points):
        prev = clean[k][0]
        total = 0.0
        for p in points:
            total += float(field(prev)[pm.world_to_cell(p)])
            prev = p
        return total
    lengths = {k: length(k, ps) for k, ps in plans.items() if ps}
    if any((not np.isfinite(v) or v > owner_travel_budget(params.get('travel_budget'), k) + 1e-06 for k, v in lengths.items())):
        return {'reason': 'invalid_incumbent_routes'}
    rc = int(math.ceil(radius / pm.CELL))
    ky, kx = np.mgrid[-rc:rc + 1, -rc:rc + 1]
    disk = ((kx * pm.CELL) ** 2 + (ky * pm.CELL) ** 2 <= radius ** 2 + 1e-08).astype(np.float32)
    best = None
    best_rank = None
    tested = 0
    for k, points in sorted(plans.items()):
        for slot, old in enumerate(points):
            if time.perf_counter() >= deadline:
                break
            old_cell = pm.world_to_cell(old)
            old_centre = float(centre[old_cell])
            if not np.isfinite(old_centre):
                continue
            fixed = [p for owner, ps in plans.items() for j, p in enumerate(ps) if not (owner == k and j == slot)]
            fixed_mask = trust._coverage_mask(pm, fixed, radius)
            residual = c['values'].copy()
            residual[fixed_mask] = 0
            confirmed = c['confirmed'].copy()
            confirmed[fixed_mask] = 0
            old_mask = trust._coverage_mask(pm, [old], radius)
            old_gain = float(residual[old_mask].sum())
            old_confirmed = float(confirmed[old_mask].sum())
            gains = cv2.filter2D(residual, -1, disk, borderType=cv2.BORDER_CONSTANT)
            cg = cv2.filter2D(confirmed, -1, disk, borderType=cv2.BORDER_CONSTANT)
            mask = c['allowed'].copy()
            mask &= gains >= old_gain - .005 * value0 - 1e-5
            mask &= cg >= old_confirmed - 1e-05
            mask &= (c['xx'] - old[0]) ** 2 + (c['yy'] - old[1]) ** 2 <= (radius * params.get('trust_radius_ratio', 1.25)) ** 2 + 1e-08
            for p in fixed:
                mask &= (c['xx'] - p[0]) ** 2 + (c['yy'] - p[1]) ** 2 >= c['separation'] ** 2 - 1e-08
            prev = clean[k][0] if slot == 0 else points[slot - 1]
            nxt = points[slot + 1] if slot + 1 < len(points) else None
            old_edge = float(field(prev)[old_cell]) + (float(field(old)[pm.world_to_cell(nxt)]) if nxt is not None else 0.0)
            grid = lengths[k] - old_edge + field(prev)
            if nxt is not None:
                grid = grid + field(nxt)
            mask &= np.isfinite(grid) & (grid <= min(lengths[k] + float(params.get('route_epsilon', 32.)), owner_travel_budget(params.get('travel_budget'), k)) + 1e-6)
            mask &= np.isfinite(centre) & (centre >= old_centre + 2. * pm.CELL - 1e-6)
            ids = np.flatnonzero(mask.ravel())
            ids = ids[np.argsort(-centre.ravel()[ids], kind='stable')[:8]]
            for flat in ids:
                if time.perf_counter() >= deadline:
                    break
                cell = tuple(map(int, np.unravel_index(int(flat), pm.shape)))
                point = pm.cell_to_world(cell)
                alt = {owner: [p.copy() for p in ps] for owner, ps in plans.items()}
                alt[k][slot] = point
                score, conf = c['scores'](alt)
                travel = length(k, alt[k])
                tested += 1
                if score < .995 * value0 - 1e-5 or conf < confirmed0 - 1e-05 or travel > min(lengths[k] + float(params.get('route_epsilon', 32.)), owner_travel_budget(params.get('travel_budget'), k)) + 1e-6:
                    continue
                rank = (float(centre[cell]) - old_centre, lengths[k] - travel, -k, -slot, -int(flat))
                if best_rank is None or rank > best_rank:
                    best_rank = rank
                    best = {'owner': k, 'slot': slot, 'target': point.tolist(), 'nominal': score, 'confirmed': conf, 'RED_before': lengths[k], 'RED_after': travel, 'known_centre_before': old_centre, 'known_centre_after': float(centre[cell])}
    return {'reason': 'positive_transport_slack' if best is not None and time.perf_counter() <= deadline else 'no_qualified_transport_slack', 'alternative': best, 'incumbent_nominal': value0, 'incumbent_confirmed': confirmed0, 'centre_sources': int(sources.sum()), 'tested': tested, 'seconds': time.perf_counter() - begun, 'deadline_reached': time.perf_counter() > deadline, 'scope': 'Own observed-centre distance proxy only, not actual BLUE travel/difficulty or official score.'}
