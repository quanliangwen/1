from pathlib import Path
import sys,json,time,traceback,types
Q=Path(__file__).resolve().parent
report={'status':'STARTED','checks':[],'game_rounds':0}
def check(n,v):
 assert v,n
 report['checks'].append(n)
try:
 sys.path.insert(0,str(Q/'workspace/src'));sys.path.insert(0,str(Q/'helper_source'))
 import numpy as np
 from delivery_schedule import improve_delivery
 from courier_advisor import courier_advice
 import transport_slack_advisor as transport
 from swarm_rescue.solutions.greedy_mapping import MapMemory
 from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
 from swarm_rescue.solutions import trust_region_cover as trust
 coords=np.array([0.,400.,64.,-96.]);D=np.abs(coords[:,None]-coords[None,:]);base={2:[2,3]}
 p,a=improve_delivery(base,{2:0},D,{2:1},{2:1000.},{},16.)
 check('actual_delivery_counterexample',p=={2:[3,2]} and a['reason']=='positive_delivery_move')
 check('original_delivery720',a['before'][2]['outbound']==224 and a['before'][2]['with_delivery']==720)
 check('reverse_delivery592',a['after'][2]['outbound']==256 and a['after'][2]['with_delivery']==592)
 check('outbound_epsilon32',a['after'][2]['outbound']==a['before'][2]['outbound']+32)
 check('source_unchanged',base=={2:[2,3]})
 p,b=improve_delivery(base,{2:0},D,{2:1},{2:590.},{},16.)
 check('complete_delivery_cap',p==base and b['reason']=='no_qualified_delivery_move')
 p,b=improve_delivery(base,{2:0},D,{2:1},{2:1000.},{},16.,route_epsilon=31.)
 check('original_route_epsilon_bound',p==base)
 p,b=improve_delivery(base,{2:0},D,{2:1},{2:1000.},{2:100.},16.)
 check('prefix_cost_preserved',b['before'][2]['outbound']==324 and b['after'][2]['outbound']==356)
 p,b=improve_delivery(base,{2:0},D,{2:1},{2:1000.},{},16.,deadline=time.perf_counter()-1)
 check('deadline_abstention',p==base and b['reason']=='deadline')
 p,b=improve_delivery({2:[2],7:[3]},{2:0,7:1},D,{2:1,7:1},{2:1000,7:1000},{},16.)
 check('one_point_set_not_invented',sorted(sum(p.values(),[]))==[2,3])
 def courier_fixture():
  m=MapMemory(640,256);m.free[:]=True
  return types.SimpleNamespace(identifier=2,carried_bombs_count=lambda:0,submitted=False,pose=np.zeros(2),rally=np.zeros(2),
    _sortie_state='DOCK',completion_certificates={0:100,2:100},team_size=3,
    fleet_states={0:(200,np.array([0.,0.]),0),1:(150,np.array([300.,0.]),1),2:(200,np.zeros(2),0)},
    STATE_FRESH_STEPS=120,_sortie_docked_step=100,last_peer_step={0:190},_step_seconds=.1,
    _remaining_steps=lambda:500.,assignment_reports={},GOAL_LEASE_STEPS=600,memory=m)
 d=courier_fixture();free=d.memory.free.copy();r,a=courier_advice(d,200,[],seconds=5.)
 check('known_courier_positive',r is not None and a['reason']=='positive_known_courier_rendezvous')
 check('known_courier_budget',a['conservative_steps']<=min(a['remaining_after_own_compute']-24,a['remaining_after_own_compute']/2))
 check('known_reverse_return',a['reverse_return_length']==a['known_outbound_length'])
 check('no_completion_fabricated',d.completion_certificates=={0:100,2:100} and d._sortie_state=='DOCK')
 check('no_own_array_mutation',np.array_equal(free,d.memory.free))
 for name in ['inventory','leader','all_certificates','no_contact','too_late','unknown','stale_origin','deadline','not_docked','another_courier']:
  d=courier_fixture();seconds=5.
  if name=='inventory':d.carried_bombs_count=lambda:1
  if name=='leader':d.identifier=0
  if name=='all_certificates':d.completion_certificates[1]=150
  if name=='no_contact':d.last_peer_step={}
  if name=='too_late':d._remaining_steps=lambda:100.
  if name=='unknown':d.memory.free[:]=False
  if name=='stale_origin':d.fleet_states[1]=(-500,np.array([300.,0.]),1)
  if name=='deadline':seconds=0.
  if name=='not_docked':d._sortie_state='RETURN'
  if name=='another_courier':d.fleet_states[1]=(200,np.array([300.,0.]),0)
  r,a=courier_advice(d,200,[],seconds=seconds);check('courier_abstains_'+name,r is None)
 d=courier_fixture();d.pose=np.array([24.,0.]);r,a=courier_advice(d,200,[],seconds=5.)
 check('actual_contact_dock_not_exact_rally_cell',r is not None and np.linalg.norm(a['contact_dock_point'])<40)
 def transport_fixture(noise=.001,confirmed_loss=False,shift_start=False):
  m=MapMemory(256,128);m.free[:]=True;pm=GeometryPlanningMemory(m)
  values=np.zeros(m.shape,np.float32);values[1,8]=1.
  if confirmed_loss:values[3,12]=.001
  pm._coverage_values_cache=(64.,values,np.zeros(m.shape,bool))
  support=np.zeros(m.shape,np.float32);support[3,12]=noise
  allowed=np.zeros(m.shape,bool);allowed[3,10]=allowed[3,6]=True
  m.nonwall_mask=np.zeros(m.hit_shape,bool);m.nonwall_mask[4*8:5*8,14*8:15*8]=True
  base={7:[m.cell_to_world((3,10))]};agents={7:(m.cell_to_world((4,9) if shift_start else (4,8)),1)}
  params={'memory':m,'agents':agents,'drops':[],'radius':64.,'travel_budget':{7:100.},'forbidden_mask':~allowed,'forbidden_points':(),'route_epsilon':32.,'trust_radius_ratio':1.25}
  return m,pm,base,params,support
 saved=trust._repeat_hit_support
 try:
  m,pm,base,p,support=transport_fixture();trust._repeat_hit_support=lambda memory:support.copy()
  a=transport.transport_advice(p,base,pm,seconds=5.)
  check('tiny_nominal_slack_positive',a['reason']=='positive_transport_slack')
  check('confirmed_preserved',a['alternative']['confirmed']>=a['incumbent_confirmed']-1e-5)
  check('nominal_half_percent_bound',a['alternative']['nominal']>=.995*a['incumbent_nominal']-1e-5)
  check('centre_two_cells_increase',a['alternative']['known_centre_after']>=a['alternative']['known_centre_before']+32-1e-5)
  for name,kwargs in [('nominal_excess',{'noise':.01}),('confirmed_loss',{'noise':.003,'confirmed_loss':True})]:
   m,pm,base,p,support=transport_fixture(**kwargs);trust._repeat_hit_support=lambda memory:support.copy()
   a=transport.transport_advice(p,base,pm,seconds=5.);check('transport_rejects_'+name,a['reason']!='positive_transport_slack')
  m,pm,base,p,support=transport_fixture(shift_start=True);trust._repeat_hit_support=lambda memory:support.copy()
  a=transport.transport_advice(p,base,pm,seconds=5.);check('explicit_32px_epsilon_supported',a['reason']=='positive_transport_slack' and a['alternative']['RED_after']<=a['alternative']['RED_before']+32+1e-5)
  a=transport.transport_advice(p,base,pm,seconds=0.);check('transport_deadline_abstains',a['reason']!='positive_transport_slack')
  m.nonwall_mask[:]=False;a=transport.transport_advice(p,base,pm,seconds=5.);check('no_measured_centre_abstains',a['reason']=='no_measured_centre')
 finally:trust._repeat_hit_support=saved
 report.update(status='PASS')
except BaseException:report.update(status='FAIL',error=traceback.format_exc());raise
finally:
 (Q/'FIRST_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'checks':len(report['checks']),'error':report.get('error')}))
