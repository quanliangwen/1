from pathlib import Path
import ast
F=Path(__file__).resolve().parent;O=F.parent/'F13_completion_joint_transport_20261027'
tree=ast.parse((O/'diagnostic_layout_advisors.py').read_text())
names={'root_memory','clone_view','context','centre_field','transport_advice'}
tree.body=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.FunctionDef) and n.name in names]
s=ast.unparse(tree)+'\n'
replacements={
 "np.abs(gains - old_gain) <= 1e-05":"gains >= old_gain - .005 * value0 - 1e-5",
 "grid <= lengths[k] + 1e-06":"grid <= min(lengths[k] + float(params.get('route_epsilon', 32.)), owner_travel_budget(params.get('travel_budget'), k)) + 1e-6",
 "centre >= old_centre + pm.CELL - 1e-06":"centre >= old_centre + 2. * pm.CELL - 1e-6",
 "score < value0 - 1e-05":"score < .995 * value0 - 1e-5",
 "travel > lengths[k] + 1e-06":"travel > min(lengths[k] + float(params.get('route_epsilon', 32.)), owner_travel_budget(params.get('travel_budget'), k)) + 1e-6",
 "'positive_transport_tie'":"'positive_transport_slack'",
 "'no_qualified_transport_tie'":"'no_qualified_transport_slack'"}
for a,b in replacements.items():assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
ast.parse(s);p=F/'transport_slack_advisor.py';assert not p.exists();p.write_text(s,encoding='utf-8')
print('Prepared frozen P03 readonly advisor; no source candidate or game')
