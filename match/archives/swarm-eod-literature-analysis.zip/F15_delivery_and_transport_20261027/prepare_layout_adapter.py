from pathlib import Path
import ast
F=Path(__file__).resolve().parent;O=F.parent/'F14_fixed_sites_schedule_20261027'
text=(O/'schedule_observer_revision1.py').read_text();tree=ast.parse(text)
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='schedule_advice')
s=ast.get_source_segment(text,fn).replace('def schedule_advice(','def delivery_advice(',1)
s=s.replace('forbidden_points,forbidden_mask,prepared,deadline):','forbidden_points,forbidden_mask,prepared,deadline,rally):',1)
s=s.replace('for owner in (prefixes or {}): plans.setdefault(int(owner),[])','for owner in agents: plans.setdefault(int(owner),[])')
marker='    cells=[pm.world_to_cell(p) for p in nodes]';assert s.count(marker)==1
s=s.replace(marker,'    ends={k:node(rally) for k in plans}\n'+marker)
i=s.index('    answers={}');s=s[:i]+'''    alternative,advice=improve_delivery(indexed,starts,matrix,ends,caps,prefix_costs,pm.CELL,32.,deadline)
    if advice['reason']=='positive_delivery_move':
        advice['alternative']={str(k):[nodes[n].tolist() for n in ps] for k,ps in alternative.items()}
    advice.update(fields=len(fields),suffix_counts={k:len(v) for k,v in plans.items()},prefix_costs=prefix_costs,full_caps=caps,
                  deadline_reached=time.perf_counter()>deadline)
    return advice
'''
header='''import time,json
import numpy as np
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
from swarm_rescue.solutions.team_coverage import observed_wall_values,path_costs
from swarm_rescue.solutions.farthest_wall_cover import owner_travel_budget
from swarm_rescue.solutions.delivery_schedule import improve_delivery
from swarm_rescue.solutions.transport_slack_advisor import transport_advice

'''
tail='''
def observe_layout(memory,agents,drops,radius,result,full_budget,suffix_budget,prefixes,
                   forbidden_points,forbidden_mask,prepared):
    root=memory
    while isinstance(root,GeometryPlanningMemory):root=root._memory
    if not getattr(root,'_f15_layout_enabled',False) or not any(result.values()):return
    step=int(getattr(root,'step',0));count=getattr(root,'_f15_layout_count',0)
    if count>=2 or step-getattr(root,'_f15_layout_last',-1000)<120:return
    root._f15_layout_count=count+1;root._f15_layout_last=step
    common={'owner':int(getattr(root,'identifier',0)),'step':step,'probe':count+1}
    begun=time.perf_counter();rally=getattr(root,'_f15_rally',None)
    if rally is None:advice={'reason':'no_own_rally'}
    else:advice=delivery_advice(memory,agents,drops,radius,result,full_budget,prefixes,
                                forbidden_points,forbidden_mask,prepared,begun+.5,np.asarray(rally,float))
    advice.update(common,kind='delivery',seconds=time.perf_counter()-begun)
    print('[F15_LAYOUT_ADVISOR]',json.dumps(advice,separators=(',',':')),flush=True)
    params={'memory':memory,'agents':agents,'drops':drops,'radius':radius,'travel_budget':suffix_budget,
            'forbidden_points':forbidden_points,'forbidden_mask':forbidden_mask,'route_epsilon':32.,'trust_radius_ratio':1.25}
    begun=time.perf_counter();advice=transport_advice(params,result,prepared,seconds=.5)
    advice.update(common,kind='transport',seconds=time.perf_counter()-begun)
    print('[F15_LAYOUT_ADVISOR]',json.dumps(advice,separators=(',',':')),flush=True)
'''
source=header+s+tail;ast.parse(source);p=F/'layout_advisors.py';assert not p.exists();p.write_text(source,encoding='utf-8')
print('Read-only P01/P03 adapter prepared; same live prepared context, no candidate/game')
