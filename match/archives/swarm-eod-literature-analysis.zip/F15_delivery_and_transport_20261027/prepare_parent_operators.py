from pathlib import Path
import ast,base64,json,hashlib,subprocess,shlex
F=Path(__file__).resolve().parent;O=F.parent/'F13_completion_joint_transport_20261027'
assert not(F/'PARENT_OPERATORS.json').exists()
bundle={}
for name,e in json.loads((O/'PARENT_OPERATORS.json').read_text()).items():
 s=base64.b64decode(e['runner_base64']).decode().replace('F13','F15')
 s=s.replace("'F15_LATE_COMPLETION_ADVISOR'","'F15_COURIER_ADVISOR'")
 ast.parse(s);bundle[name]={'runner_base64':base64.b64encode(s.encode()).decode(),'sha256':hashlib.sha256(s.encode()).hexdigest(),'map':e['map']}
maps={'PARENT_M05_DIAG':'Map05','PARENT_M04_DIAG':'Map04','P01_DIAG':'Map04','P02_DIAG':'Map05','P03_DIAG':'Map04'}
for n,d in [('PARENT_OPERATORS.json',bundle),('DIAGNOSTIC_MAP_BINDINGS.json',maps)]:(F/n).write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
for n in ['sync_metadata.py','verify_diagnostic_raw.py','read_live.py']:
 s=(O/n).read_text().replace(O.name,F.name).replace('F13','F15')
 if n=='verify_diagnostic_raw.py':s=s.replace("['PARENT_M05_DIAG', 'PARENT_M04_DIAG', 'N01_DIAG', 'N02_DIAG', 'N03_DIAG']",repr(list(maps)))
 if n=='read_live.py':s=s.replace("out['latest_late_advice']=[x for x in lines if x.startswith('[F15_LATE_COMPLETION_ADVISOR]')][-5:]","out['courier_advice']=[json.loads(x[len('[F15_COURIER_ADVISOR] '):]) for x in lines if x.startswith('[F15_COURIER_ADVISOR] ')]")
 ast.parse(s);(F/n).write_text(s,encoding='utf-8')
s=(O/'stage_parent_observer.py').read_text().replace(O.name,F.name).replace('f13diag_','f15diag_').replace('F13_MODE','F15_MODE')
s=s.replace("O/'FIRST_RESULT.json'","O/'QUALIFICATION_RESULT.json'")
s=s.replace("mode='LATE' if m=='Map05' else 'LAYOUT'","mode='COURIER' if m=='Map05' else 'LAYOUT'")
s=s.replace("pre=(H/'F08_diagnosis_led_three_20261026/BASELINE_DIAG/preflight.py').read_text()","pre=(O/'preflight.py').read_text()")
s=s.replace('Counters plus explicitly declared bounded readonly nearby-completion/joint/transport advisors','Counters plus bounded delivery-route / missing-certificate courier / nominal-slack transport advisors; no original plan or command changes')
assert 'F08_diagnosis_led_three' not in s
ast.parse(s);(F/'stage_parent_observer.py').write_text(s,encoding='utf-8')
code=r'''
from pathlib import Path
import json,sys
F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F15_delivery_and_transport_20261027')
assert json.loads((F/'observer_qualification/QUALIFICATION_RESULT.json').read_text())['status']=='PASS'
for n,d in json.load(sys.stdin).items():assert not(F/n).exists();(F/n).write_text(json.dumps(d,indent=2)+'\n')
print('Two qualified-parent diagnostic operators prepared, no game yet')
'''
print(subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps({'PARENT_OPERATORS.json':bundle,'DIAGNOSTIC_MAP_BINDINGS.json':maps}).encode()).decode())
