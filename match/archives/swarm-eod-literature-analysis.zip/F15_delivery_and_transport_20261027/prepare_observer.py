from pathlib import Path
import ast,json,base64,subprocess,shlex
F=Path(__file__).resolve().parent;O=F.parent/'F13_completion_joint_transport_20261027';ref=O/'parent_source_reference'
trust=(ref/'trust_region_cover.py').read_text();marker='    pm=GeometryPlanningMemory(memory) if _prepared is None else _prepared\n';assert trust.count(marker)==1
trust=trust.replace(marker,marker+"    if getattr(memory,'_f15_layout_enabled',False): memory._f15_live_prepared=pm\n")
lns=(ref/'team_coverage_lns.py').read_text().replace('    prepared=None\n','    _f15_full_budget=travel_budget\n    prepared=None\n',1)
marker='    return refine_trust_region(memory,agents,drops,radius,base,travel_budget=travel_budget,forbidden_points=forbidden_points,forbidden_mask=forbidden_mask,_prepared=prepared)'
assert lns.count(marker)==1
lns=lns.replace(marker,'''    try:
        result=refine_trust_region(memory,agents,drops,radius,base,travel_budget=travel_budget,forbidden_points=forbidden_points,forbidden_mask=forbidden_mask,_prepared=prepared)
        if getattr(memory,'_f15_layout_enabled',False):
            from swarm_rescue.solutions.layout_advisors import observe_layout
            observe_layout(memory,agents,drops,radius,result,_f15_full_budget,travel_budget,reserved_prefixes,
                           forbidden_points,forbidden_mask,getattr(memory,'_f15_live_prepared',prepared))
        return result
    finally:
        if '_f15_live_prepared' in vars(memory):delattr(memory,'_f15_live_prepared')''')
tree=ast.parse((O/'diagnostic_mixin.py').read_text().replace('F13','F15').replace('_f13','_f15'))
cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='DiagnosticMixin')
cls.body=[n for n in cls.body if not(isinstance(n,ast.FunctionDef) and n.name=='_maybe_place')]
next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_diag_state').name='_diag_base_state'
extra=ast.parse((F/'observer_extensions.py').read_text()).body[0].body;cls.body.extend(extra)
diag=ast.unparse(tree)+'\n'
marker="    def _build_fleet_plan(self, step):\n        started = time.perf_counter()";assert diag.count(marker)==1
diag=diag.replace(marker,"    def _build_fleet_plan(self, step):\n        self.memory._f15_rally = None if self.rally is None else np.asarray(self.rally, float).copy()\n        started = time.perf_counter()")
assets={'trust_region_cover.py':trust,'team_coverage_lns.py':lns,'diagnostic_mixin.py':diag,
        'delivery_schedule.py':(F/'delivery_schedule.py').read_text(),'courier_advisor.py':(F/'courier_advisor_revision1.py').read_text(),
        'transport_slack_advisor.py':(F/'transport_slack_advisor.py').read_text(),'layout_advisors.py':(F/'layout_advisors.py').read_text()}
for s in assets.values():ast.parse(s)
payload={n:base64.b64encode(s.encode()).decode() for n,s in assets.items()}
code=r'''
from pathlib import Path
import json,sys,base64,hashlib,shutil,ast
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F15_delivery_and_transport_20261027'
assert json.loads((F/'helper_revision1/FIRST_RESULT.json').read_text())['status']=='PASS'
Q=F/'observer_qualification';P=json.loads((F/'PREDECLARATION.json').read_text())['parent'];S=Q/'source'
if Q.exists():
 assert not(Q/'FIRST_RESULT.json').exists() and not(Q/'first_console.log').exists()
 backup=Q/'prequalification_v0';assert not backup.exists();backup.mkdir();shutil.copytree(S,backup/'source');shutil.copy2(Q/'SOURCE_BINDING.json',backup/'SOURCE_BINDING.json')
else:
 Q.mkdir();shutil.copytree(Path(P['path'])/'source',S)
for n,b in json.load(sys.stdin).items():(S/n).write_bytes(base64.b64decode(b))
p=S/'my_drone_eval.py';s=(Path(P['path'])/'source/my_drone_eval.py').read_text();assert s.count('class MyDroneEval(')==1
s=s.replace('class MyDroneEval(','class BaseParent(',1)+"\nfrom swarm_rescue.solutions.diagnostic_mixin import DiagnosticMixin\nclass MyDroneEval(DiagnosticMixin,BaseParent):\n    F15_MODE='LAYOUT'\n";p.write_text(s)
for p in S.glob('*.py'):ast.parse(p.read_text())
(Q/'SOURCE_BINDING.json').write_text(json.dumps({'parent':P,'observer_source_files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in S.iterdir() if p.is_file()},'scope':'Readonly diagnostic; corrected courier helper revision1, original failed small QA preserved. No candidate.'},indent=2)+'\n')
print(json.dumps({'source_files':len(list(S.iterdir())),'no_game_or_candidate':True}))
'''
r=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps(payload).encode());p=F/('observer_prepared_v1.txt' if (F/'observer_prepared.txt').exists() else 'observer_prepared.txt');assert not p.exists();p.write_bytes(r);print(r.decode())
