"""Read-only known-route rendezvous toward an actually received missing origin."""
import math,time
import numpy as np
from swarm_rescue.solutions.completion_consensus import _sortie_known_route


def courier_advice(drone,step,peer_goals,seconds=.35):
    begun=time.perf_counter();deadline=begun+seconds
    def no(reason):return None,{'reason':reason,'seconds':time.perf_counter()-begun}
    own=int(drone.identifier or 0)
    if (int(drone.carried_bombs_count())!=0 or drone.submitted or drone.pose is None or drone.rally is None
            or drone._sortie_state!='DOCK' or np.linalg.norm(drone.pose-drone.rally)>=40):return no('not_idle_contact_dock')
    certs=drone.completion_certificates;missing=[k for k in range(drone.team_size) if k not in certs and k!=own]
    if not missing:return no('no_missing_origin')
    active=[k for k,(ts,p,n) in drone.fleet_states.items() if p is not None and 0<=step-ts<drone.STATE_FRESH_STEPS]
    if not active or own==min(active):return no('coordinator_keeps_dock')
    docked=drone._sortie_docked_step
    if docked is None or step-docked<24 or not any(k!=own and docked<ts<=step and step-ts<100 for k,ts in drone.last_peer_step.items()):return no('no_post_dock_message_contact')
    # Elect within received fresh empty states, excluding the current coordinator.
    empty=[k for k,(ts,p,n) in drone.fleet_states.items() if p is not None and n==0
           and 0<=step-ts<drone.STATE_FRESH_STEPS and k!=min(active)]
    if empty and own!=min(empty):return no('another_received_empty_courier_has_priority')
    rate=max(.001,float(getattr(drone,'_step_seconds',None) or .05))
    remaining=float(drone._remaining_steps())-max(0.,begun-getattr(drone,'_f15_control_started',begun))/rate
    if remaining<120:return no('insufficient_remaining')
    causal=[]
    for origin in missing:
        record=drone.fleet_states.get(origin)
        if record is None:continue
        ts,position,inventory=record
        if position is None or not 0<=step-ts<=600:continue
        point=np.asarray(position,float)
        if point.shape!=(2,) or not np.isfinite(point).all():continue
        causal.append((origin,int(ts),'received_position',point))
        report=drone.assignment_reports.get(origin)
        if report is not None:
            stamp,stock,goal,since=report
            if (goal is not None and stock>0 and 0<=step-stamp<=600 and 0<=step-since<drone.GOAL_LEASE_STEPS):
                goal=np.asarray(goal,float)
                if goal.shape==(2,) and np.isfinite(goal).all():causal.append((origin,int(stamp),'received_leased_goal',goal))
    if not causal:return no('no_recent_causal_missing_origin')
    m=drone.memory;walkable=m.free & ~m.blocked();start=m.world_to_cell(drone.pose)
    walkable=walkable.copy();walkable[start]=True
    rr,cc=np.indices(m.shape);xx=(cc+.5)*m.CELL-m.width/2;yy=m.height/2-(rr+.5)*m.CELL
    metric=np.hypot(xx-drone.pose[0],yy-drone.pose[1])
    available_now=remaining-(time.perf_counter()-begun)/rate
    max_out=min(available_now-24.,available_now/2.)-48.-float(m.CELL)
    allowed=walkable & (metric>=48.) & (metric<=max_out)
    for p in peer_goals:
        if p is not None:allowed &= (xx-p[0])**2+(yy-p[1])**2>=48.**2
    candidates=[]
    for origin,stamp,kind,point in causal:
        progress=float(np.linalg.norm(point-drone.pose))-np.hypot(xx-point[0],yy-point[1])
        rank=np.where(allowed & (progress>=48.),progress,-np.inf)
        distinct=[]
        for flat in np.argsort(-rank.ravel(),kind='stable'):
            if time.perf_counter()>=deadline:break
            cell=tuple(map(int,np.unravel_index(int(flat),m.shape)))
            if not np.isfinite(rank[cell]):break
            if any((cell[0]-r)**2+(cell[1]-c)**2<4 for r,c in distinct):continue
            distinct.append(cell)
            candidates.append((float(rank[cell]),origin,stamp,kind,cell))
            if len(distinct)>=8:break
    candidates.sort(key=lambda x:(-x[0],x[1],x[4]))
    tested=[]
    for progress,origin,stamp,kind,cell in candidates:
        if len(tested)>=8 or time.perf_counter()>=deadline:break
        if any((cell[0]-r)**2+(cell[1]-c)**2<4 for r,c in tested):continue
        tested.append(cell)
        path=_sortie_known_route(m,start,cell,walkable,deadline,max_pops=8192)
        if path is None:continue
        route=[m.cell_to_world(c) for c in path[1:]]
        points=[np.asarray(drone.pose,float)]+route
        length=sum(float(np.linalg.norm(b-a)) for a,b in zip(points,points[1:]))
        available=remaining-(time.perf_counter()-begun)/rate;demand=length+48.
        if demand>min(available-24.,available/2.) or time.perf_counter()>deadline:continue
        return route,{'reason':'positive_known_courier_rendezvous','origin':origin,'received_stamp':stamp,'causal_kind':kind,
            'goal':m.cell_to_world(cell).tolist(),'contact_dock_point':np.asarray(drone.pose,float).tolist(),
            'known_outbound_length':length,'reverse_return_length':length,'conservative_steps':demand,
            'remaining_after_own_compute':available,'progress_toward_received_point':progress,'tested':len(tested),
            'seconds':time.perf_counter()-begun,'scope':'Opportunity only; no inferred completion, no guaranteed peer encounter. Real map-bearing certificate receipt needed.'}
    return no('no_bounded_known_courier_route')
