import time,json
import numpy as np
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
from swarm_rescue.solutions.team_coverage import observed_wall_values,path_costs
from swarm_rescue.solutions.farthest_wall_cover import owner_travel_budget
from swarm_rescue.solutions.delivery_schedule import improve_delivery
from swarm_rescue.solutions.transport_slack_advisor import transport_advice

def delivery_advice(memory,agents,drops,radius,result,full_budget,prefixes,
                    forbidden_points,forbidden_mask,prepared,deadline,rally):
    if prepared is None:return {'reason':'missing_exact_prepared_context'}
    # Copy mutable per-view caches to keep advisor writes outside original planning state.
    pm=object.__new__(GeometryPlanningMemory);pm.__dict__.update(prepared.__dict__)
    pm.free=prepared.free.copy();pm._blocked=prepared.blocked()
    cached=getattr(prepared,'_coverage_values_cache',None)
    if cached is not None:pm._coverage_values_cache=(cached[0],cached[1].copy(),cached[2].copy())
    _,solids=observed_wall_values(pm,radius,return_solids=True)
    walkable=pm.free & ~pm.blocked() & ~solids;allowed=walkable.copy()
    rr,cc=np.indices(pm.shape);xx=(cc+.5)*pm.CELL-pm.width/2;yy=pm.height/2-(rr+.5)*pm.CELL
    if forbidden_mask is not None:
        if np.asarray(forbidden_mask).shape!=pm.shape:return {'reason':'invalid_forbidden'}
        allowed &= ~np.asarray(forbidden_mask,bool)
    for p,r in forbidden_points:allowed[(xx-p[0])**2+(yy-p[1])**2<float(r)**2]=False
    separation=40.+.71*pm.CELL
    for p in drops:allowed[(xx-p[0])**2+(yy-p[1])**2<separation**2]=False
    plans={int(k):[np.asarray(p,float).copy() for p in ps] for k,ps in result.items()}
    for owner in agents: plans.setdefault(int(owner),[])
    if len(plans)>5 or sum(map(len,plans.values()))>10 or any(len(v)>2 for v in plans.values()):return {'reason':'unsupported_size'}
    points=[p for ps in plans.values() for p in ps]
    if any(p.shape!=(2,) or not np.isfinite(p).all() or not allowed[pm.world_to_cell(p)] for p in points):return {'reason':'invalid_original_site'}
    if any(np.linalg.norm(p-q)<separation-1e-8 for i,p in enumerate(points) for q in points[i+1:]):return {'reason':'invalid_original_spacing'}
    nodes=[];indexed={};starts={};prefix_costs={};caps={};fields={}
    def node(p):nodes.append(np.asarray(p,float));return len(nodes)-1
    for k,ps in plans.items():indexed[k]=[node(p) for p in ps]
    for k in plans:
        if k not in agents or len(plans[k])>int(agents[k][1]):return {'reason':'invalid_original_owner'}
        starts[k]=node(agents[k][0]);caps[k]=owner_travel_budget(full_budget,k)
    ends={k:node(rally) for k in plans}
    cells=[pm.world_to_cell(p) for p in nodes]
    if any(not walkable[cell] for cell in cells):return {'reason':'unknown_start_or_target'}
    def field(cell):
        if cell not in fields:
            if time.perf_counter()>=deadline:return None
            fields[cell]=path_costs(pm,walkable,cell)
        return fields[cell]
    for k in plans:
        prefix_costs[k]=0.
        if k in (prefixes or {}):
            position,target=(np.asarray(p,float) for p in prefixes[k])
            if not np.array_equal(nodes[starts[k]],target):return {'reason':'prefix_start_mismatch'}
            source=pm.world_to_cell(position);goal=pm.world_to_cell(target)
            if not walkable[source] or not walkable[goal]:return {'reason':'prefix_unreachable'}
            f=field(source)
            if f is None:return {'reason':'deadline'}
            prefix_costs[k]=float(f[goal])
    matrix=np.full((len(nodes),len(nodes)),np.inf)
    for i,cell in enumerate(cells):
        f=field(cell)
        if f is None:return {'reason':'deadline','fields':len(fields)}
        for j,other in enumerate(cells):matrix[i,j]=f[other]
    alternative,advice=improve_delivery(indexed,starts,matrix,ends,caps,prefix_costs,pm.CELL,32.,deadline)
    if advice['reason']=='positive_delivery_move':
        advice['alternative']={str(k):[nodes[n].tolist() for n in ps] for k,ps in alternative.items()}
    advice.update(fields=len(fields),suffix_counts={k:len(v) for k,v in plans.items()},prefix_costs=prefix_costs,full_caps=caps,
                  deadline_reached=time.perf_counter()>deadline)
    return advice

def observe_layout(memory,agents,drops,radius,result,full_budget,suffix_budget,prefixes,
                   forbidden_points,forbidden_mask,prepared):
    root=memory
    while isinstance(root,GeometryPlanningMemory):root=root._memory
    if not getattr(root,'_f15_layout_enabled',False) or not any(result.values()):return
    step=int(getattr(root,'step',0));count=getattr(root,'_f15_layout_count',0)
    if count>=2 or step-getattr(root,'_f15_layout_last',-1000)<120:return
    root._f15_layout_count=count+1;root._f15_layout_last=step
    common={'owner':int(getattr(root,'identifier',0)),'step':step,'probe':count+1}
    begun=time.perf_counter();rally=getattr(root,'_f15_rally',None)
    if rally is None:advice={'reason':'no_own_rally'}
    else:advice=delivery_advice(memory,agents,drops,radius,result,full_budget,prefixes,
                                forbidden_points,forbidden_mask,prepared,begun+.5,np.asarray(rally,float))
    advice.update(common,kind='delivery',seconds=time.perf_counter()-begun)
    print('[F15_LAYOUT_ADVISOR]',json.dumps(advice,separators=(',',':')),flush=True)
    params={'memory':memory,'agents':agents,'drops':drops,'radius':radius,'travel_budget':suffix_budget,
            'forbidden_points':forbidden_points,'forbidden_mask':forbidden_mask,'route_epsilon':32.,'trust_radius_ratio':1.25}
    begun=time.perf_counter();advice=transport_advice(params,result,prepared,seconds=.5)
    advice.update(common,kind='transport',seconds=time.perf_counter()-begun)
    print('[F15_LAYOUT_ADVISOR]',json.dumps(advice,separators=(',',':')),flush=True)
