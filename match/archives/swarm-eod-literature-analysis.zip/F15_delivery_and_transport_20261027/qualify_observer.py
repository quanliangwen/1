from pathlib import Path
import ast,json,base64,subprocess,shlex
F=Path(__file__).resolve().parent;O=F.parent/'F14_fixed_sites_schedule_20261027'
pre=(O/'preflight_revision1.py').read_text()
marker="assert [c.__name__ for c in MyDroneEval.__mro__[1:3]]==['ScheduleObservationMixin','DiagnosticMixin']"
assert pre.count(marker)==1;pre=pre.replace(marker,"assert MyDroneEval.__mro__[1].__name__=='DiagnosticMixin'")
ast.parse(pre);p=F/'preflight.py';assert not p.exists();p.write_text(pre,encoding='utf-8')
payload={'test':base64.b64encode((F/'observer_tests.py').read_bytes()).decode(),'preflight':base64.b64encode(pre.encode()).decode()}
code=r'''
from pathlib import Path
import json,sys,base64,hashlib,shutil,subprocess,os,ast
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F15_delivery_and_transport_20261027';Q=F/'observer_qualification'
assert not(Q/'FIRST_RESULT.json').exists() and not(Q/'first_console.log').exists()
blue=Path(json.loads((H/'F07_evidence_three_directions_20261026/infrastructure/PREDECLARATION.json').read_text())['blue_workspace'])
W=Q/'workspace';assert not W.exists();shutil.copytree(blue,W,ignore=shutil.ignore_patterns('solutions','__pycache__','*.pyc','.git','.pytest_cache'));sol=W/'src/swarm_rescue/solutions';sol.mkdir()
for p in (Q/'source').iterdir():shutil.copy2(p,W/'req.txt' if p.name=='req.txt' else sol/p.name)
d=json.load(sys.stdin)
for n,key in [('observer_tests.py','test'),('preflight.py','preflight')]:
 b=base64.b64decode(d[key]);ast.parse(b.decode());(Q/n).write_bytes(b)
binding=json.loads((Q/'SOURCE_BINDING.json').read_text());(Q/'STAGING.json').write_text(json.dumps({'workspace':str(W),'source_files':binding['observer_source_files']})+'\n')
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with (Q/'first_console.log').open('x') as log:r=subprocess.run(['bash',str(R/'run_server.sh'),'-u',str(Q/'observer_tests.py')],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
report=json.loads((Q/'FIRST_RESULT.json').read_text())
if r.returncode!=0 or report['status']!='PASS':print(json.dumps({'status':report['status'],'checks':len(report['checks']),'error':report.get('error')}));raise SystemExit(1)
with (Q/'preflight_first_console.log').open('x') as log:r=subprocess.run(['bash',str(R/'run_server.sh'),'-u',str(Q/'preflight.py')],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert r.returncode==0 and json.loads((Q/'PREFLIGHT.json').read_text())['status']=='PASS'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result={'status':'PASS','observer_checks':len(report['checks']),'preflight_first_pass':True,'source_binding_sha256':sha(Q/'SOURCE_BINDING.json'),'preflight_sha256':sha(Q/'preflight.py'),'observer_first_result_sha256':sha(Q/'FIRST_RESULT.json'),'native_game_rounds':0}
(Q/'QUALIFICATION_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
'''
r=subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps(payload).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert not(F/'observer_first_console.txt').exists();(F/'observer_first_console.txt').write_bytes(r.stdout+r.stderr);print((r.stdout+r.stderr).decode(errors='replace'));raise SystemExit(r.returncode)
