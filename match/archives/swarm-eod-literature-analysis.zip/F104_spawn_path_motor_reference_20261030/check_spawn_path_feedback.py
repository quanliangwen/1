"""Correct a declared model omission before trusting loaded motor evidence."""
from pathlib import Path
import ast,hashlib,json,time,traceback
import numpy as np
F=Path(__file__).resolve().parent;H=F.parent
specs=[(w,d,0,'sdk_noisy_mean') for w in [68.63162928880607,77.56230966173388] for d in [1.,-1.]]
declaration=dict(native_games=0,production_changed=False,horizon=7200,
 cases=[dict(width=w,direction=d,fixture=s,feedback=m) for w,d,s,m in specs],
 correction='Earlier fresh Bomb had empty path. Official _spawn_bombs_from_entries adds one pose at spawn and grasp does not clear it. Add that exact single pose and call actual Bomb.pre_step each tick, updating pose then actual force.',
 unchanged='Same F102 actual public drive/recover, real grasp joint, one-step SDK odometry/CompassAR1, iid range2.5,160px finite side walls, initial contact24/velocity0/trim0.',
 purpose='Check model fidelity and matched wide control before new contact/finite-wall cases. No game, target ranking or all-state trapping claim.')
(F/'PREDECLARATION.json').write_text(json.dumps(declaration,indent=2)+'\n')
def main():
 assert json.loads((H/'F100_raster_boundary_pilot_20261030/STATUS.json').read_text())['status']=='COMPLETE_FINITE_STAGED_CAMPAIGN'
 tree=ast.parse((H/'F73_sensor_feedback_falsification_20261030/check_actual_sensor_feedback.py').read_text())
 fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='definitions')
 ns={'H':H,'ast':ast};exec(compile(ast.Module(body=[fn],type_ignores=[]),'existing_reference_definitions_only','exec'),ns)
 _,env=ns['definitions']()
 source=(H/'F102_observed_width_motor_reference_20261030/GENERATED_REFERENCE.py').read_text()
 needle='    bomb.pm_body.position = (24.0, 0.0)';assert source.count(needle)==1
 source=source.replace(needle,needle+'''
    from swarm_rescue.simulation.utils.pose import Pose
    bomb.add_pose_to_path(Pose(np.array([24.,0.])))
    assert bomb.path.length()==1
    return_force_ticks=0
''')
 needle='        bomb.compute_movement()';assert source.count(needle)==1
 source=source.replace(needle,'''        bomb.pre_step()
        return_force_ticks += int(any(abs(c)>1e-12 for c in bomb.follow_path()))''')
 needle='return dict(feedback=feedback,';assert source.count(needle)==1
 source=source.replace(needle,"return dict(spawn_path_length=bomb.path.length(),return_force_ticks=return_force_ticks,feedback=feedback,",1)
 (F/'GENERATED_REFERENCE.py').write_text(source);exec(compile(source,'spawn_path_corrected_reference','exec'),env)
 rows=[];started=time.perf_counter()
 for w,d,s,m in specs:
    r=env['run'](w,d,s,m);r.pop('trajectory',None);rows.append(dict(width=w,direction=d,fixture=s,result=r))
    (F/'PROGRESS.json').write_text(json.dumps(dict(completed=len(rows),seconds=time.perf_counter()-started,cases=rows),indent=2)+'\n')
    print(json.dumps(rows[-1]),flush=True)
 out=dict(status='COMPLETE_SPAWN_PATH_CORRECTED_MOTOR_REFERENCE',cases=rows,seconds=time.perf_counter()-started,
   native_games=0,production_changed=False,source_sha256=hashlib.sha256(source.encode()).hexdigest(),declaration=declaration)
 (F/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status=out['status'],seconds=out['seconds'])))
if __name__=='__main__':
 try:main()
 except Exception:
  p=F/'FIRST_ERROR.json'
  if not p.exists():p.write_text(json.dumps(dict(traceback=traceback.format_exc(),native_games=0),indent=2)+'\n')
  raise
