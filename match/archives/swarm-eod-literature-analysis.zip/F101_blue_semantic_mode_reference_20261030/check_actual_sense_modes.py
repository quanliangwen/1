"""Uploaded public BLUE function bodies on fresh hypothetical observations."""
from pathlib import Path
from types import SimpleNamespace
import ast,hashlib,json,math
import numpy as np
F=Path(__file__).resolve().parent;S=F.parent/'F91_public_blue_cluster_recheck_20261030/reference_source'
sources={p.name:p.read_text(encoding='utf-8') for p in S.glob('*.py')}
types=SimpleNamespace(BOMB='fixture_BOMB',DRONE='fixture_DRONE',DISPOSAL_CENTER='fixture_DEPOT')
env=dict(np=np,math=math,DroneSemanticSensor=SimpleNamespace(TypeEntity=types),
 distance=lambda a,b:float(np.linalg.norm(np.asarray(a[:2])-np.asarray(b[:2]))))
methods={}
for filename,cls,names in [('two_stage_rescue.py','TwoStageRescue',['resolve','_remember','consolidate_tracks']),
 ('rescue_shared.py','SensorRescue',['update_cargo']),('rolling_rescue.py','RollingRescue',['_sense'])]:
 tree=ast.parse(sources[filename]);body=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==cls)
 nodes=[n for n in body.body if isinstance(n,ast.FunctionDef) and n.name in names];assert len(nodes)==len(names)
 exec(compile(ast.Module(body=nodes,type_ignores=[]),filename,'exec'),env);methods.update({n.name:env[n.name] for n in nodes})
C=type('FreshPublicSenseFixture',(),methods)
def fresh(carrying,phase,step):
 x=C();x.identifier=0;x.serial=0;x.aliases={};x.bombs={};x.pickup_origins={};x.queue=[];x.task=None
 x.pose=np.zeros(2);x.heading=0.;x.elapsed_timestep=step;x.carrying=carrying;x.phase=phase;x.home=None
 x.velocity_trim=np.zeros(2);x._last_grasper=True;x.reward=1.;x.grasped_bombs=lambda:[object()] if x.carrying else []
 x.measured_gps_position=lambda:np.zeros(2);x.measured_compass_angle=lambda:0.;x.odometer_values=lambda:np.zeros(3)
 x.lidar_values=lambda:np.full(181,300.);x.lidar_rays_angles=lambda:np.linspace(-math.pi,math.pi,181)
 x.grid=SimpleNamespace(observe=lambda *a:None)
 if carrying:x.serial=1;x.task=(0,1);x.bombs[x.task]=[0.,0.,step,1]
 return x
rows=[]
for phase in ['explore','join','dispose']:
 for carrying in [False,True]:
  for residue in [0,1]:
   x=fresh(carrying,phase,200+residue);held=x.task
   hit=SimpleNamespace(entity_type=types.BOMB,distance=50.,angle=0.,grasped=False)
   x.semantic_values=lambda:[hit]
   velocity,hits,depots=x._sense()
   free=[k for k,v in x.bombs.items() if v[3]==0]
   assert len(free)==len(hits)==1 and (not carrying or x.bombs[held][3]==1)
   rows.append(dict(phase=phase,carrying=carrying,step_residue=residue,new_free_records=len(free),semantic_hits=len(hits)))
body=next(n for n in ast.parse(sources['two_stage_rescue.py']).body if isinstance(n,ast.ClassDef) and n.name=='TwoStageRescue')
control=next(n for n in body.body if isinstance(n,ast.FunctionDef) and n.name=='control')
prefix=control.body[:3]
assert isinstance(prefix[2],ast.Assign) and isinstance(prefix[2].value,ast.Call) and prefix[2].value.func.attr=='_sense'
out=dict(status='PASS_PUBLIC_BLUE_SENSE_IS_CARGO_AND_PHASE_INDEPENDENT',rows=rows,
 control_prefix=[ast.unparse(n) for n in prefix],source_sha256={n:hashlib.sha256(t.encode()).hexdigest() for n,t in sources.items()},
 native_games=0,BLUE_private_state_read=False,production_changed=False,
 conclusion='The actual control calls _sense before mode decisions, and the actual _sense remembers visible free bombs even while carrying. The hypothesis that cargo/phase alone disables redetection is false in these source paths.',
 limitations='Constructed semantic hits only. Does not show a remaining bomb is actually visible through35 rays, walls, other bombs, traffic or grasp geometry; not a full BLUE scheduler test.')
(F/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['rows','source_sha256']}))
