"""License-free J17 release validation: one pilot, conditional one five-map cohort."""
from pathlib import Path
import fcntl,importlib.util,json,os,time,traceback
from os_resource_observer import ResourceObserver
R=Path('/home/junhao/quan/parallel_test_solver/match')
H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
F=H/'F107_J17_portable_release_20261030'
read=lambda p:json.loads(p.read_text())
spec=importlib.util.spec_from_file_location('frozen_runner',H/'F32_official_sdk_20261028/FIVE_MAP_REBASELINE/run_offline.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.F,b.D=F,read(F/'PREDECLARATION.json')
b.NAMES,b.BLUE=b.D['selection'],b.D['blue_binding'];b.WBLUE=Path(b.BLUE['blue_workspace'])
b.STATE.update(phase=F.name,decisions=[],max_native_rounds=12,release_validation=True)
def summarize():
    b.save(F/'RESULT.json',dict(b.STATE,automatic_promotion=False,official_submission_ready=False))
b.summarize=summarize
def first_review(G):
    started=time.monotonic()
    while not (G/'CLIENT_FIRST_RAW_REVIEW.json').exists():
        if b.stop_requested():return False
        if time.monotonic()-started>7200:raise TimeoutError('First Windows review timeout')
        b.state('AWAIT_FIRST_WINDOWS_REVIEW',current=G.name);time.sleep(5)
    q=read(G/'CLIENT_FIRST_RAW_REVIEW.json');a=read(G/'RAW_ARCHIVE_RECEIPT.json')
    assert q['status']=='PASS' and q['archive_sha256']==a['sha256']
    return True
def pilot_gate():
    G=F/'J17P_DIAG';matrix=read(G/'RESULT.json');r=matrix['jobs']['Map01']['rounds'][0]
    raw=Path(read(G/'LAUNCH.json')['result'])/'Map01_red/console.log'
    calls=[]
    for line in raw.read_text(errors='replace').splitlines():
        if line.startswith('[EXACT_LAYOUT] '):
            a=json.loads(line.split(' ',1)[1])
            if a.get('solver_backend')=='license_free_highs_explicit_route_separation':calls.append(a)
    gate=dict(status='PASS' if (r['placed']==r['expected']==10 and not r['red_max_walltime_reached']
        and not r['blue']['max_walltime_reached'] and r['full_score']>=75.
        and any(c.get('selected_slots',0)>0 for c in calls)) else 'FAIL',
        map='Map01',score=r['full_score'],placed=r['placed'],red_wall_hit=r['red_max_walltime_reached'],
        blue_wall_hit=r['blue']['max_walltime_reached'],actual_new_backend_calls=len(calls),
        positive_certified_backend_calls=sum(c.get('selected_slots',0)>0 for c in calls),
        frozen_gate='10/10, no RED/BLUE wall-clock hit, score>=75, at least one actual certified positive HiGHS layout',
        purpose='Submission portability smoke test, not original J17 score inheritance or rank promotion')
    b.save(F/'PILOT_GATE.json',gate);return gate['status']=='PASS'
def main():
    lease=(F/'coordinator.lock').open('a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not (F/'RUN_ONCE.json').exists()
    b.save(F/'RUN_ONCE.json',dict(utc=b.utc(),pid=os.getpid(),starttime_ticks=Path('/proc/self/stat').read_text().split()[21],driver_sha256=b.sha(__file__),study_sha256=b.sha(F/'PREDECLARATION.json')))
    b.STATE['started_utc']=b.utc();b.validate_frozen();summarize()
    observer=ResourceObserver();observer.start()
    try:
        for item in b.D['schedule']:
            if item['cohort']=='FIVE' and not pilot_gate():
                b.STATE['skipped'].append(dict(**item,reason='Frozen portability pilot gate failed; no full-five retry'))
                break
            if b.stop_requested():b.state('STOPPED_BEFORE_NEXT_COHORT');summarize();return
            b.D['maps']=item['maps'];started=time.time()
            if not b.run_cohort(item):b.state('STOPPED_BEFORE_NATIVE_START');summarize();return
            G=F/('J17P_'+item['cohort']);b.save(G/'OS_RESOURCE_REVIEW.json',observer.review(started,time.time()))
            if not first_review(G):b.state('STOPPED_AWAITING_REVIEW');summarize();return
        b.STATE['decisions'].append(dict(decision='REPORT_ALL_PORTABLE_RESULTS_SEPARATELY_FROM_ORIGINAL_J17',no_retry=True))
        b.state('COMPLETE_FINITE_STAGED_CAMPAIGN',current=None);summarize()
    except Exception:
        b.save(F/'FIRST_ERROR.json',dict(utc=b.utc(),traceback=traceback.format_exc(),first_native_failure=b.STATE['first_native_failure'],no_automatic_retry=True))
        b.state('STOPPED_FIRST_ERROR_NO_RETRY');summarize();raise
    finally:observer.close()
if __name__=='__main__':main()
