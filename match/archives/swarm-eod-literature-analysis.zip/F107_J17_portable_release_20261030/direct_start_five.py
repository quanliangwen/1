"""Explicit human-authorized CPU/load-gate override for the unstarted FIVE only.

The original driver, declaration, pilot and clocks remain immutable. This is a
continuation after the idle coordinator exited, never a game retry.
"""
from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,time,traceback
R=Path('/home/junhao/quan/parallel_test_solver/match')
H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
F=H/'F107_J17_portable_release_20261030'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('original_f107',F/'run_offline.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);b=m.b
auth=read(F/'DIRECT_START_AUTHORIZATION.json')
assert auth['human_request']=='直接启动测试'
assert auth['driver_sha256']==sha(Path(__file__))
assert auth['original_predeclaration_sha256']==sha(F/'PREDECLARATION.json')
assert not (F/'J17P_FIVE').exists()
assert not (F/'DIRECT_START_RUN_ONCE.json').exists()
old=read(F/'PRE_DIRECT_START_STATE.json')
assert not old['first_native_failure']
assert len(old['completed'])==1 and old['completed'][0]['cohort']=='DIAG'
assert read(F/'PILOT_GATE.json')['status']=='PASS'
b.STATE.clear();b.STATE.update(old)
b.STATE.update(pid=os.getpid(),status='STARTING_AUTHORIZED_HIGH_LOAD_FIVE',current=None,
    workers={},map_status={},evaluation_resource_scope='EXPLICIT_USER_CPU_AND_LOAD_GATE_OVERRIDE',
    direct_start_authorization=str(F/'DIRECT_START_AUTHORIZATION.json'),
    original_coordinator_pid=auth['original_coordinator_pid'])
used=False
def acquire_direct_once():
    global used
    assert not used,'Only one pending five-map cohort authorized'
    used=True
    if b.stop_requested():return None
    lock=(R/'solver_study/serial_evaluation.lock').open('a+')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    try:
        a=read(R/'solver_study/heuristic_20261016.json')
        assert not a.get('active_processes') and not a.get('current_formal_active')
        obs=b.resource();cfg=b.D['resource_gate']
        assert obs['memory_available_GiB']>=cfg['memory_available_GiB_min']
        assert obs['disk_free_GiB']>=cfg['disk_free_GiB_min']
        b.save(F/'DIRECT_START_RESOURCE_RECEIPT.json',dict(utc=b.utc(),observed=obs,
            bypassed=['cpu_busy_max','load_per_cpu_max','consecutive_clean_samples_delay'],
            retained=['single_global_lock','empty_native_registry','memory_floor','disk_floor',
                'original_SDK_BLUE_RED_payload','original_clocks_threads_no_external_seed'],
            applies_to='J17P_FIVE only; no later cohorts',human_request='直接启动测试'))
        b.STATE['direct_start_resource']=obs
        return lock
    except BaseException:
        lock.close();raise
b.acquire_when_ready=acquire_direct_once
def main():
    lease=(F/'coordinator.lock').open('a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    b.save(F/'DIRECT_START_RUN_ONCE.json',dict(utc=b.utc(),pid=os.getpid(),
        starttime_ticks=Path('/proc/self/stat').read_text().split()[21],
        driver_sha256=sha(Path(__file__)),authorization_sha256=sha(F/'DIRECT_START_AUTHORIZATION.json')))
    b.validate_frozen();m.summarize()
    observer=m.ResourceObserver();observer.start()
    try:
        item=next(x.copy() for x in b.D['schedule'] if x['cohort']=='FIVE')
        item['evaluation_resource_scope']='EXPLICIT_USER_CPU_AND_LOAD_GATE_OVERRIDE'
        item['resource_authorization_sha256']=sha(F/'DIRECT_START_AUTHORIZATION.json')
        b.D['maps']=item['maps'];started=time.time()
        if not b.run_cohort(item):
            b.state('STOPPED_BEFORE_NATIVE_START');m.summarize();return
        G=F/'J17P_FIVE';b.save(G/'OS_RESOURCE_REVIEW.json',observer.review(started,time.time()))
        if not m.first_review(G):
            b.state('STOPPED_AWAITING_REVIEW');m.summarize();return
        b.STATE['decisions'].append(dict(decision='REPORT_ALL_PORTABLE_RESULTS_WITH_HIGH_LOAD_SCOPE',
            human_request='直接启动测试',no_retry=True,not_resource_matched_to_original_J17=True))
        b.state('COMPLETE_FINITE_STAGED_CAMPAIGN',current=None);m.summarize()
    except Exception:
        error=dict(utc=b.utc(),traceback=traceback.format_exc(),
            first_native_failure=b.STATE['first_native_failure'],no_automatic_retry=True)
        b.save(F/'DIRECT_START_FIRST_ERROR.json',error)
        b.save(F/'FIRST_ERROR.json',error)
        b.state('STOPPED_FIRST_ERROR_NO_RETRY');m.summarize();raise
    finally:observer.close()
if __name__=='__main__':main()
