from pathlib import Path
import ast,hashlib,json,zipfile
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
F=H/'F107_J17_portable_release_20261030';P=H/'F106_J17_five_map_20261030';V=H/'J17_v07_release_validation_20261030'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
assert not (F/'PREDECLARATION.json').exists()
parent=read(P/'PREDECLARATION.json');build=read(V/'BUILD.json')
assert read(V/'MODEL_EQUIVALENCE_CHECK.json')['status']=='PASS'
for name in ['numpy1','numpy2','clean_sdk','native_main']:
    q=read(V/('ABI_'+name+'.json'));assert q['status']=='PASS' and q['submission_zip_sha256']==build['zip_sha256']
C=F/'J17P';C.mkdir();source=C/'source';source.mkdir()
with zipfile.ZipFile(build['zip']) as z:
    assert {n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}==build['source_files']
    for n in z.namelist():(source/n).write_bytes(z.read(n))
save(C/'BUILD.json',build)
q=read(V/'ABI_native_main.json');save(C/'RESEARCH_QUALIFICATION.json',q)
(F/'versions/J17P').mkdir(parents=True);save(F/'versions/J17P/QUALIFICATION.json',q)
launch=(P/'launch_campaign.py').read_text().replace(P.name,F.name).replace('max_native_rounds=10','max_native_rounds=12')
launch=launch.replace('Original gate then one complete fresh J17 Map01-05 RED+BLUE cohort; no retries','Original gate, Map01 portability pilot, first Windows review, then conditional Map01-05; no retries')
(F/'launch_campaign.py').write_text(launch)
d={k:parent[k] for k in ['sdk_commit','sdk_files','blue_binding','blue_binding_sha256','resource_gate','frozen_files']}
d.update(phase=F.name,selection=['J17P'],maps=['Map01'],seed=None,
    versions={'J17P':dict(original_zip=build['zip'],original_zip_sha256=build['zip_sha256'],source=str(source),source_files=build['source_files'])},
    explicit_human_authorization='给出J17的比赛提交版本；没有或不清楚Gurobi许可，采用免许可证适配',
    schedule=[dict(version='J17P',cohort='DIAG',label='sdk_e2f022b_f107_J17P_DIAG',maps=['Map01']),dict(version='J17P',cohort='FIVE',label='sdk_e2f022b_f107_J17P_FIVE',maps=['Map01','Map02','Map03','Map04','Map05'])],
    max_native_rounds=12,automatic_promotion=False,additional_cohorts=False,
    pilot_gate=dict(placed=10,score_min=75.,no_RED_BLUE_clock_hit=True,actual_positive_certified_HiGHS_plan=True),
    original_J17_mean_not_inherited=77.85136509918851,
    changed_scope='Same finite coverage/cardinality master, Hall/separation/inventory rows and exact route certificates; HiGHS external route cuts replace Gurobi lazy callbacks. SDK-inherited NumPy/OpenCV plus SciPy1.17.1; no Pandas override or Gurobi dependency.',
    clock_policy='Normal official clock termination retained and flagged, actual native exception stops chain; no retry/seed change.')
for p in [F/'run_offline.py',F/'os_resource_observer.py',F/'launch_campaign.py',V/'MODEL_EQUIVALENCE_CHECK.json',V/'ABI_numpy1.json',V/'ABI_numpy2.json',V/'ABI_clean_sdk.json',V/'ABI_native_main.json']:
    if p.suffix=='.py':ast.parse(p.read_text())
    d['frozen_files'][str(p)]=sha(p)
save(F/'PREDECLARATION.json',d)
print(json.dumps(dict(status='PREPARED_NOT_STARTED',zip_sha256=build['zip_sha256'],max_native_rounds=12)))
