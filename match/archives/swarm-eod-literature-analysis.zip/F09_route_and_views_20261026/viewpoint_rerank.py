"""Bounded public-memory viewpoint reranking; no peer objects or truth input."""
import math
import time
import cv2
import numpy as np

MAX_CANDIDATES=8
MAX_PEER_VIEWS=2
HORIZON=240.


def visible_cells(cell,weights,opaque,cell_size,horizon=HORIZON):
    row,col=map(int,cell)
    radius=int(math.ceil(horizon/cell_size))
    r0,r1=max(0,row-radius),min(weights.shape[0],row+radius+1)
    c0,c1=max(0,col-radius),min(weights.shape[1],col+radius+1)
    rr,cc=np.nonzero(weights[r0:r1,c0:c1]>.001);rr+=r0;cc+=c0
    keep=(rr-row)**2+(cc-col)**2<=(horizon/cell_size)**2
    ends=np.column_stack((rr[keep],cc[keep]))
    if not len(ends):return np.empty(0,dtype=np.intp)
    delta=ends-np.asarray(cell)
    count=np.maximum(2,2*np.max(np.abs(delta),axis=1)+1)
    ids=np.arange(int(count.max()))[None,:]
    sample=ids<(count-1)[:,None]
    rs=np.rint(row+ids*delta[:,0,None]/(count-1)[:,None]).astype(int)
    cs=np.rint(col+ids*delta[:,1,None]/(count-1)[:,None]).astype(int)
    rs=np.clip(rs,0,weights.shape[0]-1);cs=np.clip(cs,0,weights.shape[1]-1)
    clear=~np.any(opaque[rs,cs]&sample,axis=1)
    return ends[clear,0]*weights.shape[1]+ends[clear,1]


def fresh_peer_views(memory):
    result=[]
    for record in getattr(memory,'reservations',()):
        if not isinstance(record,(list,tuple)) or len(record)!=4:continue
        age,goal,position,peer=record
        try:
            if int(peer)==int(memory.identifier) or not 0<=float(age)<80:continue
            goal=np.asarray(goal,float);position=np.asarray(position,float)
            if goal.shape!=(2,) or position.shape!=(2,) or not np.isfinite(goal).all() or not np.isfinite(position).all():continue
            if abs(goal[0])>=memory.width/2 or abs(goal[1])>=memory.height/2:continue
            distance=float(np.linalg.norm(goal-position))
            if distance>120.:continue
            cell=memory.world_to_cell(goal)
            if not memory.free[cell]:continue
            result.append((float(age),int(peer),cell,distance/2.))
        except (ValueError,TypeError,OverflowError):continue
    result.sort(key=lambda r:(r[0],r[1]))
    seen=set();unique=[]
    for item in result:
        if item[1] in seen:continue
        seen.add(item[1]);unique.append(item)
        if len(unique)==MAX_PEER_VIEWS:break
    return unique


def rerank_views(memory,position,score,mode):
    started=time.perf_counter()
    stats=getattr(memory,'viewpoint_diagnostics',None)
    if stats is None:
        stats={'calls':0,'reranked':0,'suggested_changes':0,'candidates':0,'peer_views':0,'seconds':0.,'returned_rerank_goal':0}
        memory.viewpoint_diagnostics=stats
    stats['calls']+=1
    memory._viewpoint_factors={}
    memory._viewpoint_last=None
    try:
        peers=fresh_peer_views(memory) if mode=='peer_overlap' else []
        if mode=='peer_overlap' and not peers:return score
        flat=np.flatnonzero(np.isfinite(score.ravel())&(score.ravel()>0))
        if not len(flat):return score
        top=flat[np.argsort(-score.ravel()[flat],kind='stable')[:MAX_CANDIDATES]].tolist()
        previous=getattr(memory,'exploration_goal',None)
        if previous is not None:
            old=memory.world_to_cell(previous);index=int(old[0])*memory.shape[1]+int(old[1])
            if np.isfinite(score[old]) and score[old]>0 and index not in top:top.append(index)
        opaque=cv2.resize((memory.hits>=2).astype(np.float32),(memory.shape[1],memory.shape[0]),interpolation=cv2.INTER_AREA)>=.035
        weights=(~memory.free&~opaque).astype(np.float32)
        if mode=='occlusion':
            weak=np.ones(memory.shape,np.float32)
            bits=getattr(memory,'bearing_bits',None)
            if bits is not None:
                counts=np.unpackbits(np.asarray(bits,np.uint8)[...,None],axis=-1).sum(axis=-1)
                weak=cv2.resize((counts<2).astype(np.float32),(memory.shape[1],memory.shape[0]),interpolation=cv2.INTER_AREA)
            weights+=.25*opaque.astype(np.float32)*weak
        if not np.any(weights>0):return score
        peer_masks=[]
        for age,peer,cell,eta in peers:
            if opaque[cell]:continue
            mask=np.zeros(memory.shape,bool)
            mask.ravel()[visible_cells(cell,weights,opaque,memory.CELL)]=True
            peer_masks.append((age,eta,mask))
        if mode=='peer_overlap' and not peer_masks:return score
        result=np.full(score.shape,-np.inf)
        rr,cc=np.indices(memory.shape)
        for index in top:
            cell=tuple(map(int,np.unravel_index(index,memory.shape)))
            ids=visible_cells(cell,weights,opaque,memory.CELL)
            total=float(weights.ravel()[ids].sum())
            factor=1.
            if total>0:
                if mode=='occlusion':
                    radius=((rr-cell[0])**2+(cc-cell[1])**2)*memory.CELL**2<=HORIZON**2
                    naive=float(weights[radius].sum())
                    factor=max(.15,min(1.,total/max(.001,naive)))
                else:
                    own_eta=float(np.linalg.norm(np.asarray(position)-memory.cell_to_world(cell)))/2.
                    overlap=np.zeros(memory.shape,np.float32)
                    for age,eta,mask in peer_masks:
                        if eta+24.>own_eta:continue
                        overlap[mask]=np.maximum(overlap[mask],.5*(1.-age/80.))
                    marginal=float((weights.ravel()[ids]*(1.-overlap.ravel()[ids])).sum())
                    factor=max(.5,min(1.,marginal/total))
            elif mode=='occlusion':factor=.15
            memory._viewpoint_factors[cell]=factor
            result[cell]=score[cell]*factor
        raw=tuple(map(int,np.unravel_index(np.argmax(score),score.shape)))
        chosen=tuple(map(int,np.unravel_index(np.argmax(result),result.shape)))
        memory._viewpoint_last=(raw,chosen)
        stats['reranked']+=1;stats['suggested_changes']+=int(raw!=chosen)
        stats['candidates']+=len(top);stats['peer_views']+=len(peer_masks)
        return result
    finally:stats['seconds']+=time.perf_counter()-started


def record_returned_view(memory,goal):
    pair=getattr(memory,'_viewpoint_last',None)
    if pair is not None and goal is not None and pair[0]!=pair[1] and memory.world_to_cell(goal)==pair[1]:
        memory.viewpoint_diagnostics['returned_rerank_goal']+=1
