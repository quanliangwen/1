"""Own-memory shortest-path tree reuse, scoped to one planning transaction."""
import heapq
import math
import time
import numpy as np


def route_fields(memory,clearance,walkable,start):
    stats=getattr(memory,'route_reuse_diagnostics',None)
    if stats is None:
        stats={'queries':0,'hits':0,'searches':0,'lookup_seconds':0.,'search_seconds':0.,'reused_search_seconds':0.}
        memory.route_reuse_diagnostics=stats
    stats['queries']+=1
    started=time.perf_counter()
    cache=getattr(memory,'_route_transaction_fields',None)
    if cache is not None:
        for old_start,old_walkable,old_clearance,cost,parent,seconds in cache:
            if start==old_start and np.array_equal(walkable,old_walkable) and np.array_equal(clearance,old_clearance):
                stats['hits']+=1
                stats['lookup_seconds']+=time.perf_counter()-started
                stats['reused_search_seconds']+=seconds
                return cost,parent
    stats['lookup_seconds']+=time.perf_counter()-started
    begun=time.perf_counter()
    height,width=memory.shape
    adjacency=[[] for _ in range(height*width)]
    penalties=[.30*max(0.,(40.-float(v))/40.) for v in clearance.ravel()]
    for dr,dc in ((-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)):
        r0,r1=max(0,-dr),min(height,height-dr)
        c0,c1=max(0,-dc),min(width,width-dc)
        valid=walkable[r0:r1,c0:c1]&walkable[r0+dr:r1+dr,c0+dc:c1+dc]
        if dr and dc:valid &= walkable[r0+dr:r1+dr,c0:c1]&walkable[r0:r1,c0+dc:c1+dc]
        rr0,cc0=np.nonzero(valid);origins=(rr0+r0)*width+cc0+c0
        weight=math.sqrt(2) if dr and dc else 1.
        for source in origins.tolist():
            target=source+dr*width+dc
            adjacency[source].append((target,weight*(1.+penalties[target])))
    source=int(start[0])*width+int(start[1]);costs=[math.inf]*(height*width)
    costs[source]=0.;parents={};queue=[(0.,source)]
    while queue:
        distance,node=heapq.heappop(queue)
        if distance>costs[node]:continue
        for neighbor,weight in adjacency[node]:
            proposal=distance+weight
            if proposal<costs[neighbor]:
                costs[neighbor]=proposal;parents[neighbor]=node
                heapq.heappush(queue,(proposal,neighbor))
    cost=np.asarray(costs).reshape(memory.shape)
    parent={divmod(child,width):divmod(previous,width) for child,previous in parents.items()}
    elapsed=time.perf_counter()-begun
    stats['searches']+=1;stats['search_seconds']+=elapsed
    if cache is not None and len(cache)<4:
        cache.append((tuple(start),walkable.copy(),clearance.copy(),cost,parent,elapsed))
    return cost,parent


class RouteTransactionMixin:
    def _plan_route(self,step,returning,peer_goals):
        memory=self.memory
        previous=getattr(memory,'_route_transaction_fields',None)
        if previous is not None:
            return super()._plan_route(step,returning,peer_goals)
        memory._route_transaction_fields=[]
        try:
            return super()._plan_route(step,returning,peer_goals)
        finally:
            memory._route_transaction_fields=None
