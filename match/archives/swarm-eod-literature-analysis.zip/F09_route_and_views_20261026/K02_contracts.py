    from swarm_rescue.solutions.viewpoint_rerank import visible_cells,fresh_peer_views,rerank_views,record_returned_view
    from swarm_rescue.solutions import fast_exploration as new_fast
    import types
    def memory(rows=12,cols=20,identifier=0):
        m=types.SimpleNamespace(shape=(rows,cols),width=cols*16,height=rows*16,CELL=16,identifier=identifier,
            free=np.ones((rows,cols),bool),hits=np.zeros((rows*8,cols*8),np.uint8),reservations=[],exploration_goal=None)
        m.world_to_cell=lambda p:(min(rows-1,max(0,int((m.height/2-p[1])/16))),min(cols-1,max(0,int((p[0]+m.width/2)/16))))
        m.cell_to_world=lambda c:np.array([(c[1]+.5)*16-m.width/2,m.height/2-(c[0]+.5)*16])
        return m
    weights=np.zeros((12,20),np.float32);weights[:,11:]=1.;opaque=np.zeros(weights.shape,bool);opaque[:,10]=True
    check('visibility_closed_wall_blocks_unknown',len(visible_cells((6,9),weights,opaque,16.,160.))==0)
    check('visibility_open_wall_has_gain',len(visible_cells((6,9),weights,np.zeros(weights.shape,bool),16.,160.))>0)
    check('visibility_empty_support_returns_empty',len(visible_cells((6,9),np.zeros(weights.shape),opaque,16.))==0)
    wall_weights=opaque.astype(float)
    check('visible_surface_endpoint_not_itself_occluder',len(visible_cells((6,9),wall_weights,opaque,16.))>0)
    m=memory();m.reservations=[(0,m.cell_to_world((3,3)),m.cell_to_world((3,4)),1),(80,m.cell_to_world((3,3)),m.cell_to_world((3,4)),2),(0,m.cell_to_world((3,3)),m.cell_to_world((3,4)),0),(0,None,None,3),(0,np.array([np.nan,0]),np.zeros(2),4)]
    check('fresh_public_peer_filter',len(fresh_peer_views(m))==1 and fresh_peer_views(m)[0][1]==1)
    m.reservations=[(i,m.cell_to_world((3,3+i)),m.cell_to_world((3,3+i)),i+1) for i in range(5)]
    check('bounded_peer_view_count',len(fresh_peer_views(m))==2)
    m=memory();m.free[:,11:]=False;m.free[6,15]=True;m.hits[:,80:88]=2
    scores=np.full(m.shape,-np.inf);scores[6,9]=10.;scores[6,15]=9.
    old=scores.copy();result=rerank_views(m,m.cell_to_world((6,5)),scores,'occlusion')
    check('occlusion_reranks_visible_view',np.unravel_index(np.argmax(result),m.shape)==(6,15))
    check('source_score_not_mutated',np.array_equal(old,scores))
    check('positive_occlusion_factor_floor',all(.15<=f<=1. for f in m._viewpoint_factors.values()))
    check('candidate_work_is_bounded',m.viewpoint_diagnostics['candidates']<=9)
    record_returned_view(m,m.cell_to_world((6,15)))
    check('returned_reranked_goal_logged',m.viewpoint_diagnostics['returned_rerank_goal']==1)
    m=memory(64,64)
    m.free[14:17,11:14]=False;m.free[42:45,39:42]=False
    first,second=(12,12),(40,40)
    scores=np.full(m.shape,-np.inf);scores[first]=10.;scores[second]=9.
    p=m.cell_to_world((30,30));g=m.cell_to_world(first)
    m.reservations=[(0,g,g.copy(),1)]
    result=rerank_views(m,p,scores,'peer_overlap')
    check('fresh_peer_overlap_reduces_duplicate_view',np.unravel_index(np.argmax(result),m.shape)==second)
    check('peer_discount_is_soft_and_bounded',all(.5<=f<=1. for f in m._viewpoint_factors.values()))
    m.reservations=[(80,g,g.copy(),1)]
    check('stale_peer_exact_fallback',np.array_equal(rerank_views(m,p,scores,'peer_overlap'),scores))
    m.reservations=[]
    check('disconnected_no_messages_exact_fallback',np.array_equal(rerank_views(m,p,scores,'peer_overlap'),scores))
    m.reservations=[(0,g,g.copy(),0)]
    check('self_goal_not_peer_evidence',np.array_equal(rerank_views(m,p,scores,'peer_overlap'),scores))
    m.reservations=[(0,np.array([10000.,0]),np.zeros(2),1)]
    check('outside_public_arena_goal_fallback',np.array_equal(rerank_views(m,p,scores,'peer_overlap'),scores))
    m.reservations=[(0,g,g.copy(),1)]
    nearby=m.cell_to_world((12,13))
    result=rerank_views(m,nearby,scores,'peer_overlap')
    check('peer_must_arrive_before_own_view_margin',m._viewpoint_factors[first]==1.)
    reference=H/'PJ01_submission_team615_v05_20261026/source/fast_exploration.py'
    original_fast=types.ModuleType('f09_reference_view_fast');exec(compile(reference.read_text(),str(reference),'exec'),original_fast.__dict__)
    ref=original_fast.CoordinatedMapMemory(256,128);new=new_fast.CoordinatedMapMemory(256,128)
    ref.free[:]=True;new.free[:]=True
    pos=ref.cell_to_world((4,2));goal=ref.cell_to_world((4,12))
    for label,kwargs in [('placement_return',{'destination':goal}),('special_utility',{'utility':np.arange(ref.free.size).reshape(ref.shape).astype(float)})]:
        a=ref.route(pos,**kwargs);b=new.route(pos,**kwargs)
        check('nonordinary_route_exact_'+label,np.array_equal(a[1],b[1]) and len(a[0])==len(b[0]) and all(np.array_equal(x,y) for x,y in zip(a[0],b[0])))
    check('no_rerank_on_nonordinary_routes',not hasattr(new,'viewpoint_diagnostics'))
    from swarm_rescue.simulation.reporting.team_info import TeamInfo
    from swarm_rescue.launcher import Launcher
    from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
    import numpy.random.mtrand,importlib.metadata
    check('numeric615',type(TeamInfo().team_number) is int and TeamInfo().team_number==615)
    check('pinned_ABI_distributions',{n:importlib.metadata.version(n) for n in ['numpy','pandas','opencv-contrib-python']}=={'numpy':'1.26.4','pandas':'2.2.3','opencv-contrib-python':'4.11.0.86'})
    check('mtrand_operation',np.isfinite(np.random.RandomState(615).normal(size=8)).all())
    check('pandas_operation',pandas.DataFrame({'x':[1,2,3]})['x'].sum()==6)
