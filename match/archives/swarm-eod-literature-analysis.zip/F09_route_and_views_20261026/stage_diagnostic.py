from pathlib import Path
import json,base64,shlex,subprocess,sys
F=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['K01','K02','K04']
old=F.parent/'diagnosis-led-trials-20261026'
runner=(old/'run_baseline_diagnostic.py').read_text(encoding='utf-8').replace('BASELINE',v).replace('F08','F09').replace("'new_algorithm':False","'new_algorithm':True")
diag=(old/'diagnostic_mixin.py').read_text(encoding='utf-8').replace('F08','F09')
diag=diag.replace("'first_complete_step':self._diag_first_complete}","'first_complete_step':self._diag_first_complete, 'route_reuse':getattr(self.memory,'route_reuse_diagnostics',{}), 'viewpoint':getattr(self.memory,'viewpoint_diagnostics',{})}")
if v in ['K02','K04']:
    diag=diag.replace("'viewpoint':getattr(self.memory,'viewpoint_diagnostics',{})}","'viewpoint':getattr(self.memory,'viewpoint_diagnostics',{}), 'viewpoint_last':getattr(self.memory,'_viewpoint_last',None), 'current_goal':None if self.goal is None else np.asarray(self.goal).tolist(), 'placement_goal':None if self.placement_goal is None else np.asarray(self.placement_goal).tolist()}")
marker='        self._diag_first_complete = None\n'
diag=diag.replace(marker,marker+'''        for name in ('observe','merge','render','route'):
            original=getattr(self.memory,name)
            def measured(*args,_original=original,_name=name,**kwargs):
                started=time.perf_counter()
                try:return _original(*args,**kwargs)
                finally:self._diag_record_cost('memory_'+_name,started)
            setattr(self.memory,name,measured)
''')
diag+='''
    def _plan_route(self,step,returning,peer_goals):
        started=time.perf_counter()
        try:return super()._plan_route(step,returning,peer_goals)
        finally:self._diag_record_cost('route_plan_chain',started)
'''
remote=r'''
from pathlib import Path
import sys,json,base64,hashlib,ast,shutil,datetime,subprocess,fcntl
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F09_route_and_views_20261026'
d=json.load(sys.stdin);v=d['version'];B=json.loads((F/v/'BUILD.json').read_text());assert json.loads((F/v/'CONTRACT_RESULT.json').read_text())['status']=='PASS'
assert not(F/'FIRST_NATIVE_ERROR.json').exists() and not(F/'STOP_REQUESTED').exists()
order=json.loads((F/'PREDECLARATION.json').read_text())['order'];index=order.index(v)
if index>0:
 previous=order[index-1];performance=F/(previous+'_PERF')
 if (performance/'STATUS.json').exists():
  prior=json.loads((performance/'STATUS.json').read_text());assert prior['status'] in ['EARLY_SCREENED_VALID_SCORE','COMPLETE_ALL_EIGHT_PAIRED_GROUPS']
  proc=Path('/proc')/str(prior['pid'])/'stat'
  assert not proc.exists() or proc.read_text().split()[2]=='Z','Previous coordinator still alive'
 else:
  prior=json.loads((F/(previous+'_DIAG')/'MECHANISM_REVIEW.json').read_text());assert prior['start_five_map_now'] is False
a=json.loads((R/'solver_study/heuristic_20261016.json').read_text());assert not a.get('active_processes') and not a.get('current_formal_active')
with (R/'solver_study/serial_evaluation.lock').open('a+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
G=F/(v+'_DIAG');assert not G.exists();G.mkdir();S=G/'source';shutil.copytree(Path(B['path'])/'source',S)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
decl={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':v,'source_zip_sha256':B['zip_sha256'],'kind':'ONE_FRESH_MAP04_RED_MECHANISM_ONLY','seed':None,'no_retry':True,'BLUE':False,'ranking':False,'instrumentation':'Own method wall-clock counters/own memory diagnostics, no extra sensor/planner calls. Logging affects wall-clock; no causal speed/score comparison.'}
(G/'PREDECLARATION.json').write_text(json.dumps(decl,indent=2)+'\n')
(S/'diagnostic_mixin.py').write_bytes(base64.b64decode(d['mixin']))
p=S/'my_drone_eval.py';s=p.read_text();s=s.replace('class MyDroneEval(','class BasePJ01(',1);s+='\nfrom swarm_rescue.solutions.diagnostic_mixin import DiagnosticMixin\nclass MyDroneEval(DiagnosticMixin,BasePJ01):\n    pass\n';p.write_text(s)
for p in S.glob('*.py'):ast.parse(p.read_text())
blue=Path(json.loads((H/'F07_evidence_three_directions_20261026/infrastructure/PREDECLARATION.json').read_text())['blue_workspace'])
W=R/'experiments/target90_20261012/official_workspaces'/('f09diag_20261026_'+v+'_M04');assert not W.exists()
shutil.copytree(blue,W,ignore=shutil.ignore_patterns('solutions','__pycache__','*.pyc','.git','.pytest_cache'));sol=W/'src/swarm_rescue/solutions';sol.mkdir()
for p in S.iterdir():shutil.copy2(p,W/'req.txt' if p.name=='req.txt' else sol/p.name)
stage={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'workspace':str(W),'source_files':{p.name:sha(p) for p in S.iterdir()},'production_source':B['source_files'],'production_candidate_sha256':B['zip_sha256'],'original_SDK_workspace':str(blue),'not_for_performance_ranking':True}
(G/'STAGING.json').write_text(json.dumps(stage,indent=2)+'\n')
pre=(H/'F08_diagnosis_led_three_20261026/BASELINE_DIAG/preflight.py').read_text();ast.parse(pre);(G/'preflight.py').write_text(pre)
p=F/('run_'+v+'_diagnostic.py');p.write_bytes(base64.b64decode(d['runner']));ast.parse(p.read_text())
with (F/(v+'_diagnostic_coordinator.log')).open('x') as log:
 proc=subprocess.Popen([str(R/'.venv/bin/python'),'-u',str(p)],cwd=R,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':v,'pid':proc.pid,'starttime_ticks':(Path('/proc')/str(proc.pid)/'stat').read_text().split()[21],'candidate_sha256':B['zip_sha256'],'runner_sha256':sha(p),'only_one_RED_diagnostic':True}
(G/'LAUNCH_COORDINATOR.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
'''
b=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(remote)],input=json.dumps({'version':v,'runner':base64.b64encode(runner.encode()).decode(),'mixin':base64.b64encode(diag.encode()).decode()}).encode())
(F/(v+'_DIAGNOSTIC_LAUNCH.json')).write_bytes(b);print(b.decode())
