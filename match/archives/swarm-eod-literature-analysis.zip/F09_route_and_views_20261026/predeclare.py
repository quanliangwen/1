from pathlib import Path
import json,subprocess
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import json,datetime,hashlib,fcntl
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F09_route_and_views_20261026'
assert not F.exists()
assert json.loads((H/'F08_diagnosis_led_three_20261026/OFFLINE_BRIDGE_STATUS.json').read_text())['status']=='COMPLETE_ALL_DECLARED_OFFLINE_STUDIES'
a=json.loads((R/'solver_study/heuristic_20261016.json').read_text());assert not a.get('active_processes') and not a.get('current_formal_active')
with (R/'solver_study/serial_evaluation.lock').open('a+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
parent=H/'PJ01_submission_team615_v05_20261026/team615_red_v05.zip'
assert hashlib.sha256(parent.read_bytes()).hexdigest()=='1413661721353548f9dcb9badf6aed4c8763dbde56de0c6d170b7429dc0c9406'
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':F.name,'parent':str(parent),'parent_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),'authorization':'Human explicitly chose 1,2,4 after F08 recommendations; modify and test in recommendation order. No direction3 or5.',
'order':['K01','K02','K04'],'directions':{
'K01':{'purpose':'Reuse shortest-path tree within one _plan_route transaction for exactly identical own sensed graph and source; retain objective, tie order and all messages.','planned_files':['fast_exploration.py','my_drone_eval.py','route_transaction.py'],'prohibition':'No cross-step stale cache or skipped map evidence. Exact walkable/clearance comparison; different graph/start computes independently.'},
'K02':{'purpose':'Bounded occlusion-aware reranking of ordinary exploration viewpoints using current own free/hit evidence; no placement/return changes.','small_first':'Closed wall, opening, no unknown, disconnected graph, incumbent and runtime bound; fresh diagnostic must show actual changed ordinary goals.'},
'K04':{'purpose':'Bounded marginal exploration-view value after estimated overlap from actually received fresh peer positions/goals. Existing Gaussian point reservation retained; no peer-object/state access.','small_first':'Disjoint/overlapping/occluded views, stale/invalid/self message fallback, soft conservative overlap discount.'}},
'qualification':'First full source AST/team615/pinned req/numpy1.26.4,pandas2.2.3,cv4.11.0.86 ABI/SDK contract checks before native. Preserve first failure and any explicitly amended repair.',
'native_runtime':'Original ROOT/.venv python/run_server.sh; numpy1.26.4/pandas3.0.6/cv4.11.0; no installations or SDK/map/BLUE changes.',
'mechanism_gate':'At most one fresh Map04 RED diagnostic per candidate, no BLUE, not ranked as five-map score. No actual trigger or no meaningful computational/information change => do not expand. Agent review before performance.',
'performance':'Interleave PJ01_A,CAND_A,PJ01_B,CAND_B, optionally C/D. Original Map01-05 mean only. Candidate any complete group<80 stops. At two candidate/control groups, candidate mean<=control stops expansion. Full4v4 strict higher mean required to promote; ties retain PJ01. No significance/causal claim, no historical threshold.',
'failure':'First actual native/backend error stops declared chain; no retry/relabel/clock/input rescue. Single serial evaluator; every expansion reviewed, no automatic tuning.',
'scope':'No NPZ/pickle decoding or replay, truth/BLUE-private/global/peer objects in controller, subagents, Docker,50maps,official upload or new automation. Independent PJ01 full sources, not stacked. Existing V05 remains release recommendation.'}
F.mkdir();(F/'PREDECLARATION.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');(F/'STATUS.json').write_text(json.dumps({'status':'DECLARED_AWAIT_K01_BUILD','utc':d['utc']})+'\n');print(json.dumps(d))
'''
b=subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python','-'],input=code.encode())
(F/'PREDECLARATION.json').write_bytes(b)
print('F09 declared: K01 then K02 then K04; no games started')
