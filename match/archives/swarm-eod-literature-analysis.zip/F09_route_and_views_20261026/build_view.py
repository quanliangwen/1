from pathlib import Path
import subprocess,shlex,base64,json,sys
F=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['K02','K04']
code=r'''
from pathlib import Path
import sys,json,base64,hashlib,zipfile,ast,datetime,difflib
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F09_route_and_views_20261026'
data=json.load(sys.stdin);v=data['version'];D=json.loads((F/'PREDECLARATION.json').read_text());assert v in D['order']
C=F/v;assert not C.exists();C.mkdir();S=C/'source';S.mkdir()
with zipfile.ZipFile(D['parent']) as z:
 for n in z.namelist():(S/n).write_bytes(z.read(n))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={p.name:p.read_bytes() for p in S.iterdir()};mode='occlusion' if v=='K02' else 'peer_overlap'
(S/'viewpoint_rerank.py').write_bytes(base64.b64decode(data['helper']))
p=S/'fast_exploration.py';s=p.read_text();marker='        if not np.isfinite(score).any():\n';assert s.count(marker)==1
s=s.replace(marker,"        if destination is None and (utility is None or getattr(self,'_ordinary_frontier_depth',0)>0):\n            from swarm_rescue.solutions.viewpoint_rerank import rerank_views\n            score=rerank_views(self,position,score,"+repr(mode)+")\n"+marker)
marker='        return smooth[1:], self.cell_to_world(goal)'
if marker in s:
 s=s.replace(marker,"        from swarm_rescue.solutions.viewpoint_rerank import record_returned_view\n        if destination is None and utility is None:record_returned_view(self,self.cell_to_world(goal))\n"+marker)
else:
 marker='        return [self.cell_to_world(c) for c in smooth[1:]], self.cell_to_world(goal)'
 assert marker in s
 s=s.replace(marker,"        from swarm_rescue.solutions.viewpoint_rerank import record_returned_view\n        if destination is None and utility is None:record_returned_view(self,self.cell_to_world(goal))\n"+marker)
p.write_text(s)
p=S/'fast_exploration_edges.py';s=p.read_text();marker='        route, goal = super().route(position, identifier, peers, utility=values)';assert s.count(marker)==1
s=s.replace(marker,"        depth=getattr(self,'_ordinary_frontier_depth',0)\n        self._ordinary_frontier_depth=depth+1\n        try:\n            route, goal = super().route(position, identifier, peers, utility=values)\n        finally:self._ordinary_frontier_depth=depth")
marker='values[old_cell] >= .85*values[new_cell]';assert s.count(marker)==1
s=s.replace(marker,"values[old_cell]*getattr(self,'_viewpoint_factors',{}).get(old_cell,1.) >= .85*values[new_cell]*getattr(self,'_viewpoint_factors',{}).get(new_cell,1.)")
marker='        self.exploration_goal = np.asarray(goal, float).copy()\n        return route, goal';assert s.count(marker)==1
s=s.replace(marker,"        self.exploration_goal = np.asarray(goal, float).copy()\n        from swarm_rescue.solutions.viewpoint_rerank import record_returned_view\n        record_returned_view(self,goal)\n        return route, goal")
p.write_text(s)
for p in S.glob('*.py'):ast.parse(p.read_text())
changed=sorted(p.name for p in S.iterdir() if before.get(p.name)!=p.read_bytes());assert changed==['fast_exploration.py','fast_exploration_edges.py','viewpoint_rerank.py']
assert (S/'my_drone_eval.py').read_bytes()==before['my_drone_eval.py'] and (S/'req.txt').read_bytes()==before['req.txt'] and (S/'team_info.yml').read_bytes()==before['team_info.yml']
diff=''.join(''.join(difflib.unified_diff(before.get(n,b'').decode().splitlines(True),(S/n).read_text().splitlines(True),fromfile='PJ01/'+n,tofile=v+'/'+n)) for n in changed);(C/'CHANGES.diff').write_text(diff)
z=C/('team615_red_v'+('10' if v=='K02' else '11')+'.zip')
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as f:
 for p in sorted(S.iterdir()):f.write(p,p.name)
B={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':v,'path':str(C),'zip':str(z),'zip_sha256':sha(z),'source_files':{p.name:sha(p) for p in S.iterdir()},'changed_files':changed,'mode':mode,'declaration_sha256':sha(F/'PREDECLARATION.json'),'release_status':'INTERNAL_NOT_RELEASED'}
(C/'BUILD.json').write_text(json.dumps(B,indent=2)+'\n');print(json.dumps(B))
'''
b=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps({'version':v,'helper':base64.b64encode((F/'viewpoint_rerank.py').read_bytes()).decode()}).encode())
(F/(v+'_BUILD.json')).write_bytes(b);print(json.loads(b)['changed_files'])
