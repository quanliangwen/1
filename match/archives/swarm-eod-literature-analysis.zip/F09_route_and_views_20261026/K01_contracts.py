    from swarm_rescue.solutions import fast_exploration as candidate_fast
    from swarm_rescue.solutions.route_transaction import route_fields,RouteTransactionMixin
    import types
    original_fast=types.ModuleType('f09_reference_fast')
    reference=H/'PJ01_submission_team615_v05_20261026/source/fast_exploration.py'
    exec(compile(reference.read_text(),str(reference),'exec'),original_fast.__dict__)
    def equal_routes(a,b):
        return ((a[1] is None and b[1] is None) or (a[1] is not None and b[1] is not None and np.array_equal(a[1],b[1]))) and len(a[0])==len(b[0]) and all(np.array_equal(x,y) for x,y in zip(a[0],b[0]))
    rng=np.random.RandomState(61509)
    for n in range(12):
        ref=original_fast.CoordinatedMapMemory(256+64*(n%2),128+64*(n%3),identifier=n%5)
        new=candidate_fast.CoordinatedMapMemory(ref.width,ref.height,identifier=n%5)
        ref.free[:]=rng.random_sample(ref.shape)>.12
        ref.hits[:]=np.where(rng.random_sample(ref.hit_shape)<.001,2,0)
        ref.visits[:]=rng.randint(0,4,size=ref.shape)
        new.free[:]=ref.free;new.hits[:]=ref.hits;new.visits[:]=ref.visits
        p=ref.cell_to_world((ref.shape[0]//2,2));target=ref.cell_to_world((2,ref.shape[1]-3))
        utility=rng.random_sample(ref.shape);new._route_transaction_fields=[]
        for mode,kwargs in [('ordinary',{}),('destination',{'destination':target}),('utility',{'utility':utility})]:
            check('K01_exact_reference_route_'+str(n)+'_'+mode,equal_routes(ref.route(p,**kwargs),new.route(p,**kwargs)))
        check('K01_reuses_same_graph_'+str(n),new.route_reuse_diagnostics['hits']==2)
        new.visits[:]+=2;ref.visits[:]+=2
        check('K01_scores_recomputed_after_visits_'+str(n),equal_routes(ref.route(p),new.route(p)))
    fake=types.SimpleNamespace(shape=(6,8),_route_transaction_fields=[])
    walk=np.ones(fake.shape,bool);clear=np.full(fake.shape,80.,float)
    a=route_fields(fake,clear,walk,(2,2));b=route_fields(fake,clear,walk,(2,2))
    check('K01_same_query_cache_hit',fake.route_reuse_diagnostics['hits']==1)
    walk[2,3]=False;c=route_fields(fake,clear,walk,(2,2))
    check('K01_walkable_change_forces_search',fake.route_reuse_diagnostics['searches']==2 and np.isinf(c[0][2,3]))
    clear[1,1]=24.;route_fields(fake,clear,walk,(2,2))
    check('K01_cost_weight_change_forces_search',fake.route_reuse_diagnostics['searches']==3)
    route_fields(fake,clear,walk,(2,1))
    check('K01_source_change_forces_search',fake.route_reuse_diagnostics['searches']==4)
    clear[1,2]=23.;route_fields(fake,clear,walk,(2,1))
    check('K01_cache_size_bound',len(fake._route_transaction_fields)==4)
    fake._route_transaction_fields=None;before=fake.route_reuse_diagnostics['searches']
    route_fields(fake,clear,walk,(2,1));route_fields(fake,clear,walk,(2,1))
    check('K01_outside_transaction_no_persistence',fake.route_reuse_diagnostics['searches']==before+2)
    class Parent:
        def _plan_route(self,*args):
            assert self.memory._route_transaction_fields==[]
            if self.fail:raise ValueError('synthetic parent failure')
            return ([],None)
    class Scope(RouteTransactionMixin,Parent):pass
    obj=object.__new__(Scope);obj.memory=types.SimpleNamespace();obj.fail=False
    obj._plan_route(1,False,[])
    check('K01_scope_cleared_on_normal_return',obj.memory._route_transaction_fields is None)
    obj.fail=True
    try:obj._plan_route(2,False,[])
    except ValueError:pass
    check('K01_scope_cleared_on_exception',obj.memory._route_transaction_fields is None)
    from swarm_rescue.simulation.reporting.team_info import TeamInfo
    from swarm_rescue.launcher import Launcher
    from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
    import numpy.random.mtrand,importlib.metadata
    check('numeric615',type(TeamInfo().team_number) is int and TeamInfo().team_number==615)
    check('pinned_ABI_distributions',{n:importlib.metadata.version(n) for n in ['numpy','pandas','opencv-contrib-python']}=={'numpy':'1.26.4','pandas':'2.2.3','opencv-contrib-python':'4.11.0.86'})
    check('mtrand_operation',np.isfinite(np.random.RandomState(615).normal(size=8)).all())
    check('pandas_operation',pandas.DataFrame({'x':[1,2,3]})['x'].sum()==6)
