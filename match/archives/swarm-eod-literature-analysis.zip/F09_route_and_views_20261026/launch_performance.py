from pathlib import Path
import json,subprocess,sys
F=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['K01','K02','K04']
code=r'''
from pathlib import Path
import json,datetime,subprocess,fcntl,hashlib,os
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F09_route_and_views_20261026';v=VERSION;G=F/(v+'_PERF')
assert not(G/'STATUS.json').exists() and not(G/'LAUNCH_COORDINATOR.json').exists() and not(F/'FIRST_NATIVE_ERROR.json').exists() and not(F/'STOP_REQUESTED').exists()
a=json.loads((R/'solver_study/heuristic_20261016.json').read_text());assert not a.get('active_processes') and not a.get('current_formal_active')
with (R/'solver_study/serial_evaluation.lock').open('a+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
with (G/'coordinator_console.log').open('x') as log:
 p=subprocess.Popen([str(R/'.venv/bin/python'),'-u',str(G/'run_performance.py')],cwd=R,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':p.pid,'starttime_ticks':(Path('/proc')/str(p.pid)/'stat').read_text().split()[21],'runner_sha256':hashlib.sha256((G/'run_performance.py').read_bytes()).hexdigest(),'phase_predeclaration_sha256':hashlib.sha256((G/'PREDECLARATION.json').read_bytes()).hexdigest(),'candidate_id':v,'detached':True,'single_scheduler':True}
(G/'LAUNCH_COORDINATOR.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
'''.replace('VERSION',repr(v))
b=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python','-'],input=code.encode())
(F/(v+'_PERFORMANCE_LAUNCH.json')).write_bytes(b);print(b.decode())
