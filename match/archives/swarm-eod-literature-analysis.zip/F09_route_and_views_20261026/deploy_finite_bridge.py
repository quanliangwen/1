from pathlib import Path
import ast,json,sys,subprocess,shlex,base64,hashlib
F=Path(__file__).resolve().parent
def capture(name,v):
    p=F/(name+'.py');tree=ast.parse(p.read_text(encoding='utf-8'));cut=None
    for i,node in enumerate(tree.body):
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='b' for t in node.targets) and isinstance(node.value,ast.Call):cut=i;break
    assert cut is not None
    ctx={'__file__':str(p),'__name__':'operator_capture_only'}
    old=sys.argv;sys.argv=[str(p),v]
    try:exec(compile(ast.Module(body=tree.body[:cut],type_ignores=[]),str(p),'exec'),ctx)
    finally:sys.argv=old
    if name=='qualify':return {'code':ctx['code'],'payload':{'version':v,'contract':base64.b64encode(ctx['base'].encode()).decode()}}
    if name=='stage_diagnostic':return {'code':ctx['remote'],'payload':{'version':v,'runner':base64.b64encode(ctx['runner'].encode()).decode(),'mixin':base64.b64encode(ctx['diag'].encode()).decode()}}
    if name=='prepare_performance':return {'code':ctx['remote'],'payload':ctx['payload']}
    if name=='launch_performance':return {'code':ctx['code'],'payload':{}}
    raise AssertionError(name)
bundle={}
for v in ['K02','K04']:
    for name in ['qualify','stage_diagnostic','prepare_performance','launch_performance']:
        d=capture(name,v);ast.parse(d['code'])
        p=F/'operators'/v/(name+'.json');p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists()
        p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        bundle[str(p.relative_to(F)).replace('\\','/')]=base64.b64encode(p.read_bytes()).decode()
bridge=F/'finite_bridge.py';ast.parse(bridge.read_text(encoding='utf-8'))
bundle['finite_bridge.py']=base64.b64encode(bridge.read_bytes()).decode()
remote=r'''
from pathlib import Path
import json,sys,base64,hashlib,datetime,subprocess,ast,os
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F09_route_and_views_20261026';d=json.load(sys.stdin)
assert not(F/'CONTINUATION_AMENDMENT.json').exists() and not(F/'FINITE_BRIDGE_STATUS.json').exists()
assert not(F/'FIRST_NATIVE_ERROR.json').exists() and not(F/'STOP_REQUESTED').exists()
current=json.loads((F/'K01_PERF/STATUS.json').read_text());assert current['pid']==692852
assert (Path('/proc')/str(current['pid'])).exists()
for name,data in d.items():
 p=F/name;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(base64.b64decode(data))
 if name.endswith('.py'):ast.parse(p.read_text())
 else:ast.parse(json.loads(p.read_text())['code'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
amend={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent_declaration_sha256':sha(F/'PREDECLARATION.json'),'authorization_basis':'Human chose1,2,4 and requested modifications and testing in recommendation order, with early rejection. Earlier session preference is offline execution. Finite continuation of those three existing independent frozen candidates only; no new direction or tuning.',
'order':['K01','K02','K04'],'existing_K01_coordinator_unchanged':692852,'K01_first_pair_review':'Already model-reviewed and client-verified; continue existing B cohort, never restart.',
'mechanism_gate':'For K02/K04 first source qualification then exactly one fresh Map04 RED-only diagnostic; expand only if at least one returned ordinary exploration goal differs from the raw pre-rerank top and measured reranking/control wall-clock share<=limit. This is a mechanism/cost budget, not a score-promotion criterion or a whole-policy counterfactual. No stock/RED diagnostic score cherry-picking.',
'view_optional_cost_share_limit':.10,'performance_gate':'Same frozen original-five<80 and at n2 candidate<=contemporary control stops; positive n2 expands only declared C/D; four cohorts strict higher mean needed for promotion. No historical gate or n3 threshold.',
'review_mode':'Deterministic server archive/SHA/scope/four-term/stock/resource-rule reports. No model inference after application closes, no parameter changes. Future first Windows raw persistence may remain pending until user returns; never forge client receipt. This prospectively supersedes live-agent/client-first blocking gate for future reviews only; existing declarations/sources/results remain untouched.',
'failure':'First actual native/backend or qualification/bridge failure stops continuation; preserve all error logs, no retries, relabels, source fixes, altered clocks/inputs. No upload, release or final canonical replacement.',
'max_total_performance_groups':24,'completed_at_amendment':len(current['completed']),'max_single_RED_diagnostics':3,'stop_file':str(F/'STOP_REQUESTED'),
'candidate_sha256':{v:json.loads((F/v/'BUILD.json').read_text())['zip_sha256'] for v in ['K01','K02','K04']},
'operator_sha256':{name:sha(F/name) for name in d if name.startswith('operators/')},'bridge_sha256':sha(F/'finite_bridge.py')}
(F/'CONTINUATION_AMENDMENT.json').write_text(json.dumps(amend,ensure_ascii=False,indent=2)+'\n')
with (F/'finite_bridge_console.log').open('x') as log:
 p=subprocess.Popen([str(R/'.venv/bin/python'),'-u',str(F/'finite_bridge.py')],cwd=R,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':p.pid,'starttime_ticks':(Path('/proc')/str(p.pid)/'stat').read_text().split()[21],'bridge_sha256':sha(F/'finite_bridge.py'),'amendment_sha256':sha(F/'CONTINUATION_AMENDMENT.json'),'original_coordinator_not_restarted':True,'detached':True}
(F/'FINITE_BRIDGE_LAUNCH.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
'''
b=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(remote)],input=json.dumps(bundle).encode())
(F/'FINITE_BRIDGE_LAUNCH.json').write_bytes(b);print(b.decode())
