from pathlib import Path
import json,subprocess,base64,shlex,sys
F=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['K01','K02','K04']
base=(F.parent/'evidence-trials-20261026/base_contract.py').read_text(encoding='utf-8')
base=base.replace("R=Path('/home/junhao/quan/parallel_test_solver/match')","R=Path('/home/junhao/quan/parallel_test_solver/match')\nH=R/'solver_study/framework_screen_20261016/best87_independent_20261025'")
base=base.replace("('1.26.4','3.0.6','4.11.0')","('1.26.4','2.2.3','4.11.0')")
base=base.replace("C/'BUILD_RECEIPT.json'","C/'BUILD.json'")
base=base.replace("    sys.path.insert(0,str(W/'src'))","    sys.path.insert(0,str(H/'submission_alns_v9_20261025T1532Z/dependency_venv/lib/python3.11/site-packages'))\n    sys.path.insert(0,str(W/'src'))")
base=base.replace('    for name,module in list(sys.modules.items()):',(F/(v+'_contracts.py')).read_text(encoding='utf-8')+'\n    for name,module in list(sys.modules.items()):',1)
code=r'''
from pathlib import Path
import json,sys,base64,shutil,zipfile,os,subprocess,ast
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F09_route_and_views_20261026'
d=json.load(sys.stdin);v=d['version'];G=F/v;B=json.loads((G/'BUILD.json').read_text());assert not(G/'CONTRACT_RESULT.json').exists() and not(G/'qualification_workspace').exists()
(G/'PREDECLARATION.json').write_text(json.dumps({'candidate_id':v,'candidate_directory':B['path'],'declaration':str(F/'PREDECLARATION.json')})+'\n')
blue=Path(json.loads((H/'F07_evidence_three_directions_20261026/infrastructure/PREDECLARATION.json').read_text())['blue_workspace'])
W=G/'qualification_workspace';shutil.copytree(blue,W,ignore=shutil.ignore_patterns('solutions','__pycache__','*.pyc','.git','.pytest_cache'));sol=W/'src/swarm_rescue/solutions';sol.mkdir()
with zipfile.ZipFile(B['zip']) as z:
 for n in z.namelist():(W/'req.txt' if n=='req.txt' else sol/n).write_bytes(z.read(n))
contract=base64.b64decode(d['contract']).decode();ast.parse(contract);(G/'contract_test.py').write_text(contract)
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with (G/'contract_console.log').open('x') as log:
 p=subprocess.run(['bash',str(R/'run_server.sh'),'-u',str(G/'contract_test.py')],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
r=json.loads((G/'CONTRACT_RESULT.json').read_text());print(json.dumps({'version':v,'status':r['status'],'checks':len(r['checks']),'error':r.get('error')}))
raise SystemExit(p.returncode)
'''
b=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps({'version':v,'contract':base64.b64encode(base.encode()).decode()}).encode())
print(b.decode())
