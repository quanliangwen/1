from pathlib import Path
import subprocess,shlex,base64,json
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import sys,json,base64,hashlib,zipfile,ast,datetime,difflib
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F09_route_and_views_20261026'
D=json.loads((F/'PREDECLARATION.json').read_text());assert D['order']==['K01','K02','K04']
C=F/'K01';assert not C.exists();C.mkdir();S=C/'source';S.mkdir()
with zipfile.ZipFile(D['parent']) as z:
 for n in z.namelist():(S/n).write_bytes(z.read(n))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={p.name:p.read_bytes() for p in S.iterdir()}
(S/'route_transaction.py').write_bytes(base64.b64decode(json.load(sys.stdin)['helper']))
p=S/'fast_exploration.py';s=p.read_text()
start=s.index('        # The same directed eight-neighbour graph and heap tie ordering,')
end=s.index('\n        reachable = np.isfinite(cost)',start)
s=s[:start]+'        from swarm_rescue.solutions.route_transaction import route_fields\n        cost,parent=route_fields(self,clearance,walkable,start)\n'+s[end:];p.write_text(s)
p=S/'my_drone_eval.py';s=p.read_text();s='from swarm_rescue.solutions.route_transaction import RouteTransactionMixin\n'+s;s=s.replace('class MyDroneEval(','class MyDroneEval(RouteTransactionMixin,',1);p.write_text(s)
for p in S.glob('*.py'):ast.parse(p.read_text())
assert (S/'team_info.yml').read_bytes()==before['team_info.yml'] and (S/'req.txt').read_bytes()==before['req.txt']
changed=sorted(p.name for p in S.iterdir() if before.get(p.name)!=p.read_bytes());assert changed==sorted(D['directions']['K01']['planned_files'])
diff=''.join(''.join(difflib.unified_diff(before.get(n,b'').decode().splitlines(True),(S/n).read_text().splitlines(True),fromfile='PJ01/'+n,tofile='K01/'+n)) for n in changed)
(C/'CHANGES.diff').write_text(diff)
z=C/'team615_red_v09.zip'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as f:
 for p in sorted(S.iterdir()):f.write(p,p.name)
build={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':'K01','path':str(C),'zip':str(z),'zip_sha256':sha(z),'source_files':{p.name:sha(p) for p in S.iterdir()},'changed_files':changed,'declaration_sha256':sha(F/'PREDECLARATION.json'),'release_status':'INTERNAL_NOT_RELEASED'}
(C/'BUILD.json').write_text(json.dumps(build,indent=2)+'\n');print(json.dumps(build))
'''
b=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps({'helper':base64.b64encode((F/'route_transaction.py').read_bytes()).decode()}).encode())
(F/'K01_BUILD.json').write_bytes(b);print(json.loads(b)['changed_files'])
