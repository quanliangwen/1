"""Stage a bounded paired study only after qualified mechanism admission."""
from pathlib import Path
import json,base64,shlex,subprocess,sys,ast
F=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['K01','K02','K04']
infra=F.parent/'evidence-trials-20261026/infrastructure'
coordinator=(infra/'run_prefix_joint_comparison.py').read_text(encoding='utf-8')
coordinator=coordinator.replace("D=json.loads((F/'RUN_PLAN.json').read_text())","D=json.loads((F/'RUN_PLAN.json').read_text())\nclass ScreenedOut(Exception):pass",1)
coordinator=coordinator.replace("v=='PJ01'","v==D['candidate_id']")
coordinator=coordinator.replace("0 if v=='V010' else 1","0 if v=='PJ01' else 1")
coordinator=coordinator.replace("(F/'STOP_REQUESTED')","(F.parent/'STOP_REQUESTED')")
coordinator=coordinator.replace("'ACTUAL_PREFIX_JOINT_COMPARISON_FIVE_MAP_RUNNING'","'ACTUAL_PAIRED_FIVE_MAP_RUNNING'")
coordinator=coordinator.replace("'COMPLETE_ALL_EIGHT_PREFIX_JOINT_COMPARISON_GROUPS'","'COMPLETE_ALL_EIGHT_PAIRED_GROUPS'")
coordinator=coordinator.replace("'One frozen independent PJ01 and V010 control, four cold five-map cohorts each; unseeded, not paired causal/stability proof; total mean sole performance criterion.'","'Independent candidate vs contemporary PJ01, interleaved unseeded full-five cohorts; adaptive screening is resource allocation, no significance or causal claim.'")
old=" t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\\n');t.replace(p)"
assert coordinator.count(old)==1
new=old+"\n if p==STATUS:\n  q=F.parent/'STATUS.json';tmp=q.with_suffix('.json.tmp');tmp.write_text(json.dumps({**d,'performance_phase':str(F),'candidate_id':D['candidate_id']},ensure_ascii=False,indent=2)+'\\n');tmp.replace(q)"
coordinator=coordinator.replace(old,new,1)
gate='''
  if v==D['candidate_id']:
   n=len([r for r in state['completed'] if r['version']==D['candidate_id']])
   a=[r['mean'] for r in state['completed'] if r['version']==D['candidate_id']]
   b=[r['mean'] for r in state['completed'] if r['version']=='PJ01']
   pair={'utc':utc(),'candidate_id':D['candidate_id'],'pairs':n,'candidate_means':a,'control_means':b,'candidate_mean':sum(a)/len(a),'control_mean':sum(b)/len(b),'difference':sum(a)/len(a)-sum(b)/len(b),'paired_random_seed':False,'not_causal_or_significance_claim':True}
   save(F/('PAIR_'+str(n)+'_RESULT.json'),pair)
   if mean<80.:raise ScreenedOut('candidate_complete_five_mean_below80:'+str(mean))
   if n==2 and pair['candidate_mean']<=pair['control_mean']:
    raise ScreenedOut('first_two_interleaved_candidate_means_not_above_two_contemporary_controls:'+str(pair['difference']))
   if n<4:
    state.update(status='WAITING_FOR_AGENT_PAIR_REVIEW',pairs_complete=n,updated_utc=utc());save(STATUS,state)
    review=F/('PAIR_'+str(n)+'_REVIEW.json')
    while not review.exists():
     if (F.parent/'STOP_REQUESTED').exists():raise InterruptedError('Human stop')
     time.sleep(5)
    decision=json.loads(review.read_text());assert decision['pairs_complete']==n and decision['candidate_id']==D['candidate_id']
    if not decision['continue']:raise ScreenedOut('agent_evidence_review_stops_expansion:'+decision['reason'])
'''
assert coordinator.count('\n summary={}')==1;coordinator=coordinator.replace('\n summary={}','\n'+gate+'\n summary={}',1)
handler='''except ScreenedOut as exc:
 save(F/'RESULT.json',{'utc':utc(),'complete':False,'valid':True,'screened_out':True,'reason':str(exc),'candidate_id':D['candidate_id'],'consumed_cohorts':state['completed'],'performance_win_claim':False,'skipped_cohorts':[i for i in D['order'] if not any(r['version']==i['version'] and r['cohort']==i['cohort'] for r in state['completed'])]})
 state.update(status='EARLY_SCREENED_VALID_SCORE',reason=str(exc),updated_utc=utc(),master_pid=None);save(STATUS,state)
'''
assert coordinator.count('except BaseException as exc:')==1;coordinator=coordinator.replace('except BaseException as exc:',handler+'except BaseException as exc:',1)
coordinator=coordinator.replace("except BaseException as exc:\n state.update", "except BaseException as exc:\n save(F.parent/'FIRST_NATIVE_ERROR.json',{'utc':utc(),'phase':str(F),'first_error':traceback.format_exc(),'no_retry':True})\n state.update",1)
ast.parse(coordinator)
payload={n:base64.b64encode((infra/n).read_bytes()).decode() for n in ['PREDECLARATION.json','preflight.py','run_cold.py','archive_result.py']}
payload['run_performance.py']=base64.b64encode(coordinator.encode()).decode();payload['version']=v
payload['offline_prestage']='--offline-prestage' in sys.argv
remote=r'''
from pathlib import Path
import json,sys,base64,hashlib,datetime,zipfile,ast
R=Path('/home/junhao/quan/parallel_test_solver/match');P=R/'solver_study/framework_screen_20261016';H=P/'best87_independent_20261025';F0=H/'F09_route_and_views_20261026'
data=json.load(sys.stdin);v=data['version'];G=F0/(v+'_DIAG')
review=json.loads((G/'MECHANISM_REVIEW.json').read_text());assert review['start_five_map_now'] is True
assert not(F0/'FIRST_NATIVE_ERROR.json').exists() and not(F0/'STOP_REQUESTED').exists()
assert (json.loads((F0/'STATUS.json').read_text())['status'].endswith('COMPLETE_AWAIT_ANALYSIS') or (data.get('offline_prestage') and (F0/'OFFLINE_EXECUTION_DECLARATION.json').exists()))
F=F0/(v+'_PERF');assert not F.exists();F.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
build=json.loads((F0/v/'BUILD.json').read_text())
parent=H/'PJ01_submission_team615_v05_20261026';S=parent/'source'
if not S.exists():
 S.mkdir()
 with zipfile.ZipFile(parent/'team615_red_v05.zip') as z:
  for n in z.namelist():(S/n).write_bytes(z.read(n))
control={'path':str(parent),'zip':str(parent/'team615_red_v05.zip'),'zip_sha256':sha(parent/'team615_red_v05.zip'),'source_files':{p.name:sha(p) for p in S.iterdir() if p.is_file()}}
sources={v:build,'PJ01':control}
for name,s in sources.items():s['solutions_fingerprint']=hashlib.sha256(json.dumps({k:h for k,h in s['source_files'].items() if k!='req.txt'},sort_keys=True).encode()).hexdigest()
registry=json.loads((R/'solver_study/unseeded_five_once_registry.json').read_text())
order=[{'version':name,'cohort':cohort,'label':'f09pair_20261026_'+v+'_'+name+'_'+cohort} for cohort in ['A','B','C','D'] for name in ['PJ01',v]]
decl={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':v,'phase':'F09_interleaved_'+v,'sources':sources,'order':order,'human_authorization':'Human selected1,2,4 (route reuse, visible exploration, peer-view overlap), requests small evidence first, then tests. Candidate now has qualified source and audited native mechanism review under frozen declared gates.','mechanism_review_sha256':sha(G/'MECHANISM_REVIEW.json'),'contract_sha256':sha(F0/v/'CONTRACT_RESULT.json'),'screening':'Candidate any full-five mean<80 stop. After two candidate/control cohorts each, candidate mean<=contemporary control mean stops expansion. This is a resource rule, not proof of inferiority; no historical84.764gate. Audited review after each surviving pair; finite rule-based reviews follow CONTINUATION_AMENDMENT when enabled.','promotion':'Only full4v4 strict higher mean promotes, tiePJ01. Stock/speed/variance diagnostic only.','runtime':'Unchanged ROOT/.venv python numpy1.26.4/pandas3.0.6/cv4.11.0; submission pins/ABI separately2.2.3; no installs.','original_maps':['Map01','Map02','Map03','Map04','Map05'],'seed':None,'max_native_groups':8,'no_retry':True}
(F/'PREDECLARATION.json').write_text(json.dumps(decl,ensure_ascii=False,indent=2)+'\n')
plan={**decl,'phase_predeclaration_sha256':sha(F/'PREDECLARATION.json')};(F/'RUN_PLAN.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
original=json.loads(base64.b64decode(data['PREDECLARATION.json']))
for item in order:
 name=item['version'];s=sources[name];g=F/(name+'_'+item['cohort']);g.mkdir()
 d={**original,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'F09_interleaved_candidate_vs_PJ01','authorization':decl['human_authorization'],
 'archive_candidate':str(Path(s['path']).relative_to(P)),'base_zip_sha256':s['zip_sha256'],'source_files':s['source_files'],'original_source_files':s['source_files'],
 'base_source_compact_sha256':hashlib.sha256(json.dumps(s['source_files'],sort_keys=True).encode()).hexdigest(),'base_solutions_fingerprint':s['solutions_fingerprint'],
 'baseline_mean':84.68230805104568,'red_workspace':str(R/'experiments/target90_20261012/official_workspaces'/item['label']),'result_label':item['label'],
 'version_id':name,'cohort':item['cohort'],'parent_version':'PJ01','version_predeclaration_sha256':sha(F/'PREDECLARATION.json'),
 'new_candidate':s['solutions_fingerprint'] not in registry,'existing_retained_version':name=='PJ01','new_algorithm_code':int(name==v),
 'phase_stop_file':str(F0/'STOP_REQUESTED'),'evaluation_policy':decl['promotion'],'automation_status':'One F09 scheduler; prior native stages complete; no automation.'}
 (g/'PREDECLARATION.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 for script in ['preflight.py','run_cold.py','archive_result.py']:
  text=base64.b64decode(data[script]).decode().replace('HumanapprovedprefixjointcandidateversusV010fourcohortseach','HumanapprovedF09interleavedstudyaftermechanismreview')
  ast.parse(text);(g/script).write_text(text)
p=F/'run_performance.py';p.write_bytes(base64.b64decode(data['run_performance.py']));ast.parse(p.read_text())
print(json.dumps({'phase':str(F),'status':'STAGED_NOT_STARTED','candidate':v,'order':order,'predeclaration_sha256':sha(F/'PREDECLARATION.json'),'runner_sha256':sha(p)}))
'''
b=subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(remote)],input=json.dumps(payload).encode())
(F/(v+'_PERF_PREPARATION.json')).write_bytes(b);print(b.decode())
