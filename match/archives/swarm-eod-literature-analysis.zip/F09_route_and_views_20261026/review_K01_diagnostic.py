from pathlib import Path
import json,datetime,subprocess,shlex
F=Path(__file__).resolve().parent;G=F/'K01_DIAG'
assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'))['valid']
events=json.loads((G/'EVENTS.json').read_text(encoding='utf-8'));last={}
for t in events['F09_DIAG_TICK']:last[t['owner']]=t
s={key:sum(t['route_reuse'].get(key,0) for t in last.values()) for key in ['queries','hits','searches','lookup_seconds','search_seconds','reused_search_seconds']}
r=json.loads((G/'RESULT.json').read_text(encoding='utf-8'))
assert r['valid'] and not r['row']['crashed'] and s['hits']>0 and s['reused_search_seconds']>s['lookup_seconds']
review={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':'K01','start_five_map_now':True,'diagnostic':s,'stock':[r['row']['placed'],r['row']['expected']],'qualification_first_checks':150,'reason':'Own fresh Map04 has 294 exact-graph/start transaction reuses in 683 shortest-path queries (43.05%), all10 drops, valid submit and no crash. Lookup total0.00636s; prior search-duration sum on reused entries7.41162s indicates meaningful repeated work, not a measured causal speedup. Source route equivalence150 first checks PASS. Diagnostic map85.69057 is not BLUE/full-five score or ranking. Proceed to interleaved PJ01 vs K01 under frozen<80/n2 gates; no score improvement claim.'}
p=G/'MECHANISM_REVIEW.json';assert not p.exists();p.write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
RF='/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F09_route_and_views_20261026/K01_DIAG/MECHANISM_REVIEW.json'
code="from pathlib import Path;import sys;p=Path("+repr(RF)+");assert not p.exists();p.write_bytes(sys.stdin.buffer.read())"
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=p.read_bytes(),check=True)
print(json.dumps(review,ensure_ascii=False))
