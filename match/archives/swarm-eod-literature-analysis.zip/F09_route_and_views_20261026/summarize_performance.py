from pathlib import Path
import json,csv,statistics,sys,datetime
F=Path(__file__).resolve().parent;v=sys.argv[1] if len(sys.argv)>1 else 'K01';P=F/(v+'_PERF')
state=json.loads((P/'STATUS.json').read_text(encoding='utf-8'));rows=[];groups=[]
for item in state['completed']:
 G=P/(item['version']+'_'+item['cohort']);d=json.loads((G/'RESULT.json').read_text(encoding='utf-8'))
 groups.append({'version':d['version'],'cohort':d['cohort'],'mean':d['equal_weight_mean'],'client_raw_verified':(G/'CLIENT_FIRST_RAW_REVIEW.json').exists()})
 rows += [{'version':d['version'],'cohort':d['cohort'],**r} for r in d['rows']]
summary={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':v,'status':state['status'],'current':state.get('current'),'completed_groups':groups,'groups':len(groups),'full_RED_BLUE_games':len(rows),'aggregate':{},'comparison_complete':False,'official_container_verified':False}
terms=['map_score','wall_score','completion_adjusted_blue','time_score'];weights=[.5,.2,.2,.1]
for name in ['PJ01',v]:
 r=[row for row in rows if row['version']==name];g=[d for d in groups if d['version']==name]
 if r:summary['aggregate'][name]={'groups':len(g),'mean':statistics.mean(d['mean'] for d in g),'terms':{k:statistics.mean(x[k] for x in r) for k in terms},'placed':sum(x['placed'] for x in r),'expected':sum(x['expected'] for x in r),'crashes':sum(x['red_crashed'] or x['blue_crashed'] for x in r),'maps':{m:{k:statistics.mean(x[k] for x in r if x['map']==m) for k in ['full_score',*terms,'red_steps','red_seconds']} for m in ['Map01','Map02','Map03','Map04','Map05']}}
if len(summary['aggregate'])==2:
 a=summary['aggregate'][v];b=summary['aggregate']['PJ01']
 if a['groups']==b['groups']:
  summary.update(difference=a['mean']-b['mean'],equal_group_counts=True)
  summary['weighted_term_differences']={k:w*(a['terms'][k]-b['terms'][k]) for k,w in zip(terms,weights)}
  assert abs(sum(summary['weighted_term_differences'].values())-summary['difference'])<1e-9
  summary['comparison_complete']=a['groups']==b['groups']==4
result=P/'RESULT.json'
if result.exists():summary['terminal_result']=json.loads(result.read_text(encoding='utf-8'))
(P/'PERFORMANCE_ANALYSIS.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
text=['F09 '+v+'同期五图测试','状态：'+state['status'],'已完成%s组、%s场完整RED→BLUE。'%(len(groups),len(rows)),'每组原Map01–05平均总分是唯一性能指标。','']
for g in groups:text.append('%s_%s：%.6f；首次客户端raw核验%s'%(g['version'],g['cohort'],g['mean'],'完成' if g['client_raw_verified'] else '待完成'))
if summary.get('equal_group_counts'):
 text+=['','等组数同期均分差：%+.6f'%summary['difference'],'四项加权差值：'+json.dumps(summary['weighted_term_differences'],ensure_ascii=False),'只有完整4v4严格更高才晋级；未完整比较不作晋级声明。']
if 'terminal_result' in summary and summary['terminal_result'].get('screened_out'):text.append('停止原因：'+summary['terminal_result']['reason'])
text+=['','不把单图诊断分/速度当作提分。未统一随机种子；交错比较不构成配对因果或统计显著性证明。正式官网容器未验证。']
(P/'阶段成绩与分项.txt').write_text('\n'.join(text)+'\n',encoding='utf-8')
if rows:
 with (P/'逐图分数.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(json.dumps({k:summary.get(k) for k in ['status','groups','completed_groups','difference','comparison_complete']},ensure_ascii=False))
