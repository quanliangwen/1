from pathlib import Path
import json,base64,ast,hashlib,datetime,subprocess,shlex
F=Path(__file__).resolve().parent;p=F/'operators/K04R/stage_diagnostic_profile_v2.json';d=json.loads(p.read_text(encoding='utf-8'))
def translate(s):return s.replace('Map04','Map05').replace('MAP04','MAP05').replace('_M04','_M05')
d['code']=translate(d['code'])
runner=translate(base64.b64decode(d['payload']['runner']).decode());ast.parse(runner);ast.parse(d['code']);d['payload']['runner']=base64.b64encode(runner.encode()).decode()
new=F/'operators/K04R/stage_diagnostic_m05_profile.json';assert not new.exists();new.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Manual review of complete K02R_A five-map result: Map05 only4/10 placed and68.9310 full score, versus8/10 and75.9439 contemporary control. Before any K04R qualification/native diagnostic, move its single mechanism profile from original Map04 to original Map05 to inspect the observed execution shortfall and peer-view mechanism. Not selecting among multiple diagnostics, not rescuing a failed native run; all old planned unused operators preserved.',
'parent_declaration_sha256':sha(F/'PREDECLARATION.json'),'previous_profile_amendment_sha256':sha(F/'PROFILE_INSTRUMENTATION_AMENDMENT_2.json'),'original_operator_manifest_sha256':sha(F/'OPERATOR_SHA256.json'),'additional_operator_sha256':{'operators/K04R/stage_diagnostic_m05_profile.json':sha(new)},'diagnostic_map':'Map05','unchanged_original_map_walltime_seconds':240,'new_native_label':'f10diag_20261026_K04R_M05','superseded_unused_label':'f10diag_20261026_K04R_M04','single_RED_diagnostic_count_unchanged':1,'production_source_unchanged':True,'full_five_map_performance_protocol_unchanged':True}
(F/'MAP05_DIAGNOSTIC_AMENDMENT.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
code=r'''
from pathlib import Path
import json,sys,base64,hashlib
F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F10_visibility_fix_20261026');assert not(F/'K04R_DIAG').exists() and not(F/'K04R/CONTRACT_RESULT.json').exists()
for n,b in json.load(sys.stdin).items():
 p=F/n;assert not p.exists();p.write_bytes(base64.b64decode(b))
a=json.loads((F/'MAP05_DIAGNOSTIC_AMENDMENT.json').read_text());assert a['original_operator_manifest_sha256']==hashlib.sha256((F/'OPERATOR_SHA256.json').read_bytes()).hexdigest()
print('Prospectively declared one original Map05 RED diagnostic for K04R; no extra round or performance change')
'''
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps({str(p.relative_to(F)).replace('\\','/'):base64.b64encode(p.read_bytes()).decode() for p in [new,F/'MAP05_DIAGNOSTIC_AMENDMENT.json']}).encode(),check=True)
