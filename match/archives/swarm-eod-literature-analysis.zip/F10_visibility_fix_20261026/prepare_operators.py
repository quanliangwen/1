from pathlib import Path
import json,base64,subprocess,shlex,ast
F=Path(__file__).resolve().parent;OLD=F.parent/'F09_route_and_views_20261026'
def rewrite(text,old,new):
    return text.replace('F09_route_and_views_20261026','F10_visibility_fix_20261026').replace('f09pair_','f10pair_').replace('f09diag_','f10diag_').replace('F09','F10').replace(old,new)
extra="""
    from swarm_rescue.solutions.viewpoint_rerank import visible_cells
    regression=np.zeros((12,20),np.float32);regression[6,10]=1.
    opaque=np.zeros(regression.shape,bool);opaque[:,10]=True
    ids=visible_cells((6,9),regression,opaque,16.)
    check('repair_adjacent_target_wall_visible_with_rounded_duplicate',6*20+10 in ids)
    far=regression.copy();far[:]=0;far[6,11]=1.;opaque[:,11]=True
    check('repair_thick_wall_second_layer_still_occluded',len(visible_cells((6,9),far,opaque,16.))==0)
    far[:]=0;far[6,12]=1.
    check('repair_unknown_beyond_wall_still_occluded',len(visible_cells((6,9),far,opaque,16.))==0)
"""
bundle={}
for old,v in [('K02','K02R'),('K04','K04R')]:
    for name in ['qualify','stage_diagnostic','prepare_performance','launch_performance']:
        d=json.loads((OLD/'operators'/old/(name+'.json')).read_text(encoding='utf-8'))
        d['code']=rewrite(d['code'],old,v)
        for k,val in list(d['payload'].items()):
            if k in ['contract','runner','mixin','run_performance.py']:
                val=rewrite(base64.b64decode(val).decode(),old,v)
                if k=='contract':
                    marker='    for name,module in list(sys.modules.items()):';assert val.count(marker)==1
                    val=val.replace(marker,extra+'\n'+marker)
                ast.parse(val);d['payload'][k]=base64.b64encode(val.encode()).decode()
            elif isinstance(val,str) and val==old:d['payload'][k]=v
        ast.parse(d['code'])
        p=F/'operators'/v/(name+'.json');p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        bundle[str(p.relative_to(F)).replace('\\','/')]=base64.b64encode(p.read_bytes()).decode()
code=r'''
from pathlib import Path
import json,sys,base64,hashlib
F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F10_visibility_fix_20261026')
out={}
for n,b in json.load(sys.stdin).items():
 p=F/n;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(base64.b64decode(b));out[n]=hashlib.sha256(p.read_bytes()).hexdigest()
(F/'OPERATOR_SHA256.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
'''
b=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python','-'],input=(code+'\n').encode()) if False else subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps(bundle).encode())
(F/'OPERATOR_SHA256.json').write_bytes(b);print('Prepared eight fresh one-use operations')
for name in ['sync_metadata.py','client_verify_finished_cohort.py','summarize_performance.py','verify_diagnostic_raw.py']:
    s=(OLD/name).read_text(encoding='utf-8').replace('F09_route_and_views_20261026','F10_visibility_fix_20261026').replace('f09pair_','f10pair_').replace('f09diag_','f10diag_').replace('F09','F10')
    s=s.replace("['K01','K02','K04']","['K02R','K04R']").replace("['K01_DIAG','K02_DIAG','K04_DIAG']","['K02R_DIAG','K04R_DIAG']").replace("else 'K01'","else 'K02R'")
    (F/name).write_text(s,encoding='utf-8')
