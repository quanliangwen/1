from pathlib import Path
import sys,json,hashlib,datetime
sys.dont_write_bytecode=True
F=Path(__file__).resolve().parent
R=Path('/home/junhao/quan/parallel_test_solver/match')
H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
W=F/'K02R/qualification_workspace'
sys.path.insert(0,str(W/'src'))
import numpy as np
from swarm_rescue.solutions.joint_survey import visible_gain
from swarm_rescue.solutions.viewpoint_rerank import visible_cells
from swarm_rescue.solutions.fast_exploration_edges_optimized import OptimizedEdgeSurveyMapMemory
source=W/'src/swarm_rescue/solutions/joint_survey.py'
assert hashlib.sha256(source.read_bytes()).hexdigest()==hashlib.sha256((H/'PJ01_submission_team615_v05_20261026/source/joint_survey.py').read_bytes()).hexdigest()
out=F/'BASELINE_ENDPOINT_PROBE_FIRST.json';assert not out.exists()
memory=OptimizedEdgeSurveyMapMemory(320,192)
rows=[]
for startcol in [8,9]:
    cell=(6,startcol);end=(6,startcol+1)
    weights=np.zeros((12,20),np.float32);weights[end]=1.
    opaque=np.zeros(weights.shape,bool);opaque[end]=True
    rows.append({'start':cell,'target':end,'original_joint_visible_gain':visible_gain(cell,weights,opaque,16.),'original_edge_visibility':bool(memory._batch_line_visibility([cell],[end],opaque)[0]),'repaired_helper_visible_count':len(visible_cells(cell,weights,opaque,16.))})
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only exact baseline helper on synthetic public geometry, no game, no replay, no production source change. Translation counterexample only, not proof of score gain.','joint_survey_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'rows':rows}
out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
