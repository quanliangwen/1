from pathlib import Path
import json,subprocess
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import json,datetime,hashlib,fcntl,shutil,zipfile,ast,difflib
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';OLD=H/'F09_route_and_views_20261026';F=H/'F10_visibility_fix_20261026'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not F.exists() and json.loads((OLD/'FINITE_BRIDGE_STATUS.json').read_text())['status']=='STOPPED_FIRST_ERROR_NO_RETRY'
failure=json.loads((OLD/'K02/CONTRACT_RESULT.json').read_text());assert failure['status']=='FAIL' and 'visible_surface_endpoint_not_itself_occluder' in failure['error']
assert not(OLD/'FIRST_NATIVE_ERROR.json').exists(),'No native/backend repair or relabel permitted'
a=json.loads((R/'solver_study/heuristic_20261016.json').read_text());assert not a.get('active_processes') and not a.get('current_formal_active')
with (R/'solver_study/serial_evaluation.lock').open('a+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
F.mkdir()
decl={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':F.name,'authorization':'Continue the already selected directions2 and4 after explicit online root-cause review of a pre-native qualification bug. F09 stopped as declared. No F09 failed qualification/result overwritten or passed off as first-pass; no actual native game rerun or rescue.',
'order':['K02R','K04R'],'first_failure_preserved':{'path':str(OLD/'K02/CONTRACT_RESULT.json'),'sha256':sha(OLD/'K02/CONTRACT_RESULT.json'),'passed_checks_before_failure':len(failure['checks']),'error':failure['error']},
'diagnosis':'Doubled raster sampling can round an intermediate sample into the target cell. Excluding only the final sample still regards the target wall itself as an intervening occluder. Ignore all samples occupying the target cell; retain every other opaque cell, so hidden targets remain occluded.',
'only_source_fix':'viewpoint_rerank.visible_cells sample mask excludes all occurrences of its target cell. No weight, candidate, budget, ETA, placement, messaging or timing-physics tuning.',
'qualification':'Fresh full source/ABI/consumer/visibility fixtures for each repaired copy. Preserve old failed first-run and fresh result separately. Any further failure halts continuation for review, never auto repair or retry.',
'mechanism':'One fresh original Map04 RED diagnostic each, no BLUE, no score comparison. Returned rerank goal>0 and rerank/control measured wallclock<=10% required before five-map expansion. This is a cost/opportunity gate, not proof of score gain.',
'performance':'Same interleaved PJ01_A/CAND_A/PJ01_B/CAND_B then conditional C/D, original Map01-05. Candidate any complete group<80 stops. At n2 cumulative candidate<=contemporary control stops. Only full4v4 strictly higher mean qualifies for comparison; no significance or causal claim.',
'scope':'Independent original PJ01/V05 variants, not stacked with K01 or each other. Native runtime unmodified numpy1.26.4/pandas3.0.6/cv4.11.0, separate qualification1.26.4/2.2.3/4.11.0.86. Numericteam615 and pinned req. No installation, SDK/BLUE/map/scoring change, truth/private/peer/global/history input, NPZ/pickle decoding, replay, subagents, Docker,50maps or upload.',
'max_performance_groups':16,'max_single_RED_diagnostics':2,'no_retry':True}
(F/'PREDECLARATION.json').write_text(json.dumps(decl,ensure_ascii=False,indent=2)+'\n')
oldmask='    sample=ids<(count-1)[:,None]\n'
insert='    # Rounding can enter the target cell before the final sample.\n    # The target wall is visible; only distinct intervening cells occlude.\n    sample &= (rs!=ends[:,0,None]) | (cs!=ends[:,1,None])\n'
builds={}
for old,v,version in [('K02','K02R','12'),('K04','K04R','13')]:
 C=F/v;C.mkdir();S=C/'source';shutil.copytree(OLD/old/'source',S)
 before={p.name:p.read_bytes() for p in S.iterdir() if p.is_file()}
 p=S/'viewpoint_rerank.py';s=p.read_text();assert s.count(oldmask)==1
 marker='    clear=~np.any(opaque[rs,cs]&sample,axis=1)\n';assert s.count(marker)==1
 s=s.replace(marker,insert+marker);p.write_text(s)
 for p in S.glob('*.py'):ast.parse(p.read_text())
 changed=[p.name for p in S.iterdir() if p.is_file() and p.read_bytes()!=before[p.name]];assert changed==['viewpoint_rerank.py']
 (C/'CHANGES.diff').write_text(''.join(difflib.unified_diff(before['viewpoint_rerank.py'].decode().splitlines(True),(S/'viewpoint_rerank.py').read_text().splitlines(True),fromfile=old+'/viewpoint_rerank.py',tofile=v+'/viewpoint_rerank.py')))
 z=C/('team615_red_v'+version+'.zip')
 with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as archive:
  for p in sorted(S.iterdir()):archive.write(p,p.name)
 B={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':v,'path':str(C),'zip':str(z),'zip_sha256':sha(z),'source_files':{p.name:sha(p) for p in S.iterdir()},'changed_from_failed_or_unrun_candidate':changed,'old_candidate_zip_sha256':json.loads((OLD/old/'BUILD.json').read_text())['zip_sha256'],'declaration_sha256':sha(F/'PREDECLARATION.json'),'release_status':'INTERNAL_NOT_RELEASED'}
 (C/'BUILD.json').write_text(json.dumps(B,indent=2)+'\n');builds[v]=B
(F/'STATUS.json').write_text(json.dumps({'status':'REPAIR_BUILT_NOT_YET_QUALIFIED','utc':decl['utc']})+'\n');print(json.dumps({'declaration':decl,'builds':builds}))
'''
b=subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python','-'],input=code.encode())
d=json.loads(b)
(F/'PREDECLARATION.json').write_text(json.dumps(d['declaration'],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for v,b in d['builds'].items():(F/(v+'_BUILD.json')).write_text(json.dumps(b,indent=2)+'\n',encoding='utf-8')
print(json.dumps({v:b['zip_sha256'] for v,b in d['builds'].items()}))
