from pathlib import Path
import json,datetime,subprocess,shlex
F=Path(__file__).resolve().parent;G=F/'K02R_DIAG'
assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'))['valid']
e=json.loads((G/'EVENTS.json').read_text(encoding='utf-8'));last={}
for t in e['F10_DIAG_TICK']:last[t['owner']]=t
s={k:sum(t['viewpoint'].get(k,0) for t in last.values()) for k in ['calls','reranked','suggested_changes','returned_rerank_goal','candidates','peer_views','seconds']}
c=sum(t['costs'].get('control_total',{}).get('seconds',0) for t in last.values());r=json.loads((G/'RESULT.json').read_text(encoding='utf-8'))
assert s['returned_rerank_goal']>0 and s['seconds']/c<=.10 and r['valid'] and not r['row']['crashed']
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':'K02R','start_five_map_now':True,'viewpoint_counts':s,'control_seconds':c,'cost_share':s['seconds']/c,'stock':[r['row']['placed'],r['row']['expected']],'map_score_RED_diagnostic_only':r['row']['phase']['score_map'],'old_K02_first_failure_preserved':True,'new_source_first_qualification_checks':106,'client_raw_verified':True,
'reason':'Manual evidence review: fresh Map04 returned8 non-raw-top ordinary exploration viewpoints,202 reranks/243 calls,2.29545s vs126.34183s control (nested wallclock share1.8169%). Ten drops and no crash. Mechanism has actual opportunity with bounded cost; diagnostic map74.31046 is not full-five/BLUE score and not a comparison with other unseeded diagnostics. Proceed only to the declared contemporary PJ01 interleaving, any candidate complete-five<80 early stop. No source/weight/time tuning. Baseline grid-translation visibility counterexample is separately recorded for next round, not folded into this frozen candidate.'}
p=G/'MECHANISM_REVIEW.json';assert not p.exists();p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
rf='/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F10_visibility_fix_20261026/K02R_DIAG/MECHANISM_REVIEW.json'
code="from pathlib import Path;import sys;p=Path("+repr(rf)+");assert not p.exists();p.write_bytes(sys.stdin.buffer.read())"
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=p.read_bytes(),check=True)
print(json.dumps(d))
