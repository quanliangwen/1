from pathlib import Path
import json,base64,ast,hashlib,datetime,subprocess,shlex
F=Path(__file__).resolve().parent;p=F/'operators/K04R/stage_diagnostic_profile.json';d=json.loads(p.read_text(encoding='utf-8'))
s=base64.b64decode(d['payload']['mixin']).decode()
marker="'stall_episodes':self._profile_episode,";assert s.count(marker)==1
s=s.replace(marker,marker+" 'terminal_policy':dict(getattr(self,'terminal_value_diagnostics',{})), 'terminal_gain_rate':getattr(self,'_terminal_gain_rate',None), 'commitment_policy':dict(getattr(self,'commitment_diagnostics',{})), 'survey_policy':dict(getattr(self,'survey_diagnostics',{})),")
ast.parse(s);d['payload']['mixin']=base64.b64encode(s.encode()).decode()
new=F/'operators/K04R/stage_diagnostic_profile_v2.json';assert not new.exists();new.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Prospective same single K04R diagnostic: include already computed own terminal/commitment/survey counters and gain-rate fields, in addition to the staged own geometry/stall passive profile. No new sensing/planning/model calls or production source change. Original profile operator remains preserved and unused.','original_operator_manifest_sha256':sha(F/'OPERATOR_SHA256.json'),'previous_profile_amendment_sha256':sha(F/'PROFILE_INSTRUMENTATION_AMENDMENT.json'),'additional_operator_sha256':{'operators/K04R/stage_diagnostic_profile_v2.json':sha(new)},'same_native_label_not_previously_consumed':True,'same_single_map_budget':True}
(F/'PROFILE_INSTRUMENTATION_AMENDMENT_2.json').write_text(json.dumps(a,indent=2)+'\n',encoding='utf-8')
code=r'''
from pathlib import Path
import sys,json,base64,hashlib
F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F10_visibility_fix_20261026');assert not(F/'K04R_DIAG').exists()
for n,b in json.load(sys.stdin).items():
 p=F/n;assert not p.exists();p.write_bytes(base64.b64decode(b))
a=json.loads((F/'PROFILE_INSTRUMENTATION_AMENDMENT_2.json').read_text());assert a['original_operator_manifest_sha256']==hashlib.sha256((F/'OPERATOR_SHA256.json').read_bytes()).hexdigest()
print('Cached policy counters staged for the same not-yet-run diagnostic; no extra game')
'''
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps({str(p.relative_to(F)).replace('\\','/'):base64.b64encode(p.read_bytes()).decode() for p in [new,F/'PROFILE_INSTRUMENTATION_AMENDMENT_2.json']}).encode(),check=True)
