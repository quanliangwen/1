from pathlib import Path
import json,base64,ast,hashlib,datetime,subprocess,shlex
F=Path(__file__).resolve().parent;p=F/'operators/K04R/stage_diagnostic.json';d=json.loads(p.read_text(encoding='utf-8'))
s=base64.b64decode(d['payload']['mixin']).decode()
marker='        self._diag_first_complete = None\n';assert s.count(marker)==1
s=s.replace(marker,marker+'''        self._profile_stall_active=False
        self._profile_episode=0
        self._profile_episode_rejects=0
        self._profile_rejections={'calls':0,'nonempty_goals':0,'same_episode_extra_goals':0}
        original_get=self.memory.geometry_cache.get
        def observed_get(*args,**kwargs):
            started=time.perf_counter()
            try:
                view=original_get(*args,**kwargs)
                if not getattr(view,'_profile_route_wrapped',False):
                    original=view.route_to
                    def observed_route(*a,_original=original,**k):
                        begun=time.perf_counter()
                        try:return _original(*a,**k)
                        finally:self._diag_record_cost('geometry_fallback_route_to',begun)
                    view.route_to=observed_route
                    view._profile_route_wrapped=True
                return view
            finally:self._diag_record_cost('geometry_view_get',started)
        self.memory.geometry_cache.get=observed_get
        original_reject=self.memory.reject_goal
        def observed_reject(*args,**kwargs):
            self._profile_rejections['calls']+=1
            if self.memory.exploration_goal is not None:
                self._profile_rejections['nonempty_goals']+=1
                if self._profile_stall_active and self._profile_episode_rejects>0:
                    self._profile_rejections['same_episode_extra_goals']+=1
                self._profile_episode_rejects+=1
            return original_reject(*args,**kwargs)
        self.memory.reject_goal=observed_reject
''')
marker="'current_goal':None if self.goal is None else np.asarray(self.goal).tolist(),";assert s.count(marker)==1
s=s.replace(marker,marker+" 'exploration_rejections':dict(self._profile_rejections), 'stall_episodes':self._profile_episode,")
s+='''
    def _messages(self):
        active=self.stuck_steps>=30
        if active and not self._profile_stall_active:
            self._profile_episode+=1
            self._profile_episode_rejects=0
        self._profile_stall_active=active
        return super()._messages()
'''
ast.parse(s);d['payload']['mixin']=base64.b64encode(s.encode()).decode()
new=F/'operators/K04R/stage_diagnostic_profile.json';assert not new.exists();new.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
amend={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Prospective extra own-controller passive timers in the already planned fresh K04R diagnostic, so next round can rank geometry compute vs repeated exploration goal rejection without another native diagnostic. Production candidate ZIP/source/parameters unchanged.','scope':'Only wrap own geometry cache get/route_to and own reject_goal, invoke original exactly once, count own stuck episodes. No extra sensing/planning/rendering, simulator/private/peer/global data or replay. Timing overhead disclosed; not a causal speed or score comparison.','original_operator_manifest_sha256':sha(F/'OPERATOR_SHA256.json'),'original_stage_operator_sha256':sha(p),'additional_operator_sha256':{'operators/K04R/stage_diagnostic_profile.json':sha(new)},'old_stage_operator_unmodified':True,'same_single_map_budget':True}
(F/'PROFILE_INSTRUMENTATION_AMENDMENT.json').write_text(json.dumps(amend,indent=2)+'\n',encoding='utf-8')
code=r'''
from pathlib import Path
import json,sys,base64,hashlib
F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F10_visibility_fix_20261026');d=json.load(sys.stdin)
assert not(F/'K04R_DIAG').exists()
for name,b in d.items():
 p=F/name;assert not p.exists();p.write_bytes(base64.b64decode(b))
a=json.loads((F/'PROFILE_INSTRUMENTATION_AMENDMENT.json').read_text());assert a['original_operator_manifest_sha256']==hashlib.sha256((F/'OPERATOR_SHA256.json').read_bytes()).hexdigest()
print('Prospective own-only K04R diagnostic profiling staged; no new game or source modification')
'''
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps({str(p.relative_to(F)).replace('\\','/'):base64.b64encode(p.read_bytes()).decode() for p in [new,F/'PROFILE_INSTRUMENTATION_AMENDMENT.json']}).encode(),check=True)
