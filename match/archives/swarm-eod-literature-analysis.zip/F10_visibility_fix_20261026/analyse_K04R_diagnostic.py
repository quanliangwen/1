from pathlib import Path
import json,math,statistics,datetime
F=Path(__file__).resolve().parent;G=F/'K04R_DIAG'
assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'))['valid']
events=json.loads((G/'EVENTS.json').read_text(encoding='utf-8'));last={};owners={}
for t in events['F10_DIAG_TICK']:last[t['owner']]=t;owners.setdefault(t['owner'],[]).append(t)
row=json.loads((G/'RESULT.json').read_text(encoding='utf-8'))['row']
costs={}
for k in set(k for t in last.values() for k in t['costs']):
    costs[k]={'calls':sum(t['costs'].get(k,{}).get('calls',0) for t in last.values()),'seconds':sum(t['costs'].get(k,{}).get('seconds',0) for t in last.values())}
views={k:sum(t['viewpoint'].get(k,0) for t in last.values()) for k in ['calls','reranked','suggested_changes','returned_rerank_goal','peer_views','seconds']}
terminal={k:sum(t['terminal_policy'].get(k,0) for t in last.values()) for k in ['acquisition_calls','acquisition_continue','commitment_calls','commitment_defer']}
rejects={k:sum(t['exploration_rejections'].get(k,0) for t in last.values()) for k in ['calls','nonempty_goals','same_episode_extra_goals']}
seeking_full=[];seeking_at_rally=[];lag=[];lag_calls=[]
for owner,ticks in owners.items():
    for i,t in enumerate(ticks):
        s=t['decision_snapshot'];p=s['pose'];r=s['rally']
        if t['stock']>0 and s['seeking_fusion'] and s['fleet_plan'] is None and not s['coverage_ready'] and len(s['fresh_agents'])==5:
            record={k:t[k] for k in ['owner','step','stock','remaining_steps','wall_left']};record['leader']=s['own_is_elected_leader'];seeking_full.append(record)
            if p is not None and r is not None and math.dist(p,r)<48:seeking_at_rally.append(record)
        old=next((v for v in reversed(ticks[:i]) if v['step']<=t['step']-48),None)
        remaining=t['remaining_steps'];left=t['wall_left']
        if old is None or t['stock']<=0 or remaining<=0 or abs(remaining-(row['timestep_limit']-t['step']-24))<1e-6:continue
        estimate=(left-5)/remaining
        if estimate>5/24:estimate=left/(remaining+24)
        if estimate<=0:continue
        recent=(old['wall_left']-left)/(t['step']-old['step'])
        previous=ticks[i-1] if i else t
        calls=t['terminal_policy']['acquisition_calls']-previous['terminal_policy']['acquisition_calls']
        continues=t['terminal_policy']['acquisition_continue']-previous['terminal_policy']['acquisition_continue']
        record={'owner':owner,'step':t['step'],'stock':t['stock'],'coverage_ready':s['coverage_ready'],'recent_seconds_per_step':recent,'inferred_budget_rate':estimate,'recent_over_estimated':recent/estimate,'remaining_steps':remaining,'new_acquisition_calls':calls,'new_acquisition_continues':continues}
        lag.append(record)
        if calls>0 and recent/estimate>1.25:lag_calls.append(record)
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Analysis of first-client-verified own-controller JSON snapshots only. Nested wallclock components cannot be added; no historical arrays decoded or replayed, no causal or score-gain inference. Budget rate reconstructed from exact public remaining_steps formula when not timestep-bound; recent rate uses past48+ step samples.',
'row_RED_only':{'map_score':row['phase']['score_map'],'placed':row['placed'],'expected':row['expected'],'steps':row['timestep'],'walltime':row['walltime']},'costs_nested':costs,'viewpoint':views,'terminal_counts':terminal,'exploration_rejections':rejects,
'full_fresh_still_seeking_no_plan_ticks':len(seeking_full),'full_fresh_at_rally_still_seeking_no_plan_ticks':len(seeking_at_rally),'seeking_full_first_last':seeking_full[:3]+seeking_full[-3:],
'positive_inventory_rate_samples':len(lag),'positive_inventory_recent_rate_over125pct':sum(v['recent_over_estimated']>1.25 for v in lag),'acquisition_evaluated_during_rate_lag_samples':len(lag_calls),'acquisition_rate_lag_examples':lag_calls[:12],'largest_rate_lag_examples':sorted(lag,key=lambda v:-v['recent_over_estimated'])[:5],
'rejected_hypotheses':'Commitment deferral did not occur in this run; all10 inventory completed. No full-fresh-team-at-rally fusion deadlock observed. Geometry fallback search cost is small. Do not claim these explain prior missed drops without further evidence.'}
(G/'ANALYSIS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ['costs_nested','largest_rate_lag_examples']},ensure_ascii=False))
print('COSTS',json.dumps(costs))
