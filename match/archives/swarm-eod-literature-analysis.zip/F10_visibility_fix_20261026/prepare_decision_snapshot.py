from pathlib import Path
import json,base64,ast,hashlib,datetime,subprocess,shlex
F=Path(__file__).resolve().parent;p=F/'operators/K04R/stage_diagnostic_m05_profile.json';d=json.loads(p.read_text(encoding='utf-8'))
s=base64.b64decode(d['payload']['mixin']).decode();assert s.count('    def _diag_state(self):')==1
s=s.replace('    def _diag_state(self):','    def _diag_core_state(self):',1)
s+='''
    def _diag_state(self):
        state=self._diag_core_state()
        step=state['step'];own=state['owner']
        def point(value):
            try:
                a=np.asarray(value,float)
                return a.tolist() if a.shape==(2,) and np.isfinite(a).all() else None
            except (TypeError,ValueError):return None
        active=[int(k) for k,(ts,pos,n) in self.fleet_states.items()
                if pos is not None and 0<=step-ts<self.STATE_FRESH_STEPS]
        plan=self.fleet_plan
        plan_info=None
        if plan is not None:
            entry=plan[2].get(own)
            index=max(0,int(entry[0])-state['stock']) if entry is not None else 0
            plan_info={'age':step-int(plan[0]),'sender':int(plan[1]),
                       'own_stops_remaining':max(0,len(entry[1])-index) if entry is not None else 0}
        state['decision_snapshot']={'pose':point(self.pose),'rally':point(self.rally),
            'coverage_ready':bool(self.coverage_ready),'seeking_fusion':bool(self._seeking_fusion),
            'sortie_state':self._sortie_state,'fresh_agents':sorted(active),
            'own_is_elected_leader':bool(active and own==min(active)),
            'fleet_plan':plan_info,'pending_drop':self.pending_drop is not None,
            'coverage_model':dict(getattr(self,'coverage_model',{}) or {}),
            'memory_exploration_goal':point(getattr(self.memory,'exploration_goal',None))}
        return state
'''
ast.parse(s);d['payload']['mixin']=base64.b64encode(s.encode()).decode()
new=F/'operators/K04R/stage_diagnostic_m05_decisions.json';assert not new.exists();new.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Complete passive own decision snapshot for the same not-yet-run single original Map05 diagnostic: cached pose/rally, current plan age/own remaining stops, fresh received agents/election, fusion/coverage/sortie states, pending drop and already computed coverage model. Distinguish planner/wait-for-fusion/defer/motion mechanisms without another game.','no_extra_api_model_or_plan_calls':True,'production_source_unchanged':True,'previous_map05_amendment_sha256':sha(F/'MAP05_DIAGNOSTIC_AMENDMENT.json'),'original_operator_manifest_sha256':sha(F/'OPERATOR_SHA256.json'),'additional_operator_sha256':{'operators/K04R/stage_diagnostic_m05_decisions.json':sha(new)},'same_single_native_budget':True,'previous_unused_operators_preserved':True}
(F/'DECISION_SNAPSHOT_AMENDMENT.json').write_text(json.dumps(a,indent=2)+'\n',encoding='utf-8')
code=r'''
from pathlib import Path
import sys,json,base64,hashlib
F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F10_visibility_fix_20261026');assert not(F/'K04R_DIAG').exists() and not(F/'K04R/CONTRACT_RESULT.json').exists()
for n,b in json.load(sys.stdin).items():
 p=F/n;assert not p.exists();p.write_bytes(base64.b64decode(b))
print('Same pending Map05 diagnostic: own cached decision snapshot prepared; no extra game or candidate change')
'''
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps({str(p.relative_to(F)).replace('\\','/'):base64.b64encode(p.read_bytes()).decode() for p in [new,F/'DECISION_SNAPSHOT_AMENDMENT.json']}).encode(),check=True)
