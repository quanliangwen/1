from pathlib import Path
import json,datetime,subprocess,shlex
F=Path(__file__).resolve().parent;G=F/'K04R_DIAG'
assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'))['valid']
a=json.loads((G/'ANALYSIS.json').read_text(encoding='utf-8'));s=a['viewpoint'];control=a['costs_nested']['control_total']['seconds']
assert s['returned_rerank_goal']>0 and s['seconds']/control<=.10
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':'K04R','start_five_map_now':True,'diagnostic_map':'Map05','viewpoint_counts':s,'control_seconds':control,'cost_share':s['seconds']/control,'stock':[10,10],'map_score_RED_diagnostic_only':a['row_RED_only']['map_score'],'first_qualification_checks':106,'client_raw_verified':True,
'reason':'Manual review of the prospectively amended single original Map05 diagnostic:13 returned rerank goals,15 suggested changes over63 reranks/209 calls,75 peer views; helper0.24296s/control206.75987s=0.11751%. All10 drops, no crash and seven first-client raw entries verified. Genuine low-cost opportunity, not counterfactual whole-policy or score-gain proof. No commitment defer in81 calls and only1.56366s geometry fallback; do not tune unobserved hypotheses. Proceed only to frozen original-five contemporary PJ01 interleaving. No changes to candidate, scoring, clocks or inputs.'}
p=G/'MECHANISM_REVIEW.json';assert not p.exists();p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
rf='/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F10_visibility_fix_20261026/K04R_DIAG/MECHANISM_REVIEW.json'
code="from pathlib import Path;import sys;p=Path("+repr(rf)+");assert not p.exists();p.write_bytes(sys.stdin.buffer.read())"
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=p.read_bytes(),check=True)
print(json.dumps(d))
