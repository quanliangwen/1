"""Finite declared studies only. Reviews are deterministic, not model reasoning."""
from pathlib import Path
import json,os,sys,time,datetime,subprocess,hashlib,fcntl,traceback,statistics
R=Path('/home/junhao/quan/parallel_test_solver/match')
F=Path(__file__).resolve().parent
PY=str(R/'.venv/bin/python')
STOP=F/'STOP_REQUESTED'
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']}
env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(p):return json.loads(p.read_text())
def save(p,d):
    q=p.with_suffix(p.suffix+'.tmp');q.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');q.replace(p)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def alive(pid):
    p=Path('/proc')/str(pid)/'stat'
    try:return p.exists() and p.read_text().split()[2]!='Z'
    except (FileNotFoundError,ProcessLookupError):return False
def check_stop():
    if STOP.exists():raise InterruptedError('Human stop; no continuation')
    if (F/'FIRST_NATIVE_ERROR.json').exists():raise RuntimeError('First native/backend error preserved; stop entire chain')
def idle():
    a=read(R/'solver_study/heuristic_20261016.json')
    if a.get('active_processes') or a.get('current_formal_active'):return False
    try:
        with (R/'solver_study/serial_evaluation.lock').open('a+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:return False
    return True
def await_idle():
    deadline=time.monotonic()+120
    while not idle():
        check_stop()
        if time.monotonic()>deadline:raise RuntimeError('Idle audit timeout; no relaunch')
        time.sleep(2)
def operator(v,name):
    check_stop();await_idle()
    p=F/'operators'/v/(name+'.json');d=read(p)
    assert sha(p)==AMEND['operator_sha256'][str(p.relative_to(F))]
    out=F/'operators'/v/(name+'_first_console.log');assert not out.exists()
    with out.open('x') as log:
        result=subprocess.run([PY,'-u','-c',d['code']],input=json.dumps(d['payload']).encode(),cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    assert result.returncode==0,'First '+v+'/'+name+' failed; preserve log, no retry'
def notes(record):
    with (F/'RULE_REVIEW_LOG.jsonl').open('a') as out:out.write(json.dumps(record,ensure_ascii=False)+'\n')
    with (F/'规则复盘记录.txt').open('a') as out:out.write(utc()+' '+json.dumps(record,ensure_ascii=False)+'\n')
def pair_review(v,n):
    P=F/(v+'_PERF');p=P/('PAIR_'+str(n)+'_REVIEW.json')
    if p.exists():return
    state=read(P/'STATUS.json');assert state['status']=='WAITING_FOR_AGENT_PAIR_REVIEW' and state['pairs_complete']==n
    docs=[]
    for item in state['completed']:
        G=P/(item['version']+'_'+item['cohort']);d=read(G/'RESULT.json');a=read(G/'ARCHIVE_RECEIPT.json');scope=read(G/'SCOPE_POST.json')
        assert d['valid'] and d['complete'] and len(d['rows'])==5
        assert d['source_zip_sha256']==read(P/'RUN_PLAN.json')['sources'][d['version']]['zip_sha256']
        assert sha(G/'RAW_SHA256.json')==a['raw_manifest_sha256']==d['raw_manifest_sha256']
        assert sha(G/'raw_results.tar.gz')==a['archive_sha256']==d['archive_sha256']
        assert all(scope[k] for k in ['base_source_unchanged','base_zip_unchanged','core_unchanged','blue_core_unchanged','run_server_unchanged','worker_unchanged','evaluator_unchanged','payload_unchanged','original_registry_unchanged','own_processes_exited','lock_free'])
        for r in d['rows']:assert abs(.5*r['map_score']+.2*r['wall_score']+.2*r['completion_adjusted_blue']+.1*r['time_score']-r['full_score'])<1e-9
        docs.append(d)
    a=[d for d in docs if d['version']==v];b=[d for d in docs if d['version']=='PJ01'];assert len(a)==len(b)==n
    am=statistics.mean(d['equal_weight_mean'] for d in a);bm=statistics.mean(d['equal_weight_mean'] for d in b)
    assert min(d['equal_weight_mean'] for d in a)>=80 and (n!=2 or am>bm)
    terms={k:w*(statistics.mean(r[k] for d in a for r in d['rows'])-statistics.mean(r[k] for d in b for r in d['rows'])) for k,w in [('map_score',.5),('wall_score',.2),('completion_adjusted_blue',.2),('time_score',.1)]}
    reason='按冻结资源规则继续第二轮同期对照。' if n==1 else ('两轮累计严格高于同期对照，继续已声明C/D确认。' if n==2 else '完成已声明四轮确认，不临时添加第三轮挑分门槛。')
    record={'utc':utc(),'candidate_id':v,'pairs_complete':n,'continue':True,'reason':reason+' 固定规则复盘，不是离线模型推理；无统一随机种子，不作因果或显著性结论。','candidate_mean':am,'control_mean':bm,'difference':am-bm,'weighted_term_differences':terms,'candidate_placed':sum(r['placed'] for d in a for r in d['rows']),'control_placed':sum(r['placed'] for d in b for r in d['rows']),'server_scope_archive_score_audited':True,'client_first_raw_pending':[d['version']+'_'+d['cohort'] for d in docs if not (P/(d['version']+'_'+d['cohort'])/'CLIENT_FIRST_RAW_REVIEW.json').exists()],'rule_based_review':True,'amendment_sha256':sha(F/'CONTINUATION_AMENDMENT.json')}
    notes(record);save(p,record)
def performance(v):
    P=F/(v+'_PERF')
    deadline=time.monotonic()+30
    while not (P/'STATUS.json').exists():
        check_stop()
        if time.monotonic()>deadline:raise RuntimeError('Performance coordinator did not create status; no retry')
        time.sleep(.2)
    while True:
        check_stop();s=read(P/'STATUS.json')
        if s['status']=='WAITING_FOR_AGENT_PAIR_REVIEW':pair_review(v,int(s['pairs_complete']))
        if s['status'] in ['EARLY_SCREENED_VALID_SCORE','COMPLETE_ALL_EIGHT_PAIRED_GROUPS']:
            if not alive(s['pid']):
                await_idle();notes({'utc':utc(),'phase':v,'result':read(P/'RESULT.json'),'rule_based_terminal_review':True});return
        elif s['status'] in ['CLOSED_FIRST_FAILURE_NO_RETRY','STOPPED_BY_HUMAN']:raise RuntimeError('Performance stopped: '+v+' '+s['status'])
        time.sleep(3)
def diagnostic(v):
    G=F/(v+'_DIAG');deadline=time.monotonic()+750
    while not (G/'RESULT.json').exists():
        check_stop()
        if (G/'STATUS.json').exists() and 'FAILURE' in read(G/'STATUS.json')['status']:raise RuntimeError('First diagnostic failure '+v)
        if time.monotonic()>deadline:raise RuntimeError('Diagnostic coordinator watchdog; no retry')
        time.sleep(3)
    launcher=read(G/'LAUNCH_COORDINATOR.json')
    while alive(launcher['pid']):check_stop();time.sleep(1)
    await_idle();result=read(G/'RESULT.json');assert result['valid'] and result['complete'] and not result['row']['crashed']
    assert sha(G/'RAW_SHA256.json')==result['raw_manifest_sha256'] and sha(G/'raw_results.tar.gz')==result['raw_archive_sha256']
    latest={}
    for t in read(G/'EVENTS.json')['F09_DIAG_TICK']:latest[t['owner']]=t
    names=['calls','reranked','suggested_changes','returned_rerank_goal','candidates','peer_views','seconds']
    counts={k:sum(t['viewpoint'].get(k,0) for t in latest.values()) for k in names}
    control=sum(t['costs'].get('control_total',{}).get('seconds',0) for t in latest.values())
    share=counts['seconds']/max(1e-9,control)
    admit=counts['returned_rerank_goal']>0 and share<=AMEND['view_optional_cost_share_limit']
    reason=('普通探索确实返回了不同于原始top的重排目标，额外重排计时占控制总计时比例在预声明预算内，进入完整同期测试。' if admit else '未满足普通探索返回变化/额外开销预算，停止此方向扩大。')
    reason+=' 这不是整个原策略的反事实，也不证明新增观测或提分；单图无BLUE，不能排名。库存和建图分仅诊断；后续总分判断沿用<80及两轮同期门槛。'
    record={'utc':utc(),'candidate_id':v,'start_five_map_now':admit,'viewpoint_counts':counts,'control_seconds_nested':control,'viewpoint_cost_share':share,'limit':AMEND['view_optional_cost_share_limit'],'reason':reason,'stock':[result['row']['placed'],result['row']['expected']],'map_score_diagnostic_only':result['row']['phase']['score_map'],'client_first_raw_pending':True,'rule_based_review':True,'amendment_sha256':sha(F/'CONTINUATION_AMENDMENT.json')}
    notes(record);p=G/'MECHANISM_REVIEW.json';assert not p.exists();save(p,record)
    return admit
def overview(status,error=None):
    rows=[]
    for v in ['K02R','K04R']:
        entry={'candidate':v}
        for suffix in ['','_DIAG','_PERF']:
            G=F/(v+suffix)
            for n in (['BUILD.json','CONTRACT_RESULT.json'] if suffix=='' else ['STATUS.json','MECHANISM_REVIEW.json','RESULT.json']):
                if (G/n).exists():entry[suffix+'_'+n]=read(G/n)
        rows.append(entry)
    doc={'utc':utc(),'status':status,'error':error,'stages':rows,'scope':'The two remaining selected independent repaired directions only; K01 finished separately in F09. Deterministic finite reviews, no offline model reasoning, no source tuning, no upload. First Windows raw checks remain explicitly pending where missing.'}
    save(F/'FINITE_FINAL_OVERVIEW.json',doc)
    lines=['F10可见性修复后两方向后台测试汇总','状态：'+status,'生成UTC：'+utc()]
    for entry in rows:
        v=entry['candidate'];lines+=['',v]
        if '_DIAG_MECHANISM_REVIEW.json' in entry:lines.append('机制判断：'+entry['_DIAG_MECHANISM_REVIEW.json']['reason'])
        S=entry.get('_PERF_STATUS.json',{})
        for name in ['PJ01',v]:
            values=[r['mean'] for r in S.get('completed',[]) if r['version']==name]
            if values:lines.append(name+'：'+','.join('%.6f'%x for x in values)+'；平均%.6f'%statistics.mean(values))
        if S:lines.append('性能状态：'+S['status']+'；'+S.get('reason',''))
    if error:lines.append(error)
    lines+=['','未统一随机种子，不作因果或统计显著性结论。未通过官网容器，不自动推荐/上传候选包。','首次Windows归档核验在重新上线后逐组补齐；服务器归档SHA/计分/范围已按阶段核验。']
    (F/'FINITE_FINAL_REPORT.txt').write_text('\n'.join(lines)+'\n')

lock=(F/'finite_bridge.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not (F/'FINITE_BRIDGE_STATUS.json').exists(),'Bridge already consumed'
AMEND=read(F/'CONTINUATION_AMENDMENT.json')
assert sha(Path(__file__))==AMEND['bridge_sha256']
state={'utc':utc(),'pid':os.getpid(),'status':'RUNNING','current':'K02R','finished':[],'rule_based_reviews':True}
save(F/'FINITE_BRIDGE_STATUS.json',state)
try:
    performance('K02R');state['finished'].append('K02R');save(F/'FINITE_BRIDGE_STATUS.json',state)
    for v in ['K04R']:
        check_stop();state.update(current=v,stage='qualification',updated_utc=utc());save(F/'FINITE_BRIDGE_STATUS.json',state)
        operator(v,'qualify')
        assert read(F/v/'CONTRACT_RESULT.json')['status']=='PASS'
        state.update(stage='single_map_mechanism',updated_utc=utc());save(F/'FINITE_BRIDGE_STATUS.json',state)
        operator(v,'stage_diagnostic')
        if diagnostic(v):
            operator(v,'prepare_performance');operator(v,'launch_performance')
            state.update(stage='interleaved_five_maps',updated_utc=utc());save(F/'FINITE_BRIDGE_STATUS.json',state)
            performance(v)
        state['finished'].append(v);save(F/'FINITE_BRIDGE_STATUS.json',state)
    state.update(status='COMPLETE_SELECTED_REPAIRED_TWO',finished_utc=utc());save(F/'FINITE_BRIDGE_STATUS.json',state);overview(state['status'])
except BaseException:
    error=traceback.format_exc();state.update(status='STOPPED_FIRST_ERROR_NO_RETRY',error=error,finished_utc=utc())
    save(F/'FINITE_BRIDGE_FIRST_ERROR.json',{'utc':utc(),'error':error,'no_retry':True});save(F/'FINITE_BRIDGE_STATUS.json',state);overview(state['status'],error);raise
