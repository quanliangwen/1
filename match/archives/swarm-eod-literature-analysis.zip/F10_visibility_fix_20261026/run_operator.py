from pathlib import Path
import sys,subprocess
F=Path(__file__).resolve().parent;v,name=sys.argv[1:3]
assert v in ['K02R','K04R'] and name in ['qualify','stage_diagnostic','stage_diagnostic_profile','stage_diagnostic_profile_v2','stage_diagnostic_m05_profile','stage_diagnostic_m05_decisions','prepare_performance','launch_performance']
code=r'''
from pathlib import Path
import json,subprocess,os,hashlib
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F10_visibility_fix_20261026';v=VERSION;name=OPERATION
p=F/'operators'/v/(name+'.json');expected=json.loads((F/'OPERATOR_SHA256.json').read_text())
if name in ['stage_diagnostic_profile','stage_diagnostic_profile_v2','stage_diagnostic_m05_profile','stage_diagnostic_m05_decisions']:
 file='DECISION_SNAPSHOT_AMENDMENT.json' if name=='stage_diagnostic_m05_decisions' else ('MAP05_DIAGNOSTIC_AMENDMENT.json' if name=='stage_diagnostic_m05_profile' else ('PROFILE_INSTRUMENTATION_AMENDMENT_2.json' if name.endswith('_v2') else 'PROFILE_INSTRUMENTATION_AMENDMENT.json'))
 amend=json.loads((F/file).read_text());assert amend['original_operator_manifest_sha256']==hashlib.sha256((F/'OPERATOR_SHA256.json').read_bytes()).hexdigest();expected.update(amend['additional_operator_sha256'])
assert hashlib.sha256(p.read_bytes()).hexdigest()==expected[str(p.relative_to(F))]
d=json.loads(p.read_text());log=p.with_name(name+'_manual_first_console.log');assert not log.exists()
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with log.open('x') as out:r=subprocess.run([str(R/'.venv/bin/python'),'-u','-c',d['code']],input=json.dumps(d['payload']).encode(),cwd=R,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=180)
print(log.read_text());raise SystemExit(r.returncode)
'''.replace('VERSION',repr(v)).replace('OPERATION',repr(name))
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python','-'],input=code.encode(),check=True)
