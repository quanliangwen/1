from pathlib import Path
import json,hashlib,subprocess,sys,tarfile,shutil,datetime,base64,shlex,os
assert os.name=='nt','ExecuteclientverificationonWindows'
BASE=Path(__file__).resolve().parent
direction,version,cohort=sys.argv[1:4]
assert direction in ['K02R','K04R']
F=BASE/(direction+'_PERF')
R='/home/junhao/quan/parallel_test_solver/match';RF=R+'/solver_study/framework_screen_20261016/best87_independent_20261025/F10_visibility_fix_20261026/'+direction+'_PERF'
phase=json.loads((F/'RUN_PLAN.json').read_text(encoding='utf-8'));assert {'version':version,'cohort':cohort,'label':'f10pair_20261026_'+direction+'_'+version+'_'+cohort} in phase['order']
G=F/(version+'_'+cohort);G.mkdir(exist_ok=True);receiptpath=G/'CLIENT_FIRST_RAW_REVIEW.json';assert not receiptpath.exists(),'Alreadyclientverified; do not repeatraw'
remote="from pathlib import Path;import json,base64;p=Path("+repr(RF+'/'+G.name)+");assert not(p/'CLIENT_FIRST_RAW_REVIEW.json').exists(),'Alreadyclientverified';names=['RESULT.json','ARCHIVE_RECEIPT.json','RAW_SHA256.json','PREDECLARATION.json','PREFLIGHT.json','GAME_PREDECLARATION.json','LAUNCH.json','SCOPE_POST.json'];print(json.dumps({n:base64.b64encode((p/n).read_bytes()).decode() for n in names}))"
bundle=json.loads(subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=20','junhao@10.112.162.60',R+'/.venv/bin/python','-'],input=remote.encode()))
data={n:base64.b64decode(v) for n,v in bundle.items()};read=lambda n:json.loads(data[n]);sha=lambda b:hashlib.sha256(b).hexdigest()
result=read('RESULT.json');archive=read('ARCHIVE_RECEIPT.json');manifest=read('RAW_SHA256.json');decl=read('PREDECLARATION.json');pre=read('PREFLIGHT.json');game=read('GAME_PREDECLARATION.json');launch=read('LAUNCH.json');scope=read('SCOPE_POST.json')
assert result['valid'] and result['complete'] and result['cold_start'] and result['new_algorithm_version'] == (version==direction)
assert result['version']==version and result['cohort']==cohort and len(result['rows'])==5
assert result['source_zip_sha256']==game['source_zip_sha256']==phase['sources'][version]['zip_sha256']==decl['base_zip_sha256']
assert decl['source_files']==phase['sources'][version]['source_files'] and pre['red']=={k:v for k,v in decl['source_files'].items() if k!='req.txt'}
assert pre['status']=='PASS' and pre['versions']=={'numpy':'1.26.4','pandas':'3.0.6','cv2':'4.11.0'}
assert game['preflight_sha256']==sha(data['PREFLIGHT.json']) and game['source_predeclaration_sha256']==sha(data['PREDECLARATION.json'])
assert result['phase_predeclaration_sha256']==game['phase_predeclaration_sha256']==sha((F/'PREDECLARATION.json').read_bytes())
assert pre['utc']<game['utc']<launch['utc']<result['utc'] and game['external_seed'] is None and game['cold_new_processes'] and not game['retry']
assert all(scope[k] for k in ['base_source_unchanged','base_zip_unchanged','core_unchanged','blue_core_unchanged','run_server_unchanged','worker_unchanged','evaluator_unchanged','payload_unchanged','original_registry_unchanged','own_processes_exited','lock_free'])
assert sha(data['RAW_SHA256.json'])==archive['raw_manifest_sha256']==result['raw_manifest_sha256'] and len(manifest)==archive['raw_files']
rows=sorted(result['rows'],key=lambda x:x['map']);assert [x['map'] for x in rows]==['Map%02d'%i for i in range(1,6)]
for row in rows:
 value=.5*row['map_score']+.2*row['wall_score']+.2*row['completion_adjusted_blue']+.1*row['time_score'];assert abs(value-row['full_score'])<1e-9
mean=sum(row['full_score'] for row in rows)/5;assert abs(mean-result['equal_weight_mean'])<1e-10
raw=G/'raw_results.tar.gz';assert not raw.exists(),'Existingunverifiedlocalarchivepreserved; inspectratherthanoverwrite'
needed=archive['archive_bytes']+sum(map(len,data.values()))+5*1024*1024;assert shutil.disk_usage(F).free>needed,'Espaceguard; rootarchivekeep, no rawverificationdone'
for n,b in data.items():
 p=G/n
 if p.exists():assert p.read_bytes()==b,('Localmetadatabytesdiffer',n)
 else:p.write_bytes(b)
subprocess.run(['scp','-q','junhao@10.112.162.60:'+RF+'/'+G.name+'/raw_results.tar.gz',str(raw)],check=True)
digest=hashlib.sha256()
with raw.open('rb') as f:
 for block in iter(lambda:f.read(1024*1024),b''):digest.update(block)
assert digest.hexdigest()==archive['archive_sha256']==result['archive_sha256']
verified=set()
with tarfile.open(raw,'r:gz') as t:
 for entry in t:
  assert entry.isfile() and entry.name in manifest and entry.name not in verified
  source=t.extractfile(entry);digest=hashlib.sha256();length=0
  for block in iter(lambda:source.read(1024*1024),b''):digest.update(block);length+=len(block)
  assert length==manifest[entry.name]['bytes'] and digest.hexdigest()==manifest[entry.name]['sha256'],entry.name
  verified.add(entry.name)
assert verified==set(manifest)
terms={k:sum(r[k] for r in rows)/5 for k in ['map_score','wall_score','completion_adjusted_blue','time_score']}
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'version':version,'cohort':cohort,'valid':True,'mean':mean,'terms':terms,'stock':[r['placed'] for r in rows],'crashes':sum(r['red_crashed'] or r['blue_crashed'] for r in rows),'source_zip_sha256':result['source_zip_sha256'],'phase_predeclaration_sha256':result['phase_predeclaration_sha256'],'raw_manifest_sha256':archive['raw_manifest_sha256'],'raw_files_verified':len(verified),'archive_sha256':archive['archive_sha256'],'local_compressed_archive':str(raw),'local_disk_persistence_pending':False,'result_sha256':sha(data['RESULT.json']),'scope':'FirstWindowsclientcompressedarchivepersistedandallrawentrySHA/fourterms/source/preflight/freshgamecontextchecked. RawNPZ/pickletreatedopaque, neverexpandedorusedinproduction. No newgame/collector/profile/observer replay. Notpairedcausal/stabilityproof.'}
receiptpath.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
remote="from pathlib import Path;import sys;p=Path("+repr(RF+'/'+G.name+'/CLIENT_FIRST_RAW_REVIEW.json')+");assert not p.exists();p.write_bytes(sys.stdin.buffer.read())"
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60',R+'/.venv/bin/python -c '+shlex.quote(remote)],input=receiptpath.read_bytes(),check=True)
print(json.dumps(receipt))

