from pathlib import Path
import base64,json,subprocess,shlex
F=Path(__file__).resolve().parent
payload={n:base64.b64encode((F/n).read_bytes()).decode() for n in ['fixed_site_schedule.py','schedule_tests.py']}
code=r'''
from pathlib import Path
import json,sys,base64,hashlib,ast,subprocess,os
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F14_fixed_sites_schedule_20261027'
d=json.load(sys.stdin);Q=F/'helper_qualification';assert not Q.exists();Q.mkdir()
binding={}
for n,b in d.items():
 raw=base64.b64decode(b);ast.parse(raw.decode());(Q/n).write_bytes(raw);binding[n]=hashlib.sha256(raw).hexdigest()
(Q/'SOURCE_BINDING.json').write_text(json.dumps(binding,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with (Q/'first_console.log').open('x') as log:r=subprocess.run([str(R/'.venv/bin/python'),str(Q/'schedule_tests.py'),str(Q/'FIRST_RESULT.json')],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
report=json.loads((Q/'FIRST_RESULT.json').read_text());print(json.dumps({'status':report['status'],'checks':len(report['checks']),'error':report.get('error')}));raise SystemExit(r.returncode)
'''
p=subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps(payload).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert not(F/'helper_first_console.txt').exists();(F/'helper_first_console.txt').write_bytes(p.stdout+p.stderr);print((p.stdout+p.stderr).decode(errors='replace'));raise SystemExit(p.returncode)
