import sys,subprocess
name=sys.argv[1];assert name=='PARENT_M05'
code=r'''
from pathlib import Path
import json,hashlib,base64,shutil,fcntl,subprocess,os,ast,datetime
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F14_fixed_sites_schedule_20261027'
name=JOB;decl=json.loads((F/'PREDECLARATION.json').read_text());P=decl['parent'];O=F/'observer_qualification'
assert json.loads((O/'FIRST_RESULT.json').read_text())['status']=='PASS'
assert not(F/'FIRST_NATIVE_ERROR.json').exists() and not(F/'STOP_REQUESTED').exists()
a=json.loads((R/'solver_study/heuristic_20261016.json').read_text());assert not a.get('active_processes') and not a.get('current_formal_active')
with (R/'solver_study/serial_evaluation.lock').open('a+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
binding=json.loads((O/'SOURCE_BINDING.json').read_text());assert {p.name:sha(p) for p in (O/'source').iterdir() if p.is_file()}==binding['observer_source_files']
entry=json.loads((F/'PARENT_OPERATORS.json').read_text())[name];m=entry['map'];runner=base64.b64decode(entry['runner_base64']);assert hashlib.sha256(runner).hexdigest()==entry['sha256']
G=F/(name+'_DIAG');assert not G.exists();G.mkdir();S=G/'source';shutil.copytree(O/'source',S)
blue=Path(json.loads((H/'F07_evidence_three_directions_20261026/infrastructure/PREDECLARATION.json').read_text())['blue_workspace'])
W=R/'experiments/target90_20261012/official_workspaces'/('f14diag_20261027_'+name);assert not W.exists()
shutil.copytree(blue,W,ignore=shutil.ignore_patterns('solutions','__pycache__','*.pyc','.git','.pytest_cache'));sol=W/'src/swarm_rescue/solutions';sol.mkdir()
for p in S.iterdir():shutil.copy2(p,W/'req.txt' if p.name=='req.txt' else sol/p.name)
stage={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'workspace':str(W),'source_files':{p.name:sha(p) for p in S.iterdir() if p.is_file()},'production_parent':P,'production_source':P['source_files'],'observer_source_binding_sha256':sha(O/'SOURCE_BINDING.json'),'not_for_performance_ranking':True,'no_new_algorithm_version':True}
(G/'STAGING.json').write_text(json.dumps(stage,indent=2)+'\n')
(G/'PREDECLARATION.json').write_text(json.dumps({'utc':stage['utc'],'job':name,'control_id':decl['control_id'],'source_zip_sha256':P['zip_sha256'],'kind':'ONE_FRESH_'+m.upper()+'_PARENT_OWN_STATE_DIAGNOSTIC','map':m,'seed':None,'no_retry':True,'BLUE':False,'ranking':False,'new_algorithm':False,'qualification_sha256':sha(O/'FIRST_RESULT.json'),'observer_source_binding_sha256':sha(O/'SOURCE_BINDING.json'),'scope':'Counters plus declared bounded fixed-site suffix schedule advisors and own assignment forecast ledger; original policy commands/submission unchanged; overhead not causal speed or score.'},indent=2)+'\n')
pre=(H/'F08_diagnosis_led_three_20261026/BASELINE_DIAG/preflight.py').read_text();ast.parse(pre);(G/'preflight.py').write_text(pre)
p=F/('run_'+name+'_diagnostic.py');assert not p.exists();p.write_bytes(runner);ast.parse(p.read_text())
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with (F/(name+'_diagnostic_coordinator.log')).open('x') as log:proc=subprocess.Popen([str(R/'.venv/bin/python'),'-u',str(p)],cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'job':name,'control_id':decl['control_id'],'pid':proc.pid,'starttime_ticks':(Path('/proc')/str(proc.pid)/'stat').read_text().split()[21],'source_zip_sha256':P['zip_sha256'],'runner_sha256':sha(p),'source_binding_sha256':stage['observer_source_binding_sha256'],'only_one_RED_diagnostic':True,'new_algorithm':False}
(G/'LAUNCH_COORDINATOR.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
'''.replace('JOB',repr(name))
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python','-'],input=code.encode(),check=True)
