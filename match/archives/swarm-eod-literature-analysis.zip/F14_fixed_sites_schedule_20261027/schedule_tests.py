from pathlib import Path
import sys,json,time,traceback
import numpy as np
from fixed_site_schedule import improve_schedule,AssignmentForecastLedger
checks=[]
def check(n,v):
 assert v,n
 checks.append(n)
try:
 # One owner: visit a distant endpoint then return near start is strictly worse.
 positions=np.array([0.,20.,100.,140.]);D=np.abs(positions[:,None]-positions[None,:])
 plans={2:[2,1]};starts={2:0};caps={2:300.};prefix={2:7.}
 p,a=improve_schedule(plans,starts,D,caps,prefix,16,'order')
 check('reversal_positive',a['reason']=='positive_order' and p=={2:[1,2]})
 check('complete_prefix_included',a['before'][2]==187 and a['after'][2]==107)
 check('source_plan_unchanged',plans=={2:[2,1]})
 check('same_site_set',sorted(p[2])==sorted(plans[2]))
 q,b=improve_schedule(p,starts,D,caps,prefix,16,'order')
 check('already_optimal_unchanged',q==p and b['reason']=='no_qualified_order')
 q,b=improve_schedule(plans,starts,D,{2:100},prefix,16,'order')
 check('invalid_complete_cap_rejects',q==plans and b['reason']=='invalid_incumbent_routes')
 q,b=improve_schedule(plans,starts,D,caps,prefix,16,'order',time.perf_counter()-1)
 check('deadline_abstention',q==plans and b['reason']=='deadline')
 plans={2:[2],7:[1]};starts={2:0,7:3};caps={2:300,7:300};prefix={2:0,7:0}
 p,a=improve_schedule(plans,starts,D,caps,prefix,16,'exchange')
 check('minimax_exchange_positive',p=={2:[1],7:[2]} and a['reason']=='positive_exchange')
 check('max_route_reduced',a['max_after']<=a['max_before']-16)
 check('total_route_nonincrease',a['sum_after']<=a['sum_before'])
 check('owner_counts_preserved',all(len(plans[k])==len(p[k]) for k in plans))
 check('entire_multiset_preserved',sorted(sum(plans.values(),[]))==sorted(sum(p.values(),[])))
 frozen={**plans,8:[]}
 q,b=improve_schedule(frozen,{**starts,8:0},D,{**caps,8:500},{2:0,7:0,8:400},16,'exchange')
 check('immutable_prefix_affects_minimax',q==frozen)
 # One point is unreachable to its potential new owner.
 E=D.copy();E[0,1]=np.inf
 q,b=improve_schedule(plans,starts,E,caps,prefix,16,'exchange')
 check('unreachable_swap_rejected',q==plans)
 q,b=improve_schedule({2:[1],7:[1]},starts,D,caps,prefix,16,'exchange')
 check('duplicate_site_rejected',b['reason']=='invalid_owner_or_duplicate')
 q,b=improve_schedule({2:[1,2,3]},starts,D,caps,prefix,16,'order')
 check('bounded_size',b['reason']=='unsupported_size')
 q,b=improve_schedule(plans,starts,D,caps,prefix,1000,'exchange')
 check('meaningful_cell_gain_required',q==plans)
 # Exhaustive small line fixtures certify output is the best legal declared neighbor.
 rng=np.random.RandomState(615)
 for case in range(32):
  coords=rng.choice(1000,6,replace=False).astype(float);M=np.abs(coords[:,None]-coords[None,:])
  original={2:[2,3],7:[4,5]};st={2:0,7:1};cap={2:5000,7:5000}
  result,ad=improve_schedule(original,st,M,cap,{},1,'exchange')
  def length(k,v):return M[st[k],v[0]]+M[v[0],v[1]]
  before=[length(k,v) for k,v in original.items()];candidates=[]
  for i in range(2):
   for j in range(2):
    z={k:list(v) for k,v in original.items()};z[2][i],z[7][j]=z[7][j],z[2][i]
    lengths=[length(k,v) for k,v in z.items()]
    if max(lengths)<=max(before)-1+1e-6 and sum(lengths)<=sum(before)+1e-6:candidates.append((max(lengths),sum(lengths)))
  check('exhaustive_neighborhood_'+str(case), (not candidates and result==original) or
        (bool(candidates) and (max(length(k,v) for k,v in result.items()),sum(length(k,v) for k,v in result.items()))==min(candidates)))
 L=AssignmentForecastLedger();check('forecast_start',L.observe(10,1.,2,('a',2,10),20.) is None)
 check('same_task_not_reset',L.observe(20,2.,2,('a',2,10),99.) is None and L.current['start_step']==10)
 a=L.observe(50,5.,1,('b',1,50),10.);check('actual_inventory_ack',a['outcome']=='inventory_ack' and a['actual_steps']==40 and a['ratio']==2.)
 a=L.observe(60,6.,1,('c',1,60),12.);check('revision_censored',a['outcome']=='censored_changed_assignment' and 'ratio' not in a)
 check('ledger_restarts_new_task',L.current['start_step']==60 and L.current['identity']==('c',1,60))
 check('none_goal_not_false_completion',L.observe(65,6.5,1,None,None) is None and L.current is not None)
 a=L.observe(72,7.2,0,None,None);check('last_drop_ack',a['outcome']=='inventory_ack' and a['actual_steps']==12 and L.current is None)
 L.observe(100,10.,1,('q',1,100),12.);a=L.cancel(105)
 check('released_goal_censored',a['outcome']=='censored_changed_assignment' and L.current is None)
 result={'status':'PASS','checks':checks}
except BaseException:
 result={'status':'FAIL','checks':checks,'error':traceback.format_exc()}
p=Path(sys.argv[1]);assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'checks':len(checks),'error':result.get('error')}));raise SystemExit(result['status']!='PASS')
