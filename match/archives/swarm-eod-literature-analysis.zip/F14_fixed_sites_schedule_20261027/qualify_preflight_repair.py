from pathlib import Path
import subprocess,shlex
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import json,shutil,subprocess,os,hashlib
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F14_fixed_sites_schedule_20261027';Q=F/'observer_revision1'
assert not(Q/'FIRST_RESULT.json').exists() and not(Q/'QUALIFICATION_RESULT.json').exists()
blue=Path(json.loads((H/'F07_evidence_three_directions_20261026/infrastructure/PREDECLARATION.json').read_text())['blue_workspace'])
W=Q/'workspace';assert not W.exists();shutil.copytree(blue,W,ignore=shutil.ignore_patterns('solutions','__pycache__','*.pyc','.git','.pytest_cache'));sol=W/'src/swarm_rescue/solutions';sol.mkdir()
for p in (Q/'source').iterdir():shutil.copy2(p,W/'req.txt' if p.name=='req.txt' else sol/p.name)
binding=json.loads((Q/'SOURCE_BINDING.json').read_text());(Q/'STAGING.json').write_text(json.dumps({'workspace':str(W),'source_files':binding['observer_source_files']})+'\n')
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with (Q/'first_console.log').open('x') as log:r=subprocess.run(['bash',str(R/'run_server.sh'),'-u',str(Q/'observer_tests.py')],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
d=json.loads((Q/'FIRST_RESULT.json').read_text());assert r.returncode==0 and d['status']=='PASS',d
with (Q/'preflight_first_console.log').open('x') as log:r=subprocess.run(['bash',str(R/'run_server.sh'),'-u',str(Q/'preflight.py')],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert r.returncode==0 and json.loads((Q/'PREFLIGHT.json').read_text())['status']=='PASS'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'status':'PASS','observer_checks':len(d['checks']),'corrected_preflight_first_pass':True,'observer_first_result_sha256':sha(Q/'FIRST_RESULT.json'),'preflight_sha256':sha(Q/'preflight.py'),'preflight_result_sha256':sha(Q/'PREFLIGHT.json'),'source_binding_sha256':sha(Q/'SOURCE_BINDING.json'),'first_failed_precheck_preserved_sha256':sha(F/'FIRST_NATIVE_ERROR.json'),'game_rounds':0}
(Q/'QUALIFICATION_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
'''
r=subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert not(F/'preflight_repair_first_console.txt').exists();(F/'preflight_repair_first_console.txt').write_bytes(r.stdout+r.stderr);print((r.stdout+r.stderr).decode(errors='replace'));raise SystemExit(r.returncode)
