from pathlib import Path
import sys,json,hashlib,ast,datetime
G=Path(__file__).resolve().parent;d=json.loads((G/'STAGING.json').read_text());W=Path(d['workspace']);sys.path.insert(0,str(W/'src'))
import numpy,cv2,pandas,pyglet
import numpy.random.mtrand
from swarm_rescue.solutions.my_drone_eval import MyDroneEval,drone_class_for_mode
from swarm_rescue.simulation.reporting.team_info import TeamInfo
from swarm_rescue.launcher import Launcher
from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
assert drone_class_for_mode('place') is MyDroneEval
assert type(TeamInfo().team_number) is int and TeamInfo().team_number==615
assert (numpy.__version__,cv2.__version__,pandas.__version__)==('1.26.4','4.11.0','3.0.6')
assert [c.__name__ for c in MyDroneEval.__mro__[1:3]]==['ScheduleObservationMixin','DiagnosticMixin']
assert next(c.__name__ for c in MyDroneEval.__mro__ if '_maybe_place' in c.__dict__)=='ActiveCoverageMixin'
assert next(c.__name__ for c in MyDroneEval.__mro__ if '_remaining_steps' in c.__dict__)=='ActiveCoverageMixin'
assert numpy.isfinite(numpy.random.RandomState(615).normal(size=8)).all()
assert pandas.DataFrame({'x':[1,2]}).x.sum()==3
assert cv2.resize(numpy.zeros((4,4),numpy.uint8),(2,2)).shape==(2,2)
win=pyglet.window.Window(width=1,height=1,visible=False);win.close()
for p in (W/'src/swarm_rescue/solutions').glob('*.py'):ast.parse(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert {p.name:sha(p) for p in (W/'src/swarm_rescue/solutions').iterdir() if p.is_file()}=={n:h for n,h in d['source_files'].items() if n!='req.txt'}
assert not(G/'PREFLIGHT.json').exists()
(G/'PREFLIGHT.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS','team_number':615,'native_versions':{'numpy':numpy.__version__,'cv2':cv2.__version__,'pandas':pandas.__version__},'full_native_window_size_unrestricted':True,'contract':'Explicit observer MRO and unchanged underlying actuation/budget; actual ABI operations and SDK imports'})+'\n')
