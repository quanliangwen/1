from pathlib import Path
import base64,subprocess,shlex
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import json,sys,base64,shutil,subprocess,os,ast
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F14_fixed_sites_schedule_20261027';Q=F/'observer_qualification'
assert not(Q/'FIRST_RESULT.json').exists() and not(Q/'first_console.log').exists()
blue=Path(json.loads((H/'F07_evidence_three_directions_20261026/infrastructure/PREDECLARATION.json').read_text())['blue_workspace'])
W=Q/'workspace';assert not W.exists();shutil.copytree(blue,W,ignore=shutil.ignore_patterns('solutions','__pycache__','*.pyc','.git','.pytest_cache'));sol=W/'src/swarm_rescue/solutions';sol.mkdir()
for p in (Q/'source').iterdir():shutil.copy2(p,W/'req.txt' if p.name=='req.txt' else sol/p.name)
p=Q/'observer_tests.py';p.write_bytes(base64.b64decode(sys.stdin.buffer.read()));ast.parse(p.read_text())
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with (Q/'first_console.log').open('x') as log:r=subprocess.run(['bash',str(R/'run_server.sh'),'-u',str(p)],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
d=json.loads((Q/'FIRST_RESULT.json').read_text());print(json.dumps({'status':d['status'],'checks':len(d['checks']),'error':d.get('error')}));raise SystemExit(r.returncode)
'''
r=subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=base64.b64encode((F/'observer_tests.py').read_bytes()),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert not(F/'observer_first_console.txt').exists();(F/'observer_first_console.txt').write_bytes(r.stdout+r.stderr);print((r.stdout+r.stderr).decode(errors='replace'));raise SystemExit(r.returncode)
