from pathlib import Path
import ast,base64,json,hashlib,subprocess,shlex,datetime
F=Path(__file__).resolve().parent
observer=(F/'schedule_observer.py').read_text();marker='    plans={int(k):[np.asarray(p,float).copy() for p in ps] for k,ps in result.items()}\n';assert observer.count(marker)==1
observer=observer.replace(marker,marker+"    for owner in (prefixes or {}): plans.setdefault(int(owner),[])\n")
tests=(F/'observer_tests.py').read_text();marker=" check('prefix_not_reassigned',advice['answers']['order']['alternative']['7']==[])\n";assert tests.count(marker)==1
tests=tests.replace(marker,marker+" advice=observer.schedule_advice(m,agentsb,[],32.,base,2000.,prefixb,(),None,pm,time.perf_counter()+5)\n check('omitted_zero_suffix_owner_still_counted',advice['prefix_costs'][7]==512. and advice['suffix_counts'][7]==0)\n")
preflight='''from pathlib import Path
import sys,json,hashlib,ast,datetime
G=Path(__file__).resolve().parent;d=json.loads((G/'STAGING.json').read_text());W=Path(d['workspace']);sys.path.insert(0,str(W/'src'))
import numpy,cv2,pandas,pyglet
import numpy.random.mtrand
from swarm_rescue.solutions.my_drone_eval import MyDroneEval,drone_class_for_mode
from swarm_rescue.simulation.reporting.team_info import TeamInfo
from swarm_rescue.launcher import Launcher
from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
assert drone_class_for_mode('place') is MyDroneEval
assert type(TeamInfo().team_number) is int and TeamInfo().team_number==615
assert (numpy.__version__,cv2.__version__,pandas.__version__)==('1.26.4','4.11.0','3.0.6')
assert [c.__name__ for c in MyDroneEval.__mro__[1:3]]==['ScheduleObservationMixin','DiagnosticMixin']
assert next(c.__name__ for c in MyDroneEval.__mro__ if '_maybe_place' in c.__dict__)=='ActiveCoverageMixin'
assert next(c.__name__ for c in MyDroneEval.__mro__ if '_remaining_steps' in c.__dict__)=='ActiveCoverageMixin'
assert numpy.isfinite(numpy.random.RandomState(615).normal(size=8)).all()
assert pandas.DataFrame({'x':[1,2]}).x.sum()==3
assert cv2.resize(numpy.zeros((4,4),numpy.uint8),(2,2)).shape==(2,2)
win=pyglet.window.Window(width=1,height=1,visible=False);win.close()
for p in (W/'src/swarm_rescue/solutions').glob('*.py'):ast.parse(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert {p.name:sha(p) for p in (W/'src/swarm_rescue/solutions').iterdir() if p.is_file()}=={n:h for n,h in d['source_files'].items() if n!='req.txt'}
assert not(G/'PREFLIGHT.json').exists()
(G/'PREFLIGHT.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS','team_number':615,'native_versions':{'numpy':numpy.__version__,'cv2':cv2.__version__,'pandas':pandas.__version__},'full_native_window_size_unrestricted':True,'contract':'Explicit observer MRO and unchanged underlying actuation/budget; actual ABI operations and SDK imports'})+'\\n')
'''
for s in [observer,tests,preflight]:ast.parse(s)
for n,s in [('schedule_observer_revision1.py',observer),('observer_tests_revision1.py',tests),('preflight_revision1.py',preflight)]:
 assert not(F/n).exists();(F/n).write_text(s,encoding='utf-8')
amendment={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'SDK_PREFLIGHT_ONLY_REPAIR_NO_SIM_RETRY','first_error_preserved':True,'cause':'Reusable preflight assumed DiagnosticMixin must be immediate MRO ancestor; new readonly ledger precedes it. No LAUNCH/GAME_PREDECL/Map05_red/RESULT existed; simulator was never invoked. Team615/native ABI checks had passed before assertion.',
'observer_audit_gap':'Zero suffix owners are omitted by real market return but can own frozen prefix. Revision includes all actual prefix owners with empty suffix in complete fleet makespan. This is necessary correctness, not performance tuning. No observed game input or outcome used because0games.',
'rule':'Old failed coordinator/paths/results remain sealed. Qualify new observer and corrected preflight separately. Only after PASS may a new coordinator issue the originally budgeted first fresh native RED game. No actual failed game rerun, no altered clock/inputs/SDK/seed, no reset of FIRST_NATIVE_ERROR. If any actual simulator failure occurs, stop with FIRST_SIM_ERROR and no retry.'}
(F/'PREFLIGHT_REPAIR_DECLARATION.json').write_text(json.dumps(amendment,indent=2)+'\n',encoding='utf-8')
payload={'observer':base64.b64encode(observer.encode()).decode(),'tests':base64.b64encode(tests.encode()).decode(),'preflight':base64.b64encode(preflight.encode()).decode(),'declaration':amendment}
code=r'''
from pathlib import Path
import sys,json,base64,hashlib,shutil,fcntl
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F14_fixed_sites_schedule_20261027';G=F/'PARENT_M05_DIAG'
assert (F/'FIRST_NATIVE_ERROR.json').exists()
for n in ['LAUNCH.json','GAME_PREDECLARATION.json','Map05_red','RESULT.json']:assert not(G/n).exists()
s=json.loads((G/'STATUS.json').read_text());p=Path('/proc')/str(s['pid'])/'stat';assert not p.exists() or p.read_text().split()[2]=='Z'
a=json.loads((R/'solver_study/heuristic_20261016.json').read_text());assert not a.get('active_processes') and not a.get('current_formal_active')
lock=(R/'solver_study/serial_evaluation.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
d=json.load(sys.stdin);Q=F/'observer_revision1';assert not Q.exists();Q.mkdir();shutil.copytree(F/'observer_qualification/source',Q/'source')
(Q/'source/schedule_observer.py').write_bytes(base64.b64decode(d['observer']))
(Q/'observer_tests.py').write_bytes(base64.b64decode(d['tests']));(Q/'preflight.py').write_bytes(base64.b64decode(d['preflight']))
binding={'parent':json.loads((F/'PREDECLARATION.json').read_text())['parent'],'observer_source_files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (Q/'source').iterdir() if p.is_file()}}
(Q/'SOURCE_BINDING.json').write_text(json.dumps(binding,indent=2)+'\n');(F/'PREFLIGHT_REPAIR_DECLARATION.json').write_text(json.dumps(d['declaration'],indent=2)+'\n')
(Q/'FAILED_PRECHECK_AUDIT.json').write_text(json.dumps({'first_error_sha256':hashlib.sha256((F/'FIRST_NATIVE_ERROR.json').read_bytes()).hexdigest(),'failed_preflight_sha256':hashlib.sha256((G/'preflight.py').read_bytes()).hexdigest(),'no_simulator_ever_launched':True,'old_paths_preserved':True},indent=2)+'\n')
print('Repair declared and new observer staged. No game started.')
'''
print(subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps(payload).encode()).decode())
