from pathlib import Path
import ast,base64,json,hashlib,subprocess,shlex
F=Path(__file__).resolve().parent;O=F.parent/'F13_completion_joint_transport_20261027'
assert not(F/'PARENT_OPERATORS.json').exists()
e=json.loads((O/'PARENT_OPERATORS.json').read_text())['PARENT_M05']
s=base64.b64decode(e['runner_base64']).decode().replace('F13','F14')
s=s.replace("'F14_LATE_COMPLETION_ADVISOR','F14_LAYOUT_ADVISOR'","'F14_SCHEDULE_ADVISOR','F14_TASK_FORECAST'")
ast.parse(s);bundle={'PARENT_M05':{'runner_base64':base64.b64encode(s.encode()).decode(),'sha256':hashlib.sha256(s.encode()).hexdigest(),'map':'Map05'}}
maps={'PARENT_M05_DIAG':'Map05','O01_DIAG':'Map05','O02_DIAG':'Map05','O03_DIAG':'Map05'}
for n,d in [('PARENT_OPERATORS.json',bundle),('DIAGNOSTIC_MAP_BINDINGS.json',maps)]:
 (F/n).write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
for n in ['sync_metadata.py','verify_diagnostic_raw.py','read_live.py']:
 s=(O/n).read_text().replace(O.name,F.name).replace('F13','F14')
 if n=='verify_diagnostic_raw.py':s=s.replace("['PARENT_M05_DIAG', 'PARENT_M04_DIAG', 'N01_DIAG', 'N02_DIAG', 'N03_DIAG']",repr(list(maps)))
 ast.parse(s);(F/n).write_text(s,encoding='utf-8')
s=(O/'stage_parent_observer.py').read_text().replace(O.name,F.name).replace('f13diag_','f14diag_')
s=s.replace("assert name in ['PARENT_M04','PARENT_M05']","assert name=='PARENT_M05'")
a=s.index("if name=='PARENT_M04':");b=s.index("a=json.loads((R/'solver_study/heuristic_20261016.json')",a);s=s[:a]+s[b:]
a=s.index("mode='LATE'");b=s.index('blue=Path',a);s=s[:a]+s[b:]
s=s.replace('Counters plus explicitly declared bounded readonly nearby-completion/joint/transport advisors','Counters plus declared bounded fixed-site suffix schedule advisors and own assignment forecast ledger')
ast.parse(s);(F/'stage_parent_observer.py').write_text(s,encoding='utf-8')
code=r'''
from pathlib import Path
import json,sys
F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F14_fixed_sites_schedule_20261027');d=json.load(sys.stdin)
assert json.loads((F/'observer_qualification/FIRST_RESULT.json').read_text())['status']=='PASS'
for n,v in d.items():assert not(F/n).exists();(F/n).write_text(json.dumps(v,indent=2)+'\n')
print('One parent diagnostic operator prepared; no game started')
'''
print(subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps({'PARENT_OPERATORS.json':bundle,'DIAGNOSTIC_MAP_BINDINGS.json':maps}).encode()).decode())
