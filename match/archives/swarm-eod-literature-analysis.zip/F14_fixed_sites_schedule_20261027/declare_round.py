from pathlib import Path
import json,datetime,hashlib,subprocess,shlex
F=Path(__file__).resolve().parent;OLD=F.parent/'F13_completion_joint_transport_20261027'
assert not(F/'PREDECLARATION.json').exists()
p=json.loads((OLD/'PREDECLARATION.json').read_text())['parent']
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':F.name,'status':'DECLARED_BEFORE_HELPERS_OR_CANDIDATES','authorization':'Human requests sustained analysis-first autonomous iteration, assistant selects three of five ranked directions.','control_id':'K01','parent':p,
'previous_result':'F13 closed with no qualified N01/N02/N03 live opportunity; 2 RED-only diagnostics, zero candidates/full-five groups,14raw firstverified,0failure. Do not widen F13 gates or retry those consumed diagnostics.',
'five_ranked_directions':[
 {'id':'O01','rank':1,'recommendation':'high','name':'Exact two-stop order on fixed sites per owner','evidence':'F13 Map05 last owner traversed1658..1922 to finish one target, with continuous motion. Current final refiner preserves owners/order; compare reversed two-stop suffix without changing target geometry or committed prefix.'},
 {'id':'O02','rank':2,'recommendation':'high','name':'Fixed-site cross-owner suffix exchange minimizing longest route','evidence':'Existing full-layout/refiner preserve owner counts; reserved first goals already protected. Test whether same sites can be executed sooner by other fresh owners without enlarging total travel or violating full budgets.'},
 {'id':'O03','rank':3,'recommendation':'medium_high_diagnose_first','name':'Assignment-bound execution forecast calibration','evidence':'Old model snapshots not bound to subsequent exact goals cannot establish speed error. Need own target identity/start/route estimate/ack/changes, not global speed shrink (D03 already failed).'},
 {'id':'defer_pareto_transport','rank':4,'recommendation':'medium_low','name':'Coverage-vs-known-centre transport Pareto frontier','evidence':'F13 three strict ties had zero eligible candidate, no timeout. A controlled loss tradeoff needs separate evidence/model; no relaxed F13 gate.'},
 {'id':'defer_render','rank':5,'recommendation':'low','name':'Exact identical-input rendering reuse','evidence':'Repeated identical contexts not measured; M01 speed-only lost five maps.'}],
'selected':['O01','O02','O03'],
'synthetic_protocol':'Fixed tiny exact matrix/graph fixtures only; no actual map/historical arrays. Validate all source sets, owner counts, route caps, preserved frozen prefixes, no input mutation, timeout abstention, reversal and swaps before native observer.',
'parent_diagnostic':{'job':'PARENT_M05','map':'Map05','RED_only':True,'rounds':1,'retry':False,'ranking':False,'layout_advisors':'At most2 eligible probes per own memory separated>=120steps; at most.5s soft deadline per shared same-call known-graph context for both O01/O02. Record costs. All original results/commands/submission unchanged. Prefix from same LNS call only. Reversal<=2 remaining sites per owner; swap<=10sites/5owners, one point per different owner. Exact complete-prefix costs; no truth/private observations.','O03':'Observe own final actual plan/target, inventory, own position, predicted route length/3+24, assignment identity, clock and real inventory-decrease ack; changed target ends censored record. No planning/state input replay.'},
'gates':{'O01':'Fresh parent diagnostic must show at leastone legal same-site reversal reduces a complete owner route>=CELL, does not increase other/total routes and obeys all original full owner caps/frozen prefixes; measured cost acceptable. Then freeze bounded production implementation; first fresh candidate Map05 must select an actual reversal before five maps.',
'O02':'Fresh parent diagnostic must show same multiset/counts/prefixes and legal swap improves maximum complete route>=CELL, total complete route nonincrease, all original full owner caps. Then freeze production limits; fresh candidate Map05 must select actual swap before five maps.',
'O03':'At least3 completed same-target/assignment-bound own records and at least2 actual completion times>1.5*forecast with no goal revision; report counterexamples/censored records first. If absent defer. Even if present, freeze narrow calibration and qualify before candidate; no historical checkpoint/replay or aggregate blanket speed shrink.'},
'policy_constraints':'Only own live sensors/derived memory/received messages. Site geometry/set/count and existing spacing/forbidden fixed; never reassign committed first prefix. Candidate children independent K01; no stacking or losing parent rebase. Deadline/context failure returns original. Parent observer cannot rank scores.',
'protocol':'OriginalMap01..05 RED→unchanged actualBLUE, native180/240s. Interleaved K01_A/candidate_A/K01_B/candidate_B. Any complete candidate-five mean<80 stop; at2pairs cumulative<=control stop; positive continue complete4v4 with agent reviews after first Windows raw checks. Strict mean improvement/tie parent. No live bridge or automatic approval.',
'budget':'At most1 parent RED diagnostic +3 admitted candidate RED diagnostics+24full-five groups. No opportunity=>no candidate/full test. First native failure stops chain, preserve/no retry.',
'invariants':'Single evaluator. Native ROOT/.venv/run_server.sh only, no installs/SDK/maps/BLUE/scoring/physics/clock/thread changes. Unset MATCH_PHASE_ID/PYGLET_HEADLESS/PYTHONPATH, set MATCH_HEURISTIC_ID=heuristic_20261015T2047Z. NPZ/pickle opaque streaming SHA only never deserialize/replay. Original117 once registry unchanged; separate cold ledger. Preserve failures and low scores, no permanent deletes. No subagents/Docker/website upload/automations/50maps.',
'release':'Internal only. All source builds numeric YAML int615; exactnumpy1.26.4/pandas2.2.3/opencv-contrib4.11.0.86, real ZIP-bound mtrand/pandas/cv2/SDK modules+strict guard before actual formal delivery. Native pandas3.0.6 unchanged. ExternalV05 remains recommended; official container unverified.'}
b=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode();(F/'PREDECLARATION.json').write_bytes(b)
code=r'''
from pathlib import Path
import json,sys,hashlib,fcntl
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F14_fixed_sites_schedule_20261027'
assert not F.exists()
assert json.loads((H/'F13_completion_joint_transport_20261027/STATUS.json').read_text())['status']=='CLOSED_ALL_THREE_DEFERRED_NO_QUALIFIED_OPPORTUNITY'
a=json.loads((R/'solver_study/heuristic_20261016.json').read_text());assert not a.get('active_processes') and not a.get('current_formal_active')
lock=(R/'solver_study/serial_evaluation.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
b=sys.stdin.buffer.read();d=json.loads(b);P=d['parent'];assert hashlib.sha256(Path(P['zip']).read_bytes()).hexdigest()==P['zip_sha256']
assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(P['path'])/'source').iterdir() if p.is_file()}==P['source_files']
F.mkdir();(F/'PREDECLARATION.json').write_bytes(b);print(json.dumps({'declared':str(F),'sha256':hashlib.sha256(b).hexdigest(),'no_native_started':True}))
'''
r=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=b);(F/'DECLARATION_RECEIPT.json').write_bytes(r);print(r.decode())
