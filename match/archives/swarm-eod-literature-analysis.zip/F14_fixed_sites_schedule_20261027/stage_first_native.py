from pathlib import Path
import subprocess,shlex
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import json,hashlib,shutil,base64,ast,fcntl,datetime,subprocess,os
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F14_fixed_sites_schedule_20261027';Q=F/'observer_revision1';old=F/'PARENT_M05_DIAG'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
qa=json.loads((Q/'QUALIFICATION_RESULT.json').read_text());assert qa['status']=='PASS'
assert sha(F/'FIRST_NATIVE_ERROR.json')==qa['first_failed_precheck_preserved_sha256']
assert not(F/'FIRST_SIM_ERROR.json').exists() and not(F/'STOP_REQUESTED').exists()
for n in ['LAUNCH.json','GAME_PREDECLARATION.json','Map05_red','RESULT.json']:assert not(old/n).exists()
s=json.loads((old/'STATUS.json').read_text());p=Path('/proc')/str(s['pid'])/'stat';assert not p.exists() or p.read_text().split()[2]=='Z'
a=json.loads((R/'solver_study/heuristic_20261016.json').read_text());assert not a.get('active_processes') and not a.get('current_formal_active')
with (R/'solver_study/serial_evaluation.lock').open('a+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
binding=json.loads((Q/'SOURCE_BINDING.json').read_text());assert {p.name:sha(p) for p in (Q/'source').iterdir() if p.is_file()}==binding['observer_source_files']
name='PARENT_M05_FIRST_NATIVE';G=F/(name+'_DIAG');assert not G.exists();G.mkdir();S=G/'source';shutil.copytree(Q/'source',S)
decl=json.loads((F/'PREDECLARATION.json').read_text());P=decl['parent'];assert sha(Path(P['zip']))==P['zip_sha256']
blue=Path(json.loads((H/'F07_evidence_three_directions_20261026/infrastructure/PREDECLARATION.json').read_text())['blue_workspace'])
W=R/'experiments/target90_20261012/official_workspaces'/('f14diag_20261027_'+name);assert not W.exists();shutil.copytree(blue,W,ignore=shutil.ignore_patterns('solutions','__pycache__','*.pyc','.git','.pytest_cache'));sol=W/'src/swarm_rescue/solutions';sol.mkdir()
for p in S.iterdir():shutil.copy2(p,W/'req.txt' if p.name=='req.txt' else sol/p.name)
stage={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'workspace':str(W),'source_files':{p.name:sha(p) for p in S.iterdir()},'production_parent':P,'production_source':P['source_files'],'observer_source_binding_sha256':sha(Q/'SOURCE_BINDING.json'),'not_for_performance_ranking':True,'no_new_algorithm_version':True}
(G/'STAGING.json').write_text(json.dumps(stage,indent=2)+'\n')
(G/'PREDECLARATION.json').write_text(json.dumps({'utc':stage['utc'],'job':name,'control_id':'K01','source_zip_sha256':P['zip_sha256'],'kind':'FIRST_FRESH_MAP05_RED_AFTER_SEPARATE_PREFLIGHT_QUALIFICATION','map':'Map05','seed':None,'no_retry':True,'BLUE':False,'ranking':False,'new_algorithm':False,'qualification_sha256':sha(Q/'QUALIFICATION_RESULT.json'),'repair_declaration_sha256':sha(F/'PREFLIGHT_REPAIR_DECLARATION.json'),'prior_simulator_attempts':0,'prior_precheck_error_preserved':True},indent=2)+'\n')
shutil.copy2(Q/'preflight.py',G/'preflight.py')
entry=json.loads((F/'PARENT_OPERATORS.json').read_text())['PARENT_M05'];runner=base64.b64decode(entry['runner_base64']);assert hashlib.sha256(runner).hexdigest()==entry['sha256']
runner=runner.decode().replace('PARENT_M05',name).replace('FIRST_NATIVE_ERROR.json','FIRST_SIM_ERROR.json');ast.parse(runner)
p=F/('run_'+name+'_diagnostic.py');assert not p.exists();p.write_text(runner)
maps=json.loads((F/'DIAGNOSTIC_MAP_BINDINGS.json').read_text());assert name+'_DIAG' not in maps;maps[name+'_DIAG']='Map05';(F/'DIAGNOSTIC_MAP_BINDINGS.json').write_text(json.dumps(maps,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with (F/(name+'_diagnostic_coordinator.log')).open('x') as log:proc=subprocess.Popen([str(R/'.venv/bin/python'),'-u',str(p)],cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d={'utc':stage['utc'],'job':name,'pid':proc.pid,'starttime_ticks':(Path('/proc')/str(proc.pid)/'stat').read_text().split()[21],'source_zip_sha256':P['zip_sha256'],'runner_sha256':sha(p),'observer_source_binding_sha256':sha(Q/'SOURCE_BINDING.json'),'prior_failed_precheck_sha256':qa['first_failed_precheck_preserved_sha256'],'only_one_FIRST_native_RED_diagnostic':True,'new_algorithm':False}
(G/'LAUNCH_COORDINATOR.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
'''
r=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)])
assert not(F/'FIRST_NATIVE_LAUNCH_RECEIPT.json').exists();(F/'FIRST_NATIVE_LAUNCH_RECEIPT.json').write_bytes(r);print(r.decode())
import json
maps=json.loads((F/'DIAGNOSTIC_MAP_BINDINGS.json').read_text());maps['PARENT_M05_FIRST_NATIVE_DIAG']='Map05';(F/'DIAGNOSTIC_MAP_BINDINGS.json').write_text(json.dumps(maps,indent=2)+'\n',encoding='utf-8')
p=F/'verify_diagnostic_raw.py';s=p.read_text();s=s.replace("'PARENT_M05_DIAG',", "'PARENT_M05_DIAG', 'PARENT_M05_FIRST_NATIVE_DIAG',",1);p.write_text(s,encoding='utf-8')
p=F/'read_live.py';s=p.read_text().replace("F/'PARENT_M05_DIAG/Map05_red/console.log'","F/'PARENT_M05_FIRST_NATIVE_DIAG/Map05_red/console.log'").replace("out['first_native_error']=(F/'FIRST_NATIVE_ERROR.json').exists()","out['prior_precheck_error_preserved']=(F/'FIRST_NATIVE_ERROR.json').exists();out['first_actual_sim_error']=(F/'FIRST_SIM_ERROR.json').exists()")
p.write_text(s,encoding='utf-8')
