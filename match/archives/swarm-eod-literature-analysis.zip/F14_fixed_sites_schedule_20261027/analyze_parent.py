from pathlib import Path
import json,subprocess,shlex,datetime
from collections import Counter
F=Path(__file__).resolve().parent;name='PARENT_M05_FIRST_NATIVE_DIAG';G=F/name
assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text())['valid']
assert not(G/'ANALYSIS.json').exists()
E=json.loads((G/'EVENTS.json').read_text());R=json.loads((G/'RESULT.json').read_text())
A=E['F14_SCHEDULE_ADVISOR'];tasks=E['F14_TASK_FORECAST']
complete=[x for x in tasks if x['outcome']=='inventory_ack'];censored=[x for x in tasks if x['outcome']!='inventory_ack']
late=[x for x in complete if x['actual_steps']>1.5*x['predicted_steps']]
gates={'O01':any(x.get('answers',{}).get('order',{}).get('reason')=='positive_order' and not x.get('deadline_reached') for x in A),
       'O02':any(x.get('answers',{}).get('exchange',{}).get('reason')=='positive_exchange' and not x.get('deadline_reached') for x in A),
       'O03':len(complete)>=3 and len(late)>=2}
costs=[x['seconds'] for x in A]
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent':'K01','not_for_performance_ranking':True,'raw_arrays_loaded':0,'game_row':R['row'],'gates':gates,
   'schedule_advisors':A,'schedule_reason_counts':dict(Counter(x['reason'] for x in A)),
   'advisor_seconds_total':sum(costs),'advisor_seconds_max':max(costs,default=0),
   'completed_task_count':len(complete),'censored_task_count':len(censored),'late_completed_count':len(late),
   'completed_tasks':complete,'censored_tasks':censored,
   'scope':'Own current-plan scalar graph/forecast evidence only. No true map, peer/private state, replay, arrays or diagnostic score ranking. First failed SDK precheck preserved separately;1 actual native RED round.'}
p=G/'ANALYSIS.json';p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
remote="from pathlib import Path;import sys;p=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F14_fixed_sites_schedule_20261027/PARENT_M05_FIRST_NATIVE_DIAG/ANALYSIS.json');assert not p.exists();p.write_bytes(sys.stdin.buffer.read())"
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(remote)],input=p.read_bytes(),check=True)
print(json.dumps({k:d[k] for k in ['gates','schedule_reason_counts','advisor_seconds_total','advisor_seconds_max','completed_task_count','censored_task_count','late_completed_count']}))
