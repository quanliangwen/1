import subprocess
code = r'''
from pathlib import Path
import json
R=Path('/home/junhao/quan/parallel_test_solver/match')
F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F14_fixed_sites_schedule_20261027'
s=json.loads((F/'STATUS.json').read_text())
a=json.loads((R/'solver_study/heuristic_20261016.json').read_text())
out={k:s.get(k) for k in ['status','pid','candidate_id','current','updated_utc','performance_phase']}
out['active_processes']=a.get('active_processes',[])
out['prior_precheck_error_preserved']=(F/'FIRST_NATIVE_ERROR.json').exists();out['first_actual_sim_error']=(F/'FIRST_SIM_ERROR.json').exists()
out['coordinator_state']=None
if s.get('pid'):
 p=Path('/proc')/str(s['pid'])/'stat'
 out['coordinator_state']=p.read_text().split()[2] if p.exists() else 'exited'
if s.get('current'):
 label=s['current']['label'];p=R/'results/target90_20261012'/('unseeded_'+label)/'matrix_status.json'
 if p.exists():
  m=json.loads(p.read_text());out['matrix_updated']=m.get('updated_utc')
  out['jobs']={k:{'status':v.get('status'),'rounds':[{'score':r.get('full_score'),'placed':r.get('placed'),'red_seconds':r.get('red_walltime')} for r in v.get('rounds',[])]} for k,v in m['jobs'].items()}
p=F/'PARENT_M05_FIRST_NATIVE_DIAG/Map05_red/console.log'
if p.exists():
 lines=p.read_text(errors='replace').splitlines();out['schedule_advice']=[json.loads(x[len('[F14_SCHEDULE_ADVISOR] '):]) for x in lines if x.startswith('[F14_SCHEDULE_ADVISOR] ')]
 out['forecast_completed']=sum('\"outcome\":\"inventory_ack\"' in x for x in lines if x.startswith('[F14_TASK_FORECAST]'))
 ticks=[json.loads(x[len('[F14_DIAG_TICK] '):]) for x in lines if x.startswith('[F14_DIAG_TICK] ')]
 if ticks:out['latest_tick']={k:ticks[-1].get(k) for k in ['owner','step','stock','wall_left','remaining_steps']}
print(json.dumps(out))
'''
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60',
 '/home/junhao/quan/parallel_test_solver/match/.venv/bin/python','-'],input=code.encode(),check=True)
