from pathlib import Path
import sys,json,types,time,traceback
Q=Path(__file__).resolve().parent;W=Q/'workspace';F=Q.parent
report={'status':'STARTED','checks':[],'game_rounds':0}
def check(n,v):
 assert v,n
 report['checks'].append(n)
try:
 sys.path.insert(0,str(W/'src'))
 import numpy as np,cv2,pandas
 import swarm_rescue.solutions.trust_region_cover as trust
 import swarm_rescue.solutions.team_coverage_lns as current
 from swarm_rescue.solutions import schedule_observer as observer
 from swarm_rescue.solutions.greedy_mapping import MapMemory
 from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
 from swarm_rescue.solutions.my_drone_eval import MyDroneEval,BaseParent
 from swarm_rescue.simulation.reporting.team_info import TeamInfo
 from swarm_rescue.launcher import Launcher
 from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
 import numpy.random.mtrand
 check('native_abi',(np.__version__,pandas.__version__,cv2.__version__)==('1.26.4','3.0.6','4.11.0'))
 check('real_mtrand',np.isfinite(np.random.RandomState(615).normal(size=8)).all())
 check('team615_integer',type(TeamInfo().team_number) is int and TeamInfo().team_number==615)
 check('underlying_placement_unchanged',next(c.__name__ for c in MyDroneEval.__mro__ if '_maybe_place' in c.__dict__)=='ActiveCoverageMixin')
 check('final_route_observer',next(c.__name__ for c in MyDroneEval.__mro__ if '_plan_route' in c.__dict__)=='ScheduleObservationMixin')
 check('own_observer_source',Path(observer.__file__).resolve().is_relative_to(W))
 parent=json.loads((F/'PREDECLARATION.json').read_text())['parent']
 original=types.ModuleType('original_lns_reference');ref=Path(parent['path'])/'source/team_coverage_lns.py'
 exec(compile(ref.read_text(),str(ref),'exec'),original.__dict__)
 def same(a,b):return a.keys()==b.keys() and all(len(a[k])==len(b[k]) and all(np.array_equal(p,q) for p,q in zip(a[k],b[k])) for k in a)
 def fixture(enabled=True,pref=False,unreachable=False):
  m=MapMemory(640,256);m.free[:]=True;m.identifier=2;m.step=1000;m._f14_schedule_enabled=enabled
  if unreachable:m.free[:,11:14]=False
  pm=GeometryPlanningMemory(m);pm._coverage_values_cache=(32.,np.zeros(m.shape,np.float32),np.zeros(m.shape,bool))
  m._test_pm=pm;base={2:[m.cell_to_world((5,25)),m.cell_to_world((5,15))]}
  agents={2:(m.cell_to_world((5,5)),2)};prefixes=None
  if pref:prefixes={2:(m.cell_to_world((5,3)),agents[2][0])}
  return m,pm,base,agents,prefixes
 old_factory=trust.GeometryPlanningMemory;trust.GeometryPlanningMemory=lambda m:m._test_pm
 old_current_greedy=current._greedy_plan
 try:
  for name,settings,budget in [('disabled',{'enabled':False},2000.),('enabled',{},2000.),('prefix',{'pref':True},2000.),
                               ('cap',{},100.),('unreachable',{'unreachable':True},2000.)]:
   a,pa,base,agents,prefix=fixture(**settings);b,pb,baseb,agentsb,prefixb=fixture(**settings)
   a._f14_schedule_enabled=False
   original._greedy_plan=lambda *args,**kwargs:{k:[p.copy() for p in ps] for k,ps in base.items()}
   current._greedy_plan=lambda *args,**kwargs:{k:[p.copy() for p in ps] for k,ps in baseb.items()}
   ra=original.plan_team_coverage_lns(a,agents,[],32.,travel_budget=budget,reserved_prefixes=prefix)
   rb=current.plan_team_coverage_lns(b,agentsb,[],32.,travel_budget=budget,reserved_prefixes=prefixb)
   check('same_original_plan_'+name,same(ra,rb))
   check('same_original_counters_'+name,a.trust_region_diagnostics==b.trust_region_diagnostics)
   check('same_source_arrays_'+name,all(np.array_equal(getattr(a,k),getattr(b,k)) for k in ['hits','free','visits']))
   check('capture_cleaned_'+name,'_f14_live_prepared' not in vars(b))
   if name=='enabled':check('advisor_actually_executed',b._f14_schedule_count==1)
 finally:trust.GeometryPlanningMemory=old_factory;current._greedy_plan=old_current_greedy
 m,pm,base,agents,prefix=fixture()
 advice=observer.schedule_advice(m,agents,[],32.,base,2000.,None,(),None,pm,time.perf_counter()+5)
 check('live_graph_reversal_positive',advice['answers']['order']['reason']=='positive_order')
 check('live_graph_complete_routes',advice['answers']['order']['sum_after']<advice['answers']['order']['sum_before'])
 check('live_original_points_unchanged',same(base,{2:[m.cell_to_world((5,25)),m.cell_to_world((5,15))]}))
 advice=observer.schedule_advice(m,agents,[],32.,base,2000.,None,(),None,pm,time.perf_counter()-1)
 check('live_graph_deadline_abstains',advice['reason']=='deadline')
 forbidden=np.ones(m.shape,bool)
 advice=observer.schedule_advice(m,agents,[],32.,base,2000.,None,(),forbidden,pm,time.perf_counter()+5)
 check('live_invalid_original_abstains',advice['reason']=='invalid_original_site')
 # An empty suffix may still own a fixed prefix and dominate the makespan.
 other=m.cell_to_world((8,35));agentsb={**agents,7:(other,0)};baseb={**base,7:[]}
 prefixb={7:(m.cell_to_world((8,3)),other)}
 advice=observer.schedule_advice(m,agentsb,[],32.,baseb,2000.,prefixb,(),None,pm,time.perf_counter()+5)
 check('empty_suffix_prefix_is_counted',advice['prefix_costs'][7]==512.)
 check('prefix_not_reassigned',advice['answers']['order']['alternative']['7']==[])
 advice=observer.schedule_advice(m,agentsb,[],32.,base,2000.,prefixb,(),None,pm,time.perf_counter()+5)
 check('omitted_zero_suffix_owner_still_counted',advice['prefix_costs'][7]==512. and advice['suffix_counts'][7]==0)
 class Parent:
  def _sync_placement(self,step):self.sync_calls+=1;return 'original_sync'
  def _plan_route(self,step,returning,peer_goals):self.plan_calls+=1;return [self.placement_goal.copy()],self.placement_goal.copy()
 class Observed(observer.ScheduleObservationMixin,Parent):pass
 d=object.__new__(Observed);d.identifier=0;d.sync_calls=d.plan_calls=0;d.pose=np.array([0.,0.]);d.placement_goal=d.assignment_goal=np.array([120.,0.]);d.assignment_since=100;d.inventory=2;d.carried_bombs_count=lambda:d.inventory;d.elapsed_walltime=10.;d._remaining_steps=lambda:300.
 r=d._plan_route(100,False,[]);check('original_route_return',np.array_equal(r[0][0],[120.,0.]) and d.plan_calls==1)
 check('original_goal_preserved',np.array_equal(d.assignment_goal,[120.,0.]))
 check('forecast_binds_identity',d._f14_forecasts.current['identity']==(2,100,120.,0.))
 check('forecast_uses_actual_returned_path',d._f14_forecasts.current['predicted_steps']==64.)
 d.elapsed_walltime=11.;d._plan_route(124,False,[]);check('forecast_not_reset_on_replan',d._f14_forecasts.current['start_step']==100)
 d.inventory=1;d.elapsed_walltime=15.;r=d._sync_placement(180)
 check('sync_return_once',r=='original_sync' and d.sync_calls==1)
 check('real_inventory_ack_closes',d._f14_forecasts.current is None)
 check('factory_original_submission_ancestor',next(c.__name__ for c in BaseParent.__mro__ if '_submission_due' in c.__dict__)=='CompletionConsensusMixin')
 report.update(status='PASS',scope='Synthetic current-graph fixtures, actual native ABI/SDK imports and factory. Original plan/counters/commands unchanged; no simulator or production candidate.')
except BaseException:report.update(status='FAIL',error=traceback.format_exc());raise
finally:
 (Q/'FIRST_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'checks':len(report['checks']),'error':report.get('error')}))
