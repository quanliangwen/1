from pathlib import Path
import subprocess,shlex
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import json,datetime,fcntl,hashlib
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F14_fixed_sites_schedule_20261027';G=F/'PARENT_M05_FIRST_NATIVE_DIAG'
assert not(F/'DIRECTION_ADMISSION.json').exists() and not(F/'FIRST_SIM_ERROR.json').exists()
a=json.loads((R/'solver_study/heuristic_20261016.json').read_text());assert not a.get('active_processes') and not a.get('current_formal_active')
lock=(R/'solver_study/serial_evaluation.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
s=json.loads((G/'STATUS.json').read_text());p=Path('/proc')/str(s['pid'])/'stat';assert not p.exists() or p.read_text().split()[2]=='Z'
assert s['status'].endswith('DIAGNOSTIC_COMPLETE_AWAIT_ANALYSIS')
assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text())['valid']
analysis=json.loads((G/'ANALYSIS.json').read_text());assert analysis['gates']=={'O01':False,'O02':False,'O03':False}
for n in ['LAUNCH.json','GAME_PREDECLARATION.json','Map05_red','RESULT.json']:assert not(F/'PARENT_M05_DIAG'/n).exists()
q=json.loads((F/'observer_revision1/QUALIFICATION_RESULT.json').read_text());assert hashlib.sha256((F/'FIRST_NATIVE_ERROR.json').read_bytes()).hexdigest()==q['first_failed_precheck_preserved_sha256']
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'admitted_order':[],'gates':analysis['gates'],'parent_retained':'K01','no_candidates_created':True,'RED_only_actual_rounds':1,'five_map_groups':0,'raw_first_verified':7,'actual_native_sim_failures':0,'failed_SDK_prechecks_preserved':1,'SDK_repair_qualification':'observer_revision1/QUALIFICATION_RESULT.json','completed_task_count':analysis['completed_task_count'],'censored_task_count':analysis['censored_task_count'],'late_completed_count':analysis['late_completed_count'],'reason':'No legal positive fixed-site reversal/exchange found in declared opportunity windows;10 same-task completions had0>1.5forecast. Defer without source/full-five. No general impossibility claim.'}
(F/'DIRECTION_ADMISSION.json').write_text(json.dumps(d,indent=2)+'\n');state={**d,'status':'CLOSED_ALL_THREE_DEFERRED_AFTER_ONE_ACTUAL_RED_DIAGNOSTIC','pid':None};(F/'STATUS.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(state))
'''
r=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)])
assert not(F/'FINAL_RESULT.json').exists();(F/'FINAL_RESULT.json').write_bytes(r);print(r.decode())
