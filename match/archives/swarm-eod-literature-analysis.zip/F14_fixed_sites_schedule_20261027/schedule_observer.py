"""Read-only opportunity accounting on the current planner call."""
import time
import json
import numpy as np
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
from swarm_rescue.solutions.team_coverage import observed_wall_values,path_costs
from swarm_rescue.solutions.farthest_wall_cover import owner_travel_budget
from swarm_rescue.solutions.fixed_site_schedule import improve_schedule,AssignmentForecastLedger


def root_memory(memory):
    while isinstance(memory,GeometryPlanningMemory):memory=memory._memory
    return memory


def observe_schedule(memory,agents,drops,radius,result,full_budget,prefixes,
                     forbidden_points,forbidden_mask,prepared):
    root=root_memory(memory)
    if not getattr(root,'_f14_schedule_enabled',False):return
    step=int(getattr(root,'step',0));count=getattr(root,'_f14_schedule_count',0)
    if count>=2 or step-getattr(root,'_f14_schedule_last',-1000)<120:return
    if not(any(len(v)==2 for v in result.values()) or sum(bool(v) for v in result.values())>=2):return
    root._f14_schedule_count=count+1;root._f14_schedule_last=step
    begun=time.perf_counter();deadline=begun+.5
    out={'owner':int(getattr(root,'identifier',0)),'step':step,'probe':count+1}
    try:
        out.update(schedule_advice(memory,agents,drops,radius,result,full_budget,prefixes,
                                   forbidden_points,forbidden_mask,prepared,deadline))
    finally:out['seconds']=time.perf_counter()-begun
    print('[F14_SCHEDULE_ADVISOR]',json.dumps(out,separators=(',',':')),flush=True)


def schedule_advice(memory,agents,drops,radius,result,full_budget,prefixes,
                    forbidden_points,forbidden_mask,prepared,deadline):
    if prepared is None:return {'reason':'missing_exact_prepared_context'}
    # Copy mutable per-view caches to keep advisor writes outside original planning state.
    pm=object.__new__(GeometryPlanningMemory);pm.__dict__.update(prepared.__dict__)
    pm.free=prepared.free.copy();pm._blocked=prepared.blocked()
    cached=getattr(prepared,'_coverage_values_cache',None)
    if cached is not None:pm._coverage_values_cache=(cached[0],cached[1].copy(),cached[2].copy())
    _,solids=observed_wall_values(pm,radius,return_solids=True)
    walkable=pm.free & ~pm.blocked() & ~solids;allowed=walkable.copy()
    rr,cc=np.indices(pm.shape);xx=(cc+.5)*pm.CELL-pm.width/2;yy=pm.height/2-(rr+.5)*pm.CELL
    if forbidden_mask is not None:
        if np.asarray(forbidden_mask).shape!=pm.shape:return {'reason':'invalid_forbidden'}
        allowed &= ~np.asarray(forbidden_mask,bool)
    for p,r in forbidden_points:allowed[(xx-p[0])**2+(yy-p[1])**2<float(r)**2]=False
    separation=40.+.71*pm.CELL
    for p in drops:allowed[(xx-p[0])**2+(yy-p[1])**2<separation**2]=False
    plans={int(k):[np.asarray(p,float).copy() for p in ps] for k,ps in result.items()}
    if len(plans)>5 or sum(map(len,plans.values()))>10 or any(len(v)>2 for v in plans.values()):return {'reason':'unsupported_size'}
    points=[p for ps in plans.values() for p in ps]
    if any(p.shape!=(2,) or not np.isfinite(p).all() or not allowed[pm.world_to_cell(p)] for p in points):return {'reason':'invalid_original_site'}
    if any(np.linalg.norm(p-q)<separation-1e-8 for i,p in enumerate(points) for q in points[i+1:]):return {'reason':'invalid_original_spacing'}
    nodes=[];indexed={};starts={};prefix_costs={};caps={};fields={}
    def node(p):nodes.append(np.asarray(p,float));return len(nodes)-1
    for k,ps in plans.items():indexed[k]=[node(p) for p in ps]
    for k in plans:
        if k not in agents or len(plans[k])>int(agents[k][1]):return {'reason':'invalid_original_owner'}
        starts[k]=node(agents[k][0]);caps[k]=owner_travel_budget(full_budget,k)
    cells=[pm.world_to_cell(p) for p in nodes]
    if any(not walkable[cell] for cell in cells):return {'reason':'unknown_start_or_target'}
    def field(cell):
        if cell not in fields:
            if time.perf_counter()>=deadline:return None
            fields[cell]=path_costs(pm,walkable,cell)
        return fields[cell]
    for k in plans:
        prefix_costs[k]=0.
        if k in (prefixes or {}):
            position,target=(np.asarray(p,float) for p in prefixes[k])
            if not np.array_equal(nodes[starts[k]],target):return {'reason':'prefix_start_mismatch'}
            source=pm.world_to_cell(position);goal=pm.world_to_cell(target)
            if not walkable[source] or not walkable[goal]:return {'reason':'prefix_unreachable'}
            f=field(source)
            if f is None:return {'reason':'deadline'}
            prefix_costs[k]=float(f[goal])
    matrix=np.full((len(nodes),len(nodes)),np.inf)
    for i,cell in enumerate(cells):
        f=field(cell)
        if f is None:return {'reason':'deadline','fields':len(fields)}
        for j,other in enumerate(cells):matrix[i,j]=f[other]
    answers={}
    for mode in ['order','exchange']:
        alternative,advice=improve_schedule(indexed,starts,matrix,caps,prefix_costs,pm.CELL,mode,deadline)
        if advice['reason'].startswith('positive_'):
            advice['alternative']={str(k):[nodes[n].tolist() for n in ps] for k,ps in alternative.items()}
        answers[mode]=advice
    return {'reason':'compared_same_sites','fields':len(fields),'suffix_counts':{k:len(v) for k,v in plans.items()},
            'prefix_costs':prefix_costs,'full_caps':caps,'answers':answers,'deadline_reached':time.perf_counter()>deadline}


class ScheduleObservationMixin:
    def _f14_ledger(self):
        if not hasattr(self,'_f14_forecasts'):self._f14_forecasts=AssignmentForecastLedger()
        return self._f14_forecasts

    def _f14_record(self,record):
        if record is not None:
            record={**record,'owner':int(self.identifier or 0)}
            print('[F14_TASK_FORECAST]',json.dumps(record,separators=(',',':')),flush=True)

    def _sync_placement(self,step):
        result=super()._sync_placement(step)
        record=self._f14_ledger().observe(step,float(self.elapsed_walltime),int(self.carried_bombs_count()))
        self._f14_record(record)
        return result

    def _plan_route(self,step,returning,peer_goals):
        result=super()._plan_route(step,returning,peer_goals)
        ledger=self._f14_ledger();inventory=int(self.carried_bombs_count())
        goal=self.placement_goal
        if (goal is None or self.assignment_goal is None or inventory<=0
                or not np.array_equal(goal,self.assignment_goal)):
            self._f14_record(ledger.cancel(step));return result
        identity=(int(inventory),int(self.assignment_since),float(goal[0]),float(goal[1]))
        path=[np.asarray(self.pose,float)]+[np.asarray(p,float) for p in result[0]]
        length=sum(float(np.linalg.norm(b-a)) for a,b in zip(path,path[1:]))
        previous=ledger.current
        self._f14_record(ledger.observe(step,float(self.elapsed_walltime),inventory,identity,length/3.+24.))
        if ledger.current is not None and ledger.current is not previous:
            ledger.current.update(route_length=length,goal=np.asarray(goal,float).tolist(),
                                  start_pose=np.asarray(self.pose,float).tolist(),
                                  remaining_at_start=float(self._remaining_steps()))
        return result
