from pathlib import Path
import ast,base64,json,subprocess,shlex
F=Path(__file__).resolve().parent;OLD=F.parent/'F13_completion_joint_transport_20261027'
ref=OLD/'parent_source_reference'
s=(ref/'trust_region_cover.py').read_text();marker='    pm=GeometryPlanningMemory(memory) if _prepared is None else _prepared\n';assert s.count(marker)==1
s=s.replace(marker,marker+"    if getattr(memory,'_f14_schedule_enabled',False): memory._f14_live_prepared=pm\n")
trust=s
s=(ref/'team_coverage_lns.py').read_text();s=s.replace('    prepared=None\n','    _f14_full_budget=travel_budget\n    prepared=None\n',1)
marker='    return refine_trust_region(memory,agents,drops,radius,base,travel_budget=travel_budget,forbidden_points=forbidden_points,forbidden_mask=forbidden_mask,_prepared=prepared)'
assert s.count(marker)==1
s=s.replace(marker,'''    try:
        result=refine_trust_region(memory,agents,drops,radius,base,travel_budget=travel_budget,forbidden_points=forbidden_points,forbidden_mask=forbidden_mask,_prepared=prepared)
        if getattr(memory,'_f14_schedule_enabled',False):
            from swarm_rescue.solutions.schedule_observer import observe_schedule
            observe_schedule(memory,agents,drops,radius,result,_f14_full_budget,reserved_prefixes,
                             forbidden_points,forbidden_mask,getattr(memory,'_f14_live_prepared',prepared))
        return result
    finally:
        if '_f14_live_prepared' in vars(memory):delattr(memory,'_f14_live_prepared')''')
lns=s
tree=ast.parse((OLD/'diagnostic_mixin.py').read_text().replace('F13','F14').replace('_f13','_f14'))
cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='DiagnosticMixin')
cls.body=[n for n in cls.body if not(isinstance(n,ast.FunctionDef) and n.name=='_maybe_place')]
diag=ast.unparse(tree)+'\n'
marker="self.memory._f14_layout_enabled = getattr(self, 'F14_MODE', 'NONE') == 'LAYOUT'"
assert diag.count(marker)==1
diag=diag.replace(marker,'self.memory._f14_schedule_enabled = True')
assert 'self.memory._f14_schedule_enabled = True' in diag
assets={'trust_region_cover.py':trust,'team_coverage_lns.py':lns,'diagnostic_mixin.py':diag,
        'fixed_site_schedule.py':(F/'fixed_site_schedule.py').read_text(),'schedule_observer.py':(F/'schedule_observer.py').read_text()}
for s in assets.values():ast.parse(s)
payload={n:base64.b64encode(s.encode()).decode() for n,s in assets.items()}
code=r'''
from pathlib import Path
import json,sys,hashlib,base64,shutil,ast
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F14_fixed_sites_schedule_20261027'
assert json.loads((F/'helper_qualification/FIRST_RESULT.json').read_text())['status']=='PASS'
Q=F/'observer_qualification';assert not Q.exists();Q.mkdir();S=Q/'source';P=json.loads((F/'PREDECLARATION.json').read_text())['parent'];shutil.copytree(Path(P['path'])/'source',S)
for n,b in json.load(sys.stdin).items():(S/n).write_bytes(base64.b64decode(b))
p=S/'my_drone_eval.py';s=p.read_text();assert s.count('class MyDroneEval(')==1
s=s.replace('class MyDroneEval(','class BaseParent(',1)+"\nfrom swarm_rescue.solutions.diagnostic_mixin import DiagnosticMixin\nfrom swarm_rescue.solutions.schedule_observer import ScheduleObservationMixin\nclass MyDroneEval(ScheduleObservationMixin,DiagnosticMixin,BaseParent):\n    F14_MODE='SCHEDULE'\n";p.write_text(s)
for p in S.glob('*.py'):ast.parse(p.read_text())
binding={'parent':P,'observer_source_files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in S.iterdir() if p.is_file()}}
(Q/'SOURCE_BINDING.json').write_text(json.dumps(binding,indent=2)+'\n');print(json.dumps({'source_files':len(binding['observer_source_files']),'no_candidate_or_game':True}))
'''
r=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps(payload).encode());assert not(F/'observer_prepared.txt').exists();(F/'observer_prepared.txt').write_bytes(r);print(r.decode())
