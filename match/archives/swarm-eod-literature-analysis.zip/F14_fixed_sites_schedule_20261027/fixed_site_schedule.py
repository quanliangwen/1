"""Tiny exact suffix neighborhoods. Inputs are current public-graph costs only."""
import math
import time


def improve_schedule(plans, starts, distances, full_caps, prefix_costs, cell_size,
                     mode='order', deadline=None):
    original = {int(k):list(v) for k,v in plans.items()}
    def unchanged(reason, tested=0):
        return {k:list(v) for k,v in original.items()}, {'reason':reason,'tested':tested}
    if mode not in ('order','exchange') or not math.isfinite(cell_size) or cell_size<=0:
        return unchanged('invalid_mode_or_cell')
    if len(original)>5 or sum(map(len,original.values()))>10 or any(len(v)>2 for v in original.values()):
        return unchanged('unsupported_size')
    points=[p for v in original.values() for p in v]
    if len(set(points))!=len(points) or any(k not in starts or k not in full_caps for k in original):
        return unchanged('invalid_owner_or_duplicate')
    if any(not math.isfinite(float(prefix_costs.get(k,0.))) or float(prefix_costs.get(k,0.))<0 for k in original):
        return unchanged('invalid_prefix')
    def route(k, values):
        previous=starts[k];length=float(prefix_costs.get(k,0.))
        for node in values:
            value=float(distances[previous,node])
            if not math.isfinite(value) or value<0:return math.inf
            length+=value;previous=node
        return length
    before={k:route(k,v) for k,v in original.items()}
    if any(not math.isfinite(v) or v<0 or math.isnan(float(full_caps[k]))
           or v>float(full_caps[k])+1e-6 for k,v in before.items()):
        return unchanged('invalid_incumbent_routes')
    if not before:return unchanged('empty')
    max_before=max(before.values());sum_before=sum(before.values())
    best=None;best_rank=None;tested=0
    moves=[]
    if mode=='order':
        for k,v in sorted(original.items()):
            if len(v)==2:moves.append(((k,0),(k,1)))
    else:
        slots=[(k,j) for k,v in sorted(original.items()) for j in range(len(v))]
        moves=[(a,b) for i,a in enumerate(slots) for b in slots[i+1:] if a[0]!=b[0]]
    for (k,i),(h,j) in moves:
        if deadline is not None and time.perf_counter()>=deadline:return unchanged('deadline',tested)
        proposal={n:list(v) for n,v in original.items()}
        proposal[k][i],proposal[h][j]=proposal[h][j],proposal[k][i]
        after=dict(before)
        for owner in {k,h}:after[owner]=route(owner,proposal[owner])
        tested+=1
        if any(not math.isfinite(after[n]) or after[n]>float(full_caps[n])+1e-6 for n in {k,h}):continue
        max_after=max(after.values());sum_after=sum(after.values())
        if mode=='order':
            if after[k]>before[k]-cell_size+1e-6:continue
            rank=(sum_before-sum_after,max_before-max_after,-k)
        else:
            if max_after>max_before-cell_size+1e-6 or sum_after>sum_before+1e-6:continue
            rank=(max_before-max_after,sum_before-sum_after,-k,-i,-h,-j)
        if best_rank is None or rank>best_rank:
            best_rank=rank;best=(proposal,after,(k,i,h,j))
    if deadline is not None and time.perf_counter()>=deadline:return unchanged('deadline',tested)
    if best is None:return unchanged('no_qualified_'+mode,tested)
    proposal,after,move=best
    return proposal,{'reason':'positive_'+mode,'tested':tested,'move':list(move),
        'before':before,'after':after,'max_before':max_before,'max_after':max(after.values()),
        'sum_before':sum_before,'sum_after':sum(after.values()),
        'scope':'Same site multiset, suffix counts and frozen prefix; complete routes on same public graph.'}


class AssignmentForecastLedger:
    """One drone's own current assignment, closed by real inventory acknowledgement."""
    def __init__(self):self.current=None

    def cancel(self,step):
        if self.current is None:return None
        record={**self.current,'end_step':int(step),'outcome':'censored_changed_assignment'}
        self.current=None
        return record

    def observe(self,step,wall,inventory,identity=None,predicted_steps=None):
        completed=None
        if self.current is not None:
            old=self.current
            if inventory<old['inventory']:
                completed={**old,'end_step':int(step),'end_wall':float(wall),'outcome':'inventory_ack',
                    'actual_steps':int(step)-old['start_step'],'actual_seconds':float(wall)-old['start_wall']}
                completed['ratio']=completed['actual_steps']/max(1.,old['predicted_steps'])
                self.current=None
            elif identity is not None and identity!=old['identity'] or inventory!=old['inventory']:
                completed={**old,'end_step':int(step),'outcome':'censored_changed_assignment'};self.current=None
        if (self.current is None and inventory>0 and identity is not None and predicted_steps is not None
                and math.isfinite(predicted_steps) and predicted_steps>0):
            self.current={'start_step':int(step),'start_wall':float(wall),'inventory':int(inventory),
                          'identity':identity,'predicted_steps':float(predicted_steps)}
        return completed
