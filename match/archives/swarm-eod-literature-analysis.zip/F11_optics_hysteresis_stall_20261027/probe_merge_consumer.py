from pathlib import Path
import subprocess, shlex, json
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import ast,json,hashlib,datetime,sys,traceback,time
import numpy as np
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
F=H/'F11_optics_hysteresis_stall_20261027';G=F/'MERGE_CONSUMER_PROBE_FIRST.json'
D=F/'MERGE_CONSUMER_PROBE_DECLARATION.json';assert not D.exists() and not G.exists()
W=F/'L02/qualification_workspace';S=W/'src/swarm_rescue/solutions'
names=['bearing_core.py','bearing_memory.py','anchor_mapping.py']
hashes={n:hashlib.sha256((S/n).read_bytes()).hexdigest() for n in names}
parent=json.loads((F/'PREDECLARATION.json').read_text())['parent']['source_files']
assert all(hashes[n]==parent[n] for n in names)
D.write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_files':hashes,'scope':'Isolated actual BearingMemory consumer synthetic state test; no recorded observation input, controller control call, game or candidate source mutation. First failure retained, no retry.',
 'checks':'16 interleaved merge operations with local retractions, nonwall replacement/inplace edits, legacy/full/empty/duplicate/unsorted sparse bearing packets; compare every output hits/free/visits/bearing_bits/revision. Direct corroborated-map consumer on synthetic parent image. Only after equivalence, measure100 actual merge calls old/new. Temporary module helper substitution exists only inside this fresh test process.'})+'\n')
report={'status':'STARTED','checks':[],'timing':[]}
def check(n,x):
 assert x,n
 report['checks'].append(n)
def fast(mask,shape):
 fine=np.asarray(mask,bool)
 if fine.ndim!=2 or fine.shape[0]>2*shape[0] or fine.shape[1]>2*shape[1]:return np.zeros(shape,bool)
 out=np.zeros(shape,bool)
 for dr in range(2):
  for dc in range(2):
   part=fine[dr::2,dc::2];out[:part.shape[0],:part.shape[1]]|=part
 return out
try:
 sys.path.insert(0,str(W/'src'))
 import swarm_rescue.solutions.bearing_memory as bm
 import swarm_rescue.solutions.bearing_core as bc
 check('actual_payload_loaded',Path(bm.__file__).resolve()==(S/'bearing_memory.py').resolve())
 old=bm.fine_any_to_four
 check('original_import_alias_same',old is bc.fine_any_to_four)
 rng=np.random.RandomState(615)
 a=bm.BearingMemory(800,800,identifier=0,team_size=5);b=bm.BearingMemory(800,800,identifier=0,team_size=5)
 for key in ['hits','free','visits','bearing_bits']:
  x=getattr(a,key);x[:]=rng.randint(0,2 if x.dtype==bool else 8,x.shape);getattr(b,key)[:]=x
 a.nonwall_mask=rng.rand(*a.hits.shape)<.01;b.nonwall_mask=a.nonwall_mask.copy()
 sender=bm.BearingMemory(800,800,identifier=1,team_size=5)
 sender.hits[:]=rng.randint(0,8,sender.hits.shape);sender.free[:]=rng.rand(*sender.free.shape)<.5
 sender.visits[:]=rng.randint(0,255,sender.visits.shape);sender.bearing_bits[:]=rng.randint(0,256,sender.bearing_bits.shape)
 full=sender.packet();legacy=full[0]
 for step in range(16):
  if step%4==0:
   mask=rng.rand(*a.hits.shape)<.02;a.nonwall_mask=mask.copy();b.nonwall_mask=mask.copy()
  elif step%4==1:
   a.nonwall_mask[10:30,20:40]=~a.nonwall_mask[10:30,20:40];b.nonwall_mask[:]=a.nonwall_mask
  elif step%4==2:
   a.hits[10:30,10:30]=0;b.hits[10:30,10:30]=0
   a.bearing_bits[5:15,5:15]=0;b.bearing_bits[5:15,5:15]=0
  packet=full
  if step%4==1:packet=legacy
  elif step%4==2:packet=(legacy,(np.array([14,11,14],np.int32),np.array([1,4,128],np.uint8)))
  elif step%4==3:packet=(legacy,(np.empty(0,np.int32),np.empty(0,np.uint8)))
  a.merge(packet)
  bm.fine_any_to_four=fast;bc.fine_any_to_four=fast
  try:b.merge(packet)
  finally:bm.fine_any_to_four=old;bc.fine_any_to_four=old
  check('actual_full_merge_state_%d'%step,all(np.array_equal(getattr(a,k),getattr(b,k)) for k in ['hits','free','visits','bearing_bits']) and a._surface_revision==b._surface_revision and a.bearing_merged_packets==b.bearing_merged_packets)
 image=(rng.rand(800,800)<.03).astype(np.uint8)
 x,xa=bc.corroborated_map(image,a.hits,a.bearing_bits,800,800,a.nonwall_mask)
 bc.fine_any_to_four=fast
 try:y,ya=bc.corroborated_map(image,b.hits,b.bearing_bits,800,800,b.nonwall_mask)
 finally:bc.fine_any_to_four=old
 check('actual_corroborated_render_and_audit_exact',np.array_equal(x,y) and xa==ya)
 for name,helper in [('original',old),('sliced_OR',fast)]:
  m=bm.BearingMemory(800,800,identifier=0,team_size=5);m.nonwall_mask=a.nonwall_mask.copy()
  bm.fine_any_to_four=helper;bc.fine_any_to_four=helper;t=time.perf_counter()
  try:
   for _ in range(100):m.merge(full)
  finally:elapsed=time.perf_counter()-t;bm.fine_any_to_four=old;bc.fine_any_to_four=old
  report['timing'].append({'version':name,'actual_merge_calls':100,'seconds':elapsed})
 report.update(status='PASS',count=len(report['checks']),source_files=hashes,game_rounds=0,candidate_created=False,
  limitation='Synthetic dense packet with actual consumer; timing under host load, not measured production call-distribution or whole-game benefit. Live per-kernel opportunity still needs fresh diagnostic.')
except BaseException:
 report.update(status='FAIL',error=traceback.format_exc());raise
finally:G.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
'''
cmd='env -u MATCH_PHASE_ID -u PYGLET_HEADLESS -u PYTHONPATH MATCH_HEURISTIC_ID=heuristic_20261015T2047Z bash /home/junhao/quan/parallel_test_solver/match/run_server.sh -u -c '+shlex.quote(code)
p=subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60',cmd],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert not(F/'merge_consumer_first_console.txt').exists()
(F/'merge_consumer_first_console.txt').write_bytes(p.stdout+p.stderr)
if p.returncode:
 print(p.stdout.decode(errors='replace')[-3000:]);print(p.stderr.decode(errors='replace')[-3000:]);raise SystemExit(p.returncode)
d=json.loads(p.stdout.decode().strip().splitlines()[-1])
(F/'MERGE_CONSUMER_PROBE_FIRST.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:d[k] for k in ['status','count','timing','limitation']}))
