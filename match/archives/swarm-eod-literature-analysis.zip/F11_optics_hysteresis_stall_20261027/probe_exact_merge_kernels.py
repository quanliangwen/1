from pathlib import Path
import subprocess, shlex, json

F = Path(__file__).resolve().parent
remote = r'''
from pathlib import Path
import json, ast, hashlib, time, datetime, traceback
import numpy as np
R=Path('/home/junhao/quan/parallel_test_solver/match')
H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
F=H/'F11_optics_hysteresis_stall_20261027'
decl=F/'NEXT_KERNEL_PROBE_DECLARATION.json';out=F/'NEXT_KERNEL_PROBE_FIRST.json'
assert not decl.exists() and not out.exists()
source=H/'F09_route_and_views_20261026/K01/source/bearing_core.py'
decl.write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'One isolated synthetic equivalence/cost probe; no new candidate, SDK/controller run, game or recorded observation inputs. Native NumPy unchanged. CPU timing under current host load not causal whole-game speedup.',
 'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'hypotheses':['4 sliced OR updates equal padded2x2 any reduction for all supported dimensions; evaluate both odd/even and invalid shape inputs',
 'Sorted unique received sparse bearing ids allow direct OR; unsorted/duplicate ids must use original bitwise_or.at'],
 'fixed_checks':'70 reducer fixtures and9 sparse fixtures, first failure retained/no retry; timing only if all equivalence checks pass; no arrays saved or replayed'})+'\n')
report={'status':'STARTED','checks':[],'timings':[]}
def check(name,value):
 assert value,name
 report['checks'].append(name)
tree=ast.parse(source.read_text())
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='fine_any_to_four')
space={'np':np};exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),space)
old=space['fine_any_to_four']
def sliced(mask,shape):
 fine=np.asarray(mask,bool)
 if fine.ndim!=2 or fine.shape[0]>2*shape[0] or fine.shape[1]>2*shape[1]:return np.zeros(shape,bool)
 result=np.zeros(shape,bool)
 for dr in range(2):
  for dc in range(2):
   part=fine[dr::2,dc::2]
   result[:part.shape[0],:part.shape[1]]|=part
 return result
def fast_or(flat,ids,bits):
 if len(ids)<2 or np.all(ids[1:]>ids[:-1]):flat[ids]=np.bitwise_or(flat[ids],bits)
 else:np.bitwise_or.at(flat,ids,bits)
rng=np.random.RandomState(615)
try:
 for i,(h,w,sh,sw) in enumerate([(0,0,1,1),(1,1,1,1),(1,2,1,1),(2,1,1,1),(2,2,1,1),
     (3,5,2,3),(4,6,2,3),(3,6,2,3),(4,5,2,3),(5,6,2,3),(400,400,200,200),(401,399,201,200),(400,600,200,300)]):
  for probability in [0.,.01,.1,.5,1.]:
   m=rng.rand(h,w)<probability;a=old(m,(sh,sw));b=sliced(m,(sh,sw))
   check('reducer_%d_%s'%(i,probability),a.dtype==b.dtype and np.array_equal(a,b))
 for i,m in enumerate([np.zeros(4),np.zeros((2,2,2)),np.zeros((6,2)),np.zeros((2,8)),np.ones((1,1),np.uint8)]):
  check('input_conversion_or_invalid_%d'%i,np.array_equal(old(m,(2,3)),sliced(m,(2,3))))
 for count in [0,10,10000]:
  for mode in ['unique_sorted','unique_unsorted','duplicates']:
   ids=rng.choice(40000,count,replace=False).astype(np.intp);ids.sort()
   if mode=='unique_unsorted':rng.shuffle(ids)
   if mode=='duplicates' and count:ids[::2]=ids[0]
   bits=rng.randint(0,256,count).astype(np.uint8);a=rng.randint(0,256,40000).astype(np.uint8);b=a.copy()
   np.bitwise_or.at(a,ids,bits);fast_or(b,ids,bits)
   check('sparse_%d_%s'%(count,mode),np.array_equal(a,b))
 for h,w in [(400,400),(400,600)]:
  m=rng.rand(h,w)<.01;shape=(h//2,w//2)
  for name,fn in [('padded_reduction',old),('sliced_OR',sliced)]:
   t=time.perf_counter()
   for _ in range(100):fn(m,shape)
   report['timings'].append({'kernel':name,'fine_shape':[h,w],'calls':100,'seconds':time.perf_counter()-t})
 for count in [100,1000,10000]:
  ids=np.sort(rng.choice(40000,count,replace=False)).astype(np.intp);bits=rng.randint(0,256,count).astype(np.uint8)
  for name,fn in [('original_at',np.bitwise_or.at),('checked_unique_fast',fast_or)]:
   a=np.zeros(40000,np.uint8);t=time.perf_counter()
   for _ in range(100):fn(a,ids,bits)
   report['timings'].append({'kernel':name,'sparse_count':count,'calls':100,'seconds':time.perf_counter()-t})
 report.update(status='PASS',count=len(report['checks']),numpy=np.__version__,candidate_created=False,game_rounds=0,production_source_unchanged=hashlib.sha256(source.read_bytes()).hexdigest()==json.loads(decl.read_text())['source_sha256'])
except BaseException:
 report.update(status='FAIL',error=traceback.format_exc());raise
finally:
 out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
'''
p = subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60',
    '/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(remote)],
    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
assert not (F/'NEXT_KERNEL_PROBE_FIRST.json').exists()
(F/'kernel_probe_first_console.txt').write_bytes(p.stdout+p.stderr)
if p.returncode:
    print(p.stderr.decode(errors='replace'));raise SystemExit(p.returncode)
result=json.loads(p.stdout)
(F/'NEXT_KERNEL_PROBE_FIRST.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:result[k] for k in ['status','count','timings','production_source_unchanged']}))
