from pathlib import Path
import sys,subprocess,json
F=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['L02','L03']
code=r"""
from pathlib import Path
import json,datetime,hashlib,shutil,zipfile,ast,difflib
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F11_optics_hysteresis_stall_20261027';v=VERSION
D=json.loads((F/'PREDECLARATION.json').read_text());B=D['parent'];C=F/v;assert not C.exists();C.mkdir();S=C/'source';shutil.copytree(Path(B['path'])/'source',S)
before={p.name:p.read_bytes() for p in S.iterdir()};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if v=='L02':
 p=S/'fast_exploration.py';s=p.read_text();marker='        goal = tuple(int(v) for v in np.unravel_index(np.argmax(score), self.shape))';assert s.count(marker)==1
 s=s.replace(marker,marker+'''
        old=getattr(self,'_hysteresis_old_query',None)
        if old is not None and destination is None and utility is not None:
            old_cell=self.world_to_cell(old)
            self._hysteresis_effective_scores=(tuple(old_cell),goal,float(score[old_cell]),float(score[goal]))
''');p.write_text(s)
 p=S/'fast_exploration_edges.py';s=p.read_text();marker='super().route(position, identifier, peers, utility=values)';assert s.count(marker)==1
 s=s.replace(marker,'self._hysteresis_scored_route(position, identifier, peers, values)')
 marker='values[old_cell] >= .85*values[new_cell]'
 alternate="values[old_cell]*getattr(self,'_viewpoint_factors',{}).get(old_cell,1.) >= .85*values[new_cell]*getattr(self,'_viewpoint_factors',{}).get(new_cell,1.)"
 if alternate in s:marker=alternate
 assert s.count(marker)==1;s=s.replace(marker,'self._hysteresis_should_hold(values,old_cell,new_cell)')
 s+='''

    def _hysteresis_scored_route(self,position,identifier,peers,values):
        self._hysteresis_old_query=None if self.exploration_goal is None else np.asarray(self.exploration_goal,float).copy()
        self._hysteresis_effective_scores=None
        try:return super().route(position,identifier,peers,utility=values)
        finally:self._hysteresis_old_query=None

    def _hysteresis_should_hold(self,values,old_cell,new_cell):
        factors=getattr(self,'_viewpoint_factors',{})
        raw_old=float(values[old_cell])*factors.get(tuple(old_cell),1.)
        raw_new=float(values[new_cell])*factors.get(tuple(new_cell),1.)
        raw_hold=raw_old>=.85*raw_new
        pair=getattr(self,'_hysteresis_effective_scores',None)
        if (pair is None or pair[0]!=tuple(old_cell) or pair[1]!=tuple(new_cell)
            or not np.isfinite(pair[2]) or not np.isfinite(pair[3])
            or self.step-self.last_exploration_goal_step>=120):return raw_hold
        hold=pair[2]>=.85*pair[3]
        diag=getattr(self,'effective_hysteresis_diagnostics',None)
        if diag is None:
            diag={'comparisons':0,'changed_from_raw':0,'switched_from_raw_hold':0,'held_from_raw_switch':0}
            self.effective_hysteresis_diagnostics=diag
        diag['comparisons']+=1;diag['changed_from_raw']+=int(hold!=raw_hold)
        diag['switched_from_raw_hold']+=int(raw_hold and not hold)
        diag['held_from_raw_switch']+=int(hold and not raw_hold)
        diag['last_old_effective']=pair[2];diag['last_new_effective']=pair[3]
        return bool(hold)
''';p.write_text(s)
else:
 p=S/'fast_exploration.py';s=p.read_text();marker='        if self.stuck_steps >= 30:\n            self.memory.reject_goal(self.pose)';assert s.count(marker)==1
 s=s.replace(marker,'''        if self.stuck_steps < 30:
            self._stall_episode_rejected=False
            self._stall_episode_protected_cell=None
        elif self.memory.exploration_goal is not None:
            diag=getattr(self,'stall_rejection_diagnostics',None)
            if diag is None:
                diag={'first_goal_rejections':0,'protected_repeat_calls':0,'protected_new_goal_cells':0}
                self.stall_rejection_diagnostics=diag
            if not getattr(self,'_stall_episode_rejected',False):
                self.memory.reject_goal(self.pose)
                self._stall_episode_rejected=True
                diag['first_goal_rejections']+=1
            else:
                diag['protected_repeat_calls']+=1
                cell=tuple(self.memory.world_to_cell(self.memory.exploration_goal))
                if cell!=getattr(self,'_stall_episode_protected_cell',None):
                    diag['protected_new_goal_cells']+=1
                    self._stall_episode_protected_cell=cell''');p.write_text(s)
for p in S.glob('*.py'):ast.parse(p.read_text())
changed=sorted(p.name for p in S.iterdir() if p.read_bytes()!=before[p.name]);assert changed==sorted(D['directions'][v]['files'])
(C/'CHANGES.diff').write_text(''.join(''.join(difflib.unified_diff(before[n].decode().splitlines(True),(S/n).read_text().splitlines(True),fromfile=D['control_id']+'/'+n,tofile=v+'/'+n)) for n in changed))
z=C/('team615_red_v'+('15' if v=='L02' else '16')+'.zip')
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as archive:
 for p in sorted(S.iterdir()):archive.write(p,p.name)
build={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':v,'path':str(C),'zip':str(z),'zip_sha256':sha(z),'source_files':{p.name:sha(p) for p in S.iterdir()},'changed_files':changed,'parent_id':D['control_id'],'parent_zip_sha256':B['zip_sha256'],'predeclaration_sha256':sha(F/'PREDECLARATION.json'),'release_status':'INTERNAL_NOT_RELEASED'}
(C/'BUILD.json').write_text(json.dumps(build,indent=2)+'\n');print(json.dumps(build))
""".replace('VERSION',repr(v))
b=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python','-'],input=code.encode())
(F/(v+'_BUILD.json')).write_bytes(b);print(json.loads(b)['zip_sha256'])
