"""Unconsumed source transformer for a future fresh diagnostic, never production."""
import ast
import copy


def instrument(source):
    source = dict(source)
    tree = ast.parse(source['bearing_core.py'])
    for name in ['fine_any_to_four', 'independent_incidence']:
        fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
        original = copy.deepcopy(fn.body)
        fn.args.args.append(ast.arg(arg='_profile'))
        fn.args.defaults.append(ast.Constant(value=None))
        timer = ast.parse('_kernel_started = time.perf_counter() if _profile is not None else 0.').body
        final = ast.parse('''
if _profile is not None:
    elapsed = time.perf_counter() - _kernel_started
    _profile['calls'] = _profile.get('calls', 0) + 1
    _profile['seconds'] = _profile.get('seconds', 0.) + elapsed
    _profile['max_seconds'] = max(_profile.get('max_seconds', 0.), elapsed)
''').body
        fn.body = timer + [ast.Try(body=original, handlers=[], orelse=[], finalbody=final)]
        assert ast.dump(ast.Module(body=fn.body[-1].body, type_ignores=[])) == ast.dump(ast.Module(body=original, type_ignores=[]))
    fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'corroborated_map')
    fn.args.args.append(ast.arg(arg='_profile'))
    fn.args.defaults.append(ast.Constant(value=None))
    for node in ast.walk(fn):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            if node.func.id in ['fine_any_to_four', 'independent_incidence']:
                if node.func.id == 'independent_incidence':
                    key = 'render_incidence'
                elif isinstance(node.args[0], ast.Name) and node.args[0].id == 'nonwall':
                    key = 'render_nonwall_projection'
                else:
                    key = 'render_measured_projection'
                expr = ast.parse("_profile.setdefault(%r, {}) if _profile is not None else None" % key, mode='eval').body
                node.keywords.append(ast.keyword(arg='_profile', value=expr))
    tree.body.insert(0, ast.Import(names=[ast.alias(name='time')]))
    ast.fix_missing_locations(tree)
    source['bearing_core.py'] = ast.unparse(tree) + '\n'
    s = source['bearing_memory.py']
    before = '        self.bearing_merged_packets = 0'
    assert s.count(before) == 1
    s = s.replace(before, before + '\n        self.kernel_diagnostics = {}')
    before = 'fine_any_to_four(mask, self.bearing_bits.shape)'
    assert s.count(before) == 1
    s = s.replace(before, "fine_any_to_four(mask, self.bearing_bits.shape, _profile=self.kernel_diagnostics.setdefault('nonwall_projection', {}))")
    before = "self.width, self.height, getattr(self, 'nonwall_mask', None))"
    assert s.count(before) == 1
    s = s.replace(before, "self.width, self.height, getattr(self, 'nonwall_mask', None), _profile=self.kernel_diagnostics)")
    before = '                    np.bitwise_or.at(self.bearing_bits.ravel(), ids.astype(np.intp), bits.astype(np.uint8))'
    assert s.count(before) == 1
    after = '''                    started = time.perf_counter()
                    np.bitwise_or.at(self.bearing_bits.ravel(), ids.astype(np.intp), bits.astype(np.uint8))
                    elapsed = time.perf_counter() - started
                    item = self.kernel_diagnostics.setdefault('received_bearing_union', {})
                    item['calls'] = item.get('calls', 0) + 1
                    item['seconds'] = item.get('seconds', 0.) + elapsed
                    item['max_seconds'] = max(item.get('max_seconds', 0.), elapsed)
                    size = len(ids)
                    bucket = 'empty' if not size else ('le100' if size <= 100 else ('le1000' if size <= 1000 else ('le10000' if size <= 10000 else 'gt10000')))
                    item[bucket] = item.get(bucket, 0) + 1
                    item['elements'] = item.get('elements', 0) + size
                    if size >= 1000:
                        ordered = bool(np.all(ids[1:] > ids[:-1]))
                        item['large_sorted_unique'] = item.get('large_sorted_unique', 0) + int(ordered)
'''.rstrip()
    s = s.replace(before, after)
    ast.parse(s)
    source['bearing_memory.py'] = s
    return source
