from pathlib import Path
import base64,json,subprocess
F=Path(__file__).resolve().parent
code="from pathlib import Path;import json,base64;p=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F11_optics_hysteresis_stall_20261027');paths=list(p.glob('*.json'))+list(p.glob('*/*.json'))+list(p.glob('*_PERF/*_?/*.json'));print(json.dumps({str(f.relative_to(p)):base64.b64encode(f.read_bytes()).decode() for f in paths}))"
d=json.loads(subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python','-'],input=code.encode()))
for n,b in d.items():
 p=F/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(base64.b64decode(b))
print(json.dumps({'synced':len(d),'status':json.loads((F/'STATUS.json').read_text(encoding='utf-8'))['status']}))
