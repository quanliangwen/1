from pathlib import Path
import subprocess,json
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import json,datetime,hashlib,shutil,zipfile,ast,difflib
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F11_optics_hysteresis_stall_20261027'
D=json.loads((F/'PREDECLARATION.json').read_text());B=D['parent'];C=F/'L01';assert not C.exists();C.mkdir();S=C/'source';shutil.copytree(Path(B['path'])/'source',S)
before={p.name:p.read_bytes() for p in S.iterdir()};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=S/'joint_survey.py';s=p.read_text();marker='    clear=~np.any(opaque[rs,cs] & sample,axis=1)';assert s.count(marker)==1
s=s.replace(marker,"    sample &= (rs!=ends[:,0,None]) | (cs!=ends[:,1,None])\n"+marker);p.write_text(s)
p=S/'fast_exploration_edges_optimized.py';s=p.read_text();marker='        return ~np.any(occupied[rows, cols] & sample, axis=1)';assert s.count(marker)==1
s=s.replace(marker,"""        occupied_samples=occupied[rows, cols]
        original_clear=~np.any(occupied_samples & sample,axis=1)
        sample &= (rows!=ends[:,0,None]) | (cols!=ends[:,1,None])
        corrected_clear=~np.any(occupied_samples & sample,axis=1)
        audit=getattr(self,'optical_endpoint_diagnostics',None)
        if audit is None:
            audit={'batch_calls':0,'rays':0,'target_cell_corrections':0}
            self.optical_endpoint_diagnostics=audit
        audit['batch_calls']+=1
        audit['rays']+=len(starts)
        audit['target_cell_corrections']+=int(np.count_nonzero(corrected_clear & ~original_clear))
        return corrected_clear""");p.write_text(s)
p=S/'fast_exploration_edges.py';s=p.read_text();marker='                if len(lr) > 1 and not coarse_wall[lr[:-1], lc[:-1]].any():';assert s.count(marker)==1
s=s.replace(marker,"                intervening=(lr!=end[0]) | (lc!=end[1])\n                if len(lr) > 1 and not coarse_wall[lr[intervening], lc[intervening]].any():");p.write_text(s)
for p in S.glob('*.py'):ast.parse(p.read_text())
changed=sorted(p.name for p in S.iterdir() if p.read_bytes()!=before[p.name]);assert changed==sorted(D['directions']['L01']['files'])
(C/'CHANGES.diff').write_text(''.join(''.join(difflib.unified_diff(before[n].decode().splitlines(True),(S/n).read_text().splitlines(True),fromfile=D['control_id']+'/'+n,tofile='L01/'+n)) for n in changed))
z=C/'team615_red_v14.zip'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as archive:
 for p in sorted(S.iterdir()):archive.write(p,p.name)
build={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':'L01','path':str(C),'zip':str(z),'zip_sha256':sha(z),'source_files':{p.name:sha(p) for p in S.iterdir()},'changed_files':changed,'parent_id':D['control_id'],'parent_zip_sha256':B['zip_sha256'],'predeclaration_sha256':sha(F/'PREDECLARATION.json'),'release_status':'INTERNAL_NOT_RELEASED'}
(C/'BUILD.json').write_text(json.dumps(build,indent=2)+'\n');print(json.dumps(build))
'''
b=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python','-'],input=code.encode())
(F/'L01_BUILD.json').write_bytes(b);print(json.loads(b)['zip_sha256'])
