from pathlib import Path
import json,base64,ast,subprocess,shlex
F=Path(__file__).resolve().parent;OLD=F.parent/'F10_visibility_fix_20261026'
decl=json.loads((F/'PREDECLARATION.json').read_text(encoding='utf-8'));control=decl['control_id']
def common(s):return s.replace('F10_visibility_fix_20261026','F11_optics_hysteresis_stall_20261027').replace('f10pair_20261026_','f11pair_20261027_').replace('f10diag_20261026_','f11diag_20261027_').replace('F10','F11')
bundle={}
for v in ['L01','L02','L03']:
    for name in ['stage_diagnostic','prepare_performance','launch_performance']:
        template=OLD/'operators'/('K04R/stage_diagnostic_m05_decisions.json' if name=='stage_diagnostic' else 'K02R/'+name+'.json')
        d=json.loads(template.read_text(encoding='utf-8'));old='K04R' if name=='stage_diagnostic' else 'K02R'
        d['code']=common(d['code']).replace(old,v)
        if 'version' in d['payload']:d['payload']['version']=v
        if name=='stage_diagnostic':
            m=decl['directions'][v]['diagnostic_map']
            def maptext(s):return s.replace('Map05',m).replace('MAP05',m.upper()).replace('_M05','_M'+m[-2:])
            d['code']=maptext(d['code'])
            for key in ['runner','mixin']:
                s=common(base64.b64decode(d['payload'][key]).decode()).replace(old,v)
                if key=='runner':s=maptext(s)
                if key=='mixin':
                    marker="        state['decision_snapshot']=";assert s.count(marker)==1
                    s=s.replace(marker,"        state['feature_diagnostics']={'optical_endpoint':dict(getattr(self.memory,'optical_endpoint_diagnostics',{})), 'hysteresis':dict(getattr(self.memory,'effective_hysteresis_diagnostics',{})), 'stall':dict(getattr(self,'stall_rejection_diagnostics',{}))}\n"+marker)
                ast.parse(s);d['payload'][key]=base64.b64encode(s.encode()).decode()
        elif name=='prepare_performance':
            s=d['code'];start=s.index("parent=H/'PJ01_submission_team615_v05_20261026'");end=s.index("\nsources={v:build,'PJ01':control}",start)
            s=s[:start]+"control=json.loads((F0/'PREDECLARATION.json').read_text())['parent']\n"+s[end:]
            s=s.replace("'PJ01'",repr(control)).replace('tiePJ01','tie parent').replace('contemporary PJ01','contemporary parent')
            s=s.replace("decl={'utc':","decl={'control_id':"+repr(control)+",'utc':",1)
            s=s.replace("'existing_retained_version':name=="+repr(control),"'existing_retained_version':False,'known_existing_version':name=="+repr(control))
            s=s.replace('84.68230805104568',repr(decl['parent_confirmed_four_cohort_mean']))
            oldauth='Human selected1,2,4 (route reuse, visible exploration, peer-view overlap), requests small evidence first, then tests.'
            s=s.replace(oldauth,'Human requests continuous evidence-led iterations; assistant selected the three predeclared optics, hysteresis and stagnation directions; independent children of the frozen observed winner.')
            d['code']=s
            runner=common(base64.b64decode(d['payload']['run_performance.py']).decode()).replace("'PJ01'",repr(control)).replace('contemporary PJ01','contemporary parent')
            ast.parse(runner);d['payload']['run_performance.py']=base64.b64encode(runner.encode()).decode()
        ast.parse(d['code'])
        p=F/'operators'/v/(name+'.json');p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        bundle[str(p.relative_to(F)).replace('\\','/')]=base64.b64encode(p.read_bytes()).decode()
remote=r'''
from pathlib import Path
import sys,json,base64,hashlib
F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F11_optics_hysteresis_stall_20261027');out={}
for name,b in json.load(sys.stdin).items():
 p=F/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(base64.b64decode(b));out[name]=hashlib.sha256(p.read_bytes()).hexdigest()
(F/'OPERATOR_SHA256.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
'''
b=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(remote)],input=json.dumps(bundle).encode());(F/'OPERATOR_SHA256.json').write_bytes(b)
for name in ['sync_metadata.py','client_verify_finished_cohort.py','summarize_performance.py','review_pair.py','verify_diagnostic_raw.py']:
    s=common((OLD/name).read_text(encoding='utf-8')).replace("['K02R','K04R']","['L01','L02','L03']").replace("['K02R_DIAG','K04R_DIAG']","['L01_DIAG','L02_DIAG','L03_DIAG']").replace("else 'K02R'","else 'L01'")
    if name in ['summarize_performance.py','review_pair.py']:s=s.replace("'PJ01'",repr(control))
    if name=='verify_diagnostic_raw.py':
        s=s.replace("expected_map='Map05' if name=='K04R_DIAG' else 'Map04'","expected_map={'L01_DIAG':'Map01','L02_DIAG':'Map01','L03_DIAG':'Map05'}[name]")
        s=s.replace("if expected_map=='Map05':assert json.loads((F/'MAP05_DIAGNOSTIC_AMENDMENT.json').read_text(encoding='utf-8'))['diagnostic_map']=='Map05'","assert json.loads((F/'PREDECLARATION.json').read_text(encoding='utf-8'))['directions'][name[:-5]]['diagnostic_map']==expected_map")
    ast.parse(s);(F/name).write_text(s,encoding='utf-8')
print('Nine one-use operations prepared, control is '+control+' with actual parent source; no evaluation launched')
