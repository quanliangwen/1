    import types,ast
    from swarm_rescue.solutions.fast_exploration_edges import EdgeSurveyMapMemory as NewEdge
    parent=json.loads((F.parent/'PREDECLARATION.json').read_text())['parent']
    reference_path=Path(parent['path'])/'source/fast_exploration_edges.py'
    reference=types.ModuleType('f11_parent_edge_reference');exec(compile(reference_path.read_text(),str(reference_path),'exec'),reference.__dict__)
    def fixture(cls,old_col=25,new_col=5,old_value=100.,new_value=80.,age=24):
        m=cls(512,128);m.free[:]=True;m.step=age;m.last_exploration_goal_step=0
        p=m.cell_to_world((4,3));old=m.cell_to_world((4,old_col));new=m.cell_to_world((4,new_col))
        values=np.full(m.shape,-np.inf);values[4,old_col]=old_value;values[4,new_col]=new_value
        m.exploration_goal=old.copy();m.survey_gain=lambda blocked=None:np.ones(m.shape)
        m.exploration_utility=lambda position,peers=(),survey=None:values.copy()
        return m,p,old,new,values
    original,p,old,new,values=fixture(reference.EdgeSurveyMapMemory)
    candidate,q,_,_,_=fixture(NewEdge)
    a=original.route(p);b=candidate.route(q)
    check('parent_raw_hysteresis_counterexample_reproduced',np.array_equal(a[1],old))
    check('effective_hysteresis_switches_to_better_scored_near_goal',np.array_equal(b[1],new))
    check('reachable_actual_hysteresis_change_counted',candidate.effective_hysteresis_diagnostics['switched_from_raw_hold']==1)
    check('query_context_cleared',candidate._hysteresis_old_query is None)
    original,p,old,new,values=fixture(reference.EdgeSurveyMapMemory,6,18,70.,102.)
    candidate,q,_,_,_=fixture(NewEdge,6,18,70.,102.)
    a=original.route(p);b=candidate.route(q)
    check('parent_would_switch_based_on_raw_values',np.array_equal(a[1],new))
    check('effective_hysteresis_can_retain_near_incumbent',np.array_equal(b[1],old))
    check('inverse_hysteresis_change_counted',candidate.effective_hysteresis_diagnostics['held_from_raw_switch']==1)
    original,p,old,new,values=fixture(reference.EdgeSurveyMapMemory,age=121)
    candidate,q,_,_,_=fixture(NewEdge,age=121)
    a=original.route(p);b=candidate.route(q)
    check('existing120_step_hysteresis_age_preserved',np.array_equal(a[1],b[1]) and np.array_equal(b[1],new))
    for mode in ['destination','external_utility']:
        original,p,old,new,values=fixture(reference.EdgeSurveyMapMemory)
        candidate,q,_,_,_=fixture(NewEdge)
        kwargs={'destination':new} if mode=='destination' else {'utility':values}
        a=original.route(p,**kwargs);b=candidate.route(q,**kwargs)
        check('nonordinary_goal_unchanged_'+mode,np.array_equal(a[1],b[1]))
        check('nonordinary_path_unchanged_'+mode,len(a[0])==len(b[0]) and all(np.array_equal(x,y) for x,y in zip(a[0],b[0])))
        check('nonordinary_no_new_hysteresis_'+mode,not hasattr(candidate,'effective_hysteresis_diagnostics'))
    m,p,old,new,values=fixture(NewEdge)
    m._hysteresis_effective_scores=None
    check('missing_pair_falls_back_to_original_rule',bool(m._hysteresis_should_hold(values,(4,25),(4,5))))
    m._hysteresis_effective_scores=((4,25),(4,5),-np.inf,1.)
    check('unreachable_old_score_keeps_original_fallback',bool(m._hysteresis_should_hold(values,(4,25),(4,5))))
    try:m._hysteresis_scored_route(p,0,[],np.zeros(1))
    except (IndexError,ValueError):pass
    check('query_context_cleared_after_invalid_fixture',m._hysteresis_old_query is None)
