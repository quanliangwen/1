from pathlib import Path
import sys,json,datetime,subprocess,shlex
F=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['L01','L02','L03'];G=F/(v+'_DIAG')
assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'))['valid']
contract=json.loads((F/v/'CONTRACT_RESULT.json').read_text(encoding='utf-8'));assert contract['status']=='PASS'
e=json.loads((G/'EVENTS.json').read_text(encoding='utf-8'));last={}
for t in e['F11_DIAG_TICK']:last[t['owner']]=t
feature,signal={'L01':('optical_endpoint','target_cell_corrections'),'L02':('hysteresis','changed_from_raw'),'L03':('stall','protected_new_goal_cells')}[v]
keys=set(k for t in last.values() for k in t['feature_diagnostics'][feature])
s={k:sum(t['feature_diagnostics'][feature].get(k,0) for t in last.values()) for k in keys if not k.startswith('last_')}
result=json.loads((G/'RESULT.json').read_text(encoding='utf-8'));assert result['valid'] and not result['row']['crashed']
admit=s.get(signal,0)>0
reason=('Actual selected mechanism triggered in the declared fresh diagnostic; qualified source and first client raw checks pass. Proceed to frozen original-five comparison vs actual K01 parent, not historical PJ01.' if admit else 'No observed selected mechanism opportunity in this fresh diagnostic; stop expansion, not proof of global impossibility.')
reason+=' Own last checkpoints may undercount final calls; counters are not whole-policy counterfactuals or proof of score gain. RED-only map/stock values diagnostic, no unpaired ranking. No source/parameter/clock/input rescue.'
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':v,'start_five_map_now':admit,'feature':feature,'counts':s,'qualification_first_checks':len(contract['checks']),'stock':[result['row']['placed'],result['row']['expected']],'RED_map_score_not_performance':result['row']['phase']['score_map'],'reason':reason,'client_raw_verified':True,'control_id':json.loads((F/'PREDECLARATION.json').read_text(encoding='utf-8'))['control_id']}
p=G/'MECHANISM_REVIEW.json';assert not p.exists();p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
rf='/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F11_optics_hysteresis_stall_20261027/'+v+'_DIAG/MECHANISM_REVIEW.json'
code="from pathlib import Path;import sys;p=Path("+repr(rf)+");assert not p.exists();p.write_bytes(sys.stdin.buffer.read())"
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=p.read_bytes(),check=True)
print(json.dumps(d))
