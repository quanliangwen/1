from pathlib import Path
import subprocess, shlex, json
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import ast,json,hashlib,datetime,traceback,time
import numpy as np
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
F=H/'F11_optics_hysteresis_stall_20261027';D=F/'INCIDENCE_LOOKUP_PROBE_DECLARATION.json';G=F/'INCIDENCE_LOOKUP_PROBE_FIRST.json'
assert not D.exists() and not G.exists()
p=H/'F09_route_and_views_20261026/K01/source/bearing_core.py'
D.write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
 'scope':'One synthetic exhaustive8bit equivalence and micro-cost check; zero candidate/source mutation/game/history input. First failure retained/no retry. All256 scalar values including output ndarray type, plus array/dtype/noncontiguous/empty cases. Timing only after all pass; no actual-call-count or whole-game inference.'})+'\n')
report={'status':'STARTED','checks':[],'timings':[]}
def check(n,x):
 assert x,n
 report['checks'].append(n)
tree=ast.parse(p.read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='independent_incidence')
space={'np':np};exec(compile(ast.Module(body=[fn],type_ignores=[]),str(p),'exec'),space);old=space['independent_incidence']
lut=np.asarray([any(bool(v&(1<<a)) and bool(v&(1<<b)) and min(b-a,8-(b-a))>=2 for a in range(8) for b in range(a+1,8)) for v in range(256)],bool);lut.setflags(write=False)
def lookup(bits):return np.asarray(lut[np.asarray(bits,np.uint8)],dtype=bool)
def equal(x):
 before=np.asarray(x).copy();a=old(x);b=lookup(x)
 return isinstance(a,np.ndarray) and isinstance(b,np.ndarray) and a.shape==b.shape and a.dtype==b.dtype and np.array_equal(a,b) and np.array_equal(np.asarray(x),before)
try:
 for v in range(256):check('scalar_%d'%v,equal(v))
 rng=np.random.RandomState(615);x=rng.randint(0,256,(20,30),dtype=np.uint8)
 for name,value in [('all_values',np.arange(256,dtype=np.uint8)),('empty',np.empty((0,3),np.uint8)),('2d',x),('transpose',x.T),('reverse',x[::-1,::2]),('int16',x.astype(np.int16)),('float32',x.astype(np.float32)),('bool',x>127),('3d',x.reshape(4,5,30))]:check(name,equal(value))
 for shape in [(100,100),(200,200),(200,300)]:
  x=rng.randint(0,256,shape,dtype=np.uint8)
  for name,fn in [('original_pairs',old),('lookup',lookup)]:
   t=time.perf_counter()
   for _ in range(100):fn(x)
   report['timings'].append({'kernel':name,'shape':shape,'calls':100,'seconds':time.perf_counter()-t})
 report.update(status='PASS',count=len(report['checks']),candidate_created=False,game_rounds=0)
except BaseException:report.update(status='FAIL',error=traceback.format_exc());raise
finally:G.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
'''
p=subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert not(F/'incidence_lookup_first_console.txt').exists()
(F/'incidence_lookup_first_console.txt').write_bytes(p.stdout+p.stderr)
if p.returncode:
 print(p.stdout.decode(errors='replace')[-3000:]);print(p.stderr.decode(errors='replace')[-3000:]);raise SystemExit(p.returncode)
d=json.loads(p.stdout)
(F/'INCIDENCE_LOOKUP_PROBE_FIRST.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:d[k] for k in ['status','count','timings']}))
