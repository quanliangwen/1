from pathlib import Path
import subprocess,sys,json,os
F=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['L01','L02','L03']
subprocess.run([sys.executable,str(F/'sync_metadata.py')],check=True)
state=json.loads((F/(v+'_PERF')/'STATUS.json').read_text(encoding='utf-8'))
for item in state['completed']:
    G=F/(v+'_PERF')/(item['version']+'_'+item['cohort'])
    if (G/'CLIENT_FIRST_RAW_REVIEW.json').exists():continue
    assert not(G/'raw_results.tar.gz').exists(),'Preserve existing unverified archive, inspect instead of overwriting'
    subprocess.run([sys.executable,str(F/'client_verify_finished_cohort.py'),v,item['version'],item['cohort']],check=True)
subprocess.run([sys.executable,str(F/'summarize_performance.py'),v],check=True)
