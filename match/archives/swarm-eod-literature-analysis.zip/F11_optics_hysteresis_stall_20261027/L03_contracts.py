    import types,ast
    from swarm_rescue.solutions.fast_exploration import CoordinatedMapMemory,ExplorationMotionMixin
    class ParentMessages:
        def _messages(self):pass
    class Probe(ExplorationMotionMixin,ParentMessages):pass
    def fixture(goal=True):
        d=object.__new__(Probe);d.memory=CoordinatedMapMemory(512,128);d.identifier=0;d.rally=None;d.pose=np.zeros(2)
        d.exploration_records={};d.communicator=types.SimpleNamespace(received_messages=[]);d.stuck_steps=30
        if goal:d.memory.exploration_goal=d.memory.cell_to_world((4,15))
        return d
    d=fixture()
    for step in range(31,60):
        d.elapsed_timestep=step
        if step==48:d.memory.exploration_goal=d.memory.cell_to_world((4,19))
        d._messages()
    check('one_nonempty_rejection_per_continuous_episode',len(d.memory.failed_goals)==1)
    check('new_goal_protected_in_same_episode',np.array_equal(d.memory.exploration_goal,d.memory.cell_to_world((4,19))))
    check('original220_step_blacklist_ttl_preserved',d.memory.failed_goals[0][0]==31+220)
    check('protected_nonempty_goal_mechanism_counted',d.stall_rejection_diagnostics['protected_new_goal_cells']==1 and d.stall_rejection_diagnostics['protected_repeat_calls']>0)
    d.stuck_steps=0;d.elapsed_timestep=60;d._messages()
    d.stuck_steps=30;d.elapsed_timestep=61;d._messages()
    check('new_stagnation_episode_can_reject_again',len(d.memory.failed_goals)==2 and d.memory.exploration_goal is None)
    d=fixture(False)
    for step in range(31,40):
        d.elapsed_timestep=step
        if step==36:d.memory.exploration_goal=d.memory.cell_to_world((4,19))
        d._messages()
    check('empty_goal_does_not_consume_episode_allowance',len(d.memory.failed_goals)==1 and d.memory.failed_goals[0][0]==36+220)
    d=fixture();d.stuck_steps=29;d.elapsed_timestep=31;d._messages()
    check('original30_step_threshold_preserved',len(d.memory.failed_goals)==0 and d.memory.exploration_goal is not None)
    parent=json.loads((F.parent/'PREDECLARATION.json').read_text())['parent']
    before=ast.parse((Path(parent['path'])/'source/fast_exploration.py').read_text())
    after=ast.parse((C/'source/fast_exploration.py').read_text())
    def methods(tree):
        return {(n.name,f.name):ast.dump(f) for n in tree.body if isinstance(n,ast.ClassDef) for f in n.body if isinstance(f,ast.FunctionDef)}
    a=methods(before);b=methods(after)
    check('only_exploration_message_method_changed',set(a)==set(b) and all(a[k]==b[k] for k in a if k!=('ExplorationMotionMixin','_messages')))
