from pathlib import Path
import json,subprocess
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import json,datetime,hashlib
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F11_optics_hysteresis_stall_20261027'
assert not F.exists()
old=H/'F10_visibility_fix_20261026';assert json.loads((old/'K02R_PERF/STATUS.json').read_text())['status']=='EARLY_SCREENED_VALID_SCORE'
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':F.name,'status':'PREPARATION_ONLY_WAIT_CURRENT_K04R','authorization':'Human explicitly requests sustained evidence-led iterations, five ranked directions and assistant chooses three without asking. New selected three are optical target-cell semantics, effective-score hysteresis, and one exploration rejection per stagnation episode. Finish current K04R before native dispatch.',
'five_ranked_directions':[
{'id':1,'priority':'highest','name':'Optical visibility excludes every target-cell duplicate sample','evidence':'Actual baseline joint/edge helpers change visible1/true to0/false when translated one cell; repaired helper preserves1.'},
{'id':2,'priority':'high','name':'Ordinary frontier hysteresis uses the same final distance-weighted utility','evidence':'Actual baseline synthetic graph selects new effective74.074 vs old53.191, but raw100vs80 hysteresis retains old.'},
{'id':3,'priority':'medium_high','name':'At most one nonempty exploration goal rejected per stagnation episode','evidence':'Fresh Map05 diagnostic has6 extra nonempty goals rejected within existing episodes; actual-method synthetic fixture reproduces2 goals per episode.'},
{'id':4,'priority':'defer','name':'Use conservative recent computation rate for optional acquisition','evidence':'Own cached scalar sensitivity reconstructs95/95 decisions and proposed bound flips0 in this diagnostic. Do not expand without actual opportunity.'},
{'id':5,'priority':'low','name':'Exact early exit for explicit reachable geometry fallback goal','evidence':'Baseline full search310pops even near target, but fresh actual fallback only1.56366s/206.75987s control. Low payoff priority.'}],
'order':['L01','L02','L03'],'directions':{
'L01':{'files':['joint_survey.py','fast_exploration_edges.py','fast_exploration_edges_optimized.py'],'change':'Fix only optical ray endpoint grid-cell masking, including scalar/vector consistency; do not alter motion/path visibility, safety, weights, candidate pool or budgets. Own correction counters permitted, no global observations.','diagnostic_map':'Map01'},
'L02':{'files':['fast_exploration.py','fast_exploration_edges.py'],'change':'Expose only transient own final utility scores for old/new ordinary frontier goals, use existing .85 and120-step hysteresis on comparable scores; preserve fallback on missing/unreachable scores. No extra Dijkstra or new weights.','diagnostic_map':'Map01'},
'L03':{'files':['fast_exploration.py'],'change':'Retain original30/60-step stuck and220-step blacklist TTL; once a nonempty exploration goal has been rejected in that same stuck episode, protect new goals until the episode resets. Do not change assignment watchdog, physical motion or leases.','diagnostic_map':'Map05'}},
'parent_selection':'After current K04R terminates and no evaluators run, choose the highest observed original-five mean among complete4v4 winners vs their contemporaneous controls (K01 and optionally K04R), with previous established K01 on ties. This is a frozen observed-mean selection rule, not proof of global optimum or significance. Resolve actual source ZIP SHA/name before any candidate source mutation. Each new candidate is independent from that same frozen parent; no mid-round rebasing or feature stacking.',
'protocol':'Full actual qualified-source/ABI/consumer/small state checks, then one fresh diagnostic per candidate at specified original map. Must explain actual mechanism opportunity/cost before interleaved original Map01-05 RED→BLUE testing. Candidate any complete-five mean<80 stop; at n2 cumulative<=contemporary parent stop; positive expands to complete4v4; strict higher mean only, ties parent. No historical threshold. All surviving pairs client archive checked and reviewed. No first-native failure rerun, changed labels/clocks/inputs/SDK/BLUE/maps/scoring.',
'runtime':'Native ROOT/.venv/run_server numpy1.26.4/pandas3.0.6/cv4.11.0 unchanged, no installs. Qualification separately1.26.4/2.2.3/4.11.0.86. Numericteam615/exact pins, internal ZIPs not published until actual ZIP-bound release ABI guard.',
'scope':'Own public sensor/message state only; no truth/privateBLUE/peer objects/shared global observations/history or replay; NPZ/pickle opaque SHA only. Single evaluator, no subagents, Docker,50maps,website upload or new app automation. Preserve all prior failures/low scores. Max24 full-five groups and3 RED-only diagnostics, expand only on evidence.'}
F.mkdir();(F/'PREPARATION_DECLARATION.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(d))
'''
b=subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python','-'],input=code.encode())
(F/'PREPARATION_DECLARATION.json').write_bytes(b);print('Next three selected and prospectively declared; no source changed or new evaluation started')
