from pathlib import Path
import json, statistics, datetime
F=Path(__file__).resolve().parent
groups=[];rows=[];hashes=set()
for phase in ['L01','L02','L03']:
    P=F/(phase+'_PERF')
    if not (P/'STATUS.json').exists():continue
    state=json.loads((P/'STATUS.json').read_text(encoding='utf-8'))
    for item in state['completed']:
        if item['version']!='K01':continue
        G=P/('K01_'+item['cohort'])
        if not(G/'CLIENT_FIRST_RAW_REVIEW.json').exists():continue
        r=json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'));assert r['valid']
        d=json.loads((G/'RESULT.json').read_text(encoding='utf-8'))
        hashes.add(r['source_zip_sha256'])
        groups.append({'phase':phase,'cohort':item['cohort'],'mean':d['equal_weight_mean']})
        rows.extend(d['rows'])
assert len(hashes)==1
def describe(values):
    return {'n':len(values),'mean':statistics.mean(values),'min':min(values),'max':max(values),
        'sample_sd':statistics.stdev(values) if len(values)>1 else None}
terms=['map_score','wall_score','completion_adjusted_blue','time_score']
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_zip_sha256':next(iter(hashes)),
    'groups':groups,'cohort_means':describe([g['mean'] for g in groups]),
    'per_map':{m:{k:describe([r[k] for r in rows if r['map']==m]) for k in ['full_score',*terms]} for m in ['Map01','Map02','Map03','Map04','Map05']},
    'notes':'Descriptive snapshot of already completed first-client-verified F11 K01 controls only. No new runs, historical arrays or replay. Unequal phase times, unseeded games; not IID/no significance or causal environment effect assumed. Does not replace each candidate contemporaneous control, alter frozen gates or decide parent by highest single group.'}
(F/'PARENT_DESCRIPTIVE_ANALYSIS.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'cohort_means':report['cohort_means'],'map_full_score_ranges':{m:v['full_score'] for m,v in report['per_map'].items()}}))
