from pathlib import Path
import subprocess,json
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import json,hashlib,datetime,fcntl
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F11_optics_hysteresis_stall_20261027';OLD=H/'F10_visibility_fix_20261026'
assert not(F/'PREDECLARATION.json').exists()
for v in ['K02R','K04R']:
 s=json.loads((OLD/(v+'_PERF')/'STATUS.json').read_text());assert s['status'] in ['EARLY_SCREENED_VALID_SCORE','COMPLETE_ALL_EIGHT_PAIRED_GROUPS']
 p=Path('/proc')/str(s['pid'])/'stat'
 try:assert not p.exists() or p.read_text().split()[2]=='Z'
 except FileNotFoundError:pass
assert not(OLD/'FIRST_NATIVE_ERROR.json').exists()
activity=json.loads((R/'solver_study/heuristic_20261016.json').read_text());assert not activity.get('active_processes') and not activity.get('current_formal_active')
with (R/'solver_study/serial_evaluation.lock').open('a+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
winners=[]
for v,G,base in [('K01',H/'F09_route_and_views_20261026/K01_PERF','PJ01'),('K04R',OLD/'K04R_PERF','PJ01')]:
 result=json.loads((G/'RESULT.json').read_text())
 if result.get('complete') and result['versions'][v]['mean']>result['versions'][base]['mean']:
  source=H/('F09_route_and_views_20261026' if v=='K01' else 'F10_visibility_fix_20261026')/v/'BUILD.json'
  B=json.loads(source.read_text());winners.append((result['versions'][v]['mean'],v,B))
assert winners
winners.sort(key=lambda t:(-t[0],0 if t[1]=='K01' else 1));mean,v,B=winners[0]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(Path(B['zip']))==B['zip_sha256']
assert {p.name:sha(p) for p in (Path(B['path'])/'source').iterdir() if p.is_file()}==B['source_files']
prep=json.loads((F/'PREPARATION_DECLARATION.json').read_text())
d={**prep,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PARENT_RESOLVED_BEFORE_SOURCE_MUTATION','preparation_sha256':sha(F/'PREPARATION_DECLARATION.json'),'control_id':v,'parent':B,'parent_confirmed_four_cohort_mean':mean,'parent_interpretation':'Highest observed mean among complete4v4 winners under the predeclared rule; small advantage/no significance or global optimum claim. All three independent children use this exact source. Existing scores, clocks and inputs unchanged.'}
(F/'PREDECLARATION.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');(F/'STATUS.json').write_text(json.dumps({'status':'PARENT_RESOLVED_AWAIT_L01_BUILD','control_id':v,'utc':d['utc']})+'\n');print(json.dumps(d))
'''
b=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python','-'],input=code.encode())
(F/'PREDECLARATION.json').write_bytes(b);d=json.loads(b);print(json.dumps({'control':d['control_id'],'parent_sha256':d['parent']['zip_sha256'],'observed_mean':d['parent_confirmed_four_cohort_mean']}))
