    from swarm_rescue.solutions.joint_survey import visible_gain
    from swarm_rescue.solutions.fast_exploration_edges import EdgeSurveyMapMemory
    from swarm_rescue.solutions.fast_exploration_edges_optimized import OptimizedEdgeSurveyMapMemory
    from swarm_rescue.solutions.bearing_memory import BearingMemory
    check('active_bearing_memory_uses_patched_optical_class',issubclass(BearingMemory,OptimizedEdgeSurveyMapMemory))
    m=OptimizedEdgeSurveyMapMemory(320,192)
    for col in [8,9]:
        target=(6,col+1);start=(6,col)
        weights=np.zeros((12,20),np.float32);weights[target]=1.
        opaque=np.zeros(weights.shape,bool);opaque[target]=True
        before_weights=weights.copy();before_opaque=opaque.copy()
        check('joint_surface_translation_'+str(col),visible_gain(start,weights,opaque,16.)==1.)
        check('optimized_surface_translation_'+str(col),bool(m._batch_line_visibility([start],[target],opaque)[0]))
        check('visibility_inputs_not_mutated_'+str(col),np.array_equal(weights,before_weights) and np.array_equal(opaque,before_opaque))
    check('actual_endpoint_correction_counter',m.optical_endpoint_diagnostics['target_cell_corrections']>0)
    weights=np.zeros((12,20),np.float32);weights[6,12]=1.
    opaque=np.zeros(weights.shape,bool);opaque[:,10:12]=True
    check('joint_hidden_unknown_not_unblocked',visible_gain((6,9),weights,opaque,16.)==0.)
    check('optimized_hidden_unknown_not_unblocked',not bool(m._batch_line_visibility([(6,9)],[(6,12)],opaque)[0]))
    weights[:]=0;weights[6,11]=1.
    check('joint_far_surface_of_thick_wall_still_hidden',visible_gain((6,9),weights,opaque,16.)==0.)
    rng=np.random.RandomState(61511)
    for i in range(32):
        opaque=rng.random_sample((12,20))<.12
        start=(int(rng.randint(12)),int(rng.randint(20)));end=(int(rng.randint(12)),int(rng.randint(20)))
        lr,lc=EdgeSurveyMapMemory._line_cells(start,end)
        keep=(lr!=end[0]) | (lc!=end[1])
        scalar=not opaque[lr[keep],lc[keep]].any()
        batch=bool(m._batch_line_visibility([start],[end],opaque)[0])
        check('scalar_vector_target_cell_semantics_'+str(i),scalar==batch)
    for i in range(3):
        scalar=EdgeSurveyMapMemory(256,128)
        vector=OptimizedEdgeSurveyMapMemory(256,128)
        scalar.free[:]=True;vector.free[:]=True
        scalar.hits[:]=np.where(rng.random_sample(scalar.hit_shape)<.002,3,0)
        vector.hits[:]=scalar.hits
        a=scalar.survey_gain();b=vector.survey_gain()
        check('whole_survey_gain_scalar_vector_'+str(i),np.allclose(a,b,rtol=0,atol=1e-5))
