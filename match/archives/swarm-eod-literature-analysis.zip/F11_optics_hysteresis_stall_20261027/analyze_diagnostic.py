from pathlib import Path
import json, sys, datetime

F = Path(__file__).resolve().parent
v = sys.argv[1]
assert v in ['L01', 'L02', 'L03']
G = F / (v + '_DIAG')
assert json.loads((G / 'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'))['valid']
events = json.loads((G / 'EVENTS.json').read_text(encoding='utf-8'))
result = json.loads((G / 'RESULT.json').read_text(encoding='utf-8'))
assert result['valid'] and not result['row']['crashed']
last = {}
for name in ['F11_DIAG_TICK', 'F11_SUBMIT_DECISION', 'F11_SUBMIT_CALL']:
    for state in events.get(name, []):
        owner = state['owner']
        if owner not in last or state['step'] >= last[owner]['step']:
            last[owner] = state

costs = {}
for s in last.values():
    for name, c in s['costs'].items():
        d = costs.setdefault(name, {'calls': 0, 'seconds': 0., 'largest_call': 0.})
        d['calls'] += c['calls']
        d['seconds'] += c['seconds']
        d['largest_call'] = max(d['largest_call'], c['max_seconds'])
feature = {'L01': 'optical_endpoint', 'L02': 'hysteresis', 'L03': 'stall'}[v]
counts = {}
for s in last.values():
    for name, value in s['feature_diagnostics'][feature].items():
        if not name.startswith('last_'):
            counts[name] = counts.get(name, 0) + value
submissions = [{k: s.get(k) for k in ['owner', 'step', 'stock', 'all_certificates',
    'remaining_steps', 'wall_left', 'reason', 'cached_map_quality',
    'submitted_pixels', 'first_complete_step']} for s in events.get('F11_SUBMIT_CALL', [])]
sub_decisions = [{k: s.get(k) for k in ['owner', 'step', 'stock', 'all_certificates',
    'remaining_steps', 'wall_left', 'reason', 'cached_map_quality']} for s in events.get('F11_SUBMIT_DECISION', [])]
ticks = events.get('F11_DIAG_TICK', [])
all_done = [s for s in ticks if s['all_certificates']]
opportunities = [s for s in ticks if s['all_certificates'] and s['remaining_steps'] >= 240 and s['wall_left'] >= 15]
report = {
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'version': v,
    'own_feature_counts_at_last_checkpoints': counts,
    'own_costs_at_last_checkpoints_nested_not_additive': costs,
    'submission_decisions': sub_decisions, 'actual_submission_calls': submissions,
    'all_certificates_checkpoints': len(all_done),
    'all_certificates_and_240steps_15seconds_checkpoints': len(opportunities),
    'last_observed_steps': {str(k): s['step'] for k, s in last.items()},
    'diagnostic_row_not_five_map_ranking': result['row'],
    'notes': 'Only existing JSON own-method scalar logs; no NPZ/pickle loading, replay, new simulation, or global sensor access. Counters can undercount final calls. Logging changes walltime. Submission opportunity is a necessary budget condition, not evidence of reachable map gain. Costs are nested and must not be summed.'
}
(G / 'SCALAR_ANALYSIS.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: report[k] for k in ['version', 'own_feature_counts_at_last_checkpoints',
    'actual_submission_calls', 'all_certificates_checkpoints',
    'all_certificates_and_240steps_15seconds_checkpoints']}, ensure_ascii=False))
