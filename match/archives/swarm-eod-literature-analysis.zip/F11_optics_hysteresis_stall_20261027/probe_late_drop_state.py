from pathlib import Path
import subprocess,shlex,json
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import ast,json,hashlib,datetime,traceback,types
import numpy as np
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
F=H/'F11_optics_hysteresis_stall_20261027';D=F/'LATE_DROP_STATE_PROBE_DECLARATION.json';G=F/'LATE_DROP_STATE_PROBE_FIRST.json'
assert not D.exists() and not G.exists()
p=H/'F09_route_and_views_20261026/K01/source/active_coverage.py'
D.write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
 'scope':'Actual ActiveCoverageMixin._maybe_place AST method in isolated synthetic own-state fixture; no new candidate, controller control/simulator/game/history inputs. Only show possible source gate; native occurrence and legality not established. First execution/failure retained, no retry.',
 'contexts':'stock1/no goal at remaining80/wall95percent; valid nearby goal; far goal; no legal current position; pending command; zero stock; submitted; retry interval.'})+'\n')
tree=ast.parse(p.read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ActiveCoverageMixin')
fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_maybe_place');space={'np':np}
exec(compile(ast.Module(body=[fn],type_ignores=[]),str(p),'exec'),space);method=space['_maybe_place']
report={'status':'STARTED','checks':[],'observations':[]}
def check(n,x):
 assert x,n
 report['checks'].append(n)
def fixture():
 return types.SimpleNamespace(carried_bombs_count=lambda:1,submitted=False,pose=np.zeros(2),pending_drop=None,
  last_attempt_step=-100,placement_goal=None,placement_arrival_radius=20.,_placement_allowed=lambda step,semantic:True,
  _remaining_steps=lambda:80.,elapsed_walltime=171.,walltime_limit=180.,limit=5000)
try:
 for name in ['no_goal','near_goal','far_goal','illegal_current','pending','empty','submitted','retry']:
  d=fixture()
  if name=='near_goal':d.placement_goal=np.array([4.,0.])
  if name=='far_goal':d.placement_goal=np.array([200.,0.])
  if name=='illegal_current':d._placement_allowed=lambda step,semantic:False
  if name=='pending':d.pending_drop=(1,d.pose.copy(),2099)
  if name=='empty':d.carried_bombs_count=lambda:0
  if name=='submitted':d.submitted=True
  if name=='retry':d.last_attempt_step=2099
  command={};method(d,command,2100,[])
  attempt=command.get('place_bomb')==1
  check(name,attempt==(name=='near_goal'))
  report['observations'].append({'context':name,'remaining_steps':80.,'elapsed_wall_fraction':.95,'attempted':attempt})
 report.update(status='PASS',count=len(report['checks']),game_rounds=0,source_unchanged=hashlib.sha256(p.read_bytes()).hexdigest()==json.loads(D.read_text())['sha256'],
  interpretation='Original active method ignores imminent wall-clock budget when no reached assigned goal; this fixture is not evidence that real missed drop was legal or caused by this gate. Need fresh Map04 own-state passive guard diagnostic before implementation.')
except BaseException:report.update(status='FAIL',error=traceback.format_exc());raise
finally:G.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
'''
p=subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert not(F/'late_drop_state_first_console.txt').exists()
(F/'late_drop_state_first_console.txt').write_bytes(p.stdout+p.stderr)
if p.returncode:
 print(p.stdout.decode(errors='replace')[-3000:]);print(p.stderr.decode(errors='replace')[-3000:]);raise SystemExit(p.returncode)
d=json.loads(p.stdout);(F/'LATE_DROP_STATE_PROBE_FIRST.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
print(json.dumps(d))
