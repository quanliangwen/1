"""Finite Windows byte review and final report; never starts a native game."""
from pathlib import Path
import base64,datetime,hashlib,json,subprocess,tarfile,time,traceback
F=Path(__file__).resolve().parent;C=F
R='/home/junhao/quan/parallel_test_solver/match';RF=R+'/solver_study/framework_screen_20261016/best87_independent_20261025/'+F.name;RC=RF
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,d):
    t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');t.replace(p)
def upload(p,d):subprocess.run(['scp','-q',str(p),'junhao@10.112.162.60:'+d],check=True)
def metadata():
    code='''from pathlib import Path
import json,base64
p=Path(ROOT)
names=[str(x.relative_to(p)) for x in p.glob('*.json')]+[str(x.relative_to(p)) for x in p.glob('*.txt')]
for q in p.iterdir():
 if q.is_dir() and (q.name in ['J17'] or (q/'RAW_ARCHIVE_RECEIPT.json').exists()):
  names += [str(x.relative_to(p)) for x in q.glob('*.json')]
print(json.dumps({n:base64.b64encode((p/n).read_bytes()).decode() for n in names}))
'''.replace('ROOT',repr(RC))
    bundle=json.loads(subprocess.check_output(ssh+[R+'/.venv/bin/python','-'],input=code.encode(),timeout=45))
    for n,v in bundle.items():
        p=C/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(base64.b64decode(v))
    return read(C/'STATUS.json') if(C/'STATUS.json').exists() else {'status':'STARTING','completed':[]}
def review(G):
    if(G/'CLIENT_FIRST_RAW_REVIEW.json').exists():return
    receipt=read(G/'RAW_ARCHIVE_RECEIPT.json');manifest=read(G/'RAW_SHA256.json')
    assert sha(G/'RAW_SHA256.json')==receipt['manifest_sha256']
    archive=G/'raw_results.tar.gz';assert not archive.exists(),'Unverified archive already exists: no automatic replacement'
    subprocess.run(['scp','-q','junhao@10.112.162.60:'+RC+'/'+G.name+'/raw_results.tar.gz',str(archive)],check=True)
    assert sha(archive)==receipt['sha256'];seen=set();public=[]
    with tarfile.open(archive,'r:gz') as tar:
        for e in tar:
            assert e.isfile() and e.name in manifest and e.name not in seen and '..' not in Path(e.name).parts
            selected=e.name.endswith(('/round1_public_visual.json','/round1_red_submitted.png','/round1_bombs.json','/summary.json'))
            h=hashlib.sha256();size=0;parts=[]
            with tar.extractfile(e) as f:
                for block in iter(lambda:f.read(1024*1024),b''):
                    h.update(block);size+=len(block)
                    if selected:parts.append(block)
            assert h.hexdigest()==manifest[e.name]['sha256'] and size==manifest[e.name]['bytes']
            if selected:
                p=G/e.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b''.join(parts));public.append(e.name)
            seen.add(e.name)
    assert seen==set(manifest) and len(seen)==receipt['files']
    out={'utc':utc(),'status':'PASS','group':G.name,'archive_sha256':receipt['sha256'],
         'manifest_sha256':receipt['manifest_sha256'],'files_first_verified':len(seen),
         'public_visual_files':public,'NPZ_or_pickle_loaded':False,'private_BLUE_console_read':False}
    p=G/'CLIENT_FIRST_RAW_REVIEW.json';save(p,out);upload(p,RC+'/'+G.name+'/'+p.name)
    print(json.dumps({'first_review':G.name,'files':len(seen)}),flush=True)
def finish(state):
    groups=[]
    for x in state['completed']:
        G=C/(x['version']+'_'+x['cohort']);assert read(G/'CLIENT_FIRST_RAW_REVIEW.json')['status']=='PASS'
        matrix=read(G/'RESULT.json');replay=matrix.get('cohort')=='REPLAY'
        rows=[r for j in matrix['jobs'].values() for r in j['rounds']];n=len(rows)
        terms={'map':sum(.5*r['phase']['score_map'] for r in rows)/n,
               'wall':sum(.2*r['phase']['score_wall'] for r in rows)/n,
               'time':sum(.1*r['phase']['score_time'] for r in rows)/n,
               'difficulty_completion':sum(r['layout_contribution'] for r in rows)/n}
        mean=sum(r['full_score'] for r in rows)/n;assert abs(mean-sum(terms.values()))<1e-7
        groups.append({'group':G.name,'maps':n,'five_map_mean':mean if n==5 else None,
          'single_map_score':mean if n==1 and not replay else None,'fixed_layout_replay_merged_score':mean if replay else None,
          'native_rounds':1 if replay else 2,'fresh_RED_BLUE_pair':not replay,'weighted_terms':terms,
          'placed':sum(r['placed'] for r in rows),'expected':sum(r['expected'] for r in rows)})
    out={'utc':utc(),'status':'PASS','campaign_status':state['status'],'groups':groups,
         'decisions':state['decisions'],'skipped':state['skipped'],
         'native_failure':state['first_native_failure'],'automatic_promotion':False,'starts_native_games':False}
    p=C/'CAMPAIGN_CLIENT_REVIEW.json';save(p,out);upload(p,RC+'/'+p.name)
    print(json.dumps(out,ensure_ascii=False),flush=True)
assert not(C/'LOCAL_COLLECTOR_RESULT.json').exists(),'Already consumed finite collector'
started=time.monotonic()
try:
    while time.monotonic()-started<14*3600:
        s=metadata();save(C/'LOCAL_COLLECTOR_STATUS.json',{'utc':utc(),'server_status':s['status'],'completed':len(s.get('completed',[])),'starts_native_games':False})
        for p in sorted(C.iterdir()):
            if p.is_dir() and(p/'RAW_ARCHIVE_RECEIPT.json').exists():review(p)
        if s['status'] in ['COMPLETE_FINITE_STAGED_CAMPAIGN','STOPPED_FIRST_ERROR_NO_RETRY']:
            metadata();finish(s);save(C/'LOCAL_COLLECTOR_RESULT.json',{'utc':utc(),'status':'COMPLETE','server_status':s['status'],'starts_native_games':False});break
        time.sleep(30)
    else:raise TimeoutError('Finite14h collection window expired')
except Exception as e:
    save(C/'LOCAL_COLLECTOR_RESULT.json',{'utc':utc(),'status':'ERROR','error':repr(e),'starts_native_games':False});traceback.print_exc();raise



