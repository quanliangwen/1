"""Read OS resource counters of this coordinator's descendants only.

No Python stacks, memory contents, game/controller state, sensors or messages.
No priority/affinity/thread changes. Sampling runs outside the evaluator.
"""
from pathlib import Path
import os,threading,time

class ResourceObserver:
    def __init__(self):
        self.stop=threading.Event();self.rows=[];self.errors=[];self.root=os.getpid()
        self.thread=threading.Thread(target=self._loop,daemon=True)
    def start(self):self.thread.start()
    def close(self):self.stop.set();self.thread.join(timeout=3)
    def _descendants(self,pid):
        try:children=(Path('/proc')/str(pid)/'task'/str(pid)/'children').read_text().split()
        except (FileNotFoundError,PermissionError,ProcessLookupError):return []
        result=[]
        for child in children:result.append(int(child));result+=self._descendants(int(child))
        return result
    def _loop(self):
        while not self.stop.is_set():
            stamp=time.time()
            for pid in self._descendants(self.root):
                p=Path('/proc')/str(pid)
                try:
                    raw=(p/'stat').read_text();parts=raw[raw.rfind(')')+2:].split()
                    args=(p/'cmdline').read_bytes().decode(errors='replace').split('\0')
                    mode=args[args.index('--mode')+1] if '--mode' in args else None
                    evaluator=bool(args and Path(args[0]).name.startswith('python') and any(x.endswith('/postscore_visual_evaluator_v2.py') for x in args[:6]))
                    sched=(p/'schedstat').read_text().split()
                    status=(p/'status').read_text().splitlines()
                    get=lambda key:next((x.split(':',1)[1].strip() for x in status if x.startswith(key+':')),None)
                    self.rows.append(dict(unix_time=stamp,pid=pid,start_ticks=int(parts[19]),
                        command=raw[raw.find('(')+1:raw.rfind(')')],mode=mode,is_evaluator=evaluator,
                        utime_ticks=int(parts[11]),stime_ticks=int(parts[12]),
                        main_run_ns=int(sched[0]),main_runqueue_wait_ns=int(sched[1]),main_timeslices=int(sched[2]),
                        threads=get('Threads'),cpus_allowed=get('Cpus_allowed_list'),rss_kb=get('VmRSS')))
                except (FileNotFoundError,PermissionError,ProcessLookupError):pass
                except Exception as e:self.errors.append(dict(unix_time=stamp,error=repr(e),pid=pid))
            self.stop.wait(1.)
    def review(self,start,end):
        rows=[x for x in self.rows if start<=x['unix_time']<=end]
        keys={(x['pid'],x['start_ticks']) for x in rows if x['is_evaluator']};processes=[]
        hz=os.sysconf('SC_CLK_TCK')
        for key in sorted(keys):
            xs=[x for x in rows if (x['pid'],x['start_ticks'])==key]
            processes.append(dict(pid=key[0],start_ticks=key[1],mode=xs[0]['mode'],samples=len(xs),
                observed_span_seconds=xs[-1]['unix_time']-xs[0]['unix_time'],
                maximum_observed_process_cpu_seconds=max(x['utime_ticks']+x['stime_ticks'] for x in xs)/hz,
                maximum_observed_main_runqueue_wait_seconds=max(x['main_runqueue_wait_ns'] for x in xs)/1e9,
                maximum_observed_main_run_seconds=max(x['main_run_ns'] for x in xs)/1e9,
                maximum_threads=max(int(x['threads']) for x in xs if x['threads']),
                cpus_allowed=sorted({x['cpus_allowed'] for x in xs})))
        return dict(status='COMPLETE_EXTERNAL_OS_COUNTER_REVIEW',evaluator_processes=processes,rows=rows,errors=self.errors,
            controller_private_state_read=False,priority_affinity_or_threads_changed=False,
            limitations='One-second sampling can miss terminal CPU ticks. CPU is all process threads; runqueue wait is main thread only. Sampling includes evaluator setup/export outside the official GUI clock. Not an exact per-function CPU profile or proof of load causation.')
