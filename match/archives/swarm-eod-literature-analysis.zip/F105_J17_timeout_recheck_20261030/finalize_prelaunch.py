from pathlib import Path
import hashlib,importlib.util,json,sys
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F105_J17_timeout_recheck_20261030'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (F/'RUN_ONCE.json').exists()
d=read(F/'PREDECLARATION.json');q=read(F/'J17/RESEARCH_QUALIFICATION.json');b=read(F/'J17/BUILD.json')
assert q['status']=='PASS' and q['zip_sha256']==b['zip_sha256']=='652b59edbfba68aa5b163b2cbdc904ebecdbe75927073e3a59168013e725a839'
assert q['target_public_configuration']==dict(map='Map01',timestep_limit=2000,walltime_limit=90.,size=[1250,800])
sys.path.insert(0,str(Path(d['blue_binding']['blue_workspace'])/'src'))
from swarm_rescue.simulation.reporting.place_score_manager import PlaceScoreManager,PlacePhase1Result,ReferenceBlueRun
red=read(Path(d['fixed_input']['red_summary']))['rounds'][0];blue=read(Path(d['fixed_input']['original_blue_summary']))['rounds'][0]
m=PlaceScoreManager();ref=ReferenceBlueRun(zip_name=d['blue_binding']['opponent_id'],blue_score=blue['blue_score'],difficulty=blue['difficulty'],has_crashed=False,success=True)
bomb=m.compute_bomb_score([ref],placed_count=red['placed'],expected_count=red['expected']);score=m.merge_final_score(PlacePhase1Result(**red['phase']),bomb).round_score
assert abs(score-d['fixed_input']['original_full_score'])<1e-9
receipt=dict(status='PASS_PRELAUNCH_ORIGINAL_J17_BINDING_AND_SCORE_MERGE',zip_sha256=b['zip_sha256'],original_full_score=score,
    native_rounds_started=0,SDK_BLUE_limits_threads_resource_conditions_changed=False,
    resource_observer='Filters shell wrappers out of evaluator-process counts; reads OS counters only, no controller state.')
(F/'PRELAUNCH_CHECK.json').write_text(json.dumps(receipt,indent=2)+'\n')
(F/'PREDECLARATION_DRAFT_BEFORE_QUALIFICATION.json').write_bytes((F/'PREDECLARATION.json').read_bytes())
for p in [F/'os_resource_observer.py',F/'J17/RESEARCH_QUALIFICATION.json',F/'PRELAUNCH_CHECK.json']:d['frozen_files'][str(p)]=sha(p)
d['prelaunch_declaration_revision']='Bound fresh read-only ABI/entry check; narrowed observer identity to actual Python evaluators; no evaluation condition or game-code changes.'
(F/'PREDECLARATION.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt))
