from pathlib import Path
import ast,hashlib,json
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
F=H/'F105_J17_timeout_recheck_20261030';P=H/'F85_public_boundary_submission_pilot_20261030'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
assert not (F/'PREDECLARATION.json').exists()
assert read(P/'CAMPAIGN_CLIENT_REVIEW.json')['status']=='PASS'
parent=read(P/'PREDECLARATION.json');oldroot=Path(read(P/'J17_DIAG/LAUNCH.json')['result'])
red=oldroot/'Map01_red/summary.json';bombs=oldroot/'Map01_red/round1_bombs.json';blue=oldroot/'Map01_blue_rd1/summary.json'
row=read(red)['rounds'][0];original=read(blue)['rounds'][0]
assert row['placed']==row['expected']==10 and original['max_walltime_reached'] and original['walltime_limit']==90 and original['timestep']==1900
C=F/'J17';assert not C.exists();C.mkdir();save(C/'BUILD.json',read(P/'J17/BUILD.json'))
q=(P/'qualify_candidate.py').read_text().replace(P.name,F.name)
(F/'qualify_candidate.py').write_text(q)
for p in [F/'run_offline.py',F/'os_resource_observer.py',F/'qualify_candidate.py']:ast.parse(p.read_text())
launch=(H/'F100_raster_boundary_pilot_20261030/launch_campaign.py').read_text().replace('F100_raster_boundary_pilot_20261030',F.name)
launch=launch.replace('max_native_rounds=2','max_native_rounds=3').replace("first_stage='Two original capacity samples then Map05 RED and BLUE'","first_stage='Original gate then fixed J17 layout BLUE replay, Windows review, then one fresh Map01 J17 RED+BLUE pair'")
(F/'launch_campaign.py').write_text(launch)
d={k:parent[k] for k in ['sdk_commit','sdk_files','blue_binding','blue_binding_sha256','resource_gate','frozen_files']}
d.update(phase=F.name,selection=['J17'],maps=['Map01'],seed=None,versions=parent['versions'],optimizer=parent['optimizer'],
 explicit_human_authorization='将J17的89.8194涉及蓝队墙钟超时这个问题修复一下，重新跑看看结果',
 no_repeat_exception_scope='This explicit request authorizes this one frozen-layout BLUE replay and one fresh original-condition Map01 RED+BLUE pair. Prior data retained, all new outcomes reported, no best-only selection, further retries/five maps not authorized here.',
 schedule=[dict(version='J17',cohort='REPLAY',native_rounds=1,fixed_RED=True),dict(version='J17',cohort='FRESH',native_rounds=2,fixed_RED=False)],
 min_native_rounds=1,max_native_rounds=3,automatic_five_maps=False,automatic_promotion=False,
 fixed_input=dict(bombs=str(bombs),bombs_sha256=sha(bombs),red_summary=str(red),red_summary_sha256=sha(red),
    original_blue_summary=str(blue),original_blue_summary_sha256=sha(blue),original_full_score=89.81942520793855),
 unchanged_conditions=dict(SDK=True,BLUE=True,RED_payload=True,walltime90=True,timestep2000=True,threads=True,resources=True,seed_not_set=True),
 observations='One-second external descendant-only /proc CPU/main-runqueue counters. No stacks, memory/controller/sensor state, priority/affinity/thread changes. Public rendering happens after GUI loop in frozen evaluator.',
 purpose='Distinguish normal BLUE clock exhaustion from host/extra evaluator overhead, and check fixed-layout versus fresh J17 reproducibility. No false RED fix is invented.',
 original_resource_sample=read(P/'STATUS.json').get('resource'),
 limitations='No old-process CPU counters remain. New resource counters include setup/export and are sampled lower bounds, not exact per-function profiling. Fixed replay combines historical frozen RED phase with new BLUE score and cannot be ranked as a new five-map algorithm result.')
v=F/'versions/J17';v.mkdir(parents=True);save(v/'QUALIFICATION.json',read(P/'versions/J17/QUALIFICATION.json'))
for p in [F/'run_offline.py',F/'os_resource_observer.py',red,bombs,blue]:d['frozen_files'][str(p)]=sha(p)
save(F/'PREDECLARATION.json',d)
print(json.dumps(dict(status='PREPARED_NOT_STARTED',max_native_rounds=3,RED_code_unchanged=True,old_BLUE=dict(timestep=1900,walltime=90),zip_sha256=read(C/'BUILD.json')['zip_sha256'])))
