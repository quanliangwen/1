"""Explicitly human-authorized J17 reproducibility study; maximum3 native runs."""
from pathlib import Path
import fcntl,importlib.util,json,math,os,subprocess,tarfile,time,traceback
from os_resource_observer import ResourceObserver
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F105_J17_timeout_recheck_20261030'
read=lambda p:json.loads(p.read_text())
spec=importlib.util.spec_from_file_location('frozen_runner',H/'F32_official_sdk_20261028/FIVE_MAP_REBASELINE/run_offline.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.F,b.D=F,read(F/'PREDECLARATION.json');b.NAMES,b.BLUE=b.D['selection'],b.D['blue_binding'];b.WBLUE=Path(b.BLUE['blue_workspace'])
b.STATE.update(phase=F.name,decisions=[],max_native_rounds=3,diagnostic_only=True,explicit_authorized_repeat=True)
old_state=b.state
def state(status,**kw):old_state('RUNNING_J17_FRESH_PAIR' if status=='RUNNING_FIVE_MAPS' else status,**kw)
b.state=state
def summarize():b.save(F/'RESULT.json',dict(b.STATE,automatic_promotion=False,automatic_five_maps=False,official_submission_ready=False))
b.summarize=summarize
def review_once(cohort):
    p=F/('J17_'+cohort)/'CLIENT_FIRST_RAW_REVIEW.json';start=time.monotonic()
    while not p.exists():
        if b.stop_requested():raise RuntimeError('Human stop before next stage')
        if time.monotonic()-start>7200:raise TimeoutError('Windows first-byte review timeout')
        state('AWAIT_FIRST_WINDOWS_REVIEW',current=dict(version='J17',cohort=cohort));time.sleep(5)
    assert read(p)['status']=='PASS' and read(p)['archive_sha256']==read(p.parent/'RAW_ARCHIVE_RECEIPT.json')['sha256']
def archive_result(G,result):
    raw={str(p.relative_to(result)):dict(sha256=b.sha(p),bytes=p.stat().st_size) for p in sorted(result.rglob('*')) if p.is_file()}
    b.save(G/'RAW_SHA256.json',raw);archive=G/'raw_results.tar.gz'
    with tarfile.open(archive,'x:gz',compresslevel=1) as tar:
        for n in raw:tar.add(result/n,arcname=n,recursive=False)
    receipt=dict(utc=b.utc(),archive=str(archive),sha256=b.sha(archive),manifest_sha256=b.sha(G/'RAW_SHA256.json'),files=len(raw),first_windows_review_pending=True,raw_arrays_loaded=0)
    b.save(G/'RAW_ARCHIVE_RECEIPT.json',receipt);return receipt
def replay(observer):
    lock=b.acquire_when_ready()
    if lock is None:return False
    G=F/'J17_REPLAY';item=dict(version='J17',cohort='REPLAY',label='sdk_e2f022b_f105_J17_FIXED_LAYOUT')
    result=R/'results/target90_20261012'/('unseeded_'+item['label']);active=False
    try:
        b.validate_frozen();assert not G.exists() and not result.exists();G.mkdir();result.mkdir()
        inp=b.D['fixed_input'];oldrow=read(Path(inp['red_summary']))['rounds'][0]
        public_input=result/'Map01_red';public_input.mkdir()
        for key,name in [('bombs','round1_bombs.json'),('red_summary','summary.json')]:
            source=Path(inp[key]);assert b.sha(source)==inp[key+'_sha256'];(public_input/name).write_bytes(source.read_bytes())
        out=result/'Map01_blue_rd1';out.mkdir()
        evaluator=Path(b.BLUE['worker']).parent/'postscore_visual_evaluator_v2.py'
        command=['bash',str(R/'run_server.sh'),'-u',str(evaluator),'--workspace',str(b.WBLUE),'--map','Map01','--mode','rescue','--out',str(out),'--rounds','1','--bombs',str(public_input/'round1_bombs.json')]
        started=time.time()
        with (out/'console.log').open('x') as log:
            process=subprocess.Popen(command,cwd=R,env=b.ENV,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            b.activity_on(item,{'Map01':process});active=True
            b.save(G/'LAUNCH.json',dict(utc=b.utc(),result=str(result),worker_pids={'Map01':process.pid},command=command,native_rounds=1,fixed_RED_input=True))
            state('RUNNING_J17_FIXED_LAYOUT_BLUE',current=item)
            code=process.wait()
        ended=time.time();b.activity_off();active=False
        resources=observer.review(started,ended);b.save(G/'OS_RESOURCE_REVIEW.json',resources)
        summary=read(out/'summary.json') if (out/'summary.json').exists() else None
        valid=code==0 and summary and not summary['rounds'][0]['crashed']
        if not valid:
            b.STATE['first_native_failure']=True
            failure=dict(utc=b.utc(),complete=False,label=item['label'],version='J17',cohort='REPLAY',native_rounds=1,
                jobs=dict(Map01=dict(status='blue_failed',rounds=[])),returncode=code,fixed_input=inp,raw_arrays_loaded=0)
            b.save(result/'matrix_status.json',failure);b.save(G/'RESULT.json',failure);archive_result(G,result)
            b.save(F/'FIRST_NATIVE_ERROR.json',dict(utc=b.utc(),group=item,returncode=code,no_retry=True));raise RuntimeError('Fixed-layout BLUE native failure')
        assert summary['controller_sha256']==b.BLUE_CONTROLLER_SHA and summary['seed'] is None and summary['competition_mode'] and not summary['framework_runtime_patched']
        blue=summary['rounds'][0];assert blue['walltime_limit']==90 and blue['timestep_limit']==2000
        import sys
        sys.path.insert(0,str(b.WBLUE/'src'))
        from swarm_rescue.simulation.reporting.place_score_manager import PlaceScoreManager,PlacePhase1Result,ReferenceBlueRun
        manager=PlaceScoreManager();reference=ReferenceBlueRun(zip_name=b.BLUE['opponent_id'],blue_score=blue['blue_score'],difficulty=blue['difficulty'],has_crashed=False,success=True)
        bomb=manager.compute_bomb_score([reference],placed_count=oldrow['placed'],expected_count=oldrow['expected']);merged=manager.merge_final_score(PlacePhase1Result(**oldrow['phase']),bomb)
        row=dict(round=1,phase=oldrow['phase'],blue=dict(blue,controller_sha256=b.BLUE_CONTROLLER_SHA),placed=oldrow['placed'],expected=oldrow['expected'],
            full_score=merged.round_score,layout_contribution=manager.config.w_bomb*bomb.score,red_walltime=oldrow['walltime'],red_walltime_limit=oldrow['walltime_limit'],red_steps=oldrow['timestep'],red_max_walltime_reached=oldrow['max_walltime_reached'],red_reused_not_newly_run=True)
        matrix=dict(utc=b.utc(),complete=True,label=item['label'],version='J17',cohort='REPLAY',seed=None,
            jobs=dict(Map01=dict(status='complete',rounds=[row])),blue_opponent=b.BLUE['opponent_id'],native_rounds=1,
            score_kind='Historical frozen RED phase plus new BLUE evaluation on identical public initial layout; not a fresh RED generation or five-map ranking',
            fixed_input=inp,payload_unchanged=True,raw_arrays_loaded=0)
        b.save(result/'matrix_status.json',matrix);b.save(G/'RESULT.json',matrix);receipt=archive_result(G,result)
        b.STATE['completed'].append(dict(**item,mean=merged.round_score,map_scores=dict(Map01=merged.round_score),raw_archive=receipt,placed=dict(Map01=oldrow['placed']),native_rounds=1,fixed_red_replay=True))
        state('COHORT_COMPLETE',current=None);summarize();b.validate_frozen();return True
    finally:
        if active:b.activity_off()
        lock.close()
def main():
    lease=(F/'coordinator.lock').open('a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);assert not (F/'RUN_ONCE.json').exists()
    b.save(F/'RUN_ONCE.json',dict(utc=b.utc(),pid=os.getpid(),starttime_ticks=Path('/proc/self/stat').read_text().split()[21],driver_sha256=b.sha(__file__),study_sha256=b.sha(F/'PREDECLARATION.json'),explicit_human_repeat=True))
    b.STATE['started_utc']=b.utc();b.validate_frozen();summarize();observer=ResourceObserver();observer.start()
    try:
        if not replay(observer):state('STOPPED_BEFORE_NATIVE_START');summarize();return
        review_once('REPLAY')
        if b.stop_requested():state('STOPPED_BEFORE_FRESH_PAIR');summarize();return
        started=time.time()
        if not b.run_cohort(dict(version='J17',cohort='FRESH',label='sdk_e2f022b_f105_J17_FRESH_EXPLICIT_REPEAT')):
            state('STOPPED_BEFORE_FRESH_PAIR');summarize();return
        b.save(F/'J17_FRESH/OS_RESOURCE_REVIEW.json',observer.review(started,time.time()))
        review_once('FRESH')
        b.STATE['decisions'].append(dict(decision='ANALYZE_ALL_J17_RECHECKS_NO_BEST_ONLY_SELECTION',repeat_authorization='Latest explicit human request',native_rounds=3))
        state('COMPLETE_FINITE_STAGED_CAMPAIGN',current=None);summarize()
    except Exception:
        b.save(F/'FIRST_ERROR.json',dict(utc=b.utc(),traceback=traceback.format_exc(),first_native_failure=b.STATE['first_native_failure'],no_automatic_retry=True));state('STOPPED_FIRST_ERROR_NO_RETRY');summarize();raise
    finally:observer.close()
if __name__=='__main__':main()
