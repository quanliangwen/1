from pathlib import Path
import sys,json,types,traceback,hashlib,time
Q=Path(__file__).resolve().parent;W=Q/'workspace';F=Q.parent
report={'status':'STARTED','checks':[],'game_rounds':0}
def check(n,x):
    assert x,n
    report['checks'].append(n)
try:
    sys.path.insert(0,str(W/'src'))
    import numpy as np,cv2,pandas
    import swarm_rescue.solutions.trust_region_cover as current
    from swarm_rescue.solutions.greedy_mapping import MapMemory
    from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
    from swarm_rescue.solutions.active_coverage import ActiveCoverageMixin
    from swarm_rescue.solutions.diagnostic_mixin import DiagnosticMixin
    from swarm_rescue.solutions.my_drone_eval import MyDroneEval,BaseParent
    from swarm_rescue.simulation.reporting.team_info import TeamInfo
    from swarm_rescue.launcher import Launcher
    from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
    import numpy.random.mtrand
    parent=json.loads((F/'PREDECLARATION.json').read_text())['parent']
    original=types.ModuleType('original_refiner_reference')
    source=Path(parent['path'])/'source/trust_region_cover.py'
    exec(compile(source.read_text(),str(source),'exec'),original.__dict__)
    check('actual_observer_payload',Path(current.__file__).resolve()==(W/'src/swarm_rescue/solutions/trust_region_cover.py').resolve())
    check('underlying_factory_placement_unchanged',next(c.__name__ for c in BaseParent.__mro__ if '_maybe_place' in c.__dict__)=='ActiveCoverageMixin')
    check('observer_factory_selected',next(c.__name__ for c in MyDroneEval.__mro__ if '_maybe_place' in c.__dict__)=='DiagnosticMixin')
    check('numeric_team615',type(TeamInfo().team_number) is int and TeamInfo().team_number==615)
    check('native_runtime_unchanged',(np.__version__,pandas.__version__,cv2.__version__)==('1.26.4','3.0.6','4.11.0'))
    check('real_mtrand_operation',np.isfinite(np.random.RandomState(615).normal(size=8)).all())
    def fixture(single=True,enabled=False,budget=None,transport=False):
        m=MapMemory(256,128);m.free[:]=True;m.identifier=0;m.step=1000;m._f13_layout_enabled=enabled
        pm=GeometryPlanningMemory(m);values=np.zeros(m.shape,np.float32)
        allowed=np.zeros(m.shape,bool)
        if transport:
            values[1,8]=1.;radius=64.;old={7:[m.cell_to_world((3,10))]};agents={7:(m.cell_to_world((4,8)),1)}
            allowed[3,10]=True;allowed[3,6]=True;budget={7:64.}
            m.nonwall_mask=np.zeros(m.hit_shape,bool);m.nonwall_mask[4*8:5*8,14*8:15*8]=True
        else:
            for col,weight in [(9,1.),(11,1.),(15,2. if single else 1.)]:values[3,col]=weight
            radius=32.;old={2:[m.cell_to_world((3,8))],7:[m.cell_to_world((3,12))]};agents={k:(ps[0].copy(),1) for k,ps in old.items()}
            for col in [8,10,12,14]:allowed[3,col]=True
            budget={2:32.,7:32.} if budget is None else budget
        pm._coverage_values_cache=(radius,values,np.zeros(m.shape,bool))
        return m,pm,{'memory':m,'agents':agents,'drops':[],'radius':radius,'base':old,'travel_budget':budget,'forbidden_mask':~allowed,'_prepared':pm}
    for name,settings in [('disabled',{}),('single_enabled',{'enabled':True}),('joint_fallback_enabled',{'single':False,'enabled':True}),
                          ('owner_budget',{'enabled':True,'budget':{2:0.,7:32.}}),('transport_enabled',{'enabled':True,'transport':True})]:
        ma,pa,a=fixture(**settings);mb,pb,b=fixture(**settings)
        ra=original.refine_trust_region(**a);rb=current.refine_trust_region(**b)
        check('original_result_preserved_'+name,ra.keys()==rb.keys() and all(len(ra[k])==len(rb[k]) and all(np.array_equal(x,y) for x,y in zip(ra[k],rb[k])) for k in ra))
        check('original_diagnostics_preserved_'+name,ma.trust_region_diagnostics==mb.trust_region_diagnostics)
        check('original_arrays_preserved_'+name,all(np.array_equal(getattr(ma,k),getattr(mb,k)) for k in ['hits','free','visits']))
        check('temporary_live_snapshot_removed_'+name,'_f13_live_prepared' not in vars(mb))
        if name=='single_enabled':check('live_joint_probe_executed',getattr(mb,'_f13_joint_done',False))
        if name=='transport_enabled':check('live_transport_probe_executed',getattr(mb,'_f13_transport_done',False))
    class Parent:
        _maybe_place=ActiveCoverageMixin._maybe_place
    class Probe(DiagnosticMixin,Parent):
        F13_MODE='LATE'
    def drop_fixture(cls,name):
        d=object.__new__(cls);d.memory=MapMemory(256,128);d.memory.free[:]=True;d.pose=np.zeros(2);d.heading=0.;d.identifier=0
        d.carried_bombs_count=lambda:1;d.submitted=False;d.pending_drop=None;d.last_attempt_step=-100;d.placement_goal=None
        d.placement_arrival_radius=20.;d._placement_allowed=lambda step,semantic:True;d._remaining_steps=lambda:80.
        d.elapsed_walltime=171.;d.walltime_limit=180.;d.limit=5000;d.PLAN_START_RATIO=.1;d._step_seconds=.1
        d._placement_spacing=lambda step:30.;d._placement_forbidden_mask=lambda:None;d._known_bomb_positions=lambda semantic:[np.zeros(2)]
        d._other_live_placement_goals=lambda step:[];d.centre_surface_records={};d._diag_costs={};d._f13_control_started=time.perf_counter()
        if name=='near':d.placement_goal=np.array([4.,0.])
        if name=='far':d.placement_goal=np.array([200.,0.])
        if name=='illegal':d._placement_allowed=lambda step,semantic:False
        if name=='pending':d.pending_drop=(1,d.pose.copy(),2099)
        if name=='empty':d.carried_bombs_count=lambda:0
        if name=='submitted':d.submitted=True
        if name=='retry':d.last_attempt_step=2099
        return d
    for name in ['none','near','far','illegal','pending','empty','submitted','retry']:
        a=drop_fixture(Parent,name);b=drop_fixture(Probe,name);ca={};cb={}
        a._maybe_place(ca,2100,[]);b._maybe_place(cb,2100,[])
        check('original_command_preserved_'+name,ca==cb)
        check('original_goal_preserved_'+name,(a.placement_goal is None and b.placement_goal is None) or np.array_equal(a.placement_goal,b.placement_goal))
    binding=json.loads((Q/'SOURCE_BINDING.json').read_text())
    report.update(status='PASS',count=len(report['checks']),source_files=binding['observer_source_files'],
        scope='Actual diagnostic factory/native ABI + numerical plan/counter/command equivalence with advisors enabled. Additional diagnostic computation affects wallclock; no game/candidate/history input.')
except BaseException:
    report.update(status='FAIL',error=traceback.format_exc());raise
finally:
    (Q/'FIRST_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
