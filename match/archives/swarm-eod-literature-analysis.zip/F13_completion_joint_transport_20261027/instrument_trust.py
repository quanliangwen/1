import ast
import copy


def instrument(text):
    tree=ast.parse(text)
    original=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='refine_trust_region')
    before=copy.deepcopy(original)
    marker='    pm=GeometryPlanningMemory(memory) if _prepared is None else _prepared\n'
    assert text.count(marker)==1
    text=text.replace(marker,marker+"    if getattr(memory,'_f13_layout_enabled',False): memory._f13_live_prepared=pm\n")
    updated=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='refine_trust_region')
    position=next(i for i,n in enumerate(updated.body) if isinstance(n,ast.If)
                  and any(isinstance(x,ast.Attribute) and x.attr=='_f13_live_prepared' for x in ast.walk(n)))
    updated.body.pop(position)
    assert ast.dump(updated)==ast.dump(before)
    text+='''

_f13_original_refine = refine_trust_region
def refine_trust_region(*args, **kwargs):
    memory = args[0] if args else kwargs['memory']
    if not getattr(memory, '_f13_layout_enabled', False):
        return _f13_original_refine(*args, **kwargs)
    try:
        result = _f13_original_refine(*args, **kwargs)
        prepared = getattr(memory, '_f13_live_prepared', kwargs.get('_prepared'))
        from swarm_rescue.solutions.diagnostic_layout_advisors import observe_refinement
        observe_refinement(_f13_original_refine, args, kwargs, result, prepared)
        return result
    finally:
        if '_f13_live_prepared' in vars(memory):
            delattr(memory, '_f13_live_prepared')
'''
    ast.parse(text)
    return text
