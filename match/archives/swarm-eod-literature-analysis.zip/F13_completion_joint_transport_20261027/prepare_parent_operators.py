from pathlib import Path
import json,base64,ast,hashlib,subprocess,shlex
F=Path(__file__).resolve().parent;OLD=F.parent/'F12_kernel_drop_terminal_20261027'
assert not(F/'PARENT_OPERATORS.json').exists()
bundle={}
for name,e in json.loads((OLD/'PARENT_OPERATORS.json').read_text()).items():
 s=base64.b64decode(e['runner_base64']).decode().replace('F12','F13')
 s=s.replace("'F13_LATE_DROP_ADVISOR','F13_TERMINAL_ADVISOR'","'F13_LATE_COMPLETION_ADVISOR','F13_LAYOUT_ADVISOR'")
 ast.parse(s);bundle[name]={'runner_base64':base64.b64encode(s.encode()).decode(),'sha256':hashlib.sha256(s.encode()).hexdigest(),'map':e['map']}
maps={'PARENT_M05_DIAG':'Map05','PARENT_M04_DIAG':'Map04','N01_DIAG':'Map05','N02_DIAG':'Map04','N03_DIAG':'Map04'}
for n,d in [('PARENT_OPERATORS.json',bundle),('DIAGNOSTIC_MAP_BINDINGS.json',maps)]:
 (F/n).write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
for n in ['sync_metadata.py','verify_diagnostic_raw.py']:
 s=(OLD/n).read_text().replace('F12_kernel_drop_terminal_20261027',F.name)
 if n=='verify_diagnostic_raw.py':s=s.replace("['PARENT_M04_DIAG', 'PARENT_M05_DIAG', 'M01_DIAG', 'M02_DIAG', 'M03_DIAG']",repr(list(maps)))
 ast.parse(s);(F/n).write_text(s,encoding='utf-8')
s=(OLD/'stage_parent_observer.py').read_text().replace('F12_kernel_drop_terminal_20261027',F.name).replace('f12diag_','f13diag_').replace("F/'observer_preparation'","F/'observer_qualification'").replace("O/'QUALIFICATION_RESULT.json'","O/'FIRST_RESULT.json'").replace("binding['observer_files']","binding['observer_source_files']")
s=s.replace("if name=='PARENT_M05':","if name=='PARENT_M04':").replace("G0=F/'PARENT_M04_DIAG'","G0=F/'PARENT_M05_DIAG'").replace("s['status']=='PARENT_M04_DIAGNOSTIC_COMPLETE_AWAIT_ANALYSIS'","s['status']=='PARENT_M05_DIAGNOSTIC_COMPLETE_AWAIT_ANALYSIS'")
s=s.replace("G.mkdir();S=G/'source';shutil.copytree(O/'source',S)","G.mkdir();S=G/'source';shutil.copytree(O/'source',S)\nmode='LATE' if m=='Map05' else 'LAYOUT'\np=S/'my_drone_eval.py';s=p.read_text();assert s.count(\"F13_MODE='LAYOUT'\")==1;p.write_text(s.replace(\"F13_MODE='LAYOUT'\",\"F13_MODE=\"+repr(mode)))")
s=s.replace('Counters plus explicitly declared bounded readonly late legality/terminal advisors','Counters plus explicitly declared bounded readonly nearby-completion/joint/transport advisors')
ast.parse(s);(F/'stage_parent_observer.py').write_text(s,encoding='utf-8')
remote=r'''
from pathlib import Path
import json,sys
F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F13_completion_joint_transport_20261027')
d=json.load(sys.stdin)
assert json.loads((F/'observer_qualification/FIRST_RESULT.json').read_text())['status']=='PASS'
for n,v in d.items():
 assert not(F/n).exists();(F/n).write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps({'prepared':list(d),'no_native_started':True}))
'''
print(subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(remote)],input=json.dumps({'PARENT_OPERATORS.json':bundle,'DIAGNOSTIC_MAP_BINDINGS.json':maps}).encode()).decode())
