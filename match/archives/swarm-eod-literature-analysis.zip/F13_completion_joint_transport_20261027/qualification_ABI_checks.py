    from swarm_rescue.simulation.reporting.team_info import TeamInfo
    from swarm_rescue.launcher import Launcher
    from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
    import numpy.random.mtrand,importlib.metadata
    check('numeric_team615',type(TeamInfo().team_number) is int and TeamInfo().team_number==615)
    check('pinned_ABI_distributions',{n:importlib.metadata.version(n) for n in ['numpy','pandas','opencv-contrib-python']}=={'numpy':'1.26.4','pandas':'2.2.3','opencv-contrib-python':'4.11.0.86'})
    check('actual_mtrand_operation',np.isfinite(np.random.RandomState(615).normal(size=8)).all())
    check('actual_pandas_operation',pandas.DataFrame({'x':[1,2,3]})['x'].sum()==6)
