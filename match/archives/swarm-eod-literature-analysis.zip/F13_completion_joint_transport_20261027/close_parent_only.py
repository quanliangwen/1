from pathlib import Path
import json,subprocess,shlex
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import json,datetime,fcntl,sys
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F13_completion_joint_transport_20261027'
assert not(F/'DIRECTION_ADMISSION.json').exists() and not(F/'FIRST_NATIVE_ERROR.json').exists()
a=json.loads((R/'solver_study/heuristic_20261016.json').read_text());assert not a.get('active_processes') and not a.get('current_formal_active')
lock=(R/'solver_study/serial_evaluation.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
gates={};counts={}
for name in ['PARENT_M05_DIAG','PARENT_M04_DIAG']:
 G=F/name;s=json.loads((G/'STATUS.json').read_text());p=Path('/proc')/str(s['pid'])/'stat';assert not p.exists() or p.read_text().split()[2]=='Z'
 assert s['status'].endswith('DIAGNOSTIC_COMPLETE_AWAIT_ANALYSIS')
 c=json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text());assert c['valid'];counts[name]=c['raw_files_verified']
 gates.update(json.loads((G/'ANALYSIS.json').read_text())['gates'])
assert gates=={'N01':False,'N02':False,'N03':False}
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'admitted_order':[],'gates':gates,'reason':'Declared fresh diagnostics had no qualifying opportunity. Defer all three without production source or five-map version. Not a universal impossibility result.','no_candidates_created':True,'parent_retained':'K01','RED_only_rounds':2,'five_map_groups':0,'raw_first_verified':counts,'native_failures':0}
(F/'DIRECTION_ADMISSION.json').write_text(json.dumps(d,indent=2)+'\n')
state={**d,'status':'CLOSED_ALL_THREE_DEFERRED_NO_QUALIFIED_OPPORTUNITY','pid':None};(F/'STATUS.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(state))
'''
p=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)])
assert not(F/'FINAL_RESULT.json').exists();(F/'FINAL_RESULT.json').write_bytes(p);print(p.decode())
