from pathlib import Path
import sys,json,traceback,types,datetime
Q=Path(__file__).resolve().parent
report={'status':'STARTED','checks':[],'game_rounds':0}
def check(name,condition):
    assert condition,name
    report['checks'].append(name)
try:
    sys.path.insert(0,str(Q/'reference_workspace/src'))
    sys.path.insert(0,str(Q/'helper_source'))
    import numpy as np
    from swarm_rescue.solutions.greedy_mapping import MapMemory
    from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
    from swarm_rescue.solutions import trust_region_cover as trust
    import diagnostic_late_completion as late
    import diagnostic_layout_advisors as layout

    def late_fixture():
        m=MapMemory(256,128);m.free[:]=True
        return types.SimpleNamespace(memory=m,pose=np.zeros(2),heading=0.,submitted=False,pending_drop=None,
            carried_bombs_count=lambda:1,placement_goal=None,PLAN_START_RATIO=.1,limit=7200,
            _remaining_steps=lambda:80.,_placement_spacing=lambda step:30.,
            _placement_forbidden_mask=lambda:None,_known_bomb_positions=lambda semantic:[np.zeros(2)],
            _other_live_placement_goals=lambda step:[],centre_surface_records={},_step_seconds=.1)
    d=late_fixture();before={k:getattr(d.memory,k).copy() for k in ['hits','free','visits']}
    route,audit=late.nearby_completion(d,2000,[],seconds=5.)
    check('late_positive_known_relocation',route is not None and audit['reason']=='positive_known_legal_relocation')
    check('late_spacing_margin',np.linalg.norm(audit['target'])>=30.+.71*d.memory.CELL-1e-6)
    check('late_full_execution_guard',audit['conservative_steps']<=audit['remaining_after_own_compute'] and audit['conservative_steps']<=80.)
    check('late_original_goal_command_unmodified',d.placement_goal is None and d.pending_drop is None and not d.submitted)
    check('late_own_arrays_unmodified',all(np.array_equal(getattr(d.memory,k),v) for k,v in before.items()))
    for name in ['no_free','all_forbidden','pending','submitted','no_stock','already_targeted','too_late','too_early','before_phase','no_time','blocked_corner']:
        d=late_fixture();seconds=5.
        if name=='no_free':d.memory.free[:]=False
        if name=='all_forbidden':d._placement_forbidden_mask=lambda:np.ones(d.memory.shape,bool)
        if name=='pending':d.pending_drop=(1,np.zeros(2),1999)
        if name=='submitted':d.submitted=True
        if name=='no_stock':d.carried_bombs_count=lambda:0
        if name=='already_targeted':d.placement_goal=np.array([64.,0.])
        if name=='too_late':d._remaining_steps=lambda:23.
        if name=='too_early':d._remaining_steps=lambda:121.
        if name=='no_time':seconds=0.
        if name=='blocked_corner':
            d.memory.free[:]=False
            for cell in [(4,8),(3,9),(2,10)]:d.memory.free[cell]=True
        step=10 if name=='before_phase' else 2000
        r,a=late.nearby_completion(d,step,[],seconds=seconds)
        check('late_abstains_'+name,r is None)
    d=late_fixture();d._other_live_placement_goals=lambda step:[np.array(audit['target'])]
    r,a=late.nearby_completion(d,2000,[],seconds=5.)
    check('late_received_reservation_preserved',r is None or np.linalg.norm(np.asarray(a['target'])-np.asarray(audit['target']))>=40.+.71*d.memory.CELL-1e-6)

    def joint_fixture(budget=None):
        m=MapMemory(256,128);m.free[:]=True;pm=GeometryPlanningMemory(m)
        values=np.zeros(m.shape,np.float32)
        for col,weight in [(9,1.),(11,1.),(15,2.)]:values[3,col]=weight
        pm._coverage_values_cache=(32.,values,np.zeros(m.shape,bool))
        allowed=np.zeros(m.shape,bool)
        for col in [8,10,12,14]:allowed[3,col]=True
        base={2:[m.cell_to_world((3,8))],7:[m.cell_to_world((3,12))]}
        agents={k:(ps[0].copy(),1) for k,ps in base.items()}
        p={'memory':m,'agents':agents,'drops':[],'radius':32.,'base':base,
           'travel_budget':{2:32.,7:32.} if budget is None else budget,
           'forbidden_points':(),'forbidden_mask':~allowed,'route_epsilon':32.,'trust_radius_ratio':1.25,'_prepared':pm}
        result=trust.refine_trust_region(**p)
        return m,pm,p,result
    m,pm,p,result=joint_fixture();old_diag=dict(m.trust_region_diagnostics)
    old_points={k:[x.copy() for x in ps] for k,ps in result.items()}
    answer=layout.joint_advice(p,result,pm,seconds=5.)
    check('joint_actual_competitive_gap',answer['reason']=='positive_competitive_joint' and answer['single_nominal']==3. and answer['joint_nominal']==4.)
    check('joint_confirmed_also_improves',answer['joint_confirmed']>answer['single_confirmed'])
    check('joint_baseline_counters_restored',m.trust_region_diagnostics==old_diag)
    check('joint_returned_original_plan_unmodified',all(np.array_equal(a,b) for k in result for a,b in zip(result[k],old_points[k])))
    m,pm,p,result=joint_fixture({2:0.,7:32.});answer=layout.joint_advice(p,result,pm,seconds=5.)
    check('joint_heterogeneous_owner_cap',answer['reason']!='positive_competitive_joint')
    m,pm,p,result=joint_fixture();answer=layout.joint_advice(p,result,pm,seconds=0.)
    check('joint_deadline_abstains',answer['reason']!='positive_competitive_joint' and answer['deadline_reached'])

    def transport_fixture(owner_at_target=False):
        m=MapMemory(256,128);m.free[:]=True;pm=GeometryPlanningMemory(m)
        values=np.zeros(m.shape,np.float32);values[1,8]=1.
        pm._coverage_values_cache=(64.,values,np.zeros(m.shape,bool))
        allowed=np.zeros(m.shape,bool);allowed[3,10]=True;allowed[3,6]=True
        base={7:[m.cell_to_world((3,10))]}
        p={'memory':m,'agents':{7:(m.cell_to_world((3,10) if owner_at_target else (4,8)),1)},
           'drops':[],'radius':64.,'base':base,'travel_budget':{7:64.},'forbidden_points':(),
           'forbidden_mask':~allowed,'route_epsilon':32.,'trust_radius_ratio':1.25,'_prepared':pm}
        result=trust.refine_trust_region(**p);sources=np.zeros(m.shape,bool);sources[4,14]=True
        return m,pm,p,result,sources
    m,pm,p,result,sources=transport_fixture();before=sources.copy();diag=dict(m.trust_region_diagnostics)
    answer=layout.transport_advice(p,result,pm,seconds=5.,centre_override=sources)
    check('transport_positive_coverage_tie',answer['reason']=='positive_transport_tie' and answer['alternative']['nominal']==answer['incumbent_nominal']==1.)
    check('transport_exact_RED_route_no_increase',answer['alternative']['RED_after']<=answer['alternative']['RED_before']+1e-6)
    check('transport_known_centre_route_larger',answer['alternative']['known_centre_after']>=answer['alternative']['known_centre_before']+pm.CELL)
    check('transport_no_source_or_baseline_mutation',np.array_equal(sources,before) and m.trust_region_diagnostics==diag)
    check('transport_missing_observed_centre_abstains',layout.transport_advice(p,result,pm,seconds=5.)['reason']=='no_measured_centre')
    m,pm,p,result,sources=transport_fixture(True)
    answer=layout.transport_advice(p,result,pm,seconds=5.,centre_override=sources)
    check('transport_rejects_extra_RED_travel',answer['reason']!='positive_transport_tie')
    report.update(status='PASS',count=len(report['checks']),scope='Actual unchanged baseline consumer + bounded current-state synthetic advisors; no game, candidate or historical input. Observer return-plan equivalence still separately required before native.')
except BaseException:
    report.update(status='FAIL',error=traceback.format_exc());raise
finally:
    (Q/'FIRST_RESULT.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
