from pathlib import Path
import json,base64,subprocess,shlex
F=Path(__file__).resolve().parent
assets=json.loads((F/'OBSERVER_ASSETS.json').read_text(encoding='utf-8'))
payload={'assets':assets,'transformer':base64.b64encode((F/'instrument_trust.py').read_bytes()).decode(),'test':base64.b64encode((F/'observer_tests.py').read_bytes()).decode()}
code=r'''
from pathlib import Path
import sys,json,hashlib,base64,ast,shutil,subprocess,os
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F13_completion_joint_transport_20261027'
assert json.loads((F/'advisor_qualification/FIRST_RESULT.json').read_text())['status']=='PASS'
d=json.load(sys.stdin);Q=F/'observer_qualification';assert not Q.exists();Q.mkdir();S=Q/'source';S.mkdir()
P=json.loads((F/'PREDECLARATION.json').read_text())['parent']
scope={};exec(base64.b64decode(d['transformer']).decode(),scope)
for p in (Path(P['path'])/'source').iterdir():shutil.copy2(p,S/p.name)
p=S/'trust_region_cover.py';p.write_text(scope['instrument'](p.read_text()))
for name,record in d['assets'].items():
 b=base64.b64decode(record['base64']);assert hashlib.sha256(b).hexdigest()==record['sha256'];(S/name).write_bytes(b)
p=S/'my_drone_eval.py';s=p.read_text();assert s.count('class MyDroneEval(')==1
s=s.replace('class MyDroneEval(','class BaseParent(',1)+"\nfrom swarm_rescue.solutions.diagnostic_mixin import DiagnosticMixin\nclass MyDroneEval(DiagnosticMixin,BaseParent):\n    F13_MODE='LAYOUT'\n";p.write_text(s)
for p in S.glob('*.py'):ast.parse(p.read_text())
blue=Path(json.loads((H/'F07_evidence_three_directions_20261026/infrastructure/PREDECLARATION.json').read_text())['blue_workspace'])
W=Q/'workspace';shutil.copytree(blue,W,ignore=shutil.ignore_patterns('solutions','__pycache__','*.pyc','.git','.pytest_cache'));sol=W/'src/swarm_rescue/solutions';sol.mkdir()
for p in S.iterdir():shutil.copy2(p,W/'req.txt' if p.name=='req.txt' else sol/p.name)
(Q/'SOURCE_BINDING.json').write_text(json.dumps({'parent':P,'observer_source_files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in S.iterdir()},'assets':{n:r['sha256'] for n,r in d['assets'].items()},'scope':'Diagnostic-only temporary prepared-view capture and bounded readonly advisors; no original numeric/command return change, no production candidate.'},indent=2)+'\n')
p=Q/'observer_tests.py';p.write_bytes(base64.b64decode(d['test']));ast.parse(p.read_text())
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with (Q/'first_console.log').open('x') as log:r=subprocess.run(['bash',str(R/'run_server.sh'),'-u',str(p)],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
report=json.loads((Q/'FIRST_RESULT.json').read_text());print(json.dumps({'status':report['status'],'checks':len(report['checks']),'error':report.get('error')}));raise SystemExit(r.returncode)
'''
p=subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps(payload).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert not(F/'observer_first_console.txt').exists();(F/'observer_first_console.txt').write_bytes(p.stdout+p.stderr)
print(p.stdout.decode(errors='replace'));print(p.stderr.decode(errors='replace'));raise SystemExit(p.returncode)
