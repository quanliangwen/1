from pathlib import Path
import json,base64,subprocess,shlex,hashlib
F=Path(__file__).resolve().parent
files={n:base64.b64encode((F/n).read_bytes()).decode() for n in ['diagnostic_late_completion.py','diagnostic_layout_advisors.py','advisor_tests.py']}
code=r'''
from pathlib import Path
import sys,json,base64,ast,hashlib,shutil,subprocess,os
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F13_completion_joint_transport_20261027'
d=json.load(sys.stdin);Q=F/'advisor_qualification';assert not Q.exists();Q.mkdir();S=Q/'helper_source';S.mkdir()
for n,b in d.items():
 p=Q/n if n=='advisor_tests.py' else S/n;p.write_bytes(base64.b64decode(b));ast.parse(p.read_text())
P=json.loads((F/'PREDECLARATION.json').read_text())['parent']
blue=Path(json.loads((H/'F07_evidence_three_directions_20261026/infrastructure/PREDECLARATION.json').read_text())['blue_workspace'])
W=Q/'reference_workspace';shutil.copytree(blue,W,ignore=shutil.ignore_patterns('solutions','__pycache__','*.pyc','.git','.pytest_cache'));sol=W/'src/swarm_rescue/solutions';sol.mkdir()
for p in (Path(P['path'])/'source').iterdir():shutil.copy2(p,W/'req.txt' if p.name=='req.txt' else sol/p.name)
(Q/'SOURCE_BINDING.json').write_text(json.dumps({'parent':P,'helpers':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in S.iterdir()},'scope':'Synthetic qualification only; no native game or production source mutation.'},indent=2)+'\n')
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with (Q/'first_console.log').open('x') as log:r=subprocess.run(['bash',str(R/'run_server.sh'),'-u',str(Q/'advisor_tests.py')],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
report=json.loads((Q/'FIRST_RESULT.json').read_text());print(json.dumps({'status':report['status'],'checks':len(report['checks']),'error':report.get('error')}));raise SystemExit(r.returncode)
'''
p=subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps(files).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert not(F/'advisor_first_console.txt').exists();(F/'advisor_first_console.txt').write_bytes(p.stdout+p.stderr)
print(p.stdout.decode(errors='replace'));print(p.stderr.decode(errors='replace'));raise SystemExit(p.returncode)
