from pathlib import Path
import json,datetime,subprocess,shlex
F=Path(__file__).resolve().parent;OLD=F.parent/'F12_kernel_drop_terminal_20261027'
assert not(F/'PREDECLARATION.json').exists()
state=json.loads((OLD/'M01_PERF/STATUS.json').read_text(encoding='utf-8'));assert state['status']=='EARLY_SCREENED_VALID_SCORE'
for item in state['completed']:
    p=OLD/'M01_PERF'/(item['version']+'_'+item['cohort'])/'CLIENT_FIRST_RAW_REVIEW.json'
    assert json.loads(p.read_text(encoding='utf-8'))['valid']
admission=json.loads((OLD/'DIRECTION_ADMISSION.json').read_text(encoding='utf-8'));assert admission['M02']['admitted'] is False and admission['M03']['admitted'] is False
parent=json.loads((OLD/'PREDECLARATION.json').read_text(encoding='utf-8'))['parent']
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'F13_completion_joint_transport_20261027','status':'PARENT_RESOLVED_BEFORE_ANY_CANDIDATE',
 'authorization':'Human requests continued analysis-first iteration, five ranked directions, assistant selects three, small validation before real tests, maximize original-five mean. No further selection question.',
 'control_id':parent['candidate_id'],'parent':parent,'parent_confirmed_four_cohort_mean':82.53412110271165,
 'parent_selection':'F12 M01 original-five78.969896 vsK01 82.736121 was screened<80 with no complete4v4 winner; M02/M03 deferred without candidates. Retain actual K01/source SHA, no rebase on a losing speed optimization. All admitted N children independent from frozen parent; no feature stacking mid-round.',
 'five_ranked_directions':[
  {'id':'N01','rank':1,'recommendation':'highest_diagnose_first','name':'Known-safe nearby relocation to finish inventory after plan suffix is exhausted','evidence':'Fresh F12 parent Map05: stock2 but1 remaining stop, after2051 drop stock1/no placement goal, current original safety rejects because<30px from own drop. Ordinary goal remains near same bomb. No known legal reachable next point yet proven; F12 current-point fallback was correctly deferred.'},
  {'id':'N02','rank':2,'recommendation':'high_diagnose_first','name':'Bounded joint-pair search competes with existing single-site improvement','evidence':'Actual unchanged refiner fixed synthetic counterexample: value2→single3, feasible two-owner4 with route cap32/trust40/spacing/forbidden preserved;10checks pass. Real gap frequency and extra cost unknown.'},
  {'id':'N03','rank':3,'recommendation':'medium_diagnose_first','name':'Among tied supported coverage and nonincreasing RED travel, prefer greater known-centre transport distance','evidence':'7check fixed synthetic plateau: coverage1/1, exact REDroute38.627/38.627, own-map centre-route70.627 vs134.627; actual method keeps incumbent. Not BLUE private state or official difficulty prediction. F12 better wall but lower BLUE term motivates measuring equivalent alternatives rather than new global weights.'},
  {'id':'defer_dual_budget','rank':4,'recommendation':'medium_low','name':'Forecast execution with both timestep reward and wallclock limits','evidence':'M01 Map01 step1905/time9.5 vsparent1433/time56.7; last drop1885 then submit1905, so this case is mostly late execution, not proven post-completion fusion stall. Need forecasts bound to actual assignment revisions before changing budgets; old global speed shrink D03 already failed.'},
  {'id':'defer_render_reuse','rank':5,'recommendation':'low','name':'Exact rendering reuse within one planning transaction','evidence':'Possible repeated expensive bearing_fields, but identical-input repeats not measured; nonwall/hits can change without a simple surface revision. M01 shows speed alone is not score proof; do not blindly cache.'}],
 'selected':['N01','N02','N03'],
 'parent_diagnostics':[
  {'name':'PARENT_M05','map':'Map05','purpose':'Known-safe relocation opportunity on current own map in normal late no-goal state; at most2 readonly advisors/owner separated>=24steps, stock>0, no pending/submitted,24<=remaining<=120, before commands original legal guard unchanged. Search<=8 nearby candidate cells within available own execution budget with1s soft deadline/4096A*pops; preserve sensed walkability/corner safety/30px spacing plus existing geometry margin/observed centre exclusion. Require known path with travel/2+24<=remaining, account own computation overhead, no forced actuator or unknown target.'},
  {'name':'PARENT_M04','map':'Map04','purpose':'Read-only bounded local joint/tied-transport probes on actual planning inputs/results; at most1 joint and1 transport probe per own memory instance, each1s soft deadline, never change returned plan or original diagnostics/goal/command. Restore original counters; all new metadata in own diagnostic namespace. No controller rerun or historical input. Exact scoring/route/spacing checks, timeout is abstention. Record actual opportunity and cost before deciding source integration.'}],
 'admission_gates':{
  'N01':'At least1 declared fresh Map05 event has a feasible known-route new legal target under24..120-step urgency, all existing constraints preserved. Otherwise defer without source. Candidate first fresh Map05 must execute relocation then get real inventory-decrease acknowledgement before five maps.',
  'N02':'At least1 declared fresh Map04 planning event has joint confirmed/nominal coverage strictly better than actual returned single result, same owner/count/order/trust/forbidden/route epsilon and full owner-prefix caps, with bounded advisor cost recorded. Evaluate overhead, then freeze production runtime cap before source mutation; fresh candidate Map04 must actually accept a competitive joint move before five maps. No opportunity => defer.',
  'N03':'At least1 declared fresh Map04 event has positive supported incumbent value, an alternative with no nominal/confirmed coverage decrease (1e-5 numeric tolerance), no increase in complete owner RED route, preserved safety/trust/owner/full prefix caps, and known observed-centre route increase>=oneCELL. Centre source derived only from own measured disposal/nonwall evidence intersected known walkable cells; absent source/reachability => abstain. Record overhead, freeze bounded implementation before source. Fresh candidate Map04 must actually select such tied alternative before five maps. No opportunity => defer.'},
 'protocol':'Interleave true K01_A/candidate_A/K01_B/candidate_B on originalMap01-05 RED→actual unchanged BLUE. Any complete candidate-five mean<80 stop; at2pairs cumulative<=control stop; positive expand to complete4v4, each surviving pair first Windows raw SHA/scalar/source checks and agent review; strict higher mean only/tie parent. Stock/speed/proxy/variance diagnostic only, never substitute score. No external seed, altered SDK/map/BLUE/scoring/physics/clock/input or failed-native rerun. Original117 registry unchanged, repeat ledger separate.',
 'budget':'At most2 parent RED-only diagnostics+3 admitted candidate RED-only diagnostics+24 full-five groups; opportunity-free directions stop before code/full tests. Native limits original180/240sec, external600sec watchdog unchanged. Single evaluator, prior F12 terminal/coordinator exited/serial lock/activity clear before dispatch.',
 'scope':'Own live public sensor map and actually received messages only; fixed synthetic fixtures solely QA. No true map/private BLUE/peer objects/shared global observations/historical arrays/replay. NPZ/pickle opaque streamingSHA only, never deserialize. No Docker/subagents/50maps/website upload/new app automation; preserve failures/low scores/source. New local files E:/codex.',
 'release':'Internal only. Numeric615/exactnumpy1.26.4/pandas2.2.3/opencv-contrib4.11.0.86 and actual ZIP-bound real ABI/SDK paths+strict submission guard before delivery. Native ROOT/.venv pandas3.0.6 unchanged/no installs. V05 external recommendation unchanged; official container not verified.'}
b=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode()
code=r'''
from pathlib import Path
import sys,json,hashlib,fcntl
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';OLD=H/'F12_kernel_drop_terminal_20261027';F=H/'F13_completion_joint_transport_20261027'
assert not F.exists() and not(OLD/'FIRST_NATIVE_ERROR.json').exists()
s=json.loads((OLD/'M01_PERF/STATUS.json').read_text());assert s['status']=='EARLY_SCREENED_VALID_SCORE'
p=Path('/proc')/str(s['pid'])/'stat';assert not p.exists() or p.read_text().split()[2]=='Z'
a=json.loads((R/'solver_study/heuristic_20261016.json').read_text());assert not a.get('active_processes') and not a.get('current_formal_active')
with (R/'solver_study/serial_evaluation.lock').open('a+') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 b=sys.stdin.buffer.read();d=json.loads(b);P=d['parent'];S=Path(P['path'])/'source';assert hashlib.sha256(Path(P['zip']).read_bytes()).hexdigest()==P['zip_sha256']
 assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in S.iterdir() if p.is_file()}==P['source_files']
 F.mkdir();(F/'PREDECLARATION.json').write_bytes(b)
 print(json.dumps({'status':d['status'],'control_id':d['control_id'],'sha256':hashlib.sha256(b).hexdigest(),'no_native_started':True}))
'''
out=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=b)
(F/'PREDECLARATION.json').write_bytes(b);(F/'DECLARATION_RECEIPT.json').write_bytes(out);print(out.decode())
