from pathlib import Path
import sys,json,datetime,subprocess,shlex
F=Path(__file__).resolve().parent;name=sys.argv[1];assert name in ['PARENT_M05_DIAG','PARENT_M04_DIAG']
G=F/name
assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text())['valid']
assert not(G/'ANALYSIS.json').exists()
e=json.loads((G/'EVENTS.json').read_text());r=json.loads((G/'RESULT.json').read_text())
late=e['F13_LATE_COMPLETION_ADVISOR'];layout=e['F13_LAYOUT_ADVISOR']
from collections import Counter
counts=lambda rows:dict(Counter(x.get('reason','missing') for x in rows))
latest={}
for x in e['F13_DIAG_TICK']+e['F13_SUBMIT_DECISION']+e['F13_SUBMIT_CALL']:
 owner=x.get('owner');old=latest.get(owner)
 if old is None or x.get('step',0)>=old.get('step',0):latest[owner]=x
summary=[]
for owner,x in sorted(latest.items()):
 summary.append({k:x.get(k) for k in ['owner','step','stock','remaining_steps','placement_goal','assignment_goal','current_goal','late_completion_advisors','layout_mode','costs']})
a={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'diagnostic':name,'parent':'K01','not_for_performance_ranking':True,'game_row':r['row'],'event_counts':r['event_counts'],'late_reason_counts':counts(late),'layout_events':layout,'latest_own_scalars':summary,'raw_arrays_loaded':0,'scope':'Fresh own scalar logs only. Opportunity gate does not predict score; timeout/absence is abstention, not universal impossibility.'}
if name=='PARENT_M05_DIAG':
 a['gates']={'N01':any(x.get('reason')=='positive_known_legal_relocation' for x in late)}
 a['late_events']=late
else:
 # wrapper stores the advice directly with a kind/owner prefix; no historical planning input is replayed.
 def reasons(x):return [x.get('reason')]+[v.get('reason') for v in x.values() if isinstance(v,dict)]
 a['gates']={'N02':any('positive_competitive_joint' in reasons(x) for x in layout),'N03':any('positive_transport_tie' in reasons(x) for x in layout)}
 a['reason_lists']=[reasons(x) for x in layout]
p=G/'ANALYSIS.json';p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
remote="from pathlib import Path;import sys;F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F13_completion_joint_transport_20261027');p=F/"+repr(name)+"/'ANALYSIS.json';assert not p.exists();p.write_bytes(sys.stdin.buffer.read())"
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(remote)],input=p.read_bytes(),check=True)
print(json.dumps({k:a[k] for k in ['diagnostic','gates','late_reason_counts','layout_events']},ensure_ascii=False))
