class ExtensionMethods:
    def _submission_due(self, step):
        due = super()._submission_due(step)
        if due:
            import json
            state = self._diag_state()
            state['reason'] = 'deadline_remaining_steps_zero' if state['remaining_steps'] <= 0 else 'normal_completion_election'
            print('[F13_SUBMIT_DECISION]',json.dumps(state,separators=(',',':')),flush=True)
        return due

    def _maybe_place(self, command, step, semantic):
        result = super()._maybe_place(command, step, semantic)
        if getattr(self,'F13_MODE','NONE') != 'LATE':
            return result
        count = getattr(self,'_f13_late_count',0)
        last = getattr(self,'_f13_late_last',-1000)
        if (count >= 2 or step-last < 24 or self.submitted or self.pose is None
                or self.pending_drop is not None or int(self.carried_bombs_count()) <= 0
                or self.placement_goal is not None or step-self.last_attempt_step < 8
                or step < self.PLAN_START_RATIO*self.limit):
            return result
        remaining = self._remaining_steps()
        if not 24 <= remaining <= 120:
            return result
        self._f13_late_count = count+1;self._f13_late_last = step
        from swarm_rescue.solutions.diagnostic_late_completion import nearby_completion
        begun = time.perf_counter()
        elapsed = max(0.,begun-getattr(self,'_f13_control_started',begun))
        rate = max(.001,float(getattr(self,'_step_seconds',.05)))
        adjusted = remaining-elapsed/rate
        try:
            route,advice = nearby_completion(self,step,semantic,remaining=adjusted,seconds=1.)
        finally:
            self._diag_record_cost('late_completion_advisor_extra',begun)
        advice.update(owner=int(self.identifier or 0),step=int(step),stock=int(self.carried_bombs_count()),
                      remaining_before_own_compute=remaining,remaining_after_control_compute=adjusted,
                      original_command_place=int(command.get('place_bomb',0)))
        import json
        print('[F13_LATE_COMPLETION_ADVISOR]',json.dumps(advice,separators=(',',':')),flush=True)
        return result
