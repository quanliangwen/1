"""Bounded current-own-map advisor; it never issues a command or changes a goal."""
import heapq
import math
import time
import numpy as np
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory


def nearby_completion(drone, step, semantic, remaining=None, seconds=1.0):
    begun = time.perf_counter(); deadline = begun + seconds
    m = drone.memory; position = np.asarray(drone.pose, float)
    if position.shape != (2,) or not np.isfinite(position).all():
        return None, {'reason': 'invalid_own_position'}
    remaining = float(drone._remaining_steps() if remaining is None else remaining)
    if (drone.submitted or drone.pending_drop is not None or int(drone.carried_bombs_count()) <= 0
            or drone.placement_goal is not None or not 24 <= remaining <= 120
            or step < drone.PLAN_START_RATIO*drone.limit):
        return None, {'reason': 'outside_late_missing_goal_state'}
    walkable = m.free & ~m.blocked()
    rr, cc = np.indices(m.shape)
    xx = (cc+.5)*m.CELL-m.width/2; yy = m.height/2-(rr+.5)*m.CELL
    inside = (np.abs(xx) < m.width/2-m.CELL) & (np.abs(yy) < m.height/2-m.CELL)
    walkable &= inside
    allowed = walkable.copy()
    forbidden = drone._placement_forbidden_mask()
    if forbidden is not None:
        forbidden = np.asarray(forbidden, bool)
        if forbidden.shape != m.shape:
            return None, {'reason': 'invalid_own_forbidden_shape'}
        allowed &= ~forbidden
    spacing = max(24., float(drone._placement_spacing(step))) + .71*m.CELL
    for value in drone._known_bomb_positions(semantic):
        point = np.asarray(value, float)
        if point.shape != (2,) or not np.isfinite(point).all():
            return None, {'reason': 'invalid_known_bomb_position'}
        allowed &= (xx-point[0])**2+(yy-point[1])**2 >= spacing**2
    peer_goals = getattr(drone, '_other_live_placement_goals', lambda step: [])(step)
    for value in peer_goals:
        point = np.asarray(value, float)
        if point.shape != (2,) or not np.isfinite(point).all():
            return None, {'reason': 'invalid_received_reserved_goal'}
        allowed &= (xx-point[0])**2+(yy-point[1])**2 >= (40.+.71*m.CELL)**2
    # The existing placement guard rejects a nearby observed disposal entity.
    # Conservatively keep future targets away from the same measured surfaces.
    surfaces = []
    for _, cloud in getattr(drone, 'centre_surface_records', {}).values():
        a = np.asarray(cloud, float)
        if a.size:
            if a.ndim != 2 or a.shape[1] != 2 or not np.isfinite(a).all():
                return None, {'reason': 'invalid_measured_centre_surface'}
            surfaces.extend(a)
    for obj in semantic or ():
        if getattr(getattr(obj, 'entity_type', None), 'name', '') == 'DISPOSAL_CENTER':
            angle = drone.heading + float(obj.angle)
            surfaces.append(position+float(obj.distance)*np.array([math.cos(angle), math.sin(angle)]))
    for p in surfaces:
        allowed &= (xx-p[0])**2+(yy-p[1])**2 >= (32.+.71*m.CELL)**2
    metric = np.hypot(xx-position[0], yy-position[1])
    allowed &= metric <= max(0., remaining-24.)*2.
    cells = []
    for flat in np.argsort(np.where(allowed, metric, np.inf).ravel(), kind='stable'):
        cell = tuple(map(int, np.unravel_index(flat, m.shape)))
        if not allowed[cell]:
            break
        if any((cell[0]-r)**2+(cell[1]-c)**2 < 4 for r,c in cells):
            continue
        cells.append(cell)
        if len(cells) >= 8:
            break
    if not cells:
        return None, {'reason': 'no_known_legal_nearby_cell'}
    targets = set(cells); start = m.world_to_cell(position)
    walkable = walkable.copy(); walkable[start] = True
    distances = {start: 0.}; parents = {}; queue = [(0., start)]; popped = 0
    while queue and popped < 4096:
        if time.perf_counter() >= deadline:
            return None, {'reason': 'deadline', 'pops': popped}
        cost, cell = heapq.heappop(queue)
        if cost > distances[cell]:
            continue
        popped += 1
        if cell in targets:
            path = [cell]
            while path[-1] != start:
                path.append(parents[path[-1]])
            path.reverse()
            points = [position] + [m.cell_to_world(c) for c in path[1:]]
            if len(points) == 1:
                points.append(m.cell_to_world(cell))
            length = sum(float(np.linalg.norm(b-a)) for a,b in zip(points, points[1:]))
            rate = max(.001, float(getattr(drone, '_step_seconds', .05)))
            available = remaining-(time.perf_counter()-begun)/rate
            demand = length/2.+24.
            if demand <= available:
                smooth = [start]; index = 0
                while index < len(path)-1:
                    far = index+1
                    for next_index in range(index+2, len(path)):
                        if not GeometryPlanningMemory._visible(path[index],path[next_index],walkable):
                            break
                        far = next_index
                    smooth.append(path[far]); index = far
                target = m.cell_to_world(cell)
                route = [m.cell_to_world(c) for c in smooth[1:]] or [target.copy()]
                return route, {'reason':'positive_known_legal_relocation','target':target.tolist(),
                    'known_route_length':length,'conservative_steps':demand,'remaining_after_own_compute':available,
                    'current_inventory':int(drone.carried_bombs_count()),'candidate_cells':len(cells),
                    'pops':popped,'spacing_with_cell_margin':spacing,
                    'scope':'Only current own map/received evidence. Original live placement guard and actuator still decide at arrival; not a guaranteed placement.'}
        row, col = cell
        for dr,dc in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)):
            nr,nc = row+dr,col+dc
            if not(0 <= nr < m.shape[0] and 0 <= nc < m.shape[1]) or not walkable[nr,nc]:
                continue
            if dr and dc and (not walkable[row+dr,col] or not walkable[row,col+dc]):
                continue
            proposal = cost+m.CELL*(math.sqrt(2.) if dr and dc else 1.)
            other = (nr,nc)
            if proposal < distances.get(other, math.inf):
                distances[other] = proposal; parents[other] = cell
                heapq.heappush(queue,(proposal,other))
    return None, {'reason':'no_known_feasible_route','pops':popped}
