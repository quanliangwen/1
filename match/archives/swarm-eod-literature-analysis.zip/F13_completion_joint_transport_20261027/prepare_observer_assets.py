from pathlib import Path
import ast,json,base64,hashlib
F=Path(__file__).resolve().parent;OLD=F.parent/'F12_kernel_drop_terminal_20261027'
assert not(F/'OBSERVER_ASSETS.json').exists()
template=json.loads((OLD/'OBSERVER_ASSETS.json').read_text(encoding='utf-8'))
s=base64.b64decode(template['diagnostic_mixin.py']['base64']).decode().replace('F12','F13')
tree=ast.parse(s);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='DiagnosticMixin')
extension=ast.parse((F/'observer_extensions.py').read_text(encoding='utf-8')).body[0]
names={n.name for n in extension.body if isinstance(n,ast.FunctionDef)}|{'_diagnostic_terminal_advisor'}
cls.body=[n for n in cls.body if not(isinstance(n,ast.FunctionDef) and n.name in names)]+extension.body
init=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='__init__')
init.body+=ast.parse("self.memory._f13_layout_enabled = getattr(self,'F13_MODE','NONE') == 'LAYOUT'").body
control=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='control')
control.body=ast.parse('self._f13_control_started = time.perf_counter()').body+control.body
state=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_diag_state')
assert isinstance(state.body[-1],ast.Return)
state.body=state.body[:-1]+ast.parse("state['f13_mode']=getattr(self,'F13_MODE','NONE')\nstate['f13_late_advisor_count']=getattr(self,'_f13_late_count',0)").body+state.body[-1:]
ast.fix_missing_locations(tree);mixin=ast.unparse(tree)+'\n';ast.parse(mixin)
(F/'diagnostic_mixin.py').write_text(mixin,encoding='utf-8')
assets={'diagnostic_mixin.py':mixin}
for n in ['diagnostic_late_completion.py','diagnostic_layout_advisors.py']:
    assets[n]=(F/n).read_text(encoding='utf-8');ast.parse(assets[n])
bundle={n:{'base64':base64.b64encode(t.encode()).decode(),'sha256':hashlib.sha256(t.encode()).hexdigest()} for n,t in assets.items()}
(F/'OBSERVER_ASSETS.json').write_text(json.dumps(bundle,indent=2)+'\n',encoding='utf-8')
print(json.dumps({n:v['sha256'] for n,v in bundle.items()}))
