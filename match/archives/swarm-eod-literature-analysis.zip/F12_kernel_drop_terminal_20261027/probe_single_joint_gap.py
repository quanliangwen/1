from pathlib import Path
import json,subprocess,shlex
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import sys,json,datetime,hashlib,traceback
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F12_kernel_drop_terminal_20261027'
D=F/'SINGLE_JOINT_GAP_PROBE_DECLARATION.json';G=F/'SINGLE_JOINT_GAP_PROBE_FIRST.json';assert not D.exists() and not G.exists()
source=H/'F09_route_and_views_20261026/K01/source/trust_region_cover.py'
D.write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'One fixed synthetic actual-refiner counterexample measurement; no changed algorithm/source/candidate/game/history input. Manual alternative evaluated only on synthetic wall-value fixture. First failure retained/no retry.',
 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'fixture':'Same geometry as existing consumer single-winner fixture, but now quantify feasible2-owner alternative instead of just preserving old branch; cells9/11/15 weights1/1/2, radius32, owners2/7 at8/12, moves10/14, owner caps32.'})+'\n')
report={'status':'STARTED','checks':[]}
def check(n,x):
 assert x,n
 report['checks'].append(n)
try:
 sys.path.insert(0,str(F/'observer_preparation/reference_workspace/src'))
 import numpy as np
 from swarm_rescue.solutions.greedy_mapping import MapMemory
 from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
 from swarm_rescue.solutions.team_coverage import path_costs
 from swarm_rescue.solutions import trust_region_cover as trust
 check('actual_unchanged_refiner',hashlib.sha256(Path(trust.__file__).read_bytes()).hexdigest()==hashlib.sha256(source.read_bytes()).hexdigest())
 m=MapMemory(256,128);m.free[:]=True;pm=GeometryPlanningMemory(m)
 values=np.zeros(m.shape,np.float32)
 for col,weight in [(9,1.),(11,1.),(15,2.)]:values[3,col]=weight
 pm._coverage_values_cache=(32.,values,np.zeros(m.shape,bool))
 allowed=np.zeros(m.shape,bool)
 for col in [8,10,12,14]:allowed[3,col]=True
 base={2:[m.cell_to_world((3,8))],7:[m.cell_to_world((3,12))]}
 agents={k:(ps[0].copy(),1) for k,ps in base.items()}
 result=trust.refine_trust_region(m,agents,[],32.,base,travel_budget={2:32.,7:32.},forbidden_mask=~allowed,_prepared=pm)
 alternative={2:[m.cell_to_world((3,10))],7:[m.cell_to_world((3,14))]}
 score=lambda plan:float(values[trust._coverage_mask(pm,[p for ps in plan.values() for p in ps],32.)].sum())
 check('actual_single_result_measured',score(result)==3.)
 check('manual_joint_strictly_higher',score(alternative)==4. and score(alternative)>score(result))
 check('original_input_not_mutated',np.array_equal(base[2][0],m.cell_to_world((3,8))) and np.array_equal(base[7][0],m.cell_to_world((3,12))))
 for k in agents:
  p=alternative[k][0];dist=float(path_costs(pm,pm.free&~pm.blocked(),pm.world_to_cell(agents[k][0]))[pm.world_to_cell(p)])
  check('exact_owner_route_cap_'+str(k),dist<=32.+1e-6)
  check('trust_radius_and_allowed_'+str(k),float(np.linalg.norm(p-base[k][0]))<=1.25*32.+1e-6 and allowed[pm.world_to_cell(p)])
 check('pair_spacing_preserved',np.linalg.norm(alternative[2][0]-alternative[7][0])>=40.+.71*m.CELL)
 check('actual_early_single_branch_skips_joint','joint_pairs_evaluated' not in m.trust_region_diagnostics)
 report.update(status='PASS',count=len(report['checks']),incumbent_synthetic_value=score(base),returned_single_synthetic_value=score(result),feasible_joint_synthetic_value=score(alternative),diag=m.trust_region_diagnostics,
  note='Demonstrates bounded candidate-search gap on synthetic data, not actual frequency/net payoff or official score gain. Need fresh live opportunity/cost diagnosis before candidate integration. Current M01 remains unchanged; no fourth F12 production candidate.')
except BaseException:report.update(status='FAIL',error=traceback.format_exc());raise
finally:G.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
'''
cmd='env -u MATCH_PHASE_ID -u PYGLET_HEADLESS -u PYTHONPATH MATCH_HEURISTIC_ID=heuristic_20261015T2047Z bash /home/junhao/quan/parallel_test_solver/match/run_server.sh -u -c '+shlex.quote(code)
p=subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60',cmd],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert not(F/'single_joint_gap_first_console.txt').exists()
(F/'single_joint_gap_first_console.txt').write_bytes(p.stdout+p.stderr)
if p.returncode:
 print(p.stdout.decode(errors='replace')[-3000:]);print(p.stderr.decode(errors='replace')[-3000:]);raise SystemExit(p.returncode)
d=json.loads(p.stdout.decode().strip().splitlines()[-1]);(F/'SINGLE_JOINT_GAP_PROBE_FIRST.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
print(json.dumps(d))
