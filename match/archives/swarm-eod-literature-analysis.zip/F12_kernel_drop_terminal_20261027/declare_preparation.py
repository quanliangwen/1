from pathlib import Path
import json,datetime,hashlib,subprocess,shlex
F=Path(__file__).resolve().parent
assert not(F/'PREPARATION_DECLARATION.json').exists()
decl={
 'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'phase':'F12_kernel_drop_terminal_20261027',
 'status':'PREPARATION_ONLY_PARENT_UNRESOLVED_NO_NEW_CANDIDATE_OR_NATIVE_RUN',
 'authorization':'Human explicitly requests sustained evidence-led iterations, five ranked directions and assistant selects three; small mechanisms first and whole original-five mean only. Current F11 L03 continues unchanged; no next native run until F11 terminal/coordinator exited/activity empty/serial lock free.',
 'five_ranked_directions':[
  {'id':'M01','rank':1,'recommendation':'highest','name':'Exact four-slice Boolean2x2 projection instead of padded reduction','evidence':'79 pure-kernel and19 actual consumer checks first pass; synthetic actual merge100calls .265208s vs.146570s. Fresh own merge cost28/64s and35/154s, actual kernel share still unknown.'},
  {'id':'M02','rank':2,'recommendation':'high_diagnose_first','name':'Deadline-near legal current-point fallback when inventory remains but no placement goal','evidence':'Actual active MRO overrides base urgent drop.8 actual-method state fixtures confirm no attempt at remaining80/wall95percent/no goal. Fresh L03_A Map04 left1; console reports incomplete inventory layout, but real missing-goal/legal-current coincidence not yet observed.'},
  {'id':'M03','rank':3,'recommendation':'medium_high_diagnose_first','name':'Finite post-completion survey with submission coordination','evidence':'Fresh L03 Map05 at normal submission has all certificates,345.77estimatedsteps/48.19wallseconds;3checkpoints meet240/15 budget. SDK any submit ends before physics, so local deferral alone insufficient. Reachable beneficial target not proven.'},
  {'id':'defer_sparse','rank':4,'recommendation':'medium_low','name':'Large unique sparse bearing OR fast path','evidence':'Synthetic large10000 ids faster,100ids slower; actual cost/count distribution unknown. Measure in parent observer, no candidate now.'},
  {'id':'defer_lut','rank':5,'recommendation':'low','name':'Readonly256-entry exact incidence lookup','evidence':'265 first checks pass including all values/scalar array shape; kernel faster but absolute submillisecond per render and actual call count unknown. Measure, no candidate now.'}],
 'selected':['M01','M02','M03'],
 'parent_selection':'After F11 L03 terminal, choose highest observed mean among complete4v4 strict winners vs their contemporary control: established K01(82.53412110271165), optionally L03 only if full4v4 wins. Tie retain K01. Resolve true id/sourceZIP SHA before any production source mutation. All admitted children independent from same frozen parent; no stacking/rebasing mid-round. No parent promotion from a high single group or synthetic speedup.',
 'parent_diagnostics':[
  {'name':'PARENT_M04','map':'Map04','purpose':'Fresh original180s RED-only kernel cost and naturally occurring late-drop guard opportunity; own state only. At most8 counterfactual guard checks per owner, spaced>=24steps, stock>0/no goal/24<=remaining<=120, not pending/submitted/retry. Reuse semantic argument already supplied to normal maybe-place; extra readonly existing legality method explicitly permitted only as diagnostic advisor, no commands or policy feedback.'},
  {'name':'PARENT_M05','map':'Map05','purpose':'Fresh original240s RED-only kernel costs and terminal target opportunity. At normal submission election with allcert/remaining>=240/wall>=15 and step+120<=limit/2, at most1 readonly advisor per owner. Use only live own map and already received messages; known walkable paths/corner checks, <=6 candidates,4096 A* pops,1s soft deadline, positive inherited evidence gain>=2 and >=48px movement, conservative one-way length/2+24+24<=120. Abstain on budget/shape/timeout, no new sensing/control calls or recorded-state inputs.'}],
 'kernel_observer':'Diagnostic copies only. Per-instance profile dicts time original fine_any_to_four/independent_incidence bodies and actual received bearing OR; no global observations, all original merges/retractions still execute. Record sparse length/sorted status outside union timer. Observer/advisor affects wallclock; no unpaired causal speed/score interpretation. AST and actual consumer output-equivalence checks before first native diagnostics.',
 'admission_gates':{
  'M01':'Map04 measured sum of disjoint fine_any_to_four helper costs >=1percent of measured control cost, plus existing synthetic full merge benefit>20percent and first actual transformed candidate/source/consumer/ABI qualification. One fresh candidate Map04 RED diagnostic verifies real invocation/no crash before five maps.',
  'M02':'At least1 fresh Map04 diagnostic event meets declared late/no-goal/own legality predicate. Otherwise defer without source version or five maps; not proof global impossibility. Candidate changes only ActiveCoverageMixin maybe-place late no-goal branch at24<=remaining<=120; preserve stock/submitted/pending/retry8/position/safety checks, spacing30/centre mask/SDK actuator, original route budgets/speed. First candidate Map04 must confirm a fallback attempt followed by real inventory acknowledgement before five maps. No fallback ack => stop expansion.',
  'M03':'At least1 fresh Map05 normal-completion advisor returns positive feasible known-route target under frozen window/flat-time conditions. Otherwise defer without source/five maps. Before implementation freeze finite coordination design and test>=2 instances for early-submit race, completion knowledge arriving at different ticks, no-benefit case, hard deadline fallback and exactly one bounded episode. Original remaining<=0 always preempts. One fresh candidate Map05 must show actual terminal target execution/new observed evidence before five maps.'},
 'protocol':'Original Map01-05 RED then actual unchanged supplied BLUE. Interleave true parent_A/candidate_A/parent_B/candidate_B; candidate any complete-five mean<80 stop; at2pairs cumulative<=parent stop; positive expands to complete4v4 with per-pair first Windows raw SHA/scalar checks and agent reasoning review; strict higher mean only, tie parent. No historical threshold, stock/speed/variance only diagnostic, no external seed/SDK/physics/map/BLUE/scoring/clock/input changes. First native failure stops chain with original error retained; no failed-native reruns/relabel/rescue.',
 'budget':'At most2 parent RED-only diagnostics+3 admitted candidate RED-only diagnostics+24 complete original-five groups. Selected directions can stop at no opportunity; do not create weak versions to fill quota. Diagnostics serial, each at original native map limits, external600s hang watchdog unchanged.',
 'scope':'No Docker/subagents/50maps/website upload/new app automation. Public own live sensors and actually received messages only. NPZ/pickle SHA opaque, never deserialize/replay. Original117 once registry unchanged; separate repeat ledger. Preserve old/low-score/error files. New local files E:/codex; existing project stays in place.',
 'release':'Internal candidates only until actual ZIP SHA-bound numeric team615/exact numpy1.26.4/pandas2.2.3/opencv-contrib4.11.0.86 true ABI/SDK and strict submission guard pass. Native root existing pandas3.0.6 unchanged; no installation or SDK edits. Current V05 recommendation unchanged; official container not verified.'
}
b=(json.dumps(decl,ensure_ascii=False,indent=2)+'\n').encode()
(F/'PREPARATION_DECLARATION.json').write_bytes(b)
remote=r'''
from pathlib import Path
import sys,json,hashlib
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
F=H/'F12_kernel_drop_terminal_20261027';assert not F.exists()
b=sys.stdin.buffer.read();d=json.loads(b);assert d['status'].startswith('PREPARATION_ONLY')
F.mkdir();(F/'PREPARATION_DECLARATION.json').write_bytes(b)
print(json.dumps({'status':d['status'],'sha256':hashlib.sha256(b).hexdigest(),'current_F11_status':json.loads((H/'F11_optics_hysteresis_stall_20261027/STATUS.json').read_text())['status'],'no_native_started':True}))
'''
p=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(remote)],input=b)
(F/'PREPARATION_RECEIPT.json').write_bytes(p);print(p.decode())
