from pathlib import Path
import json,base64,ast,hashlib,subprocess,shlex
F=Path(__file__).resolve().parent;OLD=F.parent/'F11_optics_hysteresis_stall_20261027'
assert not(F/'PARENT_OPERATORS.json').exists()
d=json.loads((OLD/'operators/L03/stage_diagnostic.json').read_text(encoding='utf-8'))
template=base64.b64decode(d['payload']['runner']).decode()
bundle={}
for name,m in [('PARENT_M04','Map04'),('PARENT_M05','Map05')]:
    s=template.replace('F11','F12').replace('L03',name).replace('Map05',m).replace('MAP05',m.upper())
    assert "'new_algorithm':True" in s;s=s.replace("'new_algorithm':True","'new_algorithm':False")
    s=s.replace('RED_ONLY_NO_PERFORMANCE_RANKING','PARENT_OBSERVER_NO_PERFORMANCE_RANKING')
    assert s.count("'F12_REFINE']")==1
    s=s.replace("'F12_REFINE']","'F12_REFINE','F12_LATE_DROP_ADVISOR','F12_TERMINAL_ADVISOR']")
    ast.parse(s)
    bundle[name]={'runner_base64':base64.b64encode(s.encode()).decode(),'sha256':hashlib.sha256(s.encode()).hexdigest(),'map':m}
maps={'PARENT_M04_DIAG':'Map04','PARENT_M05_DIAG':'Map05','M01_DIAG':'Map04','M02_DIAG':'Map04','M03_DIAG':'Map05'}
(F/'DIAGNOSTIC_MAP_BINDINGS.json').write_text(json.dumps(maps,indent=2)+'\n',encoding='utf-8')
(F/'PARENT_OPERATORS.json').write_text(json.dumps(bundle,indent=2)+'\n',encoding='utf-8')
remote=r'''
from pathlib import Path
import json,sys,hashlib
F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F12_kernel_drop_terminal_20261027')
d=json.load(sys.stdin)
assert not(F/'PARENT_OPERATORS.json').exists() and not(F/'DIAGNOSTIC_MAP_BINDINGS.json').exists()
for n in ['PARENT_OPERATORS.json','DIAGNOSTIC_MAP_BINDINGS.json']:(F/n).write_text(json.dumps(d[n],indent=2)+'\n')
print(json.dumps({'prepared':list(d['PARENT_OPERATORS.json']),'maps_sha256':hashlib.sha256((F/'DIAGNOSTIC_MAP_BINDINGS.json').read_bytes()).hexdigest(),'no_native_started':True}))
'''
print(subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(remote)],input=json.dumps({'PARENT_OPERATORS.json':bundle,'DIAGNOSTIC_MAP_BINDINGS.json':maps}).encode()).decode())
for name in ['sync_metadata.py','verify_diagnostic_raw.py']:
    s=(OLD/name).read_text(encoding='utf-8').replace('F11_optics_hysteresis_stall_20261027','F12_kernel_drop_terminal_20261027')
    if name=='verify_diagnostic_raw.py':
        s=s.replace("['L01_DIAG','L02_DIAG','L03_DIAG']",repr(list(maps)))
        a=s.index("expected_map={'L01_DIAG'");b=s.index("assert game['maps']",a)
        s=s[:a]+"expected_map=json.loads((F/'DIAGNOSTIC_MAP_BINDINGS.json').read_text(encoding='utf-8'))[name]\n"+s[b:]
    if name=='sync_metadata.py':
        s=s.replace("list(p.glob('*/*.json'))","list(p.glob('*/*.json'))")
        s=s.replace("'status':json.loads((F/'STATUS.json').read_text(encoding='utf-8'))['status']","'status':json.loads((F/'STATUS.json').read_text(encoding='utf-8'))['status'] if (F/'STATUS.json').exists() else 'NOT_STARTED'")
    ast.parse(s);(F/name).write_text(s,encoding='utf-8')
