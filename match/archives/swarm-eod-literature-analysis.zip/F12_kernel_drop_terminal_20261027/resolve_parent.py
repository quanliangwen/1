from pathlib import Path
import json,datetime,subprocess,shlex,statistics
F=Path(__file__).resolve().parent;OLD=F.parent/'F11_optics_hysteresis_stall_20261027'
assert not(F/'PREDECLARATION.json').exists()
old=json.loads((OLD/'PREDECLARATION.json').read_text(encoding='utf-8'))
choices=[(old['parent_confirmed_four_cohort_mean'],1,old['parent'])]
for v in ['L01','L02','L03']:
    P=OLD/(v+'_PERF')
    if not(P/'STATUS.json').exists():
        assert json.loads((OLD/(v+'_DIAG')/'MECHANISM_REVIEW.json').read_text(encoding='utf-8'))['start_five_map_now'] is False
        continue
    state=json.loads((P/'STATUS.json').read_text(encoding='utf-8'))
    assert state['status'] in ['EARLY_SCREENED_VALID_SCORE','COMPLETE_ALL_EIGHT_PAIRED_GROUPS']
    a=[];b=[]
    for item in state['completed']:
        G=P/(item['version']+'_'+item['cohort'])
        receipt=json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'));assert receipt['valid']
        d=json.loads((G/'RESULT.json').read_text(encoding='utf-8'))
        (a if item['version']==v else b).append(d['equal_weight_mean'])
    if len(a)==len(b)==4 and statistics.mean(a)>statistics.mean(b):
        build=json.loads((OLD/v/'BUILD.json').read_text(encoding='utf-8'))
        choices.append((statistics.mean(a),0,build))
mean,_,parent=max(choices,key=lambda x:(x[0],x[1]))
decl=json.loads((F/'PREPARATION_DECLARATION.json').read_text(encoding='utf-8'))
decl.update(status='PARENT_RESOLVED_BEFORE_PRODUCTION_SOURCE_MUTATION',control_id=parent['candidate_id'],parent=parent,parent_confirmed_four_cohort_mean=mean)
data=(json.dumps(decl,ensure_ascii=False,indent=2)+'\n').encode()
code=r'''
from pathlib import Path
import sys,json,hashlib,fcntl
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
F=H/'F12_kernel_drop_terminal_20261027';OLD=H/'F11_optics_hysteresis_stall_20261027'
assert not(F/'PREDECLARATION.json').exists() and not(OLD/'FIRST_NATIVE_ERROR.json').exists()
for v in ['L01','L02','L03']:
 p=OLD/(v+'_PERF')/'STATUS.json'
 if p.exists():
  s=json.loads(p.read_text());assert s['status'] in ['EARLY_SCREENED_VALID_SCORE','COMPLETE_ALL_EIGHT_PAIRED_GROUPS']
  proc=Path('/proc')/str(s['pid'])/'stat';assert not proc.exists() or proc.read_text().split()[2]=='Z'
 else:assert json.loads((OLD/(v+'_DIAG')/'MECHANISM_REVIEW.json').read_text())['start_five_map_now'] is False
a=json.loads((R/'solver_study/heuristic_20261016.json').read_text());assert not a.get('active_processes') and not a.get('current_formal_active')
with (R/'solver_study/serial_evaluation.lock').open('a+') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 b=sys.stdin.buffer.read();d=json.loads(b);parent=d['parent'];S=Path(parent['path'])/'source'
 assert hashlib.sha256(Path(parent['zip']).read_bytes()).hexdigest()==parent['zip_sha256']
 assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in S.iterdir() if p.is_file()}==parent['source_files']
 (F/'PREDECLARATION.json').write_bytes(b)
 print(json.dumps({'control_id':d['control_id'],'parent_mean':d['parent_confirmed_four_cohort_mean'],'sha256':hashlib.sha256(b).hexdigest(),'source_zip_sha256':parent['zip_sha256'],'no_native_started':True}))
'''
p=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=data)
(F/'PREDECLARATION.json').write_bytes(data);(F/'PARENT_RESOLUTION_RECEIPT.json').write_bytes(p)
print(p.decode())
