from pathlib import Path
import json,base64,subprocess,shlex
F=Path(__file__).resolve().parent
assets=json.loads((F/'OBSERVER_ASSETS.json').read_text(encoding='utf-8'))
test=r'''
from pathlib import Path
import sys,json,types,traceback,datetime,ast,hashlib,base64
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
F=H/'F12_kernel_drop_terminal_20261027';O=F/'observer_preparation';W=O/'reference_workspace'
report={'status':'STARTED','checks':[],'game_rounds':0}
def check(n,x):
 assert x,n
 report['checks'].append(n)
try:
 sys.path.insert(0,str(W/'src'))
 import numpy as np,cv2,pandas
 import swarm_rescue.solutions.bearing_core as bc
 import swarm_rescue.solutions.bearing_memory as bm
 from swarm_rescue.solutions.active_coverage import ActiveCoverageMixin
 from swarm_rescue.solutions.my_drone_eval import MyDroneEval
 from swarm_rescue.launcher import Launcher
 from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
 import numpy.random.mtrand
 check('native_runtime_unchanged',(np.__version__,pandas.__version__,cv2.__version__)==('1.26.4','3.0.6','4.11.0'))
 check('true_active_drop_provider',next(c.__name__ for c in MyDroneEval.__mro__ if '_maybe_place' in c.__dict__)=='ActiveCoverageMixin')
 check('actual_reference_payload',Path(bm.__file__).resolve()==(W/'src/swarm_rescue/solutions/bearing_memory.py').resolve())
 newbc=types.ModuleType('diagnostic_core_shadow');exec(compile((O/'source/bearing_core.py').read_text(),'profile_bearing_core','exec'),newbc.__dict__)
 newbm=types.ModuleType('diagnostic_memory_shadow');oldmodule=sys.modules['swarm_rescue.solutions.bearing_core']
 sys.modules['swarm_rescue.solutions.bearing_core']=newbc
 try:exec(compile((O/'source/bearing_memory.py').read_text(),'profile_bearing_memory','exec'),newbm.__dict__)
 finally:sys.modules['swarm_rescue.solutions.bearing_core']=oldmodule
 rng=np.random.RandomState(615)
 for shape in [(1,1),(3,5),(400,600)]:
  mask=rng.rand(*shape)<.3;coarse=((shape[0]+1)//2,(shape[1]+1)//2);counter={}
  a=bc.fine_any_to_four(mask,coarse);b=newbc.fine_any_to_four(mask,coarse,_profile=counter)
  check('profile_projection_exact_'+str(shape),np.array_equal(a,b) and counter['calls']==1)
 counter={};bits=np.arange(256,dtype=np.uint8)
 check('profile_all256_incidence_exact',np.array_equal(bc.independent_incidence(bits),newbc.independent_incidence(bits,_profile=counter)) and counter['calls']==1)
 a=bm.BearingMemory(800,800,identifier=0,team_size=5);b=newbm.BearingMemory(800,800,identifier=0,team_size=5)
 for key in ['hits','free','visits','bearing_bits']:
  x=getattr(a,key);x[:]=rng.randint(0,2 if x.dtype==bool else 8,x.shape);getattr(b,key)[:]=x
 a.nonwall_mask=rng.rand(*a.hits.shape)<.01;b.nonwall_mask=a.nonwall_mask.copy()
 sender=bm.BearingMemory(800,800,identifier=1,team_size=5)
 sender.hits[:]=rng.randint(0,8,sender.hits.shape);sender.free[:]=rng.rand(*sender.free.shape)<.5
 sender.visits[:]=rng.randint(0,255,sender.visits.shape);sender.bearing_bits[:]=rng.randint(0,256,sender.bearing_bits.shape)
 full=sender.packet();legacy=full[0]
 for step in range(16):
  if step%4==0:
   mask=rng.rand(*a.hits.shape)<.02;a.nonwall_mask=mask.copy();b.nonwall_mask=mask.copy()
  elif step%4==1:
   a.nonwall_mask[10:30,20:40]=~a.nonwall_mask[10:30,20:40];b.nonwall_mask[:]=a.nonwall_mask
  elif step%4==2:
   a.hits[10:30,10:30]=0;b.hits[10:30,10:30]=0;a.bearing_bits[5:15,5:15]=0;b.bearing_bits[5:15,5:15]=0
  packet=full
  if step%4==1:packet=legacy
  elif step%4==2:packet=(legacy,(np.array([14,11,14],np.int32),np.array([1,4,128],np.uint8)))
  elif step%4==3:packet=(legacy,(np.empty(0,np.int32),np.empty(0,np.uint8)))
  a.merge(packet);b.merge(packet)
  check('profile_full_merge_exact_'+str(step),all(np.array_equal(getattr(a,k),getattr(b,k)) for k in ['hits','free','visits','bearing_bits']) and a._surface_revision==b._surface_revision and a.bearing_merged_packets==b.bearing_merged_packets)
 image=(rng.rand(800,800)<.03).astype(np.uint8);profile={}
 x,xa=bc.corroborated_map(image,a.hits,a.bearing_bits,800,800,a.nonwall_mask)
 y,ya=newbc.corroborated_map(image,b.hits,b.bearing_bits,800,800,b.nonwall_mask,_profile=profile)
 check('profile_actual_render_consumer_exact',np.array_equal(x,y) and xa==ya)
 check('all_profile_sections_reached',all(profile[k]['calls']>0 for k in ['render_measured_projection','render_nonwall_projection','render_incidence']) and b.kernel_diagnostics['nonwall_projection']['calls']>0 and b.kernel_diagnostics['received_bearing_union']['calls']>0)
 diag=types.ModuleType('diagnostic_mixin_shadow');exec(compile((O/'source/diagnostic_mixin.py').read_text(),'diagnostic_mixin','exec'),diag.__dict__)
 class Parent:
  _maybe_place=ActiveCoverageMixin._maybe_place
 class Probe(diag.DiagnosticMixin,Parent):pass
 for name in ['no_goal','near_goal','far_goal','illegal_current','pending','empty','submitted','retry']:
  def fixture(cls):
   d=object.__new__(cls);d.carried_bombs_count=lambda:1;d.identifier=0;d.submitted=False;d.pose=np.zeros(2);d.pending_drop=None
   d.last_attempt_step=-100;d.placement_goal=None;d.placement_arrival_radius=20.;d._placement_allowed=lambda step,semantic:True
   d._remaining_steps=lambda:80.;d.elapsed_walltime=171.;d.walltime_limit=180.;d.limit=5000;d.PLAN_START_RATIO=.1
   if name=='near_goal':d.placement_goal=np.array([4.,0.])
   if name=='far_goal':d.placement_goal=np.array([200.,0.])
   if name=='illegal_current':d._placement_allowed=lambda step,semantic:False
   if name=='pending':d.pending_drop=(1,d.pose.copy(),2099)
   if name=='empty':d.carried_bombs_count=lambda:0
   if name=='submitted':d.submitted=True
   if name=='retry':d.last_attempt_step=2099
   return d
  old=fixture(Parent);new=fixture(Probe);ca={};cb={};old._maybe_place(ca,2100,[]);new._maybe_place(cb,2100,[])
  check('advisor_command_unchanged_'+name,ca==cb)
 advisor=types.ModuleType('terminal_advisor_shadow');exec(compile((O/'source/diagnostic_terminal_advisor.py').read_text(),'terminal_advisor','exec'),advisor.__dict__)
 check('terminal_invalid_position_abstains',advisor.terminal_candidate(a,[np.nan,0])['reason']=='invalid_position')
 empty=bm.BearingMemory(256,128,identifier=0,team_size=5);empty.free[:]=True
 before={k:getattr(empty,k).copy() for k in ['hits','free','visits','bearing_bits']}
 check('terminal_no_evidence_abstains',advisor.terminal_candidate(empty,[0.,0.])['reason']=='no_unresolved_evidence')
 check('terminal_advisor_no_own_array_mutation',all(np.array_equal(getattr(empty,k),v) for k,v in before.items()))
 report.update(status='PASS',count=len(report['checks']),source_sha256=json.loads((O/'SOURCE_BINDING.json').read_text())['observer_files'],
  scope='Actual synthetic consumer/command checks; diagnostic helpers do not replace policy, but counters/advisors add runtime. No control/game/replay, native dependencies unchanged, no candidate created.')
except BaseException:report.update(status='FAIL',error=traceback.format_exc());raise
finally:(O/'QUALIFICATION_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
'''
remote=r'''
from pathlib import Path
import sys,json,base64,hashlib,ast,shutil,subprocess,os
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F12_kernel_drop_terminal_20261027'
d=json.load(sys.stdin);P=json.loads((F/'PREDECLARATION.json').read_text())['parent'];O=F/'observer_preparation';assert not O.exists();O.mkdir()
assets=d['assets'];assert all(hashlib.sha256(base64.b64decode(v['base64'])).hexdigest()==v['sha256'] for v in assets.values())
scope={};exec(base64.b64decode(assets['kernel_profile_source.py']['base64']).decode(),scope)
source={p.name:p.read_text() for p in (Path(P['path'])/'source').iterdir() if p.is_file()}
assert {k:hashlib.sha256(v.encode()).hexdigest() for k,v in source.items() if '\r' not in v} # byte hashes checked below, normalization may differ
assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(P['path'])/'source').iterdir() if p.is_file()}==P['source_files']
profile=scope['instrument'](source);S=O/'source';S.mkdir()
for name,text in profile.items():(S/name).write_text(text)
for name in ['diagnostic_mixin.py','diagnostic_terminal_advisor.py']:(S/name).write_bytes(base64.b64decode(assets[name]['base64']))
p=S/'my_drone_eval.py';s=p.read_text();assert s.count('class MyDroneEval(')==1
s=s.replace('class MyDroneEval(','class BaseParent(',1)+'\nfrom swarm_rescue.solutions.diagnostic_mixin import DiagnosticMixin\nclass MyDroneEval(DiagnosticMixin,BaseParent):\n    pass\n';p.write_text(s)
for p in S.glob('*.py'):ast.parse(p.read_text())
binding={'production_parent':P,'normalization':'Source text read/write normalizes newline only in diagnostic copy. Parent bytes unchanged; all diag source SHA bound.',
 'observer_files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in S.iterdir() if p.is_file()},'assets_sha256':{k:v['sha256'] for k,v in assets.items()},'game_rounds':0,'new_candidate':False}
(O/'SOURCE_BINDING.json').write_text(json.dumps(binding,indent=2)+'\n')
blue=Path(json.loads((H/'F07_evidence_three_directions_20261026/infrastructure/PREDECLARATION.json').read_text())['blue_workspace'])
W=O/'reference_workspace';shutil.copytree(blue,W,ignore=shutil.ignore_patterns('solutions','__pycache__','*.pyc','.git','.pytest_cache'));sol=W/'src/swarm_rescue/solutions';sol.mkdir()
for p in (Path(P['path'])/'source').iterdir():shutil.copy2(p,W/'req.txt' if p.name=='req.txt' else sol/p.name)
p=O/'observer_qualify.py';p.write_bytes(base64.b64decode(d['test']));ast.parse(p.read_text())
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with (O/'qualification_console.log').open('x') as log:result=subprocess.run(['bash',str(R/'run_server.sh'),'-u',str(p)],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
r=json.loads((O/'QUALIFICATION_RESULT.json').read_text());print(json.dumps({'status':r['status'],'checks':len(r['checks']),'error':r.get('error'),'source_binding_sha256':hashlib.sha256((O/'SOURCE_BINDING.json').read_bytes()).hexdigest()}));raise SystemExit(result.returncode)
'''
p=subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(remote)],input=json.dumps({'assets':assets,'test':base64.b64encode(test.encode()).decode()}).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(F/'observer_first_qualification_console.txt').write_bytes(p.stdout+p.stderr)
print(p.stdout.decode(errors='replace'));print(p.stderr.decode(errors='replace'))
raise SystemExit(p.returncode)
