from pathlib import Path
import subprocess,shlex
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import json,hashlib,shutil,ast,zipfile,datetime,yaml
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F12_kernel_drop_terminal_20261027'
decl=json.loads((F/'PREDECLARATION.json').read_text());P=decl['parent']
assert json.loads((F/'PARENT_M04_DIAG/CLIENT_FIRST_RAW_REVIEW.json').read_text())['valid']
admission=json.loads((F/'PARENT_M04_DIAG/ANALYSIS.json').read_text());assert admission['gates']['M01'] is True
G=F/'M01';assert not G.exists();G.mkdir();S=G/'source';shutil.copytree(Path(P['path'])/'source',S)
p=S/'bearing_core.py';text=p.read_text();tree=ast.parse(text);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='fine_any_to_four')
new="""def fine_any_to_four(mask, shape):
    'Exact 2x2 Boolean union, including zero padding at odd edges.'
    fine = np.asarray(mask, bool)
    if fine.ndim != 2 or fine.shape[0] > 2 * shape[0] or fine.shape[1] > 2 * shape[1]:
        return np.zeros(shape, bool)
    result = np.zeros(shape, bool)
    for dr in range(2):
        for dc in range(2):
            part = fine[dr::2, dc::2]
            result[:part.shape[0], :part.shape[1]] |= part
    return result
"""
lines=text.splitlines(keepends=True);p.write_text(''.join(lines[:fn.lineno-1])+new+''.join(lines[fn.end_lineno:]))
after=ast.parse(p.read_text());before_other=[ast.dump(n) for n in tree.body if n is not fn]
after_other=[ast.dump(n) for n in after.body if not(isinstance(n,ast.FunctionDef) and n.name=='fine_any_to_four')]
assert before_other==after_other
for p in S.glob('*.py'):ast.parse(p.read_text())
assert type(yaml.safe_load((S/'team_info.yml').read_text())['team_number']) is int and yaml.safe_load((S/'team_info.yml').read_text())['team_number']==615
assert {s.strip() for s in (S/'req.txt').read_text().splitlines() if s.strip()}=={'numpy==1.26.4','pandas==2.2.3','opencv-contrib-python==4.11.0.86'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();files={p.name:sha(p) for p in S.iterdir() if p.is_file()}
changed=[n for n in files if files[n]!=P['source_files'][n]];assert changed==['bearing_core.py']
z=G/'team615_red_v17.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED) as out:
 for p in sorted(S.iterdir()):out.write(p,p.name)
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':'M01','path':str(G),'zip':str(z),'zip_sha256':sha(z),'source_files':files,'changed_files':changed,'parent_id':decl['control_id'],'parent_zip_sha256':P['zip_sha256'],'declaration_sha256':sha(F/'PREDECLARATION.json'),'admission_sha256':sha(F/'PARENT_M04_DIAG/ANALYSIS.json'),'release_status':'INTERNAL_NOT_RELEASED','scope':'Pure function exact Boolean reduction only; no retained observer/advisor, route budget, score objective, caching or sensor changes.'}
(G/'BUILD.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
'''
p=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)])
(F/'M01_BUILD.json').write_bytes(p)
import json
d=json.loads(p);print(json.dumps({k:d[k] for k in ['candidate_id','zip_sha256','changed_files','parent_id','release_status']}))
