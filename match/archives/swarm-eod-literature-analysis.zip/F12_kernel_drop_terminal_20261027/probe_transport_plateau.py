from pathlib import Path
import subprocess,shlex,json
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import sys,json,hashlib,datetime,traceback
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F12_kernel_drop_terminal_20261027'
D=F/'TRANSPORT_PLATEAU_PROBE_DECLARATION.json';G=F/'TRANSPORT_PLATEAU_PROBE_FIRST.json';assert not D.exists() and not G.exists()
D.write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'One synthetic geometry plateau measurement using actual unchanged trust-region method. No candidate/source mutation, game, actual BLUE state or recorded observation input. Fixed synthetic centre is not map truth or production data. First failure retained/no retry.',
 'fixture':'owner7 at(4,8), existing(3,10), alternative(3,6), synthetic observed centre(4,14), wall-value(1,8)=1, radius64, cap64, only two allowed destinations. Compare exact coverage/RED route and known-centre geodesic proxy; no actual BLUE score claim.'})+'\n')
report={'status':'STARTED','checks':[]}
def check(n,x):
 assert x,n
 report['checks'].append(n)
try:
 sys.path.insert(0,str(F/'observer_preparation/reference_workspace/src'))
 import numpy as np
 from swarm_rescue.solutions.greedy_mapping import MapMemory
 from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
 from swarm_rescue.solutions.team_coverage import path_costs
 from swarm_rescue.solutions import trust_region_cover as trust
 source=H/'F09_route_and_views_20261026/K01/source/trust_region_cover.py'
 check('actual_unchanged_method',hashlib.sha256(Path(trust.__file__).read_bytes()).hexdigest()==hashlib.sha256(source.read_bytes()).hexdigest())
 m=MapMemory(256,128);m.free[:]=True;pm=GeometryPlanningMemory(m)
 values=np.zeros(m.shape,np.float32);values[1,8]=1.
 pm._coverage_values_cache=(64.,values,np.zeros(m.shape,bool))
 allowed=np.zeros(m.shape,bool);allowed[3,10]=True;allowed[3,6]=True
 old={7:[m.cell_to_world((3,10))]};alt={7:[m.cell_to_world((3,6))]};agents={7:(m.cell_to_world((4,8)),1)}
 result=trust.refine_trust_region(m,agents,[],64.,old,travel_budget={7:64.},forbidden_mask=~allowed,_prepared=pm)
 walkable=pm.free&~pm.blocked();from_owner=path_costs(pm,walkable,(4,8));from_centre=path_costs(pm,walkable,(4,14))
 score=lambda plan:float(values[trust._coverage_mask(pm,plan[7],64.)].sum())
 red_old=float(from_owner[3,10]);red_alt=float(from_owner[3,6]);blue_old=float(from_centre[3,10]);blue_alt=float(from_centre[3,6])
 check('original_keeps_equal_value_incumbent',np.array_equal(result[7][0],old[7][0]))
 check('positive_observed_coverage_exact_tie',score(result)==score(alt)==1.)
 check('RED_full_route_equal',abs(red_old-red_alt)<1e-8 and red_alt<=64.)
 check('known_centre_route_proxy_larger',blue_alt>blue_old)
 check('trust_radius_preserved',np.linalg.norm(old[7][0]-alt[7][0])<=1.25*64.)
 check('destination_allowed_and_slots_preserved',allowed[m.world_to_cell(alt[7][0])] and len(alt[7])==len(old[7]) and set(alt)==set(old))
 report.update(status='PASS',count=len(report['checks']),old_coverage=score(old),alternative_coverage=score(alt),RED_old_route=red_old,RED_alternative_route=red_alt,known_centre_old_route=blue_old,known_centre_alternative_route=blue_alt,
  note='Synthetic Pareto opportunity only. Transport distance is an own-map proxy, not actual BLUE route or official score; geometry/dynamics/visibility can break correlation. Need fresh own-state centre/support/tied-feasible opportunity diagnosis and actual five-map scoring before implementation/promoting.')
except BaseException:report.update(status='FAIL',error=traceback.format_exc());raise
finally:G.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
'''
cmd='env -u MATCH_PHASE_ID -u PYGLET_HEADLESS -u PYTHONPATH MATCH_HEURISTIC_ID=heuristic_20261015T2047Z bash /home/junhao/quan/parallel_test_solver/match/run_server.sh -u -c '+shlex.quote(code)
p=subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60',cmd],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert not(F/'transport_plateau_first_console.txt').exists()
(F/'transport_plateau_first_console.txt').write_bytes(p.stdout+p.stderr)
if p.returncode:
 print(p.stdout.decode(errors='replace')[-3000:]);print(p.stderr.decode(errors='replace')[-3000:]);raise SystemExit(p.returncode)
d=json.loads(p.stdout.decode().strip().splitlines()[-1]);(F/'TRANSPORT_PLATEAU_PROBE_FIRST.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
print(json.dumps(d))
