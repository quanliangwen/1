"""Read-only diagnostic on current own map, never a controller policy or replay."""
import time
import numpy as np
import cv2
from swarm_rescue.solutions.joint_survey import evidence_uncertainty, visible_gain
from swarm_rescue.solutions.completion_consensus import _sortie_known_route


def terminal_candidate(memory, position, seconds=1.0):
    deadline = time.perf_counter() + seconds
    position = np.asarray(position, float)
    if position.shape != (2,) or not np.isfinite(position).all():
        return {'reason': 'invalid_position'}
    weights, opaque = evidence_uncertainty(memory)
    if weights.shape != memory.shape or opaque.shape != memory.shape:
        return {'reason': 'invalid_own_map_shape'}
    if time.perf_counter() >= deadline:
        return {'reason': 'deadline_during_evidence'}
    if float(weights.sum()) < 2:
        return {'reason': 'no_unresolved_evidence'}
    walkable = memory.free & ~memory.blocked()
    start = memory.world_to_cell(position)
    rr, cc = np.indices(memory.shape)
    metric = np.hypot(rr - start[0], cc - start[1]) * memory.CELL
    radius = int(np.ceil(240. / memory.CELL))
    proxy = cv2.boxFilter(weights, -1, (2*radius+1, 2*radius+1), normalize=False,
                         borderType=cv2.BORDER_CONSTANT)
    eligible = walkable & (metric >= 48.) & (metric <= 144.)
    rank = np.where(eligible, proxy / (1. + metric/120.), -np.inf)
    if not np.isfinite(rank).any():
        return {'reason': 'no_nearby_known_view'}
    baseline = visible_gain(start, weights, opaque, memory.CELL)
    selected = []; best = None; searched = 0
    for flat in np.argsort(rank.ravel())[::-1]:
        if time.perf_counter() >= deadline or len(selected) >= 6:
            break
        cell = tuple(map(int, np.unravel_index(flat, rank.shape)))
        if not np.isfinite(rank[cell]) or rank[cell] <= 0:
            break
        if any((cell[0]-r)**2+(cell[1]-c)**2 < 9 for r, c in selected):
            continue
        selected.append(cell)
        path = _sortie_known_route(memory, start, cell, walkable, deadline, max_pops=4096)
        searched += 1
        if path is None:
            continue
        points = [position] + [memory.cell_to_world(c) for c in path[1:]]
        length = sum(float(np.linalg.norm(b-a)) for a,b in zip(points, points[1:]))
        demand = length / 2. + 24. + 24.
        if demand > 120.:
            continue
        gain = visible_gain(cell, weights, opaque, memory.CELL) - baseline
        if gain < 2.:
            continue
        value = (gain/(1.+length/120.), -length, -cell[0], -cell[1])
        if best is None or value > best[0]:
            best = (value, memory.cell_to_world(cell).tolist(), gain, length, demand, len(path))
    if best is None:
        return {'reason': 'no_positive_certified_view', 'tested': searched,
                'deadline_reached': time.perf_counter() >= deadline,
                'uncertainty_proxy': float(weights.sum())}
    return {'reason': 'positive_certified_view', 'target': best[1],
            'incremental_evidence_proxy_not_official_score': best[2],
            'known_oneway_route_length': best[3], 'conservative_steps': best[4],
            'path_cells': best[5], 'tested': searched, 'returns_to_rally_certified': False,
            'scope': 'Own live map only; advisory does not alter goals, routes, commands or submission. A known one-way path is not a relay or team-coordination certificate.'}
