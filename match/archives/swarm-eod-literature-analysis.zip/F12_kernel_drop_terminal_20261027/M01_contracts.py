    import ast,types,zipfile
    from swarm_rescue.solutions import bearing_core as bc
    from swarm_rescue.solutions import bearing_memory as bm
    parent=json.loads((F.parent/'PREDECLARATION.json').read_text())['parent']
    ref=Path(parent['path'])/'source/bearing_core.py';tree=ast.parse(ref.read_text())
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='fine_any_to_four')
    old_scope={'np':np};exec(compile(ast.Module(body=[fn],type_ignores=[]),str(ref),'exec'),old_scope)
    original=old_scope['fine_any_to_four'];actual=bc.fine_any_to_four
    rng=np.random.RandomState(615)
    for i,(h,w,sh,sw) in enumerate([(0,0,1,1),(1,1,1,1),(1,2,1,1),(2,1,1,1),(2,2,1,1),
        (3,5,2,3),(4,6,2,3),(3,6,2,3),(4,5,2,3),(5,6,2,3),(400,400,200,200),(401,399,201,200),(400,600,200,300)]):
        for probability in [0.,.01,.1,.5,1.]:
            mask=rng.rand(h,w)<probability;a=original(mask,(sh,sw));b=actual(mask,(sh,sw))
            check('actual_zip_projection_%d_%s'%(i,probability),a.dtype==b.dtype and a.shape==b.shape and np.array_equal(a,b))
    for i,mask in enumerate([np.zeros(4),np.zeros((2,2,2)),np.zeros((6,2)),np.zeros((2,8)),np.ones((1,1),np.uint8)]):
        check('invalid_or_converted_input_'+str(i),np.array_equal(original(mask,(2,3)),actual(mask,(2,3))))
    for i,mask in enumerate([rng.rand(21,33)<.2,(rng.rand(21,33)<.2).T,(rng.rand(21,33)<.2)[::-1,::2]]):
        shape=((mask.shape[0]+1)//2,(mask.shape[1]+1)//2)
        check('noncontiguous_input_'+str(i),np.array_equal(original(mask,shape),actual(mask,shape)))
    a=bm.BearingMemory(800,800,identifier=0,team_size=5);b=bm.BearingMemory(800,800,identifier=0,team_size=5)
    for key in ['hits','free','visits','bearing_bits']:
        x=getattr(a,key);x[:]=rng.randint(0,2 if x.dtype==bool else 8,x.shape);getattr(b,key)[:]=x
    a.nonwall_mask=rng.rand(*a.hits.shape)<.01;b.nonwall_mask=a.nonwall_mask.copy()
    sender=bm.BearingMemory(800,800,identifier=1,team_size=5)
    sender.hits[:]=rng.randint(0,8,sender.hits.shape);sender.free[:]=rng.rand(*sender.free.shape)<.5
    sender.visits[:]=rng.randint(0,255,sender.visits.shape);sender.bearing_bits[:]=rng.randint(0,256,sender.bearing_bits.shape)
    full=sender.packet();legacy=full[0]
    for step in range(16):
        if step%4==0:
            mask=rng.rand(*a.hits.shape)<.02;a.nonwall_mask=mask.copy();b.nonwall_mask=mask.copy()
        elif step%4==1:
            a.nonwall_mask[10:30,20:40]=~a.nonwall_mask[10:30,20:40];b.nonwall_mask[:]=a.nonwall_mask
        elif step%4==2:
            a.hits[10:30,10:30]=0;b.hits[10:30,10:30]=0;a.bearing_bits[5:15,5:15]=0;b.bearing_bits[5:15,5:15]=0
        packet=full
        if step%4==1:packet=legacy
        elif step%4==2:packet=(legacy,(np.array([14,11,14],np.int32),np.array([1,4,128],np.uint8)))
        elif step%4==3:packet=(legacy,(np.empty(0,np.int32),np.empty(0,np.uint8)))
        bm.fine_any_to_four=original;bc.fine_any_to_four=original
        try:a.merge(packet)
        finally:bm.fine_any_to_four=actual;bc.fine_any_to_four=actual
        b.merge(packet)
        check('actual_consumer_own_retraction_and_packet_'+str(step),all(np.array_equal(getattr(a,k),getattr(b,k)) for k in ['hits','free','visits','bearing_bits']) and a._surface_revision==b._surface_revision and a.bearing_merged_packets==b.bearing_merged_packets)
    image=(rng.rand(800,800)<.03).astype(np.uint8)
    bc.fine_any_to_four=original
    try:x,xa=bc.corroborated_map(image,a.hits,a.bearing_bits,800,800,a.nonwall_mask)
    finally:bc.fine_any_to_four=actual
    y,ya=bc.corroborated_map(image,b.hits,b.bearing_bits,800,800,b.nonwall_mask)
    check('actual_render_consumer_identical',np.array_equal(x,y) and xa==ya)
    build=json.loads((C/'BUILD.json').read_text())
    check('only_pure_function_file_changed',build['changed_files']==['bearing_core.py'])
    after=ast.parse((C/'source/bearing_core.py').read_text())
    check('other_core_functions_AST_unchanged',[ast.dump(n) for n in tree.body if n is not fn]==[ast.dump(n) for n in after.body if not(isinstance(n,ast.FunctionDef) and n.name=='fine_any_to_four')])
    with zipfile.ZipFile(build['zip']) as archive:
        payload={n:hashlib.sha256(archive.read(n)).hexdigest() for n in archive.namelist()}
    check('actual_zip_all_source_bytes_bound',payload==build['source_files'] and hashlib.sha256(Path(build['zip']).read_bytes()).hexdigest()==build['zip_sha256'])
    check('no_diagnostic_helper_in_production_zip',not any(n.startswith('diagnostic_') for n in payload))
