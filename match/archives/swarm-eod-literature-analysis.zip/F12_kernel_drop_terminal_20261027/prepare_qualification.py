from pathlib import Path
import ast
F=Path(__file__).resolve().parent;OLD=F.parent/'F11_optics_hysteresis_stall_20261027'
assert not(F/'qualify.py').exists()
s=(OLD/'qualify.py').read_text(encoding='utf-8').replace('F11_optics_hysteresis_stall_20261027','F12_kernel_drop_terminal_20261027').replace("['L01','L02','L03']","['M01','M02','M03']")
ast.parse(s);(F/'qualify.py').write_text(s,encoding='utf-8')
(F/'qualification_ABI_checks.py').write_bytes((OLD/'qualification_ABI_checks.py').read_bytes())
print('Prepared independent actual ZIP/source/ABI qualification; no game launched')
