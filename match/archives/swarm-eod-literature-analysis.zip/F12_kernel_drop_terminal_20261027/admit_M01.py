from pathlib import Path
import json,datetime,subprocess,shlex
F=Path(__file__).resolve().parent;G=F/'M01_DIAG'
assert not(G/'MECHANISM_REVIEW.json').exists()
assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'))['valid']
contract=json.loads((F/'M01/CONTRACT_RESULT.json').read_text(encoding='utf-8'));assert contract['status']=='PASS'
build=json.loads((F/'M01/BUILD.json').read_text(encoding='utf-8'))
assert contract['source_zip_sha256']==build['zip_sha256']
stage=json.loads((G/'STAGING.json').read_text(encoding='utf-8'));assert stage['production_candidate_sha256']==build['zip_sha256']
assert json.loads((F/'PARENT_M04_DIAG/ANALYSIS.json').read_text(encoding='utf-8'))['gates']['M01'] is True
events=json.loads((G/'EVENTS.json').read_text(encoding='utf-8'));last={}
order=lambda s:(s['step'],s['costs']['control_total']['calls'])
for name in ['F12_DIAG_TICK','F12_SUBMIT_DECISION','F12_SUBMIT_CALL']:
    for s in events[name]:
        if s['owner'] not in last or order(s)>=order(last[s['owner']]):last[s['owner']]=s
kernels={}
for s in last.values():
    for kind,values in s['kernel_diagnostics'].items():
        d=kernels.setdefault(kind,{})
        for key,value in values.items():d[key]=max(d.get(key,0),value) if key=='max_seconds' else d.get(key,0)+value
names=['nonwall_projection','render_measured_projection','render_nonwall_projection']
calls=sum(kernels.get(k,{}).get('calls',0) for k in names)
result=json.loads((G/'RESULT.json').read_text(encoding='utf-8'));assert result['valid'] and not result['row']['crashed']
admit=calls>0
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':'M01','start_five_map_now':admit,
 'source_zip_sha256':build['zip_sha256'],'qualification_first_checks':len(contract['checks']),
 'projection_calls_at_last_checkpoints':calls,'own_kernel_sums':kernels,
 'stock':[result['row']['placed'],result['row']['expected']],'diagnostic_steps':result['row']['timestep'],
 'diagnostic_seconds_not_speed_comparison':result['row']['walltime'],
 'diagnostic_map_score_not_performance':result['row']['phase']['score_map'],
 'reason':'Actual pure-helper usage observed after actual ZIP176 qualification/source and first client raw checks; exact functional equivalence already checked. Enter frozen original-five comparison vs true K01. No unpaired speed or score gain claim; observer/advisors change walltime. M02/M03 remain deferred. No source/clock/input/SDK/BLUE rescue.' if admit else 'No actual helper usage observed; stop expansion under frozen opportunity rule, not a global impossibility claim.'}
p=G/'MECHANISM_REVIEW.json';b=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode();p.write_bytes(b)
rf='/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F12_kernel_drop_terminal_20261027/M01_DIAG/MECHANISM_REVIEW.json'
code="from pathlib import Path;import sys;p=Path("+repr(rf)+");assert not p.exists();p.write_bytes(sys.stdin.buffer.read())"
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=b,check=True)
print(json.dumps({k:d[k] for k in ['candidate_id','start_five_map_now','projection_calls_at_last_checkpoints','stock','diagnostic_steps','diagnostic_seconds_not_speed_comparison']}))
