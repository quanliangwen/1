from pathlib import Path
import json,base64,ast,hashlib,subprocess,shlex,sys
F=Path(__file__).resolve().parent;OLD=F.parent/'F11_optics_hysteresis_stall_20261027'
v=sys.argv[1];assert v=='M01'
decl=json.loads((F/'PREDECLARATION.json').read_text(encoding='utf-8'));control=decl['control_id']
def common(s):
    return s.replace('F11_optics_hysteresis_stall_20261027','F12_kernel_drop_terminal_20261027').replace('f11pair_20261027_','f12pair_20261027_').replace('F11','F12').replace('L01',v).replace("'K01'",repr(control))
bundle={};manifest={}
for name in ['prepare_performance','launch_performance']:
    d=json.loads((OLD/'operators/L01'/(name+'.json')).read_text(encoding='utf-8'))
    d['code']=common(d['code'])
    d['code']=d['code'].replace('three predeclared optics, hysteresis and stagnation directions','predeclared kernel, late-drop and terminal directions; only candidates admitted by measured live opportunities')
    d['code']=d['code'].replace('F12_interleaved_candidate_vs_PJ01','F12_interleaved_candidate_vs_parent')
    d['code']=d['code'].replace('Audited review after each surviving pair; finite rule-based reviews follow CONTINUATION_AMENDMENT when enabled.','Agent reviews each surviving pair after first Windows raw checks; no live bridge or automatic approval.')
    for key in list(d['payload']):
        if key=='version':d['payload'][key]=v
        elif key.endswith(('.py','.json')):
            s=common(base64.b64decode(d['payload'][key]).decode())
            if key.endswith('.py'):ast.parse(s)
            d['payload'][key]=base64.b64encode(s.encode()).decode()
    ast.parse(d['code'])
    p=F/'operators'/v/(name+'.json');p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists()
    b=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode();p.write_bytes(b)
    key=str(p.relative_to(F)).replace('\\','/');bundle[key]=base64.b64encode(b).decode();manifest[key]=hashlib.sha256(b).hexdigest()
remote=r'''
from pathlib import Path
import json,base64,hashlib,sys
F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F12_kernel_drop_terminal_20261027')
d=json.load(sys.stdin);v=d['version'];out={};assert not(F/('OPERATOR_SHA_'+v+'.json')).exists()
for name,b in d['bundle'].items():
 p=F/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(base64.b64decode(b));out[name]=hashlib.sha256(p.read_bytes()).hexdigest()
(F/('OPERATOR_SHA_'+v+'.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
'''
result=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(remote)],input=json.dumps({'version':v,'bundle':bundle}).encode())
assert json.loads(result)==manifest;(F/('OPERATOR_SHA_'+v+'.json')).write_bytes(result)
for name in ['client_verify_finished_cohort.py','summarize_performance.py','review_pair.py','collect_finished.py','read_live.py']:
    p=F/name;assert not p.exists()
    s=common((OLD/name).read_text(encoding='utf-8')).replace('L02','M02').replace('L03','M03')
    ast.parse(s);p.write_text(s,encoding='utf-8')
print('Prepared two SHA-bound one-use operations and read-only analysis; no performance game launched')
