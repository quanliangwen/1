from pathlib import Path
import json,subprocess,shlex
F=Path(__file__).resolve().parent
assets=json.loads((F/'OBSERVER_ASSETS.json').read_text(encoding='utf-8'))
code=r'''
from pathlib import Path
import sys,json,hashlib,base64,ast,fcntl,shutil,subprocess,os,datetime
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F12_kernel_drop_terminal_20261027'
d=json.load(sys.stdin);v='M01';B=json.loads((F/v/'BUILD.json').read_text());assert json.loads((F/v/'CONTRACT_RESULT.json').read_text())['status']=='PASS'
for name in ['PARENT_M04','PARENT_M05']:
 G0=F/(name+'_DIAG');s=json.loads((G0/'STATUS.json').read_text());assert s['status'].endswith('DIAGNOSTIC_COMPLETE_AWAIT_ANALYSIS')
 p=Path('/proc')/str(s['pid'])/'stat';assert not p.exists() or p.read_text().split()[2]=='Z'
 assert json.loads((G0/'CLIENT_FIRST_RAW_REVIEW.json').read_text())['valid']
a=json.loads((F/'PARENT_M04_DIAG/ANALYSIS.json').read_text());b=json.loads((F/'PARENT_M05_DIAG/ANALYSIS.json').read_text())
assert a['gates']['M01'] is True and a['gates']['M02'] is False and b['gates']['M03'] is False
assert not(F/'FIRST_NATIVE_ERROR.json').exists() and not(F/'STOP_REQUESTED').exists()
activity=json.loads((R/'solver_study/heuristic_20261016.json').read_text());assert not activity.get('active_processes') and not activity.get('current_formal_active')
with (R/'solver_study/serial_evaluation.lock').open('a+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(Path(B['zip']))==B['zip_sha256']
admission={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'admitted_order':['M01'],'M01':{'admitted':True,'evidence':str(F/'PARENT_M04_DIAG/ANALYSIS.json')},'M02':{'admitted':False,'reason':'No declared fresh Map04 late legal no-goal opportunity; defer, not global impossibility.'},'M03':{'admitted':False,'reason':'Declared fresh Map05 did not complete all inventory/no positive terminal advisor; defer, not global impossibility.'},'no_candidate_created_for_M02_M03':True}
assert not(F/'DIRECTION_ADMISSION.json').exists();(F/'DIRECTION_ADMISSION.json').write_text(json.dumps(admission,indent=2)+'\n')
G=F/'M01_DIAG';assert not G.exists();G.mkdir();S=G/'source';S.mkdir()
binding=json.loads((F/'observer_preparation/SOURCE_BINDING.json').read_text());asset=d['kernel_profile_source.py'];raw=base64.b64decode(asset['base64']);assert hashlib.sha256(raw).hexdigest()==binding['assets_sha256']['kernel_profile_source.py']
scope={};exec(raw.decode(),scope)
source={p.name:p.read_text() for p in (Path(B['path'])/'source').iterdir() if p.is_file()}
assert {p.name:sha(p) for p in (Path(B['path'])/'source').iterdir() if p.is_file()}==B['source_files']
profile=scope['instrument'](source)
for name,text in profile.items():(S/name).write_text(text)
for name in ['diagnostic_mixin.py','diagnostic_terminal_advisor.py']:shutil.copy2(F/'observer_preparation/source'/name,S/name)
p=S/'my_drone_eval.py';s=p.read_text();assert s.count('class MyDroneEval(')==1;s=s.replace('class MyDroneEval(','class BaseParent(',1)+'\nfrom swarm_rescue.solutions.diagnostic_mixin import DiagnosticMixin\nclass MyDroneEval(DiagnosticMixin,BaseParent):\n    pass\n';p.write_text(s)
for p in S.glob('*.py'):ast.parse(p.read_text())
blue=Path(json.loads((H/'F07_evidence_three_directions_20261026/infrastructure/PREDECLARATION.json').read_text())['blue_workspace'])
W=R/'experiments/target90_20261012/official_workspaces/f12diag_20261027_M01';assert not W.exists()
shutil.copytree(blue,W,ignore=shutil.ignore_patterns('solutions','__pycache__','*.pyc','.git','.pytest_cache'));sol=W/'src/swarm_rescue/solutions';sol.mkdir()
for p in S.iterdir():shutil.copy2(p,W/'req.txt' if p.name=='req.txt' else sol/p.name)
(G/'STAGING.json').write_text(json.dumps({'utc':admission['utc'],'workspace':str(W),'source_files':{p.name:sha(p) for p in S.iterdir() if p.is_file()},'production_source':B['source_files'],'production_candidate_sha256':B['zip_sha256'],'not_for_performance_ranking':True},indent=2)+'\n')
(G/'PREDECLARATION.json').write_text(json.dumps({'utc':admission['utc'],'candidate_id':v,'source_zip_sha256':B['zip_sha256'],'kind':'ONE_FRESH_MAP04_RED_MECHANISM_ONLY','seed':None,'no_retry':True,'BLUE':False,'ranking':False,'mechanism':'Exact projection source equivalence qualified; verify actual projected-kernel invocation. Own diagnostic cost, not causal speed/score comparison. M02/M03 gates remain deferred regardless ancillary advisor outputs.'},indent=2)+'\n')
pre=(H/'F08_diagnosis_led_three_20261026/BASELINE_DIAG/preflight.py').read_text();ast.parse(pre);(G/'preflight.py').write_text(pre)
entry=json.loads((F/'PARENT_OPERATORS.json').read_text())['PARENT_M04'];runner=base64.b64decode(entry['runner_base64']).decode().replace('PARENT_M04','M01').replace("'new_algorithm':False","'new_algorithm':True").replace('PARENT_OBSERVER_NO_PERFORMANCE_RANKING','CANDIDATE_MECHANISM_NO_PERFORMANCE_RANKING')
ast.parse(runner);p=F/'run_M01_diagnostic.py';assert not p.exists();p.write_text(runner)
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with (F/'M01_diagnostic_coordinator.log').open('x') as log:proc=subprocess.Popen([str(R/'.venv/bin/python'),'-u',str(p)],cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
receipt={'utc':admission['utc'],'candidate_id':v,'pid':proc.pid,'starttime_ticks':(Path('/proc')/str(proc.pid)/'stat').read_text().split()[21],'candidate_sha256':B['zip_sha256'],'runner_sha256':sha(p),'only_one_RED_diagnostic':True}
(G/'LAUNCH_COORDINATOR.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
'''
print(subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps(assets).encode()).decode())
