from pathlib import Path
import json,datetime,sys,subprocess,shlex
F=Path(__file__).resolve().parent;name=sys.argv[1]
assert name in ['PARENT_M04_DIAG','PARENT_M05_DIAG'];G=F/name
assert not(G/'ANALYSIS.json').exists()
assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'))['valid']
e=json.loads((G/'EVENTS.json').read_text(encoding='utf-8'))
r=json.loads((G/'RESULT.json').read_text(encoding='utf-8'));assert r['valid'] and not r['row']['crashed']
last={}
for key in ['F12_DIAG_TICK','F12_SUBMIT_DECISION','F12_SUBMIT_CALL']:
    for s in e.get(key,[]):
        old=last.get(s['owner'])
        order=lambda x:(x['step'],x.get('costs',{}).get('control_total',{}).get('calls',0))
        if old is None or order(s)>=order(old):last[s['owner']]=s
control=sum(s['costs']['control_total']['seconds'] for s in last.values());assert control>0
kernels={}
for s in last.values():
    for kind,values in s.get('kernel_diagnostics',{}).items():
        d=kernels.setdefault(kind,{})
        for key,value in values.items():
            d[key]=max(d.get(key,0),value) if key=='max_seconds' else d.get(key,0)+value
projection=sum(kernels.get(k,{}).get('seconds',0.) for k in ['nonwall_projection','render_measured_projection','render_nonwall_projection'])
late=e.get('F12_LATE_DROP_ADVISOR',[])
legal=[s for s in late if s['existing_controller_legality_allows'] and s['actual_original_command_place']==0]
terminal=e.get('F12_TERMINAL_ADVISOR',[])
positive=[s for s in terminal if s['reason']=='positive_certified_view']
probe=json.loads((F.parent/'F11_optics_hysteresis_stall_20261027/MERGE_CONSUMER_PROBE_FIRST.json').read_text(encoding='utf-8'))
assert probe['status']=='PASS';timing={s['version']:s['seconds'] for s in probe['timing']}
synthetic_benefit=1-timing['sliced_OR']/timing['original']
gates={'M01':projection/control>=.01 and synthetic_benefit>.2,'M02':len(legal)>0,'M03':None} if name=='PARENT_M04_DIAG' else {'M01':None,'M02':None,'M03':len(positive)>0}
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'job':name,'control_id':'K01',
 'diagnostic_only_not_ranking':True,'own_kernel_sums':kernels,'own_control_seconds':control,
 'projection_disjoint_seconds':projection,'projection_fraction_of_control':projection/control,
 'synthetic_full_merge_benefit_not_whole_game':synthetic_benefit,
 'late_guard_records':late,'late_legal_no_original_attempt_records':len(legal),
 'terminal_advisors':terminal,'positive_terminal_advisors':len(positive),'gates':gates,
 'stock':[r['row']['placed'],r['row']['expected']],'native_steps':r['row']['timestep'],
 'native_seconds':r['row']['walltime'],'diagnostic_map_score':r['row']['phase']['score_map'],
 'last_observed_steps':{str(k):s['step'] for k,s in last.items()},
 'notes':'Existing JSON scalar logs only, no arrays/replay. Last checkpoints may undercount final calls; nested control/merge totals not additive. Shared observer can produce both advisor types on either map, but only declared Map04 late records and Map05 terminal records admit their respective candidate. Known-route evidence proxy is not official gain or relay/coordination proof.'}
b=(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode();(G/'ANALYSIS.json').write_bytes(b)
rf='/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F12_kernel_drop_terminal_20261027/'+name+'/ANALYSIS.json'
code="from pathlib import Path;import sys;p=Path("+repr(rf)+");assert not p.exists();p.write_bytes(sys.stdin.buffer.read())"
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=b,check=True)
print(json.dumps({k:report[k] for k in ['job','gates','own_control_seconds','projection_disjoint_seconds','projection_fraction_of_control','late_legal_no_original_attempt_records','positive_terminal_advisors','stock']}))
