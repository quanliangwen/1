from pathlib import Path
import json,datetime,sys,subprocess,shlex
F=Path(__file__).resolve().parent;v=sys.argv[1];n=int(sys.argv[2]);reason=Path(sys.argv[3]).read_text(encoding='utf-8')
P=F/(v+'_PERF');state=json.loads((P/'STATUS.json').read_text(encoding='utf-8'))
assert state['status']=='WAITING_FOR_AGENT_PAIR_REVIEW' and state['pairs_complete']==n
assert len(state['completed'])==2*n
docs=[]
for i in state['completed']:
 G=P/(i['version']+'_'+i['cohort']);assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'))['valid'];docs.append(json.loads((G/'RESULT.json').read_text(encoding='utf-8')))
a=[d['equal_weight_mean'] for d in docs if d['version']==v];b=[d['equal_weight_mean'] for d in docs if d['version']=='K01']
assert min(a)>=80 and (n!=2 or sum(a)>sum(b))
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':v,'pairs_complete':n,'continue':True,'reason':reason,'candidate_means':a,'control_means':b,'mean_difference':sum(a)/n-sum(b)/n,'not_paired_causal_or_significance_claim':True,'client_all_completed_raw_verified':True}
p=P/('PAIR_'+str(n)+'_REVIEW.json');assert not p.exists();p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
rf='/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F12_kernel_drop_terminal_20261027/'+v+'_PERF/'+p.name
code="from pathlib import Path;import sys;p=Path("+repr(rf)+");assert not p.exists();p.write_bytes(sys.stdin.buffer.read())"
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=p.read_bytes(),check=True)
print(json.dumps(d,ensure_ascii=False))
