from pathlib import Path
import json,base64,ast,hashlib
F=Path(__file__).resolve().parent;OLD=F.parent/'F11_optics_hysteresis_stall_20261027'
assert(F/'PREDECLARATION.json').exists() and not(F/'OBSERVER_ASSETS.json').exists()
operator=json.loads((OLD/'operators/L03/stage_diagnostic.json').read_text(encoding='utf-8'))
s=base64.b64decode(operator['payload']['mixin']).decode().replace('F11','F12')
marker="        state['feature_diagnostics']="
assert s.count(marker)==1
s=s.replace(marker,"        state['kernel_diagnostics']=getattr(self.memory,'kernel_diagnostics',{})\n"+marker)
marker="            print('[F12_SUBMIT_DECISION]',json.dumps(state,separators=(',',':')),flush=True)"
assert s.count(marker)==1
s=s.replace(marker,marker+"\n            self._diagnostic_terminal_advisor(state)")
s+='''
    def _maybe_place(self, command, step, semantic):
        result = super()._maybe_place(command, step, semantic)
        count = getattr(self, '_diagnostic_late_count', 0)
        last = getattr(self, '_diagnostic_late_last', -1000)
        if (count >= 8 or step-last < 24 or self.submitted or self.pose is None
                or self.pending_drop is not None or int(self.carried_bombs_count()) <= 0
                or self.placement_goal is not None or step-self.last_attempt_step < 8
                or step < self.PLAN_START_RATIO*self.limit):
            return result
        remaining = self._remaining_steps()
        if not 24 <= remaining <= 120:
            return result
        self._diagnostic_late_count = count+1
        self._diagnostic_late_last = step
        # Explicit diagnostic-only extra pure legality computation on the same
        # semantic argument already supplied to normal maybe-place; no sensing.
        allowed = bool(self._placement_allowed(step, semantic))
        import json
        print('[F12_LATE_DROP_ADVISOR]', json.dumps({'owner':int(self.identifier or 0),
            'step':int(step),'stock':int(self.carried_bombs_count()),
            'remaining_steps':remaining,'wall_left':self.walltime_limit-self.elapsed_walltime,
            'pose':np.asarray(self.pose).tolist(),'placement_goal':None,
            'existing_controller_legality_allows':allowed,
            'actual_original_command_place':int(command.get('place_bomb',0)),
            'scope':'Diagnostic only, original command unchanged; actuator not exercised by advisor.'},
            separators=(',',':')),flush=True)
        return result

    def _diagnostic_terminal_advisor(self, state):
        if getattr(self, '_diagnostic_terminal_checked', False):
            return
        if (not state['all_certificates'] or state['stock'] != 0
                or state['remaining_steps'] < 240 or state['wall_left'] < 15
                or state['step']+120 > self.limit/2):
            return
        self._diagnostic_terminal_checked = True
        from swarm_rescue.solutions.diagnostic_terminal_advisor import terminal_candidate
        begun = time.perf_counter()
        try:
            result = terminal_candidate(self.memory, self.pose, seconds=1.0)
        finally:
            self._diag_record_cost('terminal_advisor_extra', begun)
        result.update(owner=int(self.identifier or 0), step=state['step'],
                      remaining_steps=state['remaining_steps'], wall_left=state['wall_left'])
        import json
        print('[F12_TERMINAL_ADVISOR]',json.dumps(result,separators=(',',':')),flush=True)
'''
ast.parse(s)
assets={'diagnostic_mixin.py':s,'diagnostic_terminal_advisor.py':(F/'terminal_advisor.py').read_text(encoding='utf-8'),
 'kernel_profile_source.py':(OLD/'kernel_profile_source_draft.py').read_text(encoding='utf-8')}
for name,code in assets.items():ast.parse(code)
data={k:{'base64':base64.b64encode(v.encode()).decode(),'sha256':hashlib.sha256(v.encode()).hexdigest()} for k,v in assets.items()}
(F/'OBSERVER_ASSETS.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
(F/'diagnostic_mixin.py').write_text(s,encoding='utf-8')
print(json.dumps({k:v['sha256'] for k,v in data.items()}))
