from pathlib import Path
import ast,hashlib,json,shutil,sys,zipfile
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
F=H/'F100_raster_boundary_pilot_20261030';P=H/'F76_semantic_goal_consistency_pilot_20261030';Q=H/'F99_raster_measurement_model_20261030'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['RESULT.json','POSE_RESULT.json','PROCESS_RESULT.json']:
    assert read(Q/n)['reference_gate_pass'],n
assert read(Q/'GUARD_RESULT.json')['status']=='PASS_RASTER_REFERENCE_GUARDS_AND_COMPLETE_LIKELIHOOD'
assert read(P/'CAMPAIGN_CLIENT_REVIEW.json')['status']=='PASS'
parent=read(P/'J15/BUILD.json');C=F/'J20';assert not C.exists();C.mkdir();S=C/'source';shutil.copytree(P/'J15/source',S)
assert {p.name:sha(p) for p in S.iterdir()}==parent['source_files']
sys.path.insert(0,str(Q));from raster_pose_reference import patch_source
text=(S/'boundary_anchor.py').read_text();text=patch_source(text)
text=text.replace('import numpy as np','import numpy as np\nfrom swarm_rescue.solutions.raster_boundary_ml import raster_correction',1)
needle='            delta, self.last_raster_audit = raster_correction(self, lines, position, corrected_heading, observations)'
assert text.count(needle)==1
record='''
            stats = getattr(self, 'raster_stats', None)
            if stats is None:
                stats = dict(calls=0, accepted=0, nonzero=0, timed_calls=0, seconds=0., max_seconds=0., statuses={})
                self.raster_stats = stats
            stats['calls'] += 1
            status = self.last_raster_audit['status']
            stats['statuses'][status] = stats['statuses'].get(status, 0) + 1
            stats['accepted'] += int(delta is not None)
            stats['nonzero'] += int(delta is not None and np.linalg.norm(delta) > 1e-9)
            if 'seconds' in self.last_raster_audit:
                elapsed = self.last_raster_audit['seconds']
                stats['timed_calls'] += 1
                stats['seconds'] += elapsed
                stats['max_seconds'] = max(stats['max_seconds'], elapsed)
            stats['last_step'] = int(step)
            if stats['calls'] <= 2:
                import json
                print('[RASTER_BOUNDARY_ML] ' + json.dumps(dict(owner=int(getattr(self, '_raster_owner', -1)),
                    step=int(step), audit=self.last_raster_audit, cumulative=stats), sort_keys=True), flush=True)'''
text=text.replace(needle,needle+record)
(S/'boundary_anchor.py').write_text(text)
for filename,drop in [('public_frame_sensor.py',{'brute_frame_distances'}),('raster_pose_reference.py',{'patch_source'})]:
    source=(Q/filename).read_text();tree=ast.parse(source)
    for node in sorted([n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in drop],key=lambda n:n.lineno,reverse=True):
        lines=source.splitlines(keepends=True);source=''.join(lines[:node.lineno-1]+lines[node.end_lineno:])
    target='raster_boundary_ml.py' if filename=='raster_pose_reference.py' else filename
    if target=='raster_boundary_ml.py':
        source=source.replace('from public_frame_sensor import predict_frame_distances','from swarm_rescue.solutions.public_frame_sensor import predict_frame_distances')
    (S/target).write_text(source)
t=(S/'anchor_mapping.py').read_text()
needle='        self.boundary_anchor = ObservedBoundaryAnchor(*self.size_area)';assert t.count(needle)==1
t=t.replace(needle,needle+"\n        self.boundary_anchor._raster_owner = int(self.identifier or 0)")
needle='self.boundary_anchor.correct(lines,self.pose,self.heading,int(self.elapsed_timestep))';assert t.count(needle)==1
t=t.replace(needle,'self.boundary_anchor.correct(lines,self.pose,self.heading,int(self.elapsed_timestep), observations=(np.asarray(lidar,float),angles))')
(S/'anchor_mapping.py').write_text(t)
t=(S/'diagnostic_audit.py').read_text();needle="            seeking_fusion=bool(getattr(self, '_seeking_fusion', False)),";assert t.count(needle)==1
t=t.replace(needle,needle+"\n            raster_boundary=dict(getattr(getattr(self, 'boundary_anchor', None), 'raster_stats', {})),")
(S/'diagnostic_audit.py').write_text(t)
for p in S.glob('*.py'):ast.parse(p.read_text())
files={p.name:sha(p) for p in S.iterdir()};changes=sorted(n for n,h in files.items() if parent['source_files'].get(n)!=h)
assert changes==['anchor_mapping.py','boundary_anchor.py','diagnostic_audit.py','public_frame_sensor.py','raster_boundary_ml.py'],changes
zpath=C/'J20_research_payload.zip'
with zipfile.ZipFile(zpath,'x',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(S.iterdir()):z.write(p,p.name)
W=R/'experiments/target90_20261012/official_workspaces/f100_J20_actual_zip_check';assert not W.exists()
shutil.copytree(parent['workspace'],W,ignore=shutil.ignore_patterns('solutions','__pycache__','*.pyc','.git'));sol=W/'src/swarm_rescue/solutions';sol.mkdir()
with zipfile.ZipFile(zpath) as z:
    for n in z.namelist():
        assert '/' not in n and '\\' not in n
        (W/'req.txt' if n=='req.txt' else sol/n).write_bytes(z.read(n))
out=dict(candidate='J20',parent='J15',source_files=files,zip=str(zpath),zip_sha256=sha(zpath),workspace=str(W),changed_files=changes,
    research_only=True,official_submission_ready=False,
    scope='Only measured public-boundary translation model: full finite0.5px lattice ML in old5px cap; original angular/association gates and fallback. '
    'Cached lidar passed explicitly; bounded diagnostic records. No F95 bias, F96 point target, F97 scan DP, F98 interval QP, J19 issue signature, J18 clique, J17 frame or other unpromoted strategy.')
(C/'BUILD.json').write_text(json.dumps(out,indent=2)+'\n')
q=(H/'F93_issue_signature_pilot_20261030/qualify_candidate.py').read_text().replace('F93_issue_signature_pilot_20261030',F.name).replace("candidate = phase/'J19'","candidate = phase/'J20'")
(F/'qualify_candidate.py').write_text(q)
q=(Q/'check_contract_guards.py').read_text().replace('from raster_pose_reference import patch_source,raster_correction','from swarm_rescue.solutions.raster_boundary_ml import raster_correction').replace('from public_frame_sensor import brute_frame_distances','from public_frame_sensor import brute_frame_distances')
needle="env={'raster_correction':raster_correction};exec(compile(patch_source((P/'reference_source/boundary_anchor.py').read_text()),'raster_reference','exec'),env);New=env['ObservedBoundaryAnchor']";assert q.count(needle)==1
q=q.replace(needle,'from swarm_rescue.solutions.boundary_anchor import ObservedBoundaryAnchor as New')
q=q.replace("F=Path(__file__).resolve().parent;P=F.parent/'F96_boundary_surface_contract_20261030'", "F=Path(__file__).resolve().parent;P=F.parent/'F96_boundary_surface_contract_20261030'")
# Reference brute model deliberately remains outside the actual controller ZIP.
q="import sys\nsys.path.insert(0,"+repr(str(Q))+ ")\nsys.path.insert(0,"+repr(str(W/'src'))+")\n"+q
(F/'check_actual_module.py').write_text(q)
print(json.dumps(dict(status='BUILT_NOT_QUALIFIED',changed=changes,zip_sha256=out['zip_sha256'])))
