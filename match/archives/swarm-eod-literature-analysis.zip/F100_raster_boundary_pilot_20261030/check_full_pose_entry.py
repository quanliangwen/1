from pathlib import Path
import hashlib,json,sys,time
import numpy as np
F=Path(__file__).resolve().parent;B=json.loads((F/'J20/BUILD.json').read_text());W=Path(B['workspace']);sys.path.insert(0,str(W/'src'))
import pyglet
from swarm_rescue.solutions.my_drone_eval import MyDroneEval
from swarm_rescue.solutions.public_frame_sensor import predict_frame_distances
from swarm_rescue.simulation.utils.misc_data import MiscData
window=pyglet.window.Window(width=1,height=1,visible=False)
try:
    size=(1200,1200);angles=np.linspace(-np.pi,np.pi,181);position=np.array([500.,0.]);h=0.
    ranges=predict_frame_distances(position,h,angles,size)[0];ranges.flags.writeable=False;angles.flags.writeable=False
    misc=MiscData(size_area=size,number_drones=5,max_timestep_limit=7200,max_walltime_limit=240.)
    instances=[MyDroneEval(identifier=i,misc_data=misc) for i in range(5)]
    assert len({id(x.boundary_anchor) for x in instances})==len({id(x._colored_pose_filter) for x in instances})==5
    records=[]
    for i,d in enumerate(instances):
        gps=position+np.array([4.,0.]);d.pose=gps.copy();d.heading=h;d._colored_pose_filter.initialize(gps,h);d._colored_last_odom_valid=True
        d.measured_gps_position=lambda:gps.copy();d.measured_compass_angle=lambda:h;d.odometer_values=lambda:np.zeros(3)
        d.lidar_values=lambda:ranges;d.lidar_rays_angles=lambda:angles;d.semantic_values=lambda:[]
        for step in range(4,52,4):d.elapsed_timestep=step;d._update_pose()
        error=float(np.linalg.norm(d.pose-position));stats=d.boundary_anchor.raster_stats
        assert error<1.5 and stats['accepted']>0 and stats['nonzero']>0,(i,error,stats)
        assert d._colored_anchor_updates>0 and np.isfinite(d._colored_pose_filter.P).all()
        # Actual diagnostic entry serializes the new counts; no map submission.
        d.carried_bombs_count=lambda:2;d._diag_snapshot('RASTER_ENTRY_CHECK')
        records.append(dict(owner=i,error=error,pose=d.pose.tolist(),colored_anchor_updates=d._colored_anchor_updates,raster_stats=dict(stats),
            own_frame_records=len(d.frame_records),MRO=[c.__name__ for c in type(d).__mro__]))
    assert np.array_equal(ranges,predict_frame_distances(position,h,angles,size)[0])
finally:window.close()
out=dict(status='PASS_ACTUAL_ZIP_FULL_POSE_ENTRY',zip_sha256=B['zip_sha256'],records=records,native_games=0,control_loop_steps=0,
 scope='Five independent actual MyDroneEval objects, complete _update_pose MRO, public synthetic cached sensor readouts, no arena/physics/game/score. Not a performance proof.',
 actual_competition_map_loaded=False)
(F/'FULL_POSE_ENTRY_RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(status=out['status'],zip_sha256=out['zip_sha256'],owners=len(records),max_error=max(x['error'] for x in records))))
