from pathlib import Path
import hashlib,json
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
F=H/'F100_raster_boundary_pilot_20261030';P=H/'F76_semantic_goal_consistency_pilot_20261030';Q=H/'F99_raster_measurement_model_20261030';T=H/'F93_issue_signature_pilot_20261030'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
assert not (F/'PREDECLARATION.json').exists()
b=read(F/'J20/BUILD.json');q=read(F/'J20/RESEARCH_QUALIFICATION.json');entry=read(F/'FULL_POSE_ENTRY_RESULT.json')
assert q['status']=='PASS' and q['zip_sha256']==entry['zip_sha256']==b['zip_sha256']
assert entry['status']=='PASS_ACTUAL_ZIP_FULL_POSE_ENTRY'
assert read(F/'GUARD_RESULT.json')['status']=='PASS_RASTER_REFERENCE_GUARDS_AND_COMPLETE_LIKELIHOOD'
assert q['target_public_configuration']==dict(map='Map05',timestep_limit=7200,walltime_limit=240.,size=[1200,1200])
launch=(T/'launch_campaign.py').read_text().replace(T.name,F.name)
needle="assert not others, ('Another phase coordinator alive', others)";assert launch.count(needle)==1
launch=launch.replace(needle,needle+"\n(F/'PRELAUNCH_AUDIT.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),global_serial_lock_available=True,registry_active_processes=activity.get('active_processes'),registry_current_formal_active=activity.get('current_formal_active'),other_phase_coordinators=others),indent=2)+'\\n')")
(F/'launch_campaign.py').write_text(launch)
t=(T/'run_offline.py').read_text().replace(T.name,F.name).replace('J19','J20').replace('f93_J20','f100_J20').replace('issue_events','raster_events').replace('ISSUED_PLAN_SIGNATURE','RASTER_BOUNDARY_ML')
needle="    criteria=dict(all10_placed=";assert t.count(needle)==1
insert="""    raster_stats={str(x['owner']):x['raster_boundary'] for x in states if x.get('raster_boundary')}
    timed_calls=sum(x.get('timed_calls',0) for x in raster_stats.values())
    raster_seconds=sum(x.get('seconds',0.) for x in raster_stats.values())
    raster_mean=raster_seconds/timed_calls if timed_calls else None
    raster_nonzero=sum(x.get('nonzero',0) for x in raster_stats.values())
"""
t=t.replace(needle,insert+needle,1)
t=t.replace("map_at_least95=r['phase']['score_map']>=95.","map_at_least_parent_reference=r['phase']['score_map']>=97.0627560008")
old="        actual_issued_signature_normalization=bool(raster_events),\n        issue_epoch_consistent=all(x['plan_epoch']==x['step'] for x in raster_events))";assert t.count(old)==1
t=t.replace(old,"        actual_nonzero_raster_ML=raster_nonzero>0,\n        reported_model_mean_at_most8ms=raster_mean is not None and raster_mean<=.008)")
old="        issued_signature_events=raster_events,issued_signature_normalizations=len(raster_events),";assert t.count(old)==1
t=t.replace(old,"        raster_events=raster_events,reported_raster_stats_by_owner=raster_stats,reported_model_timed_calls=timed_calls,\n        reported_raster_nonzero=raster_nonzero,reported_model_seconds=raster_seconds,reported_model_mean=raster_mean,\n        reported_counts_are_lower_bounds=True,")
t=t.replace('ANALYZE_OPTIMAL_FUSION_ISSUE_SIGNATURE_AND_EXECUTION','ANALYZE_RASTER_BOUNDARY_MEASUREMENT_MODEL_AND_MAP_RECALL')
old=next(x for x in t.splitlines() if x.startswith("        scope='One independent unseeded original-resource Map05"))
t=t.replace(old,"        scope='One independent unseeded original-resource Map05 RED+team006BLUE. J15 parent, only finite full-grid public-raster boundary translation likelihood and cached readout plumbing/diagnostics. Angular/association gates, optimizer, sensor model, dependencies and original time/resource limits unchanged. Old J15 is historical, not a same-seed causal control. Periodic per-owner model counters may omit the final unsnapshotted tail.',")
(F/'run_offline.py').write_text(t)
parent=read(P/'PREDECLARATION.json');d={k:parent[k] for k in ['sdk_commit','sdk_files','blue_binding','blue_binding_sha256','resource_gate','frozen_files']}
d.update(phase=F.name,selection=['J20'],maps=['Map05'],seed=None,
 versions=dict(J20=dict(original_zip=b['zip'],original_zip_sha256=b['zip_sha256'],source=str(F/'J20/source'),source_files=b['source_files'])),
 min_native_rounds=2,max_native_rounds=2,diagnostic_only=True,
 authorization='Current-turn continuous analysis, substantive small checks and promising single pilots authorized; automation remains PAUSED.',
 purpose='Replace center-line nudging by measured public raster likelihood in bounded full0.5px lattice, after unchanged trusted boundary/heading gates.',
 reference=dict(parent='J15 prior unseeded independent Map05, not causal paired control',full=73.3645272723,map=97.0627560008,wall=74.1657463596),
 gates=dict(placed=10,full_min=75.,map_min=97.0627560008,wall_min=74.1657463596,actual_nonzero_raster_ML=True,
  reported_model_mean_max_seconds=.008,no_red_or_blue_walltime_hit=True,first_Windows_raw_review=True,no_retry=True,no_automatic_five=True),
 optimizer=parent['optimizer'],limitations='Finite local grid model is not continuous global localization, a calibrated nonlinear posterior or whole-game optimum. '
  'Reference improvements were constructed trajectories, not game scores. No F95/F96/F97/F98/J19/J18/J17 strategies stacked. '
  'No retry for low score or nonactivation; no automatic five-map expansion.')
v=F/'versions/J20';v.mkdir(parents=True);save(v/'QUALIFICATION.json',dict(status='PASS',payload_files_sha256=b['source_files'],zip_sha256=b['zip_sha256'],research_only=True))
for p in [F/'run_offline.py',F/'J20/RESEARCH_QUALIFICATION.json',F/'FULL_POSE_ENTRY_RESULT.json',F/'GUARD_RESULT.json',
          Q/'RESULT.json',Q/'POSE_RESULT.json',Q/'PROCESS_RESULT.json',Q/'GUARD_RESULT.json']:
    d['frozen_files'][str(p)]=sha(p)
save(F/'PREDECLARATION.json',d)
print(json.dumps(dict(status='PREPARED_NOT_STARTED',candidate='J20',map='Map05',max_native=2,zip_sha256=b['zip_sha256'])))
