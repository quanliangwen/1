from pathlib import Path
import ast, datetime, fcntl, hashlib, json

R = Path('/home/junhao/quan/parallel_test_solver/match')
S = R / 'solver_study'
H = S / 'framework_screen_20261016/best87_independent_20261025'
T = H / 'BLUE_team006_switch_20261027'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
d = json.loads((T / 'STAGING.json').read_text())
q = json.loads((T / 'QUALIFICATION.json').read_text())
assert q['status'] == 'PASS' and q['uploaded_zip_sha256'] == d['uploaded_zip_sha256']
lock = (S / 'serial_evaluation.lock').open('a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
active = json.loads((S / 'heuristic_20261016.json').read_text())
assert not active.get('active_processes') and not active.get('current_formal_active')
assert not (T / 'ACTIVATION.json').exists()
W = Path(d['blue_workspace'])
assert all(sha(W / n) == h for n, h in d['sdk_original_hashes'].items())
assert all(sha(W / 'src' / n) == h for n, h in d['dependency_files'].items())
assert sha(Path(d['worker'])) == d['worker_sha256']
assert sha(Path(d['original_worker'])) == d['original_worker_sha256']
assert sha(Path(d['evaluator'])) == d['evaluator_sha256']

wrapper = S / 'framework_screen_20261016/parallel_active_blue_five.py'
assert not wrapper.exists()
code = '''"""Current five-map evaluation entry; historical runners remain frozen.

Example: MATCH_HEURISTIC_ID=heuristic_20261015T2047Z bash run_server.sh
    solver_study/framework_screen_20261016/parallel_active_blue_five.py
    --label NEW_UNIQUE_LABEL --red-workspace ABSOLUTE_RED_WORKSPACE
"""
from pathlib import Path
import hashlib, json, runpy
R = Path('/home/junhao/quan/parallel_test_solver/match')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
d = json.loads((R / 'solver_study/ACTIVE_BLUE_OPPONENT.json').read_text())
assert d['status'] == 'ACTIVE'
t = Path(d['staging_manifest'])
assert sha(t) == d['staging_manifest_sha256']
s = json.loads(t.read_text())
w = Path(s['blue_workspace'])
for n, h in s['source_files'].items():
    p = w / 'req.txt' if n == 'req.txt' else w / 'src/swarm_rescue/solutions' / n
    assert sha(p) == h, ('BLUE source changed', n)
for n, h in s['dependency_files'].items():
    assert sha(w / 'src' / n) == h, ('BLUE dependency changed', n)
for n, h in s['sdk_original_hashes'].items():
    assert sha(w / n) == h, ('SDK changed', n)
worker = Path(d['worker'])
assert sha(worker) == d['worker_sha256']
assert sha(Path(d['evaluator'])) == d['evaluator_sha256']
qualification = Path(d['qualification_receipt'])
assert sha(qualification) == d['qualification_receipt_sha256']
assert json.loads(qualification.read_text())['status'] == 'PASS'
runpy.run_path(str(worker), run_name='__main__')
'''
ast.parse(code)
wrapper.write_text(code)
current = S / 'ACTIVE_BLUE_OPPONENT.json'
if current.exists():
    (T / 'PREVIOUS_ACTIVE_BLUE_OPPONENT.json').write_bytes(current.read_bytes())
record = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'ACTIVE', 'opponent_id': 'team006_preliminary_5dbf10fc13c5', 'uploaded_zip_sha256': d['uploaded_zip_sha256'], 'blue_workspace': d['blue_workspace'], 'blue_controller': d['blue_controller'], 'team_number': 6, 'worker': d['worker'], 'worker_sha256': d['worker_sha256'], 'active_five_map_entry': str(wrapper), 'active_five_map_entry_sha256': sha(wrapper), 'evaluator': d['evaluator'], 'evaluator_sha256': d['evaluator_sha256'], 'staging_manifest': str(T / 'STAGING.json'), 'staging_manifest_sha256': sha(T / 'STAGING.json'), 'qualification_receipt': str(T / 'QUALIFICATION.json'), 'qualification_receipt_sha256': sha(T / 'QUALIFICATION.json'), 'old_blue_preserved': d['old_blue_preserved'], 'history_boundary': 'All F01-F26 existing scores used the former RollingRescue opponent; new results require fresh contemporary controls, new labels and new study declaration. Do not resume old frozen runners against a different opponent.', 'game_rounds_started_by_switch': 0, 'existing_server_dependencies_modified': False}
data = json.dumps(record, ensure_ascii=False, indent=2) + '\n'
temp = current.with_suffix('.json.switch_tmp')
assert not temp.exists()
temp.write_text(data)
temp.replace(current)
(T / 'ACTIVATION.json').write_text(data)
note = ('ACTIVE BLUE OPPONENT: team006 preliminary / LBBDRescue / team_number 6\n'
        'Binding: ' + str(current) + '\n'
        'Five-map entry: ' + str(wrapper) + '\n'
        'Workspace: ' + str(W) + '\n'
        'Old BLUE workspace is preserved for historical reproduction only. All prior F01-F26 scores are OLD opponent scores.\n'
        'Use new unique labels and fresh contemporary controls. Never edit/reuse old frozen study operators to imply a same-opponent comparison.\n'
        'Switch checks: actual ZIP source hashes, native ABI operations, elkai TSP, actual 10-drone constructor; zero game scores collected.\n')
(R / 'CURRENT_BLUE_OPPONENT.txt').write_text(note)
(T / 'CURRENT_BLUE_OPPONENT.txt').write_text(note)
print(json.dumps({k: record[k] for k in ['status', 'opponent_id', 'blue_controller', 'active_five_map_entry', 'game_rounds_started_by_switch']}))
