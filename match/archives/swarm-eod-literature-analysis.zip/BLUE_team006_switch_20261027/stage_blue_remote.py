from pathlib import Path, PurePosixPath
import ast, datetime, fcntl, hashlib, json, shutil, sys, tarfile, zipfile

R = Path('/home/junhao/quan/parallel_test_solver/match')
H = R / 'solver_study/framework_screen_20261016/best87_independent_20261025'
T = H / 'BLUE_team006_switch_20261027'
OLD = R / 'experiments/target90_20261012/official_workspaces/expanded_supplied_blue_20261013'
W = OLD.with_name('blue_team006_preliminary_20261027')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
stamp = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
save = lambda p, d: p.write_text(json.dumps(d, ensure_ascii=False, indent=2) + '\n')
lock = (R / 'solver_study/serial_evaluation.lock').open('a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
active = json.loads((R / 'solver_study/heuristic_20261016.json').read_text())
assert not active.get('active_processes') and not active.get('current_formal_active')
assert T.is_dir() and not W.exists() and not (T / 'STAGING.json').exists()
Z = T / 'team006_preliminary_original.zip'
assert sha(Z) == '5dbf10fc13c5de28fd3fe7fcc8e98b0c936b38add15087f9895c4c5212b2a57c'
old_sources = {str(p.relative_to(OLD)): sha(p) for p in sorted((OLD / 'src/swarm_rescue/solutions').rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
old_sources['req.txt'] = sha(OLD / 'req.txt')
with tarfile.open(T / 'old_blue_sources.tar.gz', 'x:gz') as tar:
    for n in old_sources: tar.add(OLD / n, arcname=n, recursive=False)
save(T / 'OLD_BLUE_BACKUP.json', {'utc': stamp(), 'workspace_preserved_in_place': str(OLD), 'files': old_sources, 'archive_sha256': sha(T / 'old_blue_sources.tar.gz')})
shutil.copytree(OLD, W, ignore=shutil.ignore_patterns('solutions', '__pycache__', '*.pyc', '.git', '.pytest_cache'))
sol = W / 'src/swarm_rescue/solutions'
sol.mkdir()
payload = {}
with zipfile.ZipFile(Z) as z:
    assert len(z.namelist()) == len(set(z.namelist()))
    for i in z.infolist():
        n = PurePosixPath(i.filename)
        assert not i.is_dir() and not n.is_absolute() and len(n.parts) == 1 and '\\' not in i.filename
        assert i.filename.endswith('.py') or i.filename in ['team_info.yml', 'req.txt']
        b = z.read(i)
        if i.filename.endswith('.py'): ast.parse(b.decode('utf-8-sig'))
        target = W / 'req.txt' if i.filename == 'req.txt' else sol / i.filename
        target.write_bytes(b)
        payload[i.filename] = sha(target)
# The only added runtime dependency lives inside this workspace's import root.
# Do not install or upgrade anything in R/.venv or the existing server environment.
wheels = list(T.glob('elkai-2.0.1-*.whl'))
assert len(wheels) == 1
dependency_files = {}
with zipfile.ZipFile(wheels[0]) as z:
    for i in z.infolist():
        n = PurePosixPath(i.filename)
        assert not n.is_absolute() and '..' not in n.parts
        if i.is_dir(): continue
        p = W / 'src' / str(n)
        assert not p.exists(), str(p)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(z.read(i))
        dependency_files[str(n)] = sha(p)
sdk = {str(p.relative_to(OLD)): sha(p) for p in sorted((OLD / 'src/swarm_rescue').rglob('*')) if p.is_file() and 'solutions' not in p.relative_to(OLD).parts and '__pycache__' not in p.parts and p.suffix != '.pyc'}
assert all(sha(W / n) == h for n, h in sdk.items())
old_worker = R / 'solver_study/framework_screen_20261016/parallel_unseeded_five_one_round.py'
old_eval = old_worker.with_name('unseeded_direct_v1.py')
s = old_worker.read_text()
assert s.count("bluework = BASE / 'official_workspaces/expanded_supplied_blue_20261013'") == 1
s = s.replace("bluework = BASE / 'official_workspaces/expanded_supplied_blue_20261013'", 'bluework = Path(' + repr(str(W)) + ')')
assert s.count("BLUE_SHA = '08ec34346c5e6bb8b168a3ef36c647162a6c215291442baef41d4aefe0e86eaa'") == 1
s = s.replace("BLUE_SHA = '08ec34346c5e6bb8b168a3ef36c647162a6c215291442baef41d4aefe0e86eaa'", 'BLUE_SHA = ' + repr(payload['lbbd_rescue.py']))
s = s.replace("EVALUATOR = Path(__file__).with_name('unseeded_direct_v1.py')", 'EVALUATOR = Path(' + repr(str(old_eval)) + ')')
s = s.replace('RollingRescue', 'LBBDRescue').replace('supplied_rolling_rescue', 'team006_preliminary_5dbf10fc13c5')
ast.parse(s)
worker = T / 'parallel_five_team006.py'
worker.write_text(s)
record = {'utc': stamp(), 'status': 'STAGED_NOT_YET_ACTIVATED', 'uploaded_zip': str(Z), 'uploaded_zip_sha256': sha(Z), 'blue_workspace': str(W), 'blue_controller': 'swarm_rescue.solutions.lbbd_rescue.LBBDRescue', 'controller_sha256': payload['lbbd_rescue.py'], 'source_files': payload, 'sdk_files_unchanged_count': len(sdk), 'sdk_original_hashes': sdk, 'dependency_wheel_sha256': sha(wheels[0]), 'dependency_files': dependency_files, 'worker': str(worker), 'worker_sha256': sha(worker), 'original_worker': str(old_worker), 'original_worker_sha256': sha(old_worker), 'evaluator': str(old_eval), 'evaluator_sha256': sha(old_eval), 'old_blue_preserved': str(OLD), 'no_games_started': True, 'server_existing_dependencies_modified': False}
save(T / 'STAGING.json', record)
print(json.dumps({k: record[k] for k in ['status', 'blue_workspace', 'blue_controller', 'sdk_files_unchanged_count', 'worker_sha256', 'server_existing_dependencies_modified']}))
