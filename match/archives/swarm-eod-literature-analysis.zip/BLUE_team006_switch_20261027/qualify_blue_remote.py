from pathlib import Path
import ast, datetime, fcntl, hashlib, importlib, importlib.metadata, json, sys
R = Path('/home/junhao/quan/parallel_test_solver/match')
T = R / 'solver_study/framework_screen_20261016/best87_independent_20261025/BLUE_team006_switch_20261027'
d = json.loads((T / 'STAGING.json').read_text())
W = Path(d['blue_workspace'])
lock = (R / 'solver_study/serial_evaluation.lock').open('a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
active = json.loads((R / 'solver_study/heuristic_20261016.json').read_text())
assert not active.get('active_processes') and not active.get('current_formal_active')
assert not (T / 'QUALIFICATION.json').exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(W / n) == h for n, h in d['sdk_original_hashes'].items())
for n, h in d['source_files'].items():
    p = W / 'req.txt' if n == 'req.txt' else W / 'src/swarm_rescue/solutions' / n
    assert sha(p) == h
    if p.suffix == '.py': ast.parse(p.read_text(encoding='utf-8-sig'))
sys.path.insert(0, str(W / 'src'))
import numpy as np
import numpy.random.mtrand
import pandas as pd
import scipy
import cv2
import elkai
import yaml
from scipy.optimize import linear_sum_assignment
from swarm_rescue.solutions.my_drone_eval import drone_class_for_mode
from swarm_rescue.simulation.reporting.team_info import TeamInfo
from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
from swarm_rescue.simulation.drone.drone_abstract import DroneAbstract
from swarm_rescue.launcher import Launcher
cls = drone_class_for_mode('rescue')
assert cls.__module__ + '.' + cls.__name__ == d['blue_controller']
assert issubclass(cls, DroneAbstract)
info = TeamInfo()
assert type(info.team_number) is int and info.team_number == 6
assert yaml.safe_load((W / 'src/swarm_rescue/solutions/team_info.yml').read_text())['team_number'] == 6
assert np.isfinite(np.random.RandomState(6).normal(size=8)).all()
assert pd.DataFrame({'x': [1, 2]}).x.sum() == 3
assert cv2.resize(np.zeros((4, 4), np.uint8), (2, 2)).shape == (2, 2)
assert linear_sum_assignment(np.array([[1., 9.], [9., 1.]]))[1].tolist() == [0, 1]
tour = elkai.DistanceMatrix([[0, 1, 3], [1, 0, 2], [3, 2, 0]]).solve_tsp(runs=1)
assert set(tour) == {0, 1, 2}
assert Path(elkai.__file__).resolve().is_relative_to(W)
for p in (W / 'src/swarm_rescue/solutions').glob('*.py'):
    importlib.import_module('swarm_rescue.solutions.' + p.stem)
# Native construction only: no game loop, no stepping, no shortened score test.
import pyglet
window = pyglet.window.Window(width=1, height=1, visible=False)
from swarm_rescue.maps.map_02 import Map02
arena = Map02(drone_type=cls)
assert arena.number_drones == 10 and all(type(x) is cls for x in arena.drones)
assert arena.max_timestep_limit == 5000 and arena.max_walltime_limit == 180
assert len({id(x.grid) for x in arena.drones}) == 10
window.close()
assert all(sha(W / n) == h for n, h in d['sdk_original_hashes'].items())
assert sha(Path(d['original_worker'])) == d['original_worker_sha256']
assert sha(Path(d['worker'])) == d['worker_sha256']
result = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'PASS', 'uploaded_zip_sha256': d['uploaded_zip_sha256'], 'source_files': d['source_files'], 'blue_controller': d['blue_controller'], 'team_number': info.team_number, 'native_drone_constructors': 10, 'unique_grid_instances': 10, 'game_rounds': 0, 'native_limits_unchanged': True, 'sdk_files_unchanged_count': d['sdk_files_unchanged_count'], 'existing_server_dependency_versions': {'numpy': np.__version__, 'pandas': pd.__version__, 'scipy': scipy.__version__, 'opencv': cv2.__version__}, 'elkai_version': importlib.metadata.version('elkai'), 'elkai_module': elkai.__file__, 'tsp_tour': tour, 'interpreter': sys.executable, 'no_score_or_website_validation_claim': True}
(T / 'QUALIFICATION.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['status', 'blue_controller', 'team_number', 'native_drone_constructors', 'game_rounds', 'existing_server_dependency_versions', 'elkai_version']}))
