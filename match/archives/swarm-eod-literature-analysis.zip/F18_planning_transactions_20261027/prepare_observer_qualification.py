from pathlib import Path
import ast
F=Path(__file__).resolve().parent;O=F.parent/'F16_measured_layout_frontier_20261027'
def write(n,s):
 p=F/n;assert not p.exists();ast.parse(s);p.write_bytes(s.encode())
s=(O/'observer_tests.py').read_text(encoding='utf-8').replace('F16','F18').replace('f16','f18')
marker=" check('original_numeric_AST_unchanged',ast.dump(oldtree)==ast.dump(newtree))";assert s.count(marker)==1
s=s.replace(marker," newtree.body=[n for n in newtree.body if not(isinstance(n,ast.ImportFrom) and n.module=='swarm_rescue.solutions.planning_profile')]\n"+marker)
marker=" report.update(status='PASS',scope=";i=s.index(marker)
extra=(F/'planning_observer_tests.py').read_text(encoding='utf-8')
s=s[:i]+'\n'.join(' '+x for x in extra.splitlines())+'\n'+s[i:];write('observer_tests.py',s)
s=(O/'qualify_observer.py').read_text(encoding='utf-8').replace(O.name,F.name)
write('qualify_observer.py',s)
