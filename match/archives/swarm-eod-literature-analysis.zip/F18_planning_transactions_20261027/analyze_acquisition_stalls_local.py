from pathlib import Path
import json,collections
F=Path(__file__).resolve().parent;T=F.parent/'F17_assignment_epoch_and_consumers_20261027'
out={'scope':'Own already-verified scalar diagnostic JSON only; sampled counter changes are descriptive. No historical arrays, simulation, server commands, current production changes, or causal score inference.','jobs':{}}
for root,name,prefix in [(T,'PARENT_M04_DIAG','F17'),(T,'R02_DIAG','F17'),(T,'R03_DIAG','F17'),(F,'PARENT_M04_DIAG','F18'),(F,'S01_DIAG','F18')]:
 G=root/name
 if not(G/'CLIENT_FIRST_RAW_REVIEW.json').exists():continue
 assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'))['valid']
 E=json.loads((G/'EVENTS.json').read_text(encoding='utf-8'));rows=E[prefix+'_DIAG_TICK'];owners={}
 for owner in range(5):
  records=sorted([x for x in rows if x['owner']==owner],key=lambda x:x['step']);last=None;events=[];continued_samples=0;zero_gain_samples=0
  for x in records:
   p=x.get('terminal_policy',{});old={} if last is None else last.get('terminal_policy',{})
   dc=p.get('acquisition_continue',0)-old.get('acquisition_continue',0)
   du=p.get('model_updates',0)-old.get('model_updates',0)
   gain=x.get('terminal_gain_rate');ready=x.get('decision_snapshot',{}).get('coverage_ready',False)
   if dc>0:
    continued_samples+=1
    if gain is not None and gain<=1e-12:
     zero_gain_samples+=1
     quality_unchanged=(last is not None and x.get('cached_map_quality')==last.get('cached_map_quality') and x.get('known_free_fraction')==last.get('known_free_fraction'))
     events.append({'step':x['step'],'counter_increase':dc,'model_update_increase':du,'gain_rate':gain,'coverage_ready':ready,
       'expected_probe_gain':p.get('last_acquisition_expected_gain'),'time_loss':p.get('last_acquisition_time_loss'),
       'completion_risk':p.get('last_acquisition_completion_risk'),'gap':p.get('last_total_gap'),
       'quality_unchanged_since_previous_sample':quality_unchanged,'sample_gap':None if last is None else x['step']-last['step']})
   last=x
  owners[owner]={'continuation_positive_counter_samples':continued_samples,'zero_gain_continuation_samples':zero_gain_samples,
       'zero_gain_and_unchanged_quality_samples':sum(e['quality_unchanged_since_previous_sample'] for e in events),'examples':events[:4]}
 out['jobs'][root.name+'/'+name]=owners
p=F/'ACQUISITION_STALL_SCALAR_AUDIT.json';assert not p.exists();p.write_bytes((json.dumps(out,indent=2)+'\n').encode())
for name,owners in out['jobs'].items():print(name,json.dumps({k:{q:v[q] for q in ['continuation_positive_counter_samples','zero_gain_continuation_samples','zero_gain_and_unchanged_quality_samples']} for k,v in owners.items()}))
