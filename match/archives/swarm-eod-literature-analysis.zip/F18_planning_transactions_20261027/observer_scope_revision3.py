from pathlib import Path
import ast,subprocess,shlex,json
F=Path(__file__).resolve().parent
s=(F/'observer_tests_revision2.py').read_text(encoding='utf-8')
marker=" report.update(status='PASS',scope=";i=s.index(marker)
extra=""" from swarm_rescue.solutions import frontier_observer as callback_module
 original_callback=callback_module.observe_frontier;old_greedy=current._greedy_plan;old_factory=trust.GeometryPlanningMemory
 called=[]
 def checked_callback(memory,*args,**kwargs):
  called.append(1)
  check('advisor_excluded_from_original_profile_scope','_f18_plan_profile' not in vars(memory))
 try:
  callback_module.observe_frontier=checked_callback
  m,pm,base,agents,prefix=fixture(True,False)
  trust.GeometryPlanningMemory=lambda memory:pm
  current._greedy_plan=lambda *args,**kwargs:base
  answer=current.plan_team_coverage_lns(m,agents,[],32.,travel_budget=2000.)
  check('advisor_runs_after_original_scope_once',len(called)==1 and same(answer,base) and '_f18_plan_profile' not in vars(m))
 finally:callback_module.observe_frontier=original_callback;current._greedy_plan=old_greedy;trust.GeometryPlanningMemory=old_factory
"""
s=s[:i]+extra+s[i:];ast.parse(s);p=F/'observer_tests_revision3.py';assert not p.exists();p.write_bytes(s.encode())
s=(F/'qualify_observer_revision2.py').read_text(encoding='utf-8').replace('observer_tests_revision2.py','observer_tests_revision3.py').replace('observer_qualification_revision2','observer_qualification_revision3').replace('observer_revision2_console.txt','observer_revision3_console.txt')
ast.parse(s);p=F/'qualify_observer_revision3.py';assert not p.exists();p.write_bytes(s.encode())
code=r'''
from pathlib import Path
import json,hashlib,shutil,ast
F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F18_planning_transactions_20261027');old=F/'observer_qualification_revision2';Q=F/'observer_qualification_revision3'
assert json.loads((old/'QUALIFICATION_RESULT.json').read_text())['status']=='PASS'
assert not(F/'PARENT_M04_DIAG').exists() and not(F/'FIRST_NATIVE_ERROR.json').exists() and not Q.exists();Q.mkdir();S=Q/'source';shutil.copytree(old/'source',S)
p=S/'team_coverage_lns.py';tree=ast.parse(p.read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='plan_team_coverage_lns')
assert len(fn.body)==1 and isinstance(fn.body[0],ast.With)
scope=fn.body[0];tail=scope.body[-1];assert isinstance(tail,ast.Try) and len(tail.body)==3 and isinstance(tail.body[1],ast.If) and isinstance(tail.body[2],ast.Return)
scope.body=scope.body[:-1]+[tail.body[0]]
fn.body=[ast.Try(body=[scope]+tail.body[1:],handlers=[],orelse=[],finalbody=tail.finalbody)]
s=ast.unparse(ast.fix_missing_locations(tree))+'\n';p.write_bytes(s.encode())
binding=json.loads((old/'SOURCE_BINDING.json').read_text());binding['observer_source_files']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in S.iterdir() if p.is_file()}
binding['revision3']='Close original planner profiling scope before extra readonly advice; exclude advisor-added path/view work from admission resource counts. Earlier successful53QA+preflight preserved. No game started, no nativefailure.'
(Q/'SOURCE_BINDING.json').write_text(json.dumps(binding,indent=2)+'\n')
d={'stage':'before_first_native','previous_qualified_checks':53,'scope_correction':'Exclude extra readonly advisor paths from original planner duplicate counters. Actual original planner/commands unchanged, separate qualification before game.','native_games_started':0,'new_binding_sha256':hashlib.sha256((Q/'SOURCE_BINDING.json').read_bytes()).hexdigest()}
(F/'PROFILE_SCOPE_CORRECTION.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
'''
r=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)]);p=F/'PROFILE_SCOPE_CORRECTION.json';assert not p.exists();p.write_bytes(r);print(r.decode())
