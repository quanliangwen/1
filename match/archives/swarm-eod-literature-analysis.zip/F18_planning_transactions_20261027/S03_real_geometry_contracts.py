    # Exercise actual measured-wall geometry, not injected coverage-value fixtures.
    check('S03_specific_real_geometry_checks',build['candidate_id']=='S03')
    for label in ['closed_rectangle','open_rectangle','visited_contradiction','forbidden_band']:
        a=MapMemory(256,192);a.free[:]=True
        a.hits[25:28,30:66]=5;a.hits[53:56,30:66]=5;a.hits[25:56,30:33]=5;a.hits[25:56,63:66]=5
        a.hits[65:68,85:115]=4
        if label=='open_rectangle':a.hits[25:28,45:58]=0
        if label=='visited_contradiction':a.visits[4:6,5:7]=3
        b=MapMemory(256,192)
        for key in ['free','hits','visits']:getattr(b,key)[:]=getattr(a,key)
        mask=np.zeros(a.shape,bool)
        if label=='forbidden_band':mask[:,:3]=True
        agents={2:(a.cell_to_world((1,1)),2),3:(a.cell_to_world((9,14)),2)}
        x=old.plan_team_coverage_lns(a,agents,[],64.,travel_budget=1000.,forbidden_mask=mask)
        y=current.plan_team_coverage_lns(b,agents,[],64.,travel_budget=1000.,forbidden_mask=mask)
        check('actual_measured_geometry_plan_exact_'+label,same(x,y))
        check('actual_measured_geometry_counters_exact_'+label,a.trust_region_diagnostics==b.trust_region_diagnostics)
        check('actual_measured_geometry_arrays_unchanged_'+label,all(np.array_equal(getattr(a,key),getattr(b,key)) for key in ['free','hits','visits']))
        if label=='closed_rectangle':check('actual_measured_geometry_nonempty_shared_path',any(y.values()) and b.planning_view_diagnostics['nonempty_shared']>=1)
