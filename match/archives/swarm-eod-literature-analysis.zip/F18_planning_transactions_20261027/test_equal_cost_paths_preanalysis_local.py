"""Fixed fake graphs only, using actual canonical directed route_fields."""
from pathlib import Path
import ast,hashlib,json,types
import numpy as np
from equal_cost_paths_preanalysis import equal_cost_alternatives,directed_edge,information_union

F=Path(__file__).resolve().parent
source=(F/'next_direction_source_reference/route_transaction.py').read_text(encoding='utf-8')
tree=ast.parse(source)
# Module only imports stdlib and NumPy; it does not import or run the SDK.
env={};exec(compile(tree,'canonical_own_route_fields','exec'),env)
checks=[];examples=[]
def check(name,value):
    assert value,name
    checks.append(name)
for name,blocked,clearance in [
    ('free',[],np.full((7,9),100.,np.float32)),
    ('wall',[(3,c) for c in range(2,7)],np.full((7,9),100.,np.float32)),
    ('directed',[],np.tile(np.arange(9,dtype=np.float32)*4+8,(7,1))),
    ('corner',[(1,0)],np.full((7,9),100.,np.float32))]:
    walk=np.ones((7,9),bool)
    for p in blocked:walk[p]=False
    start=(0,0);goal=(5,8)
    memory=types.SimpleNamespace(shape=walk.shape,_route_transaction_fields=[])
    cost,parent=env['route_fields'](memory,clearance,walk,start)
    paths=equal_cost_alternatives(cost,parent,clearance,walk,start,goal)
    check(name+'_nonempty',bool(paths))
    check(name+'_cap',len(paths)<=8)
    check(name+'_unique',len({tuple(p) for p in paths})==len(paths))
    check(name+'_endpoints',all(p[0]==start and p[-1]==goal for p in paths))
    check(name+'_simple',all(len(p)==len(set(p)) for p in paths))
    check(name+'_exact_primary_cost',all(abs(sum(directed_edge(a,b,clearance,walk) for a,b in zip(p,p[1:]))-float(cost[goal]))<=1e-9 for p in paths))
    examples.append({'graph':name,'alternatives':len(paths),'primary_cost':float(cost[goal])})
    if name=='free':check('actual_tie_diversity',len(paths)>1)
vary=np.array([[10.,30.]],np.float32);mask=np.ones((1,2),bool)
check('actual_destination_clearance_asymmetry',directed_edge((0,0),(0,1),vary,mask)!=directed_edge((0,1),(0,0),vary,mask))
check('duplicate_visibility_union',information_union([(0,0),(0,1)],{(0,0):{1,2},(0,1):{2,3}})=={1,2,3})
parent={(1,1):(1,2),(1,2):(1,1)}
cost=np.ones((3,3));walk=np.ones((3,3),bool);clearance=np.ones((3,3))*100
check('invalid_parent_cycle_fallback',equal_cost_alternatives(cost,parent,clearance,walk,(0,0),(1,1))==[])
d={'status':'PASS','checks':checks,'examples':examples,'game_rounds':0,'server_commands':0,
 'canonical_route_fields_sha256':hashlib.sha256(source.encode()).hexdigest(),
 'helper_sha256':hashlib.sha256((F/'equal_cost_paths_preanalysis.py').read_bytes()).hexdigest(),
 'limits':'Only candidate path generation on fixed fake graphs qualified. No real visibility, smoothed route, turn complexity, final consumer or game-score claim. Not a production candidate.'}
p=F/'EQUAL_COST_PATHS_PREANALYSIS.json';assert not p.exists();p.write_bytes((json.dumps(d,indent=2)+'\n').encode())
print(json.dumps({'status':d['status'],'checks':len(checks),'examples':examples,'native_games':0}))
