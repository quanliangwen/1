from pathlib import Path
import ast
F=Path(__file__).resolve().parent;O=F.parent/'F16_measured_layout_frontier_20261027';T=F.parent/'F17_assignment_epoch_and_consumers_20261027'
def write(n,s,fragment=False):
 p=F/n;assert not p.exists()
 if not fragment:ast.parse(s)
 p.write_bytes(s.encode())
for n in ['layout_frontier.py','sensed_layout_context.py']:write(n,(T/n).read_text(encoding='utf-8'))
s=(O/'layout_preference.py').read_text(encoding='utf-8').replace('F16','F18')
s=s.replace("'memory':memory,'agents':agents", "'memory':memory,'immediate_owner':int(getattr(memory,'identifier',0)),'agents':agents")
marker="    step=int(getattr(memory,'step',0));attempts=getattr(memory,'_layout_preference_attempts',0)";assert s.count(marker)==1
s=s.replace(marker,"""    own=int(getattr(memory,'identifier',0))
    if not result.get(own) or own not in agents or int(agents[own][1])<=0 or own in (prefixes or {}):return result
"""+marker)
write('layout_preference.py',s)
s=(O/'helper_tests.py').read_text(encoding='utf-8');marker=" report.update(status='PASS')";assert s.count(marker)==1
extra=(F/'transaction_tests.py').read_text(encoding='utf-8')
s=s.replace(marker,'\n'.join(' '+x for x in extra.splitlines())+'\n'+marker);write('helper_tests.py',s)
s=(O/'qualify_helpers.py').read_text(encoding='utf-8').replace(O.name,F.name)
s=s.replace("'sensed_layout_context.py','helper_tests.py'","'sensed_layout_context.py','layout_preference.py','planning_cost_transaction.py','planning_profile.py','helper_tests.py'")
write('qualify_helpers.py',s)
