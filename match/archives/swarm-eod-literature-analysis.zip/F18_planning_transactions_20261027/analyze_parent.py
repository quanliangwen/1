from pathlib import Path
import json,datetime,subprocess,shlex,hashlib
F=Path(__file__).resolve().parent;G=F/'PARENT_M04_DIAG';assert not(F/'DIRECTION_ADMISSION.json').exists()
assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'))['valid']
E=json.loads((G/'EVENTS.json').read_text(encoding='utf-8'));R=json.loads((G/'RESULT.json').read_text(encoding='utf-8'))
assert R['complete'] and R['valid'] and not R['row']['crashed']
profiles=E['F18_PLAN_PROFILE'];totals={k:sum(x[k] for x in profiles) for k in ['field_calls','field_duplicates','field_duplicate_seconds','view_calls','view_duplicates','view_duplicate_seconds','view_conflicts','signature_seconds']}
delivery=[]
for e in E['F18_FRONTIER_ADVISOR']:
 p=e['proposals'].get('delivery')
 if p is None:continue
 assert p['owner']==e['owner'] and p['slot']==0 and not e['deadline_reached']
 assert p['nominal_after']>=.95*p['nominal_before']-1e-5 and p['confirmed_after']>=.95*p['confirmed_before']-1e-5
 assert p['RED_after']<=p['RED_before']+32.+1e-5 and p['RED_after']<=p['suffix_cap']+1e-5 and p['delivery_after']<=p['full_cap']+1e-5
 assert p['improvement']>=32.-1e-5;delivery.append(e)
gates={'S01':totals['field_duplicates']>=5 and totals['field_duplicate_seconds']>=.5,
       'S02':bool(delivery),'S03':totals['view_duplicates']>=3 and totals['view_duplicate_seconds']>=.25 and totals['view_conflicts']==0}
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PARENT_MECHANISM_OPPORTUNITIES_REVIEWED','gates':gates,
 'admitted_order':[v for v in ['S01','S02','S03'] if gates[v]],'profiled_original_calls_only':totals,'profile_reports':len(profiles),
 'own_immediate_delivery_opportunities':len(delivery),'delivery_example':delivery[:1],
 'production_limits_frozen_before_source':{'fields':32,'field_cache_max_bytes':8*1024*1024,'scope':'one_LNS_call_only','delivery_attempts':2,'delivery_gap':120,'delivery_seconds':.8,'delivery_success':1,'delivery_coverage_floor':.95},
 'helper_first_QA':94,'helper_revision1_QA':97,'helper_revision1_binding_sha256':hashlib.sha256((F/'helper_qualification_revision1/SOURCE_BINDING.json').read_bytes()).hexdigest(),
 'helper_accounting_refinement':'Fixed synthetic75x100 graph actualheap5.885MB vs oldconservative12.291MB causedavoidance despite8MiBfit. Samecaps32/8MiB, now conservativeCPythoncontainer/scalar-size bound, verified actualheap<=accounting andexactcosts on3fixedsizes in97QA. Parentstillusesoldhelperonlyfield_key/root, nevercache orgraphaccounting; no observedtrajectory change.',
 'parent_placed':[R['row']['placed'],R['row']['expected']],'raw_manifest_sha256':R['raw_manifest_sha256'],
 'not_performance_or_causal_claim':True,'reason':'Original planner profile scope closes BEFORE extra advisor, checked55QA+SDK. Duplicate-call durations are descriptive potential, not measured causal speedup. Only admitted mechanisms may build independent K01 children and native effectiveness checks before original-five.'}
p=F/'DIRECTION_ADMISSION.json';p.write_bytes((json.dumps(d,indent=2)+'\n').encode())
remote="from pathlib import Path;import sys;p=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F18_planning_transactions_20261027/DIRECTION_ADMISSION.json');assert not p.exists();p.write_bytes(sys.stdin.buffer.read())"
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(remote)],input=p.read_bytes(),check=True)
print(json.dumps({k:d[k] for k in ['gates','admitted_order','profiled_original_calls_only','own_immediate_delivery_opportunities','parent_placed']}))
