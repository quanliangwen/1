from pathlib import Path
import ast,base64,json,subprocess,shlex
F=Path(__file__).resolve().parent;O=F.parent/'F16_measured_layout_frontier_20261027';T=F.parent/'F13_completion_joint_transport_20261027';ref=T/'parent_source_reference'
def write(n,s):
 p=F/n;assert not p.exists();ast.parse(s);p.write_bytes(s.encode())
trust=(ref/'trust_region_cover.py').read_text(encoding='utf-8');marker='    pm=GeometryPlanningMemory(memory) if _prepared is None else _prepared\n';assert trust.count(marker)==1
trust=trust.replace(marker,marker+"    if getattr(memory,'_f18_layout_enabled',False): memory._f18_live_prepared=pm\n")
trust=trust.replace('TRUST_RADIUS_RATIO = 1.25','from swarm_rescue.solutions.planning_profile import profiled_view as GeometryPlanningMemory\n\nTRUST_RADIUS_RATIO = 1.25')
lns=(ref/'team_coverage_lns.py').read_text(encoding='utf-8').replace('    prepared=None\n','    _f18_full_budget=travel_budget\n    prepared=None\n',1)
marker='    return refine_trust_region(memory,agents,drops,radius,base,travel_budget=travel_budget,forbidden_points=forbidden_points,forbidden_mask=forbidden_mask,_prepared=prepared)';assert lns.count(marker)==1
lns=lns.replace(marker,'''    try:
        result=refine_trust_region(memory,agents,drops,radius,base,travel_budget=travel_budget,forbidden_points=forbidden_points,forbidden_mask=forbidden_mask,_prepared=prepared)
        if getattr(memory,'_f18_layout_enabled',False):
            from swarm_rescue.solutions.frontier_observer import observe_frontier
            observe_frontier(memory,agents,drops,radius,result,_f18_full_budget,travel_budget,reserved_prefixes,
                             forbidden_points,forbidden_mask,getattr(memory,'_f18_live_prepared',prepared))
        return result
    finally:
        if '_f18_live_prepared' in vars(memory):delattr(memory,'_f18_live_prepared')''')
lns=lns.replace('from swarm_rescue.solutions.trust_region_cover import refine_trust_region','from swarm_rescue.solutions.trust_region_cover import refine_trust_region\nfrom swarm_rescue.solutions.planning_profile import planning_profile,profiled_view as GeometryPlanningMemory')
tree=ast.parse(lns);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='plan_team_coverage_lns')
fn.body=[ast.With(items=[ast.withitem(context_expr=ast.Call(func=ast.Name(id='planning_profile',ctx=ast.Load()),args=[ast.Name(id='memory',ctx=ast.Load())],keywords=[]),optional_vars=None)],body=fn.body)]
lns=ast.unparse(ast.fix_missing_locations(tree))+'\n'
market=(F.parent/'F17_assignment_epoch_and_consumers_20261027/source_analysis_reference/team_coverage.py').read_text(encoding='utf-8')
market=market.replace('def path_costs(memory, walkable, start):','def _original_path_costs(memory, walkable, start):',1)
marker='\ndef _market_incumbent(';assert market.count(marker)==1
market=market.replace(marker,'''\nfrom swarm_rescue.solutions.planning_profile import profiled_path_costs,profiled_view as GeometryPlanningMemory
def path_costs(memory,walkable,start):
    return profiled_path_costs(memory,walkable,start,_original_path_costs)

def _market_incumbent(''')
diag=(O/'qualified_diagnostic_mixin_reference.py').read_text(encoding='utf-8').replace('F16','F18').replace('f16','f18')
marker="        state['completion_origins'] = sorted(self.completion_certificates)";assert diag.count(marker)==1
diag=diag.replace(marker,marker+"\n        state['planning_profile'] = dict(getattr(self.memory,'planning_profile_diagnostics',{}))\n        state['planning_cost'] = dict(getattr(self.memory,'planning_cost_diagnostics',{}))")
frontier=(F.parent/'F17_assignment_epoch_and_consumers_20261027/frontier_observer.py').read_text(encoding='utf-8').replace('F17','F18').replace('f17','f18')
marker="    step=int(getattr(root,'step',0));count=getattr(root,'_f18_frontier_count',0)";assert frontier.count(marker)==1
frontier=frontier.replace(marker,"""    own=int(getattr(root,'identifier',0))
    if not result.get(own) or own not in agents or int(agents[own][1])<=0 or own in (prefixes or {}):return
"""+marker);write('frontier_observer.py',frontier)
assets={'trust_region_cover.py':trust,'team_coverage_lns.py':lns,'team_coverage.py':market,'diagnostic_mixin.py':diag,
 **{n:(F/n).read_text(encoding='utf-8') for n in ['layout_frontier.py','sensed_layout_context.py','frontier_observer.py','planning_cost_transaction.py','planning_profile.py']}}
for s in assets.values():ast.parse(s)
payload={n:base64.b64encode(s.encode()).decode() for n,s in assets.items()}
code=r'''
from pathlib import Path
import json,sys,base64,hashlib,shutil,ast
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F18_planning_transactions_20261027'
assert json.loads((F/'helper_qualification/FIRST_RESULT.json').read_text())['status']=='PASS'
Q=F/'observer_qualification';assert not Q.exists();Q.mkdir();P=json.loads((F/'PREDECLARATION.json').read_text())['parent'];S=Q/'source';shutil.copytree(Path(P['path'])/'source',S)
for n,b in json.load(sys.stdin).items():(S/n).write_bytes(base64.b64decode(b))
p=S/'my_drone_eval.py';s=p.read_text();assert s.count('class MyDroneEval(')==1
s=s.replace('class MyDroneEval(','class BaseParent(',1)+"\nfrom swarm_rescue.solutions.diagnostic_mixin import DiagnosticMixin\nclass MyDroneEval(DiagnosticMixin,BaseParent):\n    F18_MODE='FRONTIER'\n";p.write_text(s)
for p in S.glob('*.py'):ast.parse(p.read_text())
(Q/'SOURCE_BINDING.json').write_text(json.dumps({'parent':P,'observer_source_files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in S.iterdir() if p.is_file()},'scope':'Original planner/path/view calls exactly once, readonly per-invocation own signatures/timing, eligible own immediate delivery advice. Original plans/commands unaffected. No candidate.'},indent=2)+'\n')
print(json.dumps({'source_files':len(list(S.iterdir())),'no_game_or_candidate':True}))
'''
r=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps(payload).encode());assert not(F/'observer_prepared.txt').exists();(F/'observer_prepared.txt').write_bytes(r);print(r.decode())
