"""Canonical own source, fixed fake vectors only; no server work during paired tests."""
from pathlib import Path
import ast,json,zipfile,hashlib,math,types
F=Path(__file__).resolve().parent;p=F/'SOURCE_ENDPOINT_CONTRACT_AUDIT.json';assert not p.exists()
with zipfile.ZipFile(F/'S01/team615_red_v24.zip') as z:raw=z.read('geometry_navigation.py')
source=raw.decode();tree=ast.parse(source);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='GeometryRouteMemory')
fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='route')
class V(tuple):
 def __new__(cls,*args):return tuple.__new__(cls,args)
 def __sub__(self,other):return V(*(a-b for a,b in zip(self,other)))
class Base:
 def route(self,*args,**kwargs):self.raw_calls+=1;return self.raw
env={'InferredFrameMemory':Base,'np':types.SimpleNamespace(linalg=types.SimpleNamespace(norm=lambda p:math.sqrt(sum(x*x for x in p))))}
def compile_method(name,text):
 method=ast.parse(text).body[0]
 node=ast.ClassDef(name=name,bases=[ast.Name(id='InferredFrameMemory',ctx=ast.Load())],keywords=[],body=[method],decorator_list=[])
 exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),'fixed_canonical_endpoint_contract','exec'),env)
 return env[name]
method=ast.get_source_segment(source,fn);Original=compile_method('Original',method)
assert method.count('if error<=40:')==1
ThresholdAblation=compile_method('ThresholdAblation',method.replace('if error<=40:','if error<1:'))
checks=[];examples=[]
def check(n,v):
 assert v,n
 checks.append(n)
def fixture(cls,raw_error,closer_error=0.):
 d=object.__new__(cls);d.raw_calls=0;d.fallback_calls=0;d.cache_calls=0;d.step=100;d.geometry_solids=();d.geometry_solids_step=100
 d.raw=([V(raw_error,0.)],V(raw_error,0.))
 def route_to(*args,**kwargs):d.fallback_calls+=1;return [V(closer_error,0.)],V(closer_error,0.)
 def get(*args):d.cache_calls+=1;return types.SimpleNamespace(route_to=route_to)
 d.geometry_cache=types.SimpleNamespace(get=get);return d
for error in [0.,1.,16.,32.,40.,48.]:
 a=fixture(Original,error);b=fixture(ThresholdAblation,error)
 ra=a.route(V(-100.,0.),destination=V(0.,0.));rb=b.route(V(-100.,0.),destination=V(0.,0.))
 check('original_once_'+str(error),a.raw_calls==b.raw_calls==1)
 check('original_fallback_threshold_'+str(error),a.fallback_calls==int(error>40.))
 check('ablation_fallback_threshold_'+str(error),b.fallback_calls==int(error>=1.))
 examples.append({'raw_endpoint_error':error,'original_fallback_calls':a.fallback_calls,'original_final_error':math.dist(ra[1],(0.,0.)),
                  'hypothetical_lower_threshold_calls':b.fallback_calls,'hypothetical_final_error':math.dist(rb[1],(0.,0.))})
for why,goal,utility in [('ordinary',None,None),('special_utility',V(0.,0.),object())]:
 a=fixture(ThresholdAblation,16.);a.route(V(-100.,0.),destination=goal,utility=utility)
 check('other_route_modes_unchanged_'+why,a.raw_calls==1 and a.fallback_calls==0)
for worse in [16.,48.]:
 a=fixture(ThresholdAblation,16.,worse);r=a.route(V(-100.,0.),destination=V(0.,0.))
 check('no_closer_geometry_keeps_raw_'+str(worse),r[1] is a.raw[1] and r[0] is a.raw[0])
d={'status':'PASS','checks':checks,'game_rounds':0,'server_commands':0,'canonical_file_sha256':hashlib.sha256(raw).hexdigest(),'examples':examples,
 'finding':'Canonical navigation only tries fitted-wall fallback when raw endpoint error>40, while fleet accepts exactendpoint error<1 then endpoint repair can snap within40. Fixed fake-state counterexample shows exact fitted endpoint can be skipped at1..40 error. This is an interface tradeoff, NOT proof baseline bug or real-map feasibility/score gain.',
 'next_evidence_needed':'Fresh current own requested-vs-returned endpoints, successful repair snaps, existing cached-view age and bounded exact fitted-route availability. Must validate collision/safety and actual usage before a source candidate or five-map experiment.',
 'risks':'Fallback model clearance22 differs from raw navigation; added routing cost and inferred geometry may be less conservative. No target/control production change. No claim this caused prior unexecuted preferences.',
 'arithmetic_scope':'Compiled actual canonical method with fixed stdlib fake vectors/norm/base route/cache; no SDK, NumPy array, game input, replay, private peer or BLUE object accessed.'}
p.write_bytes((json.dumps(d,indent=2)+'\n').encode());print(json.dumps({'status':d['status'],'checks':len(checks),'finding':d['finding'],'server_commands':0}))
