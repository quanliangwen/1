from pathlib import Path
import ast,subprocess,shlex,json
F=Path(__file__).resolve().parent
s=(F/'observer_tests_revision1.py').read_text(encoding='utf-8')
start=s.index(" source=source.replace(marker,marker+'''");end=s.index(" exec(compile(source,",start)
replacement="    elif any(pos is not None and int(count)>0 for pos,count in agents.values()):\n        prepared=GeometryPlanningMemory(memory)\n"
s=s[:start]+" source=source.replace(marker,marker+"+repr(replacement)+")\n"+s[end:]
marker=" original_refs=(old.GeometryPlanningMemory,single.GeometryPlanningMemory,market.GeometryPlanningMemory,trust.GeometryPlanningMemory)";assert s.count(marker)==1
s=s.replace(marker,""" baseline_market=types.ModuleType('canonical_market_synthetic')
 exec(compile((P/'team_coverage.py').read_text(),str(P/'team_coverage.py'),'exec'),baseline_market.__dict__)
 old._greedy_plan=single._greedy_plan=baseline_market.plan_team_coverage
 original_refs=(old.GeometryPlanningMemory,single.GeometryPlanningMemory,market.GeometryPlanningMemory,trust.GeometryPlanningMemory)
""")
marker='  old.GeometryPlanningMemory=single.GeometryPlanningMemory=market.GeometryPlanningMemory=trust.GeometryPlanningMemory=view_factory';assert s.count(marker)==1
s=s.replace(marker,marker+'\n  baseline_market.GeometryPlanningMemory=view_factory')
ast.parse(s);p=F/'observer_tests_revision2.py';assert not p.exists();p.write_bytes(s.encode())
s=(F/'qualify_observer_revision1.py').read_text(encoding='utf-8').replace('observer_tests_revision1.py','observer_tests_revision2.py').replace('observer_qualification_revision1','observer_qualification_revision2').replace('observer_revision1_console.txt','observer_revision2_console.txt')
ast.parse(s);p=F/'qualify_observer_revision2.py';assert not p.exists();p.write_bytes(s.encode())
code=r'''
from pathlib import Path
import json,hashlib,shutil
F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F18_planning_transactions_20261027');old=F/'observer_qualification_revision1';Q=F/'observer_qualification_revision2'
assert json.loads((old/'FIRST_RESULT.json').read_text())['status']=='FAIL' and not(old/'PREFLIGHT.json').exists()
assert not(F/'PARENT_M04_DIAG').exists() and not(F/'FIRST_NATIVE_ERROR.json').exists() and not Q.exists();Q.mkdir()
shutil.copytree(old/'source',Q/'source');shutil.copy2(old/'SOURCE_BINDING.json',Q/'SOURCE_BINDING.json')
d={'stage':'revision1_fixedstate_test_fixture','checks_before_failure':27,'error':'Indented nested multiline source literal malformed synthetic elif indentation. New test uses escaped literal; also binds canonical full market instead earlier stub so full pipeline is real. Observer production source bytes unchanged from revision1, original failures preserved.','native_games_started':0,'SDK_preflight_started':False,'first_result_sha256':hashlib.sha256((old/'FIRST_RESULT.json').read_bytes()).hexdigest()}
(F/'OBSERVER_QA_REVISION1_FAILURE.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
'''
r=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)]);p=F/'OBSERVER_QA_REVISION1_FAILURE.json';assert not p.exists();p.write_bytes(r);print(r.decode())
