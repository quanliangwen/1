from pathlib import Path
import json,math
F=Path(__file__).resolve().parent;T=F.parent/'F17_assignment_epoch_and_consumers_20261027'
out={'scope':'Own verified scalar samples only. EMA gain rarely exactly zero; identify active5percentgap floor directly, not by exact-zero gain. Equal sampled quality/known-free is incomplete information evidence, not proof no useful angular/geometry observation. No server work, arrays or production changes.','jobs':{}}
for root,name,prefix in [(T,'PARENT_M04_DIAG','F17'),(T,'R02_DIAG','F17'),(T,'R03_DIAG','F17'),(F,'PARENT_M04_DIAG','F18'),(F,'S01_DIAG','F18')]:
 G=root/name;assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'))['valid']
 E=json.loads((G/'EVENTS.json').read_text(encoding='utf-8'));owners={}
 for owner in range(5):
  records=sorted([x for x in E[prefix+'_DIAG_TICK'] if x['owner']==owner],key=lambda x:x['step']);last=None;unchanged_since=None;events=[]
  for x in records:
   stamp=(x.get('cached_map_quality'),x.get('known_free_fraction'))
   if last is None or stamp!=(last.get('cached_map_quality'),last.get('known_free_fraction')):unchanged_since=x['step']
   p=x.get('terminal_policy',{});before={} if last is None else last.get('terminal_policy',{})
   delta=p.get('acquisition_continue',0)-before.get('acquisition_continue',0)
   expected=p.get('last_acquisition_expected_gain');gap=p.get('last_total_gap')
   floor=expected is not None and gap is not None and gap>0 and abs(expected-.05*gap)<=1e-9*max(1.,gap)
   if delta>0 and floor:
    events.append({'step':x['step'],'model_updates':p.get('model_updates'),'continue_increase':delta,'gain_rate':x.get('terminal_gain_rate'),
     'expected':expected,'gap':gap,'unchanged_quality_sampled_steps':x['step']-unchanged_since,'wall_left':x['wall_left'],
     'execution':x.get('decision_snapshot',{}).get('coverage_model',{}).get('execution_steps')})
   last=x
  owners[owner]={'floor_active_continuation_samples':len(events),'floor_active_unchanged_quality_ge120':sum(e['unchanged_quality_sampled_steps']>=120 for e in events),'examples':events[:3]}
 out['jobs'][root.name+'/'+name]=owners
p=F/'ACQUISITION_FLOOR_SCALAR_AUDIT.json';assert not p.exists();p.write_bytes((json.dumps(out,indent=2)+'\n').encode())
for name,owners in out['jobs'].items():print(name,json.dumps({'floor_active_samples':sum(x['floor_active_continuation_samples'] for x in owners.values()),'unchanged_quality_ge120':sum(x['floor_active_unchanged_quality_ge120'] for x in owners.values())}))
