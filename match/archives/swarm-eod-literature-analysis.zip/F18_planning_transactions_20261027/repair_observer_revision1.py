from pathlib import Path
import ast,json,subprocess,shlex
F=Path(__file__).resolve().parent
s=(F/'observer_tests.py').read_text(encoding='utf-8')
old=''' def view_factory(memory,*args,**kwargs):
  counter.append(1);v=RealView(memory,*args,**kwargs)
  values=np.zeros(v.shape,np.float32);values[5,8]=1.;values[5,12]=1.
  v._coverage_values_cache=(32.,values,np.zeros(v.shape,bool))
  return v'''
new=''' class view_factory(RealView):
  def __init__(self,memory,*args,**kwargs):
   counter.append(1);super().__init__(memory,*args,**kwargs)
   values=np.zeros(self.shape,np.float32);values[5,8]=1.;values[5,12]=1.
   self._coverage_values_cache=(32.,values,np.zeros(self.shape,bool))'''
assert s.count(old)==1;s=s.replace(old,new)
ast.parse(s);p=F/'observer_tests_revision1.py';assert not p.exists();p.write_bytes(s.encode())
s=(F/'qualify_observer.py').read_text(encoding='utf-8')
s=s.replace("assert not p.exists();p.write_text(pre,encoding='utf-8')", "assert p.exists() and p.read_text(encoding='utf-8')==pre")
s=s.replace("(F/'observer_tests.py').read_bytes()", "(F/'observer_tests_revision1.py').read_bytes()")
s=s.replace("Q=F/'observer_qualification'", "Q=F/'observer_qualification_revision1'")
s=s.replace('observer_first_console.txt','observer_revision1_console.txt')
ast.parse(s);p=F/'qualify_observer_revision1.py';assert not p.exists();p.write_bytes(s.encode())
code=r'''
from pathlib import Path
import json,hashlib,ast,shutil
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F18_planning_transactions_20261027';old=F/'observer_qualification';Q=F/'observer_qualification_revision1'
assert json.loads((old/'FIRST_RESULT.json').read_text())['status']=='FAIL' and not(old/'PREFLIGHT.json').exists()
assert not(F/'PARENT_M04_DIAG').exists() and not(F/'FIRST_NATIVE_ERROR.json').exists() and not Q.exists()
Q.mkdir();S=Q/'source';shutil.copytree(old/'source',S)
p=S/'team_coverage.py';s=p.read_text();marker='from swarm_rescue.solutions.planning_profile import profiled_path_costs,profiled_view as GeometryPlanningMemory';assert s.count(marker)==1
s=s.replace(marker,'from swarm_rescue.solutions.planning_profile import profiled_path_costs,profiled_view')
tree=ast.parse(s)
class Fix(ast.NodeTransformer):
 def visit_Call(self,node):
  self.generic_visit(node)
  if isinstance(node.func,ast.Name) and node.func.id=='GeometryPlanningMemory':node.func.id='profiled_view'
  return node
tree=Fix().visit(tree);s=ast.unparse(ast.fix_missing_locations(tree))+'\n';p.write_bytes(s.encode())
binding=json.loads((old/'SOURCE_BINDING.json').read_text());binding['observer_source_files']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in S.iterdir() if p.is_file()}
binding['revision']='Fix readonly instrumentation type alias: preserve original GeometryPlanningMemory class for isinstance; wrap constructor calls only. Original failed QA/preflight-not-started preserved, no native game existed.'
(Q/'SOURCE_BINDING.json').write_text(json.dumps(binding,indent=2)+'\n')
failure={'stage':'observer_first_fixed_state_QA','checks_before_failure':7,'error':'Replaced class alias with function also used by isinstance in observed_wall_values. Fixed constructor calls only in new revision; original preserved.','native_games_started':0,'SDK_preflight_started':False,'first_result_sha256':hashlib.sha256((old/'FIRST_RESULT.json').read_bytes()).hexdigest()}
(F/'OBSERVER_QA_FIRST_FAILURE.json').write_text(json.dumps(failure,indent=2)+'\n');print(json.dumps(failure))
'''
r=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)]);p=F/'OBSERVER_QA_FIRST_FAILURE.json';assert not p.exists();p.write_bytes(r);print(r.decode())
