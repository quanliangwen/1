import json,time
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
from swarm_rescue.solutions.layout_frontier import frontier_advice


def observe_frontier(memory,agents,drops,radius,result,full_budget,suffix_budget,prefixes,
                     forbidden_points,forbidden_mask,prepared):
    root=memory
    while isinstance(root,GeometryPlanningMemory):root=root._memory
    if not getattr(root,'_f18_layout_enabled',False) or not any(result.values()):return
    own=int(getattr(root,'identifier',0))
    if not result.get(own) or own not in agents or int(agents[own][1])<=0 or own in (prefixes or {}):return
    step=int(getattr(root,'step',0));count=getattr(root,'_f18_frontier_count',0)
    if count>=2 or step-getattr(root,'_f18_frontier_last',-1000)<120:return
    root._f18_frontier_count=count+1;root._f18_frontier_last=step
    params={'memory':memory,'immediate_owner':int(getattr(root,'identifier',0)),'agents':agents,'drops':drops,'radius':radius,'travel_budget':suffix_budget,
            'full_budget':full_budget,'reserved_prefixes':prefixes,'forbidden_points':forbidden_points,
            'forbidden_mask':forbidden_mask,'route_epsilon':32.,'trust_radius_ratio':1.25}
    advice=frontier_advice(params,result,prepared,rally=getattr(root,'_f18_rally',None),seconds=.8,objectives=('delivery',))
    advice.update(owner=int(getattr(root,'identifier',0)),step=step,probe=count+1)
    print('[F18_FRONTIER_ADVISOR]',json.dumps(advice,separators=(',',':')),flush=True)
