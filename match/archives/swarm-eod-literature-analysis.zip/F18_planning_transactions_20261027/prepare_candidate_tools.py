from pathlib import Path
import ast
F=Path(__file__).resolve().parent;O=F.parent/'F17_assignment_epoch_and_consumers_20261027'
def write(n,s):
 p=F/n;assert not p.exists();ast.parse(s);p.write_bytes(s.encode())
for n in ['qualification_ABI_checks.py','ABI_receipt_fragment.py','candidate_common_contracts.py']:
 p=F/n;assert not p.exists();p.write_bytes((O/n).read_bytes())
s=(O/'candidate_preference_contracts.py').read_text(encoding='utf-8').replace('F17','F18').replace('f17','f18').replace("observer_qualification/SOURCE_BINDING.json","observer_qualification_revision3/SOURCE_BINDING.json")
p=F/'candidate_preference_contracts.py';assert not p.exists();p.write_bytes(s.encode())
s=(O/'qualify.py').read_text(encoding='utf-8').replace(O.name,F.name).replace('R01','S01').replace('R02','S02').replace('R03','S03')
s=s.replace("'S01':'candidate_epoch_contracts.py'","'S01':'candidate_planning_contracts.py'").replace("'S03':'candidate_horizon_contracts.py'","'S03':'candidate_planning_contracts.py'")
write('qualify.py',s)
for n in ['download_and_guard.py','collect_finished.py','client_verify_finished_cohort.py','review_pair.py','run_operator.py','read_perf_live.py','summarize_performance.py','prepare_performance_operators.py']:
 s=(O/n).read_text(encoding='utf-8').replace(O.name,F.name).replace('F17','F18').replace('f17','f18').replace('R01','S01').replace('R02','S02').replace('R03','S03')
 s=s.replace('assignment handoff, own immediate delivery and endpoint horizon ablations','same-call distance fields, eligible own immediate delivery and same-call geometry views')
 write(n,s)
