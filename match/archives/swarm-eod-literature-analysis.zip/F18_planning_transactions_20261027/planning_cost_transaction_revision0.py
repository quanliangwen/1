"""Exact distance-field reuse within one own-controller planning call only."""
from contextlib import contextmanager
import math
import time
import numpy as np
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory


def root_memory(memory):
    while isinstance(memory,GeometryPlanningMemory):memory=memory._memory
    return memory


def field_key(memory,walkable,start):
    try:
        scale=float(memory.CELL)
        if not math.isfinite(scale) or scale<=0:return None
        allowed=np.asarray(walkable,bool).copy();start=tuple(start)
        if allowed.ndim!=2 or len(start)!=2:return None
        allowed[start]=True
        return (allowed.shape,start,scale,allowed.tobytes())
    except (TypeError,ValueError,IndexError,OverflowError):return None


@contextmanager
def planning_cost_transaction(memory,capacity=32,max_bytes=8*1024*1024):
    root=root_memory(memory);marker='_planning_cost_transaction'
    previous=vars(root).get(marker)
    state={'fields':{},'graphs':{},'bytes':0,'capacity':int(capacity),'max_bytes':int(max_bytes),
           'calls':0,'hits':0,'misses':0,'bypassed':0,'lookup_seconds':0.,'source_seconds_on_reused_entries':0.}
    setattr(root,marker,state)
    try:yield state
    finally:
        if previous is None:vars(root).pop(marker,None)
        else:setattr(root,marker,previous)
        old=getattr(root,'planning_cost_diagnostics',{})
        root.planning_cost_diagnostics={k:old.get(k,0)+state[k] for k in ['calls','hits','misses','bypassed','lookup_seconds','source_seconds_on_reused_entries']}
        root.planning_cost_diagnostics.update(transactions=old.get('transactions',0)+1,
             peak_entries=max(old.get('peak_entries',0),len(state['fields'])),peak_bytes=max(old.get('peak_bytes',0),state['bytes']),
             cleanup_count=old.get('cleanup_count',0)+1)
        state['fields'].clear();state['graphs'].clear()


def cached_path_costs(memory,walkable,start,original):
    root=root_memory(memory);state=vars(root).get('_planning_cost_transaction')
    if state is None:return original(memory,walkable,start)
    state['calls']+=1;begun=time.perf_counter();key=field_key(memory,walkable,start)
    if key is not None and key in state['fields']:
        costs,graph,source_seconds=state['fields'][key]
        memory._coverage_graph_cache=graph
        state['hits']+=1;state['source_seconds_on_reused_entries']+=source_seconds
        result=costs.copy();state['lookup_seconds']+=time.perf_counter()-begun
        return result
    state['lookup_seconds']+=time.perf_counter()-begun
    state['misses']+=1;begun=time.perf_counter();result=original(memory,walkable,start)
    elapsed=time.perf_counter()-begun;graph=getattr(memory,'_coverage_graph_cache',None)
    if key is None or graph is None or len(state['fields'])>=state['capacity']:
        state['bypassed']+=1;return result
    # Conservative accounting; count shared adjacency storage only once.
    identity=id(graph[1]);extra_graph=0
    if identity not in state['graphs']:
        extra_graph=int(np.asarray(graph[0]).nbytes)+len(graph[1])*128+sum(map(len,graph[1]))*192+4096
    entry_bytes=len(key[3])+int(np.asarray(result).nbytes)+1024
    if state['bytes']+entry_bytes+extra_graph>state['max_bytes']:
        state['bypassed']+=1;return result
    state['fields'][key]=(result.copy(),graph,elapsed)
    state['graphs'][identity]=graph[1];state['bytes']+=entry_bytes+extra_graph
    return result
