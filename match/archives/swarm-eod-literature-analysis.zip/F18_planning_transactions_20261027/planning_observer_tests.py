from swarm_rescue.solutions import team_coverage as market
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory as RealView
from swarm_rescue.solutions.planning_profile import planning_profile,profiled_path_costs
calls=[];payload=np.zeros((4,4))
def one(*a,**k):calls.append(1);return payload
m=MapMemory(256,192);m.free[:]=True;m.step=1000;m.identifier=2
with planning_profile(m):
 answer=profiled_path_costs(m,np.ones((4,4),bool),(0,0),one)
check('profile_original_once_and_identity',len(calls)==1 and answer is payload)
# Compile an independent same-view variant on fixed synthetic maps only.
single=types.ModuleType('single_view_synthetic')
source=(P/'team_coverage_lns.py').read_text()
marker='        prepared,travel_budget=_prefix_budget_context(memory,agents,drops,radius,travel_budget,reserved_prefixes)\n'
assert source.count(marker)==1
source=source.replace(marker,marker+'''    elif any(pos is not None and int(count)>0 for pos,count in agents.values()):
        prepared=GeometryPlanningMemory(memory)
''')
exec(compile(source,'synthetic_single_view','exec'),single.__dict__)
original_refs=(old.GeometryPlanningMemory,single.GeometryPlanningMemory,market.GeometryPlanningMemory,trust.GeometryPlanningMemory)
counter=[]
def view_factory(memory,*args,**kwargs):
 counter.append(1);v=RealView(memory,*args,**kwargs)
 values=np.zeros(v.shape,np.float32);values[5,8]=1.;values[5,12]=1.
 v._coverage_values_cache=(32.,values,np.zeros(v.shape,bool))
 return v
try:
 old.GeometryPlanningMemory=single.GeometryPlanningMemory=market.GeometryPlanningMemory=trust.GeometryPlanningMemory=view_factory
 for name,cap,with_prefix,empty,blocked in [('normal',1000.,False,False,False),('tight',40.,False,False,False),('zero',0.,False,False,False),('prefix',1000.,True,False,False),('empty',1000.,False,True,False),('disconnected',1000.,False,False,True)]:
  a=MapMemory(256,192);a.free[:]=True;b=MapMemory(256,192);b.free[:]=True
  if blocked:a.free[:,9:11]=False;b.free[:,9:11]=False
  aa={2:(a.cell_to_world((5,3)),0 if empty else 2),3:(a.cell_to_world((5,14)),0 if empty else 2)}
  bb={k:(p.copy(),n) for k,(p,n) in aa.items()}
  prefix={2:(a.cell_to_world((5,2)),aa[2][0])} if with_prefix else None
  counter.clear();pa=old.plan_team_coverage_lns(a,aa,[],32.,travel_budget=cap,reserved_prefixes=prefix);counta=len(counter)
  counter.clear();pb=single.plan_team_coverage_lns(b,bb,[],32.,travel_budget=cap,reserved_prefixes=prefix);countb=len(counter)
  check('single_view_plan_exact_'+name,same(pa,pb))
  check('single_view_original_arrays_'+name,all(np.array_equal(getattr(a,k),getattr(b,k)) for k in ['free','hits','visits']))
  check('single_view_original_trust_counters_'+name,a.trust_region_diagnostics==b.trust_region_diagnostics)
  check('single_view_constructor_not_increased_'+name,countb<=counta)
  if name=='normal':check('actual_nonempty_two_views_become_one',any(pa.values()) and counta==2 and countb==1)
  if name=='prefix':check('existing_prefix_view_path_unchanged',counta==countb==1)
finally:old.GeometryPlanningMemory,single.GeometryPlanningMemory,market.GeometryPlanningMemory,trust.GeometryPlanningMemory=original_refs
