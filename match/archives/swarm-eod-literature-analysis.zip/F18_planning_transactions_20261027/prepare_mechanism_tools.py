from pathlib import Path
import json,base64,hashlib,subprocess,ast
F=Path(__file__).resolve().parent;O=F.parent/'F16_measured_layout_frontier_20261027';T=F.parent/'F17_assignment_epoch_and_consumers_20261027'
def write(n,s):
 p=F/n;assert not p.exists();ast.parse(s);p.write_bytes(s.encode())
code="from pathlib import Path;import json,base64,hashlib;Q=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F18_planning_transactions_20261027/observer_qualification_revision3');p=Q/'source/diagnostic_mixin.py';b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==json.loads((Q/'SOURCE_BINDING.json').read_text())['observer_source_files'][p.name];print(base64.b64encode(b).decode())"
raw=base64.b64decode(subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python','-'],input=code.encode()))
write('qualified_diagnostic_mixin_reference.py',raw.decode())
tree=ast.parse(raw.decode());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='DiagnosticMixin')
methods=ast.parse((O/'mechanism_observer_extensions.py').read_text(encoding='utf-8').replace('F16','F18')).body[0].body
names={n.name for n in methods if isinstance(n,ast.FunctionDef)};cls.body=[n for n in cls.body if not(isinstance(n,ast.FunctionDef) and n.name in names)]+methods
fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_diag_state');assert isinstance(fn.body[-1],ast.Return)
fn.body[-1:-1]=ast.parse("state['layout_preference']=dict(getattr(self.memory,'layout_preference_diagnostics',{}))\nstate['planning_view']=dict(getattr(self.memory,'planning_view_diagnostics',{}))\nstate['planning_cost_scope_active']='_planning_cost_transaction' in vars(self.memory)").body
source=ast.unparse(tree)+'\n';write('mechanism_diagnostic_mixin.py',source)
p=F/'MECHANISM_OBSERVER_BINDING.json';assert not p.exists();p.write_bytes((json.dumps({'qualified_base_sha256':hashlib.sha256(raw).hexdigest(),'mechanism_mixin_sha256':hashlib.sha256(source.encode()).hexdigest(),'scope':'Readonly production planner counters, target-selection and actual own inventory ACK. Original methods once, no production ZIP changes.'},indent=2)+'\n').encode())
s=(O/'mechanism_observer_tests.py').read_text(encoding='utf-8').replace('F16','F18')
s=s.replace("check('production_objective_bound',BaseParent.LAYOUT_PREFERENCE==json.loads((Q/'PRODUCTION_BINDING.json').read_text())['objective'])", "check('production_objective_bound',getattr(BaseParent,'LAYOUT_PREFERENCE',None)==('delivery' if json.loads((Q/'PRODUCTION_BINDING.json').read_text())['objective']=='delivery' else None))")
write('mechanism_observer_tests.py',s)
s=(T/'qualify_mechanism_observer.py').read_text(encoding='utf-8').replace(T.name,F.name).replace('F17','F18').replace('R01','S01').replace('R02','S02').replace('R03','S03')
s=s.replace("F/'observer_qualification/source/diagnostic_mixin.py'","F/'observer_qualification_revision3/source/diagnostic_mixin.py'").replace("F/'observer_qualification/preflight.py'","F/'observer_qualification_revision3/preflight.py'")
write('qualify_mechanism_observer.py',s)
s=(T/'stage_candidate_diagnostic.py').read_text(encoding='utf-8').replace(T.name,F.name).replace('F17','F18').replace('f17','f18').replace('R01','S01').replace('R02','S02').replace('R03','S03')
s=s.replace("'F18_FRONTIER_ADVISOR','F18_EPOCH_OPPORTUNITY','F18_ENDPOINT_OPPORTUNITY']","'F18_FRONTIER_ADVISOR','F18_PLAN_PROFILE']")
s=s.replace("'F18_PREFERENCE_APPLIED','F18_TARGET_SELECTED','F18_DROP_ACK','F18_SUFFIX_KEPT','F18_REPAIR_TARGET']","'F18_PREFERENCE_APPLIED','F18_TARGET_SELECTED','F18_DROP_ACK']")
write('stage_candidate_diagnostic.py',s)
