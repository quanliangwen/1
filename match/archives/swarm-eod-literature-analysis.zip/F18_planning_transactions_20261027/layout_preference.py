"""One bounded model tradeoff per own memory; original planner is the fallback."""
import json
import numpy as np
from swarm_rescue.solutions.layout_frontier import frontier_advice,OBJECTIVES


def apply_preference(memory,agents,drops,radius,result,full_budget,suffix_budget,prefixes,
                     forbidden_points,forbidden_mask,prepared):
    objective=getattr(memory,'_layout_preference_objective',None)
    if objective not in OBJECTIVES or getattr(memory,'_layout_preference_applied',False):return result
    own=int(getattr(memory,'identifier',0))
    if not result.get(own) or own not in agents or int(agents[own][1])<=0 or own in (prefixes or {}):return result
    step=int(getattr(memory,'step',0));attempts=getattr(memory,'_layout_preference_attempts',0)
    if attempts>=2 or step-getattr(memory,'_layout_preference_last',-1000)<120 or not any(result.values()):return result
    memory._layout_preference_attempts=attempts+1;memory._layout_preference_last=step
    params={'memory':memory,'immediate_owner':int(getattr(memory,'identifier',0)),'agents':agents,'drops':drops,'radius':radius,'travel_budget':suffix_budget,
            'full_budget':full_budget,'reserved_prefixes':prefixes,'forbidden_points':forbidden_points,
            'forbidden_mask':forbidden_mask,'route_epsilon':32.,'trust_radius_ratio':1.25}
    audit=frontier_advice(params,result,prepared,rally=getattr(memory,'_layout_preference_rally',None),
                          seconds=.8,objectives=(objective,))
    proof=audit['proposals'].get(objective)
    memory.layout_preference_diagnostics={'objective':objective,'attempts':attempts+1,'applied':0,
                                          'reason':audit['reason'],'seconds':audit['seconds']}
    if proof is None or audit['deadline_reached']:return result
    proposed={int(k):[np.asarray(p,float) for p in ps] for k,ps in proof['alternative'].items()}
    if proposed.keys()!=result.keys() or any(len(proposed[k])!=len(result[k]) for k in result):return result
    memory._layout_preference_applied=True
    memory.layout_preference_diagnostics.update(applied=1,proof=proof)
    print('[F18_PREFERENCE_APPLIED]',json.dumps({'owner':int(getattr(memory,'identifier',0)),
        'step':step,'objective':objective,'attempt':attempts+1,'seconds':audit['seconds'],'proof':proof},separators=(',',':')),flush=True)
    return proposed
