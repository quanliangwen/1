from pathlib import Path
import ast
F=Path(__file__).resolve().parent
p=F/'planning_cost_transaction.py';old=p.read_bytes();backup=F/'planning_cost_transaction_revision0.py';assert not backup.exists();backup.write_bytes(old)
s=old.decode().replace('import math\n','import math\nimport sys\n',1)
marker='\ndef cached_path_costs(memory,walkable,start,original):';assert s.count(marker)==1
s=s.replace(marker,'''
def graph_storage_bound(graph):
    allowed,adjacency=graph
    # Original locked supplier builds <=8 (Python int, Python float) edges/node.
    # Count each edge's scalar payload separately, conservatively even if shared.
    if any(len(row)>8 for row in adjacency):return math.inf
    edge_bytes=sys.getsizeof((0,0.0))+sys.getsizeof(max(0,len(adjacency)-1))+sys.getsizeof(1.0)
    row_bytes=max(sys.getsizeof([]),sys.getsizeof([None]*8))+8
    return (int(np.asarray(allowed).nbytes)+sys.getsizeof(adjacency)+len(adjacency)*row_bytes+
            sum(map(len,adjacency))*edge_bytes+4096)

def cached_path_costs(memory,walkable,start,original):''')
s=s.replace('extra_graph=int(np.asarray(graph[0]).nbytes)+len(graph[1])*128+sum(map(len,graph[1]))*192+4096','extra_graph=graph_storage_bound(graph)')
ast.parse(s);p.write_bytes(s.encode())
s=(F/'helper_tests.py').read_text(encoding='utf-8');marker=" report.update(status='PASS')";assert s.count(marker)==1
extra=""" from swarm_rescue.solutions.planning_cost_transaction import graph_storage_bound
 import sys as _sys
 def deep_bytes(value):
  seen=set();todo=[value];size=0
  while todo:
   item=todo.pop()
   if id(item) in seen:continue
   seen.add(id(item));size+=_sys.getsizeof(item)
   if isinstance(item,(list,tuple)):todo.extend(item)
   elif isinstance(item,dict):todo.extend(item.keys());todo.extend(item.values())
  return size
 for width,height in [(640,480),(1280,960),(1600,1200)]:
  m=MapMemory(width,height);m.free[:]=True
  with planning_cost_transaction(m) as state:
   a=cached_path_costs(m,m.free,(0,0),original_costs);b=cached_path_costs(m,m.free,(0,0),original_costs)
   actual=deep_bytes((state['fields'],state['graphs']))
   check('fixed_graph_heap_bound_'+str(width),state['hits']==1 and actual<=state['bytes']<=8*1024*1024 and np.array_equal(a,b))
"""
s=s.replace(marker,extra+marker);ast.parse(s);p=F/'helper_tests_revision1.py';assert not p.exists();p.write_bytes(s.encode())
s=(F/'qualify_helpers.py').read_text(encoding='utf-8')
s=s.replace("(F/n).read_bytes()","(F/('helper_tests_revision1.py' if n=='helper_tests.py' else n)).read_bytes()")
s=s.replace("Q=F/'helper_qualification'","Q=F/'helper_qualification_revision1'").replace('helper_first_console.txt','helper_revision1_console.txt')
ast.parse(s);p=F/'qualify_helpers_revision1.py';assert not p.exists();p.write_bytes(s.encode())
