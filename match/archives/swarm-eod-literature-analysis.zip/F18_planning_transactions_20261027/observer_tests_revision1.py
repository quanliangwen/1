from pathlib import Path
import sys,json,types,time,traceback,ast
Q=Path(__file__).resolve().parent;W=Q/'workspace';F=Q.parent
report={'status':'STARTED','checks':[],'game_rounds':0}
def check(n,v):
 assert v,n
 report['checks'].append(n)
try:
 sys.path.insert(0,str(W/'src'))
 import numpy as np,cv2,pandas
 from swarm_rescue.solutions.greedy_mapping import MapMemory
 from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
 from swarm_rescue.solutions import trust_region_cover as trust,team_coverage_lns as current
 from swarm_rescue.solutions.frontier_observer import observe_frontier
 from swarm_rescue.solutions.diagnostic_mixin import DiagnosticMixin
 from swarm_rescue.solutions.my_drone_eval import MyDroneEval,BaseParent
 from swarm_rescue.simulation.reporting.team_info import TeamInfo
 from swarm_rescue.launcher import Launcher
 from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
 import numpy.random.mtrand
 check('native_versions',(np.__version__,pandas.__version__,cv2.__version__)==('1.26.4','3.0.6','4.11.0'))
 check('actual_mtrand',np.isfinite(np.random.RandomState(615).normal(size=8)).all())
 check('team615_integer',type(TeamInfo().team_number) is int and TeamInfo().team_number==615)
 check('actual_payload',Path(current.__file__).resolve().is_relative_to(W))
 check('diagnostic_factory',MyDroneEval.__mro__[1].__name__=='DiagnosticMixin')
 check('placement_ancestor_unchanged',next(c.__name__ for c in MyDroneEval.__mro__ if '_maybe_place' in c.__dict__)=='ActiveCoverageMixin')
 parent=json.loads((F/'PREDECLARATION.json').read_text())['parent'];P=Path(parent['path'])/'source'
 oldtree=ast.parse((P/'trust_region_cover.py').read_text());newtree=ast.parse(Path(trust.__file__).read_text())
 fn=next(n for n in newtree.body if isinstance(n,ast.FunctionDef) and n.name=='refine_trust_region')
 fn.body=[n for n in fn.body if not(isinstance(n,ast.If) and any(isinstance(v,ast.Attribute) and v.attr=='_f18_live_prepared' for v in ast.walk(n)))]
 newtree.body=[n for n in newtree.body if not(isinstance(n,ast.ImportFrom) and n.module=='swarm_rescue.solutions.planning_profile')]
 check('original_numeric_AST_unchanged',ast.dump(oldtree)==ast.dump(newtree))
 old=types.ModuleType('original_lns_reference');exec(compile((P/'team_coverage_lns.py').read_text(),str(P/'team_coverage_lns.py'),'exec'),old.__dict__)
 def same(a,b):return a.keys()==b.keys() and all(len(a[k])==len(b[k]) and all(np.array_equal(p,q) for p,q in zip(a[k],b[k])) for k in a)
 def fixture(enabled=True,prefix=False):
  m=MapMemory(640,256);m.free[:]=True;m.identifier=2;m.step=1000;m._f18_layout_enabled=enabled
  pm=GeometryPlanningMemory(m);pm._coverage_values_cache=(32.,np.zeros(m.shape,np.float32),np.zeros(m.shape,bool));m._test_pm=pm
  base={2:[m.cell_to_world((5,25)),m.cell_to_world((5,15))]};agents={2:(m.cell_to_world((5,5)),2)}
  prefixes={2:(m.cell_to_world((5,3)),agents[2][0])} if prefix else None
  m._f18_rally=np.zeros(2);return m,pm,base,agents,prefixes
 for label,prefix,cap in [('normal',False,2000.),('prefix',True,2000.),('tight',False,100.)]:
  a,pa,base,agents,pref=fixture(False,prefix);b,pb,baseb,agentsb,prefb=fixture(True,prefix)
  factory=trust.GeometryPlanningMemory;greedy=current._greedy_plan
  try:
   trust.GeometryPlanningMemory=lambda m:m._test_pm
   old._greedy_plan=lambda *args,**kw:{k:[p.copy() for p in ps] for k,ps in base.items()}
   current._greedy_plan=lambda *args,**kw:{k:[p.copy() for p in ps] for k,ps in baseb.items()}
   ra=old.plan_team_coverage_lns(a,agents,[],32.,travel_budget=cap,reserved_prefixes=pref)
   rb=current.plan_team_coverage_lns(b,agentsb,[],32.,travel_budget=cap,reserved_prefixes=prefb)
  finally:trust.GeometryPlanningMemory=factory;current._greedy_plan=greedy
  check('original_result_'+label,same(ra,rb));check('original_counters_'+label,a.trust_region_diagnostics==b.trust_region_diagnostics)
  check('original_arrays_'+label,all(np.array_equal(getattr(a,k),getattr(b,k)) for k in ['hits','free','visits']))
  check('temporary_context_removed_'+label,'_f18_live_prepared' not in vars(b))
 check('live_callback_executed',b._f18_frontier_count==1)
 # Exercise a positive measured tradeoff through the actual observer callback.
 m=MapMemory(256,128);m.free[:]=True;m.step=1000;m.identifier=7;m._f18_layout_enabled=True
 pm=GeometryPlanningMemory(m);values=np.zeros(m.shape,np.float32);values[1,8]=1.;values[3,12]=.03
 pm._coverage_values_cache=(64.,values,np.zeros(m.shape,bool));allowed=np.zeros(m.shape,bool);allowed[3,10]=allowed[3,6]=True
 m.nonwall_mask=np.zeros(m.hit_shape,bool);m.nonwall_mask[4*8:5*8,14*8:15*8]=True
 base={7:[m.cell_to_world((3,10))]};agents={7:(m.cell_to_world((4,8)),1)};before=base[7][0].copy()
 observe_frontier(m,agents,[],64.,base,{7:100.},{7:100.},None,(),~allowed,pm)
 check('positive_callback_is_readonly',np.array_equal(before,base[7][0]) and m._f18_frontier_count==1)
 observe_frontier(m,agents,[],64.,base,{7:100.},{7:100.},None,(),~allowed,pm)
 check('same_step_probe_not_repeated',m._f18_frontier_count==1)
 class Parent:
  def control(self):self.control_calls+=1;return self.command
  def _build_fleet_plan(self,step):self.build_calls+=1;return 'original_build'
 class Probe(DiagnosticMixin,Parent):F18_MODE='FRONTIER'
 d=object.__new__(Probe);d._diag_core_state=lambda:{'owner':0,'step':200,'stock':0};d.fleet_states={0:(200,np.zeros(2),0)}
 d.fleet_plan=None;d.memory=types.SimpleNamespace(exploration_goal=None);d.pose=np.zeros(2);d.rally=np.zeros(2);d.coverage_ready=True
 d._seeking_fusion=False;d._sortie_state='DOCK';d.pending_drop=None;d.coverage_model={};d.completion_certificates={0:180};d.elapsed_timestep=200;d.STATE_FRESH_STEPS=120
 d.team_size=3;d._diag_first_complete=None;d._diag_costs={};d._diag_last_tick=-1000;d._diag_complete_seen=False;d._diag_end_opportunities=0;d.submitted=False
 d.walltime_limit=180.;d.elapsed_walltime=20.;d._remaining_steps=lambda:1000.;d.control_calls=d.build_calls=0
 d.command={'forward':.3,'lateral':-.1,'rotation':0.,'place_bomb':0};command_before=dict(d.command)
 state=d._diag_state();check('actual_telemetry_smoke',state['completion_origins']==[0] and state['decision_snapshot']['sortie_state']=='DOCK')
 r=d.control();check('original_control_return_identity',r is d.command and d.command==command_before and d.control_calls==1)
 r=d._build_fleet_plan(200);check('original_build_once',r=='original_build' and d.build_calls==1)
 check('own_rally_only_context',np.array_equal(d.memory._f18_rally,d.rally) and d.memory._f18_rally is not d.rally)
 from swarm_rescue.solutions import team_coverage as market
 from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory as RealView
 from swarm_rescue.solutions.planning_profile import planning_profile,profiled_path_costs
 calls=[];payload=np.zeros((4,4))
 def one(*a,**k):calls.append(1);return payload
 m=MapMemory(256,192);m.free[:]=True;m.step=1000;m.identifier=2
 with planning_profile(m):
  answer=profiled_path_costs(m,np.ones((4,4),bool),(0,0),one)
 check('profile_original_once_and_identity',len(calls)==1 and answer is payload)
 # Compile an independent same-view variant on fixed synthetic maps only.
 single=types.ModuleType('single_view_synthetic')
 source=(P/'team_coverage_lns.py').read_text()
 marker='        prepared,travel_budget=_prefix_budget_context(memory,agents,drops,radius,travel_budget,reserved_prefixes)\n'
 assert source.count(marker)==1
 source=source.replace(marker,marker+'''    elif any(pos is not None and int(count)>0 for pos,count in agents.values()):
         prepared=GeometryPlanningMemory(memory)
 ''')
 exec(compile(source,'synthetic_single_view','exec'),single.__dict__)
 original_refs=(old.GeometryPlanningMemory,single.GeometryPlanningMemory,market.GeometryPlanningMemory,trust.GeometryPlanningMemory)
 counter=[]
 class view_factory(RealView):
  def __init__(self,memory,*args,**kwargs):
   counter.append(1);super().__init__(memory,*args,**kwargs)
   values=np.zeros(self.shape,np.float32);values[5,8]=1.;values[5,12]=1.
   self._coverage_values_cache=(32.,values,np.zeros(self.shape,bool))
 try:
  old.GeometryPlanningMemory=single.GeometryPlanningMemory=market.GeometryPlanningMemory=trust.GeometryPlanningMemory=view_factory
  for name,cap,with_prefix,empty,blocked in [('normal',1000.,False,False,False),('tight',40.,False,False,False),('zero',0.,False,False,False),('prefix',1000.,True,False,False),('empty',1000.,False,True,False),('disconnected',1000.,False,False,True)]:
   a=MapMemory(256,192);a.free[:]=True;b=MapMemory(256,192);b.free[:]=True
   if blocked:a.free[:,9:11]=False;b.free[:,9:11]=False
   aa={2:(a.cell_to_world((5,3)),0 if empty else 2),3:(a.cell_to_world((5,14)),0 if empty else 2)}
   bb={k:(p.copy(),n) for k,(p,n) in aa.items()}
   prefix={2:(a.cell_to_world((5,2)),aa[2][0])} if with_prefix else None
   counter.clear();pa=old.plan_team_coverage_lns(a,aa,[],32.,travel_budget=cap,reserved_prefixes=prefix);counta=len(counter)
   counter.clear();pb=single.plan_team_coverage_lns(b,bb,[],32.,travel_budget=cap,reserved_prefixes=prefix);countb=len(counter)
   check('single_view_plan_exact_'+name,same(pa,pb))
   check('single_view_original_arrays_'+name,all(np.array_equal(getattr(a,k),getattr(b,k)) for k in ['free','hits','visits']))
   check('single_view_original_trust_counters_'+name,a.trust_region_diagnostics==b.trust_region_diagnostics)
   check('single_view_constructor_not_increased_'+name,countb<=counta)
   if name=='normal':check('actual_nonempty_two_views_become_one',any(pa.values()) and counta==2 and countb==1)
   if name=='prefix':check('existing_prefix_view_path_unchanged',counta==countb==1)
 finally:old.GeometryPlanningMemory,single.GeometryPlanningMemory,market.GeometryPlanningMemory,trust.GeometryPlanningMemory=original_refs
 report.update(status='PASS',scope='Actual telemetry/control/build/callback paths and original plan/counters/arrays, synthetic graph, native SDK/ABI; no simulator/candidate/history.')
except BaseException:report.update(status='FAIL',error=traceback.format_exc());raise
finally:
 (Q/'FIRST_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'checks':len(report['checks']),'error':report.get('error')}))
