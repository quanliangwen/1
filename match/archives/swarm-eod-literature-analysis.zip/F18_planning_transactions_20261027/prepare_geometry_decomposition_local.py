"""Source-only preparation. No server calls, sensors, simulations or installs."""
from pathlib import Path
import ast, hashlib, json

F=Path(__file__).resolve().parent
src=F/'next_direction_source_reference/coverage_geometry.py'
text=src.read_text(encoding='utf-8')
root=ast.parse(text)
fn=next(n for n in root.body if isinstance(n,ast.FunctionDef) and n.name=='geometry_wall_values')
original=ast.get_source_segment(text,fn)
assert original.count('    if allow_open_rectangles:')==1
assert original.count('    values=cv2.resize(values,')==1
assert original.count('    values[frame]*=.5')==1
changed=original.replace('def geometry_wall_values(', 'def geometry_evidence_components(',1)
changed=changed.replace('    solids=np.zeros_like(measured)',
                        '    measured_values=values.copy()\n    solids=np.zeros_like(measured)',1)
changed=changed.replace('    if allow_open_rectangles:',
                        '    closed_values=values.copy()\n    if allow_open_rectangles:',1)
changed=changed.replace('    values=cv2.resize(values,',
    '    components=(measured_values,closed_values-measured_values,values-closed_values)\n    values=cv2.resize(values,',1)
changed=changed.replace('    values[frame]*=.5',
    '    values[frame]*=.5\n    components=tuple(cv2.resize(v,(memory.shape[1],memory.shape[0]),interpolation=cv2.INTER_AREA) for v in components)\n    for component in components: component[frame]*=.5',1)
changed=changed.replace('        return values,solids','        return values,solids,components',1)
changed=changed.replace('    return values\n','    return values,components\n',1)
if changed.endswith('    return values'): changed=changed[:-len('    return values')]+'    return values,components'
out='"""Diagnostic only: exact canonical model with additive evidence layers.\nNot a production change or an estimate of true walls.\n"""\n'+ '\n'.join(text.splitlines()[7:10])+'\n\n'+changed+'\n'
# Keep the exact imports, without relying on line positions.
imports='\n'.join(ast.get_source_segment(text,n) for n in root.body if isinstance(n,(ast.Import,ast.ImportFrom)))
out='"""Diagnostic only: additive measured/closed-inferred/open-inferred layers."""\n'+imports+'\n\n'+changed+'\n'
compile(out,'geometry_evidence_components.py','exec')
p=F/'geometry_evidence_components.py'
assert not p.exists()
p.write_bytes(out.encode())
receipt={'status':'SOURCE_PREPARED_NOT_RUNTIME_QUALIFIED','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),
 'helper_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'game_rounds':0,'server_commands':0,
 'purpose':'Separate direct fitted lines, additional closed-solid inference and additional open-rectangle inference. Exact contour logic and total model unchanged; additive layers are internal diagnostics, not truth.',
 'required_runtime_tests':['all outputs equal canonical on fixed measured-hit fixtures','component nonnegativity and sum within float32 tolerance','frame attenuation applied identically','visited/free contradictions retain original semantics','no input mutations'],
 'local_environment_note':'Local preparation found cv2 unavailable; no installation and no runtime claim. Actual tests await native evaluator idle.'}
(F/'GEOMETRY_DECOMPOSITION_PREPARATION.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps(receipt))
