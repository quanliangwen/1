from pathlib import Path
import sys,json,math,datetime,hashlib,subprocess,shlex
F=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['S01','S02','S03'];G=F/(v+'_DIAG');C=F/v
assert not(G/'MECHANISM_REVIEW.json').exists()
assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'))['valid']
B=json.loads((C/'BUILD.json').read_text(encoding='utf-8'));contract=json.loads((C/'CONTRACT_RESULT.json').read_text(encoding='utf-8'))
assert contract['status']=='PASS' and contract['source_zip_sha256']==B['zip_sha256']
assert json.loads((G/'STAGING.json').read_text(encoding='utf-8'))['production_candidate_sha256']==B['zip_sha256']
guard=json.loads((C/'STRICT_PACKAGE_GUARD.json').read_text(encoding='utf-8'));assert guard['status']=='PASS' and guard['sha256']==B['zip_sha256']
E=json.loads((G/'EVENTS.json').read_text(encoding='utf-8'));R=json.loads((G/'RESULT.json').read_text(encoding='utf-8'))
ticks=E['F18_DIAG_TICK']+E['F18_SUBMIT_CALL'];latest={}
for t in sorted(ticks,key=lambda t:t['step']):latest[t['owner']]=t
acks=E['F18_DROP_ACK'];fields={str(k):x.get('planning_cost',{}) for k,x in latest.items()};views={str(k):x.get('planning_view',{}) for k,x in latest.items()}
matches=[]
if v=='S01':
 assert all(not x.get('planning_cost_scope_active',False) for x in ticks)
 for x in fields.values():
  if not x:continue
  assert x['peak_entries']<=32 and x['peak_bytes']<=8*1024*1024 and x['transactions']==x['cleanup_count']
 hits=sum(x.get('hits',0) for x in fields.values());admit=hits>=1 and len(acks)>=1
 summary={'actual_reuse_hits':hits,'actual_inventory_acks':len(acks),'owner_counters':fields,'scope_active_after_call':False}
elif v=='S03':
 shared=sum(x.get('nonempty_shared',0) for x in views.values());admit=shared>=1 and len(acks)>=1
 summary={'nonempty_actual_single_view_calls':shared,'actual_inventory_acks':len(acks),'owner_counters':views}
else:
 for a in E['F18_PREFERENCE_APPLIED']:
  p=a['proof'];owner=p['owner'];target=p['target'];assert owner==a['owner'] and p['slot']==0
  assert p['nominal_after']>=.95*p['nominal_before']-1e-5 and p['confirmed_after']>=.95*p['confirmed_before']-1e-5
  targets=[x for x in E['F18_TARGET_SELECTED'] if x['owner']==owner and x['step']>=a['step'] and math.dist(x['goal'],target)<=1.]
  ack=[x for x in acks if x['owner']==owner and x['pending_step']>=a['step'] and math.dist(x['position'],target)<=30. and any(t['step']<=x['pending_step'] for t in targets)]
  matches.append({'application':a,'targets':targets,'acks':ack})
 admit=any(x['targets'] and x['acks'] for x in matches);summary={'applications':len(matches),'executed_and_acknowledged':sum(bool(x['acks']) for x in matches),'matches':matches}
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':v,'start_five_map_now':admit,'source_zip_sha256':B['zip_sha256'],
 'qualification_checks':len(contract['checks']),'package_guard_sha256':hashlib.sha256((C/'STRICT_PACKAGE_GUARD.json').read_bytes()).hexdigest(),
 'mechanism':summary,'stock':[R['row']['placed'],R['row']['expected']],'diagnostic_steps':R['row']['timestep'],'diagnostic_seconds_not_performance':R['row']['walltime'],
 'reason':'Actual declared mechanism present with own inventory ACK and qualified source/caps; enter original-five. Exact reuse expects same targets; no score or causal speed inference.' if admit else 'Declared actual mechanism not present/acknowledged; do not expand full-five. Preserve valid diagnostic, no general inferiority claim.',
 'not_performance_or_causal_claim':True}
p=G/'MECHANISM_REVIEW.json';p.write_bytes((json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode())
remote="from pathlib import Path;import sys;p=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F18_planning_transactions_20261027')/"+repr(v+'_DIAG')+"/'MECHANISM_REVIEW.json';assert not p.exists();p.write_bytes(sys.stdin.buffer.read())"
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(remote)],input=p.read_bytes(),check=True)
print(json.dumps({k:d[k] for k in ['candidate_id','start_five_map_now','mechanism','stock','reason']}))
