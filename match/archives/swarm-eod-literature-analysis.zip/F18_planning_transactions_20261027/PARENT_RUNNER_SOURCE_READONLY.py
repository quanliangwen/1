from pathlib import Path
import datetime,fcntl,hashlib,json,os,signal,subprocess,time,traceback,tarfile
R=Path('/home/junhao/quan/parallel_test_solver/match');F=Path(__file__).resolve().parent
G=F/'PARENT_M04_DIAG';W=Path(json.loads((G/'STAGING.json').read_text())['workspace'])
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(path,data):
 q=path.with_suffix(path.suffix+'.tmp');q.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');q.replace(path)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert not(G/'STATUS.json').exists()
phase_lock=(F/'coordinator.lock').open('a+');fcntl.flock(phase_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
lock=(R/'solver_study/serial_evaluation.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
state={'utc':utc(),'pid':os.getpid(),'status':'PARENT_M04_DIAGNOSTIC_PREFLIGHT','kind':'SINGLE_MAP04_PARENT_OBSERVER_NO_PERFORMANCE_RANKING','new_algorithm':False}
save(G/'STATUS.json',state);save(F/'STATUS.json',state)
child=None
def stopped(sig,frame):
 (F/'STOP_REQUESTED').write_text(utc()+' humanstop\n')
 if child is not None and child.poll() is None:os.killpg(child.pid,signal.SIGTERM)
signal.signal(signal.SIGTERM,stopped);signal.signal(signal.SIGINT,stopped)
def activity(pids,status):
 p=R/'solver_study/heuristic_20261016.json';a=json.loads(p.read_text());a.update(active_processes=pids,current_formal_active=None,current_work={'kind':'F18_single_red_diagnostic','path':str(F),'phase':status,'updated_utc':utc()},updated_utc=utc());save(p,a)
try:
 with (G/'preflight.log').open('x') as log:
  pre=subprocess.run(['bash',str(R/'run_server.sh'),'-u',str(G/'preflight.py')],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
 assert pre.returncode==0,'First diagnostic SDK preflight failed; no retry'
 pre=json.loads((G/'PREFLIGHT.json').read_text());assert pre['status']=='PASS'
 assert not(F/'STOP_REQUESTED').exists()
 out=G/'Map04_red';assert not out.exists();out.mkdir()
 command=['bash',str(R/'run_server.sh'),'-u',str(R/'solver_study/framework_screen_20261016/unseeded_direct_v1.py'),'--workspace',str(W),'--map','Map04','--mode','place','--out',str(out),'--rounds','1']
 save(G/'GAME_PREDECLARATION.json',{'utc':utc(),'command':command,'mode':'RED_only','maps':['Map04'],'rounds':1,'external_seed':None,'fresh_controller_processes':True,'source_files':json.loads((G/'STAGING.json').read_text())['source_files'],'no_BLUE':True,'qualification_sha256':sha(G/'PREFLIGHT.json'),'not_for_performance_ranking':True,'external_hang_watchdog_seconds':600,'no_retry':True})
 with (out/'console.log').open('x') as log:
  child=subprocess.Popen(command,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 save(G/'LAUNCH.json',{'utc':utc(),'native_pid':child.pid,'native_starttime_ticks':(Path('/proc')/str(child.pid)/'stat').read_text().split()[21],'command':command})
 state.update(status='PARENT_M04_MAP04_RED_DIAGNOSTIC_RUNNING',native_pid=child.pid,updated_utc=utc());save(G/'STATUS.json',state);save(F/'STATUS.json',state);activity([os.getpid(),child.pid],state['status'])
 try:code=child.wait(timeout=600)
 except subprocess.TimeoutExpired:
  os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=30);raise RuntimeError('First native diagnostic external hang watchdog; no retry')
 assert not(F/'STOP_REQUESTED').exists(),'Human stop'
 assert code==0,'First native diagnostic failed; no retry'
 summary=json.loads((out/'summary.json').read_text());assert len(summary['rounds'])==1 and not summary['rounds'][0]['crashed']
 stage=json.loads((G/'STAGING.json').read_text())
 assert {p.name:sha(p) for p in (W/'src/swarm_rescue/solutions').iterdir() if p.is_file()}=={n:h for n,h in stage['source_files'].items() if n!='req.txt'}
 text=(out/'console.log').read_text(errors='replace');events={n:[] for n in ['F18_DIAG_TICK','F18_SUBMIT_DECISION','F18_SUBMIT_CALL','F18_REFINE','F18_FRONTIER_ADVISOR','F18_PLAN_PROFILE']}
 for line in text.splitlines():
  for name in events:
   prefix='['+name+'] '
   if line.startswith(prefix):events[name].append(json.loads(line[len(prefix):]))
 save(G/'EVENTS.json',events)
 manifest={str(p.relative_to(out)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in out.rglob('*') if p.is_file()};save(G/'RAW_SHA256.json',manifest)
 with tarfile.open(G/'raw_results.tar.gz','x:gz') as tar:
  for name in sorted(manifest):tar.add(out/name,arcname=name,recursive=False)
 result={'utc':utc(),'complete':True,'valid':True,'new_game_rounds':1,'BLUE_rounds':0,'not_for_algorithm_ranking':True,'not_five_map_score':True,'row':summary['rounds'][0],'event_counts':{k:len(v) for k,v in events.items()},'raw_files':len(manifest),'raw_manifest_sha256':sha(G/'RAW_SHA256.json'),'raw_archive_sha256':sha(G/'raw_results.tar.gz'),'raw_arrays_loaded':0,'instrumentation_overhead':'Counters and logging may affect wallclock; no paired causal score inference.'}
 save(G/'RESULT.json',result)
 state.update(status='PARENT_M04_DIAGNOSTIC_COMPLETE_AWAIT_ANALYSIS',native_pid=None,updated_utc=utc());save(G/'STATUS.json',state);save(F/'STATUS.json',state);activity([],state['status'])
except BaseException:
 err={'utc':utc(),'error':traceback.format_exc(),'first_failure':True,'no_retry':True}
 if not(F/'FIRST_NATIVE_ERROR.json').exists():save(F/'FIRST_NATIVE_ERROR.json',err)
 state.update(status='STOPPED_BY_HUMAN' if (F/'STOP_REQUESTED').exists() else 'CLOSED_FIRST_NATIVE_DIAGNOSTIC_FAILURE',error=err['error'],updated_utc=utc());save(G/'STATUS.json',state);save(F/'STATUS.json',state);activity([],state['status']);raise
