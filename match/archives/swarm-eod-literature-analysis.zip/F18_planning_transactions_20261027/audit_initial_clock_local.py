"""Canonical remaining-budget method on fixed public-clock fixtures, no simulator."""
from pathlib import Path
import ast,json,zipfile,hashlib,types
F=Path(__file__).resolve().parent;p=F/'SOURCE_INITIAL_CLOCK_AUDIT.json';assert not p.exists()
with zipfile.ZipFile(F/'S01/team615_red_v24.zip') as z:
 raw=z.read('active_coverage.py');terminal=z.read('terminal_value.py')
tree=ast.parse(raw.decode());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ActiveCoverageMixin');fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_remaining_steps')
env={}
def compile_class(name,method):
 node=ast.ClassDef(name=name,bases=[],keywords=[],body=[method],decorator_list=[])
 exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),'fixed_public_clock_fixture','exec'),env)
 return env[name]
Original=compile_class('Original',ast.parse(ast.unparse(fn)).body[0])
variant=ast.parse(ast.unparse(fn)).body[0]
rate=next(n for n in variant.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='rate' for t in n.targets))
index=variant.body.index(rate)
variant.body[index:index]=ast.parse("""observed_warmup_rate=None
anchor=self._clock_anchor
if not self._step_seconds and anchor is not None and step>anchor[0] and wall>anchor[1]:
    observed_warmup_rate=(wall-anchor[1])/(step-anchor[0])
""").body
rate.value=ast.parse('max(.001,self._step_seconds or observed_warmup_rate or wall/max(1.,step))',mode='eval').body
AnchoredWarmup=compile_class('AnchoredWarmup',variant)
def fixture(cls,anchor=(2.,6.),rate=None,step=26.,wall=10.):
 d=cls();d.elapsed_timestep=step;d.elapsed_walltime=wall;d.limit=5000.;d.walltime_limit=180.;d._step_seconds=rate;d._clock_anchor=anchor;return d
checks=[]
def check(n,v):
 assert v,n
 checks.append(n)
a=fixture(Original);b=fixture(AnchoredWarmup);old=a._remaining_steps();new=b._remaining_steps()
check('fixed_startup_offset_makes_original_budget_small',abs(old-418.)<1e-9)
check('anchor_delta_forecast_cancels_fixed_startup_offset',abs(new-990.)<1e-9)
check('actual_elapsed_limits_not_changed',a.elapsed_timestep==b.elapsed_timestep==26 and a.elapsed_walltime==b.elapsed_walltime==10 and a.walltime_limit==b.walltime_limit==180.)
for name,kw in [('matured',{'rate':.09}),('zero_offset',{'anchor':(0.,0.)}),('missing_anchor',{'anchor':None}),('future_step_anchor',{'anchor':(30.,6.)}),('future_wall_anchor',{'anchor':(2.,11.)}),('no_wall_delta',{'anchor':(2.,10.)})]:
 a=fixture(Original,**kw);b=fixture(AnchoredWarmup,**kw)
 check('original_forecast_preserved_'+name,a._remaining_steps()==b._remaining_steps())
env['np']=types.SimpleNamespace(clip=lambda x,lo,hi:min(hi,max(lo,x)))
funcs=[n for n in ast.parse(terminal.decode()).body if isinstance(n,ast.FunctionDef) and n.name in ['red_time_contribution','scheduled_delay_time_loss','bounded_completion_risk','continue_with_schedule']]
exec(compile(ast.fix_missing_locations(ast.Module(body=funcs,type_ignores=[])),'canonical_terminal_helpers','exec'),env)
before=env['continue_with_schedule'](7.,8.,26.,120.,old,432.,5000.)
after=env['continue_with_schedule'](7.,8.,26.,120.,new,432.,5000.)
check('fixed_early_commit_decision_changes',before is False and after is True)
d={'status':'PASS','checks':checks,'game_rounds':0,'server_commands':0,'canonical_active_sha256':hashlib.sha256(raw).hexdigest(),'canonical_terminal_sha256':hashlib.sha256(terminal).hexdigest(),
 'fixture':{'step':26,'wall':10,'initial_clock_anchor':[2,6],'limit':5000,'walltime_limit':180,'original_remaining':old,'anchor_delta_remaining':new,
 'model_execution':432,'probe':120,'expected_information_gain':7,'completion_value':8,'original_continue':before,'hypothetical_anchored_continue':after},
 'finding':'Before first48step rate update, canonical remaining forecast uses totalwall/totalstep instead of elapsed delta from existing own initial anchor. A fixed startup cost can depress futurestep budget and latch readiness early. Matured rate behavior unchanged in the narrow proposed ablation; actual clock/limit never modified.',
 'limitation':'Fixture clock10/anchor6 are synthetic, NOT recovered S01_B timestamps. Actual verified ownS01_B Map04 log only proves ready at26 with known_value0/layoutgap20/mapgap50/execution432. Need fresh own elapsed/anchor/observedrate/decision logging to confirm cause and frequency. No production change or new candidate.'}
p.write_bytes((json.dumps(d,indent=2)+'\n').encode());print(json.dumps({'status':d['status'],'checks':len(checks),'original_remaining':old,'hypothetical_remaining':new,'server_commands':0}))
