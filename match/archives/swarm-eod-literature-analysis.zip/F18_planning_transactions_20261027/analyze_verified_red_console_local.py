"""Only selected OWN scalar log tags from already-verified archives; never BLUE/arrays."""
from pathlib import Path
import json,ast,tarfile
F=Path(__file__).resolve().parent;P=F/'S01_PERF';out={'scope':'Own user-source scalar active-coverage/farthest-wall lines only from already-first-verified RED console members. No BLUE console, arrays, pickle, NPZ, replay, new simulator or production input. Readiness is not actual placement/causal attribution.','cohorts':{},'parse_issues':[]}
for version,cohort in [('K01','A'),('S01','A'),('K01','B'),('S01','B')]:
 G=P/(version+'_'+cohort);assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'))['valid']
 result=json.loads((G/'RESULT.json').read_text(encoding='utf-8'));maps={}
 with tarfile.open(G/'raw_results.tar.gz','r:gz') as archive:
  for row in result['rows']:
   name=row['map'];member=archive.getmember(name+'_red/console.log');stream=archive.extractfile(member)
   releases=[];layouts=[]
   for raw in stream:
    line=raw.decode('utf-8',errors='replace').strip()
    try:
     if line.startswith('[active-coverage] release_all_inventory '):
      _,_,owner,step,model=line.split(' ',4)
      releases.append({'owner':int(owner),'step':int(step),'model':ast.literal_eval(model)})
     elif line.startswith('[farthest-wall] '):layouts.append(ast.literal_eval(line[len('[farthest-wall] '):]))
    except (ValueError,SyntaxError) as e:out['parse_issues'].append({'cohort':G.name,'map':name,'tag':line.split(' ',1)[0],'error':str(e)})
   first={}
   for x in sorted(releases,key=lambda x:x['step']):first.setdefault(x['owner'],x)
   maps[name]={'score':{k:row[k] for k in ['full_score','map_score','wall_score','completion_adjusted_blue','time_score','placed','red_steps','red_seconds']},
     'first_readiness_by_owner':first,'first_any_readiness_step':min((x['step'] for x in first.values()),default=None),
     'layout_calls':len(layouts),'layout_selected_changed':sum(bool(x.get('selected_changed',False)) for x in layouts),
     'layout_reasons':{reason:sum(x.get('reason')==reason for x in layouts) for reason in sorted({str(x.get('reason')) for x in layouts})},
     'first_layout_scalar_audit':layouts[:1]}
 out['cohorts'][G.name]=maps
p=F/'S01_VERIFIED_OWN_CONSOLE_ANALYSIS.json';assert not p.exists();p.write_bytes((json.dumps(out,indent=2)+'\n').encode())
for cohort,maps in out['cohorts'].items():print(cohort,json.dumps({m:{'readiness_step':d['first_any_readiness_step'],'red_steps':d['score']['red_steps'],'placed':d['score']['placed'],'layout_calls':d['layout_calls']} for m,d in maps.items()}))
print('parse_issues',len(out['parse_issues']))
