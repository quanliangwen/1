from pathlib import Path
import sys,json,subprocess,hashlib
F=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['S01','S02','S03'];C=F/v;C.mkdir(exist_ok=True)
B=json.loads((F/(v+'_BUILD.json')).read_text(encoding='utf-8'));z=C/Path(B['zip']).name
assert not z.exists() and not(C/'STRICT_PACKAGE_GUARD.json').exists()
subprocess.run(['scp','-q','junhao@10.112.162.60:'+B['zip'],str(z)],check=True)
assert hashlib.sha256(z.read_bytes()).hexdigest()==B['zip_sha256']
assert json.loads((C/'RUNTIME_ABI_RECEIPT.json').read_text(encoding='utf-8'))['submission_zip_sha256']==B['zip_sha256']
subprocess.run([sys.executable,str(F.parent.parent/'swarm-submission-guard/check_submission_zip.py'),str(z),'--abi-receipt',str(C/'RUNTIME_ABI_RECEIPT.json'),'--output',str(C/'STRICT_PACKAGE_GUARD.json')],check=True)
