"""Readonly current invocation signatures and timings; original calls always run."""
from contextlib import contextmanager
import hashlib,json,time
import numpy as np
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
from swarm_rescue.solutions.planning_cost_transaction import root_memory,field_key


@contextmanager
def planning_profile(memory):
    root=root_memory(memory);previous=vars(root).get('_f18_plan_profile')
    state={'field_seen':set(),'view_seen':{},'field_calls':0,'field_duplicates':0,'field_duplicate_seconds':0.,
           'view_calls':0,'view_duplicates':0,'view_duplicate_seconds':0.,'view_conflicts':0,'signature_seconds':0.}
    root._f18_plan_profile=state
    try:yield state
    finally:
        if previous is None:vars(root).pop('_f18_plan_profile',None)
        else:root._f18_plan_profile=previous
        totals=getattr(root,'planning_profile_diagnostics',{})
        names=['field_calls','field_duplicates','field_duplicate_seconds','view_calls','view_duplicates','view_duplicate_seconds','view_conflicts','signature_seconds']
        root.planning_profile_diagnostics={n:totals.get(n,0)+state[n] for n in names}
        count=totals.get('transactions',0)+1;root.planning_profile_diagnostics['transactions']=count
        if count<=24:
            print('[F18_PLAN_PROFILE]',json.dumps({'owner':int(getattr(root,'identifier',0)),'step':int(getattr(root,'step',0)),
                  **{n:state[n] for n in names},'transaction':count},separators=(',',':')),flush=True)
        state['field_seen'].clear();state['view_seen'].clear()


def profiled_path_costs(memory,walkable,start,original):
    root=root_memory(memory);state=vars(root).get('_f18_plan_profile')
    if state is None:return original(memory,walkable,start)
    begun=time.perf_counter();raw=field_key(memory,walkable,start)
    key=None if raw is None else raw[:3]+(hashlib.sha256(raw[3]).digest(),)
    state['signature_seconds']+=time.perf_counter()-begun
    begun=time.perf_counter();result=original(memory,walkable,start);elapsed=time.perf_counter()-begun
    state['field_calls']+=1
    if key is not None:
        if key in state['field_seen']:
            state['field_duplicates']+=1;state['field_duplicate_seconds']+=elapsed
        elif len(state['field_seen'])<128:state['field_seen'].add(key)
    return result


def _array_signature(value):
    a=np.asarray(value)
    return (a.shape,a.dtype.str,hashlib.sha256(a.tobytes()).hexdigest())


def profiled_view(memory,*args,**kwargs):
    root=root_memory(memory);state=vars(root).get('_f18_plan_profile')
    if state is None:return GeometryPlanningMemory(memory,*args,**kwargs)
    begun=time.perf_counter()
    clearance=kwargs.get('clearance',args[0] if len(args)>0 else 22.)
    width=kwargs.get('line_width',args[1] if len(args)>1 else 8)
    key=(id(memory),int(memory.step),float(memory.CELL),float(memory.FINE),tuple(memory.shape),tuple(memory.hit_shape),
         float(clearance),int(width),_array_signature(memory.free),_array_signature(memory.hits))
    state['signature_seconds']+=time.perf_counter()-begun
    begun=time.perf_counter();view=GeometryPlanningMemory(memory,*args,**kwargs);elapsed=time.perf_counter()-begun
    begun=time.perf_counter();output=(_array_signature(view.free),_array_signature(view._blocked))
    state['signature_seconds']+=time.perf_counter()-begun;state['view_calls']+=1
    if key in state['view_seen']:
        if state['view_seen'][key]==output:state['view_duplicates']+=1;state['view_duplicate_seconds']+=elapsed
        else:state['view_conflicts']+=1
    elif len(state['view_seen'])<128:state['view_seen'][key]=output
    return view
