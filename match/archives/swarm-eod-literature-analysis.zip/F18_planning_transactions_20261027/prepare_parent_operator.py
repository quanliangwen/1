from pathlib import Path
import ast,json,base64,hashlib,subprocess,shlex
F=Path(__file__).resolve().parent;O=F.parent/'F17_assignment_epoch_and_consumers_20261027'
e=json.loads((O/'PARENT_OPERATORS.json').read_text(encoding='utf-8'))['PARENT_M04']
s=base64.b64decode(e['runner_base64']).decode().replace('F17','F18').replace('f17','f18')
s=s.replace("'F18_FRONTIER_ADVISOR','F18_EPOCH_OPPORTUNITY','F18_ENDPOINT_OPPORTUNITY'","'F18_FRONTIER_ADVISOR','F18_PLAN_PROFILE'")
ast.parse(s);bundle={'PARENT_M04':{'runner_base64':base64.b64encode(s.encode()).decode(),'sha256':hashlib.sha256(s.encode()).hexdigest(),'map':'Map04'}}
maps={'PARENT_M04_DIAG':'Map04','S01_DIAG':'Map04','S02_DIAG':'Map04','S03_DIAG':'Map04'}
for n,d in [('PARENT_OPERATORS.json',bundle),('DIAGNOSTIC_MAP_BINDINGS.json',maps)]:
 p=F/n;assert not p.exists();p.write_bytes((json.dumps(d,indent=2)+'\n').encode())
for n in ['sync_metadata.py','verify_diagnostic_raw.py','read_live.py','stage_parent_observer.py']:
 s=(O/n).read_text(encoding='utf-8').replace(O.name,F.name).replace('F17','F18').replace('f17','f18').replace('R01','S01').replace('R02','S02').replace('R03','S03')
 if n=='stage_parent_observer.py':s=s.replace("O=F/'observer_qualification'","O=F/'observer_qualification_revision3'")
 if n=='read_live.py':
  marker=" out['preferences_applied']=";i=s.index(marker)
  s=s[:i]+" out['plan_profiles']=[json.loads(x[len('[F18_PLAN_PROFILE] '):]) for x in lines if x.startswith('[F18_PLAN_PROFILE] ')]\n"+s[i:]
 ast.parse(s);p=F/n;assert not p.exists();p.write_bytes(s.encode())
code=r'''
from pathlib import Path
import json,sys
F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F18_planning_transactions_20261027')
assert json.loads((F/'observer_qualification_revision3/QUALIFICATION_RESULT.json').read_text())['status']=='PASS'
for n,d in json.load(sys.stdin).items():assert not(F/n).exists();(F/n).write_text(json.dumps(d,indent=2)+'\n')
print('One original Map04 RED diagnostic prepared; no game started')
'''
print(subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps({'PARENT_OPERATORS.json':bundle,'DIAGNOSTIC_MAP_BINDINGS.json':maps}).encode()).decode())
