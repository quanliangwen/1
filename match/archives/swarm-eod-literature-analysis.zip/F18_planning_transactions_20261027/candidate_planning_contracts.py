    import ast,types,zipfile,yaml
    from swarm_rescue.solutions import team_coverage as market,team_coverage_lns as current
    from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory as RealView
    build=json.loads((C/'BUILD.json').read_text());parent=json.loads((F.parent/'PREDECLARATION.json').read_text())['parent'];P=Path(parent['path'])/'source'
    old=types.ModuleType('canonical_LNS');exec(compile((P/'team_coverage_lns.py').read_text(),str(P/'team_coverage_lns.py'),'exec'),old.__dict__)
    if build['candidate_id']=='S01':
        from swarm_rescue.solutions.planning_cost_transaction import planning_cost_transaction,cached_path_costs
        a=ast.parse((P/'team_coverage.py').read_text());a=next(n for n in a.body if isinstance(n,ast.FunctionDef) and n.name=='path_costs')
        b=ast.parse((C/'source/team_coverage.py').read_text());b=next(n for n in b.body if isinstance(n,ast.FunctionDef) and n.name=='_original_path_costs');b.name='path_costs'
        check('original_path_supplier_AST_unchanged',ast.dump(a)==ast.dump(b))
        a=next(n for n in ast.parse((P/'team_coverage_lns.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='plan_team_coverage_lns')
        b=next(n for n in ast.parse((C/'source/team_coverage_lns.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='plan_team_coverage_lns')
        check('original_LNS_body_only_wrapped',len(b.body)==1 and isinstance(b.body[0],ast.With) and ast.dump(ast.Module(body=a.body,type_ignores=[]))==ast.dump(ast.Module(body=b.body[0].body,type_ignores=[])))
        binding=json.loads((F.parent/'helper_qualification_revision1/SOURCE_BINDING.json').read_text())
        check('actual_cost_helper_byte_identical_to97QA',build['source_files']['planning_cost_transaction.py']==binding['planning_cost_transaction.py'])
        m=MapMemory(256,192);m.free[:]=True
        with planning_cost_transaction(m) as state:
            x=market.path_costs(m,m.free,(0,0));reference=x.copy();x[:]=123.
            y=market.path_costs(m,m.free,(0,0))
            check('actual_supplier_cache_hit_and_copy',state['hits']==1 and np.array_equal(reference,y))
            check('actual_supplier_capacity_bound',len(state['fields'])<=32 and state['bytes']<=8*1024*1024)
        check('actual_supplier_cleanup','_planning_cost_transaction' not in vars(m) and not state['fields'])
        check('only_field_transaction_files_changed',build['changed_files']==sorted(['team_coverage.py','team_coverage_lns.py','planning_cost_transaction.py']))
    else:
        check('only_single_view_file_changed',build['candidate_id']=='S03' and build['changed_files']==['team_coverage_lns.py'])
    original_refs=(old.GeometryPlanningMemory,current.GeometryPlanningMemory,market.GeometryPlanningMemory,trust.GeometryPlanningMemory)
    counter=[]
    class Factory(RealView):
        def __init__(self,memory,*args,**kwargs):
            counter.append(1);super().__init__(memory,*args,**kwargs)
            values=np.zeros(self.shape,np.float32);values[5,8]=1.;values[5,12]=1.
            self._coverage_values_cache=(32.,values,np.zeros(self.shape,bool))
    try:
        old.GeometryPlanningMemory=current.GeometryPlanningMemory=market.GeometryPlanningMemory=trust.GeometryPlanningMemory=Factory
        for label,cap,prefix,empty in [('normal',1000.,False,False),('tight',40.,False,False),('prefix',1000.,True,False),('empty',1000.,False,True)]:
            a=MapMemory(256,192);a.free[:]=True;b=MapMemory(256,192);b.free[:]=True
            agents={2:(a.cell_to_world((5,3)),0 if empty else 2),3:(a.cell_to_world((5,14)),0 if empty else 2)}
            pref={2:(a.cell_to_world((5,2)),agents[2][0])} if prefix else None
            counter.clear();x=old.plan_team_coverage_lns(a,agents,[],32.,travel_budget=cap,reserved_prefixes=pref);count_old=len(counter)
            counter.clear();y=current.plan_team_coverage_lns(b,agents,[],32.,travel_budget=cap,reserved_prefixes=pref);count_new=len(counter)
            check('actual_full_pipeline_plan_exact_'+label,same(x,y))
            check('actual_full_pipeline_arrays_exact_'+label,all(np.array_equal(getattr(a,k),getattr(b,k)) for k in ['free','hits','visits']))
            check('actual_original_trust_counters_exact_'+label,a.trust_region_diagnostics==b.trust_region_diagnostics)
            if build['candidate_id']=='S01':
                diag=b.planning_cost_diagnostics
                check('actual_field_transaction_cleaned_'+label,'_planning_cost_transaction' not in vars(b) and diag['transactions']==diag['cleanup_count'])
                check('actual_field_capacity_preserved_'+label,diag['peak_entries']<=32 and diag['peak_bytes']<=8*1024*1024)
                if label=='normal':check('actual_nonempty_full_pipeline_reuses_fields',any(y.values()) and diag['hits']>=1 and count_new==count_old)
            else:
                check('actual_view_count_not_increased_'+label,count_new<=count_old)
                if label=='normal':check('actual_nonempty_full_pipeline_shared_view',any(y.values()) and count_old==2 and count_new==1 and b.planning_view_diagnostics['nonempty_shared']==1)
                if prefix:check('actual_prefix_path_unchanged',count_old==count_new==1)
    finally:old.GeometryPlanningMemory,current.GeometryPlanningMemory,market.GeometryPlanningMemory,trust.GeometryPlanningMemory=original_refs
