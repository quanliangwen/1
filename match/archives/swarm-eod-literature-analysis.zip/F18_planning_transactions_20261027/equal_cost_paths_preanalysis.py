"""Bounded alternatives in one own observed directed shortest-path field.

No new goal, no new field search, no cross-call or cross-agent state. This helper
is preanalysis only; real sensor visibility and final consumer gates remain.
"""
import math


def path_from_parent(parent,start,goal,max_nodes):
    path=[tuple(goal)]; seen={tuple(goal)}
    while path[-1]!=tuple(start):
        prev=parent.get(path[-1])
        if prev is None or tuple(prev) in seen or len(path)>=max_nodes:
            return None
        path.append(tuple(prev));seen.add(tuple(prev))
    return list(reversed(path))


def directed_edge(a,b,clearance,walkable):
    dr,dc=b[0]-a[0],b[1]-a[1]
    h,w=walkable.shape
    if (not (0<=a[0]<h and 0<=a[1]<w and 0<=b[0]<h and 0<=b[1]<w)
            or max(abs(dr),abs(dc))!=1 or not walkable[a] or not walkable[b]):
        return math.inf
    if dr and dc and (not walkable[a[0]+dr,a[1]] or not walkable[a[0],a[1]+dc]):
        return math.inf
    return (math.sqrt(2.) if dr and dc else 1.)*(1.+.30*max(0.,(40.-float(clearance[b]))/40.))


def equal_cost_alternatives(cost,parent,clearance,walkable,start,goal,max_candidates=8,max_joins=32):
    """Single alternative predecessor splice; deterministic bounded subset.

    Exact directed destination-clearance cost from canonical route_fields.
    This is not exhaustive informative-path optimization and has no guarantee
    of finding the best information path. Cost equality uses 1e-9 tolerance.
    """
    baseline=path_from_parent(parent,start,goal,int(cost.size)+1)
    if baseline is None or not math.isfinite(float(cost[goal])):
        return []
    result=[baseline];seen={tuple(baseline)}
    if max_candidates<=1:return result
    joins=list(range(1,len(baseline)))
    if len(joins)>max_joins:
        joins=sorted(set(round(i*(len(joins)-1)/max(1,max_joins-1))+1 for i in range(max_joins)))
    for index in joins:
        cell=baseline[index]
        for dr,dc in ((-1,0),(0,-1),(0,1),(1,0),(-1,-1),(-1,1),(1,-1),(1,1)):
            prev=(cell[0]+dr,cell[1]+dc)
            edge=directed_edge(prev,cell,clearance,walkable)
            if not math.isfinite(edge):continue
            before=float(cost[prev]);after=float(cost[cell])
            if not before<after or abs((before+edge)-after)>1e-9:continue
            prefix=path_from_parent(parent,start,prev,int(cost.size)+1)
            if prefix is None:continue
            candidate=prefix+baseline[index:]
            key=tuple(candidate)
            if key in seen or len(set(candidate))!=len(candidate):continue
            # Verify full primary cost, not only the splice equality.
            total=sum(directed_edge(a,b,clearance,walkable) for a,b in zip(candidate,candidate[1:]))
            if abs(total-float(cost[goal]))>1e-9:continue
            seen.add(key);result.append(candidate)
            if len(result)>=max_candidates:return result
    return result


def information_union(path,visible_sets):
    result=set()
    for cell in path:result.update(visible_sets.get(cell,()))
    return result
