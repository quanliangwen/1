from swarm_rescue.solutions.planning_cost_transaction import planning_cost_transaction,cached_path_costs,field_key
from swarm_rescue.solutions.planning_profile import planning_profile,profiled_path_costs,profiled_view
from swarm_rescue.solutions.team_coverage import path_costs as original_costs
from swarm_rescue.solutions import layout_preference as policy
from types import SimpleNamespace
def memory():
 m=MapMemory(256,192);m.free[:]=True;m.step=1000;m.identifier=2;return m
m=memory();calls=[]
def tracked(m,w,s):calls.append((s,float(m.CELL)));return original_costs(m,w,s)
walk=m.free.copy()
with planning_cost_transaction(m) as state:
 a=cached_path_costs(m,walk,(2,2),tracked);expected=a.copy();a[:]=999.
 b=cached_path_costs(m,walk,(2,2),tracked)
 check('miss_result_isolated_from_cache',np.array_equal(b,expected))
 b[:]=888.;c=cached_path_costs(m,walk,(2,2),tracked)
 check('hit_result_isolated_from_cache',np.array_equal(c,expected))
 check('actual_one_source_call_two_hits',len(calls)==1 and state['hits']==2)
 check('exact_graph_cache_side_effect',np.array_equal(m._coverage_graph_cache[0],walk))
 check('within_byte_capacity',state['bytes']<=8*1024*1024 and len(state['fields'])<=32)
check('normal_scope_cleanup','_planning_cost_transaction' not in vars(m) and not state['fields'])
check('cleanup_counter',m.planning_cost_diagnostics['cleanup_count']==1)
for n in range(10):
 rng=np.random.RandomState(n);m=memory();w=rng.uniform(size=m.shape)>.25
 with planning_cost_transaction(m):
  for start in [(0,0),(3,7),(8,5)]:
   expected=original_costs(m,w,start)
   a=cached_path_costs(m,w,start,original_costs);b=cached_path_costs(m,w,start,original_costs)
   check('exact_random_field_'+str(n)+'_'+str(start),np.array_equal(a,expected) and np.array_equal(b,expected))
m=memory();w=np.zeros(m.shape,bool);w[1,1]=True
with planning_cost_transaction(m):
 a=cached_path_costs(m,w,(0,0),original_costs)
 check('original_forced_start_and_no_corner_cut',a[0,0]==0 and np.isinf(a[1,1]))
 w[0,1]=True;b=cached_path_costs(m,w,(0,0),original_costs)
 check('mask_mutation_invalidates',np.isfinite(b[1,1]) and not np.array_equal(a,b))
 before=float(b[0,1]);m.CELL=8.;c=cached_path_costs(m,w,(0,0),original_costs)
 check('scale_change_invalidates',c[0,1]==before*.5)
 d=cached_path_costs(m,w,(1,1),original_costs)
 check('start_change_invalidates',d[1,1]==0 and c[1,1]>0)
m=memory();w=m.free.copy()
with planning_cost_transaction(m,capacity=1) as state:
 cached_path_costs(m,w,(0,0),original_costs);x=cached_path_costs(m,w,(1,1),original_costs)
 check('entry_limit_original_fallback',len(state['fields'])==1 and np.array_equal(x,original_costs(m,w,(1,1))))
with planning_cost_transaction(m,max_bytes=0) as state:
 x=cached_path_costs(m,w,(0,0),original_costs)
 check('byte_limit_original_fallback',not state['fields'] and state['bytes']==0 and np.array_equal(x,original_costs(m,w,(0,0))))
with planning_cost_transaction(m) as outer:
 cached_path_costs(m,w,(0,0),original_costs)
 with planning_cost_transaction(m) as inner:
  check('nested_scope_independent',inner is not outer and vars(m)['_planning_cost_transaction'] is inner)
 check('outer_scope_restored',vars(m)['_planning_cost_transaction'] is outer)
 cached_path_costs(m,w,(0,0),original_costs);check('outer_cache_survives_inner',outer['hits']==1)
try:
 with planning_cost_transaction(m):raise ValueError('synthetic failure')
except ValueError:pass
check('exception_scope_cleanup','_planning_cost_transaction' not in vars(m))
other=memory()
with planning_cost_transaction(m) as state:
 result=cached_path_costs(other,w,(0,0),original_costs)
 check('per_controller_isolation',state['calls']==0 and '_planning_cost_transaction' not in vars(other))
pm=GeometryPlanningMemory(m)
with planning_cost_transaction(m) as state:
 cached_path_costs(pm,w,(0,0),original_costs);cached_path_costs(m,w,(0,0),original_costs)
 check('own_view_and_root_share_transaction',state['hits']==1)
before=[m.free.copy(),m.hits.copy()]
with planning_profile(m) as state:
 expected=original_costs(m,w,(0,0));x=profiled_path_costs(m,w,(0,0),original_costs);y=profiled_path_costs(m,w,(0,0),original_costs)
 check('readonly_profile_exact_fields',np.array_equal(x,expected) and np.array_equal(y,expected) and state['field_duplicates']==1)
 a=profiled_view(m);b=profiled_view(m)
 check('readonly_profile_views_equal',np.array_equal(a.free,b.free) and np.array_equal(a._blocked,b._blocked) and state['view_duplicates']==1 and not state['view_conflicts'])
check('readonly_profile_arrays_and_cleanup',np.array_equal(m.free,before[0]) and np.array_equal(m.hits,before[1]) and '_f18_plan_profile' not in vars(m))
# Production policy: ineligible calls must not spend attempts OR their gap timestamp.
m=SimpleNamespace(step=1000,identifier=2,_layout_preference_objective='delivery');calls=[]
original=policy.frontier_advice
def absent(*a,**kw):
 calls.append(1)
 return {'proposals':{'delivery':None},'reason':'compared_model_frontier','seconds':0.,'deadline_reached':False}
try:
 policy.frontier_advice=absent
 agents={2:(np.zeros(2),1),1:(np.zeros(2),1)};own={2:[np.array([10.,0.])]}
 for name,result,prefix in [('reserved',own,{2:(np.zeros(2),np.ones(2))}),('other_owner',{1:[np.ones(2)]},None),('empty_own',{2:[]},None)]:
  answer=policy.apply_preference(m,agents,[],32.,result,200.,200.,prefix,(),None,None)
  check('ineligible_no_budget_'+name,answer is result and not calls and not hasattr(m,'_layout_preference_attempts') and not hasattr(m,'_layout_preference_last'))
 answer=policy.apply_preference(m,agents,[],32.,own,200.,200.,None,(),None,None)
 check('later_eligible_still_searched',len(calls)==1 and m._layout_preference_attempts==1)
 for step,want in [(1000,1),(1119,1),(1120,2),(1360,2)]:
  m.step=step;answer=policy.apply_preference(m,agents,[],32.,own,200.,200.,None,(),None,None)
  check('eligible_gap_and_cap_'+str(step),answer is own and m._layout_preference_attempts==want and len(calls)==want)
finally:policy.frontier_advice=original
