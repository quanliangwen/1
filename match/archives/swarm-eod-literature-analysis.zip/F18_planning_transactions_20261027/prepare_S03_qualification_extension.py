from pathlib import Path
import ast
F=Path(__file__).resolve().parent
s=(F/'qualify.py').read_text(encoding='utf-8')
marker=r"+'\n'+(F/'qualification_ABI_checks.py').read_text(encoding='utf-8')"
assert s.count(marker)==1
s=s.replace(marker,"+'\\n'+(F/'S03_real_geometry_contracts.py').read_text(encoding='utf-8')"+marker)
s=s.replace("assert v in ['S01','S02','S03']","assert v=='S03'")
ast.parse(s);p=F/'qualify_S03_revision1.py';assert not p.exists();p.write_bytes(s.encode())
print('S03 additional actual measured-geometry qualification prepared locally; no server or evaluator call')
