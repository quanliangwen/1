from pathlib import Path
import sys,json,time,traceback
Q=Path(__file__).resolve().parent;report={'status':'STARTED','checks':[],'game_rounds':0}
def check(n,v):
 assert v,n
 report['checks'].append(n)
try:
 sys.path.insert(0,str(Q/'workspace/src'))
 import numpy as np
 from swarm_rescue.solutions.layout_frontier import frontier_advice,exposure_map,reference_cells
 from swarm_rescue.solutions.greedy_mapping import MapMemory
 from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
 from swarm_rescue.solutions import trust_region_cover as trust
 def params(m,agents,radius,allowed,cap=500.):
  return {'memory':m,'agents':agents,'drops':[],'radius':radius,'travel_budget':cap,'full_budget':cap,
          'reserved_prefixes':{},'forbidden_points':(),'forbidden_mask':~allowed,'route_epsilon':32.,'trust_radius_ratio':1.25}
 def transport_fixture(loss=.03,noise=None):
  m=MapMemory(256,128);m.free[:]=True;pm=GeometryPlanningMemory(m);values=np.zeros(m.shape,np.float32);values[1,8]=1.;values[3,12]=loss
  pm._coverage_values_cache=(64.,values,np.zeros(m.shape,bool));allowed=np.zeros(m.shape,bool);allowed[3,10]=allowed[3,6]=True
  base={7:[m.cell_to_world((3,10))]};agents={7:(m.cell_to_world((4,8)),1)}
  m.nonwall_mask=np.zeros(m.hit_shape,bool);m.nonwall_mask[4*8:5*8,14*8:15*8]=True
  return m,pm,base,params(m,agents,64.,allowed,100.)
 m,pm,base,p=transport_fixture();original={k:getattr(m,k).copy() for k in ['hits','free','visits']};oldbase=base[7][0].copy()
 a=frontier_advice(p,base,pm,seconds=5.,objectives=('transport',));x=a['proposals']['transport']
 check('coverage_transport_tradeoff_exists',x is not None and a['reason']=='compared_model_frontier')
 check('two_cell_transport_gain',x['centre_after']>=x['centre_before']+32.-1e-6)
 check('confirmed95percent_floor',x['confirmed_after']>=.95*x['confirmed_before']-1e-5)
 check('nominal95percent_floor',x['nominal_after']>=.95*x['nominal_before']-1e-5)
 check('strict_coverage_tradeoff_measured',x['confirmed_after']<x['confirmed_before'])
 check('funnel_explains_old_noop',a['funnel'][0]['transport_floor_0.0']==0 and a['funnel'][0]['transport_floor_0.05']>0)
 check('source_arrays_unchanged',all(np.array_equal(v,getattr(m,k)) for k,v in original.items()))
 check('source_plan_unchanged',np.array_equal(base[7][0],oldbase))
 check('bounded_exact_candidates',a['tested']<=128 and a['tested']<=12)
 for loss,label,positive in [(.052,'just_inside',True),(.054,'outside',False),(.1,'large',False)]:
  m,pm,base,p=transport_fixture(loss);a=frontier_advice(p,base,pm,seconds=5.,objectives=('transport',))
  check('numeric_confirmed_boundary_'+label,(a['proposals']['transport'] is not None)==positive)
 saved=trust._repeat_hit_support
 try:
  m,pm,base,p=transport_fixture(.03);support=np.zeros(m.shape,np.float32);support[3,12]=.1;trust._repeat_hit_support=lambda memory:support.copy()
  a=frontier_advice(p,base,pm,seconds=5.,objectives=('transport',));check('independent_nominal_floor',a['proposals']['transport'] is None)
 finally:trust._repeat_hit_support=saved
 m,pm,base,p=transport_fixture();p['travel_budget']={7:20.}
 a=frontier_advice(p,base,pm,seconds=5.,objectives=('transport',));check('owner_cap_invalid_incumbent',a['reason']=='invalid_incumbent_route')
 p['travel_budget']={7:float('nan')};a=frontier_advice(p,base,pm,seconds=5.,objectives=('transport',));check('nan_budget_abstains',a['reason']=='invalid_budget')
 m,pm,base,p=transport_fixture();a=frontier_advice(p,base,pm,seconds=0.);check('timeout_clears_all_proposals',a['reason']=='deadline' and all(x is None for x in a['proposals'].values()))
 m.nonwall_mask[:]=False;a=frontier_advice(p,base,pm,seconds=5.,objectives=('transport','occlusion'));check('missing_centres_no_fabrication',all(x is None for x in a['proposals'].values()))
 def delivery_fixture(fullcap=600.,prefix=False):
  m=MapMemory(1024,128);m.free[:]=True;pm=GeometryPlanningMemory(m);values=np.zeros(m.shape,np.float32);values[3,27]=1.
  pm._coverage_values_cache=(32.,values,np.zeros(m.shape,bool));allowed=np.zeros(m.shape,bool);allowed[3,26]=allowed[3,28]=True
  base={2:[m.cell_to_world((3,26))]};agents={2:(m.cell_to_world((3,32)),1)};p=params(m,agents,32.,allowed,fullcap)
  if prefix:
   p['reserved_prefixes']={2:(m.cell_to_world((3,33)),agents[2][0])};p['travel_budget']={2:fullcap-16.}
  return m,pm,base,p,m.cell_to_world((3,57))
 m,pm,base,p,rally=delivery_fixture();a=frontier_advice(p,base,pm,rally,seconds=5.,objectives=('delivery',));x=a['proposals']['delivery']
 check('known_contact_region_delivery_positive',x is not None)
 check('known_contact_costs',x['delivery_before']==560. and x['delivery_after']==496.)
 check('contact_region_not_forced_unknown',a['delivery_contact_available'])
 m,pm,base,p,rally=delivery_fixture(512.,True);a=frontier_advice(p,base,pm,rally,seconds=5.,objectives=('delivery',));x=a['proposals']['delivery']
 check('same_call_prefix_budget',x is not None and x['prefix_cost']==16. and x['delivery_after']==512.)
 m,pm,base,p,rally=delivery_fixture(511.,True);a=frontier_advice(p,base,pm,rally,seconds=5.,objectives=('delivery',));check('full_prefix_delivery_cap_rejects',a['proposals']['delivery'] is None)
 m,pm,base,p,rally=delivery_fixture();a=frontier_advice(p,base,pm,None,seconds=5.,objectives=('delivery',));check('missing_rally_abstains',a['proposals']['delivery'] is None)
 # Pure visibility grid: all aliases of start/end must be excluded.
 opaque=np.zeros((5,5),bool);opaque[2,4]=True
 e=exposure_map(opaque,[(2,0)],16.,time.perf_counter()+5);check('rounded_endpoint_not_self_occlusion',e[2,4]==1)
 opaque[:]=False;opaque[2,0]=True;e=exposure_map(opaque,[(2,0)],16.,time.perf_counter()+5);check('rounded_source_not_self_occlusion',e[2,4]==1)
 opaque[:]=False;opaque[2,2]=True;e=exposure_map(opaque,[(2,0)],16.,time.perf_counter()+5);check('known_interior_wall_occludes',e[2,4]==0)
 opaque[:]=False;e=exposure_map(opaque,[(2,0),(1,0)],16.,time.perf_counter()+5);check('empty_or_unknown_is_not_blocker',e[2,4]==2)
 e=exposure_map(opaque,[(2,0)],100.,time.perf_counter()+5);check('finite_visibility_horizon',e[2,4]==0)
 check('reference_bound',len(reference_cells(np.ones((5,5),bool)))==8)
 check('visibility_deadline',exposure_map(opaque,[(2,0)],16.,time.perf_counter()-1) is None)
 m=MapMemory(256,256);m.free[:]=True;pm=GeometryPlanningMemory(m);values=np.zeros(m.shape,np.float32);values[3:9,8]=1.
 pm._coverage_values_cache=(64.,values,np.zeros(m.shape,bool));pm._blocked[3:9,8]=True
 allowed=np.zeros(m.shape,bool);allowed[1,10]=allowed[6,10]=True;base={7:[m.cell_to_world((1,10))]};agents={7:(m.cell_to_world((3,14)),1)}
 p=params(m,agents,64.,allowed);sources=np.zeros(m.shape,bool);sources[3,5]=sources[4,5]=True
 a=frontier_advice(p,base,pm,seconds=5.,objectives=('occlusion',),centre_override=sources);x=a['proposals']['occlusion']
 check('known_wall_visibility_preference_positive',x is not None)
 check('visibility_improves_two_rays',x['exposure_before']==2 and x['exposure_after']==0)
 check('occlusion_route_epsilon',x['RED_after']<=x['RED_before']+32.+1e-6)
 check('occlusion_supported_coverage_floor',x['confirmed_after']>=.95*x['confirmed_before']-1e-5)
 from swarm_rescue.solutions.planning_cost_transaction import planning_cost_transaction,cached_path_costs,field_key
 from swarm_rescue.solutions.planning_profile import planning_profile,profiled_path_costs,profiled_view
 from swarm_rescue.solutions.team_coverage import path_costs as original_costs
 from swarm_rescue.solutions import layout_preference as policy
 from types import SimpleNamespace
 def memory():
  m=MapMemory(256,192);m.free[:]=True;m.step=1000;m.identifier=2;return m
 m=memory();calls=[]
 def tracked(m,w,s):calls.append((s,float(m.CELL)));return original_costs(m,w,s)
 walk=m.free.copy()
 with planning_cost_transaction(m) as state:
  a=cached_path_costs(m,walk,(2,2),tracked);expected=a.copy();a[:]=999.
  b=cached_path_costs(m,walk,(2,2),tracked)
  check('miss_result_isolated_from_cache',np.array_equal(b,expected))
  b[:]=888.;c=cached_path_costs(m,walk,(2,2),tracked)
  check('hit_result_isolated_from_cache',np.array_equal(c,expected))
  check('actual_one_source_call_two_hits',len(calls)==1 and state['hits']==2)
  check('exact_graph_cache_side_effect',np.array_equal(m._coverage_graph_cache[0],walk))
  check('within_byte_capacity',state['bytes']<=8*1024*1024 and len(state['fields'])<=32)
 check('normal_scope_cleanup','_planning_cost_transaction' not in vars(m) and not state['fields'])
 check('cleanup_counter',m.planning_cost_diagnostics['cleanup_count']==1)
 for n in range(10):
  rng=np.random.RandomState(n);m=memory();w=rng.uniform(size=m.shape)>.25
  with planning_cost_transaction(m):
   for start in [(0,0),(3,7),(8,5)]:
    expected=original_costs(m,w,start)
    a=cached_path_costs(m,w,start,original_costs);b=cached_path_costs(m,w,start,original_costs)
    check('exact_random_field_'+str(n)+'_'+str(start),np.array_equal(a,expected) and np.array_equal(b,expected))
 m=memory();w=np.zeros(m.shape,bool);w[1,1]=True
 with planning_cost_transaction(m):
  a=cached_path_costs(m,w,(0,0),original_costs)
  check('original_forced_start_and_no_corner_cut',a[0,0]==0 and np.isinf(a[1,1]))
  w[0,1]=True;b=cached_path_costs(m,w,(0,0),original_costs)
  check('mask_mutation_invalidates',np.isfinite(b[1,1]) and not np.array_equal(a,b))
  before=float(b[0,1]);m.CELL=8.;c=cached_path_costs(m,w,(0,0),original_costs)
  check('scale_change_invalidates',c[0,1]==before*.5)
  d=cached_path_costs(m,w,(1,1),original_costs)
  check('start_change_invalidates',d[1,1]==0 and c[1,1]>0)
 m=memory();w=m.free.copy()
 with planning_cost_transaction(m,capacity=1) as state:
  cached_path_costs(m,w,(0,0),original_costs);x=cached_path_costs(m,w,(1,1),original_costs)
  check('entry_limit_original_fallback',len(state['fields'])==1 and np.array_equal(x,original_costs(m,w,(1,1))))
 with planning_cost_transaction(m,max_bytes=0) as state:
  x=cached_path_costs(m,w,(0,0),original_costs)
  check('byte_limit_original_fallback',not state['fields'] and state['bytes']==0 and np.array_equal(x,original_costs(m,w,(0,0))))
 with planning_cost_transaction(m) as outer:
  cached_path_costs(m,w,(0,0),original_costs)
  with planning_cost_transaction(m) as inner:
   check('nested_scope_independent',inner is not outer and vars(m)['_planning_cost_transaction'] is inner)
  check('outer_scope_restored',vars(m)['_planning_cost_transaction'] is outer)
  cached_path_costs(m,w,(0,0),original_costs);check('outer_cache_survives_inner',outer['hits']==1)
 try:
  with planning_cost_transaction(m):raise ValueError('synthetic failure')
 except ValueError:pass
 check('exception_scope_cleanup','_planning_cost_transaction' not in vars(m))
 other=memory()
 with planning_cost_transaction(m) as state:
  result=cached_path_costs(other,w,(0,0),original_costs)
  check('per_controller_isolation',state['calls']==0 and '_planning_cost_transaction' not in vars(other))
 pm=GeometryPlanningMemory(m)
 with planning_cost_transaction(m) as state:
  cached_path_costs(pm,w,(0,0),original_costs);cached_path_costs(m,w,(0,0),original_costs)
  check('own_view_and_root_share_transaction',state['hits']==1)
 before=[m.free.copy(),m.hits.copy()]
 with planning_profile(m) as state:
  expected=original_costs(m,w,(0,0));x=profiled_path_costs(m,w,(0,0),original_costs);y=profiled_path_costs(m,w,(0,0),original_costs)
  check('readonly_profile_exact_fields',np.array_equal(x,expected) and np.array_equal(y,expected) and state['field_duplicates']==1)
  a=profiled_view(m);b=profiled_view(m)
  check('readonly_profile_views_equal',np.array_equal(a.free,b.free) and np.array_equal(a._blocked,b._blocked) and state['view_duplicates']==1 and not state['view_conflicts'])
 check('readonly_profile_arrays_and_cleanup',np.array_equal(m.free,before[0]) and np.array_equal(m.hits,before[1]) and '_f18_plan_profile' not in vars(m))
 # Production policy: ineligible calls must not spend attempts OR their gap timestamp.
 m=SimpleNamespace(step=1000,identifier=2,_layout_preference_objective='delivery');calls=[]
 original=policy.frontier_advice
 def absent(*a,**kw):
  calls.append(1)
  return {'proposals':{'delivery':None},'reason':'compared_model_frontier','seconds':0.,'deadline_reached':False}
 try:
  policy.frontier_advice=absent
  agents={2:(np.zeros(2),1),1:(np.zeros(2),1)};own={2:[np.array([10.,0.])]}
  for name,result,prefix in [('reserved',own,{2:(np.zeros(2),np.ones(2))}),('other_owner',{1:[np.ones(2)]},None),('empty_own',{2:[]},None)]:
   answer=policy.apply_preference(m,agents,[],32.,result,200.,200.,prefix,(),None,None)
   check('ineligible_no_budget_'+name,answer is result and not calls and not hasattr(m,'_layout_preference_attempts') and not hasattr(m,'_layout_preference_last'))
  answer=policy.apply_preference(m,agents,[],32.,own,200.,200.,None,(),None,None)
  check('later_eligible_still_searched',len(calls)==1 and m._layout_preference_attempts==1)
  for step,want in [(1000,1),(1119,1),(1120,2),(1360,2)]:
   m.step=step;answer=policy.apply_preference(m,agents,[],32.,own,200.,200.,None,(),None,None)
   check('eligible_gap_and_cap_'+str(step),answer is own and m._layout_preference_attempts==want and len(calls)==want)
 finally:policy.frontier_advice=original
 report.update(status='PASS')
except BaseException:report.update(status='FAIL',error=traceback.format_exc());raise
finally:
 (Q/'FIRST_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'checks':len(report['checks']),'error':report.get('error')}))
