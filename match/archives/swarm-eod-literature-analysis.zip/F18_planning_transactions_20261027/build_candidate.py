from pathlib import Path
import sys,json,base64,subprocess,shlex,ast
F=Path(__file__).resolve().parent;O=F.parent/'F17_assignment_epoch_and_consumers_20261027';P=F.parent/'F13_completion_joint_transport_20261027/parent_source_reference'
v=sys.argv[1];assert v in ['S01','S02','S03'];admission=json.loads((F/'DIRECTION_ADMISSION.json').read_text(encoding='utf-8'));assert admission['gates'][v]
assets={}
if v=='S01':
 s=(O/'source_analysis_reference/team_coverage.py').read_text(encoding='utf-8')
 s=s.replace('def path_costs(memory, walkable, start):','def _original_path_costs(memory, walkable, start):',1)
 marker='\ndef _market_incumbent(';assert s.count(marker)==1
 s=s.replace(marker,'''\nfrom swarm_rescue.solutions.planning_cost_transaction import cached_path_costs
def path_costs(memory,walkable,start):
    return cached_path_costs(memory,walkable,start,_original_path_costs)

def _market_incumbent(''');assets['team_coverage.py']=s
 s=(P/'team_coverage_lns.py').read_text(encoding='utf-8')
 s=s.replace('from swarm_rescue.solutions.trust_region_cover import refine_trust_region','from swarm_rescue.solutions.trust_region_cover import refine_trust_region\nfrom swarm_rescue.solutions.planning_cost_transaction import planning_cost_transaction')
 tree=ast.parse(s);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='plan_team_coverage_lns')
 fn.body=[ast.With(items=[ast.withitem(context_expr=ast.Call(func=ast.Name(id='planning_cost_transaction',ctx=ast.Load()),args=[ast.Name(id='memory',ctx=ast.Load())],keywords=[]),optional_vars=None)],body=fn.body)]
 assets['team_coverage_lns.py']=ast.unparse(ast.fix_missing_locations(tree))+'\n'
 assets['planning_cost_transaction.py']=(F/'planning_cost_transaction.py').read_text(encoding='utf-8')
elif v=='S02':
 # Reuse only the source-generation branch, with this round's qualified policy/helper bytes.
 s=(P/'trust_region_cover.py').read_text(encoding='utf-8');marker='trust_radius_ratio=TRUST_RADIUS_RATIO,_prepared=None):';assert s.count(marker)==1
 s=s.replace(marker,'trust_radius_ratio=TRUST_RADIUS_RATIO,_prepared=None,_context_out=None):')
 marker='    pm=GeometryPlanningMemory(memory) if _prepared is None else _prepared\n';assert s.count(marker)==1;s=s.replace(marker,marker+'    if _context_out is not None: _context_out.append(pm)\n');assets['trust_region_cover.py']=s
 s=(P/'team_coverage_lns.py').read_text(encoding='utf-8').replace('    prepared=None\n','    _full_budget=travel_budget\n    prepared=None\n',1)
 marker='    return refine_trust_region(memory,agents,drops,radius,base,travel_budget=travel_budget,forbidden_points=forbidden_points,forbidden_mask=forbidden_mask,_prepared=prepared)';assert s.count(marker)==1
 s=s.replace(marker,'''    _context=[]
    result=refine_trust_region(memory,agents,drops,radius,base,travel_budget=travel_budget,forbidden_points=forbidden_points,forbidden_mask=forbidden_mask,_prepared=prepared,_context_out=_context)
    from swarm_rescue.solutions.layout_preference import apply_preference
    return apply_preference(memory,agents,drops,radius,result,_full_budget,travel_budget,reserved_prefixes,
                            forbidden_points,forbidden_mask,_context[-1] if _context else prepared)''');assets['team_coverage_lns.py']=s
 s=(P/'my_drone_eval.py').read_text(encoding='utf-8');marker='    CLEAR_NONWALL_HITS=True';assert s.count(marker)==1
 s=s.replace(marker,marker+'''
    LAYOUT_PREFERENCE='delivery'
    def _build_fleet_plan(self,step):
        self.memory._layout_preference_objective=self.LAYOUT_PREFERENCE
        self.memory._layout_preference_rally=None if self.rally is None else self.rally.copy()
        return super()._build_fleet_plan(step)
''');assets['my_drone_eval.py']=s
 for n in ['layout_frontier.py','sensed_layout_context.py','layout_preference.py']:assets[n]=(F/n).read_text(encoding='utf-8')
else:
 s=(P/'team_coverage_lns.py').read_text(encoding='utf-8').replace('    prepared=None\n','    prepared=None\n    _single_view_created=False\n',1)
 marker='        prepared,travel_budget=_prefix_budget_context(memory,agents,drops,radius,travel_budget,reserved_prefixes)\n';assert s.count(marker)==1
 s=s.replace(marker,marker+'''    elif any(pos is not None and int(count)>0 for pos,count in agents.values()):
        prepared=GeometryPlanningMemory(memory)
        _single_view_created=True
''')
 marker='    return refine_trust_region(memory,agents,drops,radius,base,travel_budget=travel_budget,forbidden_points=forbidden_points,forbidden_mask=forbidden_mask,_prepared=prepared)';assert s.count(marker)==1
 s=s.replace(marker,'''    if _single_view_created:
        previous=getattr(memory,'planning_view_diagnostics',{})
        memory.planning_view_diagnostics={'created':previous.get('created',0)+1,
            'nonempty_shared':previous.get('nonempty_shared',0)+int(any(base.values()))}
'''+marker);assets['team_coverage_lns.py']=s
for s in assets.values():ast.parse(s)
payload={'version':v,'assets':{n:base64.b64encode(s.encode()).decode() for n,s in assets.items()}}
# Common frozen-parent/ZIP builder retained from F17, with new IDs/objectives only.
template=(O/'build_candidate.py').read_text(encoding='utf-8');tree=ast.parse(template)
node=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='code' for t in n.targets))
code=ast.literal_eval(node.value).replace(O.name,F.name).replace("{'R01':21,'R02':22,'R03':23}","{'S01':24,'S02':25,'S03':26}").replace("{'R01':'handoff','R02':'delivery','R03':'horizon_one'}","{'S01':'planning_fields','S02':'delivery','S03':'planning_view'}")
code=code.replace('observer_qualification/QUALIFICATION_RESULT.json','observer_qualification_revision3/QUALIFICATION_RESULT.json')
ast.parse(code)
proc=subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps(payload).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
log=F/(v+'_build_revision1_console.txt');assert not log.exists();log.write_bytes(proc.stdout+proc.stderr)
if proc.returncode:print((proc.stdout+proc.stderr).decode(errors='replace')[-5000:]);raise SystemExit(proc.returncode)
r=proc.stdout
p=F/(v+'_BUILD.json');assert not p.exists();p.write_bytes(r);d=json.loads(r);print(json.dumps({k:d[k] for k in ['candidate_id','objective','zip_sha256','changed_files','release_status']}))
