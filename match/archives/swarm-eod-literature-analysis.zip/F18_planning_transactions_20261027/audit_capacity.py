from pathlib import Path
import subprocess,shlex
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import json,subprocess,os,ast
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F18_planning_transactions_20261027';Q=F/'capacity_audit';assert not Q.exists();Q.mkdir()
source=r"""
from pathlib import Path
import sys,json
Q=Path(__file__).resolve().parent;W=Q.parent/'helper_qualification/workspace';sys.path.insert(0,str(W/'src'))
import numpy as np
from swarm_rescue.solutions.greedy_mapping import MapMemory
from swarm_rescue.solutions.team_coverage import path_costs
from swarm_rescue.solutions.planning_cost_transaction import planning_cost_transaction,cached_path_costs
def deep_bytes(value):
 seen=set();todo=[value];size=0
 while todo:
  item=todo.pop()
  if id(item) in seen:continue
  seen.add(id(item));size+=sys.getsizeof(item)
  if isinstance(item,(list,tuple)):todo.extend(item)
 return size
rows=[]
for width,height in [(640,480),(1280,960),(1600,1200)]:
 m=MapMemory(width,height);m.free[:]=True
 with planning_cost_transaction(m) as state:
  x=cached_path_costs(m,m.free,(0,0),path_costs);y=cached_path_costs(m,m.free,(0,0),path_costs)
  graph=m._coverage_graph_cache;actual=deep_bytes(graph)
  estimate=int(np.asarray(graph[0]).nbytes)+len(graph[1])*128+sum(map(len,graph[1]))*192+4096
  rows.append({'synthetic_shape':list(m.shape),'actual_graph_heap_bytes':actual,'old_conservative_graph_estimate':estimate,'old_cache_hits':state['hits'],'limit':8*1024*1024,'exact_results':bool(np.array_equal(x,y))})
d={'status':'PASS','game_rounds':0,'rows':rows,'finding':'Fixed all-free synthetic graphs, not actual map snapshots. Compare overly conservative adjacency accounting with actual CPython heap size before candidate freeze; 8MiB and32field caps unchanged.'}
(Q/'FIRST_RESULT.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
"""
p=Q/'audit.py';p.write_bytes(source.encode());ast.parse(source)
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with (Q/'first_console.log').open('x') as log:r=subprocess.run(['bash',str(R/'run_server.sh'),'-u',str(p)],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
print((Q/'FIRST_RESULT.json').read_text());raise SystemExit(r.returncode)
'''
r=subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
p=F/'capacity_audit_console.txt';assert not p.exists();p.write_bytes(r.stdout);print(r.stdout.decode(errors='replace'));raise SystemExit(r.returncode)
