"""All available verified frozen-K01 cohorts in preselected phase roots, own scalars only."""
from pathlib import Path
import json,ast,tarfile
F=Path(__file__).resolve().parent;B=F.parent;sha='404d330e7f28c5b245c1486029eaab6a60633a0a33207018cd74c348398772c3'
roots=['F09_route_and_views_20261026','F11_optics_hysteresis_stall_20261027','F12_kernel_drop_terminal_20261027',F.name]
rows=[];cohorts=[];seen=set();issues=[]
for rootname in roots:
 root=B/rootname
 for receipt_path in sorted(root.glob('*_PERF/K01_*/CLIENT_FIRST_RAW_REVIEW.json')):
  G=receipt_path.parent;receipt=json.loads(receipt_path.read_text(encoding='utf-8'));p=G/'RESULT.json'
  if not p.exists() or not(G/'raw_results.tar.gz').exists():continue
  result=json.loads(p.read_text(encoding='utf-8'))
  if result.get('source_zip_sha256')!=sha or result.get('version')!='K01':continue
  assert receipt['valid'] and result['valid'] and result['complete']
  identity=receipt.get('archive_sha256') or result['raw_manifest_sha256']
  if identity in seen:continue
  seen.add(identity);cohorts.append(str(G.relative_to(B)))
  with tarfile.open(G/'raw_results.tar.gz','r:gz') as archive:
   for row in result['rows']:
    name=row['map'];events=[]
    for raw in archive.extractfile(name+'_red/console.log'):
     line=raw.decode('utf-8',errors='replace').strip()
     if not line.startswith('[active-coverage] release_all_inventory '):continue
     try:
      _,_,owner,step,model=line.split(' ',4);events.append({'owner':int(owner),'step':int(step),'model':ast.literal_eval(model)})
     except (ValueError,SyntaxError) as e:issues.append({'cohort':str(G.relative_to(B)),'map':name,'error':str(e)})
    early=[e for e in events if e['step']<48]
    rows.append({'cohort':str(G.relative_to(B)),'map':name,'full_score':row['full_score'],'placed':row['placed'],
      'first_readiness_step':min((e['step'] for e in events),default=None),'early_before48':early})
d={'status':'PASS','source_sha256':sha,'selection':'All already-first-verified locally available frozen-K01 full cohorts under four preselected F09/F11/F12/F18 phase roots at analysis time, deduplicated archiveSHA; no scores used to include/exclude.',
 'cohorts':cohorts,'full_map_rows':len(rows),'early_readiness_map_rows':sum(bool(x['early_before48']) for x in rows),
 'early_rows':[x for x in rows if x['early_before48']],'parse_issues':issues,'rows':rows,
 'scope':'Own public RED scalar source log tag only. No BLUElog/privateobjects/NPZ/pickle/array deserialization/replay or servercommands. Earlyready alone doesnotidentifyclockcause; current S01candidateoutlier is outside this frozenK01control dataset.'}
p=F/'K01_EARLY_READINESS_COHORT_AUDIT.json';assert not p.exists();p.write_bytes((json.dumps(d,indent=2)+'\n').encode());print(json.dumps({k:d[k] for k in ['status','full_map_rows','early_readiness_map_rows','early_rows','parse_issues']}))
