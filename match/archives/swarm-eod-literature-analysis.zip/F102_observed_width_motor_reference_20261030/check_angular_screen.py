"""Actual public BLUE drive on generated finite-wall noiseless snapshots."""
from pathlib import Path
from types import SimpleNamespace
import ast,json,math
import numpy as np
F=Path(__file__).resolve().parent;H=F.parent
source=(H/'F91_public_blue_cluster_recheck_20261030/reference_source/rescue_shared.py').read_text()
cls=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='SensorRescue')
drive=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='drive')
env={'np':np,'math':math};exec(compile(ast.Module(body=[drive],type_ignores=[]),'actual_public_drive','exec'),env)
angles=np.linspace(-math.pi,math.pi,181);widths=[50.,64.,68.63162928880607,72.56230966173388,80.]
rows=[]
for width in widths:
    blocked=[];rotating=[];commands=[]
    for phase in np.linspace(0,math.radians(7.5),151,endpoint=False):
        sy=np.sin(angles+phase)
        ranges=np.divide(width/2,abs(sy),out=np.full(181,np.inf),where=abs(sy)>1e-12)
        xhit=ranges*np.cos(angles+phase)
        ranges=np.where((abs(xhit)<=80)&(ranges<=300),ranges,300.)
        obj=SimpleNamespace(pose=np.zeros(2),heading=float(phase),carrying=True,grid=SimpleNamespace(speed_scale=1.),velocity_trim=np.zeros(2),
            lidar_values=lambda:ranges,lidar_rays_angles=lambda:angles)
        u=env['drive'](obj,np.array([250.,0.]),np.zeros(2))
        zero=math.hypot(u['forward'],u['lateral'])<=1e-12
        blocked.append(zero);rotating.append(zero and abs(u['rotation'])>1e-12)
        commands.append(dict(phase_degrees=float(math.degrees(phase)),command=u,zero_translation=zero))
    rows.append(dict(width=width,zero_translation_fraction=float(np.mean(blocked)),zero_but_rotating_fraction=float(np.mean(rotating)),snapshots=commands))
out=dict(status='COMPLETE_LOADED_ANGULAR_SCREEN',native_games=0,production_changed=False,rows=rows,
 scope='Actual drive only, generated finite160px walls, ideal compass/zero measured speed/trim and noiseless continuous rays. Snapshot zero translation is not dynamic trapping; rotation/recovery/physics/noise are absent.')
(F/'ANGULAR_SCREEN.json').write_text(json.dumps(out,indent=2)+'\n')
for r in rows:print(json.dumps({k:v for k,v in r.items() if k!='snapshots'}))
