"""Predeclared generated-body falsification, no native games or BLUE state."""
from pathlib import Path
import ast, hashlib, json, time, traceback
import numpy as np

F=Path(__file__).resolve().parent; H=F.parent
# These are two own-scan estimates, not true official-map widths.
widths=[68.63162928880607,72.56230966173388]
specs=[(w,d,0,'sdk_noisy_mean') for w in widths for d in [1.,-1.]]

declaration=dict(native_games=0, production_changed=False, horizon=7200,
 initial_cases=[dict(width=w,direction=d,fixture=s,feedback=m) for w,d,s,m in specs],
 max_cases=12,stage_rule='Only if any first4 case does not exit or first_exit>1800, run all4 second-noise fixtures and all4 width+5 sensitivity controls; else stop as no slow mechanism evidence.',
 fixed_geometry='walls x[-80,80]; body at(0,0), bomb at(24,0); legal fresh SDK grasp; initial velocity/trim zero',
 sensors='Actual fresh DroneOdometer raw computation and optional SDK noise; optional actual DroneCompass raw+AR1 noise. Exact mean uses ideal compass. Lidar iid2.5 as before.',
 scope='Finite160px channel is longer than the92-114px measured supporting segments: fast escape is a useful counterexample, slow/no escape is not a real-map certificate. Ideal true position still supplied, no GPS/NO_GPS_ZONE pose estimator, full BLUE scheduler, occluding other drones, disposal or official score. Same unchanged public drive+recover. Any exit falsifies universal motor trapping in this restricted setup; no exit does not prove game trapping.')
(F/'PREDECLARATION.json').write_text(json.dumps(declaration,indent=2)+'\n')

def definitions():
    p=H/'F67_long_horizon_motor_reference_20261030/check_long_horizon_motor.py'
    tree=ast.parse(p.read_text()); nodes=[]
    for n in tree.body:
        if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='started' for t in n.targets): break
        nodes.append(n)
    ns={'__file__':str(p)}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'f67_definitions_no_cases','exec'),ns)
    return ns['source'],ns['env']

def main():
    assert json.loads((H/'F100_raster_boundary_pilot_20261030/STATUS.json').read_text())['status']=='COMPLETE_FINITE_STAGED_CAMPAIGN', 'No physics reference while native queue active'
    assert json.loads((H/'F100_raster_boundary_pilot_20261030/CAMPAIGN_CLIENT_REVIEW.json').read_text())['status']=='PASS', 'Consume audited native result first'
    source,env=definitions()
    old='def run(width,direction,seed):'
    assert source.count(old)==1
    source=source.replace(old,'def run(width,direction,seed,feedback):',1)
    old='    minimum = 1000000000.0'
    assert source.count(old)==1
    source=source.replace(old,'''    from swarm_rescue.simulation.drone.drone_sensors import DroneOdometer,DroneCompass
    odometer=DroneOdometer(); odometer._anchor=base; odometer._values=np.zeros(3)
    compass=DroneCompass(); compass._anchor=base
    np.random.seed(90100+seed)
    measured_sq=0.; true_sq=0.; max_trim=0.; maximum_x=-np.inf; minimum_x=np.inf
    minimum = 1000000000.0''',1)
    old='        motor_obj.pose=np.asarray(base.pm_body.position,float);motor_obj.heading=base.pm_body.angle'
    if old not in source:
        lines=source.splitlines()
        print(json.dumps(dict(source_lines=[x for x in lines if 'motor_obj.pose' in x or 'motor_obj.heading' in x])),flush=True)
    assert source.count(old)==1
    source=source.replace(old,'''        odometer._compute_raw_sensor(); compass._compute_raw_sensor()
        if feedback=='sdk_noisy_mean':
            odometer._apply_noise(); compass._apply_noise()
        measured_heading=float(compass._values)
        odom=odometer._values
        angle=measured_heading-float(odom[2])+float(odom[1])
        measured_velocity=float(odom[0])*np.array([math.cos(angle),math.sin(angle)])
        measured_sq+=float(measured_velocity@measured_velocity)
        true_sq+=float(np.asarray(base.pm_body.velocity)@np.asarray(base.pm_body.velocity))
        motor_obj.pose=np.asarray(base.pm_body.position,float); motor_obj.heading=measured_heading
        maximum_x=max(maximum_x,float(base.pm_body.position.x)); minimum_x=min(minimum_x,float(base.pm_body.position.x))''',1)
    # Real rays use physical sensor heading, controller transforms with measured heading.
    old='sy=np.sin(angles+motor_obj.heading)'
    assert source.count(old)==1
    source=source.replace(old,'sy=np.sin(angles+base.pm_body.angle)',1)
    old='np.cos(angles+motor_obj.heading)'
    assert source.count(old)==1
    source=source.replace(old,'np.cos(angles+base.pm_body.angle)',1)
    old='command=SensorRescue.drive(motor_obj,target,np.asarray(base.pm_body.velocity,float))'
    assert source.count(old)==1
    source=source.replace(old,'command = SensorRescue.drive(motor_obj, target, measured_velocity)\n        max_trim=max(max_trim,float(np.max(np.abs(motor_obj.velocity_trim))))',1)
    old='return dict(first_exit=first_exit,'
    assert source.count(old)==1
    source=source.replace(old,"return dict(feedback=feedback,measured_velocity_rms=(measured_sq/(t+1))**.5,true_endpoint_velocity_rms=(true_sq/(t+1))**.5,max_abs_trim=max_trim,body_x_extent=[minimum_x,maximum_x],first_exit=first_exit,",1)
    (F/'GENERATED_REFERENCE.py').write_text(source)
    exec(compile(source,'actual_sdk_odom_feedback_reference','exec'),env)
    start=time.perf_counter(); rows=[]
    for w,d,s,m in specs:
        result=env['run'](w,d,s,m); result.pop('trajectory',None)
        rows.append(dict(width=w,direction=d,fixture=s,feedback=m,result=result))
        (F/'PROGRESS.json').write_text(json.dumps(dict(completed=len(rows),cases=rows,seconds=time.perf_counter()-start),indent=2)+'\n')
        print(json.dumps(rows[-1]),flush=True)
    slow=any(r['result']['first_exit'] is None or r['result']['first_exit']>1800 for r in rows)
    if slow:
        controls=[(w,d,1,'sdk_noisy_mean') for w in widths for d in [1.,-1.]]
        controls += [(w+5.,d,0,'sdk_noisy_mean') for w in widths for d in [1.,-1.]]
        for w,d,s,m in controls:
            result=env['run'](w,d,s,m);result.pop('trajectory',None)
            rows.append(dict(width=w,direction=d,fixture=s,feedback=m,result=result))
            (F/'PROGRESS.json').write_text(json.dumps(dict(completed=len(rows),cases=rows,seconds=time.perf_counter()-start),indent=2)+'\n')
            print(json.dumps(rows[-1]),flush=True)
    out=dict(initial_slow_gate=slow,
status='COMPLETE_OBSERVED_WIDTH_SENSOR_FALSIFICATION',cases=rows,seconds=time.perf_counter()-start,
             native_games=0,production_changed=False,declaration=declaration,
             generated_source_sha256=hashlib.sha256(source.encode()).hexdigest())
    (F/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__':
    try:main()
    except Exception:
        p=F/'FIRST_ERROR.json'
        if not p.exists():p.write_text(json.dumps(dict(status='REFERENCE_ERROR',traceback=traceback.format_exc(),native_games=0),indent=2)+'\n')
        raise
