"""Generated straight corridors, fresh SDK shapes/grasper and Pymunk only."""
from pathlib import Path
from types import SimpleNamespace
import json, math, sys
import numpy as np
import pymunk
R = Path('/home/junhao/quan/parallel_test_solver/match')
H = R / 'solver_study/framework_screen_20261016/best87_independent_20261025'
F = H / 'F58_grasp_geometry_model_20261030'
b = json.loads((H / 'F57_joint_backup_pilot_20261030/J10/BUILD.json').read_text())
sys.path.insert(0, str(Path(b['workspace']) / 'src'))
from swarm_rescue.simulation.drone.drone_base import DroneBase
from swarm_rescue.simulation.drone.grasper import Grasper
from swarm_rescue.simulation.elements.bomb import Bomb

def run(width,direction,seed,feedback):
    rng=np.random.default_rng(9000+seed)
    space = pymunk.Space()
    space.gravity = (0, 0)
    space.damping = 0.95
    base = DroneBase()
    base.pm_body.position = (0, 0)
    base.agent = SimpleNamespace(external_sensors=[])
    base._playground = SimpleNamespace(space=space)
    grasp = Grasper(base, max_grasped=1)
    base.add_device(grasp)
    bomb = Bomb(disposal_center=None)
    bomb.pm_body.position = (24.0, 0.0)
    for s in base._pm_shapes + bomb._pm_shapes + grasp._pm_shapes:
        s.filter = pymunk.ShapeFilter()
        s.cache_bb()
    space.add(base.pm_body, bomb.pm_body, *base._pm_shapes, *bomb._pm_shapes, *grasp._pm_shapes)
    walls = [pymunk.Segment(space.static_body, (-80, y), (80, y), 0.0) for y in [-width / 2, width / 2]]
    for s in walls:
        s.friction = 0.9
        s.elasticity = 0.5
    space.add(*walls)
    contacts = any((len(a.shapes_collide(c).points) > 0 for a in grasp._pm_shapes for c in bomb._pm_shapes))
    assert contacts
    grasp.grasp_controller.command = 1
    grasp.apply_commands()
    grasp.grasps(bomb)
    assert bomb in grasp.grasped_bombs and len(space.constraints) == 1
    initial_pivot = next(iter(space.constraints))
    joint_details = dict(type=type(initial_pivot).__name__, anchor_a=list(initial_pivot.anchor_a), anchor_b=list(initial_pivot.anchor_b), collide_bodies=initial_pivot.collide_bodies)
    motor_obj=SimpleNamespace(pose=np.zeros(2),heading=0.,grid=SimpleNamespace(speed_scale=1.),carrying=True,velocity_trim=np.zeros(2))
    motor_obj.lidar_values=lambda:motor_obj.ranges;motor_obj.lidar_rays_angles=lambda:angles
    motor_obj.progress_pose=None;motor_obj.progress_step=0;motor_obj.recovery_until=0
    motor_obj.goal=np.array([direction*200.,0.]);motor_obj.phase='dispose';motor_obj.mode='deliver';motor_obj.timed_path=()
    motor_obj.recovery_point=(0.,0.);motor_obj.awaiting_commit=lambda:False
    recoveries=0
    first_exit=None

    from swarm_rescue.simulation.drone.drone_sensors import DroneOdometer,DroneCompass
    odometer=DroneOdometer(); odometer._anchor=base; odometer._values=np.zeros(3)
    compass=DroneCompass(); compass._anchor=base
    np.random.seed(90100+seed)
    measured_sq=0.; true_sq=0.; max_trim=0.; maximum_x=-np.inf; minimum_x=np.inf
    minimum = 1000000000.0
    steps = 0
    reached = None
    trajectory = []
    for t in range(7200):
        odometer._compute_raw_sensor(); compass._compute_raw_sensor()
        if feedback=='sdk_noisy_mean':
            odometer._apply_noise(); compass._apply_noise()
        measured_heading=float(compass._values)
        odom=odometer._values
        angle=measured_heading-float(odom[2])+float(odom[1])
        measured_velocity=float(odom[0])*np.array([math.cos(angle),math.sin(angle)])
        measured_sq+=float(measured_velocity@measured_velocity)
        true_sq+=float(np.asarray(base.pm_body.velocity)@np.asarray(base.pm_body.velocity))
        motor_obj.pose=np.asarray(base.pm_body.position,float); motor_obj.heading=measured_heading
        maximum_x=max(maximum_x,float(base.pm_body.position.x)); minimum_x=min(minimum_x,float(base.pm_body.position.x))
        sy=np.sin(angles+base.pm_body.angle);motor_obj.ranges=np.full(len(angles),300.)
        for wall_y in [-width/2,width/2]:
            ray=np.divide(wall_y-motor_obj.pose[1],sy,out=np.full(len(angles),np.inf),where=abs(sy)>1e-10)
            good=(ray>0)&(ray<300)&(abs(motor_obj.pose[0]+ray*np.cos(angles+base.pm_body.angle))<=80.);motor_obj.ranges[good]=np.minimum(motor_obj.ranges[good],ray[good])
        motor_obj.ranges+=rng.normal(0,2.5,len(angles))
        motor_obj.elapsed_timestep=t
        before=motor_obj.recovery_until
        target=SensorRescue.recover(motor_obj,[direction*200.,0.],motor_obj.ranges)
        recoveries+=int(motor_obj.recovery_until!=before)
        command = SensorRescue.drive(motor_obj, target, measured_velocity)
        max_trim=max(max_trim,float(np.max(np.abs(motor_obj.velocity_trim))))
        base.forward_controller.command=command['forward'];base.lateral_controller.command=command['lateral']
        base.angular_vel_controller.command=command['rotation']
        base.apply_commands()
        bomb.compute_movement()
        for sub in range(10):
            space.step(0.1)
            steps += 1
            for obj in [base, bomb]:
                for s in obj._pm_shapes:
                    for v in s.get_vertices():
                        world = obj.pm_body.local_to_world(v)
                        minimum = min(minimum, width / 2 - abs(world.y))
            if steps % 10 == 0:
                trajectory.append(dict(step=steps, body=list(base.pm_body.position), payload=list(bomb.pm_body.position), body_angle=base.pm_body.angle, payload_angle=bomb.pm_body.angle))
        if first_exit is None and abs(base.pm_body.position.x)>100 and abs(bomb.pm_body.position.x)>100 and base.pm_body.position.x*bomb.pm_body.position.x>0:
            first_exit=t+1
        if direction*base.pm_body.position.x > 150 and direction*bomb.pm_body.position.x > 120:
            reached = t + 1
            break
    return dict(feedback=feedback,measured_velocity_rms=(measured_sq/(t+1))**.5,true_endpoint_velocity_rms=(true_sq/(t+1))**.5,max_abs_trim=max_trim,body_x_extent=[minimum_x,maximum_x],first_exit=first_exit,recovery_events=recoveries,width=width, old_radius32_center_graph_has_corridor=width >= 64.0, real_grasp_contact_at_center_distance24=contacts, actual_joint=joint_details, payload_remained_attached=bomb in grasp.grasped_bombs, transport_ticks=reached, physics_substeps=steps, minimum_hull_to_wall_margin=minimum, final_body=list(base.pm_body.position), final_payload=list(bomb.pm_body.position), physics_iterations=space.iterations, trajectory=trajectory)