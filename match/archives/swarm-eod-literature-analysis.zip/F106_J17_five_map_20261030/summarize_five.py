"""Consume only the completed, first-Windows-byte-reviewed five-map cohort."""
from pathlib import Path
import datetime,json,statistics
F=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
a=read(F/'CAMPAIGN_CLIENT_REVIEW.json')
assert a['status']=='PASS' and not a['native_failure']
assert read(F/'J17_A/CLIENT_FIRST_RAW_REVIEW.json')['status']=='PASS'
assert read(F/'LOCAL_COLLECTOR_RESULT.json')['status']=='COMPLETE'
assert len(a['groups'])==1
g=a['groups'][0];rows=g['rows']
assert g['maps']==5 and len(rows)==5 and {x['map'] for x in rows}=={'Map01','Map02','Map03','Map04','Map05'}
mean=statistics.mean(x['score'] for x in rows)
assert abs(mean-g['five_map_mean'])<1e-9
terms={k:statistics.mean(r['weighted_terms'][k] for r in rows) for k in rows[0]['weighted_terms']}
assert abs(sum(terms.values())-mean)<1e-8
report=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='COMPLETE_ANALYZED',five_map_mean=mean,
    mean_map_score=statistics.mean(r['map_score'] for r in rows),mean_wall_score=statistics.mean(r['wall_score'] for r in rows),
    placed=g['placed'],expected=g['expected'],blue_disposed=g['blue_disposed'],blue_expected=sum(r['blue_expected'] for r in rows),
    red_clock_hits=g['red_clock_hits'],blue_clock_hits=g['blue_clock_hits'],mean_weighted_terms=terms,rows=rows,
    prior_Map01_scores_excluded=True,normal_clock_terminations_retained=True,no_retries=True,
    automatic_promotion=False,official_submission_ready=False)
(F/'FINAL_FIVE_MAP_ANALYSIS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
lines=['J17完整五图结果（2026-10-30，北京时间）','',
    '一组全新Map01-05 RED+BLUE，共10native；冻结J17源码，未复用历史红队分数；所有正常时限结束的成绩均保留，不挑分或重试。',
    f'五图平均分：{mean:.10f}；实际投放：{g["placed"]}/{g["expected"]}；蓝队清除：{g["blue_disposed"]}/{sum(r["blue_expected"] for r in rows)}（按实际投放数量）。',
    '','地图 | 完整红分 | 地图分 | 墙面覆盖分 | 投放 | RED步/秒 | BLUE清除/步/秒 | RED墙钟hit | BLUE墙钟hit']
for r in rows:
    lines.append(f'{r["map"]} | {r["score"]:.8f} | {r["map_score"]:.8f} | {r["wall_score"]:.8f} | {r["placed"]}/{r["expected"]} | {r["red_steps"]}/{r["red_wall_seconds"]:.4f} | {r["blue_disposed"]}/{r["blue_expected"]} / {r["blue_steps"]} / {r["blue_wall_seconds"]:.4f} | {r["red_wall_hit"]} | {r["blue_wall_hit"]}')
lines+=['',f'平均分加权分解：地图{terms["map"]:.8f}，墙面覆盖{terms["wall"]:.8f}，红队时间{terms["time"]:.8f}，蓝队难度与完成度{terms["difficulty_completion"]:.8f}。',
    f'最低图：{min(rows,key=lambda r:r["score"])["map"]}；最高图：{max(rows,key=lambda r:r["score"])["map"]}。',
    '','原SDK e2f022b、同team006、各图原始时限/线程/资源门槛不变，未设外部seed。原始NPZ/pickle只字节SHA，未反序列化；未读取BLUE私有console或状态。',
    '首次Windows原始字节审查及campaign审查PASS。此为单组五图观察，不能称稳定提升或相同随机条件的因果对照；不自动新增重复组、晋级或发布。']
(F/'五图结果汇总.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
