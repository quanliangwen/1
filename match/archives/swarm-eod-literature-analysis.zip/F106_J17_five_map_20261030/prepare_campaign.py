from pathlib import Path
import ast,hashlib,json
R=Path('/home/junhao/quan/parallel_test_solver/match')
H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
P=H/'F105_J17_timeout_recheck_20261030';F=H/'F106_J17_five_map_20261030'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
assert not (F/'PREDECLARATION.json').exists() and read(P/'CAMPAIGN_CLIENT_REVIEW.json')['status']=='PASS'
parent=read(P/'PREDECLARATION.json')
for folder in ['J17','versions/J17']:(F/folder).mkdir(parents=True)
save(F/'J17/BUILD.json',read(P/'J17/BUILD.json'))
save(F/'versions/J17/QUALIFICATION.json',read(P/'versions/J17/QUALIFICATION.json'))
(F/'qualify_candidate.py').write_text((P/'qualify_candidate.py').read_text().replace(P.name,F.name))
launch=(P/'launch_campaign.py').read_text().replace(P.name,F.name).replace('max_native_rounds=3','max_native_rounds=10')
launch=launch.replace('Original gate then fixed J17 layout BLUE replay, Windows review, then one fresh Map01 J17 RED+BLUE pair','Original gate then one complete fresh J17 Map01-05 RED+BLUE cohort; no retries')
(F/'launch_campaign.py').write_text(launch)
d={k:parent[k] for k in ['sdk_commit','sdk_files','blue_binding','blue_binding_sha256','resource_gate','frozen_files','versions','optimizer']}
d.update(phase=F.name,selection=['J17'],maps=['Map01','Map02','Map03','Map04','Map05'],seed=None,
    explicit_human_authorization='将J17跑五图看一下平均结果',
    schedule=[dict(version='J17',cohort='A',label='sdk_e2f022b_f106_J17_A_FIVE')],
    min_native_rounds=10,max_native_rounds=10,additional_cohorts=False,automatic_promotion=False,
    prior_Map01_runs_not_part_of_five_map_mean=True,
    ranking_metric='Arithmetic mean of all five fresh full RED scores; no cherry picking, no reuse of old RED phases.',
    clock_policy='Normal official clock termination is retained in the mean and separately flagged, never hidden or rerun. Actual crash/exception stops chain and prevents a complete five-map claim.',
    unchanged_conditions=dict(SDK=True,BLUE=True,RED_payload=True,official_limits_per_map=True,threads=True,resources=True,seed_not_set=True),
    official_submission_ready=False)
for name in ['run_offline.py','os_resource_observer.py','qualify_candidate.py','launch_campaign.py']:
    ast.parse((F/name).read_text());d['frozen_files'][str(F/name)]=sha(F/name)
save(F/'PREDECLARATION.json',d)
print(json.dumps(dict(status='PREPARED_NOT_STARTED',maps=d['maps'],max_native_rounds=10,zip_sha256=d['versions']['J17']['original_zip_sha256'])))
