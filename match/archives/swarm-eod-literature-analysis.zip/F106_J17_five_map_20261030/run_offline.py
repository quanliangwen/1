"""One explicitly requested fresh J17 five-map cohort, no retries or promotion."""
from pathlib import Path
import fcntl,importlib.util,json,os,time,traceback
from os_resource_observer import ResourceObserver
R=Path('/home/junhao/quan/parallel_test_solver/match')
H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
F=H/'F106_J17_five_map_20261030'
read=lambda p:json.loads(p.read_text())
spec=importlib.util.spec_from_file_location('frozen_runner',H/'F32_official_sdk_20261028/FIVE_MAP_REBASELINE/run_offline.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.F,b.D=F,read(F/'PREDECLARATION.json')
b.NAMES,b.BLUE=b.D['selection'],b.D['blue_binding'];b.WBLUE=Path(b.BLUE['blue_workspace'])
b.STATE.update(phase=F.name,decisions=[],max_native_rounds=10,explicit_human_five_map_request=True)
def summarize():
    b.save(F/'RESULT.json',dict(b.STATE,automatic_promotion=False,additional_cohorts=False,official_submission_ready=False))
b.summarize=summarize
def main():
    lease=(F/'coordinator.lock').open('a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not (F/'RUN_ONCE.json').exists(),'Finite cohort already consumed'
    b.save(F/'RUN_ONCE.json',dict(utc=b.utc(),pid=os.getpid(),starttime_ticks=Path('/proc/self/stat').read_text().split()[21],driver_sha256=b.sha(__file__),study_sha256=b.sha(F/'PREDECLARATION.json')))
    b.STATE['started_utc']=b.utc();b.validate_frozen();summarize()
    observer=ResourceObserver();observer.start()
    try:
        started=time.time()
        if not b.run_cohort(b.D['schedule'][0]):
            b.state('STOPPED_BEFORE_NATIVE_START');summarize();return
        G=F/'J17_A';b.save(G/'OS_RESOURCE_REVIEW.json',observer.review(started,time.time()))
        start=time.monotonic()
        while not (G/'CLIENT_FIRST_RAW_REVIEW.json').exists():
            if b.stop_requested():b.state('STOPPED_AWAITING_REVIEW');summarize();return
            if time.monotonic()-start>7200:raise TimeoutError('First Windows byte review timeout')
            b.state('AWAIT_FIRST_WINDOWS_REVIEW',current=dict(version='J17',cohort='A'));time.sleep(5)
        review=read(G/'CLIENT_FIRST_RAW_REVIEW.json');receipt=read(G/'RAW_ARCHIVE_RECEIPT.json')
        assert review['status']=='PASS' and review['archive_sha256']==receipt['sha256']
        b.validate_frozen()
        assert len(b.STATE['completed'])==1 and set(b.STATE['completed'][0]['map_scores'])==set(b.D['maps'])
        b.STATE['decisions'].append(dict(decision='REPORT_ALL_FIVE_MAPS_ONCE_INCLUDING_NORMAL_CLOCK_TERMINATIONS',no_retry=True,no_best_only_selection=True))
        b.state('COMPLETE_FINITE_STAGED_CAMPAIGN',current=None);summarize()
    except Exception:
        b.save(F/'FIRST_ERROR.json',dict(utc=b.utc(),traceback=traceback.format_exc(),first_native_failure=b.STATE['first_native_failure'],no_automatic_retry=True))
        b.state('STOPPED_FIRST_ERROR_NO_RETRY');summarize();raise
    finally:observer.close()
if __name__=='__main__':main()
