from pathlib import Path
import hashlib,importlib.util,json
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
F=H/'F106_J17_five_map_20261030'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (F/'RUN_ONCE.json').exists()
d=read(F/'PREDECLARATION.json');q=read(F/'J17/RESEARCH_QUALIFICATION.json')
assert q['status']=='PASS' and q['zip_sha256']==d['versions']['J17']['original_zip_sha256']=='652b59edbfba68aa5b163b2cbdc904ebecdbe75927073e3a59168013e725a839'
assert q['payload_files_sha256']==d['versions']['J17']['source_files']
receipt=dict(status='PASS_FROZEN_J17_FIVE_MAP_PRELAUNCH',maps=d['maps'],zip_sha256=q['zip_sha256'],native_rounds_started=0,unchanged_payload_and_conditions=True,explicit_five_map_request=True)
(F/'PRELAUNCH_CHECK.json').write_text(json.dumps(receipt,indent=2)+'\n')
for name in ['PRELAUNCH_CHECK.json','J17/RESEARCH_QUALIFICATION.json']:d['frozen_files'][str(F/name)]=sha(F/name)
(F/'PREDECLARATION.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('phase_driver',F/'run_offline.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.b.validate_frozen()
print(json.dumps(receipt))
