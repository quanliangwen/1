from pathlib import Path
import ast
F=Path(__file__).resolve().parent;O=F.parent/'F16_measured_layout_frontier_20261027'
def write(n,s):
 p=F/n;assert not p.exists();ast.parse(s);p.write_bytes(s.encode())
s=(O/'observer_tests.py').read_text(encoding='utf-8').replace('F16','F17').replace('f16','f17')
# New own-only callback needs the fixture's actual owner, not an unrelated ID.
s=s.replace('m.identifier=7;m._f17_layout_enabled=True','m.identifier=7;m._f17_layout_enabled=True')
marker=" report.update(status='PASS',scope=";i=s.index(marker)
extra=(F/'epoch_observer_tests.py').read_text(encoding='utf-8')
s=s[:i]+'\n'.join(' '+x for x in extra.splitlines())+'\n'+s[i:]
write('observer_tests.py',s)
s=(O/'qualify_observer.py').read_text(encoding='utf-8').replace(O.name,F.name)
s=s.replace("O=F.parent/'F15_delivery_and_transport_20261027'","O=F.parent/'F15_delivery_and_transport_20261027'")
s=s.replace("payload={'test':", "payload={'integration':base64.b64encode((F/'epoch_integration.py').read_bytes()).decode(),'test':")
s=s.replace("[('observer_tests.py','test'),('preflight.py','preflight')]","[('observer_tests.py','test'),('preflight.py','preflight'),('epoch_integration.py','integration')]")
write('qualify_observer.py',s)
