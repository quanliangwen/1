    import ast,types,zipfile,yaml
    from swarm_rescue.solutions import fleet_endpoint_repair as endpoint
    build=json.loads((C/'BUILD.json').read_text())
    class Base:
        def _reject_assignment(self,step,point):self.reject_calls+=1;self.assignment_goal=None
    class Probe(endpoint.FleetEndpointRepairMixin,Base):
        def carried_bombs_count(self):return self.stock
        def _remaining_steps(self):return 100.
        def _point_conflicts_with_drop(self,p):return False
        def _own_assignment_report(self,step):return(step,self.stock,self.assignment_goal,self.assignment_since)
    d=object.__new__(Probe);d.identifier=0;d.stock=2;d.pose=np.zeros(2);d.reject_calls=0
    d.assignment_reports={};d.fleet_states={};d.fleet_plan=None;d.drop_records={};d.blast_radius=32.
    d.STATE_FRESH_STEPS=120;d.PLAN_FRESH_STEPS=240;d.GOAL_LEASE_STEPS=600
    target=np.array([100.,0.]);d.memory=types.SimpleNamespace(CELL=16.,route=lambda pose,destination:([],None) if np.array_equal(destination,[0.,0.]) else ([destination.copy()],destination.copy()))
    original=endpoint.plan_team_coverage;requests=[]
    def planner(memory,agents,*args,**kw):requests.append((agents,kw));return {0:[target.copy()]}
    try:
        endpoint.plan_team_coverage=planner
        d._reject_assignment(700,np.zeros(2))
    finally:endpoint.plan_team_coverage=original
    check('endpoint_horizon_is_one_under_stock_two',len(requests)==1 and requests[0][0][0][1]==1)
    check('endpoint_original_reject_once',d.reject_calls==1)
    check('endpoint_repair_target_executed',np.array_equal(d.assignment_goal,target) and np.array_equal(d._endpoint_repair_route[1],target))
    check('endpoint_original_full_budget',requests[0][1]['travel_budget']==300.)
    check('endpoint_original_forbidden_rejected_disk',requests[0][1]['forbidden_points'][0][1]==48)
    check('endpoint_actual_inventory_not_modified',d.assignment_inventory==2 and d.stock==2)
    check('endpoint_request_evidence_matches_stock',d._f17_repair_request==(700,2,1))
    check('only_endpoint_file_changed',build['changed_files']==['fleet_endpoint_repair.py'])
