from pathlib import Path
import sys,json,types,traceback,io,contextlib
Q=Path(__file__).resolve().parent;W=Q/'workspace';report={'status':'STARTED','checks':[],'game_rounds':0}
def check(n,v):
 assert v,n
 report['checks'].append(n)
try:
 sys.path.insert(0,str(W/'src'))
 import numpy as np,pandas,cv2
 from swarm_rescue.solutions.diagnostic_mixin import DiagnosticMixin
 from swarm_rescue.solutions.my_drone_eval import MyDroneEval,BaseParent
 from swarm_rescue.simulation.reporting.team_info import TeamInfo
 import numpy.random.mtrand
 check('native_runtime',(np.__version__,pandas.__version__,cv2.__version__)==('1.26.4','3.0.6','4.11.0'))
 check('actual_mtrand',np.isfinite(np.random.RandomState(615).normal(size=8)).all())
 check('team615_integer',type(TeamInfo().team_number) is int and TeamInfo().team_number==615)
 check('production_objective_bound',getattr(BaseParent,'LAYOUT_PREFERENCE',None)==('delivery' if json.loads((Q/'PRODUCTION_BINDING.json').read_text())['objective']=='delivery' else None))
 check('diagnostic_wrapper_selected',MyDroneEval.__mro__[1].__name__=='DiagnosticMixin')
 check('actuator_unchanged',next(c.__name__ for c in MyDroneEval.__mro__ if '_maybe_place' in c.__dict__)=='ActiveCoverageMixin')
 class Parent:
  def _sync_placement(self,step):self.sync_calls+=1;self.pending_drop=None;return 'original_sync'
  def _plan_route(self,step,returning,peers):self.plan_calls+=1;return self.original_route
 class Probe(DiagnosticMixin,Parent):pass
 for name,pending,stock,acks in [('ack',(2,np.array([12.,24.]),100),1,1),('no_ack',(2,np.array([12.,24.]),100),2,0),('none',None,1,0)]:
  d=object.__new__(Probe);d.pending_drop=pending;d.stock=stock;d.carried_bombs_count=lambda:d.stock;d.identifier=0;d.sync_calls=0
  out=io.StringIO()
  with contextlib.redirect_stdout(out):result=d._sync_placement(120)
  lines=out.getvalue().splitlines()
  check('sync_once_and_return_'+name,d.sync_calls==1 and result=='original_sync' and d.pending_drop is None)
  check('real_ack_logging_'+name,len(lines)==acks)
  if acks:
   event=json.loads(lines[0][len('[F17_DROP_ACK] '):]);check('command_time_vs_current_inventory',event['stock_at_command']==2 and event['stock_after']==1 and event['pending_step']==100 and event['position']==[12.,24.])
 d=object.__new__(Probe);d.identifier=3;d.stock=1;d.carried_bombs_count=lambda:d.stock;d.assignment_since=50
 d.placement_goal=np.array([32.,48.]);d.original_route=([d.placement_goal.copy()],d.placement_goal.copy());d.plan_calls=0;d._diag_costs={}
 out=io.StringIO()
 with contextlib.redirect_stdout(out):a=d._plan_route(100,False,[]);b=d._plan_route(124,False,[])
 check('original_routes_returned_once',a is d.original_route and b is d.original_route and d.plan_calls==2)
 check('same_goal_does_not_spam',len(out.getvalue().splitlines())==1)
 event=json.loads(out.getvalue().splitlines()[0][len('[F17_TARGET_SELECTED] '):]);check('actual_selected_target_logged',event['owner']==3 and event['goal']==[32.,48.] and event['stock']==1)
 check('goal_unchanged',np.array_equal(d.placement_goal,[32.,48.]))
 d.placement_goal=None
 with contextlib.redirect_stdout(io.StringIO()):d._plan_route(148,False,[])
 check('release_only_resets_diagnostic',d._diag_selected_identity is None)
 d.placement_goal=np.array([32.,48.]);out=io.StringIO()
 with contextlib.redirect_stdout(out):d._plan_route(172,False,[])
 check('released_reselected_goal_logged',len(out.getvalue().splitlines())==1)
 class RepairParent:
  def _reject_assignment(self,step,point):
   self.reject_calls+=1;self._f17_repair_request=(step,2,1);self._endpoint_repair_route=([point.copy()],point.copy());return 'original_reject_result'
 class RepairProbe(DiagnosticMixin,RepairParent):pass
 d=object.__new__(RepairProbe);d.identifier=2;d.reject_calls=0
 out=io.StringIO()
 with contextlib.redirect_stdout(out):r=d._reject_assignment(500,np.array([12.,24.]))
 check('repair_original_once_and_return',r=='original_reject_result' and d.reject_calls==1)
 event=json.loads(out.getvalue().splitlines()[0][len('[F17_REPAIR_TARGET] '):])
 check('repair_actual_quota_evidence',event['stock']==2 and event['quota']==1 and event['target']==[12.,24.])
 report.update(status='PASS',scope='Actual mechanism wrapper/factory and original target/sync returns; readonly own inventory/goal logs. No simulation or production ZIP changes.')
except BaseException:report.update(status='FAIL',error=traceback.format_exc());raise
finally:
 (Q/'FIRST_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'checks':len(report['checks']),'error':report.get('error')}))
