from pathlib import Path
import sys,json,ast,base64,hashlib,subprocess,shlex
F=Path(__file__).resolve().parent;O=F.parent/'F12_kernel_drop_terminal_20261027';v=sys.argv[1];assert v in ['R01','R02','R03']
assert v in json.loads((F/'DIRECTION_ADMISSION.json').read_text(encoding='utf-8'))['admitted_order']
assert json.loads((F/(v+'_DIAG')/'MECHANISM_REVIEW.json').read_text(encoding='utf-8'))['start_five_map_now'] is True
def common(s):
 return s.replace(O.name,F.name).replace('f12pair_','f17pair_').replace('F12','F17').replace('M01',v)
bundle={};manifest={}
for name in ['prepare_performance','launch_performance']:
 d=json.loads((O/'operators/M01'/(name+'.json')).read_text(encoding='utf-8'))
 d['code']=common(d['code']).replace('predeclared kernel, late-drop and terminal directions; only candidates admitted by measured live opportunities','predeclared independent assignment handoff, own immediate delivery and endpoint horizon ablations; candidates admitted by public live opportunities and actual selected-target inventory acknowledgement')
 for key in list(d['payload']):
  if key=='version':d['payload'][key]=v
  elif key.endswith(('.py','.json')):
   s=common(base64.b64decode(d['payload'][key]).decode())
   if key.endswith('.py'):ast.parse(s)
   d['payload'][key]=base64.b64encode(s.encode()).decode()
 ast.parse(d['code']);p=F/'operators'/v/(name+'.json');p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists()
 b=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode();p.write_bytes(b);key=str(p.relative_to(F)).replace('\\','/');bundle[key]=base64.b64encode(b).decode();manifest[key]=hashlib.sha256(b).hexdigest()
code=r'''
from pathlib import Path
import json,sys,base64,hashlib
F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F17_assignment_epoch_and_consumers_20261027');d=json.load(sys.stdin);v=d['version'];out={}
assert not(F/('OPERATOR_SHA_'+v+'.json')).exists()
for name,b in d['bundle'].items():
 p=F/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(base64.b64decode(b));out[name]=hashlib.sha256(p.read_bytes()).hexdigest()
(F/('OPERATOR_SHA_'+v+'.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
'''
r=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps({'version':v,'bundle':bundle}).encode());assert json.loads(r)==manifest
p=F/('OPERATOR_SHA_'+v+'.json');assert not p.exists();p.write_bytes(r)
for name in ['client_verify_finished_cohort.py','summarize_performance.py','review_pair.py','collect_finished.py','run_operator.py']:
 p=F/name
 if p.exists():continue
 s=(O/name).read_text(encoding='utf-8').replace(O.name,F.name).replace('f12pair_','f17pair_').replace('F12','F17').replace('M01','R01').replace('M02','R02').replace('M03','R03')
 if name=='run_operator.py':s=s.replace("assert v=='R01'","assert v in ['R01','R02','R03']")
 ast.parse(s);p.write_text(s,encoding='utf-8')
p=F/'read_perf_live.py'
if not p.exists():
 s=(O/'read_live.py').read_text(encoding='utf-8').replace(O.name,F.name);ast.parse(s);p.write_text(s,encoding='utf-8')
print('SHA-bound one-use performance operations prepared; review/source/qualification gates still required, no full-five game started')
