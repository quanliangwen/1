"""Own received report diagnostics; never mutates an original plan or command."""
import json
import numpy as np


def _emit(controller, tag, step, peer, inventory, report, old_plan, target):
    seen=getattr(controller,'_f17_epoch_logged',None)
    if seen is None:seen=set();controller._f17_epoch_logged=seen
    key=(tag,int(peer),int(report[3]),int(old_plan[0]))
    if key in seen or len(seen)>=32:return
    seen.add(key)
    evidence=controller._assignment_epochs.records[(int(peer),int(report[3]))]
    print('['+tag+']',json.dumps({'actor':int(controller.identifier or 0),'step':int(step),
          'owner':int(peer),'inventory':int(inventory),'epoch_inventory':evidence[0],
          'since':int(report[3]),'report_ts':int(report[0]),'plan_epoch':int(old_plan[0]),
          'target':np.asarray(target,float).tolist()},separators=(',',':')),flush=True)


def observe_release(controller,step,peer,inventory,report,old_plan):
    if not controller._assignment_epochs.completion_only(peer,report,step):return
    if old_plan is None or not 0<=step-old_plan[0]<controller.PLAN_FRESH_STEPS:return
    assignment=old_plan[2].get(peer)
    if assignment is None:return
    initial,goals=assignment;index=max(0,int(initial)-int(inventory))
    if index>=len(goals):return
    target=np.asarray(goals[index],float)
    if target.shape!=(2,) or not np.isfinite(target).all() or controller._point_conflicts_with_drop(target):return
    _emit(controller,'F17_EPOCH_OPPORTUNITY',step,peer,inventory,report,old_plan,target)


def log_kept_suffix(controller,step,peer,inventory,report,old_plan,target):
    _emit(controller,'F17_SUFFIX_KEPT',step,peer,inventory,report,old_plan,target)
