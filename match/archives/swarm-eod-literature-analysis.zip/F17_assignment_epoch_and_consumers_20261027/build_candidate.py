from pathlib import Path
import sys,json,base64,subprocess,shlex,ast
from epoch_integration import integrate_epoch_reports,add_production_completion_rule
F=Path(__file__).resolve().parent;O=F.parent/'F16_measured_layout_frontier_20261027';P=F.parent/'F13_completion_joint_transport_20261027/parent_source_reference'
v=sys.argv[1];assert v in ['R01','R02','R03']
admission=json.loads((F/'DIRECTION_ADMISSION.json').read_text(encoding='utf-8'));assert admission['gates'][v]
assets={}
if v=='R01':
 assets['fleet_mission.py']=add_production_completion_rule(integrate_epoch_reports((P/'fleet_mission.py').read_text(encoding='utf-8')))
 for n in ['assignment_epochs.py','epoch_observer.py']:assets[n]=(F/n).read_text(encoding='utf-8')
elif v=='R02':
 s=(P/'trust_region_cover.py').read_text(encoding='utf-8');marker='trust_radius_ratio=TRUST_RADIUS_RATIO,_prepared=None):';assert s.count(marker)==1
 s=s.replace(marker,'trust_radius_ratio=TRUST_RADIUS_RATIO,_prepared=None,_context_out=None):')
 marker='    pm=GeometryPlanningMemory(memory) if _prepared is None else _prepared\n';assert s.count(marker)==1;s=s.replace(marker,marker+'    if _context_out is not None: _context_out.append(pm)\n');assets['trust_region_cover.py']=s
 s=(P/'team_coverage_lns.py').read_text(encoding='utf-8');marker='    prepared=None\n';assert s.count(marker)==1;s=s.replace(marker,'    _full_budget=travel_budget\n    prepared=None\n')
 marker='    return refine_trust_region(memory,agents,drops,radius,base,travel_budget=travel_budget,forbidden_points=forbidden_points,forbidden_mask=forbidden_mask,_prepared=prepared)';assert s.count(marker)==1
 s=s.replace(marker,'''    _context=[]
    result=refine_trust_region(memory,agents,drops,radius,base,travel_budget=travel_budget,forbidden_points=forbidden_points,forbidden_mask=forbidden_mask,_prepared=prepared,_context_out=_context)
    from swarm_rescue.solutions.layout_preference import apply_preference
    return apply_preference(memory,agents,drops,radius,result,_full_budget,travel_budget,reserved_prefixes,
                            forbidden_points,forbidden_mask,_context[-1] if _context else prepared)''');assets['team_coverage_lns.py']=s
 s=(P/'my_drone_eval.py').read_text(encoding='utf-8');marker='    CLEAR_NONWALL_HITS=True';assert s.count(marker)==1
 s=s.replace(marker,marker+'''
    LAYOUT_PREFERENCE='delivery'
    def _build_fleet_plan(self,step):
        self.memory._layout_preference_objective=self.LAYOUT_PREFERENCE
        self.memory._layout_preference_rally=None if self.rally is None else self.rally.copy()
        return super()._build_fleet_plan(step)
''');assets['my_drone_eval.py']=s
 for n in ['layout_frontier.py','sensed_layout_context.py']:assets[n]=(F/n).read_text(encoding='utf-8')
 s=(O/'layout_preference.py').read_text(encoding='utf-8').replace('F16','F17')
 s=s.replace("'memory':memory,'agents':agents", "'memory':memory,'immediate_owner':int(getattr(memory,'identifier',0)),'agents':agents")
 assets['layout_preference.py']=s
else:
 s=(P/'fleet_endpoint_repair.py').read_text(encoding='utf-8')
 marker='            plans=plan_team_coverage(self.memory,{own:(self.pose,int(self.carried_bombs_count()))},';assert s.count(marker)==1
 s=s.replace(marker,'''            repair_stock=int(self.carried_bombs_count())
            self._f17_repair_request=(int(step),repair_stock,min(1,repair_stock))
            plans=plan_team_coverage(self.memory,{own:(self.pose,min(1,repair_stock))},''')
 assets['fleet_endpoint_repair.py']=s
for s in assets.values():ast.parse(s)
payload={'version':v,'assets':{n:base64.b64encode(s.encode()).decode() for n,s in assets.items()}}
code=r"""
from pathlib import Path
import sys,json,base64,hashlib,ast,shutil,zipfile,yaml,datetime
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F17_assignment_epoch_and_consumers_20261027'
d=json.load(sys.stdin);v=d['version'];versions={'R01':21,'R02':22,'R03':23};objectives={'R01':'handoff','R02':'delivery','R03':'horizon_one'}
A=json.loads((F/'DIRECTION_ADMISSION.json').read_text());assert v in A['admitted_order'] and A['gates'][v]
assert not(F/'FIRST_NATIVE_ERROR.json').exists() and not(F/'STOP_REQUESTED').exists()
assert json.loads((F/'PARENT_M04_DIAG/CLIENT_FIRST_RAW_REVIEW.json').read_text())['valid']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();P=json.loads((F/'PREDECLARATION.json').read_text())['parent']
assert sha(Path(P['zip']))==P['zip_sha256'] and {p.name:sha(p) for p in (Path(P['path'])/'source').iterdir() if p.is_file()}==P['source_files']
assert json.loads((F/'observer_qualification/QUALIFICATION_RESULT.json').read_text())['status']=='PASS'
G=F/v;assert not G.exists();G.mkdir();S=G/'source';shutil.copytree(Path(P['path'])/'source',S)
for n,b in d['assets'].items():(S/n).write_bytes(base64.b64decode(b))
for p in S.glob('*.py'):ast.parse(p.read_text())
info=yaml.safe_load((S/'team_info.yml').read_text());assert type(info['team_number']) is int and info['team_number']==615
assert {s.strip() for s in (S/'req.txt').read_text().splitlines() if s.strip()}=={'numpy==1.26.4','pandas==2.2.3','opencv-contrib-python==4.11.0.86'}
files={p.name:sha(p) for p in S.iterdir() if p.is_file()};changed=sorted(n for n in files if n not in P['source_files'] or files[n]!=P['source_files'][n])
assert changed==sorted(d['assets'])
assert not any(n.startswith(('diagnostic_','frontier_observer','helper_test','observer_test')) for n in files)
z=G/('team615_red_v%02d.zip'%versions[v]);assert not z.exists()
with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED) as out:
 for p in sorted(S.iterdir()):out.write(p,p.name)
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':v,'path':str(G),'zip':str(z),'zip_sha256':sha(z),'source_files':files,'changed_files':changed,
         'parent_id':'K01','parent_zip_sha256':P['zip_sha256'],'declaration_sha256':sha(F/'PREDECLARATION.json'),'admission_sha256':sha(F/'DIRECTION_ADMISSION.json'),
         'objective':objectives[v],'release_status':'INTERNAL_NOT_RELEASED','scope':json.loads((F/'PREDECLARATION.json').read_text())[v+'_design']}
(G/'BUILD.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
"""
r=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps(payload).encode())
p=F/(v+'_BUILD.json');assert not p.exists();p.write_bytes(r);d=json.loads(r);print(json.dumps({k:d[k] for k in ['candidate_id','objective','zip_sha256','changed_files','release_status']}))
