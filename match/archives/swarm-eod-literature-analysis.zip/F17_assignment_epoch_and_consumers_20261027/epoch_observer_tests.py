from swarm_rescue.solutions.assignment_epochs import AssignmentEpochCache
from swarm_rescue.solutions import fleet_mission as observed, fleet_endpoint_repair as endpoint
from epoch_integration import integrate_epoch_reports,add_production_completion_rule
oldfleet=types.ModuleType('canonical_fleet');exec(compile((P/'fleet_mission.py').read_text(),str(P/'fleet_mission.py'),'exec'),oldfleet.__dict__)
newfleet=types.ModuleType('completion_fleet');source=add_production_completion_rule(integrate_epoch_reports((P/'fleet_mission.py').read_text()))
exec(compile(source,'synthetic_completion_fleet','exec'),newfleet.__dict__)
class FakeBase:
 def __init__(self,**kwargs):self.team_size=5;self.base_message_calls=0
 def _messages(self):self.base_message_calls+=1
 def carried_bombs_count(self):return self.stock
def fleet_fixture(mixin):
 class Fake(mixin,FakeBase):
  def _map_quality(self):return (.5,20)
  def _point_conflicts_with_drop(self,p):return self.conflict
 f=Fake();f.identifier=0;f.elapsed_timestep=200;f.stock=2;f.pose=np.zeros(2);f.conflict=False
 f.communicator=types.SimpleNamespace(received_messages=[]);f.drop_records={};f.memory=types.SimpleNamespace(CELL=16.)
 return f
a=fleet_fixture(oldfleet.FleetCoverageMixin);b=fleet_fixture(observed.FleetCoverageMixin)
a.assignment_goal=b.assignment_goal=np.array([5.,7.]);a.assignment_since=b.assignment_since=150
ra=a._own_assignment_report(200);rb=b._own_assignment_report(200)
check('wire_tuple4_unchanged',len(ra)==len(rb)==4 and ra[:2]==rb[:2] and np.array_equal(ra[2],rb[2]) and ra[3]==rb[3])
check('own_goal_epoch_captured',b._assignment_epochs.records[(0,150)][0]==2)
msg={'kind':'greedy-map-v1','id':1,'assignment_reports':{1:(200,2,np.array([50.,0.]),150)}}
for f in [a,b]:f.communicator.received_messages=[(None,msg)];f._messages()
check('received_goal_epoch_captured',b._assignment_epochs.records[(1,150)][0]==2)
check('original_messages_once',a.base_message_calls==b.base_message_calls==1)
msg={'kind':'greedy-map-v1','id':1,'assignment_reports':{1:(220,1,None,150)}}
for f in [a,b]:
 f.elapsed_timestep=220;f.communicator.received_messages=[(None,msg)];f._messages()
 f.fleet_plan=(190,0,{1:(2,[np.array([50.,0.]),np.array([150.,0.])])})
active={1:(np.array([50.,0.]),1)}
check('readonly_original_release_result',a._reserved_first_goals(220,active)==b._reserved_first_goals(220,active)=={})
check('readonly_opportunity_logged',len(b._f17_epoch_logged)==1)
check('readonly_plan_unchanged',np.array_equal(b.fleet_plan[2][1][1][1],[150.,0.]))
c=fleet_fixture(newfleet.FleetCoverageMixin);c._assignment_epochs=b._assignment_epochs
c.fleet_plan=b.fleet_plan;c.assignment_reports=dict(b.assignment_reports)
r=c._reserved_first_goals(220,active)
check('production_keeps_only_confirmed_completion_suffix',set(r)=={1} and np.array_equal(r[1],[150.,0.]))
c.assignment_reports[1]=(220,2,None,150)
check('production_same_inventory_release_preserved',c._reserved_first_goals(220,{1:(np.zeros(2),2)})=={})
c.assignment_reports[1]=(220,1,None,201)
check('production_unknown_new_epoch_release_preserved',c._reserved_first_goals(220,active)=={})
c.assignment_reports[1]=(220,1,None,150);c.conflict=True
check('known_drop_conflict_still_rejected',c._reserved_first_goals(220,active)=={})
c.conflict=False;c.fleet_plan=(0,0,c.fleet_plan[2])
check('stale_plan_not_revived',c._reserved_first_goals(250,active)=={})
# New acknowledged goal is explicitly rejected at unchanged inventory: original release.
c.fleet_plan=b.fleet_plan;c._assignment_epochs.remember(1,(215,1,(150.,0.),210),215)
c.assignment_reports[1]=(220,1,None,210)
check('explicit_next_goal_rejection_preserved',c._reserved_first_goals(220,active)=={})
before=dict(b._assignment_epochs.records)
msg={'kind':'greedy-map-v1','id':1,'assignment_reports':{1:(219,7,np.array([0.,0.]),200),2:(221,2,np.zeros(2),210)}}
b.communicator.received_messages=[(None,msg)];b._messages()
check('unaccepted_reports_never_cached',b._assignment_epochs.records==before)
original=endpoint._original_plan_team_coverage
try:
 payload={0:[np.array([100.,0.]),np.array([200.,0.])]}
 endpoint._original_plan_team_coverage=lambda *a,**k:payload
 mem=types.SimpleNamespace(identifier=0,step=700)
 result=endpoint.plan_team_coverage(mem,{0:(np.zeros(2),2)},[],40.)
 check('endpoint_observer_return_identity',result is payload)
 check('actual_multitarget_request_logged',mem._f17_endpoint_opportunity_count==1)
 endpoint.plan_team_coverage(mem,{0:(np.zeros(2),1)},[],40.)
 check('single_target_request_not_opportunity',mem._f17_endpoint_opportunity_count==1)
finally:endpoint._original_plan_team_coverage=original
