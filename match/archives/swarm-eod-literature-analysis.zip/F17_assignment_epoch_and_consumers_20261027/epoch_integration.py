"""Source transforms checked against canonical K01; no game input files."""
def integrate_epoch_reports(source):
    marker='from swarm_rescue.solutions.team_coverage_lns import plan_team_coverage_lns\n'
    assert source.count(marker)==1
    source=source.replace(marker,marker+'from swarm_rescue.solutions.assignment_epochs import AssignmentEpochCache\n')
    marker='        self.assignment_reports = {}\n';assert source.count(marker)==1
    source=source.replace(marker,marker+'        self._assignment_epochs = AssignmentEpochCache(self.team_size, self.STATE_FRESH_STEPS, self.GOAL_LEASE_STEPS)\n')
    marker='        return (int(step), int(self.carried_bombs_count()), goal, int(self.assignment_since))'
    assert source.count(marker)==1
    source=source.replace(marker,'''        report = (int(step), int(self.carried_bombs_count()), goal, int(self.assignment_since))
        self._assignment_epochs.remember(int(self.identifier or 0), report, step)
        return report''')
    marker='                    self.assignment_reports[peer]=(int(ts),int(inventory),goal,int(since))\n'
    assert source.count(marker)==1
    source=source.replace(marker,marker+'                    self._assignment_epochs.remember(peer,self.assignment_reports[peer],step)\n')
    return source


def add_readonly_release_observer(source):
    marker='                if (step-ts<self.STATE_FRESH_STEPS and reported_inventory==inventory and\n'
    assert source.count(marker)==1
    source=source.replace(marker,'''                if released:
                    from swarm_rescue.solutions.epoch_observer import observe_release
                    observe_release(self,step,peer,inventory,report,old_plan)
'''+marker)
    return source


def add_production_completion_rule(source):
    marker='            released=False\n';assert source.count(marker)==1
    source=source.replace(marker,marker+'            completion_null=False\n')
    marker='                if (step-ts<self.STATE_FRESH_STEPS and reported_inventory==inventory and\n'
    assert source.count(marker)==1
    source=source.replace(marker,'''                if released and self._assignment_epochs.completion_only(peer,report,step):
                    released=False
                    completion_null=True
'''+marker)
    marker='                reserved[peer]=target\n';assert source.count(marker)==1
    source=source.replace(marker,marker+'''                if completion_null:
                    from swarm_rescue.solutions.epoch_observer import log_kept_suffix
                    log_kept_suffix(self,step,peer,inventory,report,old_plan,target)
''')
    return source
