    import zipfile,yaml
    with zipfile.ZipFile(build['zip']) as archive:
        payload_files={n:hashlib.sha256(archive.read(n)).hexdigest() for n in archive.namelist()}
        info=yaml.safe_load(archive.read('team_info.yml'))
        check('actual_zip_team_integer615',type(info['team_number']) is int and info['team_number']==615)
        check('actual_zip_pins',{s.strip() for s in archive.read('req.txt').decode().splitlines() if s.strip()}=={'numpy==1.26.4','pandas==2.2.3','opencv-contrib-python==4.11.0.86'})
        check('actual_zip_source_manifest',payload_files==build['source_files'] and hashlib.sha256(Path(build['zip']).read_bytes()).hexdigest()==build['zip_sha256'])
        check('fresh_extraction_exact_payload',all(hashlib.sha256((W/'req.txt' if n=='req.txt' else W/'src/swarm_rescue/solutions'/n).read_bytes()).hexdigest()==h for n,h in payload_files.items()))
