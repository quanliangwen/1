from pathlib import Path
import json,sys,collections
F=Path(__file__).resolve().parent
out={'scope':'Descriptive own scalar telemetry only. Sampled ticks are not exact event counts. No partial-score ranking, no arrays loaded.','jobs':{}}
for name in sys.argv[1:]:
 G=F/name;assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'))['valid']
 E=json.loads((G/'EVENTS.json').read_text(encoding='utf-8'));R=json.loads((G/'RESULT.json').read_text(encoding='utf-8'));owners={}
 ticks=E.get('F17_DIAG_TICK',[])
 for owner in range(5):
  records=sorted([x for x in ticks if x['owner']==owner],key=lambda x:x['step'])
  if not records:continue
  ready=[x for x in records if x['decision_snapshot']['coverage_ready']]
  goals=[x for x in records if x.get('placement_goal') is not None]
  defers=[x for x in records if x.get('commitment_policy',{}).get('defer')]
  last=records[-1];snap=last['decision_snapshot']
  first_attempt={}
  for x in records:
   attempts=x.get('layout_preference',{}).get('attempts',0)
   if attempts and attempts not in first_attempt:
    first_attempt[attempts]={'step_at_first_sample':x['step'],'stock':x['stock'],'wall_left':x['wall_left'],'own_plan':x['decision_snapshot']['fleet_plan'],'result':x['layout_preference']}
  owners[owner]={'first_ready_sample':ready[0]['step'] if ready else None,'first_placement_goal_sample':goals[0]['step'] if goals else None,
   'commitment_defer_samples':len(defers),'stock_positive_samples':sum(x['stock']>0 for x in records),
   'last':{'step':last['step'],'stock':last['stock'],'known_free_fraction':last['known_free_fraction'],'certificates':last['completion_origins'],
   'coverage_model':snap['coverage_model'],'own_plan':snap['fleet_plan'],'assignment_goal':last['assignment_goal'],'costs':last['costs']},'preference_attempts_first_samples':first_attempt}
 out['jobs'][name]={'placed':[R['row']['placed'],R['row']['expected']],'steps':R['row']['timestep'],'owners':owners}
p=F/('EXECUTION_TRACE_'+'_'.join(sys.argv[1:])+'.json');assert not p.exists();p.write_bytes((json.dumps(out,indent=2)+'\n').encode())
for name,d in out['jobs'].items():
 print(name,json.dumps({'placed':d['placed'],'owners':{k:{'first_ready':v['first_ready_sample'],'first_placement_goal':v['first_placement_goal_sample'],'defer_samples':v['commitment_defer_samples'],'last_stock':v['last']['stock'],'attempts':list(v['preference_attempts_first_samples'])} for k,v in d['owners'].items()}}))
