from pathlib import Path
import subprocess,shlex
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import json,hashlib,datetime,fcntl
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F17_assignment_epoch_and_consumers_20261027'
assert not(F/'FINAL_RESULT.json').exists() and not(F/'FIRST_NATIVE_ERROR.json').exists()
a=json.loads((R/'solver_study/heuristic_20261016.json').read_text());assert not a.get('active_processes') and not a.get('current_formal_active')
lock=(R/'solver_study/serial_evaluation.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
A=json.loads((F/'DIRECTION_ADMISSION.json').read_text());assert not A['gates']['R01'] and not(F/'R01').exists()
reviews={};raw=0
for name in ['PARENT_M04','R02','R03']:
 G=F/(name+'_DIAG');s=json.loads((G/'STATUS.json').read_text());assert s['status'].endswith('DIAGNOSTIC_COMPLETE_AWAIT_ANALYSIS')
 p=Path('/proc')/str(s['pid'])/'stat';assert not p.exists() or p.read_text().split()[2]=='Z'
 client=json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text());assert client['valid'];raw+=client['raw_files_verified']
 if name.startswith('R'):
  review=json.loads((G/'MECHANISM_REVIEW.json').read_text());assert review['start_five_map_now'] is False
  assert not(F/(name+'_PERF')).exists();reviews[name]={k:review[k] for k in ['applications','adopted_applications','executed_and_acknowledged_applications','stock','source_zip_sha256']}
  B=json.loads((F/name/'BUILD.json').read_text());assert hashlib.sha256(Path(B['zip']).read_bytes()).hexdigest()==B['zip_sha256']
  assert json.loads((F/name/'CONTRACT_RESULT.json').read_text())['status']=='PASS' and json.loads((F/name/'STRICT_PACKAGE_GUARD.json').read_text())['status']=='PASS'
assert json.loads((F/'attempt_consumption_audit/FIRST_RESULT.json').read_text())['status']=='PASS'
registry=json.loads((R/'solver_study/unseeded_five_once_registry.json').read_text());assert len(registry)==117
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'CLOSED_NO_EXECUTED_MECHANISM_NO_FULL_FIVE','pid':None,'parent_retained':'K01',
 'RED_only_rounds':3,'five_map_groups':0,'actual_native_failures':0,'raw_first_verified':raw,'original_once_registry_count':len(registry),
 'R01':'No qualified actual parent epoch-completion suffix opportunity; no source candidate or native candidate run.',
 'candidate_reviews':reviews,'formal_package_checks':'R02actualZIP114contracts,R03actualZIP95contracts, both ZIP-boundrealABI+strictguardPASS; internal only, official container unverified.',
 'observed_score_winner':None,'unlaunched_performance_operations':[],'reason':'R02 no preference applied; R03 no qualifying successful quota-one repair selected/acknowledged under stock>=2. Both10of10 not attribution or five-map score evidence.',
 'new_fixed_state_finding':'Current R02 can exhaust two attempts on ineligible reserved-owner calls, then skip later eligible own first target. Four checks PASS, production/current game unchanged, not actual-trajectory causal proof.',
 'next_analysis':'Prioritize exact same-call fleet distance-field/view duplication profiling (own fleet_chain occupies substantial logged control time) and eligibility-before-attempt correction. Fallback navigation only~2percentcontrol, no sampled commitment defers in three recent runs; lower priority. No claim speed alone improves scores: M01 previously failed fullfive.'}
(F/'FINAL_RESULT.json').write_text(json.dumps(d,indent=2)+'\n');(F/'STATUS.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
'''
r=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)])
assert not(F/'FINAL_RESULT.json').exists();(F/'FINAL_RESULT.json').write_bytes(r);print(r.decode())
