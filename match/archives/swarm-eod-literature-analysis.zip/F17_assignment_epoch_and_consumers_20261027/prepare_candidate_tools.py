from pathlib import Path
import ast
F=Path(__file__).resolve().parent;O=F.parent/'F16_measured_layout_frontier_20261027'
def write(n,s):
 p=F/n;assert not p.exists();ast.parse(s);p.write_bytes(s.encode())
for n in ['qualification_ABI_checks.py','ABI_receipt_fragment.py']:
 # These are indented fragments, not standalone syntax units.
 p=F/n;assert not p.exists();p.write_bytes((O/n).read_bytes())
s=(O/'candidate_contracts.py').read_text(encoding='utf-8').replace('F16','F17').replace('f16','f17')
s=s.replace("for mode in ['transport','delivery','occlusion']:","for mode in ['delivery']:").replace('m.identifier=0;m.step=1000','m.identifier=2 if mode==\'delivery\' else 7;m.step=1000')
p=F/'candidate_preference_contracts.py';assert not p.exists();p.write_bytes(s.encode())
common='''    import zipfile,yaml
    with zipfile.ZipFile(build['zip']) as archive:
        payload_files={n:hashlib.sha256(archive.read(n)).hexdigest() for n in archive.namelist()}
        info=yaml.safe_load(archive.read('team_info.yml'))
        check('actual_zip_team_integer615',type(info['team_number']) is int and info['team_number']==615)
        check('actual_zip_pins',{s.strip() for s in archive.read('req.txt').decode().splitlines() if s.strip()}=={'numpy==1.26.4','pandas==2.2.3','opencv-contrib-python==4.11.0.86'})
        check('actual_zip_source_manifest',payload_files==build['source_files'] and hashlib.sha256(Path(build['zip']).read_bytes()).hexdigest()==build['zip_sha256'])
        check('fresh_extraction_exact_payload',all(hashlib.sha256((W/'req.txt' if n=='req.txt' else W/'src/swarm_rescue/solutions'/n).read_bytes()).hexdigest()==h for n,h in payload_files.items()))
'''
p=F/'candidate_common_contracts.py';assert not p.exists();p.write_bytes(common.encode())
s=(O/'qualify.py').read_text(encoding='utf-8').replace(O.name,F.name).replace("['Q01','Q02','Q03']","['R01','R02','R03']")
s=s.replace("(F/'candidate_contracts.py').read_text(encoding='utf-8')", "(F/({'R01':'candidate_epoch_contracts.py','R02':'candidate_preference_contracts.py','R03':'candidate_horizon_contracts.py'}[v])).read_text(encoding='utf-8')+'\\n'+(F/'candidate_common_contracts.py').read_text(encoding='utf-8')")
write('qualify.py',s)
for n in ['collect_finished.py','client_verify_finished_cohort.py','review_pair.py','run_operator.py','read_perf_live.py','summarize_performance.py']:
 s=(O/n).read_text(encoding='utf-8').replace(O.name,F.name).replace('F16','F17').replace('f16','f17').replace('Q01','R01').replace('Q02','R02').replace('Q03','R03')
 write(n,s)
