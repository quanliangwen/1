from pathlib import Path
import json,base64,hashlib,subprocess,ast
F=Path(__file__).resolve().parent;O=F.parent/'F16_measured_layout_frontier_20261027'
def write(n,s):
 p=F/n;assert not p.exists();ast.parse(s);p.write_bytes(s.encode())
code="from pathlib import Path;import json,base64,hashlib;Q=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F17_assignment_epoch_and_consumers_20261027/observer_qualification');p=Q/'source/diagnostic_mixin.py';b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==json.loads((Q/'SOURCE_BINDING.json').read_text())['observer_source_files'][p.name];print(base64.b64encode(b).decode())"
raw=base64.b64decode(subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python','-'],input=code.encode()))
write('qualified_diagnostic_mixin_reference.py',raw.decode())
tree=ast.parse(raw.decode());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='DiagnosticMixin')
s=(O/'mechanism_observer_extensions.py').read_text(encoding='utf-8').replace('F16','F17')
s+='''
    def _reject_assignment(self,step,point):
        self._f17_repair_request=None
        result=super()._reject_assignment(step,point)
        request=getattr(self,'_f17_repair_request',None)
        repair=getattr(self,'_endpoint_repair_route',None)
        if request is not None and request[0]==step and request[1]>=2 and request[2]==1 and repair is not None:
            import json
            print('[F17_REPAIR_TARGET]',json.dumps({'owner':int(self.identifier or 0),'step':int(step),
                  'stock':int(request[1]),'quota':int(request[2]),'target':np.asarray(repair[1],float).tolist()},separators=(',',':')),flush=True)
        return result
'''
methods=ast.parse(s).body[0].body;names={n.name for n in methods if isinstance(n,ast.FunctionDef)}
cls.body=[n for n in cls.body if not(isinstance(n,ast.FunctionDef) and n.name in names)]+methods
fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_diag_state')
assert isinstance(fn.body[-1],ast.Return)
fn.body[-1:-1]=ast.parse("state['layout_preference'] = dict(getattr(self.memory,'layout_preference_diagnostics',{}))").body
source=ast.unparse(tree)+'\n';write('mechanism_diagnostic_mixin.py',source)
p=F/'MECHANISM_OBSERVER_BINDING.json';assert not p.exists();p.write_bytes((json.dumps({'qualified_base_sha256':hashlib.sha256(raw).hexdigest(),'mechanism_mixin_sha256':hashlib.sha256(source.encode()).hexdigest(),'scope':'Readonly own target-selection/inventory-ACK and quota-one repair evidence. Original methods once, no production ZIP changes.'},indent=2)+'\n').encode())
s=(O/'mechanism_observer_tests.py').read_text(encoding='utf-8').replace('F16','F17')
s=s.replace("check('production_objective_bound',BaseParent.LAYOUT_PREFERENCE==json.loads((Q/'PRODUCTION_BINDING.json').read_text())['objective'])", "check('production_objective_bound',getattr(BaseParent,'LAYOUT_PREFERENCE',None)==('delivery' if json.loads((Q/'PRODUCTION_BINDING.json').read_text())['objective']=='delivery' else None))")
marker=" report.update(status='PASS',scope=";i=s.index(marker)
extra=''' class RepairParent:
  def _reject_assignment(self,step,point):
   self.reject_calls+=1;self._f17_repair_request=(step,2,1);self._endpoint_repair_route=([point.copy()],point.copy());return 'original_reject_result'
 class RepairProbe(DiagnosticMixin,RepairParent):pass
 d=object.__new__(RepairProbe);d.identifier=2;d.reject_calls=0
 out=io.StringIO()
 with contextlib.redirect_stdout(out):r=d._reject_assignment(500,np.array([12.,24.]))
 check('repair_original_once_and_return',r=='original_reject_result' and d.reject_calls==1)
 event=json.loads(out.getvalue().splitlines()[0][len('[F17_REPAIR_TARGET] '):])
 check('repair_actual_quota_evidence',event['stock']==2 and event['quota']==1 and event['target']==[12.,24.])
'''
s=s[:i]+extra+s[i:];write('mechanism_observer_tests.py',s)
s=(O/'qualify_mechanism_observer_revision1.py').read_text(encoding='utf-8').replace(O.name,F.name).replace('F16','F17').replace('Q01','R01').replace('Q02','R02').replace('Q03','R03')
s=s.replace('mechanism_diagnostic_mixin_revision1.py','mechanism_diagnostic_mixin.py').replace('MECHANISM_OBSERVER_BINDING_REV1.json','MECHANISM_OBSERVER_BINDING.json').replace('_mechanism_observer_revision1_console.txt','_mechanism_observer_console.txt')
write('qualify_mechanism_observer.py',s)
s=(O/'stage_candidate_diagnostic.py').read_text(encoding='utf-8').replace(O.name,F.name).replace('F16','F17').replace('f16','f17').replace('Q01','R01').replace('Q02','R02').replace('Q03','R03')
s=s.replace('"\'F17_FRONTIER_ADVISOR\']"', '"\'F17_FRONTIER_ADVISOR\',\'F17_EPOCH_OPPORTUNITY\',\'F17_ENDPOINT_OPPORTUNITY\']"')
s=s.replace("'F17_PREFERENCE_APPLIED','F17_TARGET_SELECTED','F17_DROP_ACK']", "'F17_PREFERENCE_APPLIED','F17_TARGET_SELECTED','F17_DROP_ACK','F17_SUFFIX_KEPT','F17_REPAIR_TARGET']")
write('stage_candidate_diagnostic.py',s)
