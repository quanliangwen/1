from pathlib import Path
import sys,json,types,time,traceback,ast
Q=Path(__file__).resolve().parent;W=Q/'workspace';F=Q.parent
report={'status':'STARTED','checks':[],'game_rounds':0}
def check(n,v):
 assert v,n
 report['checks'].append(n)
try:
 sys.path.insert(0,str(W/'src'))
 import numpy as np,cv2,pandas
 from swarm_rescue.solutions.greedy_mapping import MapMemory
 from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
 from swarm_rescue.solutions import trust_region_cover as trust,team_coverage_lns as current
 from swarm_rescue.solutions.frontier_observer import observe_frontier
 from swarm_rescue.solutions.diagnostic_mixin import DiagnosticMixin
 from swarm_rescue.solutions.my_drone_eval import MyDroneEval,BaseParent
 from swarm_rescue.simulation.reporting.team_info import TeamInfo
 from swarm_rescue.launcher import Launcher
 from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
 import numpy.random.mtrand
 check('native_versions',(np.__version__,pandas.__version__,cv2.__version__)==('1.26.4','3.0.6','4.11.0'))
 check('actual_mtrand',np.isfinite(np.random.RandomState(615).normal(size=8)).all())
 check('team615_integer',type(TeamInfo().team_number) is int and TeamInfo().team_number==615)
 check('actual_payload',Path(current.__file__).resolve().is_relative_to(W))
 check('diagnostic_factory',MyDroneEval.__mro__[1].__name__=='DiagnosticMixin')
 check('placement_ancestor_unchanged',next(c.__name__ for c in MyDroneEval.__mro__ if '_maybe_place' in c.__dict__)=='ActiveCoverageMixin')
 parent=json.loads((F/'PREDECLARATION.json').read_text())['parent'];P=Path(parent['path'])/'source'
 oldtree=ast.parse((P/'trust_region_cover.py').read_text());newtree=ast.parse(Path(trust.__file__).read_text())
 fn=next(n for n in newtree.body if isinstance(n,ast.FunctionDef) and n.name=='refine_trust_region')
 fn.body=[n for n in fn.body if not(isinstance(n,ast.If) and any(isinstance(v,ast.Attribute) and v.attr=='_f17_live_prepared' for v in ast.walk(n)))]
 check('original_numeric_AST_unchanged',ast.dump(oldtree)==ast.dump(newtree))
 old=types.ModuleType('original_lns_reference');exec(compile((P/'team_coverage_lns.py').read_text(),str(P/'team_coverage_lns.py'),'exec'),old.__dict__)
 def same(a,b):return a.keys()==b.keys() and all(len(a[k])==len(b[k]) and all(np.array_equal(p,q) for p,q in zip(a[k],b[k])) for k in a)
 def fixture(enabled=True,prefix=False):
  m=MapMemory(640,256);m.free[:]=True;m.identifier=2;m.step=1000;m._f17_layout_enabled=enabled
  pm=GeometryPlanningMemory(m);pm._coverage_values_cache=(32.,np.zeros(m.shape,np.float32),np.zeros(m.shape,bool));m._test_pm=pm
  base={2:[m.cell_to_world((5,25)),m.cell_to_world((5,15))]};agents={2:(m.cell_to_world((5,5)),2)}
  prefixes={2:(m.cell_to_world((5,3)),agents[2][0])} if prefix else None
  m._f17_rally=np.zeros(2);return m,pm,base,agents,prefixes
 for label,prefix,cap in [('normal',False,2000.),('prefix',True,2000.),('tight',False,100.)]:
  a,pa,base,agents,pref=fixture(False,prefix);b,pb,baseb,agentsb,prefb=fixture(True,prefix)
  factory=trust.GeometryPlanningMemory;greedy=current._greedy_plan
  try:
   trust.GeometryPlanningMemory=lambda m:m._test_pm
   old._greedy_plan=lambda *args,**kw:{k:[p.copy() for p in ps] for k,ps in base.items()}
   current._greedy_plan=lambda *args,**kw:{k:[p.copy() for p in ps] for k,ps in baseb.items()}
   ra=old.plan_team_coverage_lns(a,agents,[],32.,travel_budget=cap,reserved_prefixes=pref)
   rb=current.plan_team_coverage_lns(b,agentsb,[],32.,travel_budget=cap,reserved_prefixes=prefb)
  finally:trust.GeometryPlanningMemory=factory;current._greedy_plan=greedy
  check('original_result_'+label,same(ra,rb));check('original_counters_'+label,a.trust_region_diagnostics==b.trust_region_diagnostics)
  check('original_arrays_'+label,all(np.array_equal(getattr(a,k),getattr(b,k)) for k in ['hits','free','visits']))
  check('temporary_context_removed_'+label,'_f17_live_prepared' not in vars(b))
 check('live_callback_executed',b._f17_frontier_count==1)
 # Exercise a positive measured tradeoff through the actual observer callback.
 m=MapMemory(256,128);m.free[:]=True;m.step=1000;m.identifier=7;m._f17_layout_enabled=True
 pm=GeometryPlanningMemory(m);values=np.zeros(m.shape,np.float32);values[1,8]=1.;values[3,12]=.03
 pm._coverage_values_cache=(64.,values,np.zeros(m.shape,bool));allowed=np.zeros(m.shape,bool);allowed[3,10]=allowed[3,6]=True
 m.nonwall_mask=np.zeros(m.hit_shape,bool);m.nonwall_mask[4*8:5*8,14*8:15*8]=True
 base={7:[m.cell_to_world((3,10))]};agents={7:(m.cell_to_world((4,8)),1)};before=base[7][0].copy()
 observe_frontier(m,agents,[],64.,base,{7:100.},{7:100.},None,(),~allowed,pm)
 check('positive_callback_is_readonly',np.array_equal(before,base[7][0]) and m._f17_frontier_count==1)
 observe_frontier(m,agents,[],64.,base,{7:100.},{7:100.},None,(),~allowed,pm)
 check('same_step_probe_not_repeated',m._f17_frontier_count==1)
 class Parent:
  def control(self):self.control_calls+=1;return self.command
  def _build_fleet_plan(self,step):self.build_calls+=1;return 'original_build'
 class Probe(DiagnosticMixin,Parent):F17_MODE='FRONTIER'
 d=object.__new__(Probe);d._diag_core_state=lambda:{'owner':0,'step':200,'stock':0};d.fleet_states={0:(200,np.zeros(2),0)}
 d.fleet_plan=None;d.memory=types.SimpleNamespace(exploration_goal=None);d.pose=np.zeros(2);d.rally=np.zeros(2);d.coverage_ready=True
 d._seeking_fusion=False;d._sortie_state='DOCK';d.pending_drop=None;d.coverage_model={};d.completion_certificates={0:180};d.elapsed_timestep=200;d.STATE_FRESH_STEPS=120
 d.team_size=3;d._diag_first_complete=None;d._diag_costs={};d._diag_last_tick=-1000;d._diag_complete_seen=False;d._diag_end_opportunities=0;d.submitted=False
 d.walltime_limit=180.;d.elapsed_walltime=20.;d._remaining_steps=lambda:1000.;d.control_calls=d.build_calls=0
 d.command={'forward':.3,'lateral':-.1,'rotation':0.,'place_bomb':0};command_before=dict(d.command)
 state=d._diag_state();check('actual_telemetry_smoke',state['completion_origins']==[0] and state['decision_snapshot']['sortie_state']=='DOCK')
 r=d.control();check('original_control_return_identity',r is d.command and d.command==command_before and d.control_calls==1)
 r=d._build_fleet_plan(200);check('original_build_once',r=='original_build' and d.build_calls==1)
 check('own_rally_only_context',np.array_equal(d.memory._f17_rally,d.rally) and d.memory._f17_rally is not d.rally)
 from swarm_rescue.solutions.assignment_epochs import AssignmentEpochCache
 from swarm_rescue.solutions import fleet_mission as observed, fleet_endpoint_repair as endpoint
 from epoch_integration import integrate_epoch_reports,add_production_completion_rule
 oldfleet=types.ModuleType('canonical_fleet');exec(compile((P/'fleet_mission.py').read_text(),str(P/'fleet_mission.py'),'exec'),oldfleet.__dict__)
 newfleet=types.ModuleType('completion_fleet');source=add_production_completion_rule(integrate_epoch_reports((P/'fleet_mission.py').read_text()))
 exec(compile(source,'synthetic_completion_fleet','exec'),newfleet.__dict__)
 class FakeBase:
  def __init__(self,**kwargs):self.team_size=5;self.base_message_calls=0
  def _messages(self):self.base_message_calls+=1
  def carried_bombs_count(self):return self.stock
 def fleet_fixture(mixin):
  class Fake(mixin,FakeBase):
   def _map_quality(self):return (.5,20)
   def _point_conflicts_with_drop(self,p):return self.conflict
  f=Fake();f.identifier=0;f.elapsed_timestep=200;f.stock=2;f.pose=np.zeros(2);f.conflict=False
  f.communicator=types.SimpleNamespace(received_messages=[]);f.drop_records={};f.memory=types.SimpleNamespace(CELL=16.)
  return f
 a=fleet_fixture(oldfleet.FleetCoverageMixin);b=fleet_fixture(observed.FleetCoverageMixin)
 a.assignment_goal=b.assignment_goal=np.array([5.,7.]);a.assignment_since=b.assignment_since=150
 ra=a._own_assignment_report(200);rb=b._own_assignment_report(200)
 check('wire_tuple4_unchanged',len(ra)==len(rb)==4 and ra[:2]==rb[:2] and np.array_equal(ra[2],rb[2]) and ra[3]==rb[3])
 check('own_goal_epoch_captured',b._assignment_epochs.records[(0,150)][0]==2)
 msg={'kind':'greedy-map-v1','id':1,'assignment_reports':{1:(200,2,np.array([50.,0.]),150)}}
 for f in [a,b]:f.communicator.received_messages=[(None,msg)];f._messages()
 check('received_goal_epoch_captured',b._assignment_epochs.records[(1,150)][0]==2)
 check('original_messages_once',a.base_message_calls==b.base_message_calls==1)
 msg={'kind':'greedy-map-v1','id':1,'assignment_reports':{1:(220,1,None,150)}}
 for f in [a,b]:
  f.elapsed_timestep=220;f.communicator.received_messages=[(None,msg)];f._messages()
  f.fleet_plan=(190,0,{1:(2,[np.array([50.,0.]),np.array([150.,0.])])})
 active={1:(np.array([50.,0.]),1)}
 check('readonly_original_release_result',a._reserved_first_goals(220,active)==b._reserved_first_goals(220,active)=={})
 check('readonly_opportunity_logged',len(b._f17_epoch_logged)==1)
 check('readonly_plan_unchanged',np.array_equal(b.fleet_plan[2][1][1][1],[150.,0.]))
 c=fleet_fixture(newfleet.FleetCoverageMixin);c._assignment_epochs=b._assignment_epochs
 c.fleet_plan=b.fleet_plan;c.assignment_reports=dict(b.assignment_reports)
 r=c._reserved_first_goals(220,active)
 check('production_keeps_only_confirmed_completion_suffix',set(r)=={1} and np.array_equal(r[1],[150.,0.]))
 c.assignment_reports[1]=(220,2,None,150)
 check('production_same_inventory_release_preserved',c._reserved_first_goals(220,{1:(np.zeros(2),2)})=={})
 c.assignment_reports[1]=(220,1,None,201)
 check('production_unknown_new_epoch_release_preserved',c._reserved_first_goals(220,active)=={})
 c.assignment_reports[1]=(220,1,None,150);c.conflict=True
 check('known_drop_conflict_still_rejected',c._reserved_first_goals(220,active)=={})
 c.conflict=False;c.fleet_plan=(0,0,c.fleet_plan[2])
 check('stale_plan_not_revived',c._reserved_first_goals(250,active)=={})
 # New acknowledged goal is explicitly rejected at unchanged inventory: original release.
 c.fleet_plan=b.fleet_plan;c._assignment_epochs.remember(1,(215,1,(150.,0.),210),215)
 c.assignment_reports[1]=(220,1,None,210)
 check('explicit_next_goal_rejection_preserved',c._reserved_first_goals(220,active)=={})
 before=dict(b._assignment_epochs.records)
 msg={'kind':'greedy-map-v1','id':1,'assignment_reports':{1:(219,7,np.array([0.,0.]),200),2:(221,2,np.zeros(2),210)}}
 b.communicator.received_messages=[(None,msg)];b._messages()
 check('unaccepted_reports_never_cached',b._assignment_epochs.records==before)
 original=endpoint._original_plan_team_coverage
 try:
  payload={0:[np.array([100.,0.]),np.array([200.,0.])]}
  endpoint._original_plan_team_coverage=lambda *a,**k:payload
  mem=types.SimpleNamespace(identifier=0,step=700)
  result=endpoint.plan_team_coverage(mem,{0:(np.zeros(2),2)},[],40.)
  check('endpoint_observer_return_identity',result is payload)
  check('actual_multitarget_request_logged',mem._f17_endpoint_opportunity_count==1)
  endpoint.plan_team_coverage(mem,{0:(np.zeros(2),1)},[],40.)
  check('single_target_request_not_opportunity',mem._f17_endpoint_opportunity_count==1)
 finally:endpoint._original_plan_team_coverage=original
 report.update(status='PASS',scope='Actual telemetry/control/build/callback paths and original plan/counters/arrays, synthetic graph, native SDK/ABI; no simulator/candidate/history.')
except BaseException:report.update(status='FAIL',error=traceback.format_exc());raise
finally:
 (Q/'FIRST_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'checks':len(report['checks']),'error':report.get('error')}))
