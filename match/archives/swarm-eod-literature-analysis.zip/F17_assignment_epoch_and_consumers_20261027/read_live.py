import subprocess
code = r'''
from pathlib import Path
import json
R=Path('/home/junhao/quan/parallel_test_solver/match')
F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F17_assignment_epoch_and_consumers_20261027'
s=json.loads((F/'STATUS.json').read_text())
a=json.loads((R/'solver_study/heuristic_20261016.json').read_text())
out={k:s.get(k) for k in ['status','pid','candidate_id','current','updated_utc','performance_phase']}
out['active_processes']=a.get('active_processes',[])
out['first_native_error']=(F/'FIRST_NATIVE_ERROR.json').exists()
out['coordinator_state']=None
if s.get('pid'):
 p=Path('/proc')/str(s['pid'])/'stat'
 out['coordinator_state']=p.read_text().split()[2] if p.exists() else 'exited'
if s.get('current'):
 label=s['current']['label'];p=R/'results/target90_20261012'/('unseeded_'+label)/'matrix_status.json'
 if p.exists():
  m=json.loads(p.read_text());out['matrix_updated']=m.get('updated_utc')
  out['jobs']={k:{'status':v.get('status'),'rounds':[{'score':r.get('full_score'),'placed':r.get('placed'),'red_seconds':r.get('red_walltime')} for r in v.get('rounds',[])]} for k,v in m['jobs'].items()}
direction=next((v for v in ['R01','R02','R03'] if s['status'].startswith(v)),None)
out['direction']=direction
p=F/((direction+'_DIAG') if direction else 'PARENT_M04_DIAG')/'Map04_red/console.log'
if p.exists():
 lines=p.read_text(errors='replace').splitlines()
 advisors=[json.loads(x[len('[F17_FRONTIER_ADVISOR] '):]) for x in lines if x.startswith('[F17_FRONTIER_ADVISOR] ')]
 out['frontier_advice']=[{k:a.get(k) for k in ['owner','step','probe','reason','positive_modes','tested','seconds','deadline_reached','proposals','funnel']} for a in advisors]
 out['preferences_applied']=[json.loads(x[len('[F17_PREFERENCE_APPLIED] '):]) for x in lines if x.startswith('[F17_PREFERENCE_APPLIED] ')]
 out['selected_target_count']=sum(x.startswith('[F17_TARGET_SELECTED] ') for x in lines)
 out['drop_ack_count']=sum(x.startswith('[F17_DROP_ACK] ') for x in lines)
 out['repair_targets']=[json.loads(x[len('[F17_REPAIR_TARGET] '):]) for x in lines if x.startswith('[F17_REPAIR_TARGET] ')]
 out['kept_suffixes']=[json.loads(x[len('[F17_SUFFIX_KEPT] '):]) for x in lines if x.startswith('[F17_SUFFIX_KEPT] ')]
 ticks=[json.loads(x[len('[F17_DIAG_TICK] '):]) for x in lines if x.startswith('[F17_DIAG_TICK] ')]
 if ticks:out['latest_tick']={k:ticks[-1].get(k) for k in ['owner','step','stock','wall_left','remaining_steps']}
 latest={x['owner']:x for x in ticks}
 out['own_preference_status']={str(k):{'step':x['step'],'stock':x['stock'],'coverage_ready':x.get('decision_snapshot',{}).get('coverage_ready'),'preference':{n:v for n,v in x.get('layout_preference',{}).items() if n!='proof'}} for k,x in latest.items()}
print(json.dumps(out))
'''
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60',
 '/home/junhao/quan/parallel_test_solver/match/.venv/bin/python','-'],input=code.encode(),check=True)
