from pathlib import Path
import ast
F=Path(__file__).resolve().parent;O=F.parent/'F16_measured_layout_frontier_20261027'
s=(O/'prepare_performance_operators.py').read_text(encoding='utf-8').replace(O.name,F.name).replace('F16','F17').replace('f16','f17').replace('Q01','R01').replace('Q02','R02').replace('Q03','R03')
marker="assert v in json.loads((F/'DIRECTION_ADMISSION.json').read_text(encoding='utf-8'))['admitted_order']"
assert s.count(marker)==1
s=s.replace(marker,marker+"\nassert json.loads((F/(v+'_DIAG')/'MECHANISM_REVIEW.json').read_text(encoding='utf-8'))['start_five_map_now'] is True")
s=s.replace('predeclared independent measured model tradeoffs for transport, delivery and visibility; candidates admitted by actual frontier evidence and mechanism review',
 'predeclared independent assignment handoff, own immediate delivery and endpoint horizon ablations; candidates admitted by public live opportunities and actual selected-target inventory acknowledgement')
ast.parse(s);p=F/'prepare_performance_operators.py';assert not p.exists();p.write_bytes(s.encode())
print('Performance operator generator prepared; cannot execute before positive actual mechanism review')
