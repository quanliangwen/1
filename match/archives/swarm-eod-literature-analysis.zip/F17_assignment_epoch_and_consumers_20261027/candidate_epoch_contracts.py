    import ast,types,zipfile,yaml
    from swarm_rescue.solutions import fleet_mission as current_fleet
    from swarm_rescue.solutions.assignment_epochs import AssignmentEpochCache
    build=json.loads((C/'BUILD.json').read_text())
    parent=json.loads((F.parent/'PREDECLARATION.json').read_text())['parent']
    class FakeBase:
        def __init__(self,**kwargs):self.team_size=5;self.message_calls=0
        def _messages(self):self.message_calls+=1
        def carried_bombs_count(self):return self.stock
    class Probe(current_fleet.FleetCoverageMixin,FakeBase):
        def _map_quality(self):return (.5,20)
        def _point_conflicts_with_drop(self,p):return self.conflict
    d=Probe();d.identifier=0;d.stock=2;d.pose=np.zeros(2);d.elapsed_timestep=200;d.conflict=False
    d.memory=types.SimpleNamespace(CELL=16.);d.drop_records={}
    d.assignment_goal=np.array([0.,1.]);d.assignment_since=150
    wire=d._own_assignment_report(200)
    check('actual_epoch_wire4',len(wire)==4 and wire[:2]==(200,2) and wire[3]==150 and np.array_equal(wire[2],[0.,1.]))
    check('actual_own_epoch_captured',d._assignment_epochs.records[(0,150)][0]==2)
    d.communicator=types.SimpleNamespace(received_messages=[(None,{'kind':'greedy-map-v1','id':1,'assignment_reports':{1:(200,2,np.array([50.,0.]),150)}})])
    d._messages();check('actual_received_epoch_captured',d._assignment_epochs.records[(1,150)][0]==2 and d.message_calls==1)
    d.elapsed_timestep=220;d.communicator.received_messages=[(None,{'kind':'greedy-map-v1','id':1,'assignment_reports':{1:(220,1,None,150)}})]
    d._messages();d.fleet_plan=(190,0,{1:(2,[np.array([50.,0.]),np.array([150.,0.])])});active={1:(np.zeros(2),1)}
    result=d._reserved_first_goals(220,active)
    check('actual_completion_suffix_handoff',set(result)=={1} and np.array_equal(result[1],[150.,0.]))
    for label,inventory,since,cache in [('same_inventory',2,150,True),('new_epoch',1,201,True),('missing_history',1,150,False)]:
        saved=d._assignment_epochs
        if not cache:d._assignment_epochs=AssignmentEpochCache(5)
        d.assignment_reports[1]=(220,inventory,None,since)
        check('actual_conservative_release_'+label,d._reserved_first_goals(220,{1:(np.zeros(2),inventory)})=={})
        d._assignment_epochs=saved
    d.assignment_reports[1]=(220,1,None,150);d.conflict=True
    check('actual_drop_conflict_preserved',d._reserved_first_goals(220,active)=={})
    d.conflict=False;d.fleet_plan=(0,0,d.fleet_plan[2])
    check('actual_stale_plan_not_revived',d._reserved_first_goals(250,active)=={})
    check('epoch_helper_matches_qualification',build['source_files']['assignment_epochs.py']==json.loads((F.parent/'observer_qualification/SOURCE_BINDING.json').read_text())['observer_source_files']['assignment_epochs.py'])
    check('only_handoff_files_changed',build['changed_files']==sorted(['fleet_mission.py','assignment_epochs.py','epoch_observer.py']))
