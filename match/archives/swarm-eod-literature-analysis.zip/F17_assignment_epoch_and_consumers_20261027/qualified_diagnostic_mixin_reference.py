"""Own-controller counters only; no added sensing/planning/submission calls."""
import time
import numpy as np

class DiagnosticMixin:

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._diag_costs = {}
        self._diag_last_tick = -1000
        self._diag_complete_seen = False
        self._diag_end_opportunities = 0
        self._diag_first_complete = None
        self._profile_stall_active = False
        self._profile_episode = 0
        self._profile_episode_rejects = 0
        self._profile_rejections = {'calls': 0, 'nonempty_goals': 0, 'same_episode_extra_goals': 0}
        original_get = self.memory.geometry_cache.get

        def observed_get(*args, **kwargs):
            started = time.perf_counter()
            try:
                view = original_get(*args, **kwargs)
                if not getattr(view, '_profile_route_wrapped', False):
                    original = view.route_to

                    def observed_route(*a, _original=original, **k):
                        begun = time.perf_counter()
                        try:
                            return _original(*a, **k)
                        finally:
                            self._diag_record_cost('geometry_fallback_route_to', begun)
                    view.route_to = observed_route
                    view._profile_route_wrapped = True
                return view
            finally:
                self._diag_record_cost('geometry_view_get', started)
        self.memory.geometry_cache.get = observed_get
        original_reject = self.memory.reject_goal

        def observed_reject(*args, **kwargs):
            self._profile_rejections['calls'] += 1
            if self.memory.exploration_goal is not None:
                self._profile_rejections['nonempty_goals'] += 1
                if self._profile_stall_active and self._profile_episode_rejects > 0:
                    self._profile_rejections['same_episode_extra_goals'] += 1
                self._profile_episode_rejects += 1
            return original_reject(*args, **kwargs)
        self.memory.reject_goal = observed_reject
        for name in ('observe', 'merge', 'render', 'route'):
            original = getattr(self.memory, name)

            def measured(*args, _original=original, _name=name, **kwargs):
                started = time.perf_counter()
                try:
                    return _original(*args, **kwargs)
                finally:
                    self._diag_record_cost('memory_' + _name, started)
            setattr(self.memory, name, measured)
        self.memory._f17_layout_enabled = getattr(self, 'F17_MODE', 'NONE') == 'FRONTIER'

    def _diag_record_cost(self, name, start):
        elapsed = time.perf_counter() - start
        count, total, maximum = self._diag_costs.get(name, (0, 0.0, 0.0))
        self._diag_costs[name] = (count + 1, total + elapsed, max(maximum, elapsed))

    def _diag_core_state(self):
        step = int(self.elapsed_timestep)
        certificates = getattr(self, 'completion_certificates', {})
        remaining = self._remaining_steps()
        all_done = all((peer in certificates for peer in range(self.team_size)))
        wall_left = float(self.walltime_limit) - float(self.elapsed_walltime)
        return {'owner': int(self.identifier or 0), 'step': step, 'stock': int(self.carried_bombs_count()), 'all_certificates': all_done, 'certificate_count': len(certificates), 'remaining_steps': remaining, 'wall_left': wall_left, 'cached_map_quality': getattr(self, '_quality_cache', None), 'known_free_fraction': float(self.memory.free.mean()), 'assignment_goal': None if self.assignment_goal is None else self.assignment_goal.tolist(), 'lease_age': step - int(getattr(self, 'assignment_since', -1000)), 'costs': {k: {'calls': v[0], 'seconds': v[1], 'max_seconds': v[2]} for k, v in self._diag_costs.items()}, 'end_probe_budget_opportunities': self._diag_end_opportunities, 'first_complete_step': self._diag_first_complete, 'route_reuse': getattr(self.memory, 'route_reuse_diagnostics', {}), 'viewpoint': getattr(self.memory, 'viewpoint_diagnostics', {}), 'viewpoint_last': getattr(self.memory, '_viewpoint_last', None), 'current_goal': None if self.goal is None else np.asarray(self.goal).tolist(), 'exploration_rejections': dict(self._profile_rejections), 'stall_episodes': self._profile_episode, 'terminal_policy': dict(getattr(self, 'terminal_value_diagnostics', {})), 'terminal_gain_rate': getattr(self, '_terminal_gain_rate', None), 'commitment_policy': dict(getattr(self, 'commitment_diagnostics', {})), 'survey_policy': dict(getattr(self, 'survey_diagnostics', {})), 'placement_goal': None if self.placement_goal is None else np.asarray(self.placement_goal).tolist()}

    def _build_fleet_plan(self, step):
        self.memory._f17_rally = None if self.rally is None else np.asarray(self.rally,float).copy()
        started = time.perf_counter()
        try:
            return super()._build_fleet_plan(step)
        finally:
            self._diag_record_cost('fleet_chain', started)

    def _commitment_model(self, step):
        started = time.perf_counter()
        try:
            return super()._commitment_model(step)
        finally:
            self._diag_record_cost('commitment_model', started)

    def _estimate_coverage_opportunity(self, step):
        started = time.perf_counter()
        try:
            return super()._estimate_coverage_opportunity(step)
        finally:
            self._diag_record_cost('coverage_opportunity', started)

    def _build_survey_plan(self, step):
        started = time.perf_counter()
        try:
            return super()._build_survey_plan(step)
        finally:
            self._diag_record_cost('survey_chain', started)

    def submit_exploration_map(self, grid):
        import json
        state = self._diag_state()
        state['submitted_pixels'] = int(np.count_nonzero(grid))
        print('[F17_SUBMIT_CALL]', json.dumps(state, separators=(',', ':')), flush=True)
        return super().submit_exploration_map(grid)

    def control(self):
        self._f17_control_started = time.perf_counter()
        started = time.perf_counter()
        try:
            return super().control()
        finally:
            self._diag_record_cost('control_total', started)
            step = int(self.elapsed_timestep)
            all_done = all((peer in self.completion_certificates for peer in range(self.team_size)))
            if all_done and self._diag_first_complete is None:
                self._diag_first_complete = step
            if all_done and self._remaining_steps() >= 240 and (self.walltime_limit - self.elapsed_walltime >= 15):
                self._diag_end_opportunities += 1
            if step - self._diag_last_tick >= 24 or all_done != self._diag_complete_seen or self.submitted:
                import json
                print('[F17_DIAG_TICK]', json.dumps(self._diag_state(), separators=(',', ':')), flush=True)
                self._diag_last_tick = step
            self._diag_complete_seen = all_done

    def _plan_route(self, step, returning, peer_goals):
        started = time.perf_counter()
        try:
            return super()._plan_route(step, returning, peer_goals)
        finally:
            self._diag_record_cost('route_plan_chain', started)

    def _messages(self):
        active = self.stuck_steps >= 30
        if active and (not self._profile_stall_active):
            self._profile_episode += 1
            self._profile_episode_rejects = 0
        self._profile_stall_active = active
        return super()._messages()

    def _diag_state(self):
        state = self._diag_core_state()
        step = state['step']
        own = state['owner']

        def point(value):
            try:
                a = np.asarray(value, float)
                return a.tolist() if a.shape == (2,) and np.isfinite(a).all() else None
            except (TypeError, ValueError):
                return None
        active = [int(k) for k, (ts, pos, n) in self.fleet_states.items() if pos is not None and 0 <= step - ts < self.STATE_FRESH_STEPS]
        plan = self.fleet_plan
        plan_info = None
        if plan is not None:
            entry = plan[2].get(own)
            index = max(0, int(entry[0]) - state['stock']) if entry is not None else 0
            plan_info = {'age': step - int(plan[0]), 'sender': int(plan[1]), 'own_stops_remaining': max(0, len(entry[1]) - index) if entry is not None else 0}
        state['kernel_diagnostics'] = getattr(self.memory, 'kernel_diagnostics', {})
        state['feature_diagnostics'] = {'optical_endpoint': dict(getattr(self.memory, 'optical_endpoint_diagnostics', {})), 'hysteresis': dict(getattr(self.memory, 'effective_hysteresis_diagnostics', {})), 'stall': dict(getattr(self, 'stall_rejection_diagnostics', {}))}
        state['decision_snapshot'] = {'pose': point(self.pose), 'rally': point(self.rally), 'coverage_ready': bool(self.coverage_ready), 'seeking_fusion': bool(self._seeking_fusion), 'sortie_state': self._sortie_state, 'fresh_agents': sorted(active), 'own_is_elected_leader': bool(active and own == min(active)), 'fleet_plan': plan_info, 'pending_drop': self.pending_drop is not None, 'coverage_model': dict(getattr(self, 'coverage_model', {}) or {}), 'memory_exploration_goal': point(getattr(self.memory, 'exploration_goal', None))}
        state['f17_mode'] = getattr(self, 'F17_MODE', 'NONE')
        state['frontier_probe_count'] = getattr(self.memory, '_f17_frontier_count', 0)
        state['completion_origins'] = sorted(self.completion_certificates)
        return state

    def _submission_due(self, step):
        due = super()._submission_due(step)
        if due:
            import json
            state = self._diag_state()
            state['reason'] = 'deadline_remaining_steps_zero' if state['remaining_steps'] <= 0 else 'normal_completion_election'
            print('[F17_SUBMIT_DECISION]', json.dumps(state, separators=(',', ':')), flush=True)
        return due
