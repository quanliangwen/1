from pathlib import Path
import ast,base64,json,subprocess,shlex
from epoch_integration import integrate_epoch_reports,add_readonly_release_observer
F=Path(__file__).resolve().parent;O=F.parent/'F16_measured_layout_frontier_20261027';T=F.parent/'F13_completion_joint_transport_20261027';ref=T/'parent_source_reference'
def write(n,s):
    p=F/n;assert not p.exists();ast.parse(s);p.write_bytes(s.encode())
trust=(ref/'trust_region_cover.py').read_text(encoding='utf-8');marker='    pm=GeometryPlanningMemory(memory) if _prepared is None else _prepared\n';assert trust.count(marker)==1
trust=trust.replace(marker,marker+"    if getattr(memory,'_f17_layout_enabled',False): memory._f17_live_prepared=pm\n")
lns=(ref/'team_coverage_lns.py').read_text(encoding='utf-8').replace('    prepared=None\n','    _f17_full_budget=travel_budget\n    prepared=None\n',1)
marker='    return refine_trust_region(memory,agents,drops,radius,base,travel_budget=travel_budget,forbidden_points=forbidden_points,forbidden_mask=forbidden_mask,_prepared=prepared)';assert lns.count(marker)==1
lns=lns.replace(marker,'''    try:
        result=refine_trust_region(memory,agents,drops,radius,base,travel_budget=travel_budget,forbidden_points=forbidden_points,forbidden_mask=forbidden_mask,_prepared=prepared)
        if getattr(memory,'_f17_layout_enabled',False):
            from swarm_rescue.solutions.frontier_observer import observe_frontier
            observe_frontier(memory,agents,drops,radius,result,_f17_full_budget,travel_budget,reserved_prefixes,
                             forbidden_points,forbidden_mask,getattr(memory,'_f17_live_prepared',prepared))
        return result
    finally:
        if '_f17_live_prepared' in vars(memory):delattr(memory,'_f17_live_prepared')''')
tree=ast.parse((T/'diagnostic_mixin.py').read_text(encoding='utf-8').replace('F13','F17').replace('f13','f17'))
cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='DiagnosticMixin')
cls.body=[n for n in cls.body if not(isinstance(n,ast.FunctionDef) and n.name=='_maybe_place')]
diag=ast.unparse(tree)+'\n';marker="getattr(self, 'F17_MODE', 'NONE') == 'LAYOUT'";assert diag.count(marker)==1
diag=diag.replace(marker,"getattr(self, 'F17_MODE', 'NONE') == 'FRONTIER'")
marker='    def _build_fleet_plan(self, step):\n        started = time.perf_counter()';assert diag.count(marker)==1
diag=diag.replace(marker,"    def _build_fleet_plan(self, step):\n        self.memory._f17_rally = None if self.rally is None else np.asarray(self.rally,float).copy()\n        started = time.perf_counter()")
marker="state['f17_late_advisor_count'] = getattr(self, '_f17_late_count', 0)";assert diag.count(marker)==1
diag=diag.replace(marker,"state['frontier_probe_count'] = getattr(self.memory, '_f17_frontier_count', 0)\n        state['completion_origins'] = sorted(self.completion_certificates)")
frontier=(O/'frontier_observer.py').read_text(encoding='utf-8').replace('F16','F17').replace('f16','f17')
frontier=frontier.replace("'memory':memory,'agents':agents", "'memory':memory,'immediate_owner':int(getattr(root,'identifier',0)),'agents':agents")
frontier=frontier.replace('seconds=.8)','seconds=.8,objectives=(\'delivery\',))')
write('frontier_observer.py',frontier)
fleet=add_readonly_release_observer(integrate_epoch_reports((ref/'fleet_mission.py').read_text(encoding='utf-8')))
endpoint=(ref/'fleet_endpoint_repair.py').read_text(encoding='utf-8')
marker='\n\nclass FleetEndpointRepairMixin:';assert endpoint.count(marker)==1
endpoint=endpoint.replace(marker,'''

_original_plan_team_coverage=plan_team_coverage
def plan_team_coverage(memory,agents,*args,**kwargs):
    result=_original_plan_team_coverage(memory,agents,*args,**kwargs)
    count=getattr(memory,'_f17_endpoint_opportunity_count',0)
    for owner,(_,quota) in agents.items():
        if quota>=2 and len(result.get(owner,[]))>=2 and count<16:
            import json
            print('[F17_ENDPOINT_OPPORTUNITY]',json.dumps({'actor':int(getattr(memory,'identifier',owner)),
                  'step':int(getattr(memory,'step',0)),'owner':int(owner),'quota':int(quota),
                  'returned':len(result[owner]),'target':np.asarray(result[owner][0],float).tolist()},separators=(',',':')),flush=True)
            count+=1
    memory._f17_endpoint_opportunity_count=count
    return result
'''+marker)
assets={'trust_region_cover.py':trust,'team_coverage_lns.py':lns,'fleet_mission.py':fleet,'fleet_endpoint_repair.py':endpoint,'diagnostic_mixin.py':diag,
        **{n:(F/n).read_text(encoding='utf-8') for n in ['layout_frontier.py','sensed_layout_context.py','frontier_observer.py','assignment_epochs.py','epoch_observer.py']}}
for s in assets.values():ast.parse(s)
payload={n:base64.b64encode(s.encode()).decode() for n,s in assets.items()}
code=r'''
from pathlib import Path
import json,sys,base64,hashlib,shutil,ast
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F17_assignment_epoch_and_consumers_20261027'
assert json.loads((F/'helper_qualification_revision1/FIRST_RESULT.json').read_text())['status']=='PASS'
Q=F/'observer_qualification';assert not Q.exists();Q.mkdir();P=json.loads((F/'PREDECLARATION.json').read_text())['parent'];S=Q/'source';shutil.copytree(Path(P['path'])/'source',S)
for n,b in json.load(sys.stdin).items():(S/n).write_bytes(base64.b64decode(b))
p=S/'my_drone_eval.py';s=p.read_text();assert s.count('class MyDroneEval(')==1
s=s.replace('class MyDroneEval(','class BaseParent(',1)+"\nfrom swarm_rescue.solutions.diagnostic_mixin import DiagnosticMixin\nclass MyDroneEval(DiagnosticMixin,BaseParent):\n    F17_MODE='FRONTIER'\n";p.write_text(s)
for p in S.glob('*.py'):ast.parse(p.read_text())
(Q/'SOURCE_BINDING.json').write_text(json.dumps({'parent':P,'observer_source_files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in S.iterdir() if p.is_file()},'scope':'Readonly accepted assignment epochs, original endpoint planner counts, own immediate delivery alternatives. Original plans/commands unaffected. No candidate.'},indent=2)+'\n')
print(json.dumps({'source_files':len(list(S.iterdir())),'no_game_or_candidate':True}))
'''
r=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps(payload).encode());assert not(F/'observer_prepared.txt').exists();(F/'observer_prepared.txt').write_bytes(r);print(r.decode())
