from pathlib import Path
import ast
F=Path(__file__).resolve().parent
s=(F/'helper_tests.py').read_text(encoding='utf-8')
s=s.replace('since=150,step=200):','since=150,step=None):').replace('r=(ts,inventory,goal,since);c.remember(peer,r,step);return r','r=(ts,inventory,goal,since);c.remember(peer,r,ts if step is None else step);return r')
s=s.replace(' event(ts=201)',' event(ts=201,step=200)')
s=s.replace("p['immediate_owner']=7","p['immediate_owner']=2").replace("['owner']==7","['owner']==2")
p=F/'helper_tests_revision1.py';assert not p.exists();ast.parse(s);p.write_bytes(s.encode())
s=(F/'qualify_helpers.py').read_text(encoding='utf-8')
s=s.replace("(F/n).read_bytes()","(F/('helper_tests_revision1.py' if n=='helper_tests.py' else n)).read_bytes()")
s=s.replace("Q=F/'helper_qualification'","Q=F/'helper_qualification_revision1'").replace("helper_first_console.txt","helper_revision1_console.txt")
p=F/'qualify_helpers_revision1.py';assert not p.exists();ast.parse(s);p.write_bytes(s.encode())
