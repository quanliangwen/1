from pathlib import Path
import ast,json,base64,hashlib,subprocess,shlex
F=Path(__file__).resolve().parent;O=F.parent/'F16_measured_layout_frontier_20261027'
e=json.loads((O/'PARENT_OPERATORS.json').read_text(encoding='utf-8'))['PARENT_M04']
s=base64.b64decode(e['runner_base64']).decode().replace('F16','F17').replace('f16','f17')
# Persist all bounded own-report/own-planner events alongside original telemetry.
s=s.replace("'F17_FRONTIER_ADVISOR'","'F17_FRONTIER_ADVISOR','F17_EPOCH_OPPORTUNITY','F17_ENDPOINT_OPPORTUNITY'")
ast.parse(s)
bundle={'PARENT_M04':{'runner_base64':base64.b64encode(s.encode()).decode(),'sha256':hashlib.sha256(s.encode()).hexdigest(),'map':'Map04'}}
maps={'PARENT_M04_DIAG':'Map04','R01_DIAG':'Map04','R02_DIAG':'Map04','R03_DIAG':'Map04'}
for n,d in [('PARENT_OPERATORS.json',bundle),('DIAGNOSTIC_MAP_BINDINGS.json',maps)]:
 p=F/n;assert not p.exists();p.write_bytes((json.dumps(d,indent=2)+'\n').encode())
for n in ['sync_metadata.py','verify_diagnostic_raw.py','read_live.py','stage_parent_observer.py']:
 s=(O/n).read_text(encoding='utf-8').replace(O.name,F.name).replace('F16','F17').replace('f16','f17').replace('Q01','R01').replace('Q02','R02').replace('Q03','R03')
 ast.parse(s);p=F/n;assert not p.exists();p.write_bytes(s.encode())
code=r'''
from pathlib import Path
import json,sys
F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F17_assignment_epoch_and_consumers_20261027')
assert json.loads((F/'observer_qualification/QUALIFICATION_RESULT.json').read_text())['status']=='PASS'
for n,d in json.load(sys.stdin).items():assert not(F/n).exists();(F/n).write_text(json.dumps(d,indent=2)+'\n')
print('One original Map04 RED diagnostic prepared; no game started')
'''
print(subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps({'PARENT_OPERATORS.json':bundle,'DIAGNOSTIC_MAP_BINDINGS.json':maps}).encode()).decode())
