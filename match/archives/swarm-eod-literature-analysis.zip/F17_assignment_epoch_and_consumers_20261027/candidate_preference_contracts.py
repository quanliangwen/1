    import ast,types,zipfile,yaml
    from swarm_rescue.solutions import layout_preference as preference
    parent=json.loads((F.parent/'PREDECLARATION.json').read_text())['parent']
    build=json.loads((C/'BUILD.json').read_text())
    oldtree=ast.parse((Path(parent['path'])/'source/trust_region_cover.py').read_text())
    newtree=ast.parse((C/'source/trust_region_cover.py').read_text())
    fn=next(n for n in newtree.body if isinstance(n,ast.FunctionDef) and n.name=='refine_trust_region')
    check('optional_context_is_last_argument',fn.args.args[-1].arg=='_context_out' and isinstance(fn.args.defaults[-1],ast.Constant) and fn.args.defaults[-1].value is None)
    fn.args.args.pop();fn.args.defaults.pop()
    fn.body=[n for n in fn.body if not(isinstance(n,ast.If) and any(isinstance(v,ast.Name) and v.id=='_context_out' for v in ast.walk(n)))]
    check('refiner_numerics_AST_preserved',ast.dump(oldtree)==ast.dump(newtree))
    m,pm,base,agents,forbidden=fixture(single=True);prepared_context=[]
    trust.refine_trust_region(m,agents,[],32.,base,travel_budget={2:32.,7:32.},forbidden_mask=forbidden,_prepared=pm,_context_out=prepared_context)
    check('actual_same_call_prepared_context',prepared_context==[pm])
    check('context_not_saved_to_memory',not hasattr(m,'_context_out') and not hasattr(m,'_f17_live_prepared'))
    check('factory_objective_bound',MyDroneEval.LAYOUT_PREFERENCE==build['objective'])
    owner=next(cls for cls in MyDroneEval.__mro__[1:] if '_build_fleet_plan' in cls.__dict__)
    original_method=owner.__dict__['_build_fleet_plan']
    def fake_build(self,step):self.test_build_calls+=1;return 'original_build_result'
    try:
        owner._build_fleet_plan=fake_build
        d=object.__new__(MyDroneEval);d.memory=types.SimpleNamespace();d.rally=np.array([12.,24.]);d.test_build_calls=0
        answer=d._build_fleet_plan(1000)
        check('factory_build_calls_original_once',answer=='original_build_result' and d.test_build_calls==1)
        check('factory_sets_only_own_preference',d.memory._layout_preference_objective==build['objective'])
        check('factory_copies_own_rally',np.array_equal(d.memory._layout_preference_rally,d.rally) and d.memory._layout_preference_rally is not d.rally)
    finally:owner._build_fleet_plan=original_method
    def policy_fixture(mode):
        if mode=='transport':
            m=MapMemory(256,128);m.free[:]=True;pm=GeometryPlanningMemory(m);values=np.zeros(m.shape,np.float32);values[1,8]=1.;values[3,12]=.03
            pm._coverage_values_cache=(64.,values,np.zeros(m.shape,bool));allowed=np.zeros(m.shape,bool);allowed[3,10]=allowed[3,6]=True
            base={7:[m.cell_to_world((3,10))]};agents={7:(m.cell_to_world((4,8)),1)};radius=64.;cap=100.;rally=None
            m.nonwall_mask=np.zeros(m.hit_shape,bool);m.nonwall_mask[4*8:5*8,14*8:15*8]=True
        elif mode=='delivery':
            m=MapMemory(1024,128);m.free[:]=True;pm=GeometryPlanningMemory(m);values=np.zeros(m.shape,np.float32);values[3,27]=1.
            pm._coverage_values_cache=(32.,values,np.zeros(m.shape,bool));allowed=np.zeros(m.shape,bool);allowed[3,26]=allowed[3,28]=True
            base={2:[m.cell_to_world((3,26))]};agents={2:(m.cell_to_world((3,32)),1)};radius=32.;cap=600.;rally=m.cell_to_world((3,57))
        else:
            m=MapMemory(256,256);m.free[:]=True;pm=GeometryPlanningMemory(m);values=np.zeros(m.shape,np.float32);values[3:9,8]=1.
            pm._coverage_values_cache=(64.,values,np.zeros(m.shape,bool));pm._blocked[3:9,8]=True
            allowed=np.zeros(m.shape,bool);allowed[1,10]=allowed[6,10]=True
            base={7:[m.cell_to_world((1,10))]};agents={7:(m.cell_to_world((3,14)),1)};radius=64.;cap=500.;rally=None
            m.nonwall_mask=np.zeros(m.hit_shape,bool)
            for row in [3,4]:m.nonwall_mask[row*8:(row+1)*8,5*8:6*8]=True
        m.identifier=2 if mode=='delivery' else 7;m.step=1000;m._layout_preference_objective=mode;m._layout_preference_rally=rally
        return m,pm,base,agents,radius,cap,~allowed
    for mode in ['delivery']:
        m,pm,base,agents,radius,cap,mask=policy_fixture(mode)
        before={k:[p.copy() for p in ps] for k,ps in base.items()};arrays={n:getattr(m,n).copy() for n in ['hits','free','visits']}
        result=preference.apply_preference(m,agents,[],radius,base,cap,cap,None,(),mask,pm)
        check('actual_policy_applied_'+mode,getattr(m,'_layout_preference_applied',False) and m.layout_preference_diagnostics['applied']==1 and not same(result,base))
        proof=m.layout_preference_diagnostics['proof']
        check('model_loss_floors_'+mode,proof['nominal_after']>=.95*proof['nominal_before']-1e-5 and proof['confirmed_after']>=.95*proof['confirmed_before']-1e-5)
        check('actual_source_input_plan_immutable_'+mode,same(base,before))
        check('actual_source_arrays_immutable_'+mode,all(np.array_equal(v,getattr(m,n)) for n,v in arrays.items()))
        m.step+=240
        again=preference.apply_preference(m,agents,[],radius,base,cap,cap,None,(),mask,pm)
        check('whole_run_one_application_'+mode,again is base and m._layout_preference_attempts==1)
    original_frontier=preference.frontier_advice
    def timeout_or_none(*args,**kwargs):return {'proposals':{k:None for k in ['transport','delivery','occlusion']},'reason':'deadline','seconds':.8,'deadline_reached':True}
    try:
        preference.frontier_advice=timeout_or_none
        m,pm,base,agents,radius,cap,mask=policy_fixture(build['objective'])
        for step,want in [(1000,1),(1000,1),(1119,1),(1120,2),(1240,2)]:
            m.step=step;answer=preference.apply_preference(m,agents,[],radius,base,cap,cap,None,(),mask,pm)
            check('bounded_attempt_gap_'+str(step)+'_'+str(len(report['checks'])),answer is base and m._layout_preference_attempts==want and not getattr(m,'_layout_preference_applied',False))
    finally:preference.frontier_advice=original_frontier
    with zipfile.ZipFile(build['zip']) as archive:
        payload_files={n:hashlib.sha256(archive.read(n)).hexdigest() for n in archive.namelist()}
        info=yaml.safe_load(archive.read('team_info.yml'))
        check('actual_zip_team_integer615',type(info['team_number']) is int and info['team_number']==615)
        check('actual_zip_pins',{s.strip() for s in archive.read('req.txt').decode().splitlines() if s.strip()}=={'numpy==1.26.4','pandas==2.2.3','opencv-contrib-python==4.11.0.86'})
        check('actual_zip_source_manifest',payload_files==build['source_files'] and hashlib.sha256(Path(build['zip']).read_bytes()).hexdigest()==build['zip_sha256'])
        check('production_has_no_observer_or_test',not any(n.startswith(('diagnostic_','frontier_observer','helper_test','observer_test')) for n in payload_files))
    binding=json.loads((F.parent/'observer_qualification/SOURCE_BINDING.json').read_text())
    check('qualified_frontier_helpers_byte_identical',all(build['source_files'][n]==binding['observer_source_files'][n] for n in ['layout_frontier.py','sensed_layout_context.py']))
    check('only_declared_files_changed',build['changed_files']==sorted(['layout_frontier.py','layout_preference.py','my_drone_eval.py','sensed_layout_context.py','team_coverage_lns.py','trust_region_cover.py']))
