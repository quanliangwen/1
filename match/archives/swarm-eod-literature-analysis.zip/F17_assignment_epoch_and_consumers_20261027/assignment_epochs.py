"""Bounded evidence from this controller's own and accepted wire reports only."""
import math


class AssignmentEpochCache:
    def __init__(self, team_size, fresh_steps=120, lease_steps=600, capacity=256):
        self.team_size = int(team_size)
        self.fresh_steps = int(fresh_steps)
        self.lease_steps = int(lease_steps)
        self.capacity = int(capacity)
        self.records = {}
        self.last_prune = -1000

    def _valid(self, peer, report, step):
        try:
            ts, inventory, goal, since = report
            return (0 <= int(peer) < self.team_size and int(peer) == peer and
                    int(ts) == ts and int(inventory) == inventory and int(since) == since and
                    0 <= int(step)-int(ts) < self.fresh_steps and inventory >= 0 and
                    0 <= int(step)-int(since) < self.lease_steps+self.fresh_steps)
        except (ValueError, TypeError, OverflowError):
            return False

    def remember(self, peer, report, step):
        if int(step)-self.last_prune >= self.fresh_steps:
            self.records = {k:v for k,v in self.records.items()
                            if 0 <= int(step)-k[1] < self.lease_steps+self.fresh_steps}
            self.last_prune = int(step)
        if not self._valid(peer, report, step):
            return
        ts, inventory, goal, since = report
        try:
            finite_goal = goal is not None and len(goal) == 2 and all(math.isfinite(float(x)) for x in goal)
        except (ValueError, TypeError, OverflowError):
            finite_goal = False
        if not finite_goal:
            return
        key = (int(peer), int(since))
        old = self.records.get(key)
        if old is not None and old[0] != int(inventory):
            self.records[key] = (None, max(old[1], int(ts)))
        elif old is None or int(ts) > old[1]:
            self.records[key] = (int(inventory), int(ts))
        if len(self.records) > self.capacity:
            oldest = min(self.records, key=lambda k:(k[1], self.records[k][1], k[0]))
            del self.records[oldest]

    def completion_only(self, peer, report, step):
        if not self._valid(peer, report, step) or report[2] is not None:
            return False
        ts, inventory, _, since = report
        old = self.records.get((int(peer), int(since)))
        return bool(old is not None and old[0] is not None and old[1] <= int(ts) and
                    0 < int(inventory) < old[0])
