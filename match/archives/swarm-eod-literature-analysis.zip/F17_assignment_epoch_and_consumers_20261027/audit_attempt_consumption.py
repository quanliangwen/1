from pathlib import Path
import subprocess,shlex
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import json,subprocess,os,ast
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F17_assignment_epoch_and_consumers_20261027';Q=F/'attempt_consumption_audit';assert not Q.exists();Q.mkdir()
source=r"""
from pathlib import Path
import sys,json,types,traceback
Q=Path(__file__).resolve().parent;W=Q.parent/'R02/qualification_workspace';sys.path.insert(0,str(W/'src'))
report={'status':'STARTED','checks':[],'game_rounds':0}
def check(n,v):
 assert v,n
 report['checks'].append(n)
try:
 import numpy as np
 from swarm_rescue.solutions import layout_preference as p
 from swarm_rescue.solutions.layout_frontier import eligible_slot
 m=types.SimpleNamespace(step=1000,identifier=2,_layout_preference_objective='delivery');calls=[]
 def observe(params,*a,**kw):
  calls.append(eligible_slot(params,2,0))
  return {'proposals':{'delivery':None},'reason':'compared_model_frontier','seconds':0.,'deadline_reached':False}
 original=p.frontier_advice;p.frontier_advice=observe
 result={2:[np.array([10.,0.])]};agents={2:(np.zeros(2),1)};prefix={2:(np.zeros(2),np.array([20.,0.]))}
 try:
  for step in [1000,1120]:
   m.step=step;answer=p.apply_preference(m,agents,[],32.,result,200.,100.,prefix,(),None,None)
   check('reserved_call_returns_original_'+str(step),answer is result)
  check('two_ineligible_calls_consume_two_attempts',m._layout_preference_attempts==2 and calls==[False,False])
  m.step=1360;answer=p.apply_preference(m,agents,[],32.,result,200.,200.,None,(),None,None)
  check('later_eligible_call_not_searched',answer is result and len(calls)==2 and eligible_slot({'immediate_owner':2},2,0))
 finally:p.frontier_advice=original
 report.update(status='PASS',finding='Current policy can spend its two attempts while own target is reserved, then cannot search a later eligible own first target. Fixed synthetic state only, NOT proof this explains the actual diagnostic trajectory; production/source/finished game unchanged.')
except BaseException:report.update(status='FAIL',error=traceback.format_exc());raise
finally:(Q/'FIRST_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
"""
p=Q/'audit.py';p.write_bytes(source.encode());ast.parse(source)
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with (Q/'first_console.log').open('x') as log:r=subprocess.run(['bash',str(R/'run_server.sh'),'-u',str(p)],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
print((Q/'FIRST_RESULT.json').read_text());raise SystemExit(r.returncode)
'''
r=subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
p=F/'attempt_consumption_audit_console.txt';assert not p.exists();p.write_bytes(r.stdout);print(r.stdout.decode(errors='replace'));raise SystemExit(r.returncode)
