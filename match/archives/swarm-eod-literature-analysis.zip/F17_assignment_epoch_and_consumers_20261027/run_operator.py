import sys,subprocess
v,name=sys.argv[1:3];assert v in ['R01','R02','R03'] and name in ['prepare_performance','launch_performance']
code=r'''
from pathlib import Path
import json,hashlib,subprocess,os
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F17_assignment_epoch_and_consumers_20261027';v=VERSION;name=OPERATION
p=F/'operators'/v/(name+'.json');assert hashlib.sha256(p.read_bytes()).hexdigest()==json.loads((F/('OPERATOR_SHA_'+v+'.json')).read_text())[str(p.relative_to(F))]
d=json.loads(p.read_text());log=p.with_name(name+'_manual_first_console.log');assert not log.exists()
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with log.open('x') as out:r=subprocess.run([str(R/'.venv/bin/python'),'-u','-c',d['code']],input=json.dumps(d['payload']).encode(),cwd=R,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=180)
print(log.read_text());raise SystemExit(r.returncode)
'''.replace('VERSION',repr(v)).replace('OPERATION',repr(name))
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python','-'],input=code.encode(),check=True)
