from pathlib import Path
import json,datetime,hashlib,subprocess,shlex
F=Path(__file__).resolve().parent;G=F/'PARENT_M04_DIAG'
assert not(F/'DIRECTION_ADMISSION.json').exists()
assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'))['valid']
E=json.loads((G/'EVENTS.json').read_text(encoding='utf-8'));R=json.loads((G/'RESULT.json').read_text(encoding='utf-8'))
assert R['complete'] and R['valid'] and not R['row']['crashed']
epochs=E['F17_EPOCH_OPPORTUNITY'];repairs=E['F17_ENDPOINT_OPPORTUNITY'];delivery=[]
for e in epochs:assert 0<e['inventory']<e['epoch_inventory'] and e['since']>=0 and e['report_ts']>e['plan_epoch']
for e in repairs:assert e['quota']>=2 and e['returned']>=2
for e in E['F17_FRONTIER_ADVISOR']:
 p=e['proposals'].get('delivery')
 if p is None:continue
 assert not e['deadline_reached'] and p['owner']==e['owner'] and p['slot']==0
 assert p['nominal_after']>=.95*p['nominal_before']-1e-5 and p['confirmed_after']>=.95*p['confirmed_before']-1e-5
 assert p['RED_after']<=p['RED_before']+32.+1e-5 and p['RED_after']<=p['suffix_cap']+1e-5 and p['delivery_after']<=p['full_cap']+1e-5
 assert p['improvement']>=32.-1e-5
 delivery.append(e)
gates={'R01':bool(epochs),'R02':bool(delivery),'R03':bool(repairs)}
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PARENT_MECHANISM_OPPORTUNITIES_REVIEWED',
 'gates':gates,'admitted_order':[v for v in ['R01','R02','R03'] if gates[v]],
 'counts':{'epoch_completion_suffix':len(epochs),'own_immediate_delivery':len(delivery),'multitarget_endpoint_repair':len(repairs)},
 'examples':{'epoch':epochs[:2],'delivery':delivery[:1],'endpoint':repairs[:2]},
 'production_limits_frozen_before_source':{'epoch_capacity':256,'epoch_age_max':720,'epoch_fresh':120,'epoch_lease':600,
   'delivery_attempts_per_own_memory':2,'delivery_gap_steps':120,'delivery_success_per_own_memory':1,'delivery_seconds':.8,'delivery_coverage_floor':.95,
   'delivery_owner':'own_only','delivery_slot':0,'delivery_reserved_owner_excluded':True,'endpoint_quota':1},
 'raw_manifest_sha256':R['raw_manifest_sha256'],'parent_placed':[R['row']['placed'],R['row']['expected']],
 'not_performance_or_causal_claim':True,'reason':'Only observed actual public-state opportunities admit independent candidates; passing now is not proof of execution or score gain. Each admitted candidate must fresh-run actual target adoption + inventory ACK before full five.'}
p=F/'DIRECTION_ADMISSION.json';p.write_bytes((json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode())
remote="from pathlib import Path;import sys;p=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F17_assignment_epoch_and_consumers_20261027/DIRECTION_ADMISSION.json');assert not p.exists();p.write_bytes(sys.stdin.buffer.read())"
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(remote)],input=p.read_bytes(),check=True)
print(json.dumps({k:d[k] for k in ['gates','admitted_order','counts','parent_placed','not_performance_or_causal_claim']}))
