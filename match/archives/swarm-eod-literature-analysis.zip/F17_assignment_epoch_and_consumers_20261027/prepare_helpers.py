from pathlib import Path
import ast
F=Path(__file__).resolve().parent;O=F.parent/'F16_measured_layout_frontier_20261027'
def write(n,s):
    p=F/n;assert not p.exists();ast.parse(s);p.write_bytes(s.encode())
s=(O/'layout_frontier.py').read_text(encoding='utf-8')
s=s.replace("OBJECTIVES=('transport','delivery','occlusion')", """OBJECTIVES=('transport','delivery','occlusion')

def eligible_slot(params, owner, slot):
    if 'immediate_owner' not in params:return True
    return (int(owner)==int(params['immediate_owner']) and slot==0 and
            owner not in (params.get('reserved_prefixes') or {}))
""")
marker='        for slot,old in enumerate(ps):\n';assert s.count(marker)==1
s=s.replace(marker,marker+'            if not eligible_slot(params,k,slot):continue\n')
write('layout_frontier.py',s);write('sensed_layout_context.py',(O/'sensed_layout_context.py').read_text(encoding='utf-8'))
s=(O/'helper_tests.py').read_text(encoding='utf-8');marker=" report.update(status='PASS')";assert s.count(marker)==1
extra=(F/'epoch_and_consumer_tests.py').read_text(encoding='utf-8')
s=s.replace(marker,'\n'.join(' '+x for x in extra.splitlines())+'\n'+marker);write('helper_tests.py',s)
s=(O/'qualify_helpers.py').read_text(encoding='utf-8').replace(O.name,F.name).replace("'sensed_layout_context.py','helper_tests.py'","'sensed_layout_context.py','assignment_epochs.py','helper_tests.py'")
write('qualify_helpers.py',s)
print('Helpers and first qualification prepared; no evaluator started')
