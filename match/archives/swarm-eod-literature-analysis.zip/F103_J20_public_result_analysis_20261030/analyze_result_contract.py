from pathlib import Path
import importlib.util,json,math
import numpy as np
from PIL import Image
F=Path(__file__).resolve().parent;H=F.parent;P=H/'F100_raster_boundary_pilot_20261030';G=P/'J20_DIAG'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert read(G/'CLIENT_FIRST_RAW_REVIEW.json')['status']=='PASS' and read(P/'CAMPAIGN_CLIENT_REVIEW.json')['status']=='PASS'
m=read(G/'MECHANISM_REVIEW.json');red=read(G/'Map05_red/summary.json')['rounds'][0]
acks=[x for x in m['request_ack_events'] if x['outcome']=='INVENTORY_DECREASED'];assert len(acks)==10
requests=np.array([x['request_pose'] for x in acks]);actual=np.array([[x['x'],x['y']] for x in read(G/'Map05_red/round1_bombs.json')['bombs']])
D=np.linalg.norm(requests[:,None]-actual[None,:],axis=2);N=len(D)
# Complete subset DP gives the min-sum geometric matching even if row minima
# collide. A geometric match is not independent proof of causal identities.
dp={0:(0.,())}
for i in range(N):
    new={}
    for mask,(cost,path) in dp.items():
        for j in range(N):
            if mask>>j&1:continue
            key=mask|1<<j;v=(cost+float(D[i,j]),path+(j,))
            if key not in new or v<new[key]:new[key]=v
    dp=new
cost,matching=dp[(1<<N)-1]
events=[]
for line in (P/'own_red_console_reference.txt').read_text(encoding='utf-8',errors='replace').splitlines():
    if '[PLACEMENT_GATE] ' in line:events.append(json.loads(line.split('[PLACEMENT_GATE] ',1)[1]))
goals=[];rows=[]
for i,a in enumerate(acks):
    candidates=[x for x in events if x.get('event')=='PLACE_DECISION' and x.get('reason')=='REQUESTED' and x['owner']==a['owner'] and x['step']==a['request_step']]
    assert len(candidates)==1 and candidates[0]['placement_goal'] is not None
    goal=np.array(candidates[0]['placement_goal']);goals.append(goal)
    rows.append(dict(owner=a['owner'],request_step=a['request_step'],matched_bomb_index=matching[i],goal=goal.tolist(),
        requested_pose=requests[i].tolist(),actual_initial=actual[matching[i]].tolist(),
        request_to_actual=float(D[i,matching[i]]),goal_to_actual=float(np.linalg.norm(goal-actual[matching[i]]))))
image_path=G/'Map05_red/round1_red_submitted.png';im=np.array(Image.open(image_path).convert('L'))>0;h,w=im.shape
rr,cc=np.nonzero(im);pixels=np.column_stack([cc-w/2,h/2-rr]);r=red['phase']['wall_breakdown']['blast_radius']
def union(points):
    cover=np.zeros(len(pixels),bool)
    for point in points:cover|=np.sum((pixels-point)**2,axis=1)<=r*r
    return float(cover.mean()*100)
first=m['model_records'][0]['minmax_inputs']['selected_points'];assert len(first)==10
spec=importlib.util.spec_from_file_location('publicframe',H/'F84_public_boundary_prior_reference_20261030/public_closed_boundary.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
_,frame=helper.complete_public_closed_boundary(im,(w,h),closed_arena_rule=True)
states=m['last_pre_submit_by_owner'];summary_events=[x for x in events if x.get('event')=='SUMMARY']
public=read(G/'Map05_blue_rd1/round1_public_visual.json');bomb_pixel=actual*np.array([1.,-1.])+np.array([w/2,h/2]);approaches=[]
for j,b in enumerate(bomb_pixel):
    per=[]
    for tr in public['tracks']:
        points=np.asarray(tr['points_pixel'],float);dist=np.linalg.norm(points-b,axis=1);near=dist<=80;best=run=0;end=None
        for t,v in enumerate(near):
            run=run+1 if v else 0
            if run>best:best=run;end=t
        ids=np.flatnonzero(dist<=40)
        per.append(dict(owner=tr['id'],nearest=float(dist.min()),first_within40_index=int(ids[0]) if len(ids) else None,
            last_within40_index=int(ids[-1]) if len(ids) else None,longest_within80_samples=best,
            interval=[end-best+1,end] if end is not None else None))
    approaches.append(dict(bomb_index=j,actual_initial=actual[j].tolist(),all_disposed=True,
        longest_local_track=max(per,key=lambda x:x['longest_within80_samples']),closest=min(per,key=lambda x:x['nearest'])))
breakdown=red['phase']['map_breakdown']
out=dict(status='COMPLETE_AUDITED_J20_PUBLIC_CONTRACT_DIAGNOSIS',native_games_added=0,production_changed=False,
 scores={k:m[k] for k in ['full_score','map_score','wall_score','placed','red_steps','red_walltime','blue']},fixed_gate_pass=m['pass_gate'],
 matching=dict(method='Exact subset-DP min total Euclidean distance',cost=cost,rowwise_lower_bound=float(D.min(axis=1).sum()),
    request_to_actual_mean=float(np.mean([x['request_to_actual'] for x in rows])),request_to_actual_max=float(np.max([x['request_to_actual'] for x in rows])),
    goal_to_actual_mean=float(np.mean([x['goal_to_actual'] for x in rows])),goal_to_actual_max=float(np.max([x['goal_to_actual'] for x in rows]))),
 placements=rows,final_prediction_unweighted_coverage=dict(actual=union(actual),requested=union(requests),requested_goals=union(goals),first_full_plan=union(first)),
 public_frame_analysis=frame,map_breakdown=breakdown,pre_submit=states,placement_summaries=summary_events,
 public_blue_initial_site_approaches=approaches,
 limitations=['All10 ultimately disposed; public trails have no per-bomb pickup/disposal times or cargo states. Near an initial position does not prove a task or persistent bomb.',
  'Final RED prediction is a common retrospective belief, not a true map or earlier belief. No feasibility/cause/official coverage inference from first plan vs actual.',
  'Geometric matching minimizes sum distance but does not independently identify which physical bomb each request created.',
  'No NPZ/pickle or BLUE private console/state; results do not establish a causal improvement over independent historical J15.'])
(F/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(status=out['status'],matching=out['matching'],coverage=out['final_prediction_unweighted_coverage'],
    missing_surface=breakdown['wall_pixels']-breakdown['wall_hits'],public_frame=frame,
    longest_local=max(approaches,key=lambda x:x['longest_local_track']['longest_within80_samples']))))
