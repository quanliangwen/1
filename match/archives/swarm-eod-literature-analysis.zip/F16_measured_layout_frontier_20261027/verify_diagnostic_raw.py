from pathlib import Path
import json,subprocess,base64,hashlib,tarfile,shlex,sys,datetime
F=Path(__file__).resolve().parent;name=sys.argv[1];assert name in ['PARENT_M04_DIAG', 'Q01_DIAG', 'Q02_DIAG', 'Q03_DIAG']
R='/home/junhao/quan/parallel_test_solver/match';RF=R+'/solver_study/framework_screen_20261016/best87_independent_20261025/F16_measured_layout_frontier_20261027/'+name
G=F/name;G.mkdir(exist_ok=True);assert not(G/'CLIENT_FIRST_RAW_REVIEW.json').exists(),'Already verified'
code="from pathlib import Path;import json,base64;p=Path("+repr(RF)+");assert not(p/'CLIENT_FIRST_RAW_REVIEW.json').exists();names=['RESULT.json','RAW_SHA256.json','STAGING.json','GAME_PREDECLARATION.json','PREFLIGHT.json','EVENTS.json'];print(json.dumps({n:base64.b64encode((p/n).read_bytes()).decode() for n in names}))"
bundle=json.loads(subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60',R+'/.venv/bin/python','-'],input=code.encode()))
data={n:base64.b64decode(v) for n,v in bundle.items()};d=json.loads(data['RESULT.json']);manifest=json.loads(data['RAW_SHA256.json']);game=json.loads(data['GAME_PREDECLARATION.json'])
sha=lambda b:hashlib.sha256(b).hexdigest()
assert d['complete'] and d['valid'] and d['new_game_rounds']==1 and d['BLUE_rounds']==0 and d['raw_arrays_loaded']==0
assert sha(data['RAW_SHA256.json'])==d['raw_manifest_sha256'] and len(manifest)==d['raw_files']
expected_map=json.loads((F/'DIAGNOSTIC_MAP_BINDINGS.json').read_text(encoding='utf-8'))[name]
assert game['maps']==[expected_map] and game['rounds']==1 and game['external_seed'] is None and game['no_BLUE'] and game['no_retry']
assert json.loads(data['PREFLIGHT.json'])['status']=='PASS' and not d['row']['crashed']
raw=G/'raw_results.tar.gz';assert not raw.exists(),'Do not overwrite unverified archive'
for n,b in data.items():(G/n).write_bytes(b)
subprocess.run(['scp','-q','junhao@10.112.162.60:'+RF+'/raw_results.tar.gz',str(raw)],check=True)
assert sha(raw.read_bytes())==d['raw_archive_sha256']
verified=set()
with tarfile.open(raw,'r:gz') as archive:
 for entry in archive:
  assert entry.isfile() and entry.name in manifest and entry.name not in verified
  digest=hashlib.sha256();count=0
  stream=archive.extractfile(entry)
  for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block);count+=len(block)
  assert count==manifest[entry.name]['bytes'] and digest.hexdigest()==manifest[entry.name]['sha256']
  verified.add(entry.name)
assert verified==set(manifest)
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'valid':True,'diagnostic':name,'raw_files_verified':len(verified),'archive_sha256':d['raw_archive_sha256'],'raw_manifest_sha256':d['raw_manifest_sha256'],'local_archive':str(raw),'scope':'First Windows compressed archive persistence and opaque entrySHA verification only. No NPZ/pickle deserialization, no replay, no BLUE or five-map ranking.'}
p=G/'CLIENT_FIRST_RAW_REVIEW.json';p.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
remote="from pathlib import Path;import sys;p=Path("+repr(RF+'/CLIENT_FIRST_RAW_REVIEW.json')+");assert not p.exists();p.write_bytes(sys.stdin.buffer.read())"
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60',R+'/.venv/bin/python -c '+shlex.quote(remote)],input=p.read_bytes(),check=True)
print(json.dumps(receipt,ensure_ascii=False))
