from pathlib import Path
import ast
F=Path(__file__).resolve().parent;O=F.parent/'F15_delivery_and_transport_20261027'
tree=ast.parse((O/'transport_slack_advisor.py').read_text())
names={'root_memory','clone_view','context','centre_field'}
tree.body=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.FunctionDef) and n.name in names]
s=ast.unparse(tree)+'\n';ast.parse(s);p=F/'sensed_layout_context.py';assert not p.exists();p.write_text(s,encoding='utf-8')
print('Current-input context copied from qualified readonly helper; no candidate/game')
