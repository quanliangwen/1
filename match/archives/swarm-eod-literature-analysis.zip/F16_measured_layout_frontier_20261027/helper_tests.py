from pathlib import Path
import sys,json,time,traceback
Q=Path(__file__).resolve().parent;report={'status':'STARTED','checks':[],'game_rounds':0}
def check(n,v):
 assert v,n
 report['checks'].append(n)
try:
 sys.path.insert(0,str(Q/'workspace/src'))
 import numpy as np
 from swarm_rescue.solutions.layout_frontier import frontier_advice,exposure_map,reference_cells
 from swarm_rescue.solutions.greedy_mapping import MapMemory
 from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
 from swarm_rescue.solutions import trust_region_cover as trust
 def params(m,agents,radius,allowed,cap=500.):
  return {'memory':m,'agents':agents,'drops':[],'radius':radius,'travel_budget':cap,'full_budget':cap,
          'reserved_prefixes':{},'forbidden_points':(),'forbidden_mask':~allowed,'route_epsilon':32.,'trust_radius_ratio':1.25}
 def transport_fixture(loss=.03,noise=None):
  m=MapMemory(256,128);m.free[:]=True;pm=GeometryPlanningMemory(m);values=np.zeros(m.shape,np.float32);values[1,8]=1.;values[3,12]=loss
  pm._coverage_values_cache=(64.,values,np.zeros(m.shape,bool));allowed=np.zeros(m.shape,bool);allowed[3,10]=allowed[3,6]=True
  base={7:[m.cell_to_world((3,10))]};agents={7:(m.cell_to_world((4,8)),1)}
  m.nonwall_mask=np.zeros(m.hit_shape,bool);m.nonwall_mask[4*8:5*8,14*8:15*8]=True
  return m,pm,base,params(m,agents,64.,allowed,100.)
 m,pm,base,p=transport_fixture();original={k:getattr(m,k).copy() for k in ['hits','free','visits']};oldbase=base[7][0].copy()
 a=frontier_advice(p,base,pm,seconds=5.,objectives=('transport',));x=a['proposals']['transport']
 check('coverage_transport_tradeoff_exists',x is not None and a['reason']=='compared_model_frontier')
 check('two_cell_transport_gain',x['centre_after']>=x['centre_before']+32.-1e-6)
 check('confirmed95percent_floor',x['confirmed_after']>=.95*x['confirmed_before']-1e-5)
 check('nominal95percent_floor',x['nominal_after']>=.95*x['nominal_before']-1e-5)
 check('strict_coverage_tradeoff_measured',x['confirmed_after']<x['confirmed_before'])
 check('funnel_explains_old_noop',a['funnel'][0]['transport_floor_0.0']==0 and a['funnel'][0]['transport_floor_0.05']>0)
 check('source_arrays_unchanged',all(np.array_equal(v,getattr(m,k)) for k,v in original.items()))
 check('source_plan_unchanged',np.array_equal(base[7][0],oldbase))
 check('bounded_exact_candidates',a['tested']<=128 and a['tested']<=12)
 for loss,label,positive in [(.052,'just_inside',True),(.054,'outside',False),(.1,'large',False)]:
  m,pm,base,p=transport_fixture(loss);a=frontier_advice(p,base,pm,seconds=5.,objectives=('transport',))
  check('numeric_confirmed_boundary_'+label,(a['proposals']['transport'] is not None)==positive)
 saved=trust._repeat_hit_support
 try:
  m,pm,base,p=transport_fixture(.03);support=np.zeros(m.shape,np.float32);support[3,12]=.1;trust._repeat_hit_support=lambda memory:support.copy()
  a=frontier_advice(p,base,pm,seconds=5.,objectives=('transport',));check('independent_nominal_floor',a['proposals']['transport'] is None)
 finally:trust._repeat_hit_support=saved
 m,pm,base,p=transport_fixture();p['travel_budget']={7:20.}
 a=frontier_advice(p,base,pm,seconds=5.,objectives=('transport',));check('owner_cap_invalid_incumbent',a['reason']=='invalid_incumbent_route')
 p['travel_budget']={7:float('nan')};a=frontier_advice(p,base,pm,seconds=5.,objectives=('transport',));check('nan_budget_abstains',a['reason']=='invalid_budget')
 m,pm,base,p=transport_fixture();a=frontier_advice(p,base,pm,seconds=0.);check('timeout_clears_all_proposals',a['reason']=='deadline' and all(x is None for x in a['proposals'].values()))
 m.nonwall_mask[:]=False;a=frontier_advice(p,base,pm,seconds=5.,objectives=('transport','occlusion'));check('missing_centres_no_fabrication',all(x is None for x in a['proposals'].values()))
 def delivery_fixture(fullcap=600.,prefix=False):
  m=MapMemory(1024,128);m.free[:]=True;pm=GeometryPlanningMemory(m);values=np.zeros(m.shape,np.float32);values[3,27]=1.
  pm._coverage_values_cache=(32.,values,np.zeros(m.shape,bool));allowed=np.zeros(m.shape,bool);allowed[3,26]=allowed[3,28]=True
  base={2:[m.cell_to_world((3,26))]};agents={2:(m.cell_to_world((3,32)),1)};p=params(m,agents,32.,allowed,fullcap)
  if prefix:
   p['reserved_prefixes']={2:(m.cell_to_world((3,33)),agents[2][0])};p['travel_budget']={2:fullcap-16.}
  return m,pm,base,p,m.cell_to_world((3,57))
 m,pm,base,p,rally=delivery_fixture();a=frontier_advice(p,base,pm,rally,seconds=5.,objectives=('delivery',));x=a['proposals']['delivery']
 check('known_contact_region_delivery_positive',x is not None)
 check('known_contact_costs',x['delivery_before']==560. and x['delivery_after']==496.)
 check('contact_region_not_forced_unknown',a['delivery_contact_available'])
 m,pm,base,p,rally=delivery_fixture(512.,True);a=frontier_advice(p,base,pm,rally,seconds=5.,objectives=('delivery',));x=a['proposals']['delivery']
 check('same_call_prefix_budget',x is not None and x['prefix_cost']==16. and x['delivery_after']==512.)
 m,pm,base,p,rally=delivery_fixture(511.,True);a=frontier_advice(p,base,pm,rally,seconds=5.,objectives=('delivery',));check('full_prefix_delivery_cap_rejects',a['proposals']['delivery'] is None)
 m,pm,base,p,rally=delivery_fixture();a=frontier_advice(p,base,pm,None,seconds=5.,objectives=('delivery',));check('missing_rally_abstains',a['proposals']['delivery'] is None)
 # Pure visibility grid: all aliases of start/end must be excluded.
 opaque=np.zeros((5,5),bool);opaque[2,4]=True
 e=exposure_map(opaque,[(2,0)],16.,time.perf_counter()+5);check('rounded_endpoint_not_self_occlusion',e[2,4]==1)
 opaque[:]=False;opaque[2,0]=True;e=exposure_map(opaque,[(2,0)],16.,time.perf_counter()+5);check('rounded_source_not_self_occlusion',e[2,4]==1)
 opaque[:]=False;opaque[2,2]=True;e=exposure_map(opaque,[(2,0)],16.,time.perf_counter()+5);check('known_interior_wall_occludes',e[2,4]==0)
 opaque[:]=False;e=exposure_map(opaque,[(2,0),(1,0)],16.,time.perf_counter()+5);check('empty_or_unknown_is_not_blocker',e[2,4]==2)
 e=exposure_map(opaque,[(2,0)],100.,time.perf_counter()+5);check('finite_visibility_horizon',e[2,4]==0)
 check('reference_bound',len(reference_cells(np.ones((5,5),bool)))==8)
 check('visibility_deadline',exposure_map(opaque,[(2,0)],16.,time.perf_counter()-1) is None)
 m=MapMemory(256,256);m.free[:]=True;pm=GeometryPlanningMemory(m);values=np.zeros(m.shape,np.float32);values[3:9,8]=1.
 pm._coverage_values_cache=(64.,values,np.zeros(m.shape,bool));pm._blocked[3:9,8]=True
 allowed=np.zeros(m.shape,bool);allowed[1,10]=allowed[6,10]=True;base={7:[m.cell_to_world((1,10))]};agents={7:(m.cell_to_world((3,14)),1)}
 p=params(m,agents,64.,allowed);sources=np.zeros(m.shape,bool);sources[3,5]=sources[4,5]=True
 a=frontier_advice(p,base,pm,seconds=5.,objectives=('occlusion',),centre_override=sources);x=a['proposals']['occlusion']
 check('known_wall_visibility_preference_positive',x is not None)
 check('visibility_improves_two_rays',x['exposure_before']==2 and x['exposure_after']==0)
 check('occlusion_route_epsilon',x['RED_after']<=x['RED_before']+32.+1e-6)
 check('occlusion_supported_coverage_floor',x['confirmed_after']>=.95*x['confirmed_before']-1e-5)
 report.update(status='PASS')
except BaseException:report.update(status='FAIL',error=traceback.format_exc());raise
finally:
 (Q/'FIRST_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'checks':len(report['checks']),'error':report.get('error')}))
