from pathlib import Path
import json,datetime,subprocess,shlex
from collections import Counter
F=Path(__file__).resolve().parent;G=F/'PARENT_M04_DIAG'
assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text())['valid'];assert not(G/'ANALYSIS.json').exists()
E=json.loads((G/'EVENTS.json').read_text());R=json.loads((G/'RESULT.json').read_text());events=E['F16_FRONTIER_ADVISOR'];modes={'Q01':'transport','Q02':'delivery','Q03':'occlusion'}
qualified={k:[] for k in modes}
for event in events:
 if event['deadline_reached'] or event['reason']!='compared_model_frontier':continue
 for code,mode in modes.items():
  x=event['proposals'].get(mode)
  if x is None:continue
  assert x['nominal_after']>=.95*x['nominal_before']-1e-5 and x['confirmed_after']>=.95*x['confirmed_before']-1e-5
  assert x['RED_after']<=x['RED_before']+32.+1e-6 and x['RED_after']<=x['suffix_cap']+1e-6
  if mode=='transport':assert x['centre_after']-x['centre_before']>=32.-1e-6
  elif mode=='delivery':assert x['delivery_before']-x['delivery_after']>=32.-1e-6 and x['delivery_after']<=x['full_cap']+1e-6
  else:assert x['exposure_before']>=2 and x['exposure_before']-x['exposure_after']>=2
  qualified[code].append({'observer_owner':event['owner'],'step':event['step'],'probe':event['probe'],'proposal':x,'advisor_seconds':event['seconds']})
funnel=Counter()
for event in events:
 for row in event['funnel']:
  for k,v in row.items():
   if k not in ['owner','slot']:funnel[k]+=v
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent':'K01','gates':{k:bool(v) for k,v in qualified.items()},'qualified_opportunities':qualified,
   'events':events,'event_reasons':dict(Counter(x['reason'] for x in events)),'funnel_totals':dict(funnel),
   'advisor_seconds_total':sum(x['seconds'] for x in events),'advisor_seconds_max':max([x['seconds'] for x in events],default=0),
   'game_row':R['row'],'raw_arrays_loaded':0,'not_for_performance_ranking':True,
   'scope':'First raw-verified current own scalar opportunities. Model losses/distance/exposure are not officialscore evidence; all independent candidates require real mechanism and original-five comparison.'}
p=G/'ANALYSIS.json';p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
admission={'utc':d['utc'],'admitted_order':[k for k in modes if d['gates'][k]],'gates':d['gates'],'evidence':str(G/'ANALYSIS.json'),
           'production_limits_frozen_before_source':{'seconds':.8,'max_attempts_per_own_memory':2,'attempt_gap_steps':120,'max_successful_applications_per_own_memory':1,'coverage_floor_nominal':.95,'coverage_floor_confirmed':.95,'route_epsilon':32.,'max_exact_options':128},
           'independent_parent':'K01','no_stacking':True,'no_candidate_for_unqualified_direction':True,'not_score_gain_claim':True}
p2=F/'DIRECTION_ADMISSION.json';assert not p2.exists();p2.write_text(json.dumps(admission,indent=2)+'\n',encoding='utf-8')
remote=r'''
from pathlib import Path
import sys,json,base64
F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F16_measured_layout_frontier_20261027')
for n,b in json.load(sys.stdin).items():assert not(F/n).exists();(F/n).write_bytes(base64.b64decode(b))
'''
import base64
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(remote)],input=json.dumps({'PARENT_M04_DIAG/ANALYSIS.json':base64.b64encode(p.read_bytes()).decode(),'DIRECTION_ADMISSION.json':base64.b64encode(p2.read_bytes()).decode()}).encode(),check=True)
print(json.dumps({'gates':d['gates'],'counts':{k:len(v) for k,v in qualified.items()},'funnel_totals':dict(funnel),'max_seconds':d['advisor_seconds_max'],'admitted_order':admission['admitted_order']}))
