import json,time
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
from swarm_rescue.solutions.layout_frontier import frontier_advice


def observe_frontier(memory,agents,drops,radius,result,full_budget,suffix_budget,prefixes,
                     forbidden_points,forbidden_mask,prepared):
    root=memory
    while isinstance(root,GeometryPlanningMemory):root=root._memory
    if not getattr(root,'_f16_layout_enabled',False) or not any(result.values()):return
    step=int(getattr(root,'step',0));count=getattr(root,'_f16_frontier_count',0)
    if count>=2 or step-getattr(root,'_f16_frontier_last',-1000)<120:return
    root._f16_frontier_count=count+1;root._f16_frontier_last=step
    params={'memory':memory,'agents':agents,'drops':drops,'radius':radius,'travel_budget':suffix_budget,
            'full_budget':full_budget,'reserved_prefixes':prefixes,'forbidden_points':forbidden_points,
            'forbidden_mask':forbidden_mask,'route_epsilon':32.,'trust_radius_ratio':1.25}
    advice=frontier_advice(params,result,prepared,rally=getattr(root,'_f16_rally',None),seconds=.8)
    advice.update(owner=int(getattr(root,'identifier',0)),step=step,probe=count+1)
    print('[F16_FRONTIER_ADVISOR]',json.dumps(advice,separators=(',',':')),flush=True)
