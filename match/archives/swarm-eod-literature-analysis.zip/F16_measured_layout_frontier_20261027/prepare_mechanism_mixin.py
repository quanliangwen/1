from pathlib import Path
import json,base64,hashlib,subprocess,ast
F=Path(__file__).resolve().parent
code="from pathlib import Path;import json,base64,hashlib;Q=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F16_measured_layout_frontier_20261027/observer_qualification');p=Q/'source/diagnostic_mixin.py';b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==json.loads((Q/'SOURCE_BINDING.json').read_text())['observer_source_files'][p.name];print(base64.b64encode(b).decode())"
raw=base64.b64decode(subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python','-'],input=code.encode()))
p=F/'qualified_diagnostic_mixin_reference.py';assert not p.exists();p.write_bytes(raw)
tree=ast.parse(raw.decode());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='DiagnosticMixin')
methods=ast.parse((F/'mechanism_observer_extensions.py').read_text()).body[0].body
names={n.name for n in methods if isinstance(n,ast.FunctionDef)}
cls.body=[n for n in cls.body if not(isinstance(n,ast.FunctionDef) and n.name in names)]+methods
fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_diag_state')
assert isinstance(fn.body[-1],ast.Return)
fn.body[-1:-1]=ast.parse("state['layout_preference'] = dict(getattr(self.memory,'layout_preference_diagnostics',{}))").body
source=ast.unparse(tree)+'\n';ast.parse(source)
p=F/'mechanism_diagnostic_mixin.py';assert not p.exists();p.write_text(source,encoding='utf-8')
(F/'MECHANISM_OBSERVER_BINDING.json').write_text(json.dumps({'qualified_base_sha256':hashlib.sha256(raw).hexdigest(),'mechanism_mixin_sha256':hashlib.sha256(source.encode()).hexdigest(),'scope':'Readonly target-selection/inventory-ack logging; original methods invoked exactly once. Not included in production ZIP.'},indent=2)+'\n',encoding='utf-8')
print('Mechanism observer prepared, no native game')
