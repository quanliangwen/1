"""Bounded current-map coverage tradeoffs; no official-score prediction."""
import math
import time
import numpy as np
import cv2
from swarm_rescue.solutions import trust_region_cover as trust
from swarm_rescue.solutions.team_coverage import path_costs
from swarm_rescue.solutions.farthest_wall_cover import owner_travel_budget
from swarm_rescue.solutions.sensed_layout_context import context,centre_field,root_memory

OBJECTIVES=('transport','delivery','occlusion')


def reference_cells(sources,limit=8):
    candidates=np.argwhere(sources)
    if not len(candidates):return []
    picked=[0];distances=np.full(len(candidates),np.inf)
    while len(picked)<min(limit,len(candidates)):
        delta=candidates-candidates[picked[-1]]
        distances=np.minimum(distances,np.sum(delta*delta,axis=1))
        distances[picked]=-np.inf
        index=int(np.argmax(distances))
        if not np.isfinite(distances[index]):break
        picked.append(index)
    return [tuple(map(int,candidates[i])) for i in picked]


def exposure_map(opaque,references,cell_size,deadline,horizon=300.):
    """Unknown is not opaque. Exclude every rounded endpoint occurrence."""
    result=np.zeros(opaque.shape,np.uint8);rr,cc=np.indices(opaque.shape)
    for row,col in references:
        if time.perf_counter()>=deadline:return None
        valid=(rr-row)**2+(cc-col)**2 <= (horizon/cell_size)**2+1e-8
        ends=np.column_stack(np.nonzero(valid));delta=ends-np.array([row,col])
        counts=np.maximum(2,2*np.abs(delta).max(axis=1)+1)
        ids=np.arange(int(counts.max()))[None,:]
        rs=np.rint(row+ids*delta[:,0,None]/(counts-1)[:,None]).astype(int)
        cs=np.rint(col+ids*delta[:,1,None]/(counts-1)[:,None]).astype(int)
        rs=np.clip(rs,0,opaque.shape[0]-1);cs=np.clip(cs,0,opaque.shape[1]-1)
        sample=(ids<counts[:,None]) & ~((rs==row)&(cs==col))
        sample &= ~((rs==ends[:,0,None])&(cs==ends[:,1,None]))
        clear=~np.any(opaque[rs,cs]&sample,axis=1)
        result[ends[clear,0],ends[clear,1]]+=1
    return result


def _spread_top(mask,primary,secondary,limit=4):
    ids=np.flatnonzero(mask.ravel())
    if not len(ids):return []
    order=ids[np.lexsort((ids,-secondary.ravel()[ids],-primary.ravel()[ids]))]
    selected=[];cells=[]
    for flat in order:
        cell=tuple(map(int,np.unravel_index(int(flat),mask.shape)))
        if any((cell[0]-r)**2+(cell[1]-c)**2<4 for r,c in cells):continue
        selected.append(int(flat));cells.append(cell)
        if len(selected)>=limit:break
    return selected


def frontier_advice(params,returned,prepared,rally=None,seconds=.8,objectives=OBJECTIVES,
                    centre_override=None):
    begun=time.perf_counter();deadline=begun+seconds;objectives=tuple(objectives)
    audit={'reason':'STARTED','proposals':{k:None for k in objectives},'funnel':[],
           'tested':0,'fields':0,'model_loss_fraction':.05,'deadline_reached':False}
    def finish(reason):
        audit.update(reason=reason,seconds=time.perf_counter()-begun,deadline_reached=time.perf_counter()>deadline)
        if audit['deadline_reached']:
            audit['reason']='deadline';audit['proposals']={k:None for k in objectives}
        return audit
    if any(k not in OBJECTIVES for k in objectives):return finish('invalid_objective')
    radius=float(params['radius']);epsilon=float(params.get('route_epsilon',32.))
    if not math.isfinite(radius) or radius<=0 or not math.isfinite(epsilon) or epsilon<0:return finish('invalid_numeric_context')
    if prepared is None:return finish('missing_exact_prepared')
    c=context(params,prepared)
    if c is None:return finish('invalid_context')
    pm=c['pm'];plans={int(k):[np.asarray(p,float).copy() for p in ps] for k,ps in returned.items()}
    if len(plans)>5 or sum(map(len,plans.values()))>10 or any(len(v)>2 for v in plans.values()):return finish('unsupported_size')
    clean={int(k):(np.asarray(p,float),int(n)) for k,(p,n) in params['agents'].items()
           if p is not None and np.asarray(p).shape==(2,) and np.isfinite(p).all()}
    points=[p for ps in plans.values() for p in ps]
    if not points:return finish('empty')
    if any(math.isnan(owner_travel_budget(params.get('travel_budget'),k)) or owner_travel_budget(params.get('travel_budget'),k)<0 for k,v in plans.items() if v):return finish('invalid_budget')
    if any(k not in clean or len(v)>clean[k][1] for k,v in plans.items() if v):return finish('invalid_owner')
    if any(p.shape!=(2,) or not np.isfinite(p).all() or not c['allowed'][pm.world_to_cell(p)] for p in points):return finish('invalid_incumbent_geometry')
    if any(np.linalg.norm(p-q)<c['separation']-1e-8 for i,p in enumerate(points) for q in points[i+1:]):return finish('invalid_incumbent_spacing')
    score0,confirmed0=c['scores'](plans);audit.update(incumbent_nominal=score0,incumbent_confirmed=confirmed0)
    if score0<=0 or confirmed0<=0:return finish('no_supported_incumbent')
    fields={}
    def field(point):
        cell=pm.world_to_cell(point)
        if not c['walkable'][cell]:return np.full(pm.shape,np.inf)
        if cell not in fields:
            if time.perf_counter()>=deadline:return np.full(pm.shape,np.inf)
            fields[cell]=path_costs(pm,c['walkable'],cell);audit['fields']=len(fields)
        return fields[cell]
    def length(k,ps):
        old=clean[k][0];value=0.
        for point in ps:value+=float(field(old)[pm.world_to_cell(point)]);old=point
        return value
    lengths={k:length(k,v) for k,v in plans.items() if v}
    if any(not np.isfinite(v) or v>owner_travel_budget(params.get('travel_budget'),k)+1e-6 for k,v in lengths.items()):return finish('invalid_incumbent_route')
    sources=np.zeros(pm.shape,bool)
    if centre_override is not None:sources=np.asarray(centre_override,bool).copy()
    else:
        raw=getattr(root_memory(params['memory']),'nonwall_mask',None)
        if raw is not None and np.asarray(raw).ndim==2 and np.asarray(raw).any():
            sources=cv2.resize(np.asarray(raw,np.float32),(pm.shape[1],pm.shape[0]),interpolation=cv2.INTER_AREA)>0
    if sources.shape!=pm.shape:return finish('invalid_centre_shape')
    sources &= c['walkable'];refs=reference_cells(sources)
    centre=None;visibility=None;return_field=None
    if 'transport' in objectives and sources.any():centre=centre_field(pm,c['walkable'],sources,deadline)
    if 'occlusion' in objectives and refs:
        visibility=exposure_map(c['confirmed']>0,refs,pm.CELL,deadline)
    if 'delivery' in objectives and rally is not None:
        rally=np.asarray(rally,float)
        if rally.shape==(2,) and np.isfinite(rally).all():
            contact=c['walkable'] & ((c['xx']-rally[0])**2+(c['yy']-rally[1])**2 < 40.**2-1e-8)
            if contact.any():return_field=centre_field(pm,c['walkable'],contact,deadline)
    audit.update(centre_sources=int(sources.sum()),visibility_references=[list(v) for v in refs],
                 delivery_contact_available=return_field is not None)
    if time.perf_counter()>=deadline:return finish('deadline')
    prefix_costs={};full_budget=params.get('full_budget',params.get('travel_budget'))
    for k,ps in plans.items():
        if not ps:continue
        prefix_costs[k]=0.
        if k in (params.get('reserved_prefixes') or {}):
            position,target=(np.asarray(p,float) for p in params['reserved_prefixes'][k])
            if not np.array_equal(clean[k][0],target):prefix_costs[k]=math.inf
            else:prefix_costs[k]=float(field(position)[pm.world_to_cell(target)])
    rc=int(math.ceil(radius/pm.CELL));ky,kx=np.mgrid[-rc:rc+1,-rc:rc+1]
    disk=((kx*pm.CELL)**2+(ky*pm.CELL)**2<=radius**2+1e-8).astype(np.float32)
    best_rank={};options=[]
    for k,ps in sorted(plans.items()):
        for slot,old in enumerate(ps):
            if time.perf_counter()>=deadline:return finish('deadline')
            old_cell=pm.world_to_cell(old)
            fixed=[p for owner,items in plans.items() for j,p in enumerate(items) if not(owner==k and j==slot)]
            fixed_mask=trust._coverage_mask(pm,fixed,radius)
            residual=c['values'].copy();residual[fixed_mask]=0
            residual_c=c['confirmed'].copy();residual_c[fixed_mask]=0
            old_mask=trust._coverage_mask(pm,[old],radius)
            old_gain=float(residual[old_mask].sum());old_cgain=float(residual_c[old_mask].sum())
            gain=cv2.filter2D(residual,-1,disk,borderType=cv2.BORDER_CONSTANT)
            cgain=cv2.filter2D(residual_c,-1,disk,borderType=cv2.BORDER_CONSTANT)
            nominal_grid=score0-old_gain+gain;confirmed_grid=confirmed0-old_cgain+cgain
            mask=c['allowed'].copy()
            mask &= (c['xx']-old[0])**2+(c['yy']-old[1])**2 <= (radius*params.get('trust_radius_ratio',1.25))**2+1e-8
            for p in fixed:mask &= (c['xx']-p[0])**2+(c['yy']-p[1])**2 >= c['separation']**2-1e-8
            row={'owner':k,'slot':slot,'basic_allowed_trust_spacing':int(mask.sum())}
            prev=clean[k][0] if slot==0 else ps[slot-1];nxt=ps[slot+1] if slot+1<len(ps) else None
            old_edge=float(field(prev)[old_cell])+(float(field(old)[pm.world_to_cell(nxt)]) if nxt is not None else 0.)
            routes=lengths[k]-old_edge+field(prev)
            if nxt is not None:routes=routes+field(nxt)
            cap=min(lengths[k]+float(params.get('route_epsilon',32.)),owner_travel_budget(params.get('travel_budget'),k))
            mask &= np.isfinite(routes)&(routes<=cap+1e-6);row['original_route_caps']=int(mask.sum())
            floors={}
            for loss in [0.,.005,.02,.05]:
                floors[loss]=mask & (nominal_grid>=(1-loss)*score0-1e-5)&(confirmed_grid>=(1-loss)*confirmed0-1e-5)
                row['coverage_floor_'+str(loss)]=int(floors[loss].sum())
            broad=floors[.05];mode_masks={};mode_metrics={}
            if centre is not None and np.isfinite(centre[old_cell]):
                delta=centre-float(centre[old_cell]);positive=mask & np.isfinite(delta)&(delta>=2*pm.CELL-1e-6)
                row['centre_progress_before_coverage']=int(positive.sum())
                for loss in floors:row['transport_floor_'+str(loss)]=int((positive&floors[loss]).sum())
                mode_masks['transport']=positive&broad;mode_metrics['transport']=delta
            if return_field is not None and np.isfinite(prefix_costs.get(k,math.inf)):
                back0=float(return_field[pm.world_to_cell(ps[-1])]);before_delivery=prefix_costs[k]+lengths[k]+back0
                after_delivery=prefix_costs[k]+routes+(return_field if slot==len(ps)-1 else back0)
                saving=before_delivery-after_delivery
                positive=mask & np.isfinite(after_delivery)&np.isfinite(saving)&(saving>=2*pm.CELL-1e-6)
                positive &= after_delivery<=owner_travel_budget(full_budget,k)+1e-6
                row['delivery_before_coverage']=int(positive.sum());row['delivery_floor_0.05']=int((positive&broad).sum())
                mode_masks['delivery']=positive&broad;mode_metrics['delivery']=saving
            if visibility is not None and int(visibility[old_cell])>=2:
                delta=int(visibility[old_cell])-visibility.astype(np.int16)
                positive=mask&(delta>=2);row['visibility_before_coverage']=int(positive.sum());row['visibility_floor_0.05']=int((positive&broad).sum())
                mode_masks['occlusion']=positive&broad;mode_metrics['occlusion']=delta
            audit['funnel'].append(row)
            memberships={}
            for mode in objectives:
                if mode in mode_masks:
                    for flat in _spread_top(mode_masks[mode],mode_metrics[mode],confirmed_grid,4):memberships.setdefault(flat,set()).add(mode)
            for flat,modes in sorted(memberships.items()):
                if audit['tested']>=128:break
                if time.perf_counter()>=deadline:return finish('deadline')
                cell=tuple(map(int,np.unravel_index(flat,pm.shape)));point=pm.cell_to_world(cell)
                proposal={owner:[p.copy() for p in items] for owner,items in plans.items()};proposal[k][slot]=point
                score,confirmed=c['scores'](proposal);audit['tested']+=1
                if score<.95*score0-1e-5 or confirmed<.95*confirmed0-1e-5:continue
                route=float(routes[cell])
                if not np.isfinite(route) or route>cap+1e-6:continue
                common={'owner':k,'slot':slot,'target':point.tolist(),'nominal_before':score0,'nominal_after':score,
                        'confirmed_before':confirmed0,'confirmed_after':confirmed,'RED_before':lengths[k],'RED_after':route,
                        'suffix_cap':owner_travel_budget(params.get('travel_budget'),k),'epsilon':float(params.get('route_epsilon',32.))}
                for mode in sorted(modes):
                    improvement=float(mode_metrics[mode][cell]);extra={}
                    if mode=='transport':extra={'centre_before':float(centre[old_cell]),'centre_after':float(centre[cell])}
                    elif mode=='delivery':
                        b0=prefix_costs[k]+lengths[k]+float(return_field[pm.world_to_cell(ps[-1])])
                        b1=prefix_costs[k]+route+(float(return_field[cell]) if slot==len(ps)-1 else float(return_field[pm.world_to_cell(ps[-1])]))
                        if not np.isfinite(b1) or b1>owner_travel_budget(full_budget,k)+1e-6 or b0-b1<2*pm.CELL-1e-6:continue
                        extra={'delivery_before':b0,'delivery_after':b1,'prefix_cost':prefix_costs[k],'full_cap':owner_travel_budget(full_budget,k)}
                    else:extra={'exposure_before':int(visibility[old_cell]),'exposure_after':int(visibility[cell])}
                    rank=(improvement,confirmed-confirmed0,score-score0,lengths[k]-route,-k,-slot,-flat)
                    if mode not in best_rank or rank>best_rank[mode]:
                        best_rank[mode]=rank;audit['proposals'][mode]={**common,**extra,'improvement':improvement,
                            'alternative':{str(owner):[p.tolist() for p in items] for owner,items in proposal.items()}}
    audit['prefix_costs']=prefix_costs
    audit['positive_modes']=[k for k,v in audit['proposals'].items() if v is not None]
    return finish('compared_model_frontier')
