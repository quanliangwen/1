from pathlib import Path
import sys,json,base64,subprocess,shlex
F=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['Q01','Q02','Q03']
guard=(F/v/'STRICT_PACKAGE_GUARD.json').read_bytes();assert json.loads(guard)['status']=='PASS'
payload={'version':v,'guard':base64.b64encode(guard).decode()}
code=r'''
from pathlib import Path
import sys,json,base64,hashlib,ast,fcntl,shutil,subprocess,os,datetime
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F16_measured_layout_frontier_20261027'
d=json.load(sys.stdin);v=d['version'];C=F/v;B=json.loads((C/'BUILD.json').read_text());A=json.loads((F/'DIRECTION_ADMISSION.json').read_text());assert v in A['admitted_order']
assert not(F/'FIRST_NATIVE_ERROR.json').exists() and not(F/'STOP_REQUESTED').exists()
for prior in A['admitted_order'][:A['admitted_order'].index(v)]:
 perf=F/(prior+'_PERF')
 if perf.exists():
  state=json.loads((perf/'STATUS.json').read_text());assert state['status'] in ['EARLY_SCREENED_VALID_SCORE','COMPLETE_ALL_EIGHT_PAIRED_GROUPS']
  p=Path('/proc')/str(state.get('pid',0))/'stat';assert not p.exists() or p.read_text().split()[2]=='Z'
 else:assert json.loads((F/(prior+'_DIAG')/'MECHANISM_REVIEW.json').read_text())['start_five_map_now'] is False
G0=F/'PARENT_M04_DIAG';s=json.loads((G0/'STATUS.json').read_text());p=Path('/proc')/str(s['pid'])/'stat';assert not p.exists() or p.read_text().split()[2]=='Z'
assert json.loads((G0/'CLIENT_FIRST_RAW_REVIEW.json').read_text())['valid']
activity=json.loads((R/'solver_study/heuristic_20261016.json').read_text());assert not activity.get('active_processes') and not activity.get('current_formal_active')
with (R/'solver_study/serial_evaluation.lock').open('a+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(Path(B['zip']))==B['zip_sha256']
assert json.loads((C/'CONTRACT_RESULT.json').read_text())['status']=='PASS'
guard=base64.b64decode(d['guard']);gd=json.loads(guard);assert gd['status']=='PASS' and gd['sha256']==B['zip_sha256']
assert not(C/'STRICT_PACKAGE_GUARD.json').exists();(C/'STRICT_PACKAGE_GUARD.json').write_bytes(guard)
Q=C/'diagnostic_qualification';qual=json.loads((Q/'QUALIFICATION_RESULT.json').read_text());assert qual['status']=='PASS' and qual['production_zip_sha256']==B['zip_sha256']
binding=json.loads((Q/'SOURCE_BINDING.json').read_text());assert {p.name:sha(p) for p in (Q/'source').iterdir() if p.is_file()}==binding['source_files']
G=F/(v+'_DIAG');assert not G.exists();G.mkdir();S=G/'source';shutil.copytree(Q/'source',S)
blue=Path(json.loads((H/'F07_evidence_three_directions_20261026/infrastructure/PREDECLARATION.json').read_text())['blue_workspace'])
W=R/'experiments/target90_20261012/official_workspaces'/('f16diag_20261027_'+v);assert not W.exists()
shutil.copytree(blue,W,ignore=shutil.ignore_patterns('solutions','__pycache__','*.pyc','.git','.pytest_cache'));sol=W/'src/swarm_rescue/solutions';sol.mkdir()
for p in S.iterdir():shutil.copy2(p,W/'req.txt' if p.name=='req.txt' else sol/p.name)
stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
stage={'utc':stamp,'workspace':str(W),'source_files':{p.name:sha(p) for p in S.iterdir() if p.is_file()},'production_source':B['source_files'],'production_candidate_sha256':B['zip_sha256'],'observer_qualification_sha256':sha(Q/'QUALIFICATION_RESULT.json'),'not_for_performance_ranking':True}
(G/'STAGING.json').write_text(json.dumps(stage,indent=2)+'\n')
(G/'PREDECLARATION.json').write_text(json.dumps({'utc':stamp,'candidate_id':v,'source_zip_sha256':B['zip_sha256'],'kind':'ONE_FRESH_MAP04_RED_ACTUAL_PREFERENCE_MECHANISM','map':'Map04','seed':None,'no_retry':True,'BLUE':False,'ranking':False,'new_algorithm':True,'native_qual_sha256':sha(Q/'QUALIFICATION_RESULT.json'),'production_contract_sha256':sha(C/'CONTRACT_RESULT.json'),'strict_package_guard_sha256':sha(C/'STRICT_PACKAGE_GUARD.json'),'mechanism':'Observe actual preference, own target adoption and inventory-decrease ack. Stricter effectiveness check before frozen original-five; no partial-score/speed ranking.'},indent=2)+'\n')
shutil.copy2(Q/'preflight.py',G/'preflight.py')
entry=json.loads((F/'PARENT_OPERATORS.json').read_text())['PARENT_M04'];raw=base64.b64decode(entry['runner_base64']);assert hashlib.sha256(raw).hexdigest()==entry['sha256']
runner=raw.decode().replace('PARENT_M04',v).replace("'new_algorithm':False","'new_algorithm':True").replace('PARENT_OBSERVER_NO_PERFORMANCE_RANKING','CANDIDATE_MECHANISM_NO_PERFORMANCE_RANKING')
runner=runner.replace("'F16_FRONTIER_ADVISOR']","'F16_PREFERENCE_APPLIED','F16_TARGET_SELECTED','F16_DROP_ACK']");assert 'F16_DROP_ACK' in runner;ast.parse(runner)
p=F/('run_'+v+'_diagnostic.py');assert not p.exists();p.write_text(runner)
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with (F/(v+'_diagnostic_coordinator.log')).open('x') as log:proc=subprocess.Popen([str(R/'.venv/bin/python'),'-u',str(p)],cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
receipt={'utc':stamp,'candidate_id':v,'pid':proc.pid,'starttime_ticks':(Path('/proc')/str(proc.pid)/'stat').read_text().split()[21],'candidate_sha256':B['zip_sha256'],'runner_sha256':sha(p),'only_one_RED_diagnostic':True,'objective':B['objective']}
(G/'LAUNCH_COORDINATOR.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
'''
r=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps(payload).encode())
p=F/(v+'_DIAGNOSTIC_LAUNCH_RECEIPT.json');assert not p.exists();p.write_bytes(r);print(r.decode())
