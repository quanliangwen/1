class ExtensionMethods:
    def _sync_placement(self,step):
        pending=self.pending_drop
        result=super()._sync_placement(step)
        stock=int(self.carried_bombs_count())
        if pending is not None and stock<int(pending[0]):
            import json
            print('[F16_DROP_ACK]',json.dumps({'owner':int(self.identifier or 0),'step':int(step),
                'pending_step':int(pending[2]),'stock_at_command':int(pending[0]),'stock_after':stock,
                'position':np.asarray(pending[1],float).tolist()},separators=(',',':')),flush=True)
        return result

    def _plan_route(self,step,returning,peer_goals):
        started=time.perf_counter()
        try:
            result=super()._plan_route(step,returning,peer_goals)
            goal=self.placement_goal
            if goal is None:self._diag_selected_identity=None
            else:
                identity=(int(self.carried_bombs_count()),int(getattr(self,'assignment_since',-1000)),float(goal[0]),float(goal[1]))
                if identity!=getattr(self,'_diag_selected_identity',None):
                    self._diag_selected_identity=identity
                    import json
                    print('[F16_TARGET_SELECTED]',json.dumps({'owner':int(self.identifier or 0),'step':int(step),
                        'stock':identity[0],'assignment_since':identity[1],'goal':np.asarray(goal,float).tolist()},separators=(',',':')),flush=True)
            return result
        finally:self._diag_record_cost('route_plan_chain',started)
