import ast
import heapq
import inspect
import math
import time
from pathlib import Path
import numpy as np
import cv2
from swarm_rescue.solutions import trust_region_cover as trust
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
from swarm_rescue.solutions.team_coverage import observed_wall_values, path_costs
from swarm_rescue.solutions.farthest_wall_cover import owner_travel_budget

def root_memory(memory):
    while isinstance(memory, GeometryPlanningMemory):
        memory = memory._memory
    return memory

def clone_view(view):
    result = object.__new__(GeometryPlanningMemory)
    result.__dict__.update(view.__dict__)
    result.free = view.free.copy()
    result._blocked = view.blocked()
    cached = getattr(view, '_coverage_values_cache', None)
    if cached is not None:
        result._coverage_values_cache = (cached[0], cached[1].copy(), cached[2].copy())
    return result

def context(params, prepared):
    memory = params['memory']
    radius = float(params['radius'])
    pm = clone_view(prepared) if prepared is not None else GeometryPlanningMemory(memory)
    confirmed, solids = observed_wall_values(pm, radius, return_solids=True)
    confirmed = np.asarray(confirmed, np.float32).copy()
    values = np.maximum(confirmed, trust._repeat_hit_support(pm))
    walkable = pm.free & ~pm.blocked() & ~solids
    allowed = walkable.copy()
    rr, cc = np.indices(pm.shape)
    xx = (cc + 0.5) * pm.CELL - pm.width / 2
    yy = pm.height / 2 - (rr + 0.5) * pm.CELL
    mask = params.get('forbidden_mask')
    if mask is not None:
        if np.asarray(mask).shape != pm.shape:
            return None
        allowed &= ~np.asarray(mask, bool)
    for p, r in params.get('forbidden_points', ()):
        allowed[(xx - p[0]) ** 2 + (yy - p[1]) ** 2 < float(r) ** 2] = False
    separation = 40.0 + 0.71 * pm.CELL
    for p in params['drops']:
        squared = (xx - p[0]) ** 2 + (yy - p[1]) ** 2
        values[squared <= radius ** 2 + 1e-08] = 0
        confirmed[squared <= radius ** 2 + 1e-08] = 0
        allowed[squared < separation ** 2] = False

    def scores(plan):
        mask = trust._coverage_mask(pm, [p for ps in plan.values() for p in ps], radius)
        return (float(values[mask].sum()), float(confirmed[mask].sum()))
    return {'pm': pm, 'values': values, 'confirmed': confirmed, 'walkable': walkable, 'allowed': allowed, 'xx': xx, 'yy': yy, 'separation': separation, 'scores': scores}

def centre_field(pm, walkable, sources, deadline):
    costs = np.full(pm.shape, np.inf)
    tentative = np.full(pm.shape, np.inf)
    queue = []
    for r, c in zip(*np.nonzero(sources)):
        tentative[r, c] = 0.0
        heapq.heappush(queue, (0.0, int(r), int(c)))
    popped = 0
    while queue and popped < 8192:
        if time.perf_counter() >= deadline:
            return None
        distance, r, c = heapq.heappop(queue)
        if distance > tentative[r, c] or np.isfinite(costs[r, c]):
            continue
        costs[r, c] = distance
        popped += 1
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)):
            nr, nc = (r + dr, c + dc)
            if not (0 <= nr < pm.shape[0] and 0 <= nc < pm.shape[1]) or not walkable[nr, nc]:
                continue
            if dr and dc and (not walkable[r + dr, c] or not walkable[r, c + dc]):
                continue
            proposal = distance + pm.CELL * (math.sqrt(2.0) if dr and dc else 1.0)
            if proposal < tentative[nr, nc]:
                tentative[nr, nc] = proposal
                heapq.heappush(queue, (proposal, nr, nc))
    return costs
