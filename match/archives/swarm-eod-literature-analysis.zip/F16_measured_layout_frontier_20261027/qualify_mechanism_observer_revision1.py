from pathlib import Path
import sys,json,base64,subprocess,shlex
F=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['Q01','Q02','Q03']
payload={'version':v,'mixin':base64.b64encode((F/'mechanism_diagnostic_mixin_revision1.py').read_bytes()).decode(),
         'binding':json.loads((F/'MECHANISM_OBSERVER_BINDING_REV1.json').read_text()),'test':base64.b64encode((F/'mechanism_observer_tests.py').read_bytes()).decode()}
code=r'''
from pathlib import Path
import sys,json,base64,hashlib,ast,shutil,subprocess,os
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=H/'F16_measured_layout_frontier_20261027'
d=json.load(sys.stdin);v=d['version'];C=F/v;B=json.loads((C/'BUILD.json').read_text());contract=json.loads((C/'CONTRACT_RESULT.json').read_text());assert contract['status']=='PASS' and contract['source_zip_sha256']==B['zip_sha256']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(Path(B['zip']))==B['zip_sha256']
assert {p.name:sha(p) for p in (C/'source').iterdir() if p.is_file()}==B['source_files']
assert sha(F/'observer_qualification/source/diagnostic_mixin.py')==d['binding']['qualified_base_sha256']
raw=base64.b64decode(d['mixin']);assert hashlib.sha256(raw).hexdigest()==d['binding']['mechanism_mixin_sha256']
Q=C/'diagnostic_qualification';assert not Q.exists();Q.mkdir();S=Q/'source';shutil.copytree(C/'source',S)
(S/'diagnostic_mixin.py').write_bytes(raw);p=S/'my_drone_eval.py';s=p.read_text();assert s.count('class MyDroneEval(')==1
s=s.replace('class MyDroneEval(','class BaseParent(',1)+"\nfrom swarm_rescue.solutions.diagnostic_mixin import DiagnosticMixin\nclass MyDroneEval(DiagnosticMixin,BaseParent):\n    F16_MODE='MECHANISM'\n";p.write_text(s)
for p in S.glob('*.py'):ast.parse(p.read_text())
(Q/'PRODUCTION_BINDING.json').write_text(json.dumps(B,indent=2)+'\n');binding={'source_files':{p.name:sha(p) for p in S.iterdir() if p.is_file()},'production_zip_sha256':B['zip_sha256'],'mechanism_mixin_sha256':hashlib.sha256(raw).hexdigest()};(Q/'SOURCE_BINDING.json').write_text(json.dumps(binding,indent=2)+'\n')
blue=Path(json.loads((H/'F07_evidence_three_directions_20261026/infrastructure/PREDECLARATION.json').read_text())['blue_workspace'])
W=Q/'workspace';shutil.copytree(blue,W,ignore=shutil.ignore_patterns('solutions','__pycache__','*.pyc','.git','.pytest_cache'));sol=W/'src/swarm_rescue/solutions';sol.mkdir()
for p in S.iterdir():shutil.copy2(p,W/'req.txt' if p.name=='req.txt' else sol/p.name)
(Q/'STAGING.json').write_text(json.dumps({'workspace':str(W),'source_files':binding['source_files']})+'\n')
p=Q/'mechanism_observer_tests.py';p.write_bytes(base64.b64decode(d['test']));ast.parse(p.read_text());shutil.copy2(F/'observer_qualification/preflight.py',Q/'preflight.py')
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with (Q/'first_console.log').open('x') as log:r=subprocess.run(['bash',str(R/'run_server.sh'),'-u',str(p)],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
report=json.loads((Q/'FIRST_RESULT.json').read_text())
if r.returncode!=0 or report['status']!='PASS':print(json.dumps({'version':v,'status':report['status'],'checks':len(report['checks']),'error':report.get('error')}));raise SystemExit(1)
with (Q/'preflight_first_console.log').open('x') as log:r=subprocess.run(['bash',str(R/'run_server.sh'),'-u',str(Q/'preflight.py')],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert r.returncode==0 and json.loads((Q/'PREFLIGHT.json').read_text())['status']=='PASS'
result={'status':'PASS','version':v,'checks':len(report['checks']),'preflight_first_pass':True,'production_zip_sha256':B['zip_sha256'],'source_binding_sha256':sha(Q/'SOURCE_BINDING.json'),'mechanism_mixin_sha256':hashlib.sha256(raw).hexdigest(),'game_rounds':0}
(Q/'QUALIFICATION_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
'''
r=subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps(payload).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
p=F/(v+'_mechanism_observer_revision1_console.txt');assert not p.exists();p.write_bytes(r.stdout+r.stderr);print((r.stdout+r.stderr).decode(errors='replace'));raise SystemExit(r.returncode)
