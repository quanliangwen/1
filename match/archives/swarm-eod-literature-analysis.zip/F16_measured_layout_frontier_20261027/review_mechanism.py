from pathlib import Path
import sys,json,math,datetime,hashlib,subprocess,shlex
F=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['Q01','Q02','Q03'];G=F/(v+'_DIAG');C=F/v
assert not(G/'MECHANISM_REVIEW.json').exists()
assert json.loads((G/'CLIENT_FIRST_RAW_REVIEW.json').read_text(encoding='utf-8'))['valid']
B=json.loads((C/'BUILD.json').read_text(encoding='utf-8'));contract=json.loads((C/'CONTRACT_RESULT.json').read_text(encoding='utf-8'))
assert contract['status']=='PASS' and contract['source_zip_sha256']==B['zip_sha256']
assert json.loads((G/'STAGING.json').read_text(encoding='utf-8'))['production_candidate_sha256']==B['zip_sha256']
guard=json.loads((C/'STRICT_PACKAGE_GUARD.json').read_text(encoding='utf-8'));assert guard['status']=='PASS' and guard['sha256']==B['zip_sha256']
E=json.loads((G/'EVENTS.json').read_text(encoding='utf-8'));R=json.loads((G/'RESULT.json').read_text(encoding='utf-8'));applied=E['F16_PREFERENCE_APPLIED'];matches=[]
for a in applied:
 assert a['objective']==B['objective'];p=a['proof'];owner=p['owner'];target=p['target']
 assert p['nominal_after']>=.95*p['nominal_before']-1e-5 and p['confirmed_after']>=.95*p['confirmed_before']-1e-5
 assert p['RED_after']<=p['RED_before']+32.+1e-6 and p['RED_after']<=p['suffix_cap']+1e-6
 targets=[x for x in E['F16_TARGET_SELECTED'] if x['owner']==owner and x['step']>=a['step'] and math.dist(x['goal'],target)<=1.]
 acks=[x for x in E['F16_DROP_ACK'] if x['owner']==owner and x['pending_step']>=a['step'] and math.dist(x['position'],target)<=30.
       and any(t['step']<=x['pending_step'] for t in targets)]
 matches.append({'application_owner':a['owner'],'application_step':a['step'],'target_owner':owner,'target':target,'proof':p,'actual_target_adoptions':targets,'actual_matching_inventory_acks':acks})
admit=any(x['actual_target_adoptions'] and x['actual_matching_inventory_acks'] for x in matches)
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':v,'start_five_map_now':admit,'source_zip_sha256':B['zip_sha256'],
   'qualification_checks':len(contract['checks']),'package_guard_sha256':hashlib.sha256((C/'STRICT_PACKAGE_GUARD.json').read_bytes()).hexdigest(),
   'applications':len(applied),'adopted_applications':sum(bool(x['actual_target_adoptions']) for x in matches),
   'executed_and_acknowledged_applications':sum(bool(x['actual_matching_inventory_acks']) for x in matches),'matches':matches,
   'stock':[R['row']['placed'],R['row']['expected']],'diagnostic_steps':R['row']['timestep'],'diagnostic_seconds_not_performance':R['row']['walltime'],
   'reason':('Qualified preference actually adopted and inventory-decrease acknowledged near its own estimated target; enter frozen original-five vsK01. Not a score/causal inference.' if admit else
             'No adopted preference reached a matching real inventory-decrease acknowledgement; do not spend full-five on an unexecuted model change. Preserve valid single-map result, not a general score inferiority claim.'),
   'ack_scope':'Only own public pending pose and inventory callback, <=30px geometric match AFTER actual goal selection. No true bomb/peer/private state or replay.',
   'not_performance_or_causal_claim':True}
p=G/'MECHANISM_REVIEW.json';p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
remote="from pathlib import Path;import sys;p=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F16_measured_layout_frontier_20261027')/"+repr(v+'_DIAG')+"/'MECHANISM_REVIEW.json';assert not p.exists();p.write_bytes(sys.stdin.buffer.read())"
subprocess.run(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(remote)],input=p.read_bytes(),check=True)
print(json.dumps({k:d[k] for k in ['candidate_id','start_five_map_now','applications','adopted_applications','executed_and_acknowledged_applications','stock','reason']}))
