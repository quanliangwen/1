"""Execute original method AST on fixed fake state, with no SDK/simulator imports."""
from pathlib import Path
import ast,json,sys,traceback,hashlib
import numpy as np
Q=Path(sys.argv[1]);P=Path(sys.argv[2]);assert not(Q/'FIRST_RESULT.json').exists()
report={'status':'STARTED','checks':[],'game_rounds':0,'historical_arrays_loaded':0}
def check(n,v):
 assert v,n
 report['checks'].append(n)
try:
 texts={n:(P/n).read_text() for n in ['fleet_endpoint_repair.py','fleet_mission.py']}
 records=[];plan={0:[np.array([64.,0.]),np.array([128.,64.])]}
 def planner(memory,agents,*args,**kwargs):
  records.append({k:int(v[1]) for k,v in agents.items()})
  return {k:[p.copy() for p in ps] for k,ps in plan.items()}
 scope={'np':np,'plan_team_coverage':planner,'plan_team_coverage_lns':planner}
 for name,clsname in [('fleet_endpoint_repair.py','FleetEndpointRepairMixin'),('fleet_mission.py','FleetCoverageMixin')]:
  tree=ast.parse(texts[name]);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==clsname)
  exec(compile(ast.Module(body=[cls],type_ignores=[]),str(P/name),'exec'),scope)
 class RejectionBase:
  def _reject_assignment(self,step,point):self.assignment_goal=None;self.assignment_inventory=None
 class Repair(scope['FleetEndpointRepairMixin'],RejectionBase):pass
 def repair_fixture():
  d=object.__new__(Repair);d.identifier=0;d.pose=np.zeros(2);d.drop_records={};d.assignment_reports={};d.assignment_since=-1000
  d.carried_bombs_count=lambda:2;d._other_live_placement_goals=lambda step:[];d._remaining_steps=lambda:1000.;d.blast_radius=96.
  d._own_assignment_report=lambda step:(step,2,d.assignment_goal,d.assignment_since)
  def route(position,destination=None):return (None,None) if np.array_equal(destination,[0.,0.]) else ([np.asarray(destination).copy()],np.asarray(destination).copy())
  d.memory=type('FixedFakeMemory',(),{'CELL':16.})()
  d.memory.route=route
  return d
 first=np.array([64.,0.]);tail_a=np.array([128.,64.]);tail_b=np.array([192.,64.])
 plan={0:[first.copy(),tail_a.copy()]};a=repair_fixture();a._reject_assignment(1000,np.zeros(2))
 plan={0:[first.copy(),tail_b.copy()]};b=repair_fixture();b._reject_assignment(1000,np.zeros(2))
 check('repair_requests_two_inventory_slots',records[-1]=={0:2} and records[-2]=={0:2})
 check('repair_consumes_only_first_endpoint',np.array_equal(a.assignment_goal,first) and np.array_equal(b.assignment_goal,first))
 check('tail_change_is_not_executed_by_repair',np.array_equal(a._endpoint_repair_route[1],b._endpoint_repair_route[1]))
 Fleet=scope['FleetCoverageMixin']
 def fleet_fixture():
  d=object.__new__(Fleet);d.memory=object();d.identifier=0;d.fleet_states={0:(1000,np.zeros(2),2)};d.assignment_reports={};d.fleet_plan=None;d.fleet_signature=None
  d.assignment_rejections={};d.drop_records={};d.elapsed_walltime=0.;d.walltime_limit=180.;d._remaining_steps=lambda:1000.;d.blast_radius=96.;d.limit=7200
  return d
 plan={0:[first.copy(),tail_b.copy()]};d=fleet_fixture();d._build_fleet_plan(1000)
 check('fleet_stores_both_supplied_targets',len(d.fleet_plan[2][0][1])==2 and np.array_equal(d.fleet_plan[2][0][1][1],tail_b))
 d=fleet_fixture();d.fleet_plan=(900,0,{0:(2,[first.copy(),tail_a.copy()])});active={0:(np.zeros(2),1)}
 d.assignment_reports={0:(1000,1,None,850)}
 reserved=d._reserved_first_goals(1000,active)
 check('fresh_none_can_discard_post_drop_suffix',0 not in reserved)
 d.assignment_reports={0:(1000,1,None,-1000)};reserved=d._reserved_first_goals(1000,active)
 check('unacknowledged_none_preserves_suffix',0 in reserved and np.array_equal(reserved[0],tail_a))
 d.assignment_reports={0:(1000,1,tail_a.copy(),950)};reserved=d._reserved_first_goals(1000,active)
 check('explicit_next_goal_ack_preserves_suffix',0 in reserved and np.array_equal(reserved[0],tail_a))
 report.update(status='PASS',source_files_sha256={n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in texts},
    findings=['Actual endpoint repair asks for all remaining inventory but consumes only[0]; changing only tail does not change its executed endpoint.',
              'Actual full fleet planner stores all targets, so these two consumers have different semantics.',
              'Fresh None report after an old plan can release its post-drop suffix; new preference must not assume that an uncommitted tail survives. This is protocol ambiguity, not proof of a universally wrong baseline.'],
    limits='Fixed synthetic method-state proof only. Does not establish which actual Q02 invocation used which consumer, nor a causal game score effect. No real controller, SDK map, observations, arrays or game replay.')
except BaseException:report.update(status='FAIL',error=traceback.format_exc());raise
finally:
 (Q/'FIRST_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'checks':len(report['checks']),'error':report.get('error'),'findings':report.get('findings')}))
