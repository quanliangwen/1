    import inspect
    import numpy.random.mtrand
    check('actual_cv_operation',cv2.resize(np.arange(16,dtype=np.uint8).reshape(4,4),(2,2)).shape==(2,2))
    abi={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS',
         'submission_zip_sha256':build['zip_sha256'],'payload_files_sha256':payload_files,'team_number':615,
         'distribution_versions':{n:importlib.metadata.version(n) for n in ['numpy','opencv-contrib-python','pandas']},
         'numeric_random_pandas_cv_operations':'PASS','sdk_launcher_and_stats_import':'PASS',
         'critical_module_paths':{'numpy':str(np.__file__),'numpy.random.mtrand':str(np.random.mtrand.__file__),'pandas':str(pandas.__file__),'cv2':str(cv2.__file__)},
         'sdk_module_paths':{'Launcher':inspect.getfile(Launcher),'StatsComputation':inspect.getfile(StatsComputation),'TeamInfo':inspect.getfile(TeamInfo)},
         'python_executable':sys.executable,'python_version':sys.version,'extraction_workspace':str(W),
         'environment_note':'Readonly reuse of existing dependency_venv package paths with native interpreter; not a new installation and not the official website container.',
         'official_container_verified':False}
    assert not(F/'RUNTIME_ABI_RECEIPT.json').exists()
    (F/'RUNTIME_ABI_RECEIPT.json').write_text(json.dumps(abi,indent=2)+'\n')
