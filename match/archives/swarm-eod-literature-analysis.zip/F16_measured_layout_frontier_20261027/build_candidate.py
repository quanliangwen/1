from pathlib import Path
import sys,json,base64,subprocess,shlex
F=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['Q01','Q02','Q03']
payload={'version':v,'policy':base64.b64encode((F/'layout_preference.py').read_bytes()).decode()}
code=r"""
from pathlib import Path
import sys,json,base64,hashlib,ast,shutil,zipfile,yaml,datetime
R=Path('/home/junhao/quan/parallel_test_solver/match');F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F16_measured_layout_frontier_20261027'
d=json.load(sys.stdin);v=d['version'];objectives={'Q01':'transport','Q02':'delivery','Q03':'occlusion'};versions={'Q01':18,'Q02':19,'Q03':20}
A=json.loads((F/'DIRECTION_ADMISSION.json').read_text());assert v in A['admitted_order'] and A['gates'][v]
assert not(F/'FIRST_NATIVE_ERROR.json').exists() and not(F/'STOP_REQUESTED').exists()
assert json.loads((F/'PARENT_M04_DIAG/CLIENT_FIRST_RAW_REVIEW.json').read_text())['valid']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();P=json.loads((F/'PREDECLARATION.json').read_text())['parent']
assert sha(Path(P['zip']))==P['zip_sha256'] and {p.name:sha(p) for p in (Path(P['path'])/'source').iterdir() if p.is_file()}==P['source_files']
Q=F/'observer_qualification';binding=json.loads((Q/'SOURCE_BINDING.json').read_text());assert json.loads((Q/'QUALIFICATION_RESULT.json').read_text())['status']=='PASS'
G=F/v;assert not G.exists();G.mkdir();S=G/'source';shutil.copytree(Path(P['path'])/'source',S)
p=S/'trust_region_cover.py';s=p.read_text();marker='trust_radius_ratio=TRUST_RADIUS_RATIO,_prepared=None):';assert s.count(marker)==1
s=s.replace(marker,'trust_radius_ratio=TRUST_RADIUS_RATIO,_prepared=None,_context_out=None):')
marker='    pm=GeometryPlanningMemory(memory) if _prepared is None else _prepared\n';assert s.count(marker)==1;s=s.replace(marker,marker+'    if _context_out is not None: _context_out.append(pm)\n');p.write_text(s)
p=S/'team_coverage_lns.py';s=p.read_text();marker='    prepared=None\n';assert s.count(marker)==1;s=s.replace(marker,'    _full_budget=travel_budget\n    prepared=None\n')
marker='    return refine_trust_region(memory,agents,drops,radius,base,travel_budget=travel_budget,forbidden_points=forbidden_points,forbidden_mask=forbidden_mask,_prepared=prepared)';assert s.count(marker)==1
s=s.replace(marker,'''    _context=[]
    result=refine_trust_region(memory,agents,drops,radius,base,travel_budget=travel_budget,forbidden_points=forbidden_points,forbidden_mask=forbidden_mask,_prepared=prepared,_context_out=_context)
    from swarm_rescue.solutions.layout_preference import apply_preference
    return apply_preference(memory,agents,drops,radius,result,_full_budget,travel_budget,reserved_prefixes,
                            forbidden_points,forbidden_mask,_context[-1] if _context else prepared)''');p.write_text(s)
p=S/'my_drone_eval.py';s=p.read_text();marker='    CLEAR_NONWALL_HITS=True';assert s.count(marker)==1
s=s.replace(marker,marker+"\n    LAYOUT_PREFERENCE="+repr(objectives[v])+'''

    def _build_fleet_plan(self,step):
        self.memory._layout_preference_objective=self.LAYOUT_PREFERENCE
        self.memory._layout_preference_rally=None if self.rally is None else self.rally.copy()
        return super()._build_fleet_plan(step)
''');p.write_text(s)
for name in ['layout_frontier.py','sensed_layout_context.py']:
 assert sha(Q/'source'/name)==binding['observer_source_files'][name];shutil.copy2(Q/'source'/name,S/name)
(S/'layout_preference.py').write_bytes(base64.b64decode(d['policy']))
for p in S.glob('*.py'):ast.parse(p.read_text())
info=yaml.safe_load((S/'team_info.yml').read_text());assert type(info['team_number']) is int and info['team_number']==615
assert {s.strip() for s in (S/'req.txt').read_text().splitlines() if s.strip()}=={'numpy==1.26.4','pandas==2.2.3','opencv-contrib-python==4.11.0.86'}
files={p.name:sha(p) for p in S.iterdir() if p.is_file()};changed=sorted(n for n in files if n not in P['source_files'] or files[n]!=P['source_files'][n])
assert changed==sorted(['trust_region_cover.py','team_coverage_lns.py','my_drone_eval.py','layout_frontier.py','sensed_layout_context.py','layout_preference.py'])
assert not any(n.startswith(('diagnostic_','frontier_observer','helper_test','observer_test')) for n in files)
z=G/('team615_red_v%02d.zip'%versions[v]);assert not z.exists()
with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED) as out:
 for p in sorted(S.iterdir()):out.write(p,p.name)
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_id':v,'path':str(G),'zip':str(z),'zip_sha256':sha(z),'source_files':files,'changed_files':changed,
         'parent_id':'K01','parent_zip_sha256':P['zip_sha256'],'declaration_sha256':sha(F/'PREDECLARATION.json'),'admission_sha256':sha(F/'DIRECTION_ADMISSION.json'),
         'objective':objectives[v],'production_limits':A['production_limits_frozen_before_source'],'release_status':'INTERNAL_NOT_RELEASED',
         'scope':'One current-model site preference, max1success/ownmemory,2attempts>=120apart,.8ssoft,95percentnominal/confirmed floors, original32epsilon/fullcaps. Geometry/private state/SDK unchanged.'}
(G/'BUILD.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
"""
r=subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps(payload).encode())
p=F/(v+'_BUILD.json');assert not p.exists();p.write_bytes(r);d=json.loads(r);print(json.dumps({k:d[k] for k in ['candidate_id','objective','zip_sha256','changed_files','release_status']}))
