from pathlib import Path
import ast,json,base64,hashlib,subprocess,shlex
F=Path(__file__).resolve().parent;O=F.parent/'F15_delivery_and_transport_20261027'
e=json.loads((O/'PARENT_OPERATORS.json').read_text())['PARENT_M04'];s=base64.b64decode(e['runner_base64']).decode().replace('F15','F16')
s=s.replace("'F16_COURIER_ADVISOR','F16_LAYOUT_ADVISOR'","'F16_FRONTIER_ADVISOR'");ast.parse(s)
bundle={'PARENT_M04':{'runner_base64':base64.b64encode(s.encode()).decode(),'sha256':hashlib.sha256(s.encode()).hexdigest(),'map':'Map04'}}
maps={'PARENT_M04_DIAG':'Map04','Q01_DIAG':'Map04','Q02_DIAG':'Map04','Q03_DIAG':'Map04'}
for n,d in [('PARENT_OPERATORS.json',bundle),('DIAGNOSTIC_MAP_BINDINGS.json',maps)]:
 assert not(F/n).exists();(F/n).write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
for n in ['sync_metadata.py','verify_diagnostic_raw.py','read_live.py']:
 s=(O/n).read_text().replace(O.name,F.name).replace('F15','F16')
 if n=='verify_diagnostic_raw.py':s=s.replace("['PARENT_M05_DIAG', 'PARENT_M04_DIAG', 'P01_DIAG', 'P02_DIAG', 'P03_DIAG']",repr(list(maps)))
 if n=='read_live.py':
  a=s.index("p=F/('PARENT_M04_DIAG");b=s.index('print(json.dumps(out))',a)
  s=s[:a]+'''p=F/'PARENT_M04_DIAG/Map04_red/console.log'
if p.exists():
 lines=p.read_text(errors='replace').splitlines()
 advisors=[json.loads(x[len('[F16_FRONTIER_ADVISOR] '):]) for x in lines if x.startswith('[F16_FRONTIER_ADVISOR] ')]
 out['frontier_advice']=[{k:a.get(k) for k in ['owner','step','probe','reason','positive_modes','tested','seconds','deadline_reached','proposals','funnel']} for a in advisors]
 ticks=[json.loads(x[len('[F16_DIAG_TICK] '):]) for x in lines if x.startswith('[F16_DIAG_TICK] ')]
 if ticks:out['latest_tick']={k:ticks[-1].get(k) for k in ['owner','step','stock','wall_left','remaining_steps']}
'''+s[b:]
 ast.parse(s);assert not(F/n).exists();(F/n).write_text(s,encoding='utf-8')
s=(O/'stage_parent_observer.py').read_text().replace(O.name,F.name).replace('f15diag_','f16diag_').replace('F15_MODE','F16_MODE')
s=s.replace("assert name in ['PARENT_M04','PARENT_M05']","assert name=='PARENT_M04'")
a=s.index("if name=='PARENT_M04':");b=s.index("a=json.loads((R/'solver_study/heuristic_20261016.json')",a);s=s[:a]+s[b:]
a=s.index("mode='COURIER'");b=s.index('blue=Path',a);s=s[:a]+s[b:]
s=s.replace('Counters plus bounded delivery-route / missing-certificate courier / nominal-slack transport advisors; no original plan or command changes','Counters plus bounded measured coverage frontier, all three preferences read-only, no original plan/command/submission change')
ast.parse(s);assert not(F/'stage_parent_observer.py').exists();(F/'stage_parent_observer.py').write_text(s,encoding='utf-8')
code=r'''
from pathlib import Path
import json,sys
F=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/F16_measured_layout_frontier_20261027')
assert json.loads((F/'observer_qualification/QUALIFICATION_RESULT.json').read_text())['status']=='PASS'
for n,d in json.load(sys.stdin).items():assert not(F/n).exists();(F/n).write_text(json.dumps(d,indent=2)+'\n')
print('One original Map04 RED diagnostic prepared; no game started')
'''
print(subprocess.check_output(['ssh','-o','BatchMode=yes','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python -c '+shlex.quote(code)],input=json.dumps({'PARENT_OPERATORS.json':bundle,'DIAGNOSTIC_MAP_BINDINGS.json':maps}).encode()).decode())
