from pathlib import Path
import os,subprocess,json,shutil,datetime
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';C=H/'COMPATIBILITY_V05_BLUE_20261029'
old=H/'submission_alns_v9_20261025T1532Z/dependency_venv/lib/python3.11/site-packages';new=C/'numpy2_probe_venv/lib/python3.11/site-packages'
failed=C/'numpy2_imports_cv2_symlink_harness_failure.json'
assert not failed.exists()
shutil.copyfile(C/'numpy2_imports.json',failed)
p=new/'cv2';assert p.is_symlink() and p.resolve()==(old/'cv2').resolve()
p.unlink();shutil.copytree(old/'cv2',p)
env=os.environ.copy();env.pop('PYTHONPATH',None)
env.update(PATH=str(R/'system/usr/bin')+':'+env.get('PATH',''),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',MPLBACKEND='Agg',LIBGL_ALWAYS_SOFTWARE='1',ALSOFT_DRIVERS='null',LP_NUM_THREADS='1')
with (C/'numpy2_imports_physical_cv2.log').open('w') as log:
 p=subprocess.run([str(R/'system/usr/bin/xvfb-run'),'-a','-s','-screen 0 640x480x24',str(C/'numpy2_probe_venv/bin/python'),str(C/'probe_imports.py'),str(new),str(R/'.venv/lib/python3.11/site-packages'),str(H/'F32_official_sdk_20261028/source_repo/src'),str(C/'numpy2_imports.json')],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
a=json.loads((C/'OVERLAY_RESULT.json').read_text());a['numpy2_import_returncode']=p.returncode;a['numpy2']=json.loads((C/'numpy2_imports.json').read_text());a['harness_fix']={'reason':'OpenCV loader recursively re-entered because a symlink resolved its own module to another site path. Replaced only the new analysis venv cv2 symlink with an identical physical copy; original environment unchanged.','preserved_failure':str(failed)}
(C/'FINAL_DEPENDENCY_RESULT.json').write_text(json.dumps(a,indent=2)+'\n')
print(json.dumps({'status':a['numpy2']['status'],'traceback':a['numpy2'].get('traceback'),'versions':a['numpy2'].get('distribution_versions')},ensure_ascii=False))
