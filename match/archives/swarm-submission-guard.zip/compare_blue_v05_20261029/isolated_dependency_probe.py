"""Isolated dependency/installer checks only. Never instantiates Launcher or runs games."""
from pathlib import Path
import datetime,json,os,subprocess,sys,venv
R=Path('/home/junhao/quan/parallel_test_solver/match')
H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
C=H/'COMPATIBILITY_V05_BLUE_20261029'
C.mkdir(exist_ok=True)
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Dependency import and pip dry-run only. No algorithm execution or simulation. No changes to existing environments.','official_container_verified':False}
base_site=R/'.venv/lib/python3.11/site-packages'
source=H/'F32_official_sdk_20261028/source_repo/src'
newenv=C/'numpy2_probe_venv'
assert not newenv.exists(),'Refusing to reuse/modify an existing probe environment'
print('CREATING_NEW_ISOLATED_VENV',flush=True)
venv.EnvBuilder(with_pip=True).create(newenv)
py=newenv/'bin/python'
env=os.environ.copy()
env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',MPLBACKEND='Agg',LIBGL_ALWAYS_SOFTWARE='1',ALSOFT_DRIVERS='null',LP_NUM_THREADS='1')
env.pop('PYTHONPATH',None)
with (C/'fresh_install.log').open('w') as log:
 p=subprocess.run([str(py),'-m','pip','install','--no-cache-dir','--disable-pip-version-check','--only-binary=:all:','numpy==2.2.6','pandas==2.2.3','opencv-contrib-python==4.11.0.86'],stdout=log,stderr=subprocess.STDOUT,env=env,timeout=300)
result['fresh_install_returncode']=p.returncode
if p.returncode:
 result['status']='INSTALL_FAILED';(C/'RESULT.json').write_text(json.dumps(result,indent=2));print(json.dumps(result));sys.exit(1)
print('FRESH_NUMERIC_INSTALL_DONE',flush=True)
probe=r'''
from pathlib import Path
import sys,os,json,traceback,importlib.metadata as md
site=Path(sys.argv[1]);base=Path(sys.argv[2]);source=Path(sys.argv[3]);target=Path(sys.argv[4])
sys.path.insert(0,str(site));sys.path.insert(1,str(source))
if str(base) not in sys.path:sys.path.append(str(base))
out={'scope':'NumPy/Pandas/OpenCV operations and SDK module import only. Other SDK dependencies reused read-only from existing base environment. No simulation or controller instantiation.','official_container_verified':False,'python':sys.version,'executable':sys.executable,'isolated_site':str(site)}
try:
 import numpy as np,pandas as pd,cv2,numpy.random.mtrand as mt
 out['distribution_versions']={n:md.version(n) for n in ['numpy','pandas','opencv-contrib-python']}
 out['module_paths']={n:m.__file__ for n,m in [('numpy',np),('pandas',pd),('cv2',cv2),('numpy.random.mtrand',mt)]}
 assert all(Path(p).resolve().is_relative_to(site.resolve()) for p in out['module_paths'].values())
 assert np.isfinite(np.random.RandomState(615).normal(size=64)).all()
 assert pd.DataFrame({'a':[1.,2.,3.]})['a'].sum()==6.
 assert cv2.filter2D(np.ones((8,8),np.float32),-1,np.ones((3,3),np.float32)).shape==(8,8)
 out['numeric_operations']='PASS'
 from swarm_rescue.launcher import Launcher
 from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
 import swarm_rescue
 out['sdk_module_path']=swarm_rescue.__file__
 assert Path(swarm_rescue.__file__).resolve().is_relative_to(source.resolve())
 out['sdk_import']='PASS';out['status']='PASS'
except BaseException:
 out['status']='FAIL';out['traceback']=traceback.format_exc()
target.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'probe':target.name,'status':out['status'],'versions':out.get('distribution_versions'),'error':out.get('traceback')},ensure_ascii=False))
sys.exit(0 if out['status']=='PASS' else 1)
'''
(C/'probe_imports.py').write_text(probe)
xvfb=R/'system/usr/bin/xvfb-run'
env['PATH']=str(R/'system/usr/bin')+':'+env.get('PATH','')
for tag,site in [('numpy1',H/'submission_alns_v9_20261025T1532Z/dependency_venv/lib/python3.11/site-packages'),('numpy2',newenv/'lib/python3.11/site-packages')]:
 print('IMPORT_PROBE_'+tag,flush=True)
 with (C/(tag+'_imports.log')).open('w') as log:
  p=subprocess.run([str(xvfb),'-a','-s','-screen 0 640x480x24',str(py),str(C/'probe_imports.py'),str(site),str(base_site),str(source),str(C/(tag+'_imports.json'))],stdout=log,stderr=subprocess.STDOUT,env=env,timeout=90)
 result[tag+'_import_returncode']=p.returncode
 if (C/(tag+'_imports.json')).exists():result[tag]=json.loads((C/(tag+'_imports.json')).read_text())
plans={'v05':['numpy==1.26.4','opencv-contrib-python==4.11.0.86','pandas==2.2.3'],'sdk_inherit_draft':['numpy>=1.24.4','opencv-contrib-python>=4.10.0.84'],'blue_numpy_line_only':['numpy>=1.24']}
for label,reqs in plans.items():
 print('INSTALLER_DRY_RUN_'+label,flush=True)
 report=C/(label+'_pip_plan.json')
 with (C/(label+'_pip_plan.log')).open('w') as log:
  p=subprocess.run([str(py),'-m','pip','install','--dry-run','--disable-pip-version-check','--only-binary=:all:','--report',str(report)]+reqs,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=180)
 result[label+'_dry_run']={'returncode':p.returncode,'requested':reqs}
 if report.exists():
  plan=json.loads(report.read_text());result[label+'_dry_run']['would_install']=[{'name':x['metadata']['name'],'version':x['metadata']['version']} for x in plan.get('install',[])]
result['status']='COMPLETED';(C/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'results_dir':str(C),'numpy1':result.get('numpy1',{}).get('status'),'numpy2':result.get('numpy2',{}).get('status'),'plans':{k:v for k,v in result.items() if k.endswith('_dry_run')}},ensure_ascii=False),flush=True)
