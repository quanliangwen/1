from pathlib import Path
import json,subprocess,os
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';C=H/'COMPATIBILITY_V05_BLUE_20261029'
old=H/'submission_alns_v9_20261025T1532Z/dependency_venv/lib/python3.11/site-packages';new=C/'numpy2_probe_venv/lib/python3.11/site-packages'
code=r'''
import sys,json,traceback
from pathlib import Path
out={'case':sys.argv[1],'scope':'Controlled dependency import only; mixed case deliberately changes numpy.__path__ in this child process. No installed file is modified. This is a mechanism reproduction, not proof of platform installation order.'}
import numpy as np
out['numpy_loaded_version']=np.__version__;out['numpy_loaded_path']=np.__file__;out['random_loaded_before_switch']='numpy.random' in sys.modules
if sys.argv[1]=='mixed_numpy2_core_numpy1_random':np.__path__[:]=[str(Path(sys.argv[2])/'numpy')]
out['numpy_search_path_after_switch']=list(np.__path__)
try:
 import pandas as pd
 import numpy.random.mtrand as mt
 out['pandas_version']=pd.__version__;out['mtrand_path']=mt.__file__;out['random_sum']=float(np.random.RandomState(615).normal(size=16).sum());out['import_status']='PASS'
except BaseException:
 out['import_status']='FAIL';out['traceback']=traceback.format_exc();out['same_dtype_size_error']='Expected 96 from C header, got 88 from PyObject' in out['traceback']
print(json.dumps(out))
'''
(C/'mixed_numpy_child.py').write_text(code)
env=os.environ.copy();env.pop('PYTHONPATH',None);env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
results=[]
for case in ['coherent_numpy2','mixed_numpy2_core_numpy1_random']:
 p=subprocess.run([str(C/'numpy2_probe_venv/bin/python'),str(C/'mixed_numpy_child.py'),case,str(old)],env=env,capture_output=True,text=True,timeout=45)
 if p.returncode:results.append({'case':case,'child_returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 else:results.append(json.loads(p.stdout))
comparison=[]
for prefix,site in [('numpy1.26.4',old),('numpy2.2.6',new)]:
 p=site/'numpy/__init__.py';lines=p.read_text().splitlines();comparison.append({'version':prefix,'path':str(p),'total_lines':len(lines),'line718':lines[717] if len(lines)>=718 else None})
out={'results':results,'numpy_source_comparison':comparison,'conclusion_scope':'Only demonstrates one way this exact ABI error can arise. Does not identify the official platform process or installer behavior.'}
(C/'MIXED_NUMPY_MECHANISM.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False))
