"""Read ZIP bytes and AST only; never imports or runs contest controllers."""
import ast, collections, hashlib, json, re, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
INPUTS={'blue':Path(r'E:\10.12-10.26算法对抗赛\算法版本呢\蓝队team006_preliminary.zip'), 'v05':Path(r'E:\10.12-10.26算法对抗赛\提交版本呢\team615_red_v05.zip')}
out={}
for label,path in INPUTS.items():
 with zipfile.ZipFile(path) as z:
  names=z.namelist(); imports=collections.defaultdict(set); syntax=[]; hooks=[]; payload={}
  for n in names:
   data=z.read(n); payload[n]=hashlib.sha256(data).hexdigest()
   if not n.endswith('.py'):continue
   try:tree=ast.parse(data.decode('utf-8-sig'),filename=n)
   except Exception as e:syntax.append({'file':n,'error':str(e)});continue
   for node in ast.walk(tree):
    if isinstance(node,ast.Import):
     for x in node.names:imports[x.name].add(n)
    elif isinstance(node,ast.ImportFrom):imports['.'*node.level+(node.module or '')].add(n)
   for i,line in enumerate(data.decode('utf-8-sig').splitlines(),1):
    if re.search(r'(sys\.path|sys\.modules|site-packages|PYTHONPATH|LD_LIBRARY|subprocess|os\.system|__import__|importlib|pip\s+install)',line):hooks.append({'file':n,'line':i,'text':line.strip()})
  stdlibs={'collections','dataclasses','heapq','math','random','time','typing','__future__'}
  external=sorted({n.split('.')[0] for n in imports if n.split('.')[0] not in stdlibs and not n.startswith('swarm_rescue')})
  out[label]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'file_count':len(names),'files':names,'payload_sha256':payload,'req_bytes_hex':z.read('req.txt').hex(),'req_text':z.read('req.txt').decode('utf-8-sig'),'crc_error':z.testzip(),'duplicate_entries':[n for n,c in collections.Counter(names).items() if c>1],'flat':all('/' not in n and '\\' not in n for n in names),'binary_entries':[n for n in names if n.endswith(('.so','.pyd','.dll','.whl','.pyc'))],'team_number_lines':[s for s in z.read('team_info.yml').decode('utf-8-sig').splitlines() if 'team_number' in s],'image_ref':z.read('image_ref.txt').decode('utf-8-sig') if 'image_ref.txt' in names else None,'syntax_errors':syntax,'external_import_roots':external,'environment_mutation_text_hits':hooks,'imports':{k:sorted(v) for k,v in sorted(imports.items())}}
(ROOT/'ZIP_COMPARISON.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:{p:v[p] for p in ['sha256','file_count','req_text','flat','crc_error','duplicate_entries','binary_entries','team_number_lines','syntax_errors','external_import_roots','environment_mutation_text_hits']} for k,v in out.items()},ensure_ascii=False))
