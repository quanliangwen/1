"""Explicit P48 V09 profile. Other release profiles stay unchanged."""
from pathlib import Path
import ast,datetime,hashlib,json,re,zipfile
EXPECTED_ZIP_SHA='fcef716d6855e7c5048299048e8ebd8216c777663ed75faf2583155d1648abc9'
COMBINATIONS={'numpy1':{'numpy':'1.26.4','pandas':'2.2.3','opencv-contrib-python':'4.11.0.86'},'numpy2':{'numpy':'2.2.6','pandas':'2.2.3','opencv-contrib-python':'4.11.0.86'},'native_main':{'numpy':'1.26.4','pandas':'3.0.6','opencv-contrib-python':'4.11.0.86'}}
def inspect_p48_v09(path,receipt=None,static_only=False):
 checks=[]
 def need(condition,name):
  if not condition:raise ValueError(name)
  checks.append(name)
 need(path.name=='team615_red_v09.zip','p48_profile_scoped_to_numeric615_red_v09')
 digest=hashlib.sha256(path.read_bytes()).hexdigest();need(digest==EXPECTED_ZIP_SHA,'whole_archive_byte_identical_to_tested_P48')
 with zipfile.ZipFile(path)as z:
  names=z.namelist();need(z.testzip()is None,'zip_crc');need(len(names)==len(set(names)),'no_duplicate_entries')
  need(all('/'not in n and'\\'not in n and n not in('.','..')for n in names),'flat_zip_without_traversal')
  need({'my_drone_eval.py','team_info.yml','req.txt'}<=set(names),'required_root_files')
  need(all(n.endswith(('.py','.txt','.yml','.yaml'))for n in names),'no_binary_venv_sdk_or_runtime_payload')
  team=z.read('team_info.yml').decode('utf-8-sig');need(len(re.findall(r'(?m)^\s*team_number\s*:',team))==1 and re.search(r'(?m)^team_number:\s*615\s*(?:#.*)?$',team)is not None,'single_yaml_integer_team615')
  need('wLoPV5EE'not in team,'historical_string_id_absent');need('AAA排雷大队'in team and'team_members:'in team,'known_team_identity_preserved')
  need(z.read('req.txt').decode('utf-8-sig').split()==['numpy>=1.24.4','opencv-contrib-python>=4.10.0.84'],'exact_P48_SDK_inheritance_no_pandas_or_solver_override')
  files={n:hashlib.sha256(z.read(n)).hexdigest()for n in names}
  for n in names:
   if n.endswith('.py'):
    ast.parse(z.read(n).decode('utf-8-sig'),filename=n);need('gurobi'not in z.read(n).decode().lower(),'no_Gurobi_source_'+n)
  need(not z.read('image_ref.txt').strip(),'code_submission_not_image_pointer')
 if not static_only:
  need(receipt is not None,'new_actual_ZIP_ABI_receipt_required');p=json.loads(receipt.read_text(encoding='utf8'))
  need(p.get('status')=='PASS'and p.get('dependency_profile')=='p48-sdk-v09','new_P48_profile_receipt_PASS')
  need(p.get('submission_zip_sha256')==digest and p.get('payload_files_sha256')==files,'receipt_exact_actual_ZIP_payload')
  need(type(p.get('team_number'))is int and p['team_number']==615,'runtime_integer_team615')
  runs=p.get('abi_runs',{});need(set(runs)==set(COMBINATIONS),'both_NumPy_branches_plus_current_frozen_SDK')
  for key,versions in COMBINATIONS.items():
   r=runs[key];need(r.get('status')=='PASS'and r.get('distribution_versions')==versions,key+'_complete_numeric_combination')
   need(r.get('submission_zip_sha256')==digest and r.get('payload_files_sha256')==files,key+'_actual_ZIP_and_payload')
   need(r.get('team_number')==615 and r.get('all_payload_hashes_match')is True,key+'_actual_team_and_sources')
   need(r.get('numeric_random_pandas_cv_operations')=='PASS',key+'_mtrand_RandomState_Pandas_cv2_actual_operations')
   need(r.get('sdk_launcher_and_stats_import')=='PASS'and r.get('controller_factory_import')=='PASS',key+'_SDK_and_controller_entry')
   need(r.get('five_independent_native_constructors')=='PASS',key+'_five_real_independent_SDK_constructors')
   need(r.get('gurobi_import_blocked_and_not_loaded')is True,key+'_runs_without_Gurobi')
   need(all(r.get('critical_module_paths',{}).get(n)for n in ['numpy','numpy.random.mtrand','pandas','cv2']),key+'_binary_paths_recorded')
   plan=r.get('installation_dry_run',{});need(plan.get('status')=='PASS'and plan.get('planned_installations')==[],key+'_actual_req_dry_run_no_replacement')
  history=p.get('native_history',{});need(history.get('status')=='PASS'and history.get('tested_zip_sha256')==digest,'five_map_history_binds_same_whole_archive')
  need(history.get('payload_files_sha256')==files and history.get('maps')==5 and history.get('placed')==50,'five_complete_maps_exact_sources_50_of50')
  need(history.get('first_windows_raw_review')=='PASS'and history.get('native_failure')is False,'five_map_first_raw_audit_PASS')
  need(history.get('red_wall_hits')==0 and history.get('blue_wall_hits')==0,'five_maps_both_sides_no_wallclock_hit')
  official=p.get('official_static_check',{});need(official.get('status')=='PASS'and official.get('submission_zip_sha256')==digest==official.get('alias_sha256'),'official_static_same_bytes_alias_PASS')
 return dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='STATIC_ONLY_PASS_NOT_RELEASED'if static_only else'PASS',zip=str(path),sha256=digest,dependency_profile='p48-sdk-v09',checks=checks,official_container_verified=False,external_full_gurobi_license_required=False)
