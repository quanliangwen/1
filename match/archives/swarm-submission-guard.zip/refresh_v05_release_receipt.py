from pathlib import Path
import subprocess,json,base64
F=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import os,subprocess,base64,json
R=Path('/home/junhao/quan/parallel_test_solver/match');C=R/'solver_study/framework_screen_20261016/best87_independent_20261025/PJ01_submission_team615_v05_20261026'
s=(C/'smoke_package.py').read_text()
s=s.replace("(C/'SDK_RUNTIME_SMOKE.json')","(C/'RELEASE_ABI_RECEIPT.json')")
marker=" out.update(status='PASS',team_number=info.team_number"
assert s.count(marker)==1
addition=""" import importlib.metadata as dist
 archive=C/'team615_red_v05.zip'
 archive_sha=hashlib.sha256(archive.read_bytes()).hexdigest()
 assert archive_sha==manifest['submission_sha256']
 versions={n:dist.version(n) for n in ['numpy','opencv-contrib-python','pandas']}
 assert versions=={'numpy':'1.26.4','opencv-contrib-python':'4.11.0.86','pandas':'2.2.3'}
 out.update(submission_zip_sha256=archive_sha,payload_files_sha256=manifest['files_sha256'],distribution_versions=versions)
"""
s=s.replace(marker,addition+marker)
p=C/'release_gate_abi.py';assert not p.exists() and not(C/'RELEASE_ABI_RECEIPT.json').exists();p.write_text(s)
env={k:v for k,v in os.environ.items() if k not in ['MATCH_PHASE_ID','PYGLET_HEADLESS','PYTHONPATH']};env['MATCH_HEURISTIC_ID']='heuristic_20261015T2047Z'
with (C/'release_gate_abi.log').open('x') as log:
 result=subprocess.run(['bash',str(R/'run_server.sh'),'-u',str(p)],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
d=json.loads((C/'RELEASE_ABI_RECEIPT.json').read_text());assert result.returncode==0 and d['status']=='PASS',d
print(json.dumps({'receipt':base64.b64encode((C/'RELEASE_ABI_RECEIPT.json').read_bytes()).decode()}))
'''
r=json.loads(subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60','/home/junhao/quan/parallel_test_solver/match/.venv/bin/python','-'],input=code.encode()))
p=F.parent/'PJ01_team615_red_v05_20261026/audit/RELEASE_ABI_RECEIPT.json';p.write_bytes(base64.b64decode(r['receipt']))
print('ZIP_BOUND_ABI_RECEIPT_SAVED',str(p))
