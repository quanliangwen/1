"""Metadata-only guard for this Swarm workspace, not unrelated user projects.

Original R85 audit remains unchanged. Resource gate and physical lock are not
relaxed; this prevents a generic external `coordinator.py` false positive.
"""
from pathlib import Path
import os,json,fcntl,datetime
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
reg=json.loads((R/'solver_study/heuristic_20261016.json').read_text())
own=[];external=[];unknown=[]
for d in Path('/proc').iterdir():
    if not d.name.isdigit() or int(d.name)==os.getpid():continue
    try:
        args=(d/'cmdline').read_bytes().decode(errors='replace').split('\0');args=[x for x in args if x]
        if not args or not any('python' in Path(x).name or Path(x).name in ('bash','sh') for x in args[:2]):continue
        programs=[x for x in args[1:] if x.endswith(('.py','.sh'))]
        sdk_names=lambda x:Path(x).name.startswith('check_sdk') or Path(x).name in ('run_offline.py','native_single_red.py','postscore_visual_evaluator_v2.py','run_native.py') or 'swarm_rescue/eval_cli/' in x
        generic=lambda x:any(s in Path(x).name for s in ('coordinator','collector','run_native'))
        relevant=[x for x in programs if sdk_names(x) or generic(x)]
        if not relevant:continue
        try:cwd=str((d/'cwd').resolve(strict=True))
        except OSError:cwd=None
        start=(d/'stat').read_text().rsplit(')',1)[1].split()[19]
        row=dict(pid=int(d.name),programs=programs,cwd=cwd,start_ticks=start)
        if any(sdk_names(x) for x in programs) or any(x.startswith(str(R)+'/') for x in programs) or (cwd and cwd.startswith(str(R)+'/')):
            own.append(row)
        elif all(x.startswith('/') and not x.startswith(str(R)+'/') for x in relevant):external.append(row)
        else:unknown.append(row)
    except (OSError,IndexError):pass
lock=(R/'solver_study/serial_evaluation.lock').open('a+')
try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);available=True;fcntl.flock(lock,fcntl.LOCK_UN)
except BlockingIOError:available=False
finally:lock.close()
active=reg.get('active_processes',[]);formal=reg.get('current_formal_active')
clean=available and not active and not formal and not own and not unknown
out=dict(status='PASS_SCOPED_SWARM_SERIAL_GUARD' if clean else 'BLOCKED_SCOPED_SWARM_SERIAL_GUARD',
    utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),lock_available=available,active_registry=active,current_formal_active=formal,
    matching_swarm_processes=own,unknown_scope_processes=unknown,external_unrelated_coordinators=external,
    external_jobs_not_stopped=True,resource_or_SDK_conditions_changed=False)
print(json.dumps(out))
raise SystemExit(0 if clean else 1)
