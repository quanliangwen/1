from pathlib import Path
import base64
import hashlib
import json
import urllib.parse
import urllib.request
from publish_progress import ROOT,WORK,TASK,git

def main():
    F=ROOT/'P146_Astar_output_map02'
    client=json.loads((F/'CAMPAIGN_CLIENT_REVIEW.json').read_text(encoding='utf-8-sig'))
    pre=json.loads((F/'PREDECLARATION.json').read_text(encoding='utf-8-sig'))
    assert client['status']=='PASS'and client['native_failure']is False
    expected='68e44a3edcc04f7632584a7e9f726a003228aa50271eea2b90d73d669fd3ba56'
    assert pre['sdk_files']['src/swarm_rescue/tools/map_exploration_scoring.py']==expected
    inputs={}
    native_names=['TEST_PROTOCOL.json','INTERNAL_ZIP_BINDING_LOCAL_FIRST.json','ENTRY_ACTUAL_ZIP_FIRST.json','PREDECLARATION.json',
                  'CAMPAIGN_CLIENT_REVIEW.json','POSTMORTEM_FIRST.json','OUTPUT_EFFECT_BOUND_FIRST.json','分析结论.txt',
                  'analyze_finished_pilot.py','bound_output_effect.py','run_offline.py','collect_offline.py',
                  'declare_native.py','prepare_zip_workspace.py','check_sdk_actual_zip_entry.py','run_qualification.py',
                  'TERMINAL_RUNTIME_FIRST.json','P145_A/CLIENT_FIRST_RAW_REVIEW.json','P145_A/RAW_ARCHIVE_RECEIPT.json',
                  'P145_A/MECHANISM_REVIEW.json','P145_A/Map02_red/summary.json','P145_A/Map02_red/round1_bombs.json']
    for name in native_names:
        inputs['P146_Astar_output_map02/'+name]=(F/name).read_text(encoding='utf-8-sig').replace('\r\n','\n').encode()
    inputs['P146_Astar_output_map02/public_red_submitted.png']=(F/'P145_A/Map02_red/round1_red_submitted.png').read_bytes()
    S=F/'versions/P145/source'
    changed={}
    for name in ['my_drone_eval.py','free_bearing_support.py','free_bearing_output.py','free_support_audit.py']:
        b=(S/name).read_bytes()
        changed[name]=dict(sha256=hashlib.sha256(b).hexdigest(),base64=base64.b64encode(b).decode())
    delta=dict(base_archive_sha256='7fdac2836596f050353dc6d6e1fff3f084b5f16eb25af7cf0e62c551cfcc810d',
               base_archive='https://raw.githubusercontent.com/quanliangwen/1/7820d3deac9b063bf6ca470c371e33662a428012/swarm-eod/P48_Astar_five_20261102/P48_Astar_research.zip',
               exact_byte_overrides=changed,internal_evaluation_zip_sha256='de3ee1ce65f9fcba1ddcaf495888c8e97cbc2a00a4d9b5d69ec563ef64fba23e',
               not_contest_release=True)
    inputs['P146_Astar_output_map02/source_delta.json']=(json.dumps(delta,ensure_ascii=False,indent=2)+'\n').encode()
    for name in ['wait_connectivity.py','check_reference.py','RESULT_FIRST.json','分析依据与小检查结论.txt']:
        inputs['P147_nonblocking_wait_reference/'+name]=(ROOT/'P147_nonblocking_wait_reference'/name).read_text(encoding='utf-8-sig').replace('\r\n','\n').encode()
    name='P145_Astar_final_output_rule/方向离散化解释补充.txt'
    inputs[name]=(ROOT/name).read_text(encoding='utf-8-sig').replace('\r\n','\n').encode()
    inputs['LATEST.md']='''# 最新进展：P146单图止损，P147只做等待点规则参考

工作底本仍为冻结P48_ASTAR，既有五图均分74.255883；没有新版本完成五图或晋级。Goal与持续任务保持ACTIVE，地图精度优先、一次一条规则、不发布比赛包。

- P145在当前A*作者闭环中，实际地图95.4703→97.4584、779帧原控制/库存/健康/原图/任务链完全相同，五机真墙credit不退。原作者碰撞被保留，不是碰撞修复资格。
- P146正式Map02完成并首审：**总72.0556／地图93.5334／覆盖76.4444／时间100／9枚**，双方无wallhit/native failure；规则真实擦1314像素并绑定实际提交PNG，但未达门槛，**不扩五图、不重跑救分**。这不是运行崩溃。
- 退出证据：1884步剩余预算0时提交，1号仍1枚；961步其他9枚已经投完，末段1号存在局部停滞。不能凭末图或其他自然随机场次断言具体堵塞/目标/噪声原因。
- 固定其他分项，从单纯像素擦除与公开评分可得：本局未清理地图的分数区间为93.0171—95.4236，对应总分71.7974—73.0007。不是实际复跑的反事实，也不确定清理本身增益，但说明仅撤掉末图规则不足以通过map96/full75。
- P147完成12项有限拓扑检查，明确反例：各自安全的两个等候点可能共同堵死两条通路。因此不直接让每架机独立固定环形停车；下一先设计联合候选与真实消息/租约的一致性，再小SDK机制测试。

P146正式报告和源码增量见该目录，实际提交PNG仅为RED预测图，不是真实地图。没有读取竞赛真图或BLUE私态、没有加载原始NPZ/pickle；原始资料保留，没有重复首审。

P147工程参考为[Ma等AAMAS2017的非阻塞等待端点原则](https://arxiv.org/html/1705.10868v1)，只借原则，不移植TP/TPTS或把已知图理论保证套到本游戏。P145方向离散化补充明确：bin中心90度不等于真实射线夹角90度或噪声独立。
'''.encode()
    checks={n:hashlib.sha256(b).hexdigest()for n,b in inputs.items()}
    inputs['REVIEW_P146_P147_SHA256SUMS.json']=(json.dumps(checks,ensure_ascii=False,indent=2)+'\n').encode()
    for name,data in inputs.items():
        dest=WORK/TASK/name
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(data)
    git('add','--',*[TASK+'/'+n for n in inputs])
    git('commit','-m','Record failed A-star output pilot and nonblocking-wait counterexample')
    git('fetch','origin','main')
    git('rebase','origin/main')
    git('push','origin','HEAD:main')
    commit=git('rev-parse','HEAD')
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    verified={}
    for name,data in inputs.items():
        url='https://raw.githubusercontent.com/quanliangwen/1/'+commit+'/'+urllib.parse.quote(TASK+'/'+name)
        b=opener.open(url,timeout=45).read()
        assert hashlib.sha256(b).hexdigest()==hashlib.sha256(data).hexdigest(),name
        verified[name]=hashlib.sha256(b).hexdigest()
    receipt=dict(status='PASS_REMOTE_P146_P147_ALL_BYTES',commit=commit,
                 url='https://github.com/quanliangwen/1/blob/'+commit+'/'+TASK+'/LATEST.md',sha256=verified,
                 contest_package_published=False,source_bytes_exactly_bound=True)
    dest=F/'PUBLICATION_FIRST.json'
    assert not dest.exists()
    dest.write_bytes((json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode())
    print(json.dumps(dict(status=receipt['status'],commit=commit,url=receipt['url'],files=len(inputs))))

if __name__=='__main__':main()
