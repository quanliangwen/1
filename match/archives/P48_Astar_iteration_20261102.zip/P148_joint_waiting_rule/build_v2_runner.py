from pathlib import Path
import ast

F=Path(__file__).resolve().parent
source=(F/'prepare_workspace.py').read_text()
source=source.replace('CANDIDATE_MANIFEST_FIRST.json','CANDIDATE_MANIFEST_V2_FIRST.json').replace("F/'candidate_project'","F/'candidate_project_v2'")
source=source.replace('workspace_P148','workspace_P148V2').replace("'P148':dict", "'P148V2':dict")
ast.parse(source)
(F/'prepare_workspace_v2.py').write_bytes(source.encode())
source=(F/'run_diagnostic.py').read_text()
replacements={
    'P148_Astar_joint_waiting_20261102':'P148_Astar_joint_waiting_v2_20261102',
    'PREDECLARATION_FIRST.json':'PREDECLARATION_V2_FIRST.json',
    'MECHANISM_PREFLIGHT_FIRST.json':'MECHANISM_PREFLIGHT_V2_FIRST.json',
    'LAUNCH_BINDING_FIRST.json':'LAUNCH_BINDING_V2_FIRST.json',
    'CANDIDATE_MANIFEST_FIRST.json':'CANDIDATE_MANIFEST_V2_FIRST.json',
    'check_sdk_joint_waiting.py':'check_sdk_joint_waiting_v2.py',
    "F/'candidate_project'":"F/'candidate_project_v2'",
    'prepare_workspace.py':'prepare_workspace_v2.py',
    'STARTED_FIRST.json':'STARTED_V2_FIRST.json',
    'JOINT_WAITING_FIRST':'JOINT_WAITING_V2_FIRST',
    "'P148','cross_sdk'":"'P148V2','cross_sdk'",
    'RESULT_FIRST.json':'RESULT_V2_FIRST.json',
    'FIRST_ERROR.json':'V2_FIRST_ERROR.json',
}
for before,after in replacements.items():source=source.replace(before,after)
ast.parse(source)
(F/'run_diagnostic_v2.py').write_bytes(source.encode())
