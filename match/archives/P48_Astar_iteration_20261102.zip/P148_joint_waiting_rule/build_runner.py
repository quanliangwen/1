from pathlib import Path
import ast

F=Path(__file__).resolve().parent
source=(F.parent/'P145_Astar_final_output_rule/run_diagnostic.py').read_text(encoding='utf-8-sig')
source=source.replace('P145_Astar_final_output_rule_20261102','P148_Astar_joint_waiting_20261102')
source=source.replace('check_sdk_output_rule.py','check_sdk_joint_waiting.py')
start=source.index("    parent=Path(pre['parent_result'])\n")
end=source.index("\nif __name__=='__main__':")
replacement='''    parent=Path(pre['parent_result'])
    assert hashlib.sha256(parent.read_bytes()).hexdigest()==pre['parent_result_sha256']
    assert hashlib.sha256((F/'CANDIDATE_MANIFEST_FIRST.json').read_bytes()).hexdigest()==pre['manifest_sha256']
    if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop before joint waiting rule')
    label='JOINT_WAITING_FIRST'
    keep(label+'_SERIAL',remote(guard))
    write('STATUS.json',dict(utc=utc(),status='RUNNING_ASTARA_JOINT_WAITING_AUTHOR_SDK',native_rounds=0),False)
    cmd=SSH+[R+'/.venv/bin/python',D+'/run_sdk_captured.py',D+'/check_sdk_joint_waiting.py',label,'P148','cross_sdk','1000','.05','OFF']
    keep(label,subprocess.run(cmd,capture_output=True,timeout=900))
    subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+label+'.json',str(F/(label+'.json'))],check=True,timeout=45)
    a=load(parent);b=load(F/(label+'.json'))
    original=a['coverage_evaluation'];candidate=b['coverage_evaluation']
    routes=[e for e in b['waiting_events']if e['kind']=='ROUTE_ACCEPTED']
    arrivals=[e for e in b['waiting_events']if e['kind']=='ARRIVED']
    first=min((e['step']for e in routes),default=len(a['rows'])+1)
    health_a=[min(r['health'][i]for r in a['rows'])for i in range(5)]
    health_b=[min(r['health'][i]for r in b['rows'])for i in range(5)]
    physical=[]
    for e in arrivals:
        window=[r for r in b['rows']if e['epoch']<=r['step']<=e['epoch']+72 and r['inventory'][e['owner']]==0]
        best=min((sum((r['positions'][e['owner']][k]-e['target'][k])**2 for k in range(2))**.5 for r in window),default=float('inf'))
        physical.append(dict(owner=e['owner'],step=e['step'],epoch=e['epoch'],target=e['target'],minimum_public_physical_error=best))
    owners={e['owner']for e in physical if e['minimum_public_physical_error']<=20.}
    submit_credit_a=a['submission_records'][0]['breakdown']['credit']if a['submission_records']else None
    submit_credit_b=b['submission_records'][0]['breakdown']['credit']if b['submission_records']else None
    checks=dict(original_nonhealth_sdk_checks=all(v for k,v in b['checks'].items()if k!='health_unchanged'),
                no_added_damage=all(x>=y for x,y in zip(health_b,health_a)),
                identical_prefix_before_first_waiting_route=b['rows'][:first-1]==a['rows'][:first-1],
                two_empty_owners_really_arrived=len(owners)>=2,
                all10=candidate['actual_bomb_count']==10 and b['rows'][-1]['inventory']==[0]*5,
                actual_submitted_map_nonregress=candidate['actual_submitted_map']is not None and candidate['actual_submitted_map']>=original['actual_submitted_map'],
                actual_surface_credit_nonregress=submit_credit_b is not None and submit_credit_b>=submit_credit_a,
                mean5_raw_map_nonregress=sum(e['score']for e in b['map_results'])>=sum(e['score']for e in a['map_results']),
                time_nonregress=candidate['score_time']>=original['score_time'],
                controllable_subtotal_gain=candidate['controllable_subtotal']is not None and candidate['controllable_subtotal']>=original['controllable_subtotal']+.25)
    result=dict(status='PASS_ASTARA_JOINT_WAITING_AUTHOR_MECHANISM'if all(checks.values())else'STOP_FIRST_JOINT_WAITING_MECHANISM_GATE',
                checks=checks,physics_steps=b['physics_steps'],parent_steps=a['physics_steps'],
                baseline=original,candidate=candidate,parent_health_min=health_a,candidate_health_min=health_b,
                waiting_events=b['waiting_events'],physical_arrival_review=physical,waiting_owners_actually_arrived=sorted(owners),
                first_waiting_route_step=first if routes else None,raw_rows_identical=a['rows']==b['rows'],
                parent_raw5_maps=a['map_results'],candidate_raw5_maps=b['map_results'],
                sdk_loop_wall_seconds=b['wall_seconds'],native_rounds=0,automatic_native=False,automatic_five=False,
                limits=['One authored scenario, not official Map02 inventory-loss reproduction or a five-map mean.',
                        'Terminal joint graph check is not collision/consensus safety proof.',
                        'Known parent collision is not repaired or silently reclassified as health-safe.'])
    write('RESULT_FIRST.json',result)
    write('STATUS.json',dict(utc=utc(),status=result['status'],native_rounds=0),False)
    print(json.dumps(result,ensure_ascii=False),flush=True)
'''
source=source[:start]+replacement+source[end:]
ast.parse(source)
p=F/'run_diagnostic.py'
assert not p.exists()
p.write_bytes(source.encode())
