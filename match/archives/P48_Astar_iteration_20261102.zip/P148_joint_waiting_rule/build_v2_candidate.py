from pathlib import Path
import ast

F=Path(__file__).resolve().parent
text=(F/'build_candidate.py').read_text()
text=text.replace("F/'CONTRACT_FIRST.json'","F/'CONTRACT_V2_FIRST.json'")
text=text.replace("'PASS_PURE_WAITING_PROTOCOL_AND_FORWARDING'","'PASS_V2_WAITING_SCOPE_PROTOCOL_AND_FORWARDING'")
text=text.replace("F/'candidate_project'","F/'candidate_project_v2'")
text=text.replace("(F/name).read_bytes()","(F/(name[:-3]+'_v2.py')).read_bytes()")
text=text.replace("F/'CANDIDATE_MANIFEST_FIRST.json'","F/'CANDIDATE_MANIFEST_V2_FIRST.json'")
text=text.replace("F/'check_sdk_joint_waiting.py'","F/'check_sdk_joint_waiting_v2.py'")
text=text.replace("F/'PREDECLARATION_FIRST.json'","F/'PREDECLARATION_V2_FIRST.json'")
text=text.replace("(F/'BASE_WORKSPACE.json').write_bytes((BASE/'WORKSPACE_READY.json').read_bytes())", "assert(F/'BASE_WORKSPACE.json').read_bytes()==(BASE/'WORKSPACE_READY.json').read_bytes()")
text=text.replace("case='cross_sdk',horizon=1000", "scope_revision='Before any SDK: preserve live wall survey and require actual docking/map exchange; empty waiting coordinator independent of main carrying leader.',case='cross_sdk',horizon=1000")
ast.parse(text)
(F/'build_candidate_v2_generated.py').write_bytes(text.encode())
