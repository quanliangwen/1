from pathlib import Path
import ast
import hashlib
import json

F=Path(__file__).resolve().parent
BASE=Path('E:/codex/P48_astar_five_20261102')
PARENT=F.parent/'P142_profile_and_task_chain/BASELINE_FIRST.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
contract=json.loads((F/'CONTRACT_V2_FIRST.json').read_text())
assert contract['status']=='PASS_V2_WAITING_SCOPE_PROTOCOL_AND_FORWARDING'
assert all(sha(F/n)==h for n,h in contract['source_sha256'].items())
base=json.loads((BASE/'CANDIDATE_MANIFEST.json').read_text(encoding='utf-8-sig'))
project=F/'candidate_project_v2'
assert not project.exists()
sol=project/'src/swarm_rescue/solutions'
sol.mkdir(parents=True)
for name,h in base['payload_files'].items():
    p=BASE/'versions/P48_ASTAR/source'/name
    assert sha(p)==h
    (project/'req.txt'if name=='req.txt'else sol/name).write_bytes(p.read_bytes())
for name in ['waiting_core.py','joint_waiting.py']:(sol/name).write_bytes((F/(name[:-3]+'_v2.py')).read_bytes())
(sol/'wait_connectivity.py').write_bytes((F.parent/'P147_nonblocking_wait_reference/wait_connectivity.py').read_bytes())
entry=sol/'my_drone_eval.py'
text=entry.read_text(encoding='utf-8-sig')
anchor='class MyDroneEval(FreshOpportunityAuditMixin,'
assert text.count(anchor)==1
text='from swarm_rescue.solutions.joint_waiting import JointWaitingMixin\n'+text
text=text.replace(anchor,'class MyDroneEval(JointWaitingMixin,FreshOpportunityAuditMixin,')
entry.write_bytes(text.encode())
files={p.relative_to(project).as_posix():sha(p)for p in project.rglob('*')if p.is_file()}
changes=[name for name,h in base['payload_files'].items()if sha(project/'req.txt'if name=='req.txt'else sol/name)!=h]
assert changes==['my_drone_eval.py']or set(changes)=={'my_drone_eval.py'}
for p in sol.glob('*.py'):ast.parse(p.read_text(encoding='utf-8-sig'))
manifest=dict(rule='Empty-only joint nonblocking waiting proposals using actual received states; original A* flies accepted goals. No P145 map filter.',
              base_archive_sha256=base['sha256'],candidate_files=files,changed_parent_files=changes,
              new_modules=['waiting_core.py','joint_waiting.py','wait_connectivity.py'],official_release=False,
              limits=['Terminal nominal graph certificate, not multi-agent transit/communication safety guarantee.',
                      'Existing exploration, sortie, placement, mapping and parent fallback retained. Optional first-feasible bounded waiting rule, not a global optimization claim.'])
(F/'CANDIDATE_MANIFEST_V2_FIRST.json').write_bytes((json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode())
assert(F/'BASE_WORKSPACE.json').read_bytes()==(BASE/'WORKSPACE_READY.json').read_bytes()

source=(F.parent/'P142_profile_and_task_chain/check_sdk_astar_profile.py').read_text(encoding='utf-8-sig')
source=source.replace('P142 frozen A* own-task-chain and optional read-only cProfile; authored physics only.',
                      'P148 optional joint waiting goals on frozen A-star base; authored SDK mechanism screen.')
anchor=' out=dict(profile_enabled='
assert source.count(anchor)==1
source=source.replace(anchor," out=dict(waiting_events=[event for d in drones for event in d.waiting_events],waiting_targets=[None if d._waiting_target is None else d._waiting_target.tolist()for d in drones],profile_enabled=")
ast.parse(source)
(F/'check_sdk_joint_waiting_v2.py').write_bytes(source.encode())
pre=dict(status='FROZEN_BEFORE_FIRST_JOINT_WAITING_SDK_FRAME',
         parent_result=str(PARENT),parent_result_sha256=sha(PARENT),code_sha256=sha(F/'check_sdk_joint_waiting_v2.py'),
         manifest_sha256=sha(F/'CANDIDATE_MANIFEST_V2_FIRST.json'),
         scope_revision='Before any SDK: preserve live wall survey and require actual docking/map exchange; empty waiting coordinator independent of main carrying leader.',case='cross_sdk',horizon=1000,wall_rate=.05,authored_seed=615,maximum_cases=1,
         gates=['All original finite/callback/inventory/loop checks except the known parent health flag; minimum health per owner cannot worsen',
                'Prefix frame rows identical before first accepted waiting route',
                'At least two empty owners actually accept distinct waiting goals and arrive within the rule tolerance',
                'All10 and actual time score >= parent; actual submitted map and true-wall credit >= retained parent',
                'Mean five raw map scores >= parent; controllable subtotal >= parent+0.25 point',
                'No P145 output filter/no map, SDK, clocks, threads, dependency or external-seed change',
                'All evaluated outputs freeze before author truth; first failure stops without parameter/seed/label rescue'],
         health_limit='Parent two owners health49 is not repaired or reclassified as safe. Novel rule starts after inventory empties; require no added damage.',
         automatic_native=False,automatic_five=False,native_rounds=0)
(F/'PREDECLARATION_V2_FIRST.json').write_bytes((json.dumps(pre,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps(dict(status=pre['status'],source_files=len(files),changed_parent_files=changes)))
