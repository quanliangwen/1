"""Pre-SDK scope correction; preserve the first, unrun candidate unchanged."""
from pathlib import Path
import ast
import json

F=Path(__file__).resolve().parent
assert not(F/'WINDOWS_LAUNCH_FIRST.json').exists()
core=(F/'waiting_core.py').read_text()
anchor='def validate_plan('
assert core.count(anchor)==1
at=core.index(anchor)
core=core[:at]+'''def waiting_leader(states):
    return min((k for k,v in states.items()if v[2]==0),default=None)

'''+core[at:]
core=core.replace('leader!=min(states)','leader!=waiting_leader(states)')
core=core.replace('protected,deadline):','protected,deadline,eligible_idle=None):')
core=core.replace("states[k][2]==0 and np.linalg.norm(np.asarray(states[k][1])-centre)<=120.]", "states[k][2]==0 and np.linalg.norm(np.asarray(states[k][1])-centre)<=120. and(eligible_idle is None or k in eligible_idle)]")
ast.parse(core)
(F/'waiting_core_v2.py').write_bytes(core.encode())

text=(F/'joint_waiting.py').read_text()
text=text.replace('states_valid,validate_plan,propose_waiting_plan','states_valid,validate_plan,propose_waiting_plan,waiting_leader')
text=text.replace('        self.waiting_events=[]','        self.waiting_events=[]\n        self._waiting_exchange_ready=False\n        self._waiting_ready_reports={}')
anchor='    def define_message_for_all(self):'
assert text.count(anchor)==1
text=text.replace(anchor,'''    def _waiting_can_wait(self,step):
        if int(self.carried_bombs_count())!=0:
            self._waiting_exchange_ready=False
            return False
        if self._sortie_state=='SORTIE':return False
        survey=getattr(self,'survey_plan',None)
        if isinstance(survey,(tuple,list))and len(survey)==6:
            epoch,leader,owner,p,until=survey[0],survey[1],survey[2],survey[3],survey[5]
            if owner==int(self.identifier or 0)and p is not None and 0<=step-epoch<120 and step<until:return False
        docked=getattr(self,'_sortie_docked_step',None)
        if not self._waiting_exchange_ready and docked is not None and step-docked>=24:
            received=getattr(self,'last_peer_step',{})
            if any(peer!=int(self.identifier or 0)and docked<stamp<=step and step-stamp<100 for peer,stamp in received.items()):
                self._waiting_exchange_ready=True
                self._waiting_emit('MAP_EXCHANGE_COMPLETED',step,docked=int(docked))
        return self._waiting_exchange_ready

'''+anchor)
# In actual survey_plan the tuple has five items (epoch,leader,owner,point,until).
text=text.replace('len(survey)==6:', 'len(survey)==5:').replace('survey[3],survey[5]', 'survey[3],survey[4]')
anchor="        result['waiting_plan_v1']=plan if plan is not None and plan['leader']==int(self.identifier or 0)and int(self.elapsed_timestep)<=plan['expires']else None"
assert text.count(anchor)==1
text=text.replace(anchor,anchor+"\n        step=int(self.elapsed_timestep)\n        result['waiting_ready_v1']=(step,bool(self._waiting_can_wait(step)))")
anchor="            plan=msg.get('waiting_plan_v1')"
assert text.count(anchor)==1
text=text.replace(anchor,'''            readiness=msg.get('waiting_ready_v1')
            if(isinstance(readiness,(tuple,list))and len(readiness)==2 and type(readiness[0])is int
                    and type(readiness[1])is bool and readiness[0]==sent and 0<=step-sent<=48):
                old_ready=self._waiting_ready_reports.get(sender,(-1,False))
                if sent>old_ready[0]:self._waiting_ready_reports[sender]=(sent,readiness[1])
            plan=msg.get('waiting_plan_v1')''')
anchor='        states=self._waiting_states(step)\n        if not states_valid(states,step,self.team_size):return original'
assert text.count(anchor)==1
text=text.replace(anchor,'        if not self._waiting_can_wait(step):return original\n'+anchor)
text=text.replace('own==min(states)', 'own==waiting_leader(states)')
anchor='            plan,audit=propose_waiting_plan(self.memory,step,own,self.team_size,states,self.rally,protected,time.perf_counter()+.05)'
assert text.count(anchor)==1
text=text.replace(anchor,'''            ready={peer for peer,(sent,flag)in self._waiting_ready_reports.items()if flag and 0<=step-sent<=48}
            ready.add(own)
            plan,audit=propose_waiting_plan(self.memory,step,own,self.team_size,states,self.rally,protected,time.perf_counter()+.05,eligible_idle=ready)''')
anchor='        step=int(self.elapsed_timestep)\n        goal=validate_plan('
assert text.count(anchor)==1
text=text.replace(anchor,'        step=int(self.elapsed_timestep)\n        if not self._waiting_can_wait(step):return result\n        goal=validate_plan(')
ast.parse(text)
(F/'joint_waiting_v2.py').write_bytes(text.encode())
(F/'DESIGN_REVIEW_FIRST.json').write_bytes((json.dumps(dict(
    status='PRE_SDK_SCOPE_CORRECTION_NO_PERFORMANCE_RERUN',
    issues=['V1 did not explicitly preserve a live assigned wall survey','V1 did not require actual initial map exchange','V1 waiting coordinator limited to main minimum ID, despite empty peer availability'],
    correction=['Preserve active five-field survey_plan and SORTIE','Require dock24+actual received message before persistent readiness','Use minimum received empty ID for the optional waiting coordinator; main fleet coordinator untouched'],
    original_unrun_candidate='candidate_project',new_source_files=['waiting_core_v2.py','joint_waiting_v2.py'],
    sdk_frames_before_correction=0,native_rounds=0,parameters_or_score_gates_changed=False),ensure_ascii=False,indent=2)+'\n').encode())
print('Pre-SDK mapping-scope correction prepared; V1 candidate unchanged')
