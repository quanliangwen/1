from pathlib import Path
import ast

F=Path(__file__).resolve().parent
source=(F/'check_contracts.py').read_text()
source=source.replace("F/'CONTRACT_FIRST.json'","F/'CONTRACT_V2_FIRST.json'")
source=source.replace("F/'waiting_core.py'","F/'waiting_core_v2.py'").replace("F/'joint_waiting.py'","F/'joint_waiting_v2.py'")
anchor="out=dict(status='PASS_PURE_WAITING_PROTOCOL_AND_FORWARDING'"
assert source.count(anchor)==1
extra='''
class RouteMemory(Memory):
    def __init__(self):super().__init__();self.route_calls=0
    def route(self,pose,destination):self.route_calls+=1;return[point.copy()for point in[destination]],np.asarray(destination).copy()
rm=RouteMemory()
def ready_fixture():
    x=D();x.qty=0;x.memory=rm;x.fleet_states=dict(states);x.survey_plan=None
    x.last_peer_step={0:90};x._sortie_docked_step=50;x._waiting_plan=copy.deepcopy(plan)
    return x
x=ready_fixture();x._sortie_docked_step=None
kept=x._plan_route(100,False,[])
check('no_docking_keeps_original_mapping_route',kept==(['parent_path'],['parent_goal'])and rm.route_calls==0)
x=ready_fixture();x.last_peer_step={}
check('no_actual_map_message_keeps_original',x._plan_route(100,False,[])==(['parent_path'],['parent_goal'])and rm.route_calls==0)
x=ready_fixture();x._sortie_docked_step=90;x.last_peer_step={0:99}
check('dock_exchange_window_not_shortened',x._plan_route(100,False,[])==(['parent_path'],['parent_goal'])and rm.route_calls==0)
x=ready_fixture();x.survey_plan=(100,0,1,np.array([80.,0.]),180)
check('active_five_field_wall_survey_is_preserved',x._plan_route(100,False,[])==(['parent_path'],['parent_goal'])and rm.route_calls==0)
x=ready_fixture();answer=x._plan_route(100,False,[])
check('post_exchange_optional_wait_route_can_apply',rm.route_calls==1 and np.array_equal(answer[1],plan['goals'][1])and x._waiting_exchange_ready)
x._sortie_docked_step=None
check('completed_exchange_evidence_survives_leaving_dock',x._waiting_can_wait(101))
report=x.define_message_for_all()
check('readiness_report_carries_actual_step_and_flag',report['waiting_ready_v1']==(100,True))
alt={0:(100,np.array([-180.,180.]),1),1:(100,np.array([0.,-16.]),0),2:(100,np.array([16.,-16.]),0)}
alt_plan,alt_audit=core.propose_waiting_plan(m,100,1,3,alt,anchor,protected,time.perf_counter()+2.)
check('empty_coordinator_available_while_main_leader_carries',alt_plan is not None and alt_plan['leader']==1 and core.validate_plan(alt_plan,100,2,3,alt,anchor,1,100)is not None)
one,why=core.propose_waiting_plan(m,100,0,3,states,anchor,protected,time.perf_counter()+2.,eligible_idle={0})
check('unready_idle_peer_not_assigned',one is not None and set(one['goals'])=={0})
all_loaded={k:(100,v[1],1)for k,v in states.items()}
check('no_empty_peer_no_waiting_coordinator',core.waiting_leader(all_loaded)is None)

# Counterexample is explicitly pre-SDK and uses the unrun V1 source.
module('swarm_rescue.solutions.waiting_core',F/'waiting_core.py')
v1=module('fixture_v1_joint_waiting',F/'joint_waiting.py')
class V1D(v1.JointWaitingMixin,Parent):pass
old=V1D();old.qty=0;old.memory=rm;old.fleet_states=dict(states);old.survey_plan=(100,0,1,np.array([80.,0.]),180);old._waiting_plan=copy.deepcopy(plan)
old_answer=old._plan_route(100,False,[])
counter=dict(status='V1_PRE_SDK_SCOPE_COUNTEREXAMPLE_CONFIRMED',active_survey_was_overridden=not isinstance(old_answer[1],list)or old_answer[1]!=['parent_goal'],sdk_frames=0)
assert counter['active_survey_was_overridden']
(F/'V1_SCOPE_COUNTEREXAMPLE_FIRST.json').write_bytes((json.dumps(counter,indent=2)+'\\n').encode())

'''
source=source.replace(anchor,extra+"out=dict(status='PASS_V2_WAITING_SCOPE_PROTOCOL_AND_FORWARDING'")
ast.parse(source)
(F/'check_contracts_v2.py').write_bytes(source.encode())
