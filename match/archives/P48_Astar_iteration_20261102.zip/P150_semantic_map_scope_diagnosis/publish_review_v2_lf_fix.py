from pathlib import Path
import hashlib,importlib.util,json,urllib.parse,urllib.request
F=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('common_publisher',F.parent/'publish_progress.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
names=['分析结论.txt','SDK_SOURCE_REVIEW_FIRST.json','SDK_ANGLE_CONTRACT_FIRST.json','SDK_CONSTANT_LINES_FIRST.json','read_frozen_sources.py','analyze_existing_public_inputs.py','analyze_existing_public_inputs_v2_fixture.py','FIRST_ERROR.json','PUBLIC_INPUT_REVIEW_V2_FIXTURE_FIRST.json','PUBLICATION_FIRST_ERROR.json']
inputs={F.name+'/'+n:(F/n).read_text(encoding='utf-8-sig').replace('\r\n','\n').encode()for n in names}
p=F.parent/'P149_ready_waiting_coordinator/RECEIVED_FRESHNESS_APPLICABILITY_FIRST.json'
inputs['P149_ready_waiting_coordinator/'+p.name]=p.read_text(encoding='utf-8-sig').replace('\r\n','\n').encode()
inputs['LATEST.md']='''# P48 A*持续迭代

- [P148真实无效执行与P149单项修正](P149_ready_waiting_coordinator/README.md)：P148没有BUILD/等待接单，保持失败不native；P149修协调资格，52小检查通过，唯一一次SDK仍等待原资源门槛，没有放宽资源或开五图。
- [P150误绘方向的范围复核](P150_semantic_map_scope_diagnosis/分析结论.txt)：零SDK、零候选。35条分类射线给表面点，不能当对象中心扩圆；原角宽已大于语义半间距。30帧记录的94个假设额外屏蔽样本并未证实为幽灵点，因此不直接加宽过滤。

当前目标与接续ACTIVE；原A*完整五图74.255883/50保持，无新正式成绩或参赛包。当前P149源码/协议冻结，不重复运行P148，不叠失败P145。
'''.encode()
checks={n:hashlib.sha256(v).hexdigest()for n,v in inputs.items()}
inputs[F.name+'/PUBLICATION_SHA256SUMS.json']=(json.dumps(checks,ensure_ascii=False,indent=2)+'\n').encode()
assert c.git('status','--porcelain')==''
dest=c.WORK/c.TASK
for n,data in inputs.items():
 p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
c.git('add','--',c.TASK+'/'+F.name,c.TASK+'/P149_ready_waiting_coordinator/RECEIVED_FRESHNESS_APPLICABILITY_FIRST.json',c.TASK+'/LATEST.md')
c.git('commit','-m','Normalize diagnostic JSON checksum after Windows line-ending audit')
c.git('fetch','origin','main');c.git('rebase','origin/main');c.git('push','origin','HEAD:main')
commit=c.git('rev-parse','HEAD');opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));verified={}
for n,data in inputs.items():
 got=opener.open('https://raw.githubusercontent.com/quanliangwen/1/'+commit+'/'+urllib.parse.quote(c.TASK+'/'+n),timeout=45).read()
 assert hashlib.sha256(got).hexdigest()==hashlib.sha256(data).hexdigest(),n
 verified[n]=hashlib.sha256(got).hexdigest()
out=dict(status='PASS_REMOTE_BYTES_AND_CHECKSUMS',commit=commit,sha256=verified,url='https://github.com/quanliangwen/1/blob/'+commit+'/'+c.TASK+'/LATEST.md',not_contest_release=True)
p=F/'PUBLICATION_FIRST.json';assert not p.exists();p.write_bytes((json.dumps(out,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in out.items()if k!='sha256'}))
