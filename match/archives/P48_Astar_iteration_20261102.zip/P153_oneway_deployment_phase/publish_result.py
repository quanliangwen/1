"""Publish actual new user-requested rule and failed first test, not a release."""
from pathlib import Path
import base64,hashlib,importlib.util,json,urllib.parse,urllib.request
F=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('publication_common',F.parent/'publish_progress.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
r=json.loads((F/'POSTMORTEM_FIRST.json').read_text());assert r['status']=='REAL_ONEWAY_PHASE_EXECUTED_BUT_FAILED_MAP_AND_TOTAL_GAIN'
inputs={}
def add(stage,names):
    for n in names:inputs[stage+'/'+n]=(F.parent/stage/n).read_text(encoding='utf-8-sig').replace('\r\n','\n').encode()
add(F.name,['分析依据与小测试结论.txt','deployment_phase.py','check_contracts.py','CONTRACT_FIRST.json','CANDIDATE_MANIFEST_FIRST.json','PREDECLARATION_FIRST.json','LAUNCH_BINDING_FIRST.json','prepare_sdk.py','check_sdk_phase.py','run_diagnostic.py','prepare_workspace.py','MECHANISM_PREFLIGHT_FIRST.json','RESULT_FIRST.json','POSTMORTEM_FIRST.json','REQUEST_GUARD_REVIEW_FIRST.json','ANALYSIS_FIRST_ERROR.json','TASK_TRACE_REVIEW_V2_FIRST.json','analyze_result.py'])
add('P152_frozen_renderer_layer_diagnosis',['RESULT_FIRST.json','LAYER_DIAGNOSIS_FIRST.json','完成分层诊断结论.txt','analyze_completed_layers.py','RESOURCE_TWO_SAMPLE_FIRST.json'])
base=json.loads(Path('E:/codex/P48_astar_five_20261102/CANDIDATE_MANIFEST.json').read_text(encoding='utf-8-sig'));m=json.loads((F/'CANDIDATE_MANIFEST_FIRST.json').read_text());delta={}
for n,h in m['candidate_files'].items():
    data=(F/'candidate_project'/n).read_bytes();assert hashlib.sha256(data).hexdigest()==h
    if base['payload_files'].get(Path(n).name)==h:continue
    delta[n]=dict(sha256=h,base64=base64.b64encode(data).decode())
assert len(delta)==2
source=dict(base_archive_sha256=base['sha256'],base_url='https://raw.githubusercontent.com/quanliangwen/1/7820d3deac9b063bf6ca470c371e33662a428012/swarm-eod/P48_Astar_five_20261102/P48_Astar_research.zip',
            actual_candidate_files=m['candidate_files'],changed_or_new_payload=delta,not_contest_release=True,
            note='Exact actual bytes in base64; readable Python is canonical LF. Candidate failed first SDK gate; do not submit as an upgrade.')
inputs[F.name+'/source_delta_actual.json']=(json.dumps(source,ensure_ascii=False,indent=2)+'\n').encode()
readme='''# P153：先探索，再专心投放——首次小试结果

## 当前P48 A*怎样布点

无人机先用公共传感器探索并交换地图。协调机判断继续探索的预计收益是否值得付出时间与未投完风险，释放全部可用库存；原覆盖供应器在已知可达区域按新增墙体覆盖、路径预算、库存、间距和禁区选择目标并给每机排序。执行路径用A*，目标/布局距离计算仍有Dijkstra，布局还含原有界局部改进，不使用Gurobi。库存实际下降才确认投放，之后可重新分配余下目标。

当前并非完全严格两阶段：承诺检查可能退回探索、可选补扫和空载SORTIE仍可发生。用户提议本轮被实现为“收到有效投放计划后单向进入DEPLOY，不再主动探新目标”，保持原探索退出时机，传感/地图更新仍继续，失效任务可以重规划或回联络。不是同点同时投放，也不是等墙钟最后一刻才开始。通信按实际收到计划逐机切换，不假装全队同时得到消息。

## 实际小试

原42项底本只新增一个阶段helper和入口，32项协议/原方法检查通过后，完成唯一一次真实SDK作者CROSS测试。五机实际在264..266步切换，首切换前全部帧同底本；131次后续最终路线均为投放或回联络/hold，全部10次请求和库存下降发生在各自切换后。没有改地图渲染、布局、SDK、依赖或结束预算。

| 同一作者场景 | 原P48 A* | 单向投放阶段 |
|---|---:|---:|
| 投放 |10/10|10/10|
| 地图分 |95.4703|93.8037|
| 墙体覆盖分 |74.6580|76.7257|
| 时间分 |100|100|
| 最后一枚实际投出步 |777|871|
| 提交结束步 |779|872|
| 可控分项小计 |72.6668|72.2470|

没有运行BLUE，小计不是完整红分，更不是五图均分。地图/逐机健康/收益门槛失败，保留首结果，不进入正式单图或五图、不晋级、不重跑救分。

父本69次承诺检查实际推迟为0，所以这个场景不能归因为消除了大量拖延。新3号首任务早12步接到，却先后释放目标并回联络，首次投放445延到840。0/3在363/364步各掉1健康；父本是1/4在344步各掉1，总损伤均2，不能说总碰撞损伤增加。具体释放分支/接触对象未采集，不能硬定为A*、禁区或拥堵。地图下降主要是误绘扣分增加1.6134pp，真实墙信用只下降.0533pp，不能简单说少探索漏了大片墙。

这不否定全部两阶段框架，只说明本次保持原切换时机、禁止再探索的具体适配没有优于底本。

## 是否最后一枚就结束

不是直接以最后一次请求投放结束。真实库存下降后才记录完成证书；正常还要本机空载、收齐全队完成证书、没有更优新鲜队友地图才提交。剩余预算耗尽则可以带余弹提交。此次最后一枚871步、872步提交；原场景777步、779步提交。结束预算和SDK规则保持。

## 工程参考与独立诊断

[PX4 Mission Mode](https://docs.px4.io/main/en/flight_modes_mc/mission)提供显式任务状态、保留进度及不可行时hold的工程参考；没有移植飞行参数或声称继承游戏保证。

P152冻结输出分层诊断也已完成身份核验。这个作者场景0号frame图99.3490，最终多方向补图后95.4703；该层增8107px只多2个真墙命中，误绘扣分增加。此场景缺多种小物体，不能直接关整层当五图改进，本轮也没有把它叠入P153。

全部研究源码变更精确字节绑定公开原A*归档，`source_delta_actual.json`可复原。没有新赛事提交包，正式V09不变。
'''
inputs[F.name+'/README.md']=readme.encode()
inputs['LATEST.md']='''# P48 A*最新研究：用户提出的两阶段投放小试已完成

[P153算法说明、结束条件和首次小试](P153_oneway_deployment_phase/README.md)。单向投放实际执行、10/10；地图95.4703→93.8037，墙体覆盖74.6580→76.7257，结束779→872步，可控小计72.6668→72.2470，未晋级、不扩正式评测或五图。这是作者SDK小试，没有BLUE完整分。

此前资源已恢复，P152分层观察也实际结束并全身份核验PASS；旧“资源等待”是历史状态。当前没有活动SDK/native队列，旧PID不重启。P48 A*正式研究五图均值仍74.255883/50，正式V09和原A*底本不改，无新比赛包。
'''.encode()
checks={n:hashlib.sha256(data).hexdigest()for n,data in inputs.items()}
inputs[F.name+'/PUBLICATION_SHA256SUMS.json']=(json.dumps(checks,ensure_ascii=False,indent=2)+'\n').encode()
assert c.git('status','--porcelain')==''
dest=c.WORK/c.TASK
for n,data in inputs.items():
    p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
c.git('add','--',c.TASK+'/'+F.name,c.TASK+'/P152_frozen_renderer_layer_diagnosis/RESULT_FIRST.json',c.TASK+'/P152_frozen_renderer_layer_diagnosis/LAYER_DIAGNOSIS_FIRST.json',c.TASK+'/P152_frozen_renderer_layer_diagnosis/完成分层诊断结论.txt',c.TASK+'/P152_frozen_renderer_layer_diagnosis/analyze_completed_layers.py',c.TASK+'/P152_frozen_renderer_layer_diagnosis/RESOURCE_TWO_SAMPLE_FIRST.json',c.TASK+'/LATEST.md')
c.git('commit','-m','Test user one-way deployment proposal and document completion guards')
c.git('fetch','origin','main');c.git('rebase','origin/main');c.git('push','origin','HEAD:main')
commit=c.git('rev-parse','HEAD');opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));verified={}
for n,data in inputs.items():
    got=opener.open('https://raw.githubusercontent.com/quanliangwen/1/'+commit+'/'+urllib.parse.quote(c.TASK+'/'+n),timeout=45).read()
    assert hashlib.sha256(got).hexdigest()==hashlib.sha256(data).hexdigest(),n
    verified[n]=hashlib.sha256(got).hexdigest()
out=dict(status='PASS_REMOTE_BYTES_AND_CHECKSUMS',commit=commit,files=len(inputs),sha256=verified,url='https://github.com/quanliangwen/1/blob/'+commit+'/'+c.TASK+'/'+F.name+'/README.md',not_contest_release=True)
p=F/'PUBLICATION_FIRST.json';assert not p.exists();p.write_bytes((json.dumps(out,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in out.items()if k!='sha256'}))
