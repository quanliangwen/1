"""Own output audit after original SDK setter. No policy or renderer changes."""
import json,hashlib
import numpy as np
class FreeSupportAuditMixin:
    def submit_exploration_map(self,image):
        result=super().submit_exploration_map(image)
        actual=np.asarray(self._exploration_map_submission)
        print('[FREE_SUPPORT_OUTPUT] '+json.dumps(dict(owner=int(self.identifier or 0),step=int(self.elapsed_timestep),inventory=int(self.carried_bombs_count()),shape=list(actual.shape),dtype=str(actual.dtype),sha256=hashlib.sha256(actual.tobytes()).hexdigest(),audit=self.last_free_support_output_audit)),flush=True)
        return result
