from pathlib import Path
import datetime
import json
import subprocess

F=Path(__file__).resolve().parent
R='/home/junhao/quan/parallel_test_solver/match'
D=R+'/solver_study/framework_screen_20261016/best87_independent_20261025/P146_Astar_output_map02_20261102'
launch=json.loads((F/'LAUNCH.json').read_text(encoding='utf-8-sig'))
code='''from pathlib import Path
import json,datetime
F=Path(ROOT)
a=json.loads((F/'LAUNCH.json').read_text())
p=Path('/proc')/str(a['pid'])
exists=p.exists()
cmd=(p/'cmdline').read_bytes().replace(b'\\0',b' ').decode()if exists else None
ticks=(p/'stat').read_text().rsplit(')',1)[1].split()[19]if exists else None
s=json.loads((F/'STATUS.json').read_text())
print(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=a['pid'],live=exists,command=cmd,starttime_ticks=ticks,start_matches=ticks==a['starttime_ticks'],status=s['status'],current=s['current'],native_failure=s['first_native_failure'])))
'''.replace('ROOT',repr(D))
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60',R+'/.venv/bin/python','-'],input=code.encode(),capture_output=True,check=True,timeout=45)
row=json.loads(p.stdout)
assert row['start_matches']and row['command']and D+'/run_offline.py'in row['command']
out=F/'RUNTIME_FIRST.json'
assert not out.exists()
out.write_bytes((json.dumps(row,indent=2)+'\n').encode())
print(json.dumps(row))
