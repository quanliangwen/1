from pathlib import Path
import ast
import hashlib
import json
import shutil
import zipfile

F=Path(__file__).resolve().parent
P=F.parent/'P145_Astar_final_output_rule'
OLD=Path('E:/codex/PJ01_rule_refinement_20261102/P126_P125_free_output_single')
BASE=Path('E:/codex/P48_astar_five_20261102')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result=json.loads((P/'RESULT_FIRST.json').read_text(encoding='utf-8-sig'))
assert result['status']=='PASS_ASTARA_FINAL_OUTPUT_MECHANISM'and all(result['checks'].values())
manifest=json.loads((P/'CANDIDATE_MANIFEST_FIRST.json').read_text(encoding='utf-8-sig'))
project=P/'candidate_project'
assert all(sha(project/n)==h for n,h in manifest['candidate_files'].items())
S=F/'versions/P145/source'
assert not S.exists()
S.mkdir(parents=True)
for p in (project/'src/swarm_rescue/solutions').iterdir():
    assert p.is_file()
    (S/p.name).write_bytes(p.read_bytes())
(S/'req.txt').write_bytes((project/'req.txt').read_bytes())
(S/'free_support_audit.py').write_bytes((OLD/'versions/P125/source/free_support_audit.py').read_bytes())
entry=S/'my_drone_eval.py'
text=entry.read_text(encoding='utf-8-sig')
anchor='class MyDroneEval(CrossSourceFreeOutputMixin,'
assert text.count(anchor)==1
text='from swarm_rescue.solutions.free_support_audit import FreeSupportAuditMixin\n'+text
text=text.replace(anchor,'class MyDroneEval(FreeSupportAuditMixin,CrossSourceFreeOutputMixin,')
entry.write_bytes(text.encode())
files={p.name:sha(p)for p in S.iterdir()}
for p in S.glob('*.py'):ast.parse(p.read_text(encoding='utf-8-sig'))
z=F/'versions/P145/P145_internal_evaluation.zip'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED)as out:
    for name in sorted(files):out.writestr(name,(S/name).read_bytes())
with zipfile.ZipFile(z)as archive:
    assert len(archive.namelist())==len(files)and all('/'not in n for n in archive.namelist())
    assert {n:hashlib.sha256(archive.read(n)).hexdigest()for n in archive.namelist()}==files
    assert archive.read('req.txt')==(project/'req.txt').read_bytes()
binding=dict(sha256=sha(z),payload_files=files,source=str(S),zip=str(z),actual_req_unchanged=True,
             functional_parent_manifest_sha256=sha(P/'CANDIDATE_MANIFEST_FIRST.json'),
             audit_sha256=sha(S/'free_support_audit.py'),audit_historical_sha256=sha(OLD/'versions/P125/source/free_support_audit.py'),
             official_submission_ready=False,contest_release=False)
(F/'INTERNAL_ZIP_BINDING_LOCAL_FIRST.json').write_bytes((json.dumps(binding,indent=2)+'\n').encode())
(F/'SMALL_TEST_EVIDENCE.json').write_bytes((P/'RESULT_FIRST.json').read_bytes())
(F/'BASE_WORKSPACE.json').write_bytes((BASE/'WORKSPACE_READY.json').read_bytes())

# Use the established pilot driver, never modify its scientific evaluator.
text=(OLD/'run_offline.py').read_text(encoding='utf-8-sig')
text=text.replace('One P125 free-supported-output-output original Map02','One P145 A-star final-output original Map02')
text=text.replace('map_at_least95=', 'map_at_least96=').replace('wall_at_least75=','wall_at_least80=')
(F/'run_offline.py').write_bytes(text.encode())
text=(OLD/'collect_offline.py').read_text(encoding='utf-8-sig')
text=text.replace('PJ01_rules_P126_P125_free_output_single_20261102','P146_Astar_output_map02_20261102').replace("'P125_A'","'P145_A'").replace('P125 originalMap02','P145 A-star originalMap02')
(F/'collect_offline.py').write_bytes(text.encode())
for name in ['launch_campaign.py','start_local_collector.py','check_scoped_serial.py']:
    text=(OLD/name).read_text(encoding='utf-8-sig').replace('P125','P145')
    (F/name).write_bytes(text.encode())
for p in F.glob('*.py'):ast.parse(p.read_text(encoding='utf-8-sig'))
protocol=dict(status='FROZEN_ONE_MAP_AFTER_ASTARA_OUTPUT_MECHANISM',version='P145',maps=['Map02'],maximum_native_rounds=2,
              minimum_map=96.,minimum_wall=80.,minimum_full=75.,time100=True,all10=True,both_no_wallhit=True,
              active_output_required=True,submitted_png_sha_binding_required=True,resource_or_sdk_changed=False,
              historical_reference='New A-star five-map Map02 75.8150/map95.5810/wall90.1227, natural episodes differ; no causal historical score claim.',
              scientific_limit='P145 author map+1.9881pp with five surface credits unchanged; parent authored collision preserved. Not a collision repair qualification.',
              automatic_five=False,automatic_promotion=False,official_release=False)
(F/'TEST_PROTOCOL.json').write_bytes((json.dumps(protocol,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps(dict(status=protocol['status'],payloads=len(files),zip_sha256=sha(z))))
