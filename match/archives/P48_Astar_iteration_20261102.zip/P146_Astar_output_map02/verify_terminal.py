from pathlib import Path
import json
import subprocess

F=Path(__file__).resolve().parent
R='/home/junhao/quan/parallel_test_solver/match'
status=json.loads((F/'STATUS.json').read_text())
client=json.loads((F/'CAMPAIGN_CLIENT_REVIEW.json').read_text())
assert status['status']=='COMPLETE_FINITE_STAGED_CAMPAIGN'
assert client['status']=='PASS'and client['native_failure']is False
guard=(F/'check_scoped_serial.py').read_text()
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60',R+'/.venv/bin/python','-'],input=guard.encode(),capture_output=True,check=True,timeout=45)
result=json.loads(p.stdout)
assert result['status']=='PASS_SCOPED_SWARM_SERIAL_GUARD'
out=F/'TERMINAL_RUNTIME_FIRST.json'
assert not out.exists()
out.write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps(dict(status=result['status'],utc=result['utc'],lock_available=result['lock_available'],own_processes=result['matching_swarm_processes'])))
