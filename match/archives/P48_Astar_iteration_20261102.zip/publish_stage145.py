from pathlib import Path
import base64
import difflib
import hashlib
import json
import urllib.parse
import urllib.request
from publish_progress import git, WORK, ROOT, TASK

F=ROOT/'P145_Astar_final_output_rule'
SUB=TASK+'/P145_Astar_final_output_rule'

def main():
    r=json.loads((F/'RESULT_FIRST.json').read_text(encoding='utf-8-sig'))
    inputs={}
    for name in ['CANDIDATE_MANIFEST_FIRST.json','PREDECLARATION_FIRST.json','LAUNCH_BINDING_FIRST.json','RESULT_FIRST.json',
                 '分析依据与小试边界.txt','分析结论.txt','build_candidate.py','prepare_workspace.py','check_sdk_output_rule.py','run_diagnostic.py','RESOURCE_TWO_SAMPLE_FIRST.json']:
        p=F/name
        assert p.exists(),p
        inputs[name]=p.read_text(encoding='utf-8-sig').replace('\r\n','\n').encode()
    source=F/'candidate_project/src/swarm_rescue/solutions'
    parent=Path('E:/codex/P48_astar_five_20261102/versions/P48_ASTAR/source')
    names=['my_drone_eval.py','free_bearing_support.py','free_bearing_output.py']
    changed={}
    patches=[]
    for name in names:
        b=(source/name).read_bytes()
        changed[name]=dict(sha256=hashlib.sha256(b).hexdigest(),base64=base64.b64encode(b).decode('ascii'))
        before=(parent/name).read_text(encoding='utf-8-sig').splitlines(keepends=True)if(parent/name).exists()else[]
        after=b.decode('utf-8-sig').replace('\r\n','\n').splitlines(keepends=True)
        patches.extend(difflib.unified_diff(before,after,fromfile='a/'+name,tofile='b/'+name))
    pack=dict(base_archive_sha256='7fdac2836596f050353dc6d6e1fff3f084b5f16eb25af7cf0e62c551cfcc810d',
              base_archive='https://raw.githubusercontent.com/quanliangwen/1/7820d3deac9b063bf6ca470c371e33662a428012/swarm-eod/P48_Astar_five_20261102/P48_Astar_research.zip',
              exact_byte_overrides=changed,not_contest_submission=True,
              note='Base archive plus these three exact byte overrides reproduces source. Human-readable diff has canonical LF; source bytes are explicitly base64 bound.')
    inputs['source_delta.json']=(json.dumps(pack,ensure_ascii=False,indent=2)+'\n').encode()
    inputs['changes.diff']=''.join(patches).encode()
    summary=dict(status=r['status'],checks=r['checks'],sdk_scope='One authored A* output-only candidate, not a competition map',
                 actual_map_gain=r['candidate']['actual_submitted_map']-r['baseline']['actual_submitted_map'],
                 parent_health_failure_preserved=True,native_rounds=0,contest_release=False)
    inputs['README.md']=(f'''# P145：A*底本上的单条最终输出规则

状态：`{r['status']}`。作者场景实际地图变化：{summary['actual_map_gain']:+.8f}个百分点。

这次适配历史P125的输出一致性规则；helper和wrapper字节不变，仅接入冻结P48_ASTAR入口。不是新算法机制，也不继承旧原生试验的性能资格。所有A*、探索、地图更新、任务、布点、运动和依赖保持。

父本作者场景的两机各掉1点健康被明确保留，本试验不宣称修复或通过健康安全资格。性能比较要求所有原动作、地图、库存、目标和健康与保留父本完全一致，只有实际提交图可改变；五机的地图与真实墙面credit也必须不退。

完整门槛、首测结果及结论见JSON/TXT。零新正式地图、零五图，不是比赛提交包。`source_delta.json`保存三份改动的精确原始字节及SHA；`changes.diff`供阅读；基准研究源码归档有固定SHA和GitHub链接。没有Gurobi、环境覆盖或官网上传。

[OctoMap原始API说明](https://octomap.github.io/octomap/doc/classoctomap_1_1OccupancyOcTreeBase.html)仅提供命中/空闲证据分离的工程参考，本规则不实现OctoMap或贝叶斯占据。实际分数证据才用于决定是否继续。
''').encode()
    inputs['SHA256SUMS.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in inputs.items()},ensure_ascii=False,indent=2)+'\n').encode()
    for n,b in inputs.items():
        p=WORK/SUB/n
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_bytes(b)
    git('add','--',SUB)
    git('commit','-m','Evaluate one historical final-map rule on frozen A-star base')
    git('fetch','origin','main')
    git('rebase','origin/main')
    git('push','origin','HEAD:main')
    commit=git('rev-parse','HEAD')
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    verified={}
    for n,b in inputs.items():
        url='https://raw.githubusercontent.com/quanliangwen/1/'+commit+'/'+urllib.parse.quote(SUB+'/'+n)
        got=opener.open(url,timeout=45).read()
        assert hashlib.sha256(got).hexdigest()==hashlib.sha256(b).hexdigest(),n
        verified[n]=hashlib.sha256(got).hexdigest()
    p=F/'PUBLICATION_FIRST.json'
    assert not p.exists()
    out=dict(status='PASS_REMOTE_STAGE145_ALL_BYTES_AND_SHA256',commit=commit,
             url='https://github.com/quanliangwen/1/tree/'+commit+'/'+SUB,sha256=verified,contest_release=False)
    p.write_bytes((json.dumps(out,ensure_ascii=False,indent=2)+'\n').encode())
    print(json.dumps(dict(status=out['status'],commit=commit,url=out['url'],files=len(inputs))))

if __name__=='__main__':main()
