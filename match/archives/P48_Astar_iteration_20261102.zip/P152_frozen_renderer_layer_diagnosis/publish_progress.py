from pathlib import Path
import hashlib,importlib.util,json,urllib.parse,urllib.request
F=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('publisher_common',F.parent/'publish_progress.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
inputs={}
def add(stage,names):
    for n in names:inputs[stage+'/'+n]=(F.parent/stage/n).read_text(encoding='utf-8-sig').replace('\r\n','\n').encode()
add('P151_waiting_view_conflict_review',['check_local_views.py','COUNTEREXAMPLE_FIRST.json','分析结论.txt'])
add('P149_ready_waiting_coordinator',['CANCEL_DECISION_FIRST.json','TERMINAL_REJECTION_FIRST.json','FIRST_ERROR.json'])
add(F.name,['分析依据与小测试结论.txt','prepare_diagnostic.py','check_freeze_contract.py','STATIC_CONTRACT_FIRST.json','PREDECLARATION_FIRST.json','LAUNCH_BINDING_FIRST.json','check_sdk_renderer_layers.py','run_diagnostic.py','TURN_PROGRESS_FIRST.json'])
inputs['P149_ready_waiting_coordinator/PRE_SDK_REJECTION.md']='''# P149终态：在SDK前自主取消

P151直接调用冻结P149的实际资格、选举、联合几何和验证函数。两个成员各自收到的ready状态不同，分别成功认证并接受同一个等待点，坐标距离0px；每个局部证书通过不能保证整个机群实际采用同一方案。

在实际进程/start及WAITING状态核对后，02:54:54写取消标志；02:55:46旧runner退出。没有两样本准入回执，没有科学运行前guard/result，零SDK/零native。原统一停止机制将异常记作`Human stop`，该原始记录保留；这是助手依反例自主否决候选，不是用户暂停或SDK运行失败。目标继续ACTIVE，绝不重启P149。

停车分支停止，不为触发规则继续堆协议。下一轮P152只观察原P48 A*冻结输出各绘图层，地图精度优先。
'''.encode()
readme='''# P152：冻结输出后定位地图误绘来源

保留原P48 A*全部42项payload，无新控制器、无SDK修改、不使用Gurobi。P149已因P151实际规则反例在SDK前取消，停止停车分支。

本次只安排一次作者CROSS观察闭环，最多800帧；实际控制/投放/提交全部冻结后，再生成同一own memory的raw参考图、实际拟合线/边界图、实际短墙补全图、实际边界推断图和最终多方向支持图。所有图像先冻结，再读取作者真值评分，不将诊断分数交给控制器。

9项静态作用域检查与原42项payload SHA通过；真实身份核验尚待资源开跑。必须保持全部779帧、健康、提交SHA、最终地图分和任务链与留存底本一致。底本两机49健康的旧失败不会变为通过；本次不是性能放行或比赛得分。

当前唯一SDK调度已离线排队，原CPU/负载门槛未满足，尚无新运行结果。没有正式单图或五图计划。拿到层归因证据后再决定一条最小规则，避免盲改整个绘图模块。
'''
inputs[F.name+'/README.md']=readme.encode()
inputs['LATEST.md']='''# P48 A*持续迭代：地图误绘归因

- [P151实际协议反例](P151_waiting_view_conflict_review/分析结论.txt)：不同就绪视图可生成同一个等候点。P149已在SDK前自主取消，零SDK/零native，持续目标未暂停。
- [P152冻结输出分层诊断](P152_frozen_renderer_layer_diagnosis/README.md)：原42项代码不改；控制结束后分别检查拟合墙线、短墙补全、边界推断和多方向支持。唯一观察闭环等待原资源门槛，暂无新成绩。

原A*五图74.255883/50保持，正式V09不变，没有新比赛提交包。P148无效执行、P145/P146失败和旧P03滤波退步均保留，不重跑救分。
'''.encode()
checks={n:hashlib.sha256(data).hexdigest()for n,data in inputs.items()}
inputs[F.name+'/PUBLICATION_SHA256SUMS.json']=(json.dumps(checks,ensure_ascii=False,indent=2)+'\n').encode()
assert c.git('status','--porcelain')==''
root=c.WORK/c.TASK
for n,data in inputs.items():
    p=root/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
c.git('add','--',c.TASK+'/P151_waiting_view_conflict_review',c.TASK+'/P149_ready_waiting_coordinator/CANCEL_DECISION_FIRST.json',c.TASK+'/P149_ready_waiting_coordinator/TERMINAL_REJECTION_FIRST.json',c.TASK+'/P149_ready_waiting_coordinator/FIRST_ERROR.json',c.TASK+'/P149_ready_waiting_coordinator/PRE_SDK_REJECTION.md',c.TASK+'/'+F.name,c.TASK+'/LATEST.md')
c.git('commit','-m','Reject inconsistent waiting protocol before SDK and prepare renderer provenance')
c.git('fetch','origin','main');c.git('rebase','origin/main');c.git('push','origin','HEAD:main')
commit=c.git('rev-parse','HEAD');opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));verified={}
for n,data in inputs.items():
    got=opener.open('https://raw.githubusercontent.com/quanliangwen/1/'+commit+'/'+urllib.parse.quote(c.TASK+'/'+n),timeout=45).read()
    assert hashlib.sha256(got).hexdigest()==hashlib.sha256(data).hexdigest(),n
    verified[n]=hashlib.sha256(got).hexdigest()
out=dict(status='PASS_REMOTE_BYTES_AND_CHECKSUMS',commit=commit,files=len(inputs),sha256=verified,url='https://github.com/quanliangwen/1/blob/'+commit+'/'+c.TASK+'/LATEST.md',not_contest_release=True)
p=F/'PUBLICATION_FIRST.json';assert not p.exists();p.write_bytes((json.dumps(out,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in out.items()if k!='sha256'}))
