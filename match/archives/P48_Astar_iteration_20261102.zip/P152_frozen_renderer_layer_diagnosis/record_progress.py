from pathlib import Path
import datetime,hashlib,json,subprocess
F=Path(__file__).resolve().parent
P=F.parent/'P149_ready_waiting_coordinator';C=F.parent/'P151_waiting_view_conflict_review'
assert not(P/'TERMINAL_REJECTION_FIRST.json').exists()
status=json.loads((P/'STATUS.json').read_text())
err=json.loads((P/'FIRST_ERROR.json').read_text())
assert status['status']=='STOP_FIRST_DIAGNOSTIC_ERROR'and 'Human stop'in err['traceback']
assert not(P/'RESOURCE_TWO_SAMPLE_FIRST.json').exists()and not(P/'READY_WAITING_FIRST_SERIAL.capture.txt').exists()
ps=subprocess.run(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process -Filter 'ProcessId=115628' | Select-Object ProcessId,CreationDate,CommandLine | ConvertTo-Json -Compress"],capture_output=True,text=True,check=True)
assert not ps.stdout.strip(),ps.stdout
terminal=dict(status='REJECTED_AUTONOMOUSLY_BEFORE_ANY_SDK_FRAME',reason='Verified divergent-readiness protocol counterexample, not a human pause or measured SDK failure.',
              legacy_runner_error_preserved=True,windows_handle_missing=True,
              capacity_two_sample_receipt_absent=True,scientific_pre_run_guard_receipt_absent=True,
              cancel_decision_sha256=hashlib.sha256((P/'CANCEL_DECISION_FIRST.json').read_bytes()).hexdigest(),
              counterexample_sha256=hashlib.sha256((C/'COUNTEREXAMPLE_FIRST.json').read_bytes()).hexdigest(),
              sdk_frames=0,native_rounds=0,goal_remains_active=True,automatic_restart=False)
(P/'TERMINAL_REJECTION_FIRST.json').write_bytes((json.dumps(terminal,ensure_ascii=False,indent=2)+'\n').encode())
note='''P151真实规则反例与P149取消（2026-11-02）

直接调用冻结P149的实际_waiting_eligible、waiting_leader、propose_waiting_plan和validate_plan。两机均空载、已真实就绪，但双方最近收到对方ready=False：本机资格集合分别{0}/{1}。同一个known-free图上只有一个原规则圆环候选格，每个实例分别通过原联合终点图证书，并接受完全相同的等待坐标，距离0<原44px排斥值。
这不是物理碰撞或官方地图复现，而是当前信息条件下规则不能保证不同无人机等待点彼此分离的精确反例。P149本来已声明不提供共识，本次进一步给出了可执行的具体后果；不能只因每个局部证书通过就推断联合等候安全。
不继续层叠协议来强求这条停车线成为有效版：在其仍WAITING且实际Windows进程/start核对后写取消标志，02:55:46原runner退出；未达到两样本资源准入，科学预运行guard/result均未创建，零SDK/零native。原runner把统一STOP_REQUESTED写为Human stop，此字面异常保留，但CANCEL_DECISION/TERMINAL_REJECTION明确是助手根据反例自主拒绝候选，绝不是用户暂停或SDK运行失败。Goal保持ACTIVE。
P148失败和P149反例不能推断真实Map02尾弹已证拥堵；停车分支目前停止，原P48_ASTAR地图/布点/运动不叠这些模块。
'''
(C/'分析结论.txt').write_text(note,encoding='utf-8')
with(P/'分析依据与小测试结论.txt').open('a',encoding='utf-8')as f:f.write('\n'+note)
(P/'WORKING_HANDOFF.txt').write_text('P149已被P151真实helper反例在SDK前自主拒绝，115628已结束，零SDK/零native。FIRST_ERROR的Human stop是原runner统一标签，非用户暂停；见CANCEL_DECISION/TERMINAL_REJECTION。不能恢复/重跑本候选。最新P152冻结输出分层诊断是唯一新队列。\n\n'+(P/'WORKING_HANDOFF.txt').read_text(encoding='utf-8'),encoding='utf-8')
analysis='''P152 冻结输出后的绘图分层诊断（2026-11-02）

目标保持原P48_ASTAR独立底本；地图精度优先，最终原条件完整五图均分。不再继续叠加等待位规则。上一turn是PROGRESS：P148真实小测无效→资格原因→P149实现排队→P150否决盲扩大语义过滤。本turn也有实质进展：P151实际代码构造局部证书冲突，实际取消未开跑P149，避免无效/有缺口测试；转到地图误绘出处。

分析依据：A*已完成五图中每图误绘扣分大于漏墙项；P145作者最终输出过滤有局部收益，但P146正式Map02依旧未过门槛。P150进一步表明语义表面点不能直接当对象中心，宽过滤没有真实错误分类证据。应先弄清现有图中哪些层产生虚胖/误绘，而非盲调阈值。

一个纯观察诊断，不产生新控制器：使用原P48_ASTAR及留存作者CROSS设置，最多800帧、固定lab615/.05*step；所有实际控制/投放/提交完全冻结后，分别从同一own memory调用原raw参考图、实际Anchored线/边界层、实际box_dense短墙层、实际InferredFrame层、实际Bearing最终图。五组图片全部先固定，再读取作者真值评分；图层差异不反馈控制或以后任何动作。raw参考图不是实际live parent，必须单独标注，不把raw→Anchored差异当简单并集。

防止观察误改：9项静态契约通过，控制循环与原父本字节一致，42payload全部本地SHA不变。真实闭环必须779行控制/位置/库存/健康/地图SHA、提交SHA、任务与gate链和各最终地图分全部与留存父本相同；冻结后额外调用不能改own memory任何ndarray，full层必须等于原冻结图。首错/身份差异停止，不自动修候选或刷seed恢复资格。

父本344步两机49健康失败保留，这不是健康修复或性能放行，不以新层诊断绕过旧失败。图层分数只说明同一冻结状态的输出差异，不代表将其删除后的全游戏轨迹/总分或官方Map02因果改善。

当前唯一SDK离线诊断：Windows114360/startUTC02:56:49.377766/run_diagnostic.py；H/P152_Astar_frozen_renderer_layers_20261102，14h有限等待。原CPU<=60/loadcore<=.4/RAM8GiB/盘12GiB两60秒，SDK e2f022b124SHA、team006、时限线程与原41pin依赖不变。初样CPU94/load240/256不满足，在WAITING非比赛已运行。没有新候选/正式ZIP/native/五图计划。

下一步：只有实际层归因证据出来才选择一条规则：若误绘来自特定推断层，先用同冻结输入做反例和最小保守改动；若实测层也同样不准，应转观测/定位来源，不用收窄所有墙掩盖漏图。不直接移植旧P03有色滤波（已正式Map02退步93.828vs95.626），不把其旧历史97.17当当前有效规则。
'''
(F/'分析依据与小测试结论.txt').write_text(analysis,encoding='utf-8')
handoff='''最新P152_frozen_renderer_layer_diagnosis（2026-11-02），优先于P149活动调度历史。Goal ACTIVE/原P48_ASTAR独立底本/地图精度优先/一次一条规则，不spawn代理、不自行暂停complete、不发布比赛包。
先读分析TXT、PREDECLARATION_FIRST/STATIC_CONTRACT_FIRST/LAUNCH_BINDING_FIRST和最新STATUS/RESULT_FIRST/FIRST_ERROR。唯一Windows离线SDK调度114360/startUTC02:56:49.377766/run_diagnostic.py，14h有限；服务器H/P152_Astar_frozen_renderer_layers_20261102。先核实际CIM command/start/STATUS、scoped/global lock/registry，不重复启动；等待也占唯一调度。初样CPU94/load240/256超原门槛，尚未SDK。
当前最多一次原作者CROSS800帧/lab615/.05*step，原42payload不改，零native/no automatic five。仅在所有动作/提交冻结后评估原渲染各层；全部图先固定才作者truth，禁止将诊断分数反馈控制。9静态契约PASS不是SDK结果；实际必须全部779行/提交/图分/健康/任务/gate链与留存P142同，memory所有ndarray不改/full图匹配。父本健康49失败仍保留，不救资格；只是分层出处，不是完整分或官方因果改善。
P149115628已经退出，P151实际helper反例证实不同ready视图可各自通过局部联合证书、接受同一个等待点，0距离<44。02:54:54在其实际WAITING核验后自主取消，02:55:46旧runner记录Human stop原错保留；CANCEL_DECISION/TERMINAL_REJECTION明确非人类暂停、非SDK失败，零SDK/零native，不能恢复P149或P148。停止停车分支，不继续为触发/收益堆协议。
P150零SDK否决盲扩大角宽/中心圆擦图；P145实际输出规则不叠。P03旧滤波正式图退步不重试。A*完整五图仍74.255883/50，正式V09不变，J17 Gurobi排除。
原服务器/资源/环境/数据边界全部保持：R=/home/junhao/quan/parallel_test_solver/match；H=R/solver_study/framework_screen_20261016/best87_independent_20261025；sshjunhao@10.112.162.60；科学Python只R/.venv/bin/python；SDK e2f022b124SHA/team006/原时限线程/无外seed；CPU<=60/loadcore<=.4/RAM8GiB/盘12GiB两60秒，旧高负载授权耗尽。NumPy1.26.4/Pandas3.0.6/CV4.11/41pins不安装覆盖，不碰外CCMCKP/旧match7。
生产只own公共观测和实际收到消息，禁竞赛真图/BLUE私态console/peer对象/历史输入硬码，作者truth只输出冻结后。竞赛NPZ/pickle只首次opaqueSHA不反序列化或重复已审raw。每次依据/实改/首错/小测/淘汰写TXT交接；仅实质机制/分数/失败/决策通知，状态无变化安静。新交付GitHub quanliangwen/1 swarm-eod任务目录并核远端SHA，E:/codex必要临时非永久备份。用户停止立即停后续，普通分析测试自主持续。
本goalturn PROGRESS（反例→实际取消→新观察诊断），不是只轮询；资源门槛未恢复不可强开或无限造夹具。后续真实外部阻塞重复三goalturn且无意义进展时再按goal blocked审计。
'''
(F/'WORKING_HANDOFF.txt').write_text(handoff,encoding='utf-8')
current=F.parent/'CURRENT_HANDOFF.txt';current.write_text(handoff+'\n【以下历史接续】\n'+current.read_text(encoding='utf-8'),encoding='utf-8')
(F/'TURN_PROGRESS_FIRST.json').write_bytes((json.dumps(dict(previous_goal_turn='PROGRESS',current_goal_turn='PROGRESS',evidence=['P151 actual helper conflict','P149 actual pre-SDK rejection and missing handle','P152 immutable observer and nine contracts/new unique waiting SDK'],goal_active=True),indent=2)+'\n').encode())
print('P149 terminal/P151 counterexample/P152 observer protocol and handoff recorded')
