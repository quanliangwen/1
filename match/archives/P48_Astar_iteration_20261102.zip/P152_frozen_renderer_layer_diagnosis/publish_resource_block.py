from pathlib import Path
import hashlib,importlib.util,json,urllib.parse,urllib.request
F=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('publication_common',F.parent/'publish_progress.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
audit=json.loads((F/'RESOURCE_BLOCK_AUDIT_FIRST.json').read_text())
assert audit['status']=='THREE_GOAL_TURN_EXTERNAL_RESOURCE_BLOCK_CONFIRMED'
note='''资源阻塞审计（2026-11-02UTC03:01）
连续三个goalturn同一CPU/负载准入阻塞。前两轮仍取得真实代码/机制证据，本轮为VERIFIED_WAIT：Windows114360/start02:56:49.377766同命令实际存活，原SDK观察仍未启动；当前CPU99.9922%、load309.92/256，RAM82.96GiB/盘20.24GiB正常。
下一有决定价值的证据是冻结P152绘图层真实输出；重复纯夹具不能代替实际地图精度归因。本轮按系统规则将完整目标标记资源BLOCKED，未完成，也不是人类暂停。唯一P152离线排队、原条件/14小时有限窗口和automation90监控都保留；不kill/restart/并开，不降低准入，不动外部任务或源码/依赖。
资源恢复时现有runner会自动依原两样本gate继续；到期或失败保留真实原错，不自动换标签重启。自动化只监控此已活队列和实质外部变化，不无限造人工小测试，也不调用create_goal伪造active。新的目标状态恢复由用户或系统控制。
原目标所有范围/数据/发布约束保留，正式V09不变，无新SDK/native分数或参赛发布。
'''
(F/'资源阻塞说明.txt').write_bytes(note.encode())
for p in[F/'WORKING_HANDOFF.txt',F.parent/'CURRENT_HANDOFF.txt']:
    old=p.read_text(encoding='utf-8');p.write_bytes((note+'\n【以下阶段历史，最新资源状态以上文为准】\n'+old).encode())
inputs={F.name+'/'+n:(F/n).read_text(encoding='utf-8-sig').replace('\r\n','\n').encode()for n in['资源阻塞说明.txt','RESOURCE_BLOCK_AUDIT_FIRST.json','audit_resource_wait.py']}
inputs['LATEST.md']='''# P48 A*当前状态：等待原资源准入

[资源阻塞审计与保留队列](P152_frozen_renderer_layer_diagnosis/资源阻塞说明.txt)：UTC03:01核实CPU约100%、load310/256，同一114360等待进程/start仍活。连续三goalturn同阻塞，下一需要真实SDK图层输出，不能用更多人工PASS代替。按系统资源BLOCKED审计处理，目标未完成、不是用户暂停。

原P152单次观察离线队列与14小时窗口保留，资源达标后原runner自动继续；监控保持，不重启/并开/放宽条件。暂无新小闭环或正式成绩。

[P151协议反例](P151_waiting_view_conflict_review/分析结论.txt)已使P149在SDK前取消，零SDK/零native。[P152冻结输出分层观察](P152_frozen_renderer_layer_diagnosis/README.md)原42项源码不改，定位实际误绘来源。原A*五图74.255883/50、正式V09保持，无新提交包。
'''.encode()
checks={n:hashlib.sha256(data).hexdigest()for n,data in inputs.items()}
inputs[F.name+'/RESOURCE_BLOCK_PUBLICATION_SHA256SUMS.json']=(json.dumps(checks,ensure_ascii=False,indent=2)+'\n').encode()
assert c.git('status','--porcelain')==''
dest=c.WORK/c.TASK
for n,data in inputs.items():
    p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
c.git('add','--',c.TASK+'/'+F.name,c.TASK+'/LATEST.md')
c.git('commit','-m','Record three-turn resource block while preserving live offline observer')
c.git('fetch','origin','main');c.git('rebase','origin/main');c.git('push','origin','HEAD:main')
commit=c.git('rev-parse','HEAD');opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));verified={}
for n,data in inputs.items():
    got=opener.open('https://raw.githubusercontent.com/quanliangwen/1/'+commit+'/'+urllib.parse.quote(c.TASK+'/'+n),timeout=45).read()
    assert hashlib.sha256(got).hexdigest()==hashlib.sha256(data).hexdigest(),n
    verified[n]=hashlib.sha256(got).hexdigest()
out=dict(status='PASS_REMOTE_BYTES_AND_CHECKSUMS',commit=commit,files=len(inputs),sha256=verified,url='https://github.com/quanliangwen/1/blob/'+commit+'/'+c.TASK+'/LATEST.md',queue_cancelled=False)
p=F/'RESOURCE_BLOCK_PUBLICATION_FIRST.json';assert not p.exists();p.write_bytes((json.dumps(out,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in out.items()if k!='sha256'}))
