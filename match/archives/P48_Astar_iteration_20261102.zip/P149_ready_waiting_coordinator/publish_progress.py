"""Publish reviewed results and exact changed source, never a contest ZIP."""
from pathlib import Path
import base64,hashlib,importlib.util,json,urllib.parse,urllib.request
F=Path(__file__).resolve().parent
ROOT=F.parent
spec=importlib.util.spec_from_file_location('publisher_common',ROOT/'publish_progress.py')
common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
inputs={}
def add(stage,names):
    for name in names:
        p=ROOT/stage/name
        inputs[stage+'/'+name]=p.read_text(encoding='utf-8-sig').replace('\r\n','\n').encode()
add('P148_joint_waiting_rule',[
    '分析依据与小测试结论.txt','DESIGN_REVIEW_FIRST.json','V1_SCOPE_COUNTEREXAMPLE_FIRST.json',
    'CONTRACT_V2_FIRST.json','CANDIDATE_MANIFEST_V2_FIRST.json','PREDECLARATION_V2_FIRST.json',
    'SDK_GATE_ADDENDUM_FIRST.json','RESULT_V2_FIRST.json','NOOP_DIAGNOSIS_FIRST.json',
    'review_noop.py','joint_waiting_v2.py','waiting_core_v2.py','check_contracts_v2.py',
    'check_sdk_joint_waiting_v2.py','run_diagnostic_v2.py','prepare_workspace_v2.py'])
add(F.name,[
    '目标与任务.txt','分析依据与小测试结论.txt','DESIGN_FIRST.json','CONTRACT_FIRST.json',
    'CANDIDATE_MANIFEST_FIRST.json','PREDECLARATION_FIRST.json','SDK_GATE_ADDENDUM_FIRST.json',
    'LAUNCH_BINDING_FIRST.json','prepare_rule.py','build_checks.py','check_contracts.py',
    'prepare_sdk.py','waiting_core.py','joint_waiting.py','wait_connectivity.py',
    'check_sdk_ready_waiting.py','run_diagnostic.py','prepare_workspace.py'])
# Canonical UTF-8 scripts are for reading. Exact actual payload bytes are retained separately.
base=json.loads(Path('E:/codex/P48_astar_five_20261102/CANDIDATE_MANIFEST.json').read_text(encoding='utf-8-sig'))
for stage,project,manifest in[
    ('P148_joint_waiting_rule','candidate_project_v2','CANDIDATE_MANIFEST_V2_FIRST.json'),
    (F.name,'candidate_project','CANDIDATE_MANIFEST_FIRST.json')]:
    folder=ROOT/stage;frozen=json.loads((folder/manifest).read_text())
    delta={}
    for name,h in frozen['candidate_files'].items():
        p=folder/project/name;data=p.read_bytes()
        assert hashlib.sha256(data).hexdigest()==h
        short=p.name
        if base['payload_files'].get(short)==h:continue
        delta[name]=dict(sha256=h,base64=base64.b64encode(data).decode())
    assert len(delta)==4
    doc=dict(base_archive_sha256=base['sha256'],
             base_url='https://raw.githubusercontent.com/quanliangwen/1/7820d3deac9b063bf6ca470c371e33662a428012/swarm-eod/P48_Astar_five_20261102/P48_Astar_research.zip',
             interpretation='Verify base solution payload hashes then overlay these exact paths. Not a contest submission or release qualification.',
             actual_candidate_files=frozen['candidate_files'],changed_or_new_payload=delta)
    inputs[stage+'/source_delta_actual.json']=(json.dumps(doc,ensure_ascii=False,indent=2)+'\n').encode()
status=json.loads((F/'STATUS.json').read_text())
readme='''# P148失败诊断与P149单项修正

当前目标继续为原P48 A*底本，地图精度优先，一次一条规则，真实小试支持后才正式单图/五图。目标和接续任务保持ACTIVE。既有A*完整五图74.255883/50；没有新版本超过的完整证据，没有新比赛提交包。

P148在作者SDK首次闭环779步、10/10，实际提交地图95.470342918942、墙体覆盖74.658009203808、时间100。全部控制、目标、地图和健康与留存父本逐帧一致：只出现两次实际地图交换就绪，没有BUILD、接单或等待到达，执行与收益门槛失败，不进入正式评测。这里未运行BLUE，72.666773为可控分项小计，不能称完整红分。

实际received fleet快照12个时点确认：原规则选最小空载编号，但这个成员尚未符合等待资格；已经完成交换的1号/2号始终不能协调。没有进入几何求解，因此不能将失败解释为环形位物理不可达，更不能说停车已修复Map02缺弹。

P149只有一个功能修正：在真正fresh ready且空载的成员中选协调者，创建、接收和控制采用同一资格域。原补扫、SORTIE、首次交换、地图/布点/运动、等待几何/预算/参数和所有SDK评估门槛保持。52项纯协议/范围/反例检查通过，真实SDK已排队，当前资源超原门槛，尚未开跑；不会放宽条件或自动跑五图。若没有实际收益，停止停车分支，回到地图误绘/尾任务链。

局部ready视图可能不同，不提供分布式共识或动态多机避碰保证。所有实际飞行仍原A*。V1是在任何SDK前发现范围缺口的未运行草案；V2才是P148首次真实SDK，不抹掉原错误。P149保留P148失败而修改明确资格逻辑，不调参数、种子或门槛救分。

`source_delta_actual.json`保存实际四项新/改payload的精确字节及全部45项清单，绑定公开原A*源码归档；可读.py规范化为LF，精确字节以delta与manifest为准。这是研究源码和结果，不是赛事发布资格。
'''
inputs['P149_ready_waiting_coordinator/README.md']=readme.encode()
inputs['LATEST.md']=('''# 当前A*持续迭代记录

[P148真实SDK失败依据与P149资格修正](P149_ready_waiting_coordinator/README.md)。P148未产生新动作，不扩正式评测；P149已通过52项小检查，唯一SDK任务等待原资源门槛。Goal与持续接续ACTIVE。

已完成A*五图仍74.255883/50，无新比赛包；正式V09保持。上一P146 Map02总72.055594/9枚的失败不抹掉、不重跑。
''').encode()
checks={n:hashlib.sha256(data).hexdigest()for n,data in inputs.items()}
inputs[F.name+'/PUBLICATION_SHA256SUMS.json']=(json.dumps(checks,ensure_ascii=False,indent=2)+'\n').encode()
dest=common.WORK/common.TASK
assert common.git('status','--porcelain')==''
for name,data in inputs.items():
    p=dest/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
common.git('add','--',common.TASK+'/P148_joint_waiting_rule',common.TASK+'/'+F.name,common.TASK+'/LATEST.md')
common.git('commit','-m','Record no-op waiting SDK diagnosis and ready-coordinator candidate')
common.git('fetch','origin','main');common.git('rebase','origin/main');common.git('push','origin','HEAD:main')
commit=common.git('rev-parse','HEAD')
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));verified={}
for name,data in inputs.items():
    url='https://raw.githubusercontent.com/quanliangwen/1/'+commit+'/'+urllib.parse.quote(common.TASK+'/'+name)
    got=opener.open(url,timeout=45).read();h=hashlib.sha256(got).hexdigest()
    assert h==hashlib.sha256(data).hexdigest(),name
    verified[name]=h
result=dict(status='PASS_REMOTE_BYTES_AND_CHECKSUMS',commit=commit,files=len(inputs),sha256=verified,
            url='https://github.com/quanliangwen/1/blob/'+commit+'/'+common.TASK+'/'+F.name+'/README.md',
            not_contest_release=True,local_delivery_copy_created=False,status_at_publication=status)
p=F/'PUBLICATION_FIRST.json';assert not p.exists();p.write_bytes((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in result.items()if k not in['sha256','status_at_publication']}))
