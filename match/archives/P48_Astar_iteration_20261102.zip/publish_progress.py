"""Publish only this task's reviewed artifacts; verify canonical remote bytes."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
import urllib.parse
import urllib.request

ROOT=Path(__file__).resolve().parent
WORK=Path('E:/codex/P48_astar_five_20261102/github_worktree')
def _task_destination():
    # Publication-only gate: SDK/evaluation processes never import this module.
    marker=ROOT/'GITHUB_MIGRATION.lock'
    deadline=time.monotonic()+3600
    while marker.exists():
        if time.monotonic()>=deadline:raise TimeoutError('GitHub directory migration did not release publication gate')
        time.sleep(1)
    config=ROOT/'GITHUB_DESTINATION.json'
    return json.loads(config.read_text(encoding='utf-8-sig'))['task_prefix'] if config.exists() else 'match/P48_Astar_iteration_20261102'

TASK=_task_destination()
GIT='D:/Git/cmd/git.exe'
ENV=dict(os.environ,GIT_TERMINAL_PROMPT='0')

def git(*args):
    p=subprocess.run([GIT,'-c','http.proxy=','-c','credential.interactive=never','-C',str(WORK),*args],capture_output=True,check=True,env=ENV,timeout=120)
    return p.stdout.decode('utf-8',errors='strict').strip()

def main():
    review=ROOT/'P142_profile_and_task_chain/RESULT_FIRST.json'
    assert review.exists(), 'Finish diagnostic before publication'
    result=json.loads(review.read_text(encoding='utf-8-sig'))
    inputs={}
    for stage,names in {
        'P141_baseline_diagnosis':['目标与任务.txt','分析依据与结论.txt','BASELINE_DIAGNOSIS_FIRST.json','analyze_existing.py'],
        'P142_profile_and_task_chain':['PREDECLARATION_FIRST.json','RESULT_FIRST.json','HEALTH_REVIEW_FIRST.json','build_diagnostic.py','check_sdk_astar_profile.py','run_diagnostic.py','review_first_failure.py'],
    }.items():
        for name in names:
            p=ROOT/stage/name
            inputs[stage+'/'+name]=p.read_text(encoding='utf-8-sig').replace('\r\n','\n').encode('utf-8')
    conclusion=ROOT/'P142_profile_and_task_chain/分析结论.txt'
    if conclusion.exists():inputs['P142_profile_and_task_chain/分析结论.txt']=conclusion.read_text(encoding='utf-8-sig').replace('\r\n','\n').encode()
    p143=ROOT/'P143_drive_encounter_evidence'
    for name in ['PREDECLARATION_FIRST.json','RESULT_FIRST.json','MOTOR_REVIEW_FIRST.json','分析结论.txt','build_trace.py','check_sdk_drive_evidence.py','build_runner.py','run_diagnostic.py','analyze_drive_evidence.py']:
        p=p143/name
        if p.exists():inputs['P143_drive_encounter_evidence/'+name]=p.read_text(encoding='utf-8-sig').replace('\r\n','\n').encode()
    for name in ['RESULT_FIRST.json','check_recorded_inputs.py']:
        p=ROOT/'P144_momentum_tube_countercheck'/name
        inputs['P144_momentum_tube_countercheck/'+name]=p.read_text(encoding='utf-8-sig').replace('\r\n','\n').encode()
    baseline_url='https://github.com/quanliangwen/1/tree/7820d3deac9b063bf6ca470c371e33662a428012/swarm-eod/P48_Astar_five_20261102'
    readme=f'''# P48 A* 持续分析与规则验证（2026-11-02）

工作底本已切换到冻结P48_ASTAR；Goal和automation90已恢复ACTIVE。一次一条规则，先分析、反例及真实SDK小闭环，有希望才正式单图和同条件五图。地图精度优先，最终以完整五图红队平均分评价，不以路线更直或作者场景分数代替。

[已完成的A*五图与冻结源码]({baseline_url})：74.2558833655，50/50，双方无墙钟超时；旧P48留存72.6026760546。自然随机不同，仅观察差异。

## 本轮已完成

- P141：5份已首审的own RED日志和公开评分复盘，零新比赛。Map01末投和提交同在1194步；五图误绘扣分均大于漏墙项。Map04满投10枚但覆盖65.8717，不能解释为少投，也不能把最终图当规划时输入。
- P142：诊断状态 `{result['status']}`。最多两臂同一作者场景，OFF/ON只区别cProfile；完整任务快照是只读观察。这里不运行蓝队，不复现官方Map04，不构成新的完整红队成绩。
- P142实际在OFF首臂健康检查失败（344步两机各掉1健康），ON未启动；原错误和门槛保留。P143仅补原失败的实际感知/驱动证据，要求全部动作/地图/健康与原失败完全一致，不重试恢复性能资格，不计新成绩。
- P143全部779帧与原失败一致，实际感知说明侧向交会进入目标方向管道较晚，已经刹车时仍有明显惯性速度。P144进一步用已有输入否决“仅加自身速度方向的同宽管道就能补上缺口”，没有为这个不成立的简单改动开比赛。
- 正式V09提交包保持；没有发布新的比赛包，没有使用Gurobi或改SDK/依赖/正式门槛。

目标、依据、小测协议、脚本、结果与限制见各子目录。实际运行的详细逐帧输入输出保留在必要临时工作区和服务器证据链，不把临时存储当用户下载或永久备份。后续分析按目标自主接续，用户停止立即停后续。

## 工程原文

[Nav2 Smac2D](https://docs.nav2.org/jazzy/configuration_and_development/configuration_guide/planners_plugins/smac/smac_2d/configuring_smac_2d/)提供代价感知的全向A*工程参考；[Nav2重规划条件](https://docs.nav2.org/rolling/getting_started/nav2_behavior_trees/trees/nav_to_pose_with_consistent_replanning_and_if_path_becomes_invalid/)区分目标变化、路径失效和周期触发。只借工程原则，不搬阈值、清图或重试，不将文献当游戏提分证据。
'''
    inputs['README.md']=readme.encode()
    checks={name:hashlib.sha256(data).hexdigest() for name,data in inputs.items()}
    inputs['SHA256SUMS.json']=(json.dumps(checks,ensure_ascii=False,indent=2)+'\n').encode()
    dest=WORK/TASK
    dest.mkdir(parents=True,exist_ok=True)
    for name,data in inputs.items():
        p=dest/name
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_bytes(data)
    git('add','--',TASK)
    git('commit','-m','Set P48 A-star iteration goal and publish baseline diagnostics')
    git('fetch','origin','main')
    git('rebase','origin/main')
    git('push','origin','HEAD:main')
    commit=git('rev-parse','HEAD')
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    verified={}
    for name,data in inputs.items():
        url='https://raw.githubusercontent.com/quanliangwen/1/'+commit+'/'+urllib.parse.quote(TASK+'/'+name)
        got=opener.open(url,timeout=45).read()
        assert hashlib.sha256(got).hexdigest()==hashlib.sha256(data).hexdigest(),name
        verified[name]=hashlib.sha256(got).hexdigest()
    receipt=dict(status='PASS_REMOTE_BYTES_AND_CHECKSUMS',commit=commit,
                 url='https://github.com/quanliangwen/1/tree/'+commit+'/'+TASK,sha256=verified,
                 not_contest_release=True,local_delivery_copy_created=False)
    out=ROOT/'PUBLICATION_FIRST.json'
    assert not out.exists()
    out.write_bytes((json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode())
    print(json.dumps(dict(status=receipt['status'],commit=commit,url=receipt['url'],files=len(inputs)),ensure_ascii=False))

if __name__=='__main__':main()
