"""Reference only: conflicting free evidence for unmeasured bearing expansion.

Not a Bayesian posterior and not a controller. Original parent and every raw
hit pixel are authoritative. No wall truth, teammate object or map label used.
"""
import math
import time
import numpy as np

def cross_source_support(bits):
    fields=np.asarray(bits,np.uint8)
    if fields.ndim!=3:return None
    supported=np.zeros(fields.shape[1:],bool)
    for source in range(fields.shape[0]):
        other=np.zeros(fields.shape[1:],np.uint8)
        for peer in range(fields.shape[0]):
            if peer!=source:other|=fields[peer]
        for angle in range(8):
            allowed=sum(1<<b for b in range(8)if min((b-angle)%8,(angle-b)%8)>=2)
            supported|=((fields[source]&(1<<angle))!=0)&((other&allowed)!=0)
    return supported

def free_direction_fields(records,width,height,step,team_size=5,deadline=None):
    shape=((height+3)//4,(width+3)//4)
    fields=np.zeros((team_size,*shape),np.uint8);frames=0;rays=0;invalid=0
    if not isinstance(records,dict):return fields,dict(status='NO_VALID_RECORD_DICTIONARY',frames=0,rays=0)
    distances=np.arange(24.,285.,2.)
    for key,record in records.items():
        if deadline is not None and time.perf_counter()>=deadline:
            return None,dict(status='ABSTAIN_BUDGET_NO_PARTIAL_ERASURE',frames=frames,rays=rays)
        try:
            source,stamp,_,origin,endpoints,*_=record
            if (not isinstance(source,(int,np.integer))or not isinstance(stamp,(int,np.integer))
                    or not 0<=source<team_size or not 0<=stamp<=step or tuple(key)!=(source,stamp)):
                invalid+=1;continue
            p=np.asarray(origin,float);ends=np.asarray(endpoints,float)
            if p.shape!=(2,)or ends.ndim!=2 or ends.shape[1]!=2 or not np.isfinite(p).all():
                invalid+=1;continue
            good=np.isfinite(ends).all(axis=1);ends=ends[good];v=ends-p
            lengths=np.linalg.norm(v,axis=1);good=lengths>36.;v=v[good];lengths=lengths[good]
            if not len(lengths):continue
            unit=v/lengths[:,None];points=p+distances[None,:,None]*unit[:,None,:]
            cols=np.floor((points[:,:,0]+width/2)/4).astype(int)
            rows=np.floor((height/2-points[:,:,1])/4).astype(int)
            xx=(cols+.5)*4-width/2;yy=height/2-(rows+.5)*4
            dx,dy=xx-p[0],yy-p[1]
            along=dx*unit[:,None,0]+dy*unit[:,None,1]
            across=np.abs(dx*unit[:,None,1]-dy*unit[:,None,0])
            valid=(rows>=0)&(rows<shape[0])&(cols>=0)&(cols<shape[1])
            # The center must actually lie within1px of the beam. Merely
            # clipping a four-pixel cell corner does not clear the whole cell.
            valid&=(across<=1.)&(along>=24.)&(along<np.minimum(285.,lengths[:,None]-12.))
            angles=np.mod(np.arctan2(unit[:,1],unit[:,0]),2*math.pi)
            sectors=np.floor(angles*(4/math.pi)).astype(np.uint8)
            raybits=np.broadcast_to(np.left_shift(np.uint8(1),sectors)[:,None],valid.shape)
            ids=rows[valid]*shape[1]+cols[valid]
            np.bitwise_or.at(fields[source].ravel(),ids,raybits[valid])
            frames+=1;rays+=len(lengths)
        except (TypeError,ValueError,IndexError,OverflowError):invalid+=1
    return fields,dict(status='COMPLETE_FREE_DIRECTION_REFERENCE',frames=frames,rays=rays,invalid_records=invalid)

def filter_expansion(image,parent,hits,records,width,height,step,team_size=5,deadline=None):
    original=np.asarray(image);base=np.asarray(parent);raw=np.asarray(hits)
    if (original.shape!=(height,width)or base.shape!=original.shape
            or raw.shape!=((height+1)//2,(width+1)//2)
            or not np.all(original[base>0]>0)):
        return original.copy(),dict(status='ABSTAIN_INPUT_CONTRACT',erased_pixels=0)
    fields,audit=free_direction_fields(records,width,height,step,team_size,deadline)
    if fields is None:return original.copy(),dict(audit,erased_pixels=0)
    negative=cross_source_support(fields)
    negative=np.repeat(np.repeat(negative,4,axis=0),4,axis=1)[:height,:width]
    protect=np.repeat(np.repeat(raw>0,2,axis=0),2,axis=1)[:height,:width]
    erase=(original>0)&(base==0)&~protect&negative
    result=original.copy();result[erase]=0
    return result,dict(audit,erased_pixels=int(erase.sum()),raw_positive_pixels_protected=int(protect.sum()),parent_preserved=bool(np.array_equal(result[base>0],original[base>0])),raw_positive_preserved=bool(np.array_equal(result[protect],original[protect])),negative_cells=int(np.count_nonzero(cross_source_support(fields))))
