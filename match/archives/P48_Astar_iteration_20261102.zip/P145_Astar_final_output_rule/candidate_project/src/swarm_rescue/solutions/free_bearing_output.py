"""One optional final-output rule; navigation and ordinary render untouched."""
import time,hashlib
import numpy as np
from swarm_rescue.solutions.frame_mapping import InferredFrameMemory
from swarm_rescue.solutions.free_bearing_support import filter_expansion

def complete_free_supported_output(memory,image,step):
    original=np.asarray(image);started=time.perf_counter();deadline=started+.5
    if (original.shape!=(int(memory.height),int(memory.width))
            or int(memory.FINE)!=2):
        return original,dict(status='ABSTAIN_GRID_CONTRACT',erased_pixels=0)
    try:
        parent=InferredFrameMemory.render(memory)
        result,audit=filter_expansion(original,parent,memory.hits,
            getattr(memory,'frame_records',{}),memory.width,memory.height,int(step),
            int(getattr(memory,'team_size',5)),deadline)
    except (ValueError,TypeError,IndexError,KeyError,OverflowError)as error:
        return original,dict(status='ABSTAIN_INVALID_EVIDENCE',erased_pixels=0,error_type=type(error).__name__)
    elapsed=time.perf_counter()-started
    # Cooperative checks bound optional work in ordinary inputs; primitive
    # calls may overrun between checks. Never use a late partial result.
    if elapsed>.5:
        result=original;audit=dict(status='ABSTAIN_OUTPUT_BUDGET',erased_pixels=0)
    audit=dict(audit,seconds=elapsed,original_sha256=hashlib.sha256(original.tobytes()).hexdigest(),
        output_sha256=hashlib.sha256(result.tobytes()).hexdigest())
    return result,audit

class CrossSourceFreeOutputMixin:
    def submit_exploration_map(self,image):
        if float(self.elapsed_walltime)+1.>=float(self.walltime_limit):
            self.last_free_support_output_audit=dict(status='ABSTAIN_ORIGINAL_WALLCLOCK_GUARD',erased_pixels=0)
            return super().submit_exploration_map(image)
        result,audit=complete_free_supported_output(self.memory,image,int(self.elapsed_timestep))
        self.last_free_support_output_audit=audit
        return super().submit_exploration_map(result)
