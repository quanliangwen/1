"""Exact line-cell coverage vs retained own query masks. No SDK or physics."""
from pathlib import Path
from fractions import Fraction
from types import SimpleNamespace
import ast,json,hashlib,base64,datetime,math,copy
import numpy as np
F=Path(__file__).resolve().parent;out=F/'RECORDED_SEGMENT_REVIEW_FIRST.json';assert not out.exists()
B=Path('E:/codex/PJ01_rule_refinement_20261101/P48_P35_refresh_deferral_candidate/candidate_project/src/swarm_rescue/solutions')
P=Path('E:/codex/PJ01_rule_refinement_20261101/P10_route_cause_observation');source=P/'OBS_A/MECHANISM_REVIEW.json'
assert json.loads((P/'CAMPAIGN_CLIENT_REVIEW.json').read_text())['status']=='PASS'
assert json.loads((P/'OBS_A/CLIENT_FIRST_RAW_REVIEW.json').read_text())['status']=='PASS'
env=dict(np=np)
def method(file,cls,name):
 tree=ast.parse((B/file).read_text());c=next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name==cls);f=copy.deepcopy(next(n for n in c.body if isinstance(n,ast.FunctionDef)and n.name==name));f.decorator_list=[]
 exec(compile(ast.Module(body=[f],type_ignores=[]),'actual_'+name,'exec'),env);return env[name]
line=method('fast_exploration.py','CoordinatedMapMemory','_line_cells');world=method('greedy_mapping.py','MapMemory','world_to_cell')
def supercover(a,b):
 r,c=map(int,a);er,ec=map(int,b);dr,dc=abs(er-r),abs(ec-c);sr=0 if r==er else 1 if er>r else-1;sc=0 if c==ec else 1 if ec>c else-1
 cells={(r,c)};nr=nc=0
 while(r,c)!=(er,ec):
  if r==er:kind=1
  elif c==ec:kind=-1
  else:
   left=(2*nr+1)*dc;right=(2*nc+1)*dr;kind=-1 if left<right else 1 if left>right else 0
  if kind<=0:
   if kind==0:cells.add((r+sr,c));cells.add((r,c+sc))
   r+=sr;nr+=1
  if kind>=0:c+=sc;nc+=1
  cells.add((r,c))
 return cells
def intersects(a,b,cell):
 lo,hi=Fraction(0),Fraction(1)
 for x,y,k in zip(a,b,cell):
  start=2*x;delta=2*(y-x);lower,upper=2*k-1,2*k+1
  if delta==0:
   if not lower<=start<=upper:return False
  else:
   x0,x1=Fraction(lower-start,delta),Fraction(upper-start,delta);lo=max(lo,min(x0,x1));hi=min(hi,max(x0,x1))
   if lo>hi:return False
 return True
checks={};pairs=[]
for a in [(1,1),(1,4),(3,2),(4,4)]:
 for b in [(r,c)for r in range(1,6)for c in range(1,6)]:
  actual=supercover(a,b);oracle={(r,c)for r in range(7)for c in range(7)if intersects(a,b,(r,c))}
  assert actual==oracle,(a,b,actual^oracle)
  assert actual==supercover(b,a)
  pairs.append((a,b))
checks['independent_exact_slab_oracle_100_pairs']=len(pairs)==100
mask=np.ones((5,5),bool);mask[2,1]=False;rr,cc=line((1,1),(2,2))
checks['actual_sampling_accepts_diagonal_corner_counterexample']=bool(mask[rr,cc].all())
checks['same_no_corner_cut_graph_rejects_counterexample']=any(not mask[cell]for cell in supercover((1,1),(2,2)))
assert all(checks.values())
def unpack(d):
 bits=np.unpackbits(np.frombuffer(base64.b64decode(d['bits']),np.uint8));return bits[:int(np.prod(d['shape']))].reshape(d['shape']).astype(bool)
events=json.loads(source.read_text())['route_events'];rows=[];excluded={}
def skip(key):excluded[key]=excluded.get(key,0)+1
for e in events:
 if e['kind']!='PLAN_RETURN':continue
 q=e['matched_query']
 if q is None or e['goal']is None or not e['route']:skip('missing_query_or_route');continue
 if e['final_goal_matching_query_count']!=1:skip('multiple_matching_queries');continue
 if q['query_kind']not in ['ordinary_frontier','provided_utility']:skip('explicit_destination');continue
 if e['role_after']!='ACQUISITION_EXPLORATION':skip('other_mode');continue
 m=unpack(q['masks']['walkable_mask']);memory=SimpleNamespace(width=q['world_width'],height=q['world_height'],CELL=q['cell_size'],shape=m.shape)
 cells=[tuple(q['source_cell'])]+[tuple(world(memory,p))for p in e['route']]
 old_ok=True;bad=[];touch_only=[]
 for index,(a,b)in enumerate(zip(cells,cells[1:])):
  rr,cc=line(a,b)
  if not m[rr,cc].all():old_ok=False;continue
  for cell in sorted(supercover(a,b)):
   if not m[cell]:
    bad.append(dict(segment=index,start=list(a),end=list(b),cell=list(cell)))
    # Strictly interior intersection distinguished from conservative vertex touch.
    if Fraction(cell[0]*2-1,2)<a[0]<Fraction(cell[0]*2+1,2):pass
 if not old_ok:skip('original_sampled_segments_not_certified');continue
 rows.append(dict(owner=e['owner'],step=e['step'],query_kind=q['query_kind'],route_segments=len(cells)-1,grid_route=cells,sampled_certificate=True,supercover_certificate=not bad,additional_nonwalkable_cells=bad,query_source_equals_pose_cell=tuple(world(memory,e['pose']))==cells[0],physical_safety_not_inferred=True))
summary=dict(retained_plan_returns=sum(e['kind']=='PLAN_RETURN'for e in events),eligible_unique_matched_exploration_plans=len(rows),plans_with_additional_nonwalkable_cells=sum(not r['supercover_certificate']for r in rows),additional_nonwalkable_segment_cell_events=sum(len(r['additional_nonwalkable_cells'])for r in rows),source_equals_pose_cells=sum(r['query_source_equals_pose_cell']for r in rows),oracle_pairs=len(pairs))
report=dict(status='COMPLETE_RECORDED_SMOOTHING_GRID_CONTRACT_REVIEW',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),checks=checks,summary=summary,excluded=excluded,rows=rows,input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),source_sha256={n:hashlib.sha256((B/n).read_bytes()).hexdigest()for n in ['fast_exploration.py','greedy_mapping.py']},SDK_frames=0,native_rounds=0,production_changed=False,limits=['Uses exact retained own planning masks, no physical wall truth or BLUE state.','Supercover includes corner-touch cells to match the inherited graph no-corner-cut constraint. A rejected cell does not prove a collision or lost score.','Only unique matched exploration queries included; runtime pose may depart from smoothed center-to-center segments.','A mathematical corner counterexample is not sufficient for controller integration; actual occurrence and execution impact must be checked.'])
out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],checks=checks,summary=summary,excluded=excluded)))
