from pathlib import Path
import ast,subprocess,json,time,datetime,hashlib
F=Path(__file__).resolve().parent;R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P114_grid_scope_coupling_diagnosis_20261102';ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60'];utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def remote(code):return subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=code.encode(),capture_output=True)
def keep(name,p):
 out=F/(name+'.capture.txt');assert not out.exists();out.write_bytes(p.stdout+p.stderr);print(p.stdout.decode(errors='replace')[-1000:],flush=True)
 if p.returncode:raise RuntimeError('Keep first prefix scope-trace error '+name)
def fetch(name):subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+name,str(F/name)],check=True)
def main():
 assert not(F/'STARTED_FIRST.json').exists();pre=json.loads((F/'PREDECLARATION_FIRST.json').read_text());assert sha(F/'check_same_failed_grid_prefix.py')==pre['source_sha256']
 parent=json.loads(Path(pre['baseline_trace_reused']['old_trace']).read_text());fresh=json.loads((F.parent/'P113_P112_actual_coverage_validation/CROSS_P48_ACTUAL_COVERAGE_FIRST.json').read_text());keys=[k for k in fresh['source_sha256']if any(n in k for n in ['coverage','terminal','fleet','survey','commitment','geometry_navigation'])];model_checks={k:parent['source_sha256'].get(k)==fresh['source_sha256'][k]for k in keys};assert all(model_checks.values())
 (F/'BASELINE_CORE_MODEL_BINDING_FIRST.json').write_text(json.dumps(dict(checks=model_checks,SDK_frames=0),indent=2)+'\n')
 guard=Path('E:/codex/UAV_rules_astar_restart_20261030/R154_scoped_serial_guard_20261101/check_scoped_serial.py').read_text();keep('SERIAL_FIRST',remote(guard));keep('MKDIR_FIRST',remote('from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n'))
 (F/'STARTED_FIRST.json').write_text(json.dumps(dict(utc=utc(),finite_hours=14,readonly=True,native_rounds=0),indent=2)+'\n')
 for name in ['check_same_failed_grid_prefix.py','WORKSPACE_READY.json','PREDECLARATION_FIRST.json']:
  subprocess.run(['scp','-q',str(F/name),'junhao@10.112.162.60:'+D+'/'],check=True)
 subprocess.run(['scp','-q','E:/codex/UAV_rules_astar_restart_20261030/run_sdk_captured.py','junhao@10.112.162.60:'+D+'/'],check=True)
 old=Path('E:/codex/PJ01_environment_restore_20261101/P35_continuation_after_parent_repair/run_offline.py').read_text();methods='\n'.join(ast.get_source_segment(old,n)for n in ast.parse(old).body if isinstance(n,ast.FunctionDef)and n.name in ['cpu_sample','resource']);capacity='from pathlib import Path\nimport os,time,shutil,json,datetime\nR=Path('+repr(R)+')\nD=json.loads((R/"solver_study/framework_screen_20261016/best87_independent_20261025/P37_phase_five_comparison_20261101/PREDECLARATION.json").read_text())\ndef utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()\n'+methods+'\nprint(json.dumps(resource()))\n'
 end=time.monotonic()+14*3600;consecutive=[];count=0
 while time.monotonic()<end:
  if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop')
  count+=1;p=remote(capacity);keep('CAPACITY_'+str(count)+'_FIRST',p);row=json.loads(p.stdout);consecutive=consecutive+[row]if row['clean']else[];(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='WAITING_ORIGINAL_CAPACITY',resource=row),indent=2)+'\n')
  if len(consecutive)>=2:break
  time.sleep(60)
 else:raise TimeoutError('Finite scope-trace wait expired')
 (F/'RESOURCE_TWO_SAMPLE_FIRST.json').write_text(json.dumps(consecutive,indent=2)+'\n');keep('BEFORE_TRACE_SERIAL_FIRST',remote(guard));label=pre['label'];(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='RUNNING_SAME_FAILED_PREFIX300_SCOPE_TRACE',native_rounds=0),indent=2)+'\n')
 keep(label,subprocess.run(ssh+[R+'/.venv/bin/python',D+'/run_sdk_captured.py',D+'/check_same_failed_grid_prefix.py',label,'P112',pre['case'],str(pre['horizon']),str(pre['wall_rate'])],capture_output=True));fetch(label+'.json')
 c=json.loads((F/(label+'.json')).read_text());pfile=Path(pre['failed_input']);assert sha(pfile)==pre['failed_input_sha256'];p=json.loads(pfile.read_text());n=pre['prefix_frames'];oldproj=[e for e in p['projection_events']if e['step']<=n];newproj=[{k:v for k,v in e.items()if k!='consumer'}for e in c['projection_events']]
 checks=dict(all300_rows_identical=c['rows']==p['rows'][:n],all_projection_values_identical=newproj==oldproj,source_identical=c['source_sha256']==p['source_sha256'],expected300=c['physics_steps']==n,gate_trace_present=bool(c['gate_events']),route_trace_present=bool(c['route_details']))
 report=dict(status='PASS_SAME_FAILED_PREFIX_SCOPE_IDENTITY'if all(checks.values())else'STOP_SCOPE_DIAGNOSIS_IDENTITY_MISMATCH',utc=utc(),identity_checks=checks,gate_records=len(c['gate_events']),route_records=len(c['route_details']),projection_records=len(c['projection_events']),SDK_frames_added=n,native_rounds=0,not_performance=True)
 (F/'RESULT_FIRST.json').write_text(json.dumps(report,indent=2)+'\n');(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status=report['status'],native_rounds=0),indent=2)+'\n');print(json.dumps(report),flush=True)
 if not all(checks.values()):raise RuntimeError('Readonly trace mismatch, preserve and do not interpret scope')
if __name__=='__main__':
 try:main()
 except Exception:
  import traceback
  (F/'FIRST_ERROR.json').write_text(json.dumps(dict(utc=utc(),traceback=traceback.format_exc(),no_retry=True),indent=2)+'\n');raise
