from pathlib import Path
import ast,json,hashlib,datetime,shutil
F=Path(__file__).resolve().parent;P=F.parent/'P113_P112_actual_coverage_validation';B=F.parent/'P82_P48_gate_trace';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert not(F/'PREDECLARATION_FIRST.json').exists()
fresh=json.loads((P/'CROSS_P48_ACTUAL_COVERAGE_FIRST.json').read_text());oldpath=B/'CROSS_TRACE_FIRST.json';old=json.loads(oldpath.read_text());assert old['rows']==fresh['rows']and old['map_results']==fresh['map_results']
out=dict(status='PASS_REUSE_EXISTING_BASELINE_GATE_TRACE_NO_NEW_FLIGHT',old_trace=str(oldpath),old_trace_sha256=sha(oldpath),fresh_baseline_sha256=sha(P/'CROSS_P48_ACTUAL_COVERAGE_FIRST.json'),rows_identical=True,raw_maps_identical=True,old_gate_records=len(old['gate_events']),old_route_records=len(old['route_details']),SDK_frames=0,native_rounds=0)
(F/'PARENT_TRACE_REUSE_FIRST.json').write_text(json.dumps(out,indent=2)+'\n')
s=(P/'check_sdk_actual_coverage.py').read_text();s=s.replace(s.splitlines()[0],'"""Read-only first300 prefix of failed P112; diagnose shared-model vs task-layout roles, never a score retry."""')
s=s.replace('TRACE_ENABLED=False','TRACE_ENABLED=True')
needle='projection_events=[]\n';assert s.count(needle)==1
extra='''projection_events=[]
consumer_stack=[]
from swarm_rescue.solutions.fleet_mission import FleetCoverageMixin
raw_fleet_build=FleetCoverageMixin._build_fleet_plan
def observe_layout_build(self,step):
 consumer_stack.append('layout_route_allocation')
 try:return raw_fleet_build(self,step)
 finally:consumer_stack.pop()
FleetCoverageMixin._build_fleet_plan=observe_layout_build
'''
s=s.replace(needle,extra).replace("projection_events.append(dict(owner=", "projection_events.append(dict(consumer=consumer_stack[-1]if consumer_stack else'other',owner=")
needle='class MyDroneEval(Original):\n';assert s.count(needle)==1
s=s.replace(needle,needle+''' def _estimate_coverage_opportunity(self,step):
  consumer_stack.append('opportunity_model')
  try:return super()._estimate_coverage_opportunity(step)
  finally:consumer_stack.pop()
''')
ast.parse(s);(F/'check_same_failed_grid_prefix.py').write_text(s);(F/'WORKSPACE_READY.json').write_bytes((P/'WORKSPACE_READY.json').read_bytes())
decl=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=sha(F/'check_same_failed_grid_prefix.py'),failed_input=str(P/'CROSS_P112_ACTUAL_COVERAGE_FIRST.json'),failed_input_sha256=sha(P/'CROSS_P112_ACTUAL_COVERAGE_FIRST.json'),failed_comparison_sha256=sha(P/'CROSS_COMPARISON_FIRST.json'),prefix_frames=300,label='SAME_FAILED_GRID_PREFIX300_FIRST',case='cross_sdk',wall_rate=.05,horizon=300,controller_changes=False,native_rounds=0,scope='All300rows,production source SHA and existing projection events (excluding new consumer annotation) must equal failed P112 prefix. Observe existing build/acquisition/route states only, no new planners/sensors/changed inputs.',baseline_trace_reused=out,question='Initial discovery stop timing and stage at first different target278, vs changed actual placement route after shared field correction. No final-map causal split is claimed from this short prefix.')
(F/'PREDECLARATION_FIRST.json').write_text(json.dumps(decl,indent=2)+'\n');print(json.dumps(dict(status='FROZEN_PREFIX_DIAGNOSIS_WITH_REUSED_BASELINE',baseline_rows=len(old['rows']),candidate_prefix=300)))
