from pathlib import Path
import json,hashlib,ast,datetime
F=Path(__file__).resolve().parent;A=F.parent/'P103_sensor_aligned_phase';B=F.parent/'P85_P48_observed_fragment_output'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not(F/'PREDECLARATION_FIRST.json').exists()
failure=json.loads((A/'URGENT_PHASE_FIRST_REVIEW.json').read_text());assert not failure['checks']['selected_map_nonregress']
s=(A/'check_sdk_phase_candidate.py').read_text();s=s.replace(s.splitlines()[0],'"""Read-only cause diagnosis of the failed P103 phase rule and retained P48; no new controller/ranking."""')
assert "TRACE_ENABLED=arm=='P48Trace'" in s;s=s.replace("TRACE_ENABLED=arm=='P48Trace'",'TRACE_ENABLED=True')
needle=' def submit_exploration_map(self,image):'
extra=''' def _submission_due(self,step):
  before=gate_snapshot(self,step)
  result=super()._submission_due(step)
  if result:
   submit_decisions.append(dict(before=before,after=gate_snapshot(self,step),quality=list(self._map_quality()),quality_records=dict(self.map_quality_records),reason='PREDICTED_BUDGET_EXHAUSTED'if before['remaining']<=0 else 'ALL_CERTIFICATES_NO_FRESH_BETTER_PEER'))
  return result
'''
assert s.count(needle)==1;s=s.replace(needle,extra+needle)
s=s.replace('plan_calls=[];local_calls=[];probe_history=[];', 'submit_decisions=[];plan_calls=[];local_calls=[];probe_history=[];')
s=s.replace('gate_events=gate_events,route_details=route_details,TRACE_ENABLED=TRACE_ENABLED,','submit_decisions=submit_decisions,gate_events=gate_events,route_details=route_details,TRACE_ENABLED=TRACE_ENABLED,')
ast.parse(s);(F/'check_sdk_readonly_phase.py').write_text(s)
meta=json.loads((A/'WORKSPACE_READY.json').read_text());parent=json.loads((F.parent/'P91_known_graph_tail_reference/WORKSPACE_READY.json').read_text())['versions']['P48Reference']
(F/'WORKSPACE_READY.json').write_text(json.dumps(dict(status='READONLY_ORIGINAL_WORKSPACES_NO_COPY_OR_EDITS',versions={'P48Parent':parent,'P103Failed':meta['versions']['P103']}),indent=2)+'\n')
cases=[]
for label,arm,p in [('P48_PARENT_TRACE_FIRST','P48Parent',B/'WIDE_RATE15_P85_FIRST.json'),('P103_FAILED_TRACE_FIRST','P103Failed',A/'URGENT_PHASE_FIRST.json')]:
 d=json.loads(p.read_text());cases.append(dict(label=label,arm=arm,case='wide_cross_sdk',horizon=900,wall_rate=.15,input=str(p),input_sha256=sha(p),expected_frames=d['physics_steps']))
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=sha(F/'check_sdk_readonly_phase.py'),workspace_manifest_sha256=sha(F/'WORKSPACE_READY.json'),cases=cases,production_changes=False,native_rounds=0,scope='Keep P103 failure; replay identical authored physics only for new passive gate/route/submission records. No seed/phase/gate changes or performance retry.',identity_gate='Every frame row, original submitted image SHA/map/owner/step, all5 raw map scores and frozen production source hashes must equal respective retained input. P85 enhanced submission is compared using original_image/original_map_score only, not its different output layer. Stop first mismatch.',questions=['When do same-prefix actions diverge?','Do readiness, commitment/fusion and planned route endpoints change before information gains?','How much score loss is missed wall credit versus false positives?','Does actual completion mean budget exhaustion or certificates?'])
(F/'PREDECLARATION_FIRST.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(status='FROZEN_READONLY_DIAGNOSIS',cases=[(c['arm'],c['expected_frames'])for c in cases])))
