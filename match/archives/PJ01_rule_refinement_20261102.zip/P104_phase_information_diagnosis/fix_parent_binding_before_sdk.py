from pathlib import Path
import json,hashlib,datetime,ast
F=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not(F/'STARTED_FIRST.json').exists()and not(F/'PREDECLARATION_V2_FIRST.json').exists()
old=json.loads((F/'WORKSPACE_READY.json').read_text());m=json.loads((F.parent/'P85_P48_observed_fragment_output/WORKSPACE_READY.json').read_text())['versions']['P85']
old['versions']['P48Parent']=m
(F/'WORKSPACE_READY_V2.json').write_text(json.dumps(old,indent=2)+'\n')
p=F/'check_sdk_readonly_phase.py';s=p.read_text().replace("F/'WORKSPACE_READY.json'","F/'WORKSPACE_READY_V2.json'");ast.parse(s);p.write_text(s)
pre=json.loads((F/'PREDECLARATION_FIRST.json').read_text());pre.update(source_sha256=sha(p),workspace_manifest_sha256=sha(F/'WORKSPACE_READY_V2.json'),pre_sdk_protocol_fix='Use exact retained P85 production sources, including its output-only layer, instead of P48 stripped entry. Compare original map channels as declared. No SDK run, candidate/source/threshold/seed changes. Initial manifest kept.',original_predecl_sha256=sha(F/'PREDECLARATION_FIRST.json'))
(F/'PREDECLARATION_V2_FIRST.json').write_text(json.dumps(pre,indent=2)+'\n')
p=F/'run_readonly_diagnosis.py';s=p.read_text().replace('PREDECLARATION_FIRST.json','PREDECLARATION_V2_FIRST.json').replace('WORKSPACE_READY.json','WORKSPACE_READY_V2.json');ast.parse(s);p.write_text(s)
(F/'PRE_SDK_BINDING_FIX_FIRST.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='PRE_SDK_METADATA_BINDING_CORRECTED',reason=pre['pre_sdk_protocol_fix'],native_rounds=0,SDK_frames=0),indent=2)+'\n')
print('Exact retained parent source binding corrected before first SDK call; original declaration preserved')
