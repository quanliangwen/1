from pathlib import Path
import ast,subprocess,json,time,datetime,hashlib
F=Path(__file__).resolve().parent;R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P104_phase_information_diagnosis_20261102';ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60'];utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def remote(code):return subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=code.encode(),capture_output=True)
def keep(name,p):
 dest=F/(name+'.capture.txt');assert not dest.exists();dest.write_bytes(p.stdout+p.stderr);print(p.stdout.decode(errors='replace')[-1000:],flush=True)
 if p.returncode:raise RuntimeError('Keep first readonly phase diagnostic error '+name)
def fetch(name):subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+name,str(F/name)],check=True)
def main():
 assert not(F/'STARTED_FIRST.json').exists();pre=json.loads((F/'PREDECLARATION_V2_FIRST.json').read_text());assert sha(F/'check_sdk_readonly_phase.py')==pre['source_sha256']and sha(F/'WORKSPACE_READY_V2.json')==pre['workspace_manifest_sha256']
 guard=Path('E:/codex/UAV_rules_astar_restart_20261030/R154_scoped_serial_guard_20261101/check_scoped_serial.py').read_text();keep('SERIAL_FIRST',remote(guard));keep('MKDIR_FIRST',remote('from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n'))
 (F/'STARTED_FIRST.json').write_text(json.dumps(dict(utc=utc(),finite_hours=14,native_rounds=0,readonly=True),indent=2)+'\n')
 for name in ['check_sdk_readonly_phase.py','WORKSPACE_READY_V2.json','PREDECLARATION_V2_FIRST.json']:
  subprocess.run(['scp','-q',str(F/name),'junhao@10.112.162.60:'+D+'/'],check=True)
 subprocess.run(['scp','-q','E:/codex/UAV_rules_astar_restart_20261030/run_sdk_captured.py','junhao@10.112.162.60:'+D+'/'],check=True)
 old=Path('E:/codex/PJ01_environment_restore_20261101/P35_continuation_after_parent_repair/run_offline.py').read_text();methods='\n'.join(ast.get_source_segment(old,n)for n in ast.parse(old).body if isinstance(n,ast.FunctionDef)and n.name in ['cpu_sample','resource'])
 capacity='from pathlib import Path\nimport os,time,shutil,json,datetime\nR=Path('+repr(R)+')\nD=json.loads((R/"solver_study/framework_screen_20261016/best87_independent_20261025/P37_phase_five_comparison_20261101/PREDECLARATION.json").read_text())\ndef utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()\n'+methods+'\nprint(json.dumps(resource()))\n'
 deadline=time.monotonic()+14*3600;consecutive=[];count=0
 while time.monotonic()<deadline:
  if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop')
  count+=1;p=remote(capacity);keep('CAPACITY_'+str(count)+'_FIRST',p);row=json.loads(p.stdout);consecutive=consecutive+[row]if row['clean']else[]
  (F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='WAITING_ORIGINAL_CAPACITY',resource=row),indent=2)+'\n')
  if len(consecutive)>=2:break
  time.sleep(60)
 else:raise TimeoutError('Finite diagnostic wait expired')
 (F/'RESOURCE_TWO_SAMPLE_FIRST.json').write_text(json.dumps(consecutive,indent=2)+'\n');reviews=[]
 for case in pre['cases']:
  if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop before next trace')
  label=case['label'];keep(label+'_SERIAL',remote(guard));(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='RUNNING_READONLY_PHASE_TRACE',current=label,native_rounds=0),indent=2)+'\n')
  keep(label,subprocess.run(ssh+[R+'/.venv/bin/python',D+'/run_sdk_captured.py',D+'/check_sdk_readonly_phase.py',label,case['arm'],case['case'],str(case['horizon']),str(case['wall_rate'])],capture_output=True));fetch(label+'.json')
  c=json.loads((F/(label+'.json')).read_text());pfile=Path(case['input']);assert sha(pfile)==case['input_sha256'];p=json.loads(pfile.read_text());keys=['owner','step','original_sha256','original_map_score','original_breakdown']
  checks=dict(all_frame_rows_identical=c['rows']==p['rows'],same_original_submission=[{k:e[k]for k in keys}for e in c['submission_records']]==[{k:e[k]for k in keys}for e in p['submission_records']],same_all5_raw_maps=c['map_results']==p['map_results'],same_source=c['source_sha256']==p['source_sha256'],expected_frames=c['physics_steps']==case['expected_frames'],actual_submit_reason=bool(c['submit_decisions']),actual_trace_records=bool(c['gate_events'])and bool(c['route_details']))
  review=dict(status='PASS_READONLY_IDENTITY_NOT_PERFORMANCE'if all(checks.values())else'STOP_DIAGNOSIS_INPUT_MISMATCH',checks=checks,arm=case['arm'],frames=c['physics_steps'],gate_events=len(c['gate_events']),route_details=len(c['route_details']),submission_reason=c['submit_decisions'],native_rounds=0)
  (F/(label+'_REVIEW.json')).write_text(json.dumps(review,indent=2)+'\n');reviews.append(review);print(json.dumps({k:v for k,v in review.items()if k!='submission_reason'}),flush=True)
  if not all(checks.values()):raise RuntimeError('Readonly phase diagnosis identity mismatch, no retry')
 (F/'RESULT_FIRST.json').write_text(json.dumps(dict(status='COMPLETE_TWO_READONLY_PHASE_TRACES',reviews=reviews,native_rounds=0),indent=2)+'\n');(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='COMPLETE_READONLY_PHASE_TRACES',native_rounds=0),indent=2)+'\n')
if __name__=='__main__':
 try:main()
 except Exception:
  import traceback
  (F/'FIRST_ERROR.json').write_text(json.dumps(dict(utc=utc(),traceback=traceback.format_exc(),no_retry=True),indent=2)+'\n');raise
