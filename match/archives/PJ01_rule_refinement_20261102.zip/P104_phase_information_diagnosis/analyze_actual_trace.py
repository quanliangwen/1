from pathlib import Path
from collections import Counter
import json,hashlib,datetime
F=Path(__file__).resolve().parent;dest=F/'ACTUAL_CAUSE_REVIEW_FIRST.json';assert not dest.exists()
result=json.loads((F/'RESULT_FIRST.json').read_text());assert result['status']=='COMPLETE_TWO_READONLY_PHASE_TRACES'
assert all(all(e['checks'].values())for e in result['reviews'])
def analyze(label):
 p=F/(label+'.json');d=json.loads(p.read_text());classes=Counter();releases=[];declines=[];fusion=[]
 for e in d['gate_events']:
  b,a,dec=e['before'],e['after'],e['acquisition']
  if not b['ready']and a['ready']:kind='NEW_READY'
  elif b['ready']:kind='ALREADY_READY'
  elif not dec:kind='NOT_FRESH_COORDINATOR'
  elif dec[-1]['decision']:kind='CONTINUE_ACQUISITION'
  elif a['seeking_fusion']:kind='DECLINE_ACQUISITION_SEEK_FUSION'
  else:kind='OTHER'
  classes[kind]+=1
  detail=dict(owner=b['owner'],step=b['step'],remaining=b['remaining'],known_cells=b['known_cells'],hit_cells=b['confirmed_hit_cells'],model=a['model'],fresh_peers=a['fresh_peers'],rally_distance=b['rally_distance'],acquisition=dec)
  if kind=='NEW_READY':releases.append(detail)
  if dec and not dec[-1]['decision']:declines.append(detail)
  if kind=='DECLINE_ACQUISITION_SEEK_FUSION':fusion.append(detail)
 routes=[]
 for owner in range(5):
  es=[r for r in d['route_details']if r['before']['owner']==owner]
  def first(pred):return next((r['before']['step']for r in es if pred(r)),None)
  routes.append(dict(owner=owner,first_ready_before_call=first(lambda r:r['before']['ready']),first_ready_after_call=first(lambda r:r['after']['ready']),first_fusion_after_call=first(lambda r:r['after']['fusion']),first_placement_target=first(lambda r:r['after']['placement_goal']is not None),first_empty_inventory=first(lambda r:r['before']['inventory']==0),early_ordinary_calls=[dict(step=e['step'],goal=e['goal'],remaining=e['remaining'])for e in d['plan_calls']if e['owner']==owner and e['early']and e['ordinary_scope']]))
 selected=d['submission_records'][0];dec=d['submit_decisions'];lastdec=next(e for e in dec if e['before']['owner']==selected['owner'])
 return dict(label=label,input_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),frames=d['physics_steps'],map=selected['original_map_score'],submit_owner=selected['owner'],submit_reason=lastdec['reason'],remaining_at_submission=lastdec['before']['remaining'],known_cells_at_submission=lastdec['after']['known_cells'],certificates=lastdec['after']['certificates'],gate_classes=dict(classes),ready_transitions=releases,declined_acquisition=declines,fusion_samples=fusion,actors=routes,known_at_steps={str(t):d['rows'][t-1]['known_fraction']for t in [36,100,200,300,400,500,533]if t<=len(d['rows'])})
out=dict(status='COMPLETE_SAME_FAILURE_GATE_ROUTE_SUBMISSION_DIAGNOSIS',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent=analyze('P48_PARENT_TRACE_FIRST'),failed_candidate=analyze('P103_FAILED_TRACE_FIRST'),native_rounds=0,controller_changes=0,limits=['Identity checks prove passive observer did not change these two authored runs, not a general timing overhead guarantee.','Readiness transition can arrive in a received fleet plan before next own plan call; first sampled ready is an upper bound.','Known-cell coverage and model map_gap are belief proxies, not actual wall pixel accuracy.','No counterfactual intervention isolates how much loss was trajectory versus shortened exploration/fusion; avoid causal overclaim.','Not tournament results or a score retry. P103 remains rejected.'])
dest.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:{a:v[a]for a in ['frames','map','submit_owner','submit_reason','remaining_at_submission','gate_classes','actors','ready_transitions']}for k,v in out.items()if k in ['parent','failed_candidate']}))
