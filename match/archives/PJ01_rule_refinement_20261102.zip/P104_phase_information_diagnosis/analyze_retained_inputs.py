from pathlib import Path
import json,hashlib,math,datetime
F=Path(__file__).resolve().parent;A=F.parent/'P103_sensor_aligned_phase'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
dest=F/'RETAINED_PHASE_COMPARISON_FIRST.json';assert not dest.exists()
pre=json.loads((A/'SDK_PREDECLARATION_FIRST.json').read_text());out=[]
for case in pre['cases']:
 pp=Path(case['parent']);cp=A/(case['label']+'.json');assert sha(pp)==case['parent_sha256'];p=json.loads(pp.read_text());c=json.loads(cp.read_text())
 ps=p['submission_records'][0];cs=c['submission_records'][0];pb=ps['original_breakdown'];cb=cs['original_breakdown']
 first=next((r['step']for r,s in zip(p['rows'],c['rows'])if r!=s),None)
 changed=[]
 if first:
  a,b=p['rows'][first-1],c['rows'][first-1]
  for owner in range(5):
   fields=[k for k in ['commands','positions','inventory','goals','known_fraction','main_state']if a[k][owner]!=b[k][owner]]
   if fields:changed.append(dict(owner=owner,fields=fields,parent_goal=a['goals'][owner],candidate_goal=b['goals'][owner],parent_known=a['known_fraction'][owner],candidate_known=b['known_fraction'][owner]))
 def actor_rows(d):
  result=[]
  for i in range(5):
   drops=[r['step']for j,r in enumerate(d['rows'])if r['inventory'][i]<(2 if j==0 else d['rows'][j-1]['inventory'][i])]
   distance=sum(math.dist(a['positions'][i],b['positions'][i])for a,b in zip(d['rows'],d['rows'][1:]))
   result.append(dict(owner=i,drops=drops,known_end=d['rows'][-1]['known_fraction'][i],travel=distance,raw_map_score=d['map_results'][i]['score']))
  return result
 same_step=min(len(c['rows']),len(p['rows']))
 out.append(dict(case=case['case'],rate=case['wall_rate'],parent_input_sha256=sha(pp),candidate_input_sha256=sha(cp),first_different_row=first,first_changed_actors=changed,parent_submission=dict(owner=ps['owner'],step=ps['step'],map=ps['original_map_score']),candidate_submission=dict(owner=cs['owner'],step=cs['step'],map=cs['original_map_score']),credit_delta_pp=100*(cb['credit']-pb['credit']),penalty_delta_pp=100*(cb['penalty']-pb['penalty']),map_delta_pp=cs['original_map_score']-ps['original_map_score'],represented_true_wall_pixel_delta=cb['wall_hits']-pb['wall_hits'],parent_actors=actor_rows(p),candidate_actors=actor_rows(c),same_step=same_step,parent_known_at_same_step=p['rows'][same_step-1]['known_fraction'],candidate_known_at_same_step=c['rows'][same_step-1]['known_fraction'],actual_10_both=p['rows'][-1]['inventory']==c['rows'][-1]['inventory']==[0]*5))
result=dict(status='COMPLETE_RETAINED_INPUT_COMPARISON_NO_NEW_FLIGHT',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cases=out,new_SDK_frames=0,native_rounds=0,limits=['Authored deterministic fixtures, not tournament scores. No change in time score when both <=1000 steps.','Map credit loss is output missing walls; cause may be trajectory, fusion, evidence or termination and is not localized by this decomposition alone.','Same-step known free fraction is not wall accuracy. Shorter travel/earlier submission is not automatically better.','First changed recorded row includes only its own action/state timing, not all hidden callback states.'])
dest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps([{k:e[k]for k in ['case','first_different_row','first_changed_actors','credit_delta_pp','penalty_delta_pp','represented_true_wall_pixel_delta','parent_submission','candidate_submission']}for e in out]))
