from pathlib import Path
import ast,json,hashlib,datetime
F=Path(__file__).resolve().parent;O=F.parent/'P103_sensor_aligned_phase';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert not(F/'SDK_PREDECLARATION_FIRST.json').exists()
assert json.loads((F/'MECHANISM_PREFLIGHT_FIRST.json').read_text())['status']=='PASS_NO_EXACT_HISTORICAL_SOURCE_MATCH'
s=(O/'check_sdk_phase_candidate.py').read_text();s=s.replace(s.splitlines()[0],'"""P110 one raw static vote-confidence rule on unchanged P35 phases; actual full noisy author mission, no native score."""')
needle="TRACE_ENABLED=arm=='P48Trace'";assert s.count(needle)==1
extra='''TRACE_ENABLED=False
from swarm_rescue.solutions.greedy_mapping import MapMemory
import swarm_rescue.solutions.greedy_mapping as greedy_module
vote_events=[];vote_context=[]
raw_vote=greedy_module.update_static_votes
raw_observe=MapMemory.observe
def audit_vote(old,clear,weak):
 result=raw_vote(old,clear,weak)
 parent=np.minimum(32,np.asarray(old).astype(np.int64)+np.asarray(clear)+np.asarray(weak)).astype(np.uint8)
 if np.any(parent!=result):
  owner,step=vote_context[-1]
  vote_events.append(dict(owner=owner,step=step,changed_cells=int(np.count_nonzero(parent!=result)),parent_promoted_stable=int(np.count_nonzero((np.asarray(old)<2)&(parent>=2)&(result<2))),existing_not_retracted=bool(np.all(result>=np.asarray(old))),weak_only_not_promoted=bool(np.all(result[np.asarray(clear)==0]<=np.maximum(1,np.asarray(old)[np.asarray(clear)==0]))),old=np.asarray(old).tolist(),clear=np.asarray(clear).tolist(),weak=np.asarray(weak).tolist(),candidate=result.tolist()))
 return result
def audit_observe(mem,*args,**kwargs):
 vote_context.append((int(mem.identifier),int(mem.step)))
 try:return raw_observe(mem,*args,**kwargs)
 finally:vote_context.pop()
greedy_module.update_static_votes=audit_vote
MapMemory.observe=audit_observe'''
s=s.replace(needle,extra).replace('gate_events=gate_events,route_details=route_details,TRACE_ENABLED=TRACE_ENABLED,','vote_events=vote_events,gate_events=gate_events,route_details=route_details,TRACE_ENABLED=TRACE_ENABLED,')
ast.parse(s);(F/'check_sdk_vote_confidence.py').write_text(s)
(F/'prepare_workspace.py').write_text((O/'prepare_workspace.py').read_text().replace('P103','P110'))
s=(O/'run_sdk_checks.py').read_text().replace('P103_sensor_aligned_phase','P110_P35_ambiguous_drone_votes').replace('PJ01_rules_P110_P35_ambiguous_drone_votes_20261102','PJ01_rules_P110_ambiguous_drone_votes_20261102').replace('PHASE_CONTRACTS_FIRST.json','ACTUAL_OBSERVE_CONTRACT_FIRST.json').replace('PASS_PHASE_TIMELINE_REGIMES','PASS_ACTUAL_OBSERVE_ARRAY_RULE_NOT_FLIGHT').replace('check_sdk_phase_candidate.py','check_sdk_vote_confidence.py').replace("label,'P103'","label,'P110'")
s=s.replace("    guard=Path(","    assert json.loads((F/'MECHANISM_PREFLIGHT_FIRST.json').read_text())['status']=='PASS_NO_EXACT_HISTORICAL_SOURCE_MATCH'\n    guard=Path(")
start=s.index("        early=[r for r in actual['plan_calls']");end=s.index("        (F/(label+'_REVIEW.json'))",start)
new='''        selected_map=None if selected is None else selected['original_map_score']
        time_value=10*max(0,min(1,(2000-actual['physics_steps'])/1000))
        votes=actual['vote_events']
        checks=dict(original_actual_checks=all(actual['checks'].values()),all10=actual['rows'][-1]['inventory']==[0]*5,actual_submission=selected is not None,selected_map_nonregress=selected_map is not None and selected_map>=case['parent_map'],health_nonregress=all(r['health'][i]>=case['parent_min_health'][i]for r in actual['rows']for i in range(5)),time_contribution_nonregress=time_value>=case['parent_time_contribution'],input_walltime_within_original_limit=case['wall_rate']*actual['physics_steps']<=90,actual_confidence_changes=bool(votes),weak_only_never_promoted=all(e['weak_only_not_promoted']for e in votes),no_existing_votes_retracted=all(e['existing_not_retracted']for e in votes))
        report=dict(status='PASS_STATIC_VOTE_CONFIDENCE_AUTHOR_CASE'if all(checks.values())else'STOP_KEEP_FIRST_CONFIDENCE_RULE_FAILURE',utc=utc(),case=case['case'],rate=case['wall_rate'],checks=checks,parent_steps=case['parent_steps'],candidate_steps=actual['physics_steps'],parent_map=case['parent_map'],candidate_map=selected_map,map_delta=None if selected_map is None else selected_map-case['parent_map'],actual_owner=None if selected is None else selected['owner'],actual_changed_observations=len(votes),changed_cells=sum(e['changed_cells']for e in votes),prevented_stable_promotions=sum(e['parent_promoted_stable']for e in votes),wall_seconds=actual['wall_seconds'],all_actor_map_diagnostics=actual['map_results'],native_rounds=0)
'''
s=s[:start]+new+s[end:];s=s.replace('One independent P48 early-phase change, staged actualSDK checks only; no automatic native/five','One semantic ambiguity vote confidence rule on unchanged P35/P48; no automatic native/five')
s=s.replace('RUNNING_FULL_FRAMEWORK_PHASE_CANDIDATE','RUNNING_FULL_MISSION_VOTE_CONFIDENCE_CHECK').replace('STOP_FIRST_PHASE_CASE_NO_RETRY','STOP_FIRST_VOTE_CONFIDENCE_CASE_NO_RETRY').replace('COMPLETE_PROMISING_PHASE_CANDIDATE_AUTHOR_CHECKS','COMPLETE_PROMISING_VOTE_CONFIDENCE_CHECKS').replace('COMPLETE_PHASE_CHECKS_NO_SUBSTANTIVE_GAIN','COMPLETE_VOTE_CONFIDENCE_CHECKS_NO_SUBSTANTIVE_GAIN')
ast.parse(s);(F/'run_sdk_checks.py').write_text(s)
cases=json.loads((O/'SDK_PREDECLARATION_FIRST.json').read_text())['cases']
for c in cases:c['label']=c['label'].replace('PHASE','VOTE_CONFIDENCE')
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=sha(F/'check_sdk_vote_confidence.py'),candidate_manifest_sha256=sha(F/'CANDIDATE_MANIFEST_FIRST.json'),local_contract_sha256=sha(F/'ACTUAL_OBSERVE_CONTRACT_FIRST.json'),mechanism_preflight_sha256=sha(F/'MECHANISM_PREFLIGHT_FIRST.json'),cases=cases,gates=['Both authored full mission cases: actual first raw map>=retained originalP48,10/10,health per actor nonregress, exact official time contribution nonregress, original real loop90 and declared inputwall<=90.', 'Actual vote rule changes must occur; record blocked stable promotions and prove no existing votes retracted/weak-only not promoted. Clear-only/no-DRONE equivalence already actual source-method checked.', 'First failed case stops chain, keep first error/score, no thresholds/labels/seeds rescue. Both pass and at least one actual map+.5 required before considering separate ZIP/ABI qualification and original-resource native pilot. No automatic five.'],not_stacked=['P67/P105 complete-chain events','P68/P106 path repair','P73/P74 recovery','P103 phases','P108 hard angular mask'],native_rounds=0,official_submission=False)
(F/'SDK_PREDECLARATION_FIRST.json').write_text(json.dumps(out,indent=2)+'\n');print('Full actualSDK two-case confidence-rule checks frozen; original P35 phase preserved')
