from pathlib import Path
from types import SimpleNamespace
import numpy as np
import ast,json,math,heapq,hashlib
F=Path(__file__).resolve().parent;C=F/'candidate_project';manifest=json.loads((F/'CANDIDATE_MANIFEST_FIRST.json').read_text());B=Path(manifest['parent']);dest=F/'ACTUAL_OBSERVE_CONTRACT_FIRST.json';assert not dest.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert all(sha(C/n)==h for n,h in manifest['candidate_files'].items())
helper={};exec((C/'src/swarm_rescue/solutions/semantic_static_evidence.py').read_text(),helper)
def memory(source):
 tree=ast.parse(source.read_text());node=next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name=='MapMemory');env=dict(np=np,math=math,heapq=heapq,**{k:helper[k]for k in ['ambiguous_drone_returns','update_static_votes']});exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),env);return env['MapMemory']
Old=memory(B/'src/swarm_rescue/solutions/greedy_mapping.py');New=memory(C/'src/swarm_rescue/solutions/greedy_mapping.py');cases=[]
def object(kind,angle,distance):return SimpleNamespace(entity_type=SimpleNamespace(name=kind),angle=angle,distance=distance)
def run(name,distances,angles,semantic,repeat,expected_identity,seed_old=None):
 old,new=Old(800,600),New(800,600)
 if seed_old is not None:old.hits[:]=seed_old;new.hits[:]=seed_old
 for _ in range(repeat):
  for m in [old,new]:m.observe(np.array([0.,0.]),0.,np.asarray(distances),np.asarray(angles),semantic)
 same=np.array_equal(old.hits,new.hits);checks=dict(free_same=np.array_equal(old.free,new.free),visits_same=np.array_equal(old.visits,new.visits),expected_hits_comparison=same==expected_identity,existing_evidence_not_erased=True if seed_old is None else bool((new.hits>=seed_old).all()))
 cases.append(dict(name=name,checks=checks,parent_max=int(old.hits.max()),candidate_max=int(new.hits.max())));assert all(checks.values());return old,new
run('no_semantics_identity',[100.],[.244],[],2,True)
run('no_DRONE_identity',[100.],[.244],[object('BOMB',1.,100.)],2,True)
run('wall_label_identity',[100.],[.244],[object('WALL',.3696,100.)],2,True)
run('old_excluded_DRONE_identity',[100.],[.244],[object('DRONE',.244,100.)],2,True)
run('outside_depth_band_identity',[100.],[.244],[object('DRONE',.3696,50.)],2,True)
run('outside_one_gap_identity',[100.],[-.3],[object('DRONE',.3696,100.)],2,True)
run('far_not_a_wall_hit_identity',[250.],[.244],[object('DRONE',.3696,250.)],2,True)
run('same_ambiguous_not_promoted',[103.92465],[.244346],[object('DRONE',.369599,86.17656)],2,False)
seed=np.zeros((300,400),np.uint8);seed[137,250]=8
run('preexisting_votes_never_cleared',[103.92465],[.244346],[object('DRONE',.369599,86.17656)],2,False,seed)
old,new=run('ambiguous_true_wall_deferred',[72.142954],[.244346],[object('DRONE',.369599,89.978439)],2,False)
new.observe(np.array([0.,0.]),0.,np.array([72.142954]),np.array([.244346]),[])
assert new.hits.max()==2;cases.append(dict(name='clear_reobservation_confirms_deferred_wall',checks=dict(actual_count2=True),candidate_max=2))
# Retained source public observations, no received packets or outputs replayed.
P=F.parent/'P107_blocking_evidence_provenance';data=json.loads((P/'SAME_FAILED_PROVENANCE64_FIRST.json').read_text());old,new=Old(800,600),New(800,600)
for r in data['raw_observations']:
 if r['owner']!=2:continue
 sem=[object(o['kind'],o['angle'],o['distance'])for o in r['semantic']]
 for m in [old,new]:m.observe(np.asarray(r['position']),r['heading'],np.asarray(r['distances']),np.asarray(r['angles']),sem)
assert int(old.hits.ravel()[68962])==2 and int(new.hits.ravel()[68962])==1 and np.array_equal(old.free,new.free)and np.array_equal(old.visits,new.visits)
cases.append(dict(name='actual_original_observe_source_point2_to_weak1',checks=dict(counts_correct=True,free_visits_same=True),parent_count=2,candidate_count=1))
out=dict(status='PASS_ACTUAL_OBSERVE_ARRAY_RULE_NOT_FLIGHT',cases=cases,source_sha256={str(p):sha(p)for p in [C/'src/swarm_rescue/solutions/greedy_mapping.py',C/'src/swarm_rescue/solutions/semantic_static_evidence.py']},SDK_frames=0,native_rounds=0,limitation='Exact original/candidate MapMemory bodies run on arrays; no SDK/physics/render/packet or complete mission guarantee. True wall ambiguity tradeoff kept explicit. No candidate promotion.')
dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status=out['status'],cases=len(cases))))
