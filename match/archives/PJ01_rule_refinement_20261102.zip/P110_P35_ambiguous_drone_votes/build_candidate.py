from pathlib import Path
import ast,json,hashlib,shutil,datetime
F=Path(__file__).resolve().parent;B=Path('E:/codex/PJ01_rule_refinement_20261101/P48_P35_refresh_deferral_candidate');P=B/'candidate_project';C=F/'candidate_project';assert not C.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();old=json.loads((B/'CANDIDATE_MANIFEST_FIRST.json').read_text());assert all(sha(P/n)==h for n,h in old['candidate_files'].items())
shutil.copytree(P,C,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git'));S=C/'src/swarm_rescue/solutions'
helper='''"""Weak static votes for coarse-DRONE-sector ambiguity, not a hard mask.

Same existing35-ray semantic configuration and24px depth association. Motion
still uses unmodified raw lidar. Known votes, free rays, maps and clocks are
never cleared. This is an engineering confidence rule, not a noise bound.
"""
import math
import numpy as np
def ambiguous_drone_returns(distances,angles,semantic):
    ambiguous=np.zeros(len(distances),bool)
    for obj in semantic or ():
        if getattr(getattr(obj,'entity_type',None),'name','')!='DRONE':continue
        delta=np.abs((angles-float(obj.angle)+math.pi)%(2*math.pi)-math.pi)
        ambiguous|=(delta>=.10)&(delta<2*math.pi/34)&(np.abs(distances-float(obj.distance))<24)
    return ambiguous
def update_static_votes(old,clear,weak):
    result=np.minimum(32,np.asarray(old).astype(np.int64)+np.asarray(clear).astype(np.int64))
    return np.maximum(result,(np.asarray(weak)>0).astype(np.int64)).astype(np.uint8)
'''
ast.parse(helper);(S/'semantic_static_evidence.py').write_text(helper)
p=S/'greedy_mapping.py';s=p.read_text();needle='from __future__ import annotations\n';assert s.count(needle)==1;s=s.replace(needle,needle+'\nfrom swarm_rescue.solutions.semantic_static_evidence import ambiguous_drone_returns, update_static_votes\n')
needle='        flat[indices] = np.minimum(32, flat[indices].astype(np.int16) + counts).astype(np.uint8)\n';assert s.count(needle)==1
replacement='''        ambiguous = ambiguous_drone_returns(d, a, semantic)[hit][valid]
        if not ambiguous.any():
            flat[indices] = np.minimum(32, flat[indices].astype(np.int16) + counts).astype(np.uint8)
        else:
            cell_ids = rows[valid] * self.hit_shape[1] + cols[valid]
            clear_ids, clear_counts = np.unique(cell_ids[~ambiguous], return_counts=True)
            trusted = np.zeros(len(indices), dtype=np.int64)
            trusted[np.searchsorted(indices, clear_ids)] = clear_counts
            flat[indices] = update_static_votes(flat[indices], trusted, counts - trusted)
'''
s=s.replace(needle,replacement);ast.parse(s);p.write_text(s)
files={p.relative_to(C).as_posix():sha(p)for p in C.rglob('*')if p.is_file()};diff=[n for n in sorted(files.keys()|old['candidate_files'].keys())if files.get(n)!=old['candidate_files'].get(n)];assert diff==['src/swarm_rescue/solutions/greedy_mapping.py','src/swarm_rescue/solutions/semantic_static_evidence.py']
out=dict(status='FROZEN_ONE_SEMANTIC_AMBIGUITY_CONFIDENCE_RULE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent=str(P),parent_files=old['candidate_files'],candidate_files=files,differences=diff,rule='Only raw static vote accumulation: rays outside originalDRONE .1 but within one35-ray semantic gap and original24px depth band are ambiguous. Alone they leave at most count1; ordinary clear votes follow original update. Never delete existing votes or change semantic_mask,free,layout,phase,clocks,motor,SDK.',source_evidence='P107 exact hit ledger: source2 own56/60 writes same2px cell,61gossips all4; original .1 mask missed both nearDRONE-sector rays. P108 broad hard mask has a true-wall occlusion counterexample, so do not hard delete.',not_stacked=['P105/P67 path events','P106/P68 path repair','P73/P74 localclearance recovery','P103 phase changes','P94 exchange','P96 filter'],tradeoff='A real wall observed only ambiguously can remain weak until a clear observation; performance and wall loss must be measured, not assumed zero.',SDK_change=False,req_unchanged=(C/'req.txt').read_bytes()==(P/'req.txt').read_bytes(),native_rounds=0,official_submission=False)
(F/'CANDIDATE_MANIFEST_FIRST.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status=out['status'],differences=diff)))
