"""Weak static votes for coarse-DRONE-sector ambiguity, not a hard mask.

Same existing35-ray semantic configuration and24px depth association. Motion
still uses unmodified raw lidar. Known votes, free rays, maps and clocks are
never cleared. This is an engineering confidence rule, not a noise bound.
"""
import math
import numpy as np
def ambiguous_drone_returns(distances,angles,semantic):
    ambiguous=np.zeros(len(distances),bool)
    for obj in semantic or ():
        if getattr(getattr(obj,'entity_type',None),'name','')!='DRONE':continue
        delta=np.abs((angles-float(obj.angle)+math.pi)%(2*math.pi)-math.pi)
        ambiguous|=(delta>=.10)&(delta<2*math.pi/34)&(np.abs(distances-float(obj.distance))<24)
    return ambiguous
def update_static_votes(old,clear,weak):
    result=np.minimum(32,np.asarray(old).astype(np.int64)+np.asarray(clear).astype(np.int64))
    return np.maximum(result,(np.asarray(weak)>0).astype(np.int64)).astype(np.uint8)
