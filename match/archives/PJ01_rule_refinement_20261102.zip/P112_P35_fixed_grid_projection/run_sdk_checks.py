from pathlib import Path
import ast,subprocess,json,time,datetime,hashlib
F=Path(__file__).resolve().parent;R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P112_fixed_grid_projection_sdk_20261102';ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60'];utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def remote(code):return subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=code.encode(),capture_output=True)
def keep(name,p):
    dest=F/(name+'.capture.txt');assert not dest.exists();dest.write_bytes(p.stdout+p.stderr);print(p.stdout.decode(errors='replace')[-1600:],flush=True)
    if p.returncode:raise RuntimeError('Keep first phase candidate error '+name)
def fetch(name):subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+name,str(F/name)],check=True)
def main():
    assert not(F/'STARTED_FIRST.json').exists();pre=json.loads((F/'SDK_PREDECLARATION_FIRST.json').read_text());assert sha(F/'check_sdk_grid_projection.py')==pre['source_sha256']and sha(F/'CANDIDATE_MANIFEST_FIRST.json')==pre['candidate_manifest_sha256']and sha(F/'COMPLETE_MODEL_CONTRACT_V2_FIXTURE_FIXED.json')==pre['local_contract_sha256']
    assert json.loads((F/'COMPLETE_MODEL_CONTRACT_V2_FIXTURE_FIXED.json').read_text())['status']=='PASS_ORIGINAL_COMPLETE_GEOMETRY_MODEL_PROJECTION_CONTRACT'
    assert json.loads((F/'MECHANISM_PREFLIGHT_FIRST.json').read_text())['status']=='PASS_NO_EXACT_HISTORICAL_SOURCE_MATCH'
    history=json.loads((F/'MECHANISM_PREFLIGHT_FIRST.json').read_text());decl=json.loads((F/'CANDIDATE_MANIFEST_FIRST.json').read_text());assert sha(F/'MECHANISM_PREFLIGHT_FIRST.json')==pre['mechanism_preflight_sha256']and hashlib.sha256(json.dumps(decl['candidate_files'],sort_keys=True,separators=(',',':')).encode()).hexdigest()==history['candidate_fingerprint']
    guard=Path('E:/codex/UAV_rules_astar_restart_20261030/R154_scoped_serial_guard_20261101/check_scoped_serial.py').read_text();keep('SERIAL_FIRST',remote(guard));keep('MKDIR_FIRST',remote('from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n'))
    (F/'STARTED_FIRST.json').write_text(json.dumps(dict(utc=utc(),finite_hours=14,scope='One fixed-world-grid projection rule on unchanged P35/P48; no automatic native/five'),indent=2)+'\n')
    for name in ['candidate_project','CANDIDATE_MANIFEST_FIRST.json','prepare_workspace.py','check_sdk_grid_projection.py','SDK_PREDECLARATION_FIRST.json']:
        subprocess.run(['scp','-q','-r',str(F/name),'junhao@10.112.162.60:'+D+'/'],check=True)
    subprocess.run(['scp','-q','E:/codex/UAV_rules_astar_restart_20261030/run_sdk_captured.py','junhao@10.112.162.60:'+D+'/'],check=True)
    keep('WORKSPACE_FIRST',subprocess.run(ssh+[R+'/.venv/bin/python',D+'/prepare_workspace.py'],capture_output=True));fetch('WORKSPACE_READY.json')
    src=Path('E:/codex/PJ01_environment_restore_20261101/P35_continuation_after_parent_repair/run_offline.py').read_text();methods='\n'.join(ast.get_source_segment(src,n)for n in ast.parse(src).body if isinstance(n,ast.FunctionDef)and n.name in ['cpu_sample','resource'])
    capacity='from pathlib import Path\nimport os,time,shutil,json,datetime\nR=Path('+repr(R)+')\nD=json.loads((R/"solver_study/framework_screen_20261016/best87_independent_20261025/P37_phase_five_comparison_20261101/PREDECLARATION.json").read_text())\ndef utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()\n'+methods+'\nprint(json.dumps(resource()))\n'
    deadline=time.monotonic()+14*3600;count=0;consecutive=[]
    while time.monotonic()<deadline:
        if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop')
        count+=1;p=remote(capacity);keep('CAPACITY_'+str(count)+'_FIRST',p);row=json.loads(p.stdout);consecutive=consecutive+[row]if row['clean']else[]
        (F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='WAITING_ORIGINAL_CAPACITY',resource=row),indent=2)+'\n')
        if len(consecutive)>=2:break
        time.sleep(60)
    else:raise TimeoutError('Finite phase candidate capacity wait expired')
    (F/'RESOURCE_TWO_SAMPLE_FIRST.json').write_text(json.dumps(consecutive,indent=2)+'\n');reviews=[]
    for case in pre['cases']:
        if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop before next case')
        label=case['label'];keep(label+'_SERIAL',remote(guard));(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='RUNNING_FULL_MISSION_FIXED_GRID_CHECK',current=label,native_rounds=0),indent=2)+'\n')
        keep(label,subprocess.run(ssh+[R+'/.venv/bin/python',D+'/run_sdk_captured.py',D+'/check_sdk_grid_projection.py',label,'P112',case['case'],str(case['horizon']),str(case['wall_rate'])],capture_output=True));fetch(label+'.json')
        actual=json.loads((F/(label+'.json')).read_text());parent=Path(case['parent']);assert sha(parent)==case['parent_sha256'];selected=actual['submission_records'][0]if actual['submission_records']else None
        selected_map=None if selected is None else selected['original_map_score']
        time_value=10*max(0,min(1,(2000-actual['physics_steps'])/1000))
        projections=actual['projection_events'];changed=[e for e in projections if e['changed_cells']>0]
        checks=dict(original_actual_checks=all(actual['checks'].values()),all10=actual['rows'][-1]['inventory']==[0]*5,actual_submission=selected is not None,selected_map_nonregress=selected_map is not None and selected_map>=case['parent_map'],health_nonregress=all(r['health'][i]>=case['parent_min_health'][i]for r in actual['rows']for i in range(5)),time_contribution_nonregress=time_value>=case['parent_time_contribution'],input_walltime_within_original_limit=case['wall_rate']*actual['physics_steps']<=90,actual_model_projection_changes=bool(changed),all_projections_finite_and_type_preserved=bool(projections)and all(e['finite']and e['dtype_unchanged']for e in projections))
        report=dict(status='PASS_FIXED_GRID_PROJECTION_AUTHOR_CASE'if all(checks.values())else'STOP_KEEP_FIRST_GRID_PROJECTION_FAILURE',utc=utc(),case=case['case'],rate=case['wall_rate'],checks=checks,parent_steps=case['parent_steps'],candidate_steps=actual['physics_steps'],parent_map=case['parent_map'],candidate_map=selected_map,map_delta=None if selected_map is None else selected_map-case['parent_map'],actual_owner=None if selected is None else selected['owner'],projection_calls=len(projections),changed_projection_calls=len(changed),changed_value_calls=sum(e['interpolation']=='AREA'for e in changed),changed_solid_calls=sum(e['interpolation']=='NEAREST'for e in changed),wall_seconds=actual['wall_seconds'],all_actor_map_diagnostics=actual['map_results'],native_rounds=0)
        (F/(label+'_REVIEW.json')).write_text(json.dumps(report,indent=2)+'\n');reviews.append(report);print(json.dumps({k:v for k,v in report.items()if k not in ['early_events','all_actor_map_diagnostics']}),flush=True)
        if not all(checks.values()):
            result=dict(status='STOP_FIRST_GRID_CASE_NO_RETRY',reviews=reviews,later_cases_skipped=True,native_rounds=0);break
    else:
        meaningful=any(r['map_delta']>=.5 for r in reviews)
        result=dict(status='COMPLETE_PROMISING_FIXED_GRID_CHECKS'if meaningful else'COMPLETE_FIXED_GRID_CHECKS_NO_SUBSTANTIVE_GAIN',reviews=reviews,substantive_gain=meaningful,native_rounds=0,automatic_native_or_five=False)
    (F/'RESULT_FIRST.json').write_text(json.dumps(result,indent=2)+'\n');(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status=result['status'],native_rounds=0),indent=2)+'\n')
if __name__=='__main__':
    try:main()
    except Exception:
        import traceback
        (F/'FIRST_ERROR.json').write_text(json.dumps(dict(utc=utc(),traceback=traceback.format_exc(),no_retry=True),indent=2)+'\n');raise
