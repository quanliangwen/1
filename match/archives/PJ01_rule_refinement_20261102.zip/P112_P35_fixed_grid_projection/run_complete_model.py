from pathlib import Path
import subprocess,json,shutil,hashlib,datetime
F=Path(__file__).resolve().parent;R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P112_fixed_grid_projection_20261102';ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60'];utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def remote(code):return subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=code.encode(),capture_output=True)
def keep(name,p):
 out=F/(name+'.capture.txt');assert not out.exists();out.write_bytes(p.stdout+p.stderr);print(p.stdout.decode(errors='replace')[-1000:],flush=True)
 if p.returncode:raise RuntimeError('Keep first complete-model reference failure '+name)
def main():
 assert not(F/'METHOD_STARTED_FIRST.json').exists();decl=json.loads((F/'CANDIDATE_MANIFEST_FIRST.json').read_text());history=json.loads((F/'MECHANISM_PREFLIGHT_FIRST.json').read_text());assert history['status']=='PASS_NO_EXACT_HISTORICAL_SOURCE_MATCH'
 assert hashlib.sha256(json.dumps(decl['candidate_files'],sort_keys=True,separators=(',',':')).encode()).hexdigest()==history['candidate_fingerprint']
 parent=F/'parent_reference';assert not parent.exists();shutil.copytree(Path(decl['parent']),parent,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git'))
 guard=Path('E:/codex/UAV_rules_astar_restart_20261030/R154_scoped_serial_guard_20261101/check_scoped_serial.py').read_text();keep('METHOD_SERIAL_FIRST',remote(guard));keep('METHOD_MKDIR_FIRST',remote('from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n'))
 (F/'METHOD_STARTED_FIRST.json').write_text(json.dumps(dict(utc=utc(),scope='Frozen full model and independent block oracles only, NumPy/OpenCV no SDK imports or flights',source_sha256=sha(F/'check_complete_model.py'),candidate_sha256=sha(F/'CANDIDATE_MANIFEST_FIRST.json'),native_rounds=0),indent=2)+'\n')
 for name in ['parent_reference','candidate_project','CANDIDATE_MANIFEST_FIRST.json','check_complete_model.py']:
  subprocess.run(['scp','-q','-r',str(F/name),'junhao@10.112.162.60:'+D+'/'],check=True)
 keep('COMPLETE_MODEL_FIRST',subprocess.run(ssh+[R+'/.venv/bin/python',D+'/check_complete_model.py'],capture_output=True));subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/COMPLETE_MODEL_CONTRACT_FIRST.json',str(F/'COMPLETE_MODEL_CONTRACT_FIRST.json')],check=True)
if __name__=='__main__':
 try:main()
 except Exception:
  import traceback
  (F/'COMPLETE_MODEL_FIRST_ERROR.json').write_text(json.dumps(dict(utc=utc(),traceback=traceback.format_exc()),indent=2)+'\n');raise
