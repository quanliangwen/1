from pathlib import Path
import ast,json,hashlib,shutil,datetime
F=Path(__file__).resolve().parent;B=Path('E:/codex/PJ01_rule_refinement_20261101/P48_P35_refresh_deferral_candidate');P=B/'candidate_project';C=F/'candidate_project';assert not C.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();old=json.loads((B/'CANDIDATE_MANIFEST_FIRST.json').read_text());assert all(sha(P/n)==h for n,h in old['candidate_files'].items())
shutil.copytree(P,C,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git'));p=C/'src/swarm_rescue/solutions/coverage_geometry.py';s=p.read_text()
helper='''def _project_wall_field(field,memory,interpolation):
    """Keep the existing fixed CELL world grid; do not stretch a partial cell.

    Preserve the old interpolation and exact no-op on an aligned canvas.
    Unsupported grid conventions retain the original projection.
    """
    destination=(memory.shape[1],memory.shape[0])
    ratio=float(memory.CELL)/float(memory.FINE)
    if not np.isfinite(ratio) or ratio<1 or not ratio.is_integer():
        return cv2.resize(field,destination,interpolation=interpolation)
    factor=int(ratio)
    expected=(int(np.ceil(memory.height/memory.FINE)),int(np.ceil(memory.width/memory.FINE)))
    canvas=(memory.shape[0]*factor,memory.shape[1]*factor)
    if field.shape!=expected or expected[0]>canvas[0] or expected[1]>canvas[1] or field.shape==canvas:
        return cv2.resize(field,destination,interpolation=interpolation)
    padded=np.zeros(canvas,dtype=field.dtype)
    padded[:field.shape[0],:field.shape[1]]=field
    return cv2.resize(padded,destination,interpolation=interpolation)


'''
needle='def geometry_wall_values(';assert s.count(needle)==1;s=s.replace(needle,helper+needle)
needle='    values=cv2.resize(values,(memory.shape[1],memory.shape[0]),interpolation=cv2.INTER_AREA)';assert s.count(needle)==1;s=s.replace(needle,'    values=_project_wall_field(values,memory,cv2.INTER_AREA)')
needle='        solids=cv2.resize(solids,(memory.shape[1],memory.shape[0]),interpolation=cv2.INTER_NEAREST)>0';assert s.count(needle)==1;s=s.replace(needle,'        solids=_project_wall_field(solids,memory,cv2.INTER_NEAREST)>0')
ast.parse(s);p.write_text(s);files={f.relative_to(C).as_posix():sha(f)for f in C.rglob('*')if f.is_file()};diff=[n for n in sorted(files.keys()|old['candidate_files'].keys())if files.get(n)!=old['candidate_files'].get(n)];assert diff==['src/swarm_rescue/solutions/coverage_geometry.py']
out=dict(status='FROZEN_ONE_FIXED_WORLD_GRID_PROJECTION_RULE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent=str(P),parent_files=old['candidate_files'],candidate_files=files,differences=diff,rule='Only coverage_geometry value/solid raster-to-coarse coordinate projection: pad missing lower/right nominal fine-grid cells with zero, retain original AREA/NEAREST semantics. Aligned full canvas executes original resize. No global resize replacement.',source_evidence='P111 numeric1250x800 model point moves from world375 to391 under originalresize; actual own measured-line component10drop model errors8 better/1worse after alignment, not game score.',not_stacked=['P110 ambiguous votes','P105/P67 events','P68 repair','P73/P74 clearance recovery','P103 phase','P77 output extension'],unchanged=['model line_width/contours/solid confidence/free/visits tests','parent P35 phase and clocks','sensing/render/rawhits/motor','SDK/requirements/limits/threads'],req_unchanged=(P/'req.txt').read_bytes()==(C/'req.txt').read_bytes(),SDK_change=False,native_rounds=0,official_submission=False)
(F/'CANDIDATE_MANIFEST_FIRST.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status=out['status'],differences=diff)))
