from pathlib import Path
import ast,json,hashlib,subprocess,datetime
F=Path(__file__).resolve().parent;R='/home/junhao/quan/parallel_test_solver/match';D=R+'/solver_study/framework_screen_20261016/best87_independent_20261025/PJ01_rules_P112_fixed_grid_projection_20261102';ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();dest=F/'FIXTURE_CORRECTION_FIRST.json';assert not dest.exists()
error=(F/'COMPLETE_MODEL_FIRST.capture.txt').read_text();assert "np.unravel_index(np.argmax(r),m.shape)==(12,62)"in error
source=F/'check_complete_model.py';s=source.read_text().replace("dest=F/'COMPLETE_MODEL_CONTRACT_FIRST.json'","dest=F/'COMPLETE_MODEL_CONTRACT_V2_FIXTURE_FIXED.json'")
old=" a=np.zeros((400,625),dtype);a[100,500]=1;b=a.copy();r=new['_project_wall_field'](a,m,cv2.INTER_AREA);assert np.unravel_index(np.argmax(r),m.shape)==(12,62)and np.array_equal(a,b)\n cases.append(dict(kind='point_world_association_'+str(np.dtype(dtype)),checks=dict(correct_cell=True,no_array_mutation=True)))"
new=""" a=np.zeros((400,625),dtype);a[100,500]=1;b=a.copy();r=new['_project_wall_field'](a,m,cv2.INTER_AREA)
 assert np.array_equal(a,b)
 if dtype==np.float32:
  assert np.unravel_index(np.argmax(r),m.shape)==(12,62)
  cases.append(dict(kind='float_value_point_world_association',checks=dict(correct_cell=True)))
 else:
  # A single uint8 value1 averaged over64 samples rounds to0. That is the
  # retained OpenCV dtype behavior, not a loss of a float wall value.
  assert not r.any()
  a2=np.zeros_like(a);a2[96,496]=1;b2=a2.copy();r=new['_project_wall_field'](a2,m,cv2.INTER_NEAREST)
  assert np.array_equal(a2,b2)
  assert np.unravel_index(np.argmax(r),m.shape)==(12,62)
  cases.append(dict(kind='uint8_area_rounding_and_actual_nearest_solid',checks=dict(area_rounds_zero_as_original=True,nearest_correct_cell=True)))
"""
assert s.count(old)==1;s=s.replace(old,new);ast.parse(s);p=F/'check_complete_model_v2_fixture.py';assert not p.exists();p.write_text(s)
record=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),reason='First35 complete-model cases passed; extra fixture falsely expected uint8 AREA to retain a single1/64. Production values use float32 AREA and solids use uint8 NEAREST. Correct fixture preserves integer AREA rounding0 and separately verifies actual NEAREST coordinate sample.',original_error_sha256=sha(F/'COMPLETE_MODEL_FIRST.capture.txt'),original_test_sha256=sha(source),corrected_test_sha256=sha(p),candidate_manifest_sha256=sha(F/'CANDIDATE_MANIFEST_FIRST.json'),candidate_source_unchanged=True,SDK_frames=0,native_rounds=0)
dest.write_text(json.dumps(record,indent=2)+'\n')
subprocess.run(['scp','-q',str(p),'junhao@10.112.162.60:'+D+'/'],check=True)
run=subprocess.run(ssh+[R+'/.venv/bin/python',D+'/'+p.name],capture_output=True);out=F/'COMPLETE_MODEL_V2_FIRST.capture.txt';assert not out.exists();out.write_bytes(run.stdout+run.stderr);print(run.stdout.decode(errors='replace'))
if run.returncode:raise RuntimeError('Keep corrected full-model fixture first error')
subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/COMPLETE_MODEL_CONTRACT_V2_FIXTURE_FIXED.json',str(F/'COMPLETE_MODEL_CONTRACT_V2_FIXTURE_FIXED.json')],check=True)
