"""Original full coverage function, with independent physical block oracles.

NumPy/OpenCV only, no SDK imports, fake free maps, GUI or simulator. Fixture
free/visits are explicit authored scenarios, not a historical state replay.
"""
from pathlib import Path
from types import SimpleNamespace
import ast,json,math,time,hashlib,datetime
import numpy as np
import cv2
F=Path(__file__).resolve().parent;dest=F/'COMPLETE_MODEL_CONTRACT_V2_FIXTURE_FIXED.json';assert not dest.exists();manifest=json.loads((F/'CANDIDATE_MANIFEST_FIRST.json').read_text());C=F/'candidate_project';B=F/'parent_reference';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert all(sha(C/n)==h for n,h in manifest['candidate_files'].items())and all(sha(B/n)==h for n,h in manifest['parent_files'].items())
def definitions(source):return[n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)]
line_source=(B/'src/swarm_rescue/solutions/line_regularization.py').read_text();env=dict(np=np,cv2=cv2,math=math);exec(compile(ast.Module(body=definitions(line_source),type_ignores=[]),'frozen_line_functions','exec'),env);regularized=env['regularized_walls']
class Recorder:
 def __init__(self,m):self.memory=m;self.calls=[]
 def __getattr__(self,n):return getattr(cv2,n)
 def resize(self,array,size,**kwargs):
  if tuple(size)==(self.memory.shape[1],self.memory.shape[0]):self.calls.append(dict(field=array.copy(),interpolation=kwargs['interpolation']))
  return cv2.resize(array,size,**kwargs)
def functions(source,m):
 proxy=Recorder(m);scope=dict(np=np,cv2=proxy,regularized_walls=regularized)
 exec(compile(ast.Module(body=definitions(source),type_ignores=[]),'bound_coverage_geometry','exec'),scope);return scope,proxy
oldtext=(B/'src/swarm_rescue/solutions/coverage_geometry.py').read_text();newtext=(C/'src/swarm_rescue/solutions/coverage_geometry.py').read_text();start=time.perf_counter();cases=[]
for width,height in [(640,480),(650,490),(1250,800),(801,601),(512,256)]:
 for kind in ['empty','thin_wall','closed_box','open_u','visited_closed_room','ray_free_open_u','edge_wall']:
  m=SimpleNamespace(width=width,height=height,CELL=16,FINE=2,shape=(math.ceil(height/16),math.ceil(width/16)),hits=np.zeros((math.ceil(height/2),math.ceil(width/2)),np.uint8));m.free=np.zeros(m.shape,bool);m.visits=np.zeros(m.shape,np.uint8)
  if kind=='thin_wall':cv2.line(m.hits,(int(.8*width/2),20),(int(.8*width/2),int(height/2)-20),8,1)
  elif kind=='edge_wall':cv2.line(m.hits,(int(width/2)-2,20),(int(width/2)-2,int(height/2)-20),8,1)
  elif kind in ['closed_box','visited_closed_room']:cv2.rectangle(m.hits,(40,40),(100,90),8,1)
  elif kind in ['open_u','ray_free_open_u']:
   cv2.line(m.hits,(40,90),(40,40),8,1);cv2.line(m.hits,(40,40),(100,40),8,1);cv2.line(m.hits,(100,40),(100,90),8,1)
  if kind=='visited_closed_room':m.visits[:]=1
  if kind=='ray_free_open_u':m.free[:]=True
  copies=m.hits.copy(),m.free.copy(),m.visits.copy();old,op=functions(oldtext,m);new,np_=functions(newtext,m);ov,os=old['geometry_wall_values'](m,80,return_solids=True);nv,ns=new['geometry_wall_values'](m,80,return_solids=True);assert len(op.calls)==len(np_.calls)==2
  rawv,raws=op.calls[0]['field'],op.calls[1]['field'];ratio=8;canvas=(m.shape[0]*ratio,m.shape[1]*ratio);padded=[]
  for a in [rawv,raws]:
   p=np.zeros(canvas,dtype=a.dtype);p[:a.shape[0],:a.shape[1]]=a;padded.append(p)
  oracle=np.zeros(m.shape,np.float32);oracle_s=np.zeros(m.shape,bool)
  for r in range(m.shape[0]):
   for c in range(m.shape[1]):
    block=rawv[r*ratio:(r+1)*ratio,c*ratio:(c+1)*ratio];oracle[r,c]=np.sum(block,dtype=np.float64)/(ratio*ratio)
    if r*ratio<raws.shape[0]and c*ratio<raws.shape[1]:oracle_s[r,c]=bool(raws[r*ratio,c*ratio])
  rr,cc=np.indices(m.shape);xx=(cc+.5)*16-width/2;yy=height/2-(rr+.5)*16;frame=(abs(xx)>width/2-16)|(abs(yy)>height/2-16);oracle[frame]*=.5
  check=dict(raw_geometry_field_identical=np.array_equal(np_.calls[0]['field'],padded[0]),raw_solids_identical=np.array_equal(np_.calls[1]['field'],padded[1]),independent_area_oracle=bool(np.allclose(nv,oracle,rtol=0,atol=2e-7)),independent_nearest_oracle=np.array_equal(ns,oracle_s),source_arrays_unchanged=all(np.array_equal(a,b)for a,b in zip(copies,[m.hits,m.free,m.visits])),shape_and_finite=nv.shape==m.shape and ns.shape==m.shape and bool(np.isfinite(nv).all()),aligned_full_canvas_exact_noop=(np.array_equal(ov,nv)and np.array_equal(os,ns))if width%16==0 and height%16==0 else True)
  if kind in ['empty','visited_closed_room','ray_free_open_u']:check['empty_or_contradicted_solid_not_filled']=not ns.any()
  if kind in ['closed_box','open_u']:check['supported_obstacle_still_recognized']=bool(ns.any())
  cases.append(dict(width=width,height=height,kind=kind,checks=check,old_value_sum=float(ov.sum()),new_value_sum=float(nv.sum()),old_solid_cells=int(os.sum()),new_solid_cells=int(ns.sum())))
  assert all(check.values()),(width,height,kind,check)
# Projection-only unsupported convention fallback, and dtype/zero extension.
m=SimpleNamespace(width=1250,height=800,CELL=16,FINE=2,shape=(50,79));new,proxy=functions(newtext,m)
for dtype in [np.float32,np.uint8]:
 a=np.zeros((400,625),dtype);a[100,500]=1;b=a.copy();r=new['_project_wall_field'](a,m,cv2.INTER_AREA)
 assert np.array_equal(a,b)
 if dtype==np.float32:
  assert np.unravel_index(np.argmax(r),m.shape)==(12,62)
  cases.append(dict(kind='float_value_point_world_association',checks=dict(correct_cell=True)))
 else:
  # A single uint8 value1 averaged over64 samples rounds to0. That is the
  # retained OpenCV dtype behavior, not a loss of a float wall value.
  assert not r.any()
  a2=np.zeros_like(a);a2[96,496]=1;b2=a2.copy();r=new['_project_wall_field'](a2,m,cv2.INTER_NEAREST)
  assert np.array_equal(a2,b2)
  assert np.unravel_index(np.argmax(r),m.shape)==(12,62)
  cases.append(dict(kind='uint8_area_rounding_and_actual_nearest_solid',checks=dict(area_rounds_zero_as_original=True,nearest_correct_cell=True)))

m.FINE=3;a=np.ones((267,417),np.float32);r=new['_project_wall_field'](a,m,cv2.INTER_AREA);assert np.array_equal(r,cv2.resize(a,(79,50),interpolation=cv2.INTER_AREA));cases.append(dict(kind='unsupported_ratio_original_fallback',checks=dict(exact_original=True)))
out=dict(status='PASS_ORIGINAL_COMPLETE_GEOMETRY_MODEL_PROJECTION_CONTRACT',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cases=cases,source_sha256=manifest['candidate_files']['src/swarm_rescue/solutions/coverage_geometry.py'],line_source_sha256=sha(B/'src/swarm_rescue/solutions/line_regularization.py'),elapsed_numeric_seconds=time.perf_counter()-start,SDK_imports=0,SDK_frames=0,native_rounds=0,limits=['Original full model runs on explicit authored arrays, not the incomplete P75 free/visits state.','Only grid projection changes; genuine solidity, physical safety and scores still depend on model quality and execution.','INTER_NEAREST stays upper-left fixed-grid sampling, not a new center/any occupancy interpretation.'])
dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status=out['status'],cases=len(cases),elapsed=out['elapsed_numeric_seconds'])))
