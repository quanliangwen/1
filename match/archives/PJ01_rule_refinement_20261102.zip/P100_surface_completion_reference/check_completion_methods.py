from pathlib import Path
import json
import numpy as np
from target_sections import target_sections
F=Path(__file__).resolve().parent;dest=F/'COMPLETION_METHODS_FIRST.json';assert not dest.exists()
probe=dict(wall=[0.,0.],observed_segment=[[-50.,0.],[50.,0.]])
blank=np.zeros((160,160),np.uint8);checks=[]
assert target_sections(blank,probe,160,160,16)['fraction']==0;checks.append('empty depiction never completes')
dot=blank.copy();dot[80,80]=1;assert target_sections(dot,probe,160,160,16)['fraction']<.7;checks.append('one isolated pixel cannot complete via overlapping sample boxes')
wall=blank.copy();wall[80,55:106]=1;r=target_sections(wall,probe,160,160,16);assert r['fraction']==1;checks.append('finite represented measured segment completes')
near=blank.copy();near[70,55:106]=1;assert target_sections(near,probe,160,160,16)['fraction']==1;checks.append('inherited16px normal uncertainty band retained')
outside=blank.copy();outside[55,55:106]=1;assert target_sections(outside,probe,160,160,16)['fraction']==0;checks.append('distant unrelated parallel wall cannot complete target')
short=dict(wall=[0,0],observed_segment=[[-10,0],[10,0]]);assert not target_sections(wall,short,160,160,16)['valid'];checks.append('unsupported short witness rejected')
assert not target_sections(np.ones((2,2)),probe,160,160,16)['valid'];checks.append('bad geometry safely incomplete')
before=wall.copy();target_sections(wall,probe,160,160,16);assert np.array_equal(before,wall);checks.append('depiction not modified')
rot=dict(wall=[0,0],observed_segment=[[0,-50],[0,50]]);v=blank.copy();v[55:106,80]=1;assert target_sections(v,rot,160,160,16)['fraction']==1;checks.append('rotated measured surface uses its own tangent')
dest.write_text(json.dumps(dict(status='PASS_FINITE_SURFACE_COMPLETION_METHODS',checks=checks,count=len(checks),physical_frames=0,native_rounds=0,limitation='Read-only depiction predicate only. Real near scans and phase/semantic/budget gates require separate actualSDK reference.'),indent=2)+'\n');print(json.dumps(dict(status='PASS_FINITE_SURFACE_COMPLETION_METHODS',count=len(checks))))
