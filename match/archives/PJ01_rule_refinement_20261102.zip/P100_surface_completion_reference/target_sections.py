"""Read-only depiction check on finite measured surface, no truth or painting."""
import numpy as np


def target_sections(image, probe, width, height, cell):
    image=np.asarray(image)
    rejected=dict(valid=False,represented_sections=[False]*7,fraction=0.)
    if image.shape!=(height,width)or width<=0 or height<=0 or cell<=0:
        return rejected
    try:
        ends=np.asarray(probe['observed_segment'],float)
        center=np.asarray(probe['wall'],float)
    except (KeyError,TypeError,ValueError):
        return rejected
    if ends.shape!=(2,2)or center.shape!=(2,)or not np.isfinite(ends).all()or not np.isfinite(center).all():
        return rejected
    tangent=ends[1]-ends[0];length=float(np.linalg.norm(tangent))
    if length<40.:
        return rejected
    tangent/=length;normal=np.array([-tangent[1],tangent[0]])
    # Along-surface samples do not share a square neighbourhood. A single
    # pixel cannot masquerade as a long represented wall by overlapping boxes.
    half=min(24.,length/2)
    along=np.linspace(-half,half,7)
    across=np.arange(-float(cell),float(cell)+.5,1.)
    represented=[]
    for distance in along:
        points=center+distance*tangent+across[:,None]*normal
        rows=np.floor(height/2-points[:,1]).astype(int)
        cols=np.floor(points[:,0]+width/2).astype(int)
        valid=(rows>=0)&(rows<height)&(cols>=0)&(cols<width)
        represented.append(bool(np.any(image[rows[valid],cols[valid]])))
    return dict(valid=True,represented_sections=represented,fraction=sum(represented)/7.,sample_span=2*half,normal_half_width=float(cell))
