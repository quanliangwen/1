"""Bounded measured-surface view proposal; reference, not a production policy.

Preserves original public220px wall incorporation. Far TLS is ambiguous and is
only a reason to look from nearer known-free cells, never a wall insertion.
"""
import math
import time
import numpy as np
from swarm_rescue.solutions.scan_geometry import extract_scan_lines


def propose_views(*, pose, heading, distances, angles, excluded, parent_image,
                  free, blocked, width, height, cell, world_to_cell,
                  cell_to_world, route_solver, remaining, step, limit,
                  deadline=None):
    deadline = time.perf_counter()+.05 if deadline is None else float(deadline)
    available = min(96., float(remaining)/2., .5*float(limit)-int(step)-24.)
    p = np.asarray(pose, float)
    d, a, bad = np.asarray(distances, float), np.asarray(angles, float), np.asarray(excluded, bool)
    raw_free, occupied = np.asarray(free, bool), np.asarray(blocked, bool)
    image = np.asarray(parent_image)
    if (p.shape != (2,) or not np.isfinite(p).all() or not math.isfinite(float(heading))
            or d.ndim != 1 or d.shape != a.shape or d.shape != bad.shape
            or raw_free.ndim != 2 or raw_free.shape != occupied.shape
            or image.shape != (height, width) or available < 48
            or cell <= 0 or time.perf_counter() >= deadline):
        return None
    walkable = raw_free & ~occupied
    start = tuple(world_to_cell(p))
    if (not (0 <= start[0] < walkable.shape[0] and 0 <= start[1] < walkable.shape[1])
            or not walkable[start]):
        return None  # Do not inherit the lower-level forced-start relaxation.
    c, s = math.cos(float(heading)), math.sin(float(heading))
    rotation = np.array([[c, s], [-s, c]])
    best = None
    segments = extract_scan_lines(d, a, bad)
    tested = 0
    for first, last, ids in segments:
        if time.perf_counter() >= deadline:
            break
        # Reuse old P07's six far returns; one slightly nearer return must not
        # veto the entire supported segment. No new near/far range constants.
        if np.count_nonzero((d[ids] >= 220.) & (d[ids] < 285.)) < 6:
            continue
        endpoints = np.array([first, last]) @ rotation + p
        vector = endpoints[1]-endpoints[0]
        length = float(np.linalg.norm(vector))
        if length < 40.:
            continue
        wall = endpoints.mean(axis=0)
        delta = wall-p
        distance = float(np.linalg.norm(delta))
        if not 220. <= distance < 280.:
            continue
        row, col = int(math.floor(height/2-wall[1])), int(math.floor(wall[0]+width/2))
        if not (0 <= row < height and 0 <= col < width):
            continue
        band = 2*cell
        if np.any(image[max(0,row-band):min(height,row+band+1),
                        max(0,col-band):min(width,col+band+1)]):
            continue
        base = wall-delta*(190./distance)
        tangent = vector/length
        offset = min(32., length/4.)
        for sign in (-1., 1.):
            wanted = [base, base+sign*offset*tangent]
            if time.perf_counter() >= deadline:
                break
            if any(not (-width/2 < z[0] < width/2 and -height/2 < z[1] < height/2) for z in wanted):
                continue
            targets = [tuple(world_to_cell(z)) for z in wanted]
            if targets[0] == start or targets[0] == targets[1]:
                continue
            if any(not (0 <= r < walkable.shape[0] and 0 <= k < walkable.shape[1] and walkable[r,k]) for r,k in targets):
                continue
            goals = [np.asarray(cell_to_world(z), float) for z in targets]
            if (float(np.linalg.norm(goals[1]-goals[0])) < 16.
                    or any(not 48. <= float(np.linalg.norm(z-wall)) < 218. for z in goals)):
                continue
            paths = []
            source = start
            for target in targets:
                path = route_solver(source, target, walkable, deadline)
                if path is None:
                    break
                paths.append(path)
                source = target
            if len(paths) != 2:
                continue
            points = [p]+[np.asarray(cell_to_world(z),float) for z in paths[0][1:]]
            points += [np.asarray(cell_to_world(z),float) for z in paths[1][1:]]
            travel = sum(float(np.linalg.norm(y-x)) for x,y in zip(points,points[1:]))
            needed = math.ceil(travel/2.)+24.
            if needed > available:
                continue
            tested += 1
            candidate = dict(goals=[z.tolist() for z in goals],
                paths=[[list(z)for z in path]for path in paths],
                wall=wall.tolist(), observed_segment=endpoints.tolist(),
                source_ray_indices=ids.tolist(), source_origin=p.tolist(),
                source_range=distance, path_length=travel, nominal_steps=needed,
                step=int(step), expiry=int(step)+int(math.floor(available)))
            if best is None or (travel,candidate['goals']) < (best['path_length'],best['goals']):
                best = candidate
    if best is not None:
        best.update(feasible_orders_tested=tested,
                    model='Bounded local engineering view choice, not global optimal planning')
    return best


def matched_near_returns(*, pose, heading, distances, angles, excluded, wall):
    """Original near range plus contiguous actual unexcluded surface returns."""
    p, d, a = np.asarray(pose,float), np.asarray(distances,float), np.asarray(angles,float)
    bad = np.asarray(excluded,bool)
    if p.shape != (2,) or d.ndim != 1 or d.shape != a.shape or d.shape != bad.shape:
        return np.zeros(d.shape,bool)
    theta = float(heading)+a
    ends = p+d[:,None]*np.column_stack((np.cos(theta),np.sin(theta)))
    good = np.isfinite(d)&(d>8.)&(d<220.)&~bad&(np.linalg.norm(ends-np.asarray(wall,float),axis=1)<=32.)
    if len(good)<3 or not np.any(good[:-2]&good[1:-1]&good[2:]):
        return np.zeros(d.shape,bool)
    return good
