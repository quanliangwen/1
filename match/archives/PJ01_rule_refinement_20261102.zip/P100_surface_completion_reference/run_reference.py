from pathlib import Path
import ast,subprocess,json,time,datetime,hashlib
F=Path(__file__).resolve().parent;R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P100_surface_completion_reference_20261102';ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60'];utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def remote(code):return subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=code.encode(),capture_output=True)
def keep(name,p):
    dest=F/(name+'.capture.txt');assert not dest.exists();dest.write_bytes(p.stdout+p.stderr);print(p.stdout.decode(errors='replace')[-1600:],flush=True)
    if p.returncode:raise RuntimeError('Keep first completion-reference error '+name)
def fetch(name):subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+name,str(F/name)],check=True)
def main():
    assert not(F/'STARTED_FIRST.json').exists();pre=json.loads((F/'PREDECLARATION_FIRST.json').read_text());assert all(sha(F/n)==h for n,h in pre['sources'].items())
    guard=Path('E:/codex/UAV_rules_astar_restart_20261030/R154_scoped_serial_guard_20261101/check_scoped_serial.py').read_text();keep('SERIAL_FIRST',remote(guard));keep('MKDIR_FIRST',remote('from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n'))
    (F/'STARTED_FIRST.json').write_text(json.dumps(dict(utc=utc(),finite_hours=14,scope=pre['purpose'],native_rounds=0),indent=2)+'\n')
    for name in ['check_sdk_completion_reference.py','approach_views_reference.py','own_map_snapshot.py','target_sections.py','check_completion_methods.py','PREDECLARATION_FIRST.json','WORKSPACE_READY.json']:
        subprocess.run(['scp','-q',str(F/name),'junhao@10.112.162.60:'+D+'/'],check=True)
    subprocess.run(['scp','-q','E:/codex/UAV_rules_astar_restart_20261030/run_sdk_captured.py','junhao@10.112.162.60:'+D+'/'],check=True)
    src=Path('E:/codex/PJ01_environment_restore_20261101/P35_continuation_after_parent_repair/run_offline.py').read_text();methods='\n'.join(ast.get_source_segment(src,n)for n in ast.parse(src).body if isinstance(n,ast.FunctionDef)and n.name in ['cpu_sample','resource'])
    capacity='from pathlib import Path\nimport os,time,shutil,json,datetime\nR=Path('+repr(R)+')\nD=json.loads((R/"solver_study/framework_screen_20261016/best87_independent_20261025/P37_phase_five_comparison_20261101/PREDECLARATION.json").read_text())\ndef utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()\n'+methods+'\nprint(json.dumps(resource()))\n'
    deadline=time.monotonic()+14*3600;count=0;consecutive=[]
    while time.monotonic()<deadline:
        if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop')
        count+=1;p=remote(capacity);keep('CAPACITY_'+str(count)+'_FIRST',p);row=json.loads(p.stdout);consecutive=consecutive+[row]if row['clean']else[]
        (F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='WAITING_ORIGINAL_CAPACITY',resource=row),indent=2)+'\n')
        if len(consecutive)>=2:break
        time.sleep(60)
    else:raise TimeoutError('Finite completion capacity window expired')
    (F/'RESOURCE_TWO_SAMPLE_FIRST.json').write_text(json.dumps(consecutive,indent=2)+'\n');keep('BEFORE_METHOD_SERIAL_FIRST',remote(guard))
    keep('COMPLETION_METHODS_FIRST',subprocess.run(ssh+[R+'/.venv/bin/python',D+'/run_sdk_captured.py',D+'/check_completion_methods.py','COMPLETION_METHODS_FIRST'],capture_output=True));fetch('COMPLETION_METHODS_FIRST.json')
    assert json.loads((F/'COMPLETION_METHODS_FIRST.json').read_text())['status']=='PASS_FINITE_SURFACE_COMPLETION_METHODS'
    reviews=[]
    for case in pre['cases']:
        if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop before next reference')
        label=case['label'];keep(label+'_SERIAL',remote(guard));(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='RUNNING_COMPLETION_REFERENCE',current=label,native_rounds=0),indent=2)+'\n')
        keep(label,subprocess.run(ssh+[R+'/.venv/bin/python',D+'/run_sdk_captured.py',D+'/check_sdk_completion_reference.py',label,case['case']],capture_output=True));fetch(label+'.json')
        actual=json.loads((F/(label+'.json')).read_text());checks=dict(actual['checks'])
        if case['case']=='wall':
            old=json.loads((F.parent/'P98_autonomous_surface_view_reference/WALL_AUTONOMOUS_FIRST.json').read_text());keys=['step','pose','goal','phase','inventory','health','command','semantic']
            checks['old72frame_motion_preserved']=[{k:r[k]for k in keys}for r in actual['rows'][:72]]==[{k:r[k]for k in keys}for r in old['rows']]
            checks['map_representation_confirmed']=bool(actual['completion_checks'])and actual['completion_checks'][-1]['fraction']>=.7
            checks['original_budget_not_extended']=actual['steps']<=old['proposal']['expiry'] and actual['proposal']==old['proposal']
        report=dict(status='PASS_COMPLETION_REFERENCE_CASE'if all(checks.values())else'STOP_KEEP_FIRST_COMPLETION_REFERENCE_FAILURE',case=case['case'],checks=checks,reason=actual['reason'],steps=actual['steps'],feature_hits=actual['feature_hits'],feature_pixels=actual['feature_render_pixels'],actual_views=actual['actual_views'],completion_checks=actual['completion_checks'],snapshot={k:v for k,v in actual['snapshot'].items()if k!='payload'},native_rounds=0)
        (F/(label+'_REVIEW.json')).write_text(json.dumps(report,indent=2)+'\n');reviews.append(report);print(json.dumps(report),flush=True)
        if not all(checks.values()):
            result=dict(status='STOP_FIRST_COMPLETION_REFERENCE_FAILURE',reviews=reviews,later_cases_skipped=True,native_rounds=0);break
    else:result=dict(status='COMPLETE_TWO_COMPLETION_REFERENCES',reviews=reviews,native_rounds=0,new_production_candidate=False)
    (F/'RESULT_FIRST.json').write_text(json.dumps(result,indent=2)+'\n');(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status=result['status'],native_rounds=0),indent=2)+'\n')
if __name__=='__main__':
    try:main()
    except Exception:
        import traceback
        (F/'FIRST_ERROR.json').write_text(json.dumps(dict(utc=utc(),traceback=traceback.format_exc(),no_retry=True),indent=2)+'\n');raise
