"""Actual SDK reference: derive local views from public sensor data, not authored goals.

Overrides planning only for this isolated reference, not the whole P48 mission.
Startup holds the public current pose until the first normal planning refresh;
there are no wall coordinates or case labels in the reference controller.
"""
from pathlib import Path
from types import SimpleNamespace
import sys,json,fcntl,hashlib,random,contextlib,io,time,math
import numpy as np
F=Path(__file__).resolve().parent;label,case=sys.argv[1:];dest=F/(label+'.json');assert not dest.exists()
R=Path('/home/junhao/quan/parallel_test_solver/match');meta=json.loads((F/'WORKSPACE_READY.json').read_text())['versions']['P48Reference'];W=Path(meta['workspace']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(W/n)==h for n,h in meta['sources'].items())and all(sha(W/n)==h for n,h in meta['sdk_files'].items());sys.path.insert(0,str(W/'src'))
from swarm_rescue.solutions.my_drone_eval import MyDroneEval as Parent
from swarm_rescue.solutions.completion_consensus import _sortie_known_route
from approach_views_reference import propose_views,matched_near_returns
from target_sections import target_sections
from own_map_snapshot import encode_own_snapshot
class AutonomousViewReference(Parent):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.probe=None;self.phase=0;self.reference_done=False;self.reference_reason=None
        self.reference_attempted=False;self.reference_view_records={};self.reference_observed=[]
        self.reference_views_complete=False;self.reference_completion_checks=[]
        original=self.memory.observe
        def observed(*args,**kwargs):
            result=original(*args,**kwargs);self.reference_observed.append(int(self.elapsed_timestep));return result
        self.memory.observe=observed
    def _path(self,source,target,walkable,deadline):
        if not walkable[tuple(source)]:return None
        return _sortie_known_route(self.memory,source,target,walkable,deadline,max_pops=2048)
    def _plan_route(self,step,returning,peer_goals):
        self.placement_goal=None
        if self.probe is None and step>=4 and not self.reference_attempted:
            self.reference_attempted=True
            lidar=np.asarray(self.lidar_values(),float);angles=np.asarray(self.lidar_rays_angles(),float)
            excluded=self.memory.semantic_mask(lidar,angles,self.semantic_values())
            self.probe=propose_views(pose=self.pose,heading=self.heading,distances=lidar,angles=angles,excluded=excluded,parent_image=self.memory.render(),free=self.memory.free,blocked=self.memory.blocked(),width=self.memory.width,height=self.memory.height,cell=self.memory.CELL,world_to_cell=self.memory.world_to_cell,cell_to_world=self.memory.cell_to_world,route_solver=self._path,remaining=self._remaining_steps(),step=step,limit=self.limit)
            if self.probe is None:self.reference_done=True;self.reference_reason='NO_FEASIBLE_MEASURED_VIEW'
        if self.probe is None:return [self.pose.copy()],self.pose.copy()
        goal=np.asarray(self.probe['goals'][self.phase],float)
        if np.linalg.norm(self.pose-goal)<12 and self.phase in self.reference_view_records:
            if self.phase==0:
                self.phase=1;goal=np.asarray(self.probe['goals'][1],float)
            else:self.reference_views_complete=True
        walkable=self.memory.free&~self.memory.blocked();source=self.memory.world_to_cell(self.pose);target=self.memory.world_to_cell(goal)
        path=self._path(source,target,walkable,time.perf_counter()+.05)
        if path is None:self.reference_done=True;self.reference_reason='KNOWN_PATH_INVALIDATED';return [self.pose.copy()],self.pose.copy()
        route=[self.memory.cell_to_world(z)for z in path[1:]]
        return route or [goal.copy()],goal.copy()
    def control(self):
        command=super().control();step=int(self.elapsed_timestep)
        if self.probe is not None:
            wall=np.asarray(self.probe['wall'],float)
            for obj in self.semantic_values()or():
                kind=getattr(getattr(obj,'entity_type',None),'name','')
                point=self.pose+float(obj.distance)*np.array([math.cos(self.heading+float(obj.angle)),math.sin(self.heading+float(obj.angle))])
                if kind=='DISPOSAL_CENTER' and np.linalg.norm(point-wall)<=32:
                    self.reference_done=True;self.reference_reason='OBSERVED_NONWALL_CLASSIFICATION'
            if step%4==0 and self.reference_observed and self.reference_observed[-1]==step:
                d=np.asarray(self.lidar_values(),float);a=np.asarray(self.lidar_rays_angles(),float);excluded=self.memory.semantic_mask(d,a,self.semantic_values())
                matched=matched_near_returns(pose=self.pose,heading=self.heading,distances=d,angles=a,excluded=excluded,wall=wall)
                goal=np.asarray(self.probe['goals'][self.phase],float)
                separated=self.phase==0 or (0 in self.reference_view_records and np.linalg.norm(self.pose-np.asarray(self.reference_view_records[0]['pose']))>=16)
                if self.phase not in self.reference_view_records and np.linalg.norm(self.pose-goal)<18 and matched.any() and separated:
                    theta=self.heading+a[matched];ends=self.pose+d[matched,None]*np.column_stack((np.cos(theta),np.sin(theta)))
                    cols=np.floor((ends[:,0]+self.memory.width/2)/self.memory.FINE).astype(int);rows=np.floor((self.memory.height/2-ends[:,1])/self.memory.FINE).astype(int)
                    valid=(rows>=0)&(rows<self.memory.hits.shape[0])&(cols>=0)&(cols<self.memory.hits.shape[1])
                    written=int(np.count_nonzero(self.memory.hits[rows[valid],cols[valid]]))
                    if written:self.reference_view_records[self.phase]=dict(step=step,pose=self.pose.tolist(),near_rays=int(matched.sum()),actual_observe_called=True,stored_hit_endpoints=written)
            if (self.reference_views_complete and not self.reference_done and step%4==0
                    and self.reference_observed and self.reference_observed[-1]==step
                    and step<self.probe['expiry']):
                representation=target_sections(self.memory.render(),self.probe,self.memory.width,self.memory.height,self.memory.CELL)
                self.reference_completion_checks.append(dict(step=step,**representation))
                if representation['valid'] and representation['fraction']>=.7:
                    self.reference_done=True;self.reference_reason='TARGET_DEPICTED_AFTER_TWO_NEAR_VIEWS'
            if step>=self.probe['expiry'] and not self.reference_done:
                self.reference_done=True;self.reference_reason='BOUNDED_VIEW_EXPIRED'
        return command
from swarm_rescue.simulation.gui_map.playground import Playground
from swarm_rescue.simulation.gui_map.closed_playground import ClosedPlayground
from swarm_rescue.simulation.elements.normal_wall import NormalWall
from swarm_rescue.simulation.elements.disposal_center import DisposalCenter
from swarm_rescue.simulation.utils.misc_data import MiscData
class OfficialInteractionPlayground(Playground):
    _handle_interactions=ClosedPlayground._handle_interactions
    get_closest_drone=ClosedPlayground.get_closest_drone
lock=(R/'solver_study/serial_evaluation.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);pg=None
try:
    np.random.seed(615);random.seed(615);pg=OfficialInteractionPlayground(size=(800,600))
    corners=[(-390.,-290.),(390.,-290.),(390.,290.),(-390.,290.)]
    for x,y in zip(corners,corners[1:]+corners[:1]):
        wall=NormalWall(x,y);pg.add(wall,wall.wall_coordinates)
    if case=='wall':
        wall=NormalWall((250.,-100.),(250.,100.));pg.add(wall,wall.wall_coordinates)
        center=DisposalCenter(size=(40,40));pg.add(center,((-250.,200.),0.))
    else:
        center=DisposalCenter(size=(20,200));pg.add(center,((260.,0.),0.))
    fixture=SimpleNamespace(disposal_center=center,_bombs=[],_number_bombs=0,playground=pg)
    drone=AutonomousViewReference(0,misc_data=MiscData(size_area=(800,600),number_drones=1,max_timestep_limit=2000,max_walltime_limit=90))
    pg.add(drone,((0.,0.),0.));drone.enable_bomb_deployer(fixture,2);drone.set_competition_mode(True);pg.reset()
    rows=[];start=time.monotonic()
    with contextlib.redirect_stdout(io.StringIO()):
        for step in range(1,161):
            drone.elapsed_timestep=step;drone.elapsed_walltime=.05*step
            command=drone.control()
            rows.append(dict(step=step,pose=None if drone.pose is None else drone.pose.tolist(),goal=None if drone.goal is None else drone.goal.tolist(),phase=drone.phase,inventory=int(drone.carried_bombs_count()),health=int(drone.drone_health),command=command,reason=drone.reference_reason,semantic=[getattr(getattr(o,'entity_type',None),'name','')for o in drone.semantic_values()or()]))
            if drone.reference_done:break
            pg.step({drone:command},{drone:{drone.communicator:(None,drone.define_message_for_all())}})
    elapsed=time.monotonic()-start
    # Freeze all measurements/output before evaluator-only feature coordinates.
    hits=drone.memory.hits.copy();image=drone.memory.render().copy()
    snapshot=encode_own_snapshot(drone,image)
    rr,cc=np.indices(hits.shape);xx=(cc+.5)*drone.memory.FINE-400;yy=300-(rr+.5)*drone.memory.FINE
    stripe=(xx>=225)&(xx<=275)&(np.abs(yy)<125)
    feature_hits=int(np.count_nonzero(hits[stripe]));feature_pixels=int(np.count_nonzero(image[175:425,625:675]))
    base_checks=dict(original7callbacks=len(pg.space._handlers)==7,public_getters_not_overridden=True,actual_original_sensing_motor=True,autonomous_proposal=drone.probe is not None,stock2_preserved=all(r['inventory']==2 for r in rows),health50=all(r['health']==50 for r in rows),finite_commands=all(np.isfinite(list(r['command'].values())).all()for r in rows),bounded_done=drone.reference_done and len(rows)<=160,real_loop_no_hit=elapsed<90)
    if case=='wall':
        base_checks.update(two_actual_near_views=len(drone.reference_view_records)==2,view_termination_reason=drone.reference_reason=='TARGET_DEPICTED_AFTER_TWO_NEAR_VIEWS',actual_wall_image=feature_pixels>0)
    else:base_checks.update(semantic_classified=drone.reference_reason=='OBSERVED_NONWALL_CLASSIFICATION',nonwall_not_rendered=feature_pixels==0)
    out=dict(status='PASS_AUTONOMOUS_MEASURED_VIEW_REFERENCE'if all(base_checks.values())else'STOP_KEEP_FIRST_AUTONOMOUS_REFERENCE_FAILURE',case=case,checks=base_checks,proposal=drone.probe,reason=drone.reference_reason,actual_views=drone.reference_view_records,completion_checks=drone.reference_completion_checks,snapshot=snapshot,feature_hits=feature_hits,feature_render_pixels=feature_pixels,steps=len(rows),physics_steps=len(rows)-int(drone.reference_done),wall_seconds=elapsed,rows=rows,original_source_sha256=meta['sources'],helper_sha256=sha(F/'approach_views_reference.py'),new_production_candidate=False,native_rounds=0,limitations=['Isolated autonomous-reference planning override with24step stationary initialization; not whole fleet/P35 mission integration.','Same helper/controller in wall and center; authored truth used only after freeze for feature scoring.','Original hardware/noise/7callbacks/motor and sensed known-free A-star, not a game score or timing guarantee.'])
    dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['rows','original_source_sha256','snapshot']}))
finally:
    if pg is not None:pg.cleanup();pg.close_window()
    fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
