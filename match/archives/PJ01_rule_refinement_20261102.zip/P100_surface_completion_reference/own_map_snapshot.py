"""Post-submit own-public-belief snapshot, never consulted by control policy."""
import base64
import hashlib
import json
import time
import zlib
import numpy as np


def _json_value(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(type(value).__name__)


def _sparse(array):
    a = np.asarray(array)
    ids = np.flatnonzero(a.ravel())
    return dict(shape=list(a.shape), dtype=str(a.dtype), ids=ids.tolist(), values=a.ravel()[ids].tolist())


def encode_own_snapshot(drone, image):
    started = time.perf_counter()
    memory = drone.memory
    a = np.asarray(image)
    nonwall = getattr(memory, 'nonwall_mask', None)
    payload = dict(schema='own-public-map-v1', owner=int(drone.identifier or 0),
        step=int(drone.elapsed_timestep), width=int(memory.width), height=int(memory.height),
        CELL=int(memory.CELL), FINE=int(memory.FINE), inventory=int(drone.carried_bombs_count()),
        image_sha256=hashlib.sha256(a.tobytes()).hexdigest(), image_shape=list(a.shape), image_dtype=str(a.dtype),
        hits=_sparse(memory.hits), bearing_bits=_sparse(memory.bearing_bits),
        nonwall_mask=None if nonwall is None else _sparse(nonwall),
        frame_records=list(getattr(memory, 'frame_records', {}).values()),
        frame_negative=[[list(key), entries] for key, entries in getattr(memory, 'frame_negative', {}).items()],
        source_frames=int(memory.bearing_source_frames), merged_packets=int(memory.bearing_merged_packets),
        peer_message_steps=[[int(peer), int(stamp)] for peer,stamp in drone.last_peer_step.items()])
    raw = json.dumps(payload, separators=(',', ':'), default=_json_value, allow_nan=False).encode('utf-8')
    if len(raw) > 32*1024*1024:
        raise ValueError('own-public snapshot exceeds fixed32MiB diagnostic limit')
    compressed = zlib.compress(raw, level=1)
    return dict(schema='own-public-map-v1', owner=payload['owner'], step=payload['step'],
        image_sha256=payload['image_sha256'], snapshot_sha256=hashlib.sha256(raw).hexdigest(),
        raw_bytes=len(raw), compressed_bytes=len(compressed), encode_seconds=time.perf_counter()-started,
        payload=base64.b64encode(compressed).decode('ascii'))


class OwnMapSnapshotMixin:
    def submit_exploration_map(self, image):
        result = super().submit_exploration_map(image)
        # The submitted image was already passed unchanged to the SDK setter.
        if float(self.elapsed_walltime)+1. > float(self.walltime_limit):
            print('[OWN_MAP_SNAPSHOT_ERROR] insufficient post-submit diagnostic walltime', flush=True)
            return result
        try:
            packet = encode_own_snapshot(self, image)
            self._last_own_map_snapshot_packet = packet
            print('[OWN_MAP_SNAPSHOT] '+json.dumps(packet, separators=(',', ':')), flush=True)
        except Exception as error:
            # Observer failure cannot alter the algorithm; the analysis gate fails.
            print('[OWN_MAP_SNAPSHOT_ERROR] '+type(error).__name__+': '+str(error), flush=True)
        return result
