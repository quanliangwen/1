from pathlib import Path
import ast,json,hashlib,shutil,datetime
F=Path(__file__).resolve().parent;P=F.parent/'P98_autonomous_surface_view_reference';dest=F/'check_sdk_completion_reference.py';assert not dest.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
diag=json.loads((F.parent/'P99_bounded_observation_completion_diagnosis/DIAGNOSIS_REVIEW_FIRST.json').read_text());assert all(diag['checks'].values())and diag['first_representation70_percent']==76
s=(P/'check_sdk_autonomous_views.py').read_text();s=s.replace('from approach_views_reference import propose_views,matched_near_returns','from approach_views_reference import propose_views,matched_near_returns\nfrom target_sections import target_sections\nfrom own_map_snapshot import encode_own_snapshot')
needle='        self.reference_attempted=False;self.reference_view_records={};self.reference_observed=[]';assert s.count(needle)==1;s=s.replace(needle,needle+'\n        self.reference_views_complete=False;self.reference_completion_checks=[]')
needle="            else:self.reference_done=True;self.reference_reason='TWO_SPATIALLY_SEPARATED_NEAR_VIEWS'";assert s.count(needle)==1;s=s.replace(needle,'            else:self.reference_views_complete=True')
needle='            if step>=self.probe[\'expiry\'] and not self.reference_done:';assert s.count(needle)==1
extra='''            if (self.reference_views_complete and not self.reference_done and step%4==0
                    and self.reference_observed and self.reference_observed[-1]==step
                    and step<self.probe['expiry']):
                representation=target_sections(self.memory.render(),self.probe,self.memory.width,self.memory.height,self.memory.CELL)
                self.reference_completion_checks.append(dict(step=step,**representation))
                if representation['valid'] and representation['fraction']>=.7:
                    self.reference_done=True;self.reference_reason='TARGET_DEPICTED_AFTER_TWO_NEAR_VIEWS'
'''
s=s.replace(needle,extra+needle)
s=s.replace("drone.reference_reason=='TWO_SPATIALLY_SEPARATED_NEAR_VIEWS'","drone.reference_reason=='TARGET_DEPICTED_AFTER_TWO_NEAR_VIEWS'")
needle='hits=drone.memory.hits.copy();image=drone.memory.render().copy()';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    snapshot=encode_own_snapshot(drone,image)')
needle='actual_views=drone.reference_view_records,';assert s.count(needle)==1;s=s.replace(needle,needle+'completion_checks=drone.reference_completion_checks,snapshot=snapshot,')
s=s.replace("if k not in ['rows','original_source_sha256']","if k not in ['rows','original_source_sha256','snapshot']")
ast.parse(s);dest.write_text(s)
shutil.copyfile(P/'approach_views_reference.py',F/'approach_views_reference.py');shutil.copyfile(P/'WORKSPACE_READY.json',F/'WORKSPACE_READY.json');shutil.copyfile(F.parent/'P75_P48_map_layer_diagnosis/own_map_snapshot.py',F/'own_map_snapshot.py')
for name in ['target_sections.py','check_completion_methods.py','run_reference.py']:ast.parse((F/name).read_text())
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources={n:sha(F/n)for n in ['check_sdk_completion_reference.py','approach_views_reference.py','own_map_snapshot.py','target_sections.py','check_completion_methods.py','run_reference.py']},prior_diagnosis_sha256=sha(F.parent/'P99_bounded_observation_completion_diagnosis/DIAGNOSIS_REVIEW_FIRST.json'),cases=[dict(label='CENTER_COMPLETION_FIRST',case='center'),dict(label='WALL_COMPLETION_FIRST',case='wall')],purpose='Only isolated reference completion changes: two real near views insufficient until original parent renderer depicts finite target across>=70% non-overlapping normal sections; semantic stop/old expiry preserved. P98 original failure immutable.',gates=['9method counterexamples first, including isolated-pixel false-completion protection.','CENTER first: autonomous measured proposal, actual semantic nonwall termination, zero feature rendered, stock2/health50/original7callbacks/finite/real-loop90.','WALL: original first72 recorded poses/commands/goals/stock/health identical to P98 excluding changed completion reason; two real near views, finite target support>=.7, original feature image>0; same old expiry120 not extended.','No controller case input/hardcoded targets; same explicit reference startup hold24, not production behavior. New snapshot after output freeze only.','Any failure stops chain, no threshold/seed/label rerun; no automatic native/five/production integration.'],native_rounds=0,new_production_candidate=False)
(F/'PREDECLARATION_FIRST.json').write_text(json.dumps(out,indent=2)+'\n');print('P100 completion reference frozen; old P98/P99 and96step budget unchanged')
