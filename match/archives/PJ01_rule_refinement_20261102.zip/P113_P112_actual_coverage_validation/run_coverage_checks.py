from pathlib import Path
import ast,subprocess,json,time,datetime,hashlib
F=Path(__file__).resolve().parent;P=F.parent/'P112_P35_fixed_grid_projection';R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P113_P112_actual_coverage_validation_20261102';ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60'];utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def remote(code):return subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=code.encode(),capture_output=True)
def keep(name,p):
 target=F/(name+'.capture.txt');assert not target.exists();target.write_bytes(p.stdout+p.stderr);print(p.stdout.decode(errors='replace')[-1100:],flush=True)
 if p.returncode:raise RuntimeError('Preserve first actual-coverage SDK error '+name)
def fetch(name):subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+name,str(F/name)],check=True)
def main():
 assert not(F/'STARTED_FIRST.json').exists();pre=json.loads((F/'PREDECLARATION_FIRST.json').read_text());assert sha(F/'check_sdk_actual_coverage.py')==pre['source_sha256']and sha(F/'WORKSPACE_READY.json')==pre['workspace_sha256']
 for name,key in [('CANDIDATE_MANIFEST_FIRST.json','candidate_manifest_sha256'),('COMPLETE_MODEL_CONTRACT_V2_FIXTURE_FIXED.json','model_contract_sha256'),('MECHANISM_PREFLIGHT_FIRST.json','mechanism_preflight_sha256'),('PRE_SDK_PROTOCOL_CANCEL_FIRST.json','cancel_receipt_sha256')]:assert sha(P/name)==pre[key]
 assert json.loads((P/'COMPLETE_MODEL_CONTRACT_V2_FIXTURE_FIXED.json').read_text())['status']=='PASS_ORIGINAL_COMPLETE_GEOMETRY_MODEL_PROJECTION_CONTRACT'
 history=json.loads((P/'MECHANISM_PREFLIGHT_FIRST.json').read_text());decl=json.loads((P/'CANDIDATE_MANIFEST_FIRST.json').read_text());assert history['status']=='PASS_NO_EXACT_HISTORICAL_SOURCE_MATCH'and hashlib.sha256(json.dumps(decl['candidate_files'],sort_keys=True,separators=(',',':')).encode()).hexdigest()==history['candidate_fingerprint']
 guard=Path('E:/codex/UAV_rules_astar_restart_20261030/R154_scoped_serial_guard_20261101/check_scoped_serial.py').read_text();keep('SERIAL_FIRST',remote(guard));keep('MKDIR_FIRST',remote('from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n'))
 (F/'STARTED_FIRST.json').write_text(json.dumps(dict(utc=utc(),finite_hours=14,native_rounds=0,maximum_author_missions=4),indent=2)+'\n')
 for name in ['check_sdk_actual_coverage.py','WORKSPACE_READY.json','PREDECLARATION_FIRST.json']:
  subprocess.run(['scp','-q',str(F/name),'junhao@10.112.162.60:'+D+'/'],check=True)
 subprocess.run(['scp','-q','E:/codex/UAV_rules_astar_restart_20261030/run_sdk_captured.py','junhao@10.112.162.60:'+D+'/'],check=True)
 original=Path('E:/codex/PJ01_environment_restore_20261101/P35_continuation_after_parent_repair/run_offline.py').read_text();methods='\n'.join(ast.get_source_segment(original,n)for n in ast.parse(original).body if isinstance(n,ast.FunctionDef)and n.name in ['cpu_sample','resource']);capacity='from pathlib import Path\nimport os,time,shutil,json,datetime\nR=Path('+repr(R)+')\nD=json.loads((R/"solver_study/framework_screen_20261016/best87_independent_20261025/P37_phase_five_comparison_20261101/PREDECLARATION.json").read_text())\ndef utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()\n'+methods+'\nprint(json.dumps(resource()))\n'
 deadline=time.monotonic()+14*3600;consecutive=[];count=0
 while time.monotonic()<deadline:
  if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop')
  count+=1;p=remote(capacity);keep('CAPACITY_'+str(count)+'_FIRST',p);row=json.loads(p.stdout);consecutive=consecutive+[row]if row['clean']else[];(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='WAITING_ORIGINAL_CAPACITY',resource=row),indent=2)+'\n')
  if len(consecutive)>=2:break
  time.sleep(60)
 else:raise TimeoutError('Finite actual-coverage resource wait expired')
 (F/'RESOURCE_TWO_SAMPLE_FIRST.json').write_text(json.dumps(consecutive,indent=2)+'\n');reviews=[];stop=False
 for case in pre['cases']:
  outputs={}
  for arm,labelkey in [('P48Reference','parent_label'),('P112','candidate_label')]:
   if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop before mission')
   label=case[labelkey];keep(label+'_SERIAL',remote(guard));(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='RUNNING_ACTUAL_COVERAGE_AUTHOR_MISSION',current=label,native_rounds=0),indent=2)+'\n')
   keep(label,subprocess.run(ssh+[R+'/.venv/bin/python',D+'/run_sdk_captured.py',D+'/check_sdk_actual_coverage.py',label,arm,case['case'],str(case['horizon']),str(case['wall_rate'])],capture_output=True));fetch(label+'.json');data=json.loads((F/(label+'.json')).read_text());outputs[arm]=data
   if arm=='P48Reference':
    oldfile=Path(case['retained_parent']);assert sha(oldfile)==case['retained_parent_sha256'];old=json.loads(oldfile.read_text());keys=['owner','step','original_sha256','original_map_score','original_breakdown'];identity=dict(all_rows=data['rows']==old['rows'],all_raw_maps=data['map_results']==old['map_results'],raw_submitted=[{k:r[k]for k in keys}for r in data['submission_records']]==[{k:r[k]for k in keys}for r in old['submission_records']])
    (F/(label+'_IDENTITY_FIRST.json')).write_text(json.dumps(identity,indent=2)+'\n')
    if not all(identity.values()):raise RuntimeError('Baseline diagnostic differs; no candidate run or retry')
  parent,candidate=outputs['P48Reference'],outputs['P112'];pv,cv=parent['coverage_evaluation'],candidate['coverage_evaluation'];changed=[e for e in candidate['projection_events']if e['changed_cells']]
  checks=dict(parent_physical_checks=all(parent['checks'].values()),candidate_physical_checks=all(candidate['checks'].values()),all10=parent['rows'][-1]['inventory']==candidate['rows'][-1]['inventory']==[0]*5 and pv['actual_bomb_count']==cv['actual_bomb_count']==10,actual_submission=cv['actual_submitted_map']is not None,map_nonregress=cv['actual_submitted_map']is not None and cv['actual_submitted_map']>=pv['actual_submitted_map'],wall_nonregress=cv['score_wall']>=pv['score_wall'],time_nonregress=cv['score_time']>=pv['score_time'],subtotal_nonregress=cv['controllable_subtotal']is not None and cv['controllable_subtotal']>=pv['controllable_subtotal'],health_nonregress=all(r['health'][i]>=case['min_health'][i]for r in candidate['rows']for i in range(5)),declared_input_wall_bound=case['wall_rate']*candidate['physics_steps']<=90,actual_projection_changes=bool(changed),finite_same_dtype=all(e['finite']and e['dtype_unchanged']for e in candidate['projection_events']))
  delta=None if cv['controllable_subtotal']is None else cv['controllable_subtotal']-pv['controllable_subtotal'];review=dict(status='PASS_ACTUAL_COVERAGE_AUTHOR_COMPARISON'if all(checks.values())else'STOP_KEEP_FIRST_COVERAGE_COMPARISON_FAILURE',utc=utc(),case=case['case'],rate=case['wall_rate'],checks=checks,parent={k:pv[k]for k in ['actual_bomb_count','actual_submitted_map','score_wall','score_time','controllable_subtotal']},candidate={k:cv[k]for k in ['actual_bomb_count','actual_submitted_map','score_wall','score_time','controllable_subtotal']},parent_steps=parent['physics_steps'],candidate_steps=candidate['physics_steps'],controllable_subtotal_delta=delta,changed_projection_calls=len(changed),changed_value_calls=sum(e['interpolation']=='AREA'for e in changed),changed_solid_calls=sum(e['interpolation']=='NEAREST'for e in changed),candidate_loop_seconds=candidate['wall_seconds'],not_full_red_score=True,native_rounds=0)
  (F/(case['code']+'_COMPARISON_FIRST.json')).write_text(json.dumps(review,indent=2)+'\n');reviews.append(review);print(json.dumps(review),flush=True)
  if not all(checks.values()):stop=True;break
 meaningful=not stop and any(r['controllable_subtotal_delta']>=.30 for r in reviews)
 result=dict(status='STOP_FIRST_COVERAGE_COMPARISON_NO_RETRY'if stop else'COMPLETE_PROMISING_ACTUAL_COVERAGE_CHECKS'if meaningful else'COMPLETE_COVERAGE_CHECKS_NO_SUBSTANTIVE_GAIN',reviews=reviews,substantive_gain=meaningful,native_rounds=0,automatic_native_or_five=False,not_full_red_score=True)
 (F/'RESULT_FIRST.json').write_text(json.dumps(result,indent=2)+'\n');(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status=result['status'],native_rounds=0),indent=2)+'\n')
if __name__=='__main__':
 try:main()
 except Exception:
  import traceback
  (F/'FIRST_ERROR.json').write_text(json.dumps(dict(utc=utc(),traceback=traceback.format_exc(),no_retry=True),indent=2)+'\n');raise
