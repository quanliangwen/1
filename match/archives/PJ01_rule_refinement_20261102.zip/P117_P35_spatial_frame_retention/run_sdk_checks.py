from pathlib import Path
import ast,subprocess,json,time,datetime,hashlib
F=Path(__file__).resolve().parent;R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P117_P35_spatial_frame_retention_20261102'
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60'];utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def remote(code):return subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=code.encode(),capture_output=True)
def keep(name,p):
 path=F/(name+'.capture.txt');assert not path.exists();path.write_bytes(p.stdout+p.stderr);print(p.stdout.decode(errors='replace')[-1100:],flush=True)
 if p.returncode:raise RuntimeError('Preserve first SDK error '+name)
def fetch(name):subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+name,str(F/name)],check=True)
def main():
 assert not(F/'SDK_STARTED_FIRST.json').exists();pre=json.loads((F/'PREDECLARATION_FIRST.json').read_text());decl=json.loads((F/'CANDIDATE_MANIFEST_FIRST.json').read_text());work=json.loads((F/'WORKSPACE_READY.json').read_text())
 for file,key in [('check_sdk_retention.py','source_sha256'),('CANDIDATE_MANIFEST_FIRST.json','manifest_sha256'),('ACTUAL_METHOD_CHECK_FIRST.json','method_check_sha256'),('MECHANISM_PREFLIGHT_FIRST.json','preflight_sha256')]:assert sha(F/file)==pre[key]
 assert work['versions']['P48Reference']['sources']==decl['parent_files'];assert work['versions']['P117']['sources']==decl['candidate_files'];assert work['versions']['P48Reference']['sdk_files']==work['versions']['P117']['sdk_files']
 assert sha(Path(pre['reference_control']))==pre['reference_control_sha256'];assert sha(Path(pre['urgent_parent_reference']))==pre['urgent_parent_reference_sha256']
 history=json.loads((F/'MECHANISM_PREFLIGHT_FIRST.json').read_text());assert history['status']=='PASS_NO_EXACT_HISTORICAL_SOURCE_MATCH'and history['candidate_fingerprint']==hashlib.sha256(json.dumps(decl['candidate_files'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
 guard=Path('E:/codex/UAV_rules_astar_restart_20261030/R154_scoped_serial_guard_20261101/check_scoped_serial.py').read_text();keep('SDK_SERIAL_FIRST',remote(guard))
 (F/'SDK_STARTED_FIRST.json').write_text(json.dumps(dict(utc=utc(),finite_hours=14,maximum_author_missions=3,native_rounds=0),indent=2)+'\n')
 for name in ['check_sdk_retention.py','PREDECLARATION_FIRST.json']:subprocess.run(['scp','-q',str(F/name),'junhao@10.112.162.60:'+D+'/'],check=True)
 subprocess.run(['scp','-q','E:/codex/UAV_rules_astar_restart_20261030/run_sdk_captured.py','junhao@10.112.162.60:'+D+'/'],check=True)
 original=Path('E:/codex/PJ01_environment_restore_20261101/P35_continuation_after_parent_repair/run_offline.py').read_text();methods='\n'.join(ast.get_source_segment(original,n)for n in ast.parse(original).body if isinstance(n,ast.FunctionDef)and n.name in ['cpu_sample','resource'])
 capacity='from pathlib import Path\nimport os,time,shutil,json,datetime\nR=Path('+repr(R)+')\nD=json.loads((R/"solver_study/framework_screen_20261016/best87_independent_20261025/P37_phase_five_comparison_20261101/PREDECLARATION.json").read_text())\ndef utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()\n'+methods+'\nprint(json.dumps(resource()))\n'
 deadline=time.monotonic()+14*3600;consecutive=[];count=0
 while time.monotonic()<deadline:
  if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop')
  count+=1;p=remote(capacity);keep('SDK_CAPACITY_'+str(count)+'_FIRST',p);row=json.loads(p.stdout);consecutive=consecutive+[row]if row['clean']else[]
  (F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='WAITING_ORIGINAL_CAPACITY',resource=row),indent=2)+'\n')
  if len(consecutive)>=2:break
  time.sleep(60)
 else:raise TimeoutError('Finite SDK wait expired')
 (F/'SDK_RESOURCE_TWO_SAMPLE_FIRST.json').write_text(json.dumps(consecutive,indent=2)+'\n');reviews=[];stop=False
 for case in pre['cases']:
  outputs={}
  if case['retained_parent']:
   parent=json.loads(Path(pre['reference_control']).read_text());assert parent['source_sha256']==work['versions']['P48Reference']['sources']
   (F/'CROSS_BASELINE_REUSE_FIRST.json').write_text(json.dumps(dict(utc=utc(),source=str(pre['reference_control']),sha256=pre['reference_control_sha256'],all40_source_equal=True,SDK124_equal=True,SDK_frames_added=0,geometry_same='same source fixture and cross_sdk/.05/seed615'),indent=2)+'\n');outputs['P48Reference']=parent
  for arm,labelkey in [('P48Reference','parent_label'),('P117','candidate_label')]:
   if arm=='P48Reference'and case['retained_parent']:continue
   if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop before mission')
   label=case[labelkey];keep(label+'_SERIAL_FIRST',remote(guard))
   (F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='RUNNING_AUTHOR_RETENTION_CLOSURE',current=label,native_rounds=0),indent=2)+'\n')
   keep(label,subprocess.run(ssh+[R+'/.venv/bin/python',D+'/run_sdk_captured.py',D+'/check_sdk_retention.py',label,arm,case['case'],str(case['horizon']),str(case['wall_rate'])],capture_output=True));fetch(label+'.json');data=json.loads((F/(label+'.json')).read_text());outputs[arm]=data
   if arm=='P48Reference':
    old=json.loads(Path(pre['urgent_parent_reference']).read_text());keys=['owner','step','original_sha256','original_map_score','original_breakdown']
    identity=dict(all_rows=data['rows']==old['rows'],all_raw_maps=data['map_results']==old['map_results'],all_source=data['source_sha256']==old['source_sha256'],actual_submission=[{k:e[k]for k in keys}for e in data['submission_records']]==[{k:e[k]for k in keys}for e in old['submission_records']])
    (F/'URGENT_BASELINE_IDENTITY_FIRST.json').write_text(json.dumps(identity,indent=2)+'\n')
    if not all(identity.values()):raise RuntimeError('Baseline identity mismatch, no candidate or retry')
  parent,candidate=outputs['P48Reference'],outputs['P117'];pv,cv=parent['coverage_evaluation'],candidate['coverage_evaluation'];events=candidate['frame_retention_events']
  checks=dict(parent_physical=all(parent['checks'].values()),candidate_physical=all(candidate['checks'].values()),all10=parent['rows'][-1]['inventory']==candidate['rows'][-1]['inventory']==[0]*5 and pv['actual_bomb_count']==cv['actual_bomb_count']==10,actual_submission=cv['actual_submitted_map']is not None,map_nonregress=cv['actual_submitted_map']is not None and cv['actual_submitted_map']>=pv['actual_submitted_map'],wall_nonregress=cv['score_wall']>=pv['score_wall'],time_nonregress=cv['score_time']>=pv['score_time'],subtotal_nonregress=cv['controllable_subtotal']is not None and cv['controllable_subtotal']>=pv['controllable_subtotal'],health_nonregress=all(r['health'][i]>=case['min_health'][i]for r in candidate['rows']for i in range(5)),declared_input_wall_bound=case['wall_rate']*candidate['physics_steps']<=90,actual_cull=bool(events),spatial_witnesses_actually_retained=any(e['spatial_additions']>0 for e in events),retention_contract=all(e['after_count']<=344 and e['old_records_not_kept']==0 and e['original_record_objects']and e['negative_dictionary_unchanged']and e['physical_alias']for e in events))
  delta=None if cv['controllable_subtotal']is None else cv['controllable_subtotal']-pv['controllable_subtotal']
  review=dict(status='PASS_AUTHOR_RETENTION_COMPARISON'if all(checks.values())else'STOP_FIRST_RETENTION_COMPARISON_FAILURE',utc=utc(),case=case['case'],wall_rate=case['wall_rate'],checks=checks,parent={k:pv[k]for k in ['actual_bomb_count','actual_submitted_map','score_wall','score_time','controllable_subtotal']},candidate={k:cv[k]for k in ['actual_bomb_count','actual_submitted_map','score_wall','score_time','controllable_subtotal']},parent_steps=parent['physics_steps'],candidate_steps=candidate['physics_steps'],subtotal_delta=delta,cull_events=len(events),spatial_cull_events=sum(e['spatial_additions']>0 for e in events),max_kept=max((e['after_count']for e in events),default=0),candidate_loop_seconds=candidate['wall_seconds'],not_full_red_score=True,native_rounds=0)
  (F/(case['code']+'_COMPARISON_FIRST.json')).write_text(json.dumps(review,indent=2)+'\n');reviews.append(review);print(json.dumps(review),flush=True)
  if not all(checks.values()):stop=True;break
 promising=not stop and any(e['subtotal_delta']>=.30 for e in reviews)
 result=dict(status='STOP_FIRST_RETENTION_COMPARISON_NO_RETRY'if stop else'COMPLETE_PROMISING_RETENTION_AUTHOR_CHECKS'if promising else'COMPLETE_RETENTION_NO_SUBSTANTIVE_GAIN',reviews=reviews,promising=promising,native_rounds=0,automatic_native_or_five=False)
 (F/'RESULT_FIRST.json').write_text(json.dumps(result,indent=2)+'\n');(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status=result['status'],native_rounds=0),indent=2)+'\n')
if __name__=='__main__':
 try:main()
 except Exception:
  import traceback
  (F/'SDK_FIRST_ERROR.json').write_text(json.dumps(dict(utc=utc(),traceback=traceback.format_exc(),no_retry=True),indent=2)+'\n');raise
