from pathlib import Path
import json,hashlib,datetime
F=Path(__file__).resolve().parent;dest=F/'MECHANISM_REVIEW_FIRST.json';assert not dest.exists()
result=json.loads((F/'RESULT_FIRST.json').read_text());pre=json.loads((F/'PREDECLARATION_FIRST.json').read_text());out=[]
for review in result['reviews']:
 code='CROSS'if review['wall_rate']==.05 else'URGENT';case=next(c for c in pre['cases']if c['code']==code)
 parentfile=Path(pre['reference_control'])if case['retained_parent']else F/(case['parent_label']+'.json');childfile=F/(case['candidate_label']+'.json');p=json.loads(parentfile.read_text());c=json.loads(childfile.read_text())
 different=next((n for n,(a,b)in enumerate(zip(p['rows'],c['rows']),1)if a!=b),None)
 same_rows=p['rows']==c['rows'];sub=p['submission_records'][0];subc=c['submission_records'][0]if c['submission_records']else None
 owners=[]
 for owner in range(5):
  events=[e for e in c['frame_retention_events']if e['owner']==owner]
  drops=lambda d:[r['step']for j,r in enumerate(d['rows'])if r['inventory'][owner]<(2 if j==0 else d['rows'][j-1]['inventory'][owner])]
  owners.append(dict(owner=owner,map_parent=p['map_results'][owner]['score'],map_candidate=c['map_results'][owner]['score'],cull_count=len(events),spatial_cull_count=sum(e['spatial_additions']>0 for e in events),first_cull_step=None if not events else events[0]['step'],max_new_witness_records=max((e['spatial_additions']for e in events),default=0),parent_drop_steps=drops(p),candidate_drop_steps=drops(c)))
 out.append(dict(case=code,source_hashes=dict(parent=hashlib.sha256(parentfile.read_bytes()).hexdigest(),candidate=hashlib.sha256(childfile.read_bytes()).hexdigest()),all_physical_actions_and_raw_states_identical=same_rows,first_different_row=different,parent_steps=p['physics_steps'],candidate_steps=c['physics_steps'],submission_owner_step_same=subc is not None and (sub['owner'],sub['step'])==(subc['owner'],subc['step']),actual_submission_sha_same=subc is not None and sub['output_sha256']==subc['output_sha256'],all_actual_wall_placement_evaluation_identical={k:v for k,v in p['coverage_evaluation'].items()if k not in ['actual_submitted_map','controllable_subtotal','score_eval_seconds']}=={k:v for k,v in c['coverage_evaluation'].items()if k not in ['actual_submitted_map','controllable_subtotal','score_eval_seconds']},owners=owners))
report=dict(status='COMPLETE_FIRST_SPATIAL_RETENTION_CLOSURE_REVIEW',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),overall_result=result['status'],cases=out,native_rounds=0,limits=['Identity of actions and raw arrays permits attribution of any changed image in that authored case to record retention/rendering; it does not prove general tournament performance.','A real cull with zero score gain is successful mechanism activation, not an improved version.','Do not stack failed grid projection to create an apparent rescued score.'])
dest.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
