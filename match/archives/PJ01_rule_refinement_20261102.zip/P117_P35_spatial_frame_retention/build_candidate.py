from pathlib import Path
import ast,json,hashlib,shutil,datetime,textwrap
F=Path(__file__).resolve().parent;B=Path('E:/codex/PJ01_rule_refinement_20261101/P48_P35_refresh_deferral_candidate');P=B/'candidate_project';C=F/'candidate_project'
assert not C.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((B/'CANDIDATE_MANIFEST_FIRST.json').read_text());assert all(sha(P/n)==h for n,h in old['candidate_files'].items())
reference=F.parent/'P116_spatial_frame_retention_reference'
assert json.loads((reference/'REFERENCE_CHECK_FIRST.json').read_text())['status']=='PASS_BOUNDED_SPATIAL_FRAME_REFERENCE'
shutil.copytree(P,C,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git'))
p=C/'src/swarm_rescue/solutions/frame_mapping.py';s=p.read_text();tree=ast.parse(s)
helper=ast.get_source_segment((reference/'spatial_record_reference.py').read_text(),next(n for n in ast.parse((reference/'spatial_record_reference.py').read_text()).body if isinstance(n,ast.FunctionDef))).replace('def retained_keys(','def _retained_frame_keys(',1)
needle='class InferredFrameMemory(';assert s.count(needle)==1;s=s.replace(needle,helper+'\n\n\n'+needle)
tree=ast.parse(s);node=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='_limit_frame_records');original=ast.get_source_segment(s,node)
replacement='''def _limit_frame_records(self):
        if len(self.frame_records)<=384: return
        keys=_retained_frame_keys(self.frame_records,self.memory.width,self.memory.height)
        self.frame_records={key:self.frame_records[key]for key in keys}
        self.memory.frame_records=self.frame_records'''
assert s.count(original)==1;s=s.replace(original,replacement);ast.parse(s);p.write_text(s)
files={f.relative_to(C).as_posix():sha(f)for f in C.rglob('*')if f.is_file()};diff=[n for n in sorted(files.keys()|old['candidate_files'].keys())if files.get(n)!=old['candidate_files'].get(n)]
assert diff==['src/swarm_rescue/solutions/frame_mapping.py']
out=dict(status='FROZEN_ONE_BOUNDED_MEASURED_SPAN_RETENTION_RULE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent=str(P),parent_files=old['candidate_files'],candidate_files=files,differences=diff,rule='Only frame record culling above384: preserve old recent80 per side plus at most3 distinct measured records at each span extreme/side. At most344 records after cull. Use inherited fitter angle/normal/length guards for witness selection; do not draw new geometry or weaken acceptance. Preserve all existing negative evidence and each retained original record/rays.',source_evidence='P115 samefailed556 identity PASS, raw stable points retained but old frame records lost; fixedfinal raw/negative restoration alone recovers frame. P116 bounded numeric and opening/missingcorner/interior counterexamples PASS. Failed P112 projection is not stacked.',references=['https://github.com/raulmur/ORB_SLAM2/blob/master/src/LocalMapping.cc','https://zaguan.unizar.es/record/32799/files/texto_completo.pdf?version=1'],conceptual_history_review=['P77 adds output closed-frame rendering; nativeP78 zeroactual addition, not the record-retention mechanism','P94 final exchange regresses map, not record culling','P96 removes bearing hits loses true walls, not included','P112 grid projection wall up/mapdown rejected, used readonly diagnosis only','P67/P105 duplicated event branch rejected, not included'],unchanged=['P35 phases and parentP48 stale opportunity refresh','all map rendering and frame rejection/contradiction thresholds','raw hits/semantic/free/bearing/motion/coverage/layout/SDK/req/limits/threads'],req_unchanged=(P/'req.txt').read_bytes()==(C/'req.txt').read_bytes(),SDK_change=False,native_rounds=0,official_submission=False)
(F/'CANDIDATE_MANIFEST_FIRST.json').write_text(json.dumps(out,indent=2)+'\n')
numeric=(reference/'check_spatial_reference.py').read_text();numeric=numeric.replace("from spatial_record_reference import retained_keys",'''import ast,math
from types import SimpleNamespace
F0=Path(__file__).resolve().parent
source_code=(F0/'candidate_project/src/swarm_rescue/solutions/frame_mapping.py').read_text()
tree=ast.parse(source_code);helper=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='_retained_frame_keys');method=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='_limit_frame_records')
scope=dict(np=np,math=math);exec(compile(ast.Module(body=[helper,method],type_ignores=[]),'frozen_actual_frame_method','exec'),scope)
def retained_keys(records,width,height):
    state=SimpleNamespace(frame_records=records.copy(),memory=SimpleNamespace(width=width,height=height));state.memory.frame_records=state.frame_records
    scope['_limit_frame_records'](state)
    assert state.memory.frame_records is state.frame_records
    assert all(state.frame_records[k] is records[k]for k in state.frame_records)
    return list(state.frame_records)''').replace("dest=F/'REFERENCE_CHECK_FIRST.json'","dest=F/'ACTUAL_METHOD_CHECK_FIRST.json'").replace("(F/'spatial_record_reference.py').read_bytes()","(F/'candidate_project/src/swarm_rescue/solutions/frame_mapping.py').read_bytes()").replace("status='PASS_BOUNDED_SPATIAL_FRAME_REFERENCE'","status='PASS_ACTUAL_FROZEN_FRAME_CULL_METHOD'")
ast.parse(numeric);(F/'check_candidate_method.py').write_text(numeric)
print(json.dumps(dict(status=out['status'],differences=diff)))
