"""Finite memory/geometry checks plus fixed actual own-state replay; no SDK."""
from pathlib import Path
import importlib.util,sys,json,hashlib,copy,time,datetime
import numpy as np
import cv2
import ast,math
from types import SimpleNamespace
F0=Path(__file__).resolve().parent
source_code=(F0/'candidate_project/src/swarm_rescue/solutions/frame_mapping.py').read_text()
tree=ast.parse(source_code);helper=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='_retained_frame_keys');method=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='_limit_frame_records')
scope=dict(np=np,math=math);exec(compile(ast.Module(body=[helper,method],type_ignores=[]),'frozen_actual_frame_method','exec'),scope)
def retained_keys(records,width,height):
    state=SimpleNamespace(frame_records=records.copy(),memory=SimpleNamespace(width=width,height=height));state.memory.frame_records=state.frame_records
    scope['_limit_frame_records'](state)
    assert state.memory.frame_records is state.frame_records
    assert all(state.frame_records[k] is records[k]for k in state.frame_records)
    return list(state.frame_records)
F=Path(__file__).resolve().parent;dest=F/'ACTUAL_METHOD_CHECK_FIRST.json';assert not dest.exists()
G=F.parent/'PJ01_rules_P115_render_regression_timeline_20261102'
assert json.loads((G/'RESULT_FIRST.json').read_text())['status']=='PASS_SAME_FAILED_TIMELINE_IDENTITY'
meta=json.loads((G/'WORKSPACE_READY.json').read_text());source=Path(meta['versions']['P112']['workspace'])/'src/swarm_rescue/solutions/rectangular_boundary.py'
assert hashlib.sha256(source.read_bytes()).hexdigest()==meta['versions']['P112']['sources']['src/swarm_rescue/solutions/rectangular_boundary.py']
spec=importlib.util.spec_from_file_location('frozen_original_frame',source);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
def model(records,negative=()):
 groups={}
 for source,step,lines,origin,endpoints,*_ in records.values():groups[(source,step)]=[source,step,lines,origin,list(endpoints)]
 for _,entries in negative:
  for _,source,step,origin,endpoint in entries:
   r=groups.setdefault((source,step),[source,step,[],origin,[]]);r[4].append(endpoint)
 m=module.RectangularBoundaryInference(800,600,world_axis_prior=True,plane_coordinate_guard=10,plane_mad_limit=3.5,maximum_line_angle_deg=2,maximum_line_normal_spread=8)
 m.ingest_batch(groups.values());image=m.render();return m,image
def old_keys(records):
 if len(records)<=384:return list(records)
 ordered=sorted(records,key=lambda k:k[1],reverse=True);kept=set()
 for side in range(4):kept.update([k for k in ordered if side in records[k][5]][:80])
 return list(kept)
def select(records,selector):
 chosen=selector(records,800,600)if selector is retained_keys else selector(records)
 return{k:records[k]for k in chosen}
def record(side,key,lo,hi,plane=None):
 axis=side//2;plane=(-1 if side%2==0 else 1)*(396 if axis==0 else 296)if plane is None else plane
 line=[[plane,lo],[plane,hi]]if axis==0 else[[lo,plane],[hi,plane]]
 return(key[0],key[1],[line],[0.,0.],[],(side,))
cases=[];start=time.perf_counter()
def add(name,checks,**details):
 cases.append(dict(name=name,checks=checks,**details));assert all(checks.values()),(name,checks)
full={}
for side in range(4):
 half=296 if side<2 else 396
 for scan in range(3):
  key=(side,scan+1);full[key]=record(side,key,-half+3,half-3)
for step in range(10,410):
 side=step%4;key=(side,step);full[key]=record(side,key,-80.,80.)
saved=copy.deepcopy(full);old=select(full,old_keys);new=select(full,retained_keys);om,_=model(old);nm,image=model(new)
add('old_unique_extent_is_not_replaced_by_recent_repetition',dict(old_rejects=om.hypothesis is None,new_accepts=nm.hypothesis is not None,bounded_records=len(new)<=344,source_values_unchanged=full==saved,subset_only=set(new)<=set(full)),old_reason=om.reason,new_records=len(new),model_line_count=len(nm.lines))
small=dict(list(full.items())[:12]);add('below_capacity_is_exact_noop',dict(same_order=retained_keys(small,800,600)==list(small)))
add('selected_state_is_idempotent',dict(same_order=retained_keys(new,800,600)==list(new)))
interior={k:record(r[5][0],k,-120,120,plane=(-1 if r[5][0]%2==0 else 1)*180)for k,r in full.items()};im,_=model(select(interior,retained_keys));add('interior_rectangle_does_not_become_frame',dict(rejected=im.hypothesis is None))
missing={k:r for k,r in full.items()if r[5][0]!=3};mm,_=model(select(missing,retained_keys));add('missing_side_not_created',dict(rejected=mm.hypothesis is None))
central={k:record(r[5][0],k,-80.,80.)for k,r in full.items()};cm,_=model(select(central,retained_keys));add('unobserved_corners_still_rejected',dict(rejected=cm.hypothesis is None))
negative=[([0,0],[[1.,9,901,[-200.,0.],[-460.,0.]],[2.,9,902,[-200.,0.],[-460.,0.]]])]
gm,gapimage=model(new,negative);add('new_opening_overrules_retained_old_positive',dict(frame_fit=gm.hypothesis is not None,opening_retained=bool(gm.confirmed_gaps),wall_interval_cleared=not bool(gapimage[300,4])),confirmed_gaps=gm.confirmed_gaps)
actual=[]
for owner in [0,1]:
 snapshots=[json.loads((G/('AUTHOR_OWN_'+str(owner)+'_STEP_'+str(step)+'.json')).read_text())for step in [264,300,360,420,480,556]]
 records={}
 for s in snapshots:
  for r in s['frame_records']:records[(int(r[0]),int(r[1]))]=r
 # This is a retained-observation subset, not the complete live message stream.
 # Common chronology is an explicitly declared reference order only.
 records=dict(sorted(records.items(),key=lambda item:(item[0][1],item[0][0])))
 variants={}
 for name,selector in [('original_recent_only',old_keys),('spatial_witness_reference',retained_keys)]:
  kept=select(records,selector);m,image=model(kept,snapshots[-1]['frame_negative'])
  variants[name]=dict(records=len(kept),model_lines=len(m.lines),diagnostics=m.diagnostics(),sha256=hashlib.sha256(image.tobytes()).hexdigest())
 actual.append(dict(owner=owner,available_own_records=len(records),final_negative_evidence_retained=True,variants=variants))
 add('actual_own_subset_owner'+str(owner),dict(bounded=variants['spatial_witness_reference']['records']<=344,frame_supported=variants['spatial_witness_reference']['diagnostics']['accepted']),variants=variants)
out=dict(status='PASS_ACTUAL_FROZEN_FRAME_CULL_METHOD',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cases=cases,actual_reference=actual,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),rule_sha256=hashlib.sha256((F/'candidate_project/src/swarm_rescue/solutions/frame_mapping.py').read_bytes()).hexdigest(),numeric_seconds=time.perf_counter()-start,SDK_imports=0,SDK_frames=0,native_rounds=0,limits=['Retained own snapshot union lacks intermediate live arrival order; this is a numerical reference, not the live controller.','No map truth or performance score is used here. Frame acceptance and bounded memory are necessary checks, not proof of higher five-map score.','Reference keeps recent80/side plus at most3 independent records at each observed span extreme; no invented wall lines, threshold relaxation, saved best map or extra negative-evidence deletion.'])
dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
