from pathlib import Path
import ast,json,hashlib,datetime
F=Path(__file__).resolve().parent;P=F.parent/'P113_P112_actual_coverage_validation';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not(F/'PREDECLARATION_FIRST.json').exists()
assert json.loads((F/'ACTUAL_METHOD_CHECK_FIRST.json').read_text())['status']=='PASS_ACTUAL_FROZEN_FRAME_CULL_METHOD'
assert json.loads((F/'MECHANISM_PREFLIGHT_FIRST.json').read_text())['status']=='PASS_NO_EXACT_HISTORICAL_SOURCE_MATCH'
s=(P/'check_sdk_actual_coverage.py').read_text();s=s.replace(s.splitlines()[0],'"""First independent P48+spatial record retention SDK check, original actual wall/map/time evaluation after outputs freeze."""')
needle='gate_events=[];gate_stack={};route_details=[]';assert s.count(needle)==1
audit='''from swarm_rescue.solutions.frame_mapping import FrameMappingMixin
raw_limit=FrameMappingMixin._limit_frame_records
frame_retention_events=[]
def audit_limit(self):
 if len(self.frame_records)<=384:return raw_limit(self)
 before=self.frame_records.copy();ordered=sorted(before,key=lambda key:key[1],reverse=True);old=set()
 for side in range(4):old.update([k for k in ordered if side in before[k][5]][:80])
 negative=self.frame_negative
 result=raw_limit(self);after=set(self.frame_records)
 frame_retention_events.append(dict(owner=int(self.identifier or 0),step=int(self.elapsed_timestep),before_count=len(before),after_count=len(after),original_would_keep=len(old),spatial_additions=len(after-old),old_records_not_kept=len(old-after),original_record_objects=all(self.frame_records[k]is before[k]for k in after),negative_dictionary_unchanged=self.frame_negative is negative,physical_alias=self.memory.frame_records is self.frame_records))
 return result
FrameMappingMixin._limit_frame_records=audit_limit

'''
s=s.replace(needle,audit+needle).replace('coverage_evaluation=coverage_evaluation,projection_events=projection_events,','frame_retention_events=frame_retention_events,coverage_evaluation=coverage_evaluation,projection_events=projection_events,')
ast.parse(s);(F/'check_sdk_retention.py').write_text(s)
control=P/'CROSS_P48_ACTUAL_COVERAGE_FIRST.json';c=json.loads(control.read_text());m=json.loads((F/'CANDIDATE_MANIFEST_FIRST.json').read_text());assert c['source_sha256']==m['parent_files']
pre=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=sha(F/'check_sdk_retention.py'),manifest_sha256=sha(F/'CANDIDATE_MANIFEST_FIRST.json'),method_check_sha256=sha(F/'ACTUAL_METHOD_CHECK_FIRST.json'),preflight_sha256=sha(F/'MECHANISM_PREFLIGHT_FIRST.json'),reference_control=str(control),reference_control_sha256=sha(control),maximum_author_missions=3,native_rounds=0,automatic_native_or_five=False,rule='Independent P48 plus one bounded spatial frame-retention rule. Does not stack failed P112.',cases=[dict(code='CROSS',case='cross_sdk',wall_rate=.05,horizon=900,min_health=[50]*5,candidate_label='CROSS_P117_SPATIAL_FIRST',retained_parent=True),dict(code='URGENT',case='cross_sdk',wall_rate=.15,horizon=900,min_health=[50]*5,parent_label='URGENT_P48_RETAINED_RULE_FIRST',candidate_label='URGENT_P117_SPATIAL_FIRST',retained_parent=False)],gate='At first failed case stop; no seed/label/threshold rescue. 10 actual bombs, valid actual submission, all original physical/health checks, map/wall/time/controllable subtotal nonregress vs same fixture source baseline; real cull and spatial additions with original retained record objects, negative dictionary and memory alias. At least one actual subtotal improvement >=0.30 across both cases before considering qualification and native single. Controllable subtotal excludes BLUE difficulty and is not full red score.',comparison_limits='CROSS control reused only after all40 exact parent sources+SDK124 and fixture geometry/settings binding. Fresh URGENT parent must match retained original P104 trajectory/output before running candidate. No formal baseline/five replay.')
urgent=F.parent/'P104_phase_actual_exit_diagnosis'
# Locate retained URGENT parent by contents rather than inventing a path.
matches=[]
for folder in F.parent.glob('P*'):
 for file in folder.glob('*.json'):
  if file.stat().st_size<100000:continue
  try:d=json.loads(file.read_text())
  except (ValueError,OSError):continue
  if d.get('arm')=='P48Reference'and d.get('case')=='cross_sdk'and d.get('author_wall_rate')==.15 and d.get('source_sha256')==m['parent_files']and d.get('physics_steps')==567:matches.append(file)
assert matches,'Need exact retained urgent parent before freezing'
pre['urgent_parent_reference']=str(sorted(matches)[0]);pre['urgent_parent_reference_sha256']=sha(sorted(matches)[0])
(F/'PREDECLARATION_FIRST.json').write_text(json.dumps(pre,indent=2)+'\n');print(json.dumps(dict(status='FROZEN_SDK_PROTOCOL',retained_urgent=pre['urgent_parent_reference'],max_author=3)))
