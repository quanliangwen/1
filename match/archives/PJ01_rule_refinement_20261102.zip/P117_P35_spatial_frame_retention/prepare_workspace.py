from pathlib import Path
import json,hashlib,shutil
F=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((F.parent/'PJ01_rules_P91_tail_reference_20261102/WORKSPACE_READY.json').read_text())['versions']['P48Reference'];W=Path(base['workspace'])
assert all(sha(W/n)==h for n,h in base['sources'].items())and all(sha(W/n)==h for n,h in base['sdk_files'].items())
decl=json.loads((F/'CANDIDATE_MANIFEST_FIRST.json').read_text());S=F/'candidate_project';assert all(sha(S/n)==h for n,h in decl['candidate_files'].items())
new=F/'workspace_P117';assert not new.exists();shutil.copytree(W,new,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git'))
for name in decl['candidate_files']:
    p=new/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(S/name,p)
assert all(sha(new/n)==h for n,h in base['sdk_files'].items());assert(new/'req.txt').read_bytes()==(W/'req.txt').read_bytes()
out=dict(status='CANDIDATE_SOURCE_AND_SDK_BOUND_NO_PHYSICS_YET',versions={'P48Reference':base,'P117':dict(workspace=str(new),sources={n:sha(new/n)for n in decl['candidate_files']},sdk_files=base['sdk_files'])},official_submission=False)
(F/'WORKSPACE_READY.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status=out['status'],files=len(decl['candidate_files']))))
