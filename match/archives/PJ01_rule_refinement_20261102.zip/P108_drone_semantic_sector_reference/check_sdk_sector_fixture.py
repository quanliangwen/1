"""Independent authored sensor fixture; masks are evaluated, never applied.

Public laser/semantic arrays freeze before evaluator-only rendered ray entity
labels are accessed. No controller uses labels, masks or actor private states.
"""
from pathlib import Path
from types import SimpleNamespace
import sys,json,random,hashlib,fcntl,math
import numpy as np
from sector_reference import sector_mask
F=Path(__file__).resolve().parent;dest=F/'SENSOR_SECTOR_FIRST.json';assert not dest.exists()
R=Path('/home/junhao/quan/parallel_test_solver/match');m=json.loads((F/'WORKSPACE_READY.json').read_text())['versions']['P48Reference'];W=Path(m['workspace']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(W/n)==h for n,h in m['sources'].items())and all(sha(W/n)==h for n,h in m['sdk_files'].items());sys.path.insert(0,str(W/'src'))
from swarm_rescue.solutions.my_drone_eval import MyDroneEval
from swarm_rescue.solutions.greedy_mapping import MapMemory
from swarm_rescue.simulation.drone.drone_base import DroneBase
from swarm_rescue.simulation.drone.agent import Agent
from swarm_rescue.simulation.gui_map.playground import Playground
from swarm_rescue.simulation.gui_map.closed_playground import ClosedPlayground
from swarm_rescue.simulation.elements.normal_wall import NormalWall,NormalBox
from swarm_rescue.simulation.elements.disposal_center import DisposalCenter
from swarm_rescue.simulation.utils.misc_data import MiscData
from swarm_rescue.simulation.utils.constants import RESOLUTION_SEMANTIC_SENSOR,FOV_SEMANTIC_SENSOR,RESOLUTION_LIDAR_SENSOR
assert(RESOLUTION_SEMANTIC_SENSOR,FOV_SEMANTIC_SENSOR,RESOLUTION_LIDAR_SENSOR)==(35,360,181)
class Fixture(Playground):
 _handle_interactions=ClosedPlayground._handle_interactions
 get_closest_drone=ClosedPlayground.get_closest_drone
lock=(R/'solver_study/serial_evaluation.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
pg=None;rows=[];np.random.seed(615);random.seed(615)
layouts=[dict(name='peer_near',distance=40.,angle=.25,wall=False),dict(name='peer_middle',distance=100.,angle=.25,wall=False),dict(name='peer_far',distance=160.,angle=.25,wall=False),dict(name='peer_beside_wall',distance=100.,angle=.25,wall=True),dict(name='wall_without_peer',distance=None,angle=.25,wall=True)]
try:
 for layout in layouts:
  pg=Fixture(size=(800,600));ClosedPlayground._walls_creation(pg,6)
  if layout['wall']:
   wall=NormalWall((120.,-100.),(120.,100.));pg.add(wall,wall.wall_coordinates)
  center=DisposalCenter(size=(40,40));pg.add(center,((-250.,200.),0.));fixture=SimpleNamespace(disposal_center=center,_bombs=[],_number_bombs=0,playground=pg)
  poses=[(0.,0.)]
  if layout['distance']is not None:poses.append((layout['distance']*math.cos(layout['angle']),layout['distance']*math.sin(layout['angle'])))
  drones=[]
  for i,p in enumerate(poses):
   drone=MyDroneEval(i,misc_data=MiscData(size_area=(800,600),number_drones=len(poses),max_timestep_limit=2000,max_walltime_limit=90));pg.add(drone,(p,0.));drone.enable_bomb_deployer(fixture,2);drone.set_competition_mode(True);drones.append(drone)
  pg.reset();zero=dict(forward=0.,lateral=0.,rotation=0.,grasper=0,place_bomb=0)
  for step in range(1,5):
   pg.step({drone:dict(zero)for drone in drones},{})
   own=drones[0]
   # Freeze the public interface BEFORE any evaluator object identity access.
   distances=np.asarray(own.lidar_values(),float).copy();angles=np.asarray(own.lidar_rays_angles(),float).copy();semantic=list(own.semantic_values()or())
   frozen=dict(distances=distances.tolist(),angles=angles.tolist(),semantic=[dict(kind=getattr(getattr(o,'entity_type',None),'name',''),distance=float(o.distance),angle=float(o.angle))for o in semantic])
   old=MapMemory.semantic_mask(distances,angles,semantic);new=sector_mask(distances,angles,semantic)
   assert np.array_equal(distances,np.asarray(frozen['distances']))and np.array_equal(angles,np.asarray(frozen['angles']))and not np.any(old&~new)
   # Author-only measurement ground truth. Never available to production.
   points=np.asarray(own.lidar()._hitpoints).copy();assert len(points)==len(distances)and points.shape[1]>=10
   labels=[]
   for uid in points[:,8].astype(int):
    try:entity=pg.get_entity_from_uid(uid)
    except KeyError:labels.append('UNKNOWN');continue
    labels.append('DRONE'if isinstance(entity,(DroneBase,Agent))else'WALL'if isinstance(entity,(NormalWall,NormalBox))else'OTHER')
   labels=np.asarray(labels);usable=np.isfinite(distances)&(distances>8)&(distances<220);extra=new&~old&usable
   rows.append(dict(layout=layout['name'],step=step,public=frozen,evaluator_labels=labels.tolist(),old_excluded=old.tolist(),new_excluded=new.tolist(),usable_static_candidates=int(usable.sum()),extra_excluded=int(extra.sum()),extra_drone=int(np.count_nonzero(extra&(labels=='DRONE'))),extra_wall=int(np.count_nonzero(extra&(labels=='WALL'))),extra_unknown=int(np.count_nonzero(extra&(labels=='UNKNOWN'))),old_retained_drone=int(np.count_nonzero(usable&~old&(labels=='DRONE'))),new_retained_drone=int(np.count_nonzero(usable&~new&(labels=='DRONE'))),original7callbacks=len(pg.space._handlers)==7,health=[d.drone_health for d in drones],inventory=[int(d.carried_bombs_count())for d in drones]))
  pg.cleanup();pg.close_window();pg=None
 checks=dict(original_callbacks=all(r['original7callbacks']for r in rows),all_health50=all(all(v==50 for v in r['health'])for r in rows),all_stock2=all(all(v==2 for v in r['inventory'])for r in rows),no_peer_identical=all(r['old_excluded']==r['new_excluded']for r in rows if r['layout']=='wall_without_peer'))
 summary=[]
 for layout in layouts:
  subset=[r for r in rows if r['layout']==layout['name']];summary.append(dict(layout=layout['name'],**{k:sum(r[k]for r in subset)for k in ['extra_excluded','extra_drone','extra_wall','extra_unknown','old_retained_drone','new_retained_drone']}))
 loss=sum(r['extra_wall']for r in rows);gain=sum(r['extra_drone']for r in rows)
 out=dict(status='COMPLETE_REFERENCE_OVERFILTERS_TRUE_WALLS'if loss else'COMPLETE_REFERENCE_NO_EXTRA_WALL_LOSS_IN_FIXTURES',checks=checks,summary=summary,rows=rows,extra_true_wall_rays=loss,extra_dynamic_rays=gain,eligible_for_full_mission_candidate=all(checks.values())and gain>0 and loss==0,SDK_frames=len(rows),controller_calls=0,native_rounds=0,limits=['Stationary author-applied zero actions, not navigation or tournament scores.','Ground truth UID labels are only read after public arrays freeze and never feed a controller.','Five finite layouts cannot prove wall safety in all geometries/noise.','One semantic gap is association uncertainty, not proof all nearby matching depth returns are dynamic.'])
 dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k]for k in ['status','checks','summary','extra_true_wall_rays','extra_dynamic_rays','eligible_for_full_mission_candidate','SDK_frames']}))
finally:
 if pg is not None:pg.cleanup();pg.close_window()
 fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
