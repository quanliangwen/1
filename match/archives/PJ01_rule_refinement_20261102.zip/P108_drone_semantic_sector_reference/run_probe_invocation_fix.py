"""Repair the pre-SDK wrapper invocation only, retain original IndexError."""
from pathlib import Path
import ast,json,time,datetime,hashlib,subprocess
from run_sensor_probe import F,R,D,ssh,remote,keep,fetch,utc
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 assert not(F/'INVOCATION_FIX_STARTED_FIRST.json').exists()and not(F/'SENSOR_SECTOR_FIRST.json').exists()
 error=(F/'SENSOR_SECTOR_FIRST.capture.txt').read_text();assert 'script=Path(sys.argv[1]);label=sys.argv[2]'in error and 'IndexError: list index out of range'in error
 pre=json.loads((F/'PREDECLARATION_FIRST.json').read_text());assert sha(F/'check_sdk_sector_fixture.py')==pre['source_sha256']and sha(F/'sector_reference.py')==pre['reference_sha256']
 (F/'INVOCATION_FIX_STARTED_FIRST.json').write_text(json.dumps(dict(utc=utc(),reason='run_sdk_captured wrapper requires a capture label before runpy; original call omitted it and failed at line5 before loading the SDK/probe. Pass original SENSOR_SECTOR_FIRST label, not a changed experiment label.',first_error_sha256=sha(F/'FIRST_ERROR.json'),source_sha256=pre['source_sha256'],reference_sha256=pre['reference_sha256'],SDK_frames_before_fix=0,candidate_changes=False,seed_layout_gates_changed=False),indent=2)+'\n')
 guard=Path('E:/codex/UAV_rules_astar_restart_20261030/R154_scoped_serial_guard_20261101/check_scoped_serial.py').read_text();keep('INVOCATION_FIX_SERIAL_FIRST',remote(guard))
 old=Path('E:/codex/PJ01_environment_restore_20261101/P35_continuation_after_parent_repair/run_offline.py').read_text();methods='\n'.join(ast.get_source_segment(old,n)for n in ast.parse(old).body if isinstance(n,ast.FunctionDef)and n.name in ['cpu_sample','resource'])
 capacity='from pathlib import Path\nimport os,time,shutil,json,datetime\nR=Path('+repr(R)+')\nD=json.loads((R/"solver_study/framework_screen_20261016/best87_independent_20261025/P37_phase_five_comparison_20261101/PREDECLARATION.json").read_text())\ndef utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()\n'+methods+'\nprint(json.dumps(resource()))\n'
 end=time.monotonic()+14*3600;consecutive=[];count=0
 while time.monotonic()<end:
  if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop')
  count+=1;p=remote(capacity);keep('FIX_CAPACITY_'+str(count)+'_FIRST',p);row=json.loads(p.stdout);consecutive=consecutive+[row]if row['clean']else[]
  (F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='WAITING_ORIGINAL_CAPACITY_FOR_PRE_SDK_INVOCATION_FIX',resource=row),indent=2)+'\n')
  if len(consecutive)>=2:break
  time.sleep(60)
 else:raise TimeoutError('Finite invocation-fix wait expired')
 (F/'FIX_RESOURCE_TWO_SAMPLE_FIRST.json').write_text(json.dumps(consecutive,indent=2)+'\n');keep('FIX_BEFORE_SENSOR_SERIAL_FIRST',remote(guard))
 (F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='RUNNING_FROZEN_SENSOR_PROBE_ORIGINAL_LABEL',native_rounds=0),indent=2)+'\n')
 keep('FIX_SENSOR_INVOCATION_FIRST',subprocess.run(ssh+[R+'/.venv/bin/python',D+'/run_sdk_captured.py',D+'/check_sdk_sector_fixture.py','SENSOR_SECTOR_FIRST'],capture_output=True));fetch('SENSOR_SECTOR_FIRST.json')
 c=json.loads((F/'SENSOR_SECTOR_FIRST.json').read_text());report={k:v for k,v in c.items()if k!='rows'};report.update(source_sha256=pre['source_sha256'],reference_sha256=pre['reference_sha256'],initial_wrapper_error_preserved=True)
 (F/'RESULT_FIRST.json').write_text(json.dumps(report,indent=2)+'\n');(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status=c['status'],native_rounds=0),indent=2)+'\n');print(json.dumps(report),flush=True)
if __name__=='__main__':
 try:main()
 except Exception:
  import traceback
  (F/'INVOCATION_FIX_ERROR_FIRST.json').write_text(json.dumps(dict(utc=utc(),traceback=traceback.format_exc()),indent=2)+'\n');raise
