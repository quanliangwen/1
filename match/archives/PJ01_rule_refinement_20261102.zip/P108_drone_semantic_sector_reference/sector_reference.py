"""Reference-only association uncertainty; never clears historical map votes.

The widened window is one gap of the frozen35-ray semantic sensor, not an
object radius or a proof all matching depth returns belong to that object.
"""
import math
import numpy as np
def sector_mask(distances,angles,semantic,kinds=('DRONE','DISPOSAL_CENTER','BOMB'),semantic_resolution=35):
 mask=np.zeros(len(distances),dtype=bool)
 for obj in semantic or ():
  kind=getattr(getattr(obj,'entity_type',None),'name','')
  if kind not in kinds:continue
  gap=2*math.pi/(semantic_resolution-1)if kind=='DRONE'else .10
  diff=np.abs((angles-float(obj.angle)+math.pi)%(2*math.pi)-math.pi)
  mask|=(diff<gap)&(np.abs(distances-float(obj.distance))<24)
 return mask
