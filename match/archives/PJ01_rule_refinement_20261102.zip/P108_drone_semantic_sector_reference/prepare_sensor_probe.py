from pathlib import Path
import ast,json,hashlib,datetime
F=Path(__file__).resolve().parent;P=F.parent/'P107_blocking_evidence_provenance';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not(F/'PREDECLARATION_FIRST.json').exists();meta=json.loads((F.parent/'P91_known_graph_tail_reference/WORKSPACE_READY.json').read_text());(F/'WORKSPACE_READY.json').write_text(json.dumps(meta,indent=2)+'\n')
pre=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=sha(F/'check_sdk_sector_fixture.py'),reference_sha256=sha(F/'sector_reference.py'),retained_check_sha256=sha(F/'RETAINED_SECTOR_REFERENCE_FIRST.json'),layouts=['peer_near','peer_middle','peer_far','peer_beside_wall','wall_without_peer'],frames_each=4,author_seed=615,protocol='Public observations freeze, then author-only rendered hit UID labels evaluate both masks on same arrays. Mask does not feed any controller; author applies fixed zero actions, no control calls. Source frozen, originalSDK/41pins/limits/threads,2resource samples60sec/single lock.',gate='No new full mission candidate if even one additionally excluded usable ray is a labeled true wall in these layouts. No-peer exact equality/health50/stock2/official callbacks required. Extra dynamic returns must be observed; passes still do not prove general safety.',controller_changes=False,native_rounds=0,automatic_five=False)
(F/'PREDECLARATION_FIRST.json').write_text(json.dumps(pre,indent=2)+'\n')
s=(P/'run_provenance.py').read_text().replace('P107_blocking_evidence_provenance','P108_drone_semantic_sector_reference').replace('check_sdk_hit_provenance.py','check_sdk_sector_fixture.py')
s=s.replace("assert sha(F/'check_sdk_sector_fixture.py')==pre['source_sha256']","assert sha(F/'check_sdk_sector_fixture.py')==pre['source_sha256']and sha(F/'sector_reference.py')==pre['reference_sha256']")
s=s.replace("['check_sdk_sector_fixture.py','WORKSPACE_READY.json','PREDECLARATION_FIRST.json']","['check_sdk_sector_fixture.py','sector_reference.py','WORKSPACE_READY.json','PREDECLARATION_FIRST.json']")
start=s.index(" (F/'RESOURCE_TWO_SAMPLE_FIRST.json')");end=s.index("if __name__=='__main__':",start)
new=''' (F/'RESOURCE_TWO_SAMPLE_FIRST.json').write_text(json.dumps(consecutive,indent=2)+'\\n');keep('BEFORE_SENSOR_SERIAL_FIRST',remote(guard))
 (F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='RUNNING_FIVE_SENSOR_LAYOUTS',native_rounds=0),indent=2)+'\\n')
 keep('SENSOR_SECTOR_FIRST',subprocess.run(ssh+[R+'/.venv/bin/python',D+'/run_sdk_captured.py',D+'/check_sdk_sector_fixture.py'],capture_output=True));fetch('SENSOR_SECTOR_FIRST.json')
 c=json.loads((F/'SENSOR_SECTOR_FIRST.json').read_text());report={k:v for k,v in c.items()if k!='rows'};report['source_sha256']=pre['source_sha256'];report['reference_sha256']=pre['reference_sha256']
 (F/'RESULT_FIRST.json').write_text(json.dumps(report,indent=2)+'\\n');(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status=c['status'],native_rounds=0),indent=2)+'\\n');print(json.dumps(report),flush=True)
'''
s=s[:start]+new+s[end:];ast.parse(s);(F/'run_sensor_probe.py').write_text(s);print('Five-layout reference sensor probe frozen; zero mission/controller modifications')
