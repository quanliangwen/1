from pathlib import Path
from types import SimpleNamespace
import math,json,datetime
import numpy as np
from sector_reference import sector_mask
F=Path(__file__).resolve().parent;dest=F/'OCCLUSION_COUNTEREXAMPLE_FIRST.json';assert not dest.exists()
# Authored analytic disk, not an assertion about SDK DroneBase's sprite hull.
# A wall ends below the semantic ray, while a denser lidar ray hits that wall
# before reaching the nearby disk. Their ranges are still within original24.
center=100*np.array([math.cos(.30),math.sin(.30)]);radius=12.;semantic_angle=2*math.pi/17
direction=np.array([math.cos(semantic_angle),math.sin(semantic_angle)]);projection=float(center@direction);perpendicular2=float(center@center)-projection**2
assert perpendicular2<radius**2
semantic_distance=projection-math.sqrt(radius**2-perpendicular2)
ray_angle=14*math.pi/180;wall_x=70.;wall_ymax=20.;wall_distance=wall_x/math.cos(ray_angle);wall_hit=np.array([wall_x,wall_distance*math.sin(ray_angle)])
assert wall_hit[1]<wall_ymax and wall_x*math.tan(semantic_angle)>wall_ymax
assert np.linalg.norm(center-np.array([wall_x,wall_ymax]))>radius
sem=[SimpleNamespace(entity_type=SimpleNamespace(name='DRONE'),angle=semantic_angle,distance=semantic_distance)]
old=abs(ray_angle-semantic_angle)<.10 and abs(wall_distance-semantic_distance)<24
new=bool(sector_mask(np.array([wall_distance]),np.array([ray_angle]),sem)[0]);assert not old and new
out=dict(status='PROVED_ONE_GAP_MASK_CAN_SUPPRESS_REAL_WALL_RETURN',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),disk_center=center.tolist(),analytic_disk_radius=radius,semantic=dict(angle=semantic_angle,distance=semantic_distance),wall=dict(x=wall_x,ymax=wall_ymax),lidar=dict(angle=ray_angle,distance=wall_distance,hit=wall_hit.tolist()),original_mask_excluded=old,one_gap_mask_excluded=new,range_difference=abs(wall_distance-semantic_distance),production_candidate_allowed=False,SDK_frames=0,native_rounds=0,limitation='Constructed 2D occlusion counterexample, not SDK geometry or competition evidence. It disproves a semantic angular gap as sufficient identity proof. Existing finite sensor probes may still pass and do not override this counterexample.')
dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
