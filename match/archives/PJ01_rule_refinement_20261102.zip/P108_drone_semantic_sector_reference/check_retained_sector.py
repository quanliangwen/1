from pathlib import Path
from types import SimpleNamespace
import ast,json,hashlib,math,datetime
import numpy as np
from sector_reference import sector_mask
F=Path(__file__).resolve().parent;P=F.parent/'P107_blocking_evidence_provenance';dest=F/'RETAINED_SECTOR_REFERENCE_FIRST.json';assert not dest.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
src=Path('E:/codex/PJ01_rule_refinement_20261101/P48_P35_refresh_deferral_candidate/candidate_project/src/swarm_rescue/solutions/greedy_mapping.py');tree=ast.parse(src.read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name=='MapMemory');node=next(n for n in cls.body if isinstance(n,ast.FunctionDef)and n.name=='semantic_mask');node.decorator_list=[];env=dict(np=np,math=math);exec(compile(ast.Module(body=[node],type_ignores=[]),str(src),'exec'),env);original=env['semantic_mask']
read=lambda n:json.loads((P/n).read_text());assert all(read('RESULT_FIRST.json')['identity_checks'].values());d=read('SAME_FAILED_PROVENANCE64_FIRST.json');rows=[]
for e in d['raw_observations']:
 sem=[SimpleNamespace(entity_type=SimpleNamespace(name=o['kind']),angle=o['angle'],distance=o['distance'])for o in e['semantic']];a=np.asarray(e['angles']);ranges=np.asarray(e['distances']);before=ranges.copy(),a.copy();old=original(ranges,a,sem);new=sector_mask(ranges,a,sem)
 assert not np.any(old&~new)and np.array_equal(ranges,before[0])and np.array_equal(a,before[1])
 rawids=[]
 if e['owner']==2 and e['step']in [56,60]:
  theta=a+e['heading'];ends=np.asarray(e['position'])+np.column_stack((np.cos(theta),np.sin(theta)))*ranges[:,None];rr=np.floor((300-ends[:,1])/2).astype(int);cc=np.floor((ends[:,0]+400)/2).astype(int)
  ids=np.flatnonzero((rr==172)&(cc==162)&(ranges>8)&(ranges<220))
  rawids=[dict(ray=int(i),distance=float(ranges[i]),angle=float(a[i]),old_excluded=bool(old[i]),new_excluded=bool(new[i]))for i in ids]
 rows.append(dict(owner=e['owner'],step=e['step'],old_excluded=int(old.sum()),new_excluded=int(new.sum()),new_ambiguous_static_candidates=int(np.count_nonzero(new&~old&(ranges>8)&(ranges<220))),blocking_cell_rays=rawids))
checks={}
angles=np.array([-.18,-.125,-.05,0.,.05,.125,.18,.21]);ranges=np.ones(8)*100
for kind in ['BOMB','DISPOSAL_CENTER','WALL','OTHER']:
 sem=[SimpleNamespace(entity_type=SimpleNamespace(name=kind),angle=0.,distance=100.)];checks[kind+'_unchanged']=bool(np.array_equal(original(ranges,angles,sem),sector_mask(ranges,angles,sem)))
checks['empty_same']=bool(np.array_equal(original(ranges,angles,[]),sector_mask(ranges,angles,[])))
sem=[SimpleNamespace(entity_type=SimpleNamespace(name='DRONE'),angle=0.,distance=70.)];checks['depth_mismatch_stays_unmasked']=bool(not sector_mask(ranges,angles,sem).any())
sem=[SimpleNamespace(entity_type=SimpleNamespace(name='DRONE'),angle=math.pi-.02,distance=100.)];checks['wrap_handled']=bool(sector_mask(np.array([100.]),np.array([-math.pi+.02]),sem)[0])
assert all(checks.values())
out=dict(status='PASS_RETAINED_SECTOR_MECHANISM_NOT_WALL_SAFETY',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),reference_source_sha256=sha(F/'sector_reference.py'),original_mask_source_sha256=sha(src),retained_input_sha256=sha(P/'SAME_FAILED_PROVENANCE64_FIRST.json'),checks=checks,rows=rows,blocking_ray_checks=[r for r in rows if r['blocking_cell_rays']],new_candidates_total=sum(r['new_ambiguous_static_candidates']for r in rows),SDK_frames=0,native_rounds=0,limitation='Only association sensitivity on identical public retained streams. No true-wall labels here; one semantic gap can also suppress nearby real walls. Must run independent sensor fixture before any production candidate.')
dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k]for k in ['status','checks','blocking_ray_checks','new_candidates_total']}))
