from pathlib import Path
import ast,json,hashlib,shutil,datetime
F=Path(__file__).resolve().parent;B=Path('E:/codex/PJ01_rule_refinement_20261101/P48_P35_refresh_deferral_candidate');P=B/'candidate_project';C=F/'candidate_project';assert not C.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((B/'CANDIDATE_MANIFEST_FIRST.json').read_text());assert all(sha(P/n)==h for n,h in old['candidate_files'].items())
shutil.copytree(P,C,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git'))
file=C/'src/swarm_rescue/solutions/exploration_phase.py';s=file.read_text();needle='    phase=(period*identifier)//team_size';assert s.count(needle)==1
new='''    # Original sensing/pose correction writes own observations every4steps.
    # Quantize optional early phases to these ticks when distinct slots fit.
    # Normal24step due still wins and never waits for a sensing barrier.
    if period%4==0 and team_size<=period//4:
        phase=4*((period*identifier)//(4*team_size))
    else:
        phase=(period*identifier)//team_size'''
s=s.replace(needle,new);ast.parse(s);file.write_text(s)
source=P/'src/swarm_rescue/solutions/greedy_mapping.py';tree=ast.parse(source.read_text());control=next(n for n in next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name=='GreedyMappingDrone').body if isinstance(n,ast.FunctionDef)and n.name=='control');text=ast.get_source_segment(source.read_text(),control)
assert 'step % 4 == 0' in text and 'self.memory.observe' in text
files={p.relative_to(C).as_posix():sha(p)for p in C.rglob('*')if p.is_file()};diff=[n for n in sorted(set(files)|set(old['candidate_files']))if files.get(n)!=old['candidate_files'].get(n)];assert diff==['src/swarm_rescue/solutions/exploration_phase.py']
out=dict(status='SOURCE_FROZEN_SINGLE_PHASE_RULE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent=str(P),parent_files=old['candidate_files'],candidate_files=files,differences=diff,rule='Optional ordinary-exploration early phases quantized to existing own4step sensing cadence when distinct slots fit. Original due predicate/scope/task chain unchanged; no blocking wait, no map/motion/placement modification.',n5_parent_phases=[0,4,9,14,19],n5_candidate_phases=[0,4,8,12,16],cadence_source_sha256=sha(source),not_stacked=['P100 optional surface views','P96 hit filtering','P94 final exchange','P85 fragments','P43 local-only task dispatch'],req_unchanged=(C/'req.txt').read_bytes()==(P/'req.txt').read_bytes(),official_submission=False,native_rounds=0)
(F/'CANDIDATE_MANIFEST_FIRST.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status=out['status'],differences=diff,phases=out['n5_candidate_phases'])))
