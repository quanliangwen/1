"""Timeline/regime tests against frozen original phase function, no body simulation."""
from pathlib import Path
import importlib.util,json,hashlib
F=Path(__file__).resolve().parent;dest=F/'PHASE_CONTRACTS_FIRST.json';assert not dest.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
decl=json.loads((F/'CANDIDATE_MANIFEST_FIRST.json').read_text());P=Path(decl['parent']);C=F/'candidate_project';relative='src/swarm_rescue/solutions/exploration_phase.py'
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
old=load('old_phase',P/relative);new=load('new_phase',C/relative);checks=[];timelines=[]
for owner in range(5):
    parent_times=[];child_times=[];lastp=lastc=1
    for step in range(2,121):
        if old.exploration_route_due(step,lastp,owner,5,ordinary_exploration=True):parent_times.append(step);lastp=step
        if new.exploration_route_due(step,lastc,owner,5,ordinary_exploration=True):child_times.append(step);lastc=step
    assert all(t%4==0 for t in child_times);assert all(y-x==24 for x,y in zip(child_times,child_times[1:]));assert len(child_times)==len(parent_times)
    timelines.append(dict(owner=owner,old=parent_times,new=child_times,own_scan_age_old=[t%4 for t in parent_times],own_scan_age_new=[t%4 for t in child_times]))
checks.append('five independent regular timelines keep call count/24period, all optional phases on own observation ticks')
for period in [24,25,28]:
 for team in [1,2,3,4,5,6,7,12]:
  if team>period:continue
  for owner in range(team):
   for last in [-1,0,1,7,23,32]:
    for step in [last,last+1,last+period-1,last+period,last+period+1]:
     value=new.exploration_route_due(step,last,owner,team,ordinary_exploration=True,period=period)
     if step-last>=period:assert value
     assert new.exploration_route_due(step,last,owner,team,ordinary_exploration=False,period=period)==old.exploration_route_due(step,last,owner,team,ordinary_exploration=False,period=period)
     if period%4!=0 or team>period//4:assert value==old.exploration_route_due(step,last,owner,team,ordinary_exploration=True,period=period)
checks.append('original deadline due and all excluded regimes unchanged; unsupported unique sensing slots fall back exactly')
for owner in [0,1]:assert timelines[owner]['old']==timelines[owner]['new']
checks.append('five-agent owner0/1 early cadence unchanged, others advance1/2/3steps')
assert sha(C/'req.txt')==sha(P/'req.txt');checks.append('dependencies unchanged')
out=dict(status='PASS_PHASE_TIMELINE_REGIMES',checks=checks,timelines=timelines,candidate_source_sha256=sha(C/relative),physical_frames=0,native_rounds=0,limitations=['A changed timestamp is not evidence of map improvement.','Received peer maps may update every frame; own-scan alignment does not prove whole belief globally freshest.','Does not exclude extra whole mission-chain side effects already present in P35; P43 local-only branch not stacked.'])
dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
