from pathlib import Path
import json,hashlib,datetime,ast,math,sys
from types import SimpleNamespace
import numpy as np
from confidence_reference import update_counts
F=Path(__file__).resolve().parent;D=F.parent/'P108_drone_semantic_sector_reference';sys.path.insert(0,str(D));from sector_reference import sector_mask
dest=F/'CONFIDENCE_REFERENCE_FIRST.json';assert not dest.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cases=[]
def keep(name,old,clear,weak,expected):
 a=np.asarray(old,np.uint8);b=np.asarray(clear,int);c=np.asarray(weak,int);copies=a.copy(),b.copy(),c.copy();actual=update_counts(a,b,c)
 ok=actual.tolist()==expected and all(np.array_equal(x,y)for x,y in zip([a,b,c],copies));cases.append(dict(name=name,pass_check=ok,actual=actual.tolist(),expected=expected))
keep('two_ambiguous_rays_not_stable',[0],[0],[2],[1])
keep('repeated_ambiguous_not_stable',[1],[0],[7],[1])
keep('historical_stable_wall_not_erased',[2,8,32],[0,0,0],[5,4,6],[2,8,32])
keep('ordinary_two_clear_original_rule',[0],[2],[0],[2])
keep('ordinary_counts_saturate32',[31],[5],[0],[32])
keep('one_clear_one_weak_same_scan_not_two',[0],[1],[1],[1])
keep('later_clear_observation_can_confirm',[1],[1],[0],[2])
keep('empty_observation_identity',[0,1,2,32],[0,0,0,0],[0,0,0,0],[0,1,2,32])
keep('clear_only_same_as_parent',[0,1,7,31],[1,2,3,9],[0,0,0,0],[1,3,10,32])
# Exactly the observed source's own ray stream, not a counterfactual fleet
# replay: incoming packets would differ if weak cells were not published.
P=F.parent/'P107_blocking_evidence_provenance';d=json.loads((P/'SAME_FAILED_PROVENANCE64_FIRST.json').read_text());value=0;events=[];cell=68962
for r in d['raw_observations']:
 if r['owner']!=2:continue
 distances=np.asarray(r['distances']);angles=np.asarray(r['angles']);theta=angles+r['heading'];ends=np.asarray(r['position'])+np.column_stack((np.cos(theta),np.sin(theta)))*distances[:,None];rr=np.floor((300-ends[:,1])/2).astype(int);cc=np.floor((400+ends[:,0])/2).astype(int)
 original=np.asarray(r['excluded'],bool);sem=[SimpleNamespace(entity_type=SimpleNamespace(name=x['kind']),angle=x['angle'],distance=x['distance'])for x in r['semantic']];expanded=sector_mask(distances,angles,sem);accepted=np.isfinite(distances)&(distances>8)&(distances<220)&~original&(rr*400+cc==cell)
 clear=int(np.count_nonzero(accepted&~expanded));weak=int(np.count_nonzero(accepted&expanded))
 if clear or weak:
  prior=value;value=int(update_counts([value],[clear],[weak])[0]);events.append(dict(step=r['step'],before=prior,clear=clear,ambiguous=weak,after=value))
assert value==1 and [e['step']for e in events]==[56,60]
cases.append(dict(name='actual_source_point_stays_weak_without_gossip_simulation',pass_check=True,events=events,final=value,original_actual_final=2))
assert all(r['pass_check']for r in cases)
out=dict(status='PASS_PURE_AMBIGUITY_CONFIDENCE_REFERENCE_NOT_CONTROLLER',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cases=cases,reference_sha256=sha(F/'confidence_reference.py'),sector_reference_sha256=sha(D/'sector_reference.py'),source_input_sha256=sha(P/'SAME_FAILED_PROVENANCE64_FIRST.json'),production_candidate=False,SDK_frames=0,native_rounds=0,limits=['One clear later vote plus one weak earlier point can reach original threshold2; not a statistical independence proof.','A real wall seen only inside the ambiguous DRONE sector can remain at count1 until an unambiguous observation. This is a real tradeoff, not a zero-loss guarantee.','No original packet replay is used as if unchanged: cap1 would alter what is broadcast, then routes and future sensors. Must test an actual independent full mission candidate if integrated.','No old hit deletion, expanded hard mask, clearance lowering, path event, goal/timer change or new controller is implemented here.'])
dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status=out['status'],cases=len(cases),source_point_events=events)))
