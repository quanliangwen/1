"""Pure per-cell update reference, not yet a production controller.

Ordinary accepted rays keep original vote counts. Returns that are outside
the original semantic mask but inside one coarse DRONE sector are weak:
they can mark an unobserved cell once but cannot alone raise its count.
Existing evidence is never erased. No history, new dependency or gossip.
"""
import numpy as np
def update_counts(old_values,clear_counts,ambiguous_counts):
 old=np.asarray(old_values);clear=np.asarray(clear_counts);weak=np.asarray(ambiguous_counts)
 if old.shape!=clear.shape or old.shape!=weak.shape:raise ValueError('Mismatched cell counts')
 if np.any(clear<0)or np.any(weak<0):raise ValueError('Negative observations')
 result=np.minimum(32,old.astype(np.int64)+clear.astype(np.int64))
 result=np.maximum(result,(weak>0).astype(np.int64))
 return result.astype(np.uint8)
