"""Fixed retained author states only; zero SDK/physics/controller imports."""
from pathlib import Path
import importlib.util,sys,json,hashlib,copy,time,datetime
import numpy as np
import cv2
F=Path(__file__).resolve().parent
dest=F/'FRAME_RECORD_ABLATION_FIRST.json';assert not dest.exists()
identity=json.loads((F/'RESULT_FIRST.json').read_text());assert all(identity['checks'].values())
meta=json.loads((F/'WORKSPACE_READY.json').read_text());source=Path(meta['versions']['P112']['workspace'])/'src/swarm_rescue/solutions/rectangular_boundary.py'
assert hashlib.sha256(source.read_bytes()).hexdigest()==meta['versions']['P112']['sources']['src/swarm_rescue/solutions/rectangular_boundary.py']
spec=importlib.util.spec_from_file_location('retained_frame_reference',source);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
truth_source=F/'SAME_FAILED_RENDER_TIMELINE_FIRST.json';timeline=json.loads(truth_source.read_text())['render_timeline']
def records(s):return{(int(r[0]),int(r[1])):r for r in s['frame_records']}
def evaluate(s,positive,base):
 groups={}
 for source,step,lines,origin,endpoints,*_ in positive.values():groups[(source,step)]=[source,step,lines,origin,list(endpoints)]
 for _,entries in s['frame_negative']:
  for _,source,step,origin,endpoint in entries:
   r=groups.setdefault((source,step),[source,step,[],origin,[]]);r[4].append(endpoint)
 model=module.RectangularBoundaryInference(s['width'],s['height'],world_axis_prior=True,plane_coordinate_guard=10,plane_mad_limit=3.5,maximum_line_angle_deg=2,maximum_line_normal_spread=8)
 model.ingest_batch(groups.values());image=model.render(base)
 return image,dict(diagnostics=model.diagnostics(),input_positive_records=len(positive),model_lines=len(model.lines),ray_blocks=len(model.ray_blocks),sha256=hashlib.sha256(image.tobytes()).hexdigest(),pixels=int(np.count_nonzero(image)))
rows=[];start=time.perf_counter()
for owner in [0,1]:
 old=json.loads((F/('AUTHOR_OWN_'+str(owner)+'_STEP_300.json')).read_text());last=json.loads((F/('AUTHOR_OWN_'+str(owner)+'_STEP_556.json')).read_text())
 base=(cv2.imread(str(F/('AUTHOR_OWN_'+str(owner)+'_STEP_556_short_support.png')),0)>0).astype(np.uint8)
 a,b=records(old),records(last);old_missing=a.keys()-b.keys();baseline,info=evaluate(last,b,base)
 expected=next(e for e in timeline if e['owner']==owner and e['step']==556)['layers']['frame']['sha256']
 assert info['sha256']==expected,'Frozen production frame baseline mismatch'
 variants=dict(original=info)
 for name,with_endpoints in [('restore_old_positive_only',False),('restore_old_positive_and_original_rays',True)]:
  restored=copy.deepcopy(b)
  for key in sorted(old_missing):
   r=copy.deepcopy(a[key])
   if not with_endpoints:r[4]=[]
   restored[key]=r
  image,details=evaluate(last,restored,base)
  details['added_pixels_from_original']=int(np.count_nonzero((image>0)&(baseline==0)))
  details['removed_pixels_from_original']=int(np.count_nonzero((image==0)&(baseline>0)))
  filename='OWNER_'+str(owner)+'_'+name+'.png';assert cv2.imwrite(str(F/filename),image*255);details['image_file']=filename;variants[name]=details
 rows.append(dict(owner=owner,original_snapshot300_sha256=hashlib.sha256((F/('AUTHOR_OWN_'+str(owner)+'_STEP_300.json')).read_bytes()).hexdigest(),final_snapshot556_sha256=hashlib.sha256((F/('AUTHOR_OWN_'+str(owner)+'_STEP_556.json')).read_bytes()).hexdigest(),missing_records=len(old_missing),current_negative_evidence_unchanged=True,current_raw_base_unchanged=True,variants=variants))
out=dict(status='COMPLETE_FIXED_EVIDENCE_FRAME_RECORD_ABLATION',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),rows=rows,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),SDK_imports=0,SDK_frames=0,native_rounds=0,numeric_seconds=time.perf_counter()-start,limits=['Same final raw arrays and complete final negative evidence, only positive record set changed.','Uses all missing300 records as a diagnostic intervention, not a bounded retention rule or production controller.','No truth scored or selected in this check. Restored-frame acceptance alone does not establish general map accuracy.'])
dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
