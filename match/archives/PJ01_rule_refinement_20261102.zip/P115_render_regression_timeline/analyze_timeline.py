from pathlib import Path
import json,hashlib,datetime
F=Path(__file__).resolve().parent
assert not(F/'LAYER_TIMELINE_REVIEW_FIRST.json').exists()
identity=json.loads((F/'RESULT_FIRST.json').read_text());assert all(identity['checks'].values())
p=json.loads((F/'PREDECLARATION_FIRST.json').read_text())
source=F/(p['label']+'.json');d=json.loads(source.read_text())
rows=[];deltas=[]
for owner in p['owners']:
 selected=sorted((e for e in d['render_timeline']if e['owner']==owner),key=lambda e:e['step'])
 for e in selected:
  row=dict(owner=owner,step=e['step'],inventory=e['inventory'],frame_accepted=e['frame_diagnostics'].get('accepted'),frame_reason=e['frame_diagnostics'].get('reason'),frame_records=e['frame_record_count'],nonwall_cells=e['nonwall_pixels'],stable_raw_cells=e['stable_raw_cells'],scores={k:v['map_score']for k,v in e['layers'].items()},credits={k:v['breakdown']['credit']for k,v in e['layers'].items()},penalties={k:v['breakdown']['penalty']for k,v in e['layers'].items()})
  rows.append(row)
 first=next(e for e in selected if e['step']==300);last=selected[-1]
 a=json.loads((F/first['snapshot_file']).read_text());b=json.loads((F/last['snapshot_file']).read_text())
 def values(s,key):
  field=s.get(key);return{}if field is None else dict(zip(field['ids'],field['values']))
 hits_a,hits_b=values(a,'hits'),values(b,'hits');stable_a={k for k,v in hits_a.items()if v>=2}
 keys_a=set(map(tuple,first['frame_keys']));keys_b=set(map(tuple,last['frame_keys']))
 deltas.append(dict(owner=owner,interval=[first['step'],last['step']],map_score_deltas={k:last['layers'][k]['map_score']-first['layers'][k]['map_score']for k in first['layers']},credit_deltas_pp={k:100*(last['layers'][k]['breakdown']['credit']-first['layers'][k]['breakdown']['credit'])for k in first['layers']},penalty_deltas_pp={k:100*(last['layers'][k]['breakdown']['penalty']-first['layers'][k]['breakdown']['penalty'])for k in first['layers']},original_positive_raw_cells=len(hits_a),original_stable_raw_cells=len(stable_a),original_positive_now_zero=sum(hits_b.get(k,0)==0 for k in hits_a),original_stable_now_unstable=sum(hits_b.get(k,0)<2 for k in stable_a),new_positive_raw_cells=len(hits_b.keys()-hits_a.keys()),discarded_frame_records=len(keys_a-keys_b),retained_old_frame_records=len(keys_a&keys_b),added_frame_records=len(keys_b-keys_a)))
out=dict(status='COMPLETE_IDENTITY_QUALIFIED_RENDER_TIMELINE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),rows=rows,deltas=deltas,SDK_frames_added=0,native_rounds=0,limits=['Checkpoints diagnose this retained failed trajectory, not five-map performance or causal effect of a future patch.','Frame record loss is causal only if fixed-evidence reconstruction isolates it; count alone is not proof.','Truth used for authored post-freeze evaluation only; never choose maps or rules from true coordinates.'])
(F/'LAYER_TIMELINE_REVIEW_FIRST.json').write_text(json.dumps(out,indent=2)+'\n')
for row in rows:print(json.dumps(row,ensure_ascii=False))
print(json.dumps(dict(deltas=deltas)))
