from pathlib import Path
import ast, subprocess, json, time, datetime, hashlib
F=Path(__file__).resolve().parent
R='/home/junhao/quan/parallel_test_solver/match'
H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025'
D=H+'/PJ01_rules_P115_render_regression_timeline_20261102'
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def remote(code):return subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=code.encode(),capture_output=True)
def keep(name,p):
 out=F/(name+'.capture.txt');assert not out.exists();out.write_bytes(p.stdout+p.stderr)
 print(p.stdout.decode(errors='replace')[-1200:],flush=True)
 if p.returncode:raise RuntimeError('Preserve first timeline error: '+name)
def fetch(name):
 assert '/' not in name and '\\' not in name
 subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+name,str(F/name)],check=True)
def main():
 assert not(F/'STARTED_FIRST.json').exists()
 pre=json.loads((F/'PREDECLARATION_FIRST.json').read_text())
 assert sha(F/'check_same_failed_timeline.py')==pre['source_sha256']
 for key in ['failed_input','prefix_input']:assert sha(Path(pre[key]))==pre[key+'_sha256']
 guard=Path('E:/codex/UAV_rules_astar_restart_20261030/R154_scoped_serial_guard_20261101/check_scoped_serial.py').read_text()
 keep('SERIAL_FIRST',remote(guard))
 keep('MKDIR_FIRST',remote('from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n'))
 (F/'STARTED_FIRST.json').write_text(json.dumps(dict(utc=utc(),finite_hours=14,readonly=True,native_rounds=0),indent=2)+'\n')
 for name in ['check_same_failed_timeline.py','WORKSPACE_READY.json','PREDECLARATION_FIRST.json']:
  subprocess.run(['scp','-q',str(F/name),'junhao@10.112.162.60:'+D+'/'],check=True)
 subprocess.run(['scp','-q','E:/codex/UAV_rules_astar_restart_20261030/run_sdk_captured.py','junhao@10.112.162.60:'+D+'/'],check=True)
 old=Path('E:/codex/PJ01_environment_restore_20261101/P35_continuation_after_parent_repair/run_offline.py').read_text()
 methods='\n'.join(ast.get_source_segment(old,n)for n in ast.parse(old).body if isinstance(n,ast.FunctionDef)and n.name in ['cpu_sample','resource'])
 capacity='from pathlib import Path\nimport os,time,shutil,json,datetime\nR=Path('+repr(R)+')\nD=json.loads((R/"solver_study/framework_screen_20261016/best87_independent_20261025/P37_phase_five_comparison_20261101/PREDECLARATION.json").read_text())\ndef utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()\n'+methods+'\nprint(json.dumps(resource()))\n'
 end=time.monotonic()+14*3600;consecutive=[];count=0
 while time.monotonic()<end:
  if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop')
  count+=1;p=remote(capacity);keep('CAPACITY_'+str(count)+'_FIRST',p);row=json.loads(p.stdout)
  consecutive=consecutive+[row]if row['clean']else[]
  (F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='WAITING_ORIGINAL_CAPACITY',resource=row),indent=2)+'\n')
  if len(consecutive)>=2:break
  time.sleep(60)
 else:raise TimeoutError('Finite timeline wait expired')
 (F/'RESOURCE_TWO_SAMPLE_FIRST.json').write_text(json.dumps(consecutive,indent=2)+'\n')
 keep('BEFORE_TIMELINE_SERIAL_FIRST',remote(guard));label=pre['label']
 (F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='RUNNING_SAME_FAILED556_PASSIVE_TIMELINE',native_rounds=0),indent=2)+'\n')
 keep(label,subprocess.run(ssh+[R+'/.venv/bin/python',D+'/run_sdk_captured.py',D+'/check_same_failed_timeline.py',label,'P112',pre['case'],str(pre['horizon']),str(pre['wall_rate'])],capture_output=True))
 fetch(label+'.json');c=json.loads((F/(label+'.json')).read_text())
 p=json.loads(Path(pre['failed_input']).read_text());prefix=json.loads(Path(pre['prefix_input']).read_text())
 def clean_cov(a):return{k:v for k,v in a.items()if k!='score_eval_seconds'}
 def clean_submit(a):return[{k:v for k,v in e.items()if k!='output_seconds'}for e in a]
 checks=dict(rows_identical=c['rows']==p['rows'],projection_events_identical=c['projection_events']==p['projection_events'],production_source_identical=c['source_sha256']==p['source_sha256'],expected556=c['physics_steps']==pre['expected_frames'],all5_final_raw_maps_identical=c['map_results']==p['map_results'],actual_submission_identical=clean_submit(c['submission_records'])==clean_submit(p['submission_records']),actual_wall_placements_scores_identical=clean_cov(c['coverage_evaluation'])==clean_cov(p['coverage_evaluation']),all_original_health_completion_checks=all(c['checks'].values()),twelve_checkpoints=len(c['render_timeline'])==len(pre['owners'])*len(pre['checkpoints']))
 for e in c['render_timeline']:
  owner=e['owner'];step=e['step'];final=e['layers']['final']
  if step==300:
   reference=prefix['map_results'][owner]
   checks['owner'+str(owner)+'_300_score_exact']=final['map_score']==reference['score']and final['breakdown']==reference['breakdown']
  if step==556:
   reference=p['map_results'][owner]
   checks['owner'+str(owner)+'_556_score_exact']=final['map_score']==reference['score']and final['breakdown']==reference['breakdown']
   if owner==p['submission_records'][0]['owner']:checks['submitted_final_snapshot_sha_exact']=final['sha256']==p['submission_records'][0]['output_sha256']
  fetch(e['snapshot_file']);assert sha(F/e['snapshot_file'])==e['snapshot_sha256']
  json.loads((F/e['snapshot_file']).read_text())
  for name in e['layers']:fetch('AUTHOR_OWN_'+str(owner)+'_STEP_'+str(step)+'_'+name+'.png')
 result=dict(status='PASS_SAME_FAILED_TIMELINE_IDENTITY'if all(checks.values())else'STOP_IDENTITY_OR_RECONSTRUCTION_MISMATCH',utc=utc(),checks=checks,SDK_frames_added=556,native_rounds=0,not_new_strategy=True,source_sha256=pre['source_sha256'])
 (F/'RESULT_FIRST.json').write_text(json.dumps(result,indent=2)+'\n')
 (F/'STATUS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
 if not all(checks.values()):raise RuntimeError('Readonly timeline mismatch; preserve first and do not interpret layers')
if __name__=='__main__':
 try:main()
 except Exception:
  import traceback
  (F/'FIRST_ERROR.json').write_text(json.dumps(dict(utc=utc(),traceback=traceback.format_exc(),no_retry=True),indent=2)+'\n');raise
