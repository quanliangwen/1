from pathlib import Path
import ast,json,hashlib,datetime
F=Path(__file__).resolve().parent;P=F.parent/'P113_P112_actual_coverage_validation';S=F.parent/'P114_grid_scope_coupling_diagnosis';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert not(F/'PREDECLARATION_FIRST.json').exists()
diag=json.loads((S/'SCOPE_CAUSE_REVIEW_FIRST.json').read_text());assert diag['acquisition_boolean_events_identical']and diag['first_ready_events_identical']
partial=json.loads((S/'SAME_FAILED_GRID_PREFIX300_FIRST.json').read_text());full=json.loads((P/'CROSS_P112_ACTUAL_COVERAGE_FIRST.json').read_text());assert partial['rows']==full['rows'][:300]
assert partial['map_results'][0]['score']>full['map_results'][0]['score']+10
s=(P/'check_sdk_actual_coverage.py').read_text();s=s.replace(s.splitlines()[0],'"""Passive same-failed-P112 full trajectory with own-belief checkpoints. Render/scoring only after all controls freeze; no new controller or score retry."""')
s=s.replace('from pathlib import Path\n','from pathlib import Path\nimport copy\n',1)
needle='TRACE_ENABLED=False\n';assert s.count(needle)==1
snap='''TRACE_ENABLED=False
checkpoints={264,300,360,420,480,556};selected_owners={0,1};frozen_checkpoints=[]
def sparse(array):
 a=np.asarray(array);ids=np.flatnonzero(a.ravel());return dict(shape=list(a.shape),dtype=str(a.dtype),ids=ids.tolist(),values=a.ravel()[ids].tolist())
def freeze_own(d):
 m=d.memory;nonwall=getattr(m,'nonwall_mask',None)
 return dict(schema='authored-own-belief-snapshot-v1',owner=int(d.identifier or 0),step=int(d.elapsed_timestep),width=m.width,height=m.height,CELL=m.CELL,FINE=m.FINE,inventory=int(d.carried_bombs_count()),hits=m.hits.copy(),free=m.free.copy(),visits=m.visits.copy(),bearing_bits=m.bearing_bits.copy(),nonwall_mask=None if nonwall is None else nonwall.copy(),frame_records=copy.deepcopy(m.frame_records),frame_negative=copy.deepcopy(m.frame_negative),source_frames=m.bearing_source_frames,merged_packets=m.bearing_merged_packets)
'''
s=s.replace(needle,snap)
needle='   if any(d.submitted for d in drones):break\n';assert s.count(needle)==1
s=s.replace(needle,"   if step in checkpoints:\n    frozen_checkpoints.extend(freeze_own(d)for d in drones if int(d.identifier or 0)in selected_owners)\n"+needle)
needle=" out=dict(status='PASS_AUTHORED_FIVE_BODY_SDK_CLOSURE'if all(checks.values())else'FAIL_KEEP_FIRST_CLOSURE',arm=arm,checks=checks,"
assert s.count(needle)==1
extra=''' # No map reconstructions, truth labels or snapshots enter the controls.
 # All commands/rows/live final outputs above have now been frozen.
 from swarm_rescue.solutions.bearing_memory import BearingMemory
 from swarm_rescue.solutions.anchor_mapping import AnchoredMapMemory
 from swarm_rescue.solutions.frame_mapping import InferredFrameMemory
 from swarm_rescue.solutions.short_wall_support import add_short_wall_support
 timeline=[]
 for snap in frozen_checkpoints:
  mem=BearingMemory(snap['width'],snap['height'],identifier=snap['owner'],team_size=5);mem.step=snap['step']
  for key in ['hits','free','visits','bearing_bits']:setattr(mem,key,snap[key].copy())
  if snap['nonwall_mask']is not None:mem.nonwall_mask=snap['nonwall_mask'].copy()
  mem.frame_records=copy.deepcopy(snap['frame_records']);mem.frame_negative=copy.deepcopy(snap['frame_negative']);mem.bearing_source_frames=snap['source_frames'];mem.bearing_merged_packets=snap['merged_packets']
  anchored=AnchoredMapMemory.render(mem);short=add_short_wall_support(mem,anchored,mode='box_dense',density=2);frame=InferredFrameMemory.render(mem);final=mem.render()
  layer_images=dict(anchored=anchored,short_support=short,frame=frame,final=final);layers={}
  for name,image in layer_images.items():
   result=scorer.score(truth,image,0.);layers[name]=dict(map_score=result.score,breakdown=breakdown_to_dict(result),pixels=int(np.count_nonzero(image)),sha256=hashlib.sha256(image.tobytes()).hexdigest())
   filename='AUTHOR_OWN_'+str(snap['owner'])+'_STEP_'+str(snap['step'])+'_'+name+'.png';assert not(F/filename).exists();assert cv2.imwrite(str(F/filename),(image>0).astype(np.uint8)*255)
  payload={k:v for k,v in snap.items()if k not in ['hits','free','visits','bearing_bits','nonwall_mask','frame_records','frame_negative']}
  for key in ['hits','free','visits','bearing_bits']:payload[key]=sparse(snap[key])
  payload['nonwall_mask']=None if snap['nonwall_mask']is None else sparse(snap['nonwall_mask']);payload['frame_records']=list(snap['frame_records'].values());payload['frame_negative']=[[list(k),v]for k,v in snap['frame_negative'].items()]
  def default(value):
   if isinstance(value,np.ndarray):return value.tolist()
   if isinstance(value,np.generic):return value.item()
   raise TypeError(type(value).__name__)
  filename='AUTHOR_OWN_'+str(snap['owner'])+'_STEP_'+str(snap['step'])+'.json';assert not(F/filename).exists();text=json.dumps(payload,separators=(',',':'),default=default,allow_nan=False);(F/filename).write_text(text+'\\n')
  timeline.append(dict(owner=snap['owner'],step=snap['step'],inventory=snap['inventory'],snapshot_file=filename,snapshot_sha256=hashlib.sha256((F/filename).read_bytes()).hexdigest(),layers=layers,frame_diagnostics=getattr(mem,'frame_diagnostics',{}),frame_record_count=len(mem.frame_records),frame_keys=[list(k)for k in sorted(mem.frame_records)],nonwall_pixels=0 if snap['nonwall_mask']is None else int(snap['nonwall_mask'].sum()),stable_raw_cells=int(np.count_nonzero(snap['hits']>=2))))
'''
s=s.replace(needle,extra+needle).replace('coverage_evaluation=coverage_evaluation,projection_events=projection_events,','render_timeline=timeline,coverage_evaluation=coverage_evaluation,projection_events=projection_events,')
ast.parse(s);(F/'check_same_failed_timeline.py').write_text(s);(F/'WORKSPACE_READY.json').write_bytes((P/'WORKSPACE_READY.json').read_bytes())
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=sha(F/'check_same_failed_timeline.py'),failed_input=str(P/'CROSS_P112_ACTUAL_COVERAGE_FIRST.json'),failed_input_sha256=sha(P/'CROSS_P112_ACTUAL_COVERAGE_FIRST.json'),prefix_input=str(S/'SAME_FAILED_GRID_PREFIX300_FIRST.json'),prefix_input_sha256=sha(S/'SAME_FAILED_GRID_PREFIX300_FIRST.json'),scope_diagnosis_sha256=sha(S/'SCOPE_CAUSE_REVIEW_FIRST.json'),expected_frames=556,label='SAME_FAILED_RENDER_TIMELINE_FIRST',case='cross_sdk',horizon=900,wall_rate=.05,owners=[0,1],checkpoints=[264,300,360,420,480,556],controller_changes=False,native_rounds=0,identity='All original556rows,projection events,production source SHA,actual submitted image/score/wall placements and5rawmaps identical. Reconstructed300layer final image scores equal retained prefix; reconstructed556 final images match live frozen outputs. Stop first mismatch. No score/seed/label rescue.',purpose='Determine layer/time of true map regression already present between300 and556; not assume insufficient exploration or blame initial release. Complete own checkpoint arrays include missing free/visits for later numeric checks, never fed to production.')
(F/'PREDECLARATION_FIRST.json').write_text(json.dumps(out,indent=2)+'\n');print('Own-belief timeline frozen; maps reconstructed only after same failed full controls finish')
