"""Bounded measured-span witnesses, a reference rule; no controller integration."""
import math
import numpy as np

def retained_keys(records,width,height):
    if len(records)<=384:
        return list(records)
    ordered=sorted(records,key=lambda key:key[1],reverse=True)
    recent=set()
    for side in range(4):
        recent.update(key for key in [k for k in ordered if side in records[k][5]][:80])
    spans=[{}for _ in range(4)]
    for key,record in records.items():
        for line in record[2]:
            p=np.asarray(line,float)
            if p.shape!=(2,2)or not np.isfinite(p).all():continue
            vector=p[1]-p[0]
            if np.linalg.norm(vector)<60:continue
            angle=math.atan2(vector[1],vector[0]);folded=(angle+math.pi/4)%(math.pi/2)-math.pi/4
            if abs(folded)>math.radians(2):continue
            axis=0 if abs(vector[1])>abs(vector[0])else 1
            if abs(vector[axis])>8:continue
            plane=float(p[:,axis].mean());extent=width if axis==0 else height
            if abs(abs(plane)-extent/2)>10:continue
            side=axis*2+int(plane>=0);lo,hi=float(p[:,1-axis].min()),float(p[:,1-axis].max())
            old=spans[side].get(key)
            spans[side][key]=(lo,hi)if old is None else(min(lo,old[0]),max(hi,old[1]))
    witness=set()
    for family in spans:
        witness.update(sorted(family,key=lambda k:(family[k][0],-k[1],k[0]))[:3])
        witness.update(sorted(family,key=lambda k:(-family[k][1],-k[1],k[0]))[:3])
    # Keep witnessed extremes at the end for the inherited finite line deque.
    # This does not enlarge that deque or relax its physical acceptance guards.
    return [k for k in ordered if k in recent and k not in witness]+sorted(witness,key=lambda k:(k[1],k[0]))
