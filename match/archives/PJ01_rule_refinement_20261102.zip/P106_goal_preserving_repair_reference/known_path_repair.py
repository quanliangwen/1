"""Bounded directed A* reference. Caller keeps goal/mission clocks unchanged.

No SDK, private state, map edits or fallback target selection. A route is a
finite known-belief graph result, not a continuous collision guarantee.
"""
import math,heapq
def repair_path(allowed,clearance,start,goal,*,max_pops=8192):
 rows,cols=allowed.shape;start=tuple(start);goal=tuple(goal)
 if clearance.shape!=allowed.shape or not isinstance(max_pops,int)or max_pops<=0:
  return dict(status='ABSTAIN_INVALID_INPUT',path=None,pops=0)
 if any(not 0<=p[0]<rows or not 0<=p[1]<cols for p in [start,goal])or not allowed[start]or not allowed[goal]:
  return dict(status='ABSTAIN_ENDPOINT_NOT_WALKABLE',path=None,pops=0)
 def h(p):
  a,b=abs(p[0]-goal[0]),abs(p[1]-goal[1]);return max(a,b)+(math.sqrt(2)-1)*min(a,b)
 best={start:0.};parent={};queue=[(h(start),0.,start)];pops=0
 while queue and pops<max_pops:
  _,g,p=heapq.heappop(queue)
  if g>best[p]:continue
  pops+=1
  if p==goal:
   path=[p]
   while path[-1]!=start:path.append(parent[path[-1]])
   return dict(status='FOUND_SAME_GOAL',path=path[::-1],cost=g,pops=pops)
  for dr,dc in [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]:
   q=(p[0]+dr,p[1]+dc)
   if not(0<=q[0]<rows and 0<=q[1]<cols and allowed[q]):continue
   if dr and dc and not(allowed[p[0]+dr,p[1]]and allowed[p[0],p[1]+dc]):continue
   weight=(math.sqrt(2)if dr and dc else 1.)*(1.+.30*max(0.,(40.-float(clearance[q]))/40.))
   candidate=g+weight
   if candidate<best.get(q,math.inf):
    best[q]=candidate;parent[q]=p;heapq.heappush(queue,(candidate+h(q),candidate,q))
 return dict(status='ABSTAIN_BUDGET'if queue else'ABSTAIN_DISCONNECTED',path=None,pops=pops)
