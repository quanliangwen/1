from pathlib import Path
import json,hashlib,ast,datetime,heapq,math
import numpy as np
from known_path_repair import repair_path
F=Path(__file__).resolve().parent;P=F.parent/'P105_P35_confirmed_obstacle_event';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not(F/'PREDECLARATION_FIRST.json').exists();cases=[]
# Independent uniform-cost oracle, directed destination clearance penalties.
def oracle(a,c,s,t):
 if not a[s]or not a[t]:return math.inf
 dist={s:0.};q=[(0.,s)]
 while q:
  value,p=heapq.heappop(q)
  if value!=dist[p]:continue
  if p==t:return value
  for dr in [-1,0,1]:
   for dc in [-1,0,1]:
    if not(dr or dc):continue
    v=p[0]+dr,p[1]+dc
    if not(0<=v[0]<a.shape[0]and 0<=v[1]<a.shape[1]and a[v]):continue
    if dr and dc and not(a[p[0]+dr,p[1]]and a[p[0],p[1]+dc]):continue
    cost=value+math.hypot(dr,dc)*(1+.30*max(0.,(40-float(c[v]))/40))
    if cost<dist.get(v,math.inf):dist[v]=cost;heapq.heappush(q,(cost,v))
 return math.inf
for name,wall in [('open',None),('detour',(slice(0,5),4)),('disconnected',(slice(None),4)),('corner',(3,3))]:
 a=np.ones((7,9),bool);c=np.arange(63,dtype=float).reshape(7,9)+1
 if wall is not None:a[wall]=False
 before=a.copy(),c.copy();s,t=(3,1),(3,7);r=repair_path(a,c,s,t);v=oracle(a,c,s,t)
 ok=(r['path']is None and math.isinf(v))or(r['path']is not None and abs(r['cost']-v)<1e-10 and r['path'][0]==s and r['path'][-1]==t)
 cases.append(dict(name=name,pass_check=ok and np.array_equal(a,before[0])and np.array_equal(c,before[1]),result=r))
a=np.ones((7,9),bool);c=np.ones((7,9))*50
for name,s,t,b in [('budget',(0,0),(6,8),1),('same',(3,3),(3,3),10),('bad_goal',(0,0),(8,9),10)]:
 r=repair_path(a,c,s,t,max_pops=b);expected='ABSTAIN_BUDGET'if name=='budget'else'FOUND_SAME_GOAL'if name=='same'else'ABSTAIN_ENDPOINT_NOT_WALKABLE';cases.append(dict(name=name,pass_check=r['status']==expected,result=r))
a=np.array([[1,0],[0,1]],bool);r=repair_path(a,np.ones((2,2))*50,(0,0),(1,1));cases.append(dict(name='no_corner_cut',pass_check=r['path']is None,result=r))
assert all(e['pass_check']for e in cases)
(F/'REFERENCE_METHOD_FIRST.json').write_text(json.dumps(dict(status='PASS_BOUNDED_SAME_GOAL_REFERENCE_ONLY',cases=cases,source_sha256=sha(F/'known_path_repair.py'),controller_changes=0,native_rounds=0),indent=2)+'\n')
s=(P/'check_sdk_path_event.py').read_text();s=s.replace(s.splitlines()[0],'"""Passive first64-frame replay of failed P105; capture own event context for zero-flight path-repair reference. No controller modification."""')
s=s.replace('event_queries=[];issued_arms=[]','event_contexts=[];event_queries=[];issued_arms=[]')
needle=" state=getattr(d,'_path_event_state',None)\n event_queries.append("
extra=''' state=getattr(d,'_path_event_state',None)
 if answer:
  from swarm_rescue.solutions.path_event import _navigation_mask
  allowed=_navigation_mask(d.memory,d.pose);clearance=d.memory.clearance()
  event_contexts.append(dict(owner=int(d.identifier or 0),step=int(step),last_plan_step=int(before),pose=np.asarray(d.pose).tolist(),goal=None if d.goal is None else np.asarray(d.goal).tolist(),waypoints=[np.asarray(p).tolist()for p in d.waypoints],start=list(d.memory.world_to_cell(d.pose)),goal_cell=None if d.goal is None else list(d.memory.world_to_cell(d.goal)),allowed=allowed.astype(int).tolist(),clearance=clearance.tolist(),own_only=True))
 event_queries.append('''
assert s.count(needle)==1;s=s.replace(needle,extra).replace('event_queries=event_queries,issued_arms=issued_arms,','event_contexts=event_contexts,event_queries=event_queries,issued_arms=issued_arms,')
ast.parse(s);(F/'check_same_failed_prefix.py').write_text(s)
meta=P/'WORKSPACE_READY.json';(F/'WORKSPACE_READY.json').write_bytes(meta.read_bytes())
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=sha(F/'check_same_failed_prefix.py'),failed_input=str(P/'CROSS_PATH_EVENT_FIRST.json'),failed_input_sha256=sha(P/'CROSS_PATH_EVENT_FIRST.json'),failed_review_sha256=sha(P/'CROSS_PATH_EVENT_FIRST_REVIEW.json'),prefix_frames=64,label='SAME_FAILED_PREFIX64_FIRST',case='cross_sdk',wall_rate=.05,horizon=64,identity='All64 frame rows, all event query/issued arm records and production source SHA identical to original failed P105 prefix. Actual snapshot before replacement, never fed to controller. No performance retry.',controller_changes=False,native_rounds=0,reference_method_sha256=sha(F/'REFERENCE_METHOD_FIRST.json'))
(F/'PREDECLARATION_FIRST.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(status='REFERENCE_PASS_AND_SAME_FAILED_PREFIX_DECLARED',method_cases=len(cases),prefix_frames=64)))
