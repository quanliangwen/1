"""Before any new candidate's SDK run, reject an already-tested exact source.

Read-only diagnoses and actual ZIP qualifications are separate workflows;
this gate is for declaring a NEW algorithm candidate. It never starts tests.
"""
from pathlib import Path
import json,hashlib,sys,datetime
ROOTS=[Path('E:/codex/PJ01_rule_refinement_20261101'),Path('E:/codex/PJ01_rule_refinement_20261102')]
def manifest_files(d):
 for key in ['candidate_files','files']:
  value=d.get(key)
  if isinstance(value,dict)and value and all(isinstance(k,str)and isinstance(v,str)and len(v)==64 for k,v in value.items()):return value
 return None
def fingerprint(files):return hashlib.sha256(json.dumps(files,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def check(path,output):
 path=Path(path).resolve();output=Path(output);assert not output.exists();d=json.loads(path.read_text(encoding='utf-8-sig'));files=manifest_files(d);assert files,'Need an actual candidate file manifest'
 own=fingerprint(files);matches=[];index=[]
 for root in ROOTS:
  for p in root.glob('*/CANDIDATE_MANIFEST*.json'):
   if p.resolve()==path:continue
   try:old=json.loads(p.read_text(encoding='utf-8-sig'));candidate=manifest_files(old)
   except (ValueError,OSError):continue
   if candidate is None:continue
   statuses=[]
   for pattern in ['*REVIEW*.json','*RESULT*.json','*STATUS*.json']:
    for evidence in p.parent.glob(pattern):
     try:
      e=json.loads(evidence.read_text(encoding='utf-8-sig'));status=e.get('status')
     except (ValueError,OSError):continue
     if status:statuses.append(dict(path=str(evidence),status=status,sha256=hashlib.sha256(evidence.read_bytes()).hexdigest()))
   row=dict(stage=p.parent.name,manifest=str(p),manifest_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),fingerprint=fingerprint(candidate),rule=old.get('rule',old.get('basis')),status_evidence=statuses)
   index.append(row)
   if row['fingerprint']==own:matches.append(row)
 result=dict(status='STOP_ALREADY_DECLARED_SOURCE_NOT_A_NEW_CANDIDATE'if matches else'PASS_NO_EXACT_HISTORICAL_SOURCE_MATCH',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),candidate=str(path),candidate_fingerprint=own,source_files=len(files),exact_matches=matches,index=index,limits=['No exact match is not proof of conceptual novelty. Read closest mechanisms and outcomes before making a new rule.','Same module with new thresholds/labels remains the same mechanism and needs a specific new causal reason, not this hash PASS.','A matched earlier candidate is never a new scientific improvement merely because its label/seed/horizon changed.'],SDK_frames=0,native_rounds=0)
 output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');return result
if __name__=='__main__':
 r=check(sys.argv[1],sys.argv[2]);print(json.dumps(dict(status=r['status'],matched_stages=[e['stage']for e in r['exact_matches']],indexed=len(r['index']))))
 if r['exact_matches']:sys.exit(2)
