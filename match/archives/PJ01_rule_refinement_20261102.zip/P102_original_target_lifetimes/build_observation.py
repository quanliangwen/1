from pathlib import Path
import ast,json,hashlib,shutil,datetime
F=Path(__file__).resolve().parent;P=F.parent/'P101_surface_opportunity_shadow';dest=F/'check_target_lifetimes.py';assert not dest.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((P/'SHADOW_REVIEW_FIRST.json').read_text());assert all(r['checks'].values())
targets=[dict(index=i,**e)for i,e in enumerate(r['events'])if e['admissible_in_existing_scope']];assert len(targets)==8
(F/'FROZEN_AUTHOR_OPPORTUNITIES_FIRST.json').write_text(json.dumps(targets,indent=2)+'\n')
s=(F.parent/'P85_P48_observed_fragment_output/check_sdk_fragment_flight.py').read_text().replace('P85 final output-only observed fragments','P102 readonly original target lifetime observation, never production inputs')
needle="TRACE_ENABLED=arm=='P48Trace'";assert s.count(needle)==1
extra='''
from target_sections import target_sections
from approach_views_reference import matched_near_returns
from own_map_snapshot import encode_own_snapshot
author_targets=json.loads((F/'FROZEN_AUTHOR_OPPORTUNITIES_FIRST.json').read_text())
target_timelines={str(e['index']):[]for e in author_targets};unresolved_snapshots=[]
def observe_original_targets(actors,step):
 cache={}
 for event in author_targets:
  probe=event['proposal'];admitted=event['step'];expiry=probe['expiry']
  if step<admitted or step>expiry or not(step==admitted or step==expiry or step%12==0):continue
  owner=event['owner'];drone=actors[owner];mem=drone.memory
  if owner not in cache:
   image=mem.render().copy();d=np.asarray(drone.lidar_values(),float);a=np.asarray(drone.lidar_rays_angles(),float)
   excluded=mem.semantic_mask(d,a,drone.semantic_values());cache[owner]=(image,d,a,excluded)
  image,d,a,excluded=cache[owner]
  representation=target_sections(image,probe,mem.width,mem.height,mem.CELL)
  if step==admitted:
   assert np.array_equal(np.asarray(drone.pose),np.asarray(probe['source_origin']))
   assert representation['fraction']==0.,'Target depiction differs at original admission'
  near=matched_near_returns(pose=drone.pose,heading=drone.heading,distances=d,angles=a,excluded=excluded,wall=probe['wall'])
  target_timelines[str(event['index'])].append(dict(step=step,age=step-admitted,owner=owner,own_pose=drone.pose.tolist(),target_fraction=representation['fraction'],sections=representation['represented_sections'],actual_unexcluded_near_ray_count=int(near.sum()),original_observe_tick=(step%4==0),inventory=int(drone.carried_bombs_count()),bearing_merged_packets=int(mem.bearing_merged_packets),frame_records=len(drone.frame_records),image_sha256=hashlib.sha256(image.tobytes()).hexdigest()))
  if step==expiry and representation['fraction']<.7:
   name='UNRESOLVED_AUTHOR_TARGET_'+str(event['index'])+'_FIRST.json';packet=encode_own_snapshot(drone,image)
   assert not(F/name).exists();(F/name).write_text(json.dumps(packet,separators=(',',':')))
   unresolved_snapshots.append(dict(file=name,target_index=event['index'],owner=owner,step=step,snapshot_sha256=packet['snapshot_sha256'],file_sha256=hashlib.sha256((F/name).read_bytes()).hexdigest()))
'''
s=s.replace(needle,needle+extra)
needle='   pg.step(commands,messages)';assert s.count(needle)==1;s=s.replace(needle,'   observe_original_targets(drones,step)\n'+needle)
needle='gate_events=gate_events,route_details=route_details,TRACE_ENABLED=TRACE_ENABLED,';assert s.count(needle)==1
s=s.replace(needle,'target_timelines=target_timelines,unresolved_snapshots=unresolved_snapshots,'+needle)
ast.parse(s);dest.write_text(s)
for root,name in [(F.parent/'P100_surface_completion_reference','target_sections.py'),(F.parent/'P98_autonomous_surface_view_reference','approach_views_reference.py'),(F.parent/'P75_P48_map_layer_diagnosis','own_map_snapshot.py'),(F.parent/'P91_known_graph_tail_reference','WORKSPACE_READY.json')]:shutil.copyfile(root/name,F/name)
parent=P/'WIDE_FULL_FRAMEWORK_SHADOW_FIRST.json';horizon=max(e['proposal']['expiry']for e in targets);assert horizon==369
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources={n:sha(F/n)for n in ['check_target_lifetimes.py','target_sections.py','approach_views_reference.py','own_map_snapshot.py','run_observation.py','FROZEN_AUTHOR_OPPORTUNITIES_FIRST.json']},parent=str(parent),parent_sha256=sha(parent),case='wide_cross_sdk',label='ORIGINAL_TARGET_LIFETIMES_FIRST',horizon=horizon,wall_rate=.05,scope='Bounded first369 frames of original P48 full5actor baseline, all8 prior OWN AUTHOR proposal points monitored by observer only, never read by agent policy. No forced new views/actions or new performance score. Observe whether existing sensing/map fusion already represents the surfaces.',gates=['All369 recorded frame rows and original core source hashes identical to existing original P48 author trace; first mismatch stops interpretation.','Only initial own-derived target points from frozen P101 diagnostic input; global observer accesses public own memories after control and before author physics, not production policy.','At admission own pose must equal original source_origin and original target representation must be0.','Map checks each12steps and exact admission/expiry. Snapshot only unresolved targets at old expiry; no new observer window extension/official truth/BLUE/NPZ.','No automatic candidate/native/five. Depiction does not itself prove truth accuracy, and lack of later snapshot before this study did not prove failure.'],native_rounds=0,new_production_candidate=False)
(F/'PREDECLARATION_FIRST.json').write_text(json.dumps(out,indent=2)+'\n');print('Original369-frame passive observation bound, no policy input or control changes')
