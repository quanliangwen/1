from pathlib import Path
import ast,subprocess,json,time,datetime,hashlib
F=Path(__file__).resolve().parent;R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P102_original_target_lifetimes_20261102';ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60'];utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def remote(code):return subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=code.encode(),capture_output=True)
def keep(name,p):
    dest=F/(name+'.capture.txt');assert not dest.exists();dest.write_bytes(p.stdout+p.stderr);print(p.stdout.decode(errors='replace')[-1500:],flush=True)
    if p.returncode:raise RuntimeError('Keep first target lifetime observation error '+name)
def fetch(name):subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+name,str(F/name)],check=True)
def main():
    assert not(F/'STARTED_FIRST.json').exists();pre=json.loads((F/'PREDECLARATION_FIRST.json').read_text());assert all(sha(F/n)==h for n,h in pre['sources'].items())
    guard=Path('E:/codex/UAV_rules_astar_restart_20261030/R154_scoped_serial_guard_20261101/check_scoped_serial.py').read_text();keep('SERIAL_FIRST',remote(guard));keep('MKDIR_FIRST',remote('from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n'))
    (F/'STARTED_FIRST.json').write_text(json.dumps(dict(utc=utc(),finite_hours=14,scope=pre['scope'],native_rounds=0),indent=2)+'\n')
    for name in ['check_target_lifetimes.py','target_sections.py','approach_views_reference.py','own_map_snapshot.py','FROZEN_AUTHOR_OPPORTUNITIES_FIRST.json','PREDECLARATION_FIRST.json','WORKSPACE_READY.json']:
        subprocess.run(['scp','-q',str(F/name),'junhao@10.112.162.60:'+D+'/'],check=True)
    subprocess.run(['scp','-q','E:/codex/UAV_rules_astar_restart_20261030/run_sdk_captured.py','junhao@10.112.162.60:'+D+'/'],check=True)
    src=Path('E:/codex/PJ01_environment_restore_20261101/P35_continuation_after_parent_repair/run_offline.py').read_text();methods='\n'.join(ast.get_source_segment(src,n)for n in ast.parse(src).body if isinstance(n,ast.FunctionDef)and n.name in ['cpu_sample','resource'])
    capacity='from pathlib import Path\nimport os,time,shutil,json,datetime\nR=Path('+repr(R)+')\nD=json.loads((R/"solver_study/framework_screen_20261016/best87_independent_20261025/P37_phase_five_comparison_20261101/PREDECLARATION.json").read_text())\ndef utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()\n'+methods+'\nprint(json.dumps(resource()))\n'
    deadline=time.monotonic()+14*3600;count=0;consecutive=[]
    while time.monotonic()<deadline:
        if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop')
        count+=1;p=remote(capacity);keep('CAPACITY_'+str(count)+'_FIRST',p);row=json.loads(p.stdout);consecutive=consecutive+[row]if row['clean']else[]
        (F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='WAITING_ORIGINAL_CAPACITY',resource=row),indent=2)+'\n')
        if len(consecutive)>=2:break
        time.sleep(60)
    else:raise TimeoutError('Finite target observation capacity wait expired')
    (F/'RESOURCE_TWO_SAMPLE_FIRST.json').write_text(json.dumps(consecutive,indent=2)+'\n');keep('BEFORE_OBSERVATION_SERIAL_FIRST',remote(guard))
    label=pre['label'];(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='RUNNING_PASSIVE_TARGET_LIFETIME_OBSERVATION',native_rounds=0),indent=2)+'\n')
    keep(label,subprocess.run(ssh+[R+'/.venv/bin/python',D+'/run_sdk_captured.py',D+'/check_target_lifetimes.py',label,'P48Reference',pre['case'],str(pre['horizon']),str(pre['wall_rate'])],capture_output=True));fetch(label+'.json')
    c=json.loads((F/(label+'.json')).read_text());parent=Path(pre['parent']);assert sha(parent)==pre['parent_sha256'];p=json.loads(parent.read_text());n=pre['horizon']
    checks=dict(all_original_recorded369frames_identical=c['rows']==p['rows'][:n],same_core_source=c['source_sha256']==p['source_sha256'],exact_bounded_horizon=c['physics_steps']==n,original_physical_checks=all(c['checks'].values()),no_new_submission=not c['submission_records'])
    targets=json.loads((F/'FROZEN_AUTHOR_OPPORTUNITIES_FIRST.json').read_text());rows=[]
    for e in targets:
        trace=c['target_timelines'][str(e['index'])];first=next((r for r in trace if r['target_fraction']>=.7),None)
        rows.append(dict(index=e['index'],owner=e['owner'],admission=e['step'],expiry=e['proposal']['expiry'],samples=len(trace),first_depicted_step=None if first is None else first['step'],first_depiction_delay=None if first is None else first['age'],first_depicted_with_own_near_returns=None if first is None else first['actual_unexcluded_near_ray_count']>=3,expiry_fraction=trace[-1]['target_fraction']if trace else None,trace=trace))
    report=dict(status='PASS_ORIGINAL_TARGET_LIFETIME_OBSERVATION'if all(checks.values())else'STOP_TARGET_OBSERVATION_INPUT_MISMATCH',utc=utc(),checks=checks,targets=len(rows),represented_in_original_window=sum(r['first_depicted_step']is not None for r in rows),represented_at_expiry=sum(r['expiry_fraction']is not None and r['expiry_fraction']>=.7 for r in rows),rows=rows,unresolved_snapshots=c['unresolved_snapshots'],physical_frames=n,native_rounds=0,new_controller=False,new_score=False)
    (F/'TARGET_REVIEW_FIRST.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='rows'}),flush=True)
    if not all(checks.values()):raise RuntimeError('Original target observer altered recorded inputs, no interpretation')
    for item in c['unresolved_snapshots']:
        fetch(item['file']);assert sha(F/item['file'])==item['file_sha256']
    (F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='COMPLETE_TARGET_LIFETIME_OBSERVATION',native_rounds=0),indent=2)+'\n')
if __name__=='__main__':
    try:main()
    except Exception:
        import traceback
        (F/'FIRST_ERROR.json').write_text(json.dumps(dict(utc=utc(),traceback=traceback.format_exc(),no_retry=True),indent=2)+'\n');raise
