from pathlib import Path
import json,hashlib,ast,datetime
F=Path(__file__).resolve().parent;O=F.parent/'P103_sensor_aligned_phase';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not(F/'SDK_PREDECLARATION_FIRST.json').exists()
s=(O/'check_sdk_phase_candidate.py').read_text();s=s.replace(s.splitlines()[0],'"""P105 unchanged P35 phase plus own-confirmed newly blocked path event; full noisy authored SDK closure, no native score."""')
needle="TRACE_ENABLED=arm=='P48Trace'";assert s.count(needle)==1
extra='''TRACE_ENABLED=False
import swarm_rescue.solutions.greedy_mapping as greedy_module
event_queries=[];issued_arms=[]
raw_event=greedy_module.observed_path_replan_due
raw_arm=greedy_module.remember_issued_plan
def observe_event(d,step,returning,distances,angles):
 before=d.last_plan_step
 answer=raw_event(d,step,returning,distances,angles)
 state=getattr(d,'_path_event_state',None)
 event_queries.append(dict(owner=int(d.identifier or 0),step=int(step),last_plan_step=int(before),fired=bool(answer),epoch=None if state is None else state.epoch,confirmations=None if state is None else state.confirmations,supported=[]if state is None else sorted([list(c)for c in state.supported]),own_observe_epoch=getattr(d.memory,'_bearing_frame_step',None)))
 return answer
def observe_arm(d,step,returning):
 result=raw_arm(d,step,returning)
 state=getattr(d,'_path_event_state',None)
 issued_arms.append(dict(owner=int(d.identifier or 0),step=int(step),armed=state is not None and state.epoch==step))
 return result
greedy_module.observed_path_replan_due=observe_event
greedy_module.remember_issued_plan=observe_arm'''
s=s.replace(needle,extra).replace('gate_events=gate_events,route_details=route_details,TRACE_ENABLED=TRACE_ENABLED,','event_queries=event_queries,issued_arms=issued_arms,gate_events=gate_events,route_details=route_details,TRACE_ENABLED=TRACE_ENABLED,')
ast.parse(s);(F/'check_sdk_path_event.py').write_text(s)
s=(O/'prepare_workspace.py').read_text().replace('P103','P105');(F/'prepare_workspace.py').write_text(s)
s=(O/'run_sdk_checks.py').read_text().replace('P103_sensor_aligned_phase','P105_P35_confirmed_obstacle_event').replace('PJ01_rules_P105_P35_confirmed_obstacle_event_20261102','PJ01_rules_P105_confirmed_obstacle_event_20261102').replace('PHASE_CONTRACTS_FIRST.json','CONTROL_CONTRACT_FIRST.json').replace('PASS_PHASE_TIMELINE_REGIMES','PASS_LOCAL_EVENT_STATE_AND_ORIGINAL_CONTROL_ONLY').replace('check_sdk_phase_candidate.py','check_sdk_path_event.py').replace("label,'P103'","label,'P105'").replace('full-plan calls','path-event calls')
start=s.index("        early=[r for r in actual['plan_calls']")
end=s.index("        (F/(label+'_REVIEW.json'))",start)
new='''        fires=[r for r in actual['event_queries']if r['fired']]
        old=json.loads(parent.read_text())
        selected_map=None if selected is None else selected['original_map_score']
        time_value=10*max(0,min(1,(2000-actual['physics_steps'])/1000))
        identity=actual['rows']==old['rows']and actual['map_results']==old['map_results']and [{k:r[k]for k in ['owner','step','original_sha256','original_map_score']}for r in actual['submission_records']]==[{k:r[k]for k in ['owner','step','original_sha256','original_map_score']}for r in old['submission_records']]
        checks=dict(original_actual_checks=all(actual['checks'].values()),all10=actual['rows'][-1]['inventory']==[0]*5,actual_submission=selected is not None,selected_map_nonregress=selected_map is not None and selected_map>=case['parent_map'],health_nonregress=all(r['health'][i]>=case['parent_min_health'][i]for r in actual['rows']for i in range(5)),time_contribution_nonregress=time_value>=case['parent_time_contribution'],input_walltime_within_original_limit=case['wall_rate']*actual['physics_steps']<=90,all_fires_after_same_step_own_observe=all(r['own_observe_epoch']==r['step']for r in fires),all_fires_gap12=all(12<=r['step']-r['last_plan_step']<24 for r in fires),all_fires_two_confirmations=all(r['confirmations']>=2 and r['supported']for r in fires),no_event_same_full_behavior=bool(fires)or identity)
        report=dict(status='PASS_CONFIRMED_PATH_EVENT_AUTHOR_CASE'if all(checks.values())else'STOP_KEEP_FIRST_PATH_EVENT_FAILURE',utc=utc(),case=case['case'],rate=case['wall_rate'],checks=checks,parent_steps=case['parent_steps'],candidate_steps=actual['physics_steps'],parent_map=case['parent_map'],candidate_map=selected_map,map_delta=None if selected_map is None else selected_map-case['parent_map'],actual_owner=None if selected is None else selected['owner'],event_queries=len(actual['event_queries']),issued_arms=len(actual['issued_arms']),valid_arms=sum(r['armed']for r in actual['issued_arms']),fired_events=fires,no_event_identity=identity,wall_seconds=actual['wall_seconds'],all_actor_map_diagnostics=actual['map_results'],native_rounds=0)
'''
s=s[:start]+new+s[end:]
s=s.replace("['early_events','all_actor_map_diagnostics']","['fired_events','all_actor_map_diagnostics']")
s=s.replace("meaningful=any(r['map_delta']>=.5 for r in reviews)","meaningful=any(r['map_delta']>=.5 and r['fired_events']for r in reviews)")
s=s.replace('One independent P48 early-phase change, staged actualSDK checks only; no automatic native/five','One confirmed-obstacle-event rule, preserve P35 phases; staged actualSDK only, no automatic native/five')
s=s.replace('RUNNING_FULL_FRAMEWORK_PHASE_CANDIDATE','RUNNING_CONFIRMED_PATH_EVENT_SDK_CHECK').replace('STOP_FIRST_PHASE_CASE_NO_RETRY','STOP_FIRST_PATH_EVENT_CASE_NO_RETRY').replace('COMPLETE_PROMISING_PHASE_CANDIDATE_AUTHOR_CHECKS','COMPLETE_PROMISING_CONFIRMED_PATH_EVENT_CHECKS').replace('COMPLETE_PHASE_CHECKS_NO_SUBSTANTIVE_GAIN','COMPLETE_PATH_EVENT_CHECKS_NO_SUBSTANTIVE_GAIN')
ast.parse(s);(F/'run_sdk_checks.py').write_text(s)
old=json.loads((O/'SDK_PREDECLARATION_FIRST.json').read_text());cases=old['cases']
for c in cases:c['label']=c['label'].replace('PHASE','PATH_EVENT')
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=sha(F/'check_sdk_path_event.py'),candidate_manifest_sha256=sha(F/'CANDIDATE_MANIFEST_FIRST.json'),local_contract_sha256=sha(F/'CONTROL_CONTRACT_FIRST.json'),cases=cases,gates=['Both actual full mission author cases: original SDK callbacks/commands/legal stock,10/10, real loop<90 and declared input wall<=90, actual first raw map/time/health no worse than retained original P48.', 'If zero actual event fires, all frame rows, actual original submission SHA/owner/step/map and all5 raw maps must equal retained parent. No-op is integration evidence, not promise.', 'Any fire requires own observation same step,12<=gap<24,>=2 persistent confirmations/supported cells. Original P35 due predicates and phases unchanged.', 'First failed case stops chain; no seed/label/threshold rescue. Both pass plus actual fire and map>=parent+.5 required even to consider a separate internalZIP/ABI/native pilot. No automatic five.'],unchanged=['P35 0/4/9/14/19 phase','P48 freshness repair','map fusion/render','task objective/motor/placement','SDK/requirements/limits'],native_rounds=0,official_submission=False)
(F/'SDK_PREDECLARATION_FIRST.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(status='FROZEN_FULL_SDK_CHECKS_WITH_FIRST_FAILURE_STOP',cases=[c['label']for c in cases])))
