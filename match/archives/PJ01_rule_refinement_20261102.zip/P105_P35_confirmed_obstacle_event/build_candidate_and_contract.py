from pathlib import Path
import ast,json,hashlib,shutil,datetime
F=Path(__file__).resolve().parent;B=Path('E:/codex/PJ01_rule_refinement_20261101/P48_P35_refresh_deferral_candidate');O=Path('E:/codex/PJ01_rule_refinement_20261101/P40_confirmed_path_event_candidate');P=B/'candidate_project';C=F/'candidate_project';assert not C.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((B/'CANDIDATE_MANIFEST_FIRST.json').read_text());assert all(sha(P/n)==h for n,h in old['candidate_files'].items())
shutil.copytree(P,C,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git'));S=C/'src/swarm_rescue/solutions';p=S/'greedy_mapping.py';s=p.read_text()
line='        if step - self.last_plan_step >= 24 or early_exploration_due(self, step, returning):\n';assert s.count(line)==1
s=s.replace(line,line.rstrip(':\n')+' or (lidar is not None and step % 4 == 0 and observed_path_replan_due(self, step, returning, lidar, angles)):\n')
needle='            self.waypoints, self.goal = self._plan_route(step, returning, peer_goals)\n            self.last_plan_step = step\n';assert s.count(needle)==1;s=s.replace(needle,needle+'            remember_issued_plan(self, step, returning)\n')
needle='from __future__ import annotations\n';assert s.count(needle)==1;s=s.replace(needle,needle+'\nfrom swarm_rescue.solutions.path_event import observed_path_replan_due, remember_issued_plan\n');ast.parse(s);p.write_text(s)
for name in ['path_event.py','projected_suffix_revision.py']:shutil.copyfile(O/'candidate_project/src/swarm_rescue/solutions'/name,S/name)
files={p.relative_to(C).as_posix():sha(p)for p in C.rglob('*')if p.is_file()};diff=[n for n in sorted(files.keys()|old['candidate_files'].keys())if files.get(n)!=old['candidate_files'].get(n)]
assert diff==['src/swarm_rescue/solutions/greedy_mapping.py','src/swarm_rescue/solutions/path_event.py','src/swarm_rescue/solutions/projected_suffix_revision.py']
out=dict(status='SOURCE_FROZEN_SINGLE_CONFIRMED_PATH_EVENT_ON_P35_P48',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent=str(P),parent_files=old['candidate_files'],candidate_files=files,files=files,differences=diff,rule='Preserve P35 phases and normal24 due, add only own two-consecutive-scan confirmed newly-closed forward path event with min12 gap. Existing P40 helper unchanged. Original full mission planner, no preemptive task deletion.',req_unchanged=(P/'req.txt').read_bytes()==(C/'req.txt').read_bytes(),not_stacked=['P103 aligned phases','P100 new views','P94 final exchange','P96 hit filtering','P43 local-only'],native_rounds=0,official_submission=False)
(F/'CANDIDATE_MANIFEST_FIRST.json').write_text(json.dumps(out,indent=2)+'\n')
# Adapt the previously exercised contract harness to the actual P48 control
# body. Helpers retain identical source SHA; recheck the new OR-composition.
s=(O/'check_event_and_original_control.py').read_text();s=s.replace("OUT=F/'EVENT_AND_CONTROL_CONTRACT_V2_FIXTURE_FIXED.json'","OUT=F/'CONTROL_CONTRACT_FIRST.json'")
s=s.replace("B=F.parent/'P01_baseline_rules/baseline_project/src/swarm_rescue/solutions'","B=Path("+repr(str(P/'src/swarm_rescue/solutions'))+")")
s=s.replace('env=dict(np=np,observed_path_replan_due=', 'from swarm_rescue.solutions.exploration_phase import early_exploration_due\nenv=dict(np=np,early_exploration_due=early_exploration_due,observed_path_replan_due=')
s=s.replace("checks['actual_original_control_has_event_effect']=any(r['mode']=='blocked_event'and any(e['early']for e in r['candidate'])for r in rows)","checks['actual_original_control_has_event_effect']=any(r['mode']=='blocked_event'and any(e['step']not in {a['step']for a in r['original']}for e in r['candidate'])for r in rows)")
s=s.replace("checks['all_extra_calls_after_min12']=all(e['step']-e['last']>=12 for r in rows for e in r['candidate']if e['early'])","checks['all_new_event_calls_after_min12']=all(e['step']-e['last']>=12 for r in rows for e in r['candidate']if e['step']not in {a['step']for a in r['original']})")
ast.parse(s);(F/'check_control_contract.py').write_text(s)
print(json.dumps(dict(status=out['status'],differences=diff,unchanged_phase_sha256=sha(S/'exploration_phase.py'))))
