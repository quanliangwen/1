"""One ordinary-exploration event rule; source/SDK qualification pending.

No map edits, route objective changes, target assignments or shared state.
OpenCV is the existing SDK dependency, imported only by numerical adapters.
"""
from types import SimpleNamespace
import math
import numpy as np
from .projected_suffix_revision import projected_suffix_revision

PERIOD=24
OBSERVATION_PERIOD=4
MIN_EXTRA_GAP=PERIOD//2

class ObstacleEventTracker:
    def __init__(self):
        self.epoch=None;self.signature=None;self.points=None;self.allowed=None;self.occupied=None
        self.previous_sample=None;self.supported=set();self.confirmations=0;self.fired=False
    def reset(self):
        self.epoch=None;self.signature=None;self.points=None;self.allowed=None;self.occupied=None
        self.previous_sample=None;self.supported=set();self.confirmations=0;self.fired=False
    def arm(self,step,signature,points,allowed,occupied):
        self.reset();self.epoch=int(step);self.signature=signature
        self.points=np.asarray(points,float).copy();self.allowed=np.asarray(allowed,bool).copy();self.occupied=np.asarray(occupied,bool).copy()
    def sample(self,step,signature,supported_cells,*,own_observation):
        if self.epoch is None or signature!=self.signature:
            self.reset();return False
        if not own_observation or step%OBSERVATION_PERIOD or self.fired or step<=self.epoch or step-self.epoch>=PERIOD:
            return False
        if self.previous_sample is not None and step<=self.previous_sample:return False
        cells={tuple(map(int,c))for c in supported_cells}
        common=self.supported&cells
        if cells and self.previous_sample is not None and step-self.previous_sample==OBSERVATION_PERIOD and common:
            self.confirmations+=1;self.supported=common
        else:
            self.confirmations=1 if cells else 0;self.supported=cells
        self.previous_sample=int(step)
        self.fired=bool(self.confirmations>=2 and step-self.epoch>=MIN_EXTRA_GAP)
        return self.fired

def ordinary_exploration_scope(drone,step,returning):
    if (returning or getattr(drone,'submitted',False)
        or getattr(drone,'coverage_ready',True)
        or getattr(drone,'_seeking_fusion',False)
        or step<getattr(drone,'escape_until',-1)
        or getattr(drone,'assignment_goal',None)is not None
        or getattr(drone,'placement_goal',None)is not None
        or getattr(drone,'pending_drop',None)is not None
        or getattr(drone,'goal',None)is None
        or not getattr(drone,'waypoints',None)):
        return False
    if not hasattr(drone,'carried_bombs_count')or not hasattr(drone,'_remaining_steps'):return False
    if drone.carried_bombs_count()<=0 or drone._remaining_steps()<=24.:return False
    plan=getattr(drone,'survey_plan',None)
    if isinstance(plan,(tuple,list))and len(plan)==5:
        epoch,sender,owner,point,until=plan
        if owner==int(drone.identifier or 0)and point is not None and 0<=step-epoch<120 and step<until:return False
    return True

def _signature(drone):return(int(drone.last_plan_step),tuple(np.asarray(drone.goal,float).tolist()))

def _navigation_mask(memory,position):
    import cv2
    clearance=memory.clearance()
    free=cv2.morphologyEx(memory.free.astype(np.uint8),cv2.MORPH_CLOSE,np.ones((3,3),np.uint8)).astype(bool)|memory.free
    allowed=free&(clearance>=memory.CLEARANCE)
    allowed[memory.world_to_cell(position)]=True
    return allowed

def _current_wall_hits(drone,distances,angles):
    memory=drone.memory;d=np.asarray(distances,float);a=np.asarray(angles,float);p=np.asarray(drone.pose,float)
    if d.ndim!=1 or d.shape!=a.shape or p.shape!=(2,)or not np.isfinite(p).all()or not np.isfinite(float(drone.heading)):
        return np.empty((0,2),int),np.empty((0,2),float)
    excluded=memory.semantic_mask(d,a,drone.semantic_values())
    keep=np.isfinite(d)&np.isfinite(a)&(d>8)&(d<220)&~excluded
    theta=float(drone.heading)+a[keep]
    ends=p+np.column_stack((d[keep]*np.cos(theta),d[keep]*np.sin(theta)))
    cols=np.floor((ends[:,0]+memory.width/2)/memory.FINE).astype(int)
    rows=np.floor((memory.height/2-ends[:,1])/memory.FINE).astype(int)
    valid=(rows>=0)&(cols>=0)&(rows<memory.hit_shape[0])&(cols<memory.hit_shape[1])
    return np.column_stack((rows[valid],cols[valid])),ends[valid]

def _near_issued_path(ends,points,radius):
    if not len(ends):return np.zeros(0,bool)
    answer=np.zeros(len(ends),bool)
    for a,b in zip(points,points[1:]):
        delta=b-a;squared=float(np.dot(delta,delta))
        if squared<=1e-12:continue
        t=np.clip((ends-a)@delta/squared,0.,1.)
        answer|=np.sum((ends-(a+t[:,None]*delta))**2,axis=1)<=radius*radius
    return answer

def _own_supported_cells(memory,hit_cells,closed_cells):
    if not len(hit_cells)or not closed_cells:return set()
    own=np.zeros_like(memory.hits);own[hit_cells[:,0],hit_cells[:,1]]=2
    # Same clearance function as the current frozen PJ01 class. This shadow
    # is geometric support for one frame only; it never merges into the map.
    proxy=SimpleNamespace(hits=own,shape=memory.shape,width=memory.width,height=memory.height,
        FINE=memory.FINE,CELL=memory.CELL,hit_shape=memory.hit_shape)
    clearance=type(memory).clearance(proxy)
    return{tuple(map(int,c))for c in closed_cells if clearance[tuple(c)]<memory.CLEARANCE}

def remember_issued_plan(drone,step,returning):
    state=getattr(drone,'_path_event_state',None)
    if state is None:state=ObstacleEventTracker();drone._path_event_state=state
    if not ordinary_exploration_scope(drone,step,returning):state.reset();return
    points=np.asarray([drone.pose]+list(drone.waypoints),float)
    if points.ndim!=2 or points.shape[1]!=2 or len(points)<2 or len(points)>129 or not np.isfinite(points).all():state.reset();return
    allowed=_navigation_mask(drone.memory,drone.pose)
    # Validate the issued geometry with the exact current rounded samples.
    sampled=0
    for a,b in zip(points,points[1:]):
        rr,cc=drone.memory._line_cells(drone.memory.world_to_cell(a),drone.memory.world_to_cell(b));sampled+=len(rr)
        if sampled>8192 or not allowed[rr,cc].all():state.reset();return
    state.arm(step,_signature(drone),points,allowed,drone.memory.hits>=2)

def observed_path_replan_due(drone,step,returning,distances,angles):
    state=getattr(drone,'_path_event_state',None)
    if state is None:return False
    if not ordinary_exploration_scope(drone,step,returning):state.reset();return False
    if step%OBSERVATION_PERIOD or state.epoch is None or state.signature!=_signature(drone):
        if state.epoch is not None and state.signature!=_signature(drone):state.reset()
        return False
    if state.fired or step<=state.epoch or step-state.epoch>=PERIOD:return False
    cells,ends=_current_wall_hits(drone,distances,angles)
    memory=drone.memory
    if len(cells):
        fresh=~state.occupied[cells[:,0],cells[:,1]]&(memory.hits[cells[:,0],cells[:,1]]>=2)
        # Conservative screening only. The exact graph test below decides.
        hint_radius=memory.CLEARANCE+math.sqrt(2)*(memory.CELL+2*memory.FINE)
        fresh&=_near_issued_path(ends,state.points,hint_radius)
        cells=cells[fresh]
    if not len(cells):return state.sample(step,_signature(drone),set(),own_observation=True)
    current=_navigation_mask(memory,drone.pose)
    result=projected_suffix_revision(state.points,drone.pose,state.allowed,current,memory.world_to_cell,memory._line_cells)
    supported=_own_supported_cells(memory,cells,result.get('closed_cells',[]))if result['newly_closed']is True else set()
    return state.sample(step,_signature(drone),supported,own_observation=True)
