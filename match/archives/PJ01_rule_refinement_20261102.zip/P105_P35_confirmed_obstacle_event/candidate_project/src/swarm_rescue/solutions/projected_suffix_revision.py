"""Diagnostic-only issued geometric suffix validation, no task replacement."""
import numpy as np

def projected_suffix_revision(points,position,old_allowed,new_allowed,to_cell,line_cells,*,max_segments=128,max_cells=8192):
    a=np.asarray(points,float);p=np.asarray(position,float)
    if a.ndim!=2 or a.shape[1:]!=(2,)or len(a)<2 or p.shape!=(2,)or not np.isfinite(a).all()or not np.isfinite(p).all():
        return dict(status='ABSTAIN_INVALID_GEOMETRY',newly_closed=None)
    old=np.asarray(old_allowed,bool);new=np.asarray(new_allowed,bool)
    if old.ndim!=2 or old.shape!=new.shape:return dict(status='ABSTAIN_GRID_MISMATCH',newly_closed=None)
    if len(a)-1>max_segments:return dict(status='ABSTAIN_SEGMENT_BUDGET',newly_closed=None)
    spans=[];arc=0.
    for k,(u,v)in enumerate(zip(a,a[1:])):
        d=v-u;length=float(np.linalg.norm(d))
        if length>1e-9:
            t=float(np.clip(np.dot(p-u,d)/(length*length),0.,1.));q=u+t*d
            spans.append(dict(segment=k,point=q,distance=float(np.linalg.norm(p-q)),progress=arc+t*length))
        arc+=length
    if not spans:return dict(status='ABSTAIN_ZERO_LENGTH_ROUTE',newly_closed=None)
    nearest=min(spans,key=lambda x:(x['distance'],x['progress']))
    if nearest['distance']>32.:
        return dict(status='ABSTAIN_POSE_OFF_ISSUED_ROUTE',newly_closed=None,projection_distance=nearest['distance'])
    near=[s for s in spans if s['distance']<=nearest['distance']+12.]
    if max(s['progress']for s in near)-min(s['progress']for s in near)>32.:
        return dict(status='ABSTAIN_AMBIGUOUS_PROGRESS',newly_closed=None,projection_distance=nearest['distance'])
    tail=[nearest['point']]+[x.copy()for x in a[nearest['segment']+1:]]
    closed=set();trace_count=0;inspected=0
    for u,v in zip(tail,tail[1:]):
        if np.linalg.norm(v-u)<1e-9:continue
        start,end=to_cell(u),to_cell(v);rr,cc=line_cells(start,end)
        trace_count+=len(rr)
        if trace_count>max_cells:return dict(status='ABSTAIN_CELL_BUDGET',newly_closed=None)
        if not old[rr,cc].all():return dict(status='ABSTAIN_OLD_SUFFIX_NOT_CERTIFIED',newly_closed=None)
        inspected+=1
        for r,c in zip(rr[~new[rr,cc]],cc[~new[rr,cc]]):closed.add((int(r),int(c)))
    if not inspected:return dict(status='NO_REMAINING_GEOMETRIC_SUFFIX',newly_closed=False,projection_distance=nearest['distance'])
    return dict(status='NEWLY_CLOSED_PROJECTED_SUFFIX'if closed else'PROJECTED_SUFFIX_STILL_OPEN',newly_closed=bool(closed),
        closed_cells=[list(c)for c in sorted(closed)],projection_distance=nearest['distance'],projected_progress=nearest['progress'],
        issued_total_length=arc,inspected_segments=inspected,sampled_cells=trace_count,
        scope='Issued geometric suffix in own belief only; pose-to-projection connection is uninspected. Not physical reachability or causal saved-step proof.')
