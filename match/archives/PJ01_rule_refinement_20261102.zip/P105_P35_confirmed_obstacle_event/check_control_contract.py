"""No SDK: actual tracker/control bodies with authored graph collaborators.

OpenCV graph construction, raw-hit/geometry correspondence and independent
current-frame clearance are deliberately NOT qualified by these unit cases.
"""
from pathlib import Path
from types import SimpleNamespace
import sys,ast,copy,json,hashlib
import numpy as np
F=Path(__file__).resolve().parent;OUT=F/'CONTROL_CONTRACT_FIRST.json';assert not OUT.exists()
C=F/'candidate_project';sys.path.insert(0,str(C/'src'))
from swarm_rescue.solutions import path_event as event
S=C/'src/swarm_rescue/solutions';B=Path('E:\\codex\\PJ01_rule_refinement_20261101\\P48_P35_refresh_deferral_candidate\\candidate_project\\src\\swarm_rescue\\solutions')
manifest=json.loads((F/'CANDIDATE_MANIFEST_FIRST.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(C/n)==h for n,h in manifest['files'].items())
signature=(0,(100.,0.));points=np.array([[0.,0.],[100.,0.]]);allowed=np.ones((5,10),bool);occupied=np.zeros((20,40),bool)
def state():
    t=event.ObstacleEventTracker();t.arm(0,signature,points,allowed,occupied);return t
checks={};t=state()
checks['two_observations_not_bypass_min12']=not t.sample(4,signature,{(2,4)},own_observation=True)and not t.sample(8,signature,{(2,4)},own_observation=True)and t.sample(12,signature,{(2,4)},own_observation=True)
checks['latched_one_event_before_actual_replan']=not t.sample(16,signature,{(2,4)},own_observation=True)
t=state()
checks['gossip_or_timer_not_own_confirmation']=all(not t.sample(s,signature,{(2,4)},own_observation=False)for s in [4,8,12,16])and t.confirmations==0
t=state();a=t.sample(4,signature,{(2,4)},own_observation=True);n=t.confirmations;b=t.sample(4,signature,{(2,4)},own_observation=True)
checks['same_frame_not_double_counted']=not a and not b and n==t.confirmations==1
t=state();decisions=[t.sample(s,signature,c,own_observation=True)for s,c in [(4,{(2,4)}),(8,{(2,5)}),(12,{(2,4)})]]
checks['different_closed_cells_not_persistent']=not any(decisions)and t.confirmations==1
t=state();decisions=[t.sample(s,signature,c,own_observation=True)for s,c in [(4,{(2,4)}),(8,set()),(12,{(2,4)})]]
checks['cleared_obstacle_resets']=not any(decisions)and t.confirmations==1
t=state();t.sample(4,signature,{(2,4)},own_observation=True)
checks['missing_observation_breaks_consecutive_confirmation']=not t.sample(12,signature,{(2,4)},own_observation=True)and t.confirmations==1
t=state();t.sample(4,signature,{(2,4)},own_observation=True)
checks['goal_or_plan_epoch_changed_abstains']=not t.sample(8,(0,(200.,0.)),{(2,4)},own_observation=True)and t.epoch is None
t=state();checks['original_period_due_not_extra']=not t.sample(24,signature,{(2,4)},own_observation=True)
t=state();t.points[0,0]=42.;t.allowed[0,0]=False;t.occupied[0,0]=True
checks['private_snapshots_do_not_change_input_arrays']=bool(points[0,0]==0 and allowed.all()and not occupied.any())

from swarm_rescue.solutions.exploration_phase import early_exploration_due
env=dict(np=np,early_exploration_due=early_exploration_due,observed_path_replan_due=event.observed_path_replan_due,remember_issued_plan=event.remember_issued_plan)
def method(path,clsname,name):
    tree=ast.parse(path.read_text(encoding='utf-8'));cl=next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name==clsname)
    node=copy.deepcopy(next(n for n in cl.body if isinstance(n,ast.FunctionDef)and n.name==name));node.decorator_list=[]
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(path)+':'+name,'exec'),env);return env[name]
old_control=method(B/'greedy_mapping.py','GreedyMappingDrone','control');new_control=method(S/'greedy_mapping.py','GreedyMappingDrone','control')
to_cell=method(B/'greedy_mapping.py','MapMemory','world_to_cell');line=method(B/'fast_exploration.py','CoordinatedMapMemory','_line_cells')

# Author numerical services allow testing real integration/state ordering
# without pretending to execute OpenCV, the SDK, physical sensors or flight.
event._navigation_mask=lambda m,p:m.author_graph.copy()
event._current_wall_hits=lambda d,distances,angles:(np.array([[64,220]],int),np.array([[184.,0.]]))if d.mode=='blocked_event'else(np.empty((0,2),int),np.empty((0,2),float))
event._own_supported_cells=lambda m,cells,closed:{tuple(c)for c in closed}
class Recorder:
    def __init__(self,mode):
        self.mode=mode;self.identifier=0;self.team_size=5;self.elapsed_timestep=1;self.last_plan_step=-100
        self.pose=np.array([0.,0.]);self.heading=0.;self.coverage_ready=False;self._seeking_fusion=False
        self.submitted=False;self.escape_until=-1;self.assignment_goal=None;self.placement_goal=None;self.pending_drop=None
        self.goal=None;self.waypoints=[];self.peers={};self.progress_anchor=None;self.stuck_steps=0;self.escape_sign=1
        self.inventory=2;self.remaining=1000.;self.survey_plan=None;self.calls=[];self.counters=dict(observe=0,messages=0,returning=0,submit_check=0,drive=0,submit=0)
        self.memory=SimpleNamespace(width=512,height=256,CELL=16,FINE=2,CLEARANCE=19.,shape=(16,32),hit_shape=(128,256),
            hits=np.zeros((128,256),np.uint8),author_graph=np.ones((16,32),bool),observe=self.observe,render=lambda:'AUTHOR_MAP')
        self.memory.world_to_cell=lambda p:to_cell(self.memory,p);self.memory._line_cells=line
    def carried_bombs_count(self):return self.inventory
    def _remaining_steps(self):return self.remaining
    def _update_pose(self):self.pose=np.array([float(self.elapsed_timestep)*2.,0.])
    def _messages(self):self.counters['messages']+=1
    def observe(self,*args):
        self.counters['observe']+=1
        if self.mode=='blocked_event'and self.elapsed_timestep>=4:
            self.memory.author_graph[8,28]=False;self.memory.hits[64,220]=2
    def _is_returning(self,step):self.counters['returning']+=1;return self.mode=='returning'
    def _submission_due(self,step):self.counters['submit_check']+=1;return step>=100
    def _empty_command(self):return dict(move=False)
    def _plan_route(self,step,returning,peers):
        self.calls.append(dict(step=step,last=self.last_plan_step,early=bool(self.last_plan_step>=0 and 0<step-self.last_plan_step<24)))
        return[np.array([200.,0.])],np.array([200.,0.])
    def _drive(self,*args):self.counters['drive']+=1;return dict(move=True)
    def submit_exploration_map(self,image):assert image=='AUTHOR_MAP';self.counters['submit']+=1
    def lidar_values(self):return np.array([100.,100.])
    def lidar_rays_angles(self):return np.array([0.,1.])
    def semantic_values(self):return[]

def run(fn,mode):
    d=Recorder(mode);commands=[]
    for step in range(1,101):
        d.elapsed_timestep=step
        if mode=='placement':d.assignment_goal=np.array([1.,2.])
        elif mode=='fusion':d._seeking_fusion=True
        elif mode=='ready':d.coverage_ready=True
        elif mode=='empty':d.inventory=0
        elif mode=='pending':d.pending_drop=(2,np.array([1.,2.]),step-1)
        elif mode=='short_budget':d.remaining=24.
        elif mode=='directed':d.survey_plan=(step,0,0,np.array([3.,4.]),step+100)
        elif mode=='escaping':d.escape_until=step+4
        commands.append(fn(d))
    return dict(calls=d.calls,counters=d.counters,commands=commands,submitted=d.submitted)
rows=[]
for mode in ['no_event','blocked_event','returning','placement','fusion','ready','empty','pending','short_budget','directed','escaping']:
    a,b=run(old_control,mode),run(new_control,mode)
    rows.append(dict(mode=mode,original=a['calls'],candidate=b['calls'],per_frame_ordering_paths_preserved=a['counters']==b['counters']and a['commands']==b['commands']and a['submitted']==b['submitted']))
checks['actual_original_control_has_event_effect']=any(r['mode']=='blocked_event'and any(e['step']not in {a['step']for a in r['original']}for e in r['candidate'])for r in rows)
checks['no_signal_and_all_exempt_modes_same_plan_cadence']=all(r['original']==r['candidate']for r in rows if r['mode']!='blocked_event')
checks['per_frame_sensing_messages_budgets_submission_motion_preserved']=all(r['per_frame_ordering_paths_preserved']for r in rows)
checks['all_new_event_calls_after_min12']=all(e['step']-e['last']>=12 for r in rows for e in r['candidate']if e['step']not in {a['step']for a in r['original']})
checks={k:bool(v)for k,v in checks.items()};assert all(checks.values())
out=dict(status='PASS_LOCAL_EVENT_STATE_AND_ORIGINAL_CONTROL_ONLY',checks=checks,cases=rows,
    source_sha256={str(p):sha(p)for p in [S/'path_event.py',S/'greedy_mapping.py',S/'projected_suffix_revision.py']},
    numerical_geometry_adapters_overridden=True,new_sdk_frames=0,new_native_rounds=0,
    limitations=['Only temporal/scope/control ordering is qualified here; graph/raw-hit/current-frame geometry services are authored stubs.',
        'No OpenCV mask equivalence, physical sensing/semantic filter correspondence, compute overhead, repaired route or full-inventory mission proof.',
        'No first native or research ZIP allowed until real SDK qualification after the sole P37 queue ends.'])
OUT.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(status=out['status'],checks=checks,cases=len(rows),extra=[e for r in rows for e in r['candidate']if e['early']]),ensure_ascii=False,indent=2))
