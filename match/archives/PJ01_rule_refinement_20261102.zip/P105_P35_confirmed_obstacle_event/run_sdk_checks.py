from pathlib import Path
import ast,subprocess,json,time,datetime,hashlib
F=Path(__file__).resolve().parent;R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P105_confirmed_obstacle_event_20261102';ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60'];utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def remote(code):return subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=code.encode(),capture_output=True)
def keep(name,p):
    dest=F/(name+'.capture.txt');assert not dest.exists();dest.write_bytes(p.stdout+p.stderr);print(p.stdout.decode(errors='replace')[-1600:],flush=True)
    if p.returncode:raise RuntimeError('Keep first phase candidate error '+name)
def fetch(name):subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+name,str(F/name)],check=True)
def main():
    assert not(F/'STARTED_FIRST.json').exists();pre=json.loads((F/'SDK_PREDECLARATION_FIRST.json').read_text());assert sha(F/'check_sdk_path_event.py')==pre['source_sha256']and sha(F/'CANDIDATE_MANIFEST_FIRST.json')==pre['candidate_manifest_sha256']and sha(F/'CONTROL_CONTRACT_FIRST.json')==pre['local_contract_sha256']
    assert json.loads((F/'CONTROL_CONTRACT_FIRST.json').read_text())['status']=='PASS_LOCAL_EVENT_STATE_AND_ORIGINAL_CONTROL_ONLY'
    guard=Path('E:/codex/UAV_rules_astar_restart_20261030/R154_scoped_serial_guard_20261101/check_scoped_serial.py').read_text();keep('SERIAL_FIRST',remote(guard));keep('MKDIR_FIRST',remote('from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n'))
    (F/'STARTED_FIRST.json').write_text(json.dumps(dict(utc=utc(),finite_hours=14,scope='One confirmed-obstacle-event rule, preserve P35 phases; staged actualSDK only, no automatic native/five'),indent=2)+'\n')
    for name in ['candidate_project','CANDIDATE_MANIFEST_FIRST.json','prepare_workspace.py','check_sdk_path_event.py','SDK_PREDECLARATION_FIRST.json']:
        subprocess.run(['scp','-q','-r',str(F/name),'junhao@10.112.162.60:'+D+'/'],check=True)
    subprocess.run(['scp','-q','E:/codex/UAV_rules_astar_restart_20261030/run_sdk_captured.py','junhao@10.112.162.60:'+D+'/'],check=True)
    keep('WORKSPACE_FIRST',subprocess.run(ssh+[R+'/.venv/bin/python',D+'/prepare_workspace.py'],capture_output=True));fetch('WORKSPACE_READY.json')
    src=Path('E:/codex/PJ01_environment_restore_20261101/P35_continuation_after_parent_repair/run_offline.py').read_text();methods='\n'.join(ast.get_source_segment(src,n)for n in ast.parse(src).body if isinstance(n,ast.FunctionDef)and n.name in ['cpu_sample','resource'])
    capacity='from pathlib import Path\nimport os,time,shutil,json,datetime\nR=Path('+repr(R)+')\nD=json.loads((R/"solver_study/framework_screen_20261016/best87_independent_20261025/P37_phase_five_comparison_20261101/PREDECLARATION.json").read_text())\ndef utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()\n'+methods+'\nprint(json.dumps(resource()))\n'
    deadline=time.monotonic()+14*3600;count=0;consecutive=[]
    while time.monotonic()<deadline:
        if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop')
        count+=1;p=remote(capacity);keep('CAPACITY_'+str(count)+'_FIRST',p);row=json.loads(p.stdout);consecutive=consecutive+[row]if row['clean']else[]
        (F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='WAITING_ORIGINAL_CAPACITY',resource=row),indent=2)+'\n')
        if len(consecutive)>=2:break
        time.sleep(60)
    else:raise TimeoutError('Finite phase candidate capacity wait expired')
    (F/'RESOURCE_TWO_SAMPLE_FIRST.json').write_text(json.dumps(consecutive,indent=2)+'\n');reviews=[]
    for case in pre['cases']:
        if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop before next case')
        label=case['label'];keep(label+'_SERIAL',remote(guard));(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='RUNNING_CONFIRMED_PATH_EVENT_SDK_CHECK',current=label,native_rounds=0),indent=2)+'\n')
        keep(label,subprocess.run(ssh+[R+'/.venv/bin/python',D+'/run_sdk_captured.py',D+'/check_sdk_path_event.py',label,'P105',case['case'],str(case['horizon']),str(case['wall_rate'])],capture_output=True));fetch(label+'.json')
        actual=json.loads((F/(label+'.json')).read_text());parent=Path(case['parent']);assert sha(parent)==case['parent_sha256'];selected=actual['submission_records'][0]if actual['submission_records']else None
        fires=[r for r in actual['event_queries']if r['fired']]
        old=json.loads(parent.read_text())
        selected_map=None if selected is None else selected['original_map_score']
        time_value=10*max(0,min(1,(2000-actual['physics_steps'])/1000))
        identity=actual['rows']==old['rows']and actual['map_results']==old['map_results']and [{k:r[k]for k in ['owner','step','original_sha256','original_map_score']}for r in actual['submission_records']]==[{k:r[k]for k in ['owner','step','original_sha256','original_map_score']}for r in old['submission_records']]
        checks=dict(original_actual_checks=all(actual['checks'].values()),all10=actual['rows'][-1]['inventory']==[0]*5,actual_submission=selected is not None,selected_map_nonregress=selected_map is not None and selected_map>=case['parent_map'],health_nonregress=all(r['health'][i]>=case['parent_min_health'][i]for r in actual['rows']for i in range(5)),time_contribution_nonregress=time_value>=case['parent_time_contribution'],input_walltime_within_original_limit=case['wall_rate']*actual['physics_steps']<=90,all_fires_after_same_step_own_observe=all(r['own_observe_epoch']==r['step']for r in fires),all_fires_gap12=all(12<=r['step']-r['last_plan_step']<24 for r in fires),all_fires_two_confirmations=all(r['confirmations']>=2 and r['supported']for r in fires),no_event_same_full_behavior=bool(fires)or identity)
        report=dict(status='PASS_CONFIRMED_PATH_EVENT_AUTHOR_CASE'if all(checks.values())else'STOP_KEEP_FIRST_PATH_EVENT_FAILURE',utc=utc(),case=case['case'],rate=case['wall_rate'],checks=checks,parent_steps=case['parent_steps'],candidate_steps=actual['physics_steps'],parent_map=case['parent_map'],candidate_map=selected_map,map_delta=None if selected_map is None else selected_map-case['parent_map'],actual_owner=None if selected is None else selected['owner'],event_queries=len(actual['event_queries']),issued_arms=len(actual['issued_arms']),valid_arms=sum(r['armed']for r in actual['issued_arms']),fired_events=fires,no_event_identity=identity,wall_seconds=actual['wall_seconds'],all_actor_map_diagnostics=actual['map_results'],native_rounds=0)
        (F/(label+'_REVIEW.json')).write_text(json.dumps(report,indent=2)+'\n');reviews.append(report);print(json.dumps({k:v for k,v in report.items()if k not in ['fired_events','all_actor_map_diagnostics']}),flush=True)
        if not all(checks.values()):
            result=dict(status='STOP_FIRST_PATH_EVENT_CASE_NO_RETRY',reviews=reviews,later_cases_skipped=True,native_rounds=0);break
    else:
        meaningful=any(r['map_delta']>=.5 and r['fired_events']for r in reviews)
        result=dict(status='COMPLETE_PROMISING_CONFIRMED_PATH_EVENT_CHECKS'if meaningful else'COMPLETE_PATH_EVENT_CHECKS_NO_SUBSTANTIVE_GAIN',reviews=reviews,substantive_gain=meaningful,native_rounds=0,automatic_native_or_five=False)
    (F/'RESULT_FIRST.json').write_text(json.dumps(result,indent=2)+'\n');(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status=result['status'],native_rounds=0),indent=2)+'\n')
if __name__=='__main__':
    try:main()
    except Exception:
        import traceback
        (F/'FIRST_ERROR.json').write_text(json.dumps(dict(utc=utc(),traceback=traceback.format_exc(),no_retry=True),indent=2)+'\n');raise
