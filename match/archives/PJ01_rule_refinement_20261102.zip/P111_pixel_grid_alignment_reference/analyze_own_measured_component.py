"""Owned retained observations, measured-wall component only; no SDK imports.

The missing free/visits arrays prevent exact replay of inferred solids. Do
not fill them with fake zeros or call these values actual game scores.
"""
from pathlib import Path
import ast,json,math,hashlib,time,datetime
import numpy as np
import cv2
F=Path(__file__).resolve().parent;dest=F/'OWN_MEASURED_COMPONENT_FIRST.json';assert not dest.exists();start=time.perf_counter();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
binding=json.loads((F/'OWN_COMPONENT_BINDING_FIRST.json').read_text())
for n,h in binding['inputs'].items():assert sha(F/n)==h
d=json.loads((F/'OWN_SNAPSHOT_INPUT.json').read_text());drops=json.loads((F/'PUBLIC_DROPS_INPUT.json').read_text())['bombs'];source=(F/'LINE_SOURCE_REFERENCE.py').read_text();tree=ast.parse(source);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='regularized_walls');env=dict(np=np,cv2=cv2,math=math);exec(compile(ast.Module(body=[node],type_ignores=[]),'original_bound_regularized_walls','exec'),env)
hits=np.zeros(d['hits']['shape'],dtype=d['hits']['dtype']);hits.ravel()[np.asarray(d['hits']['ids'],int)]=d['hits']['values'];before=hits.copy();fine=d['FINE'];cell=d['CELL'];height=d['height'];width=d['width'];shape=(math.ceil(height/cell),math.ceil(width/cell));ratio=cell//fine;assert cell%fine==0
measured=env['regularized_walls'](hits,fine=fine,line_width=12,keep_raw=False,fit_band=10,duplicate_distance=8,covariance_limit=30).astype(np.float32);assert np.array_equal(hits,before)
old=cv2.resize(measured,(shape[1],shape[0]),interpolation=cv2.INTER_AREA);pad=np.zeros((shape[0]*ratio,shape[1]*ratio),np.float32);pad[:measured.shape[0],:measured.shape[1]]=measured;new=pad.reshape(shape[0],ratio,shape[1],ratio).mean(axis=(1,3))
rr,cc=np.indices(shape);xx=(cc+.5)*cell-width/2;yy=height/2-(rr+.5)*cell;frame=(np.abs(xx)>width/2-cell)|(np.abs(yy)>height/2-cell);old[frame]*=.5;new[frame]*=.5
fr,fc=np.indices(measured.shape);fx=(fc+.5)*fine-width/2;fy=height/2-(fr+.5)*fine;worldr=np.minimum((fr//ratio),shape[0]-1);worldc=np.minimum((fc//ratio),shape[1]-1);fineweight=np.where(frame[worldr,worldc],.5,1.);finevalue=measured*fineweight
radius=round(.12*min(width,height));evaluated=[]
for i,drop in enumerate(drops):
 r=int(np.clip((height/2-drop['y'])//cell,0,shape[0]-1));c=int(np.clip((width/2+drop['x'])//cell,0,shape[1]-1));centerx=(c+.5)*cell-width/2;centery=height/2-(r+.5)*cell
 coarse_disk=(xx-centerx)**2+(yy-centery)**2<=radius**2;exact_disk=(fx-centerx)**2+(fy-centery)**2<=radius**2
 oldgain=float(old[coarse_disk].sum()*cell**2);newgain=float(new[coarse_disk].sum()*cell**2);exact=float(finevalue[exact_disk].sum()*fine**2)
 evaluated.append(dict(public_drop_number=i+1,coarse_cell=[r,c],same_model_center=[centerx,centery],old_coarse_measured_gain=oldgain,aligned_coarse_measured_gain=newgain,fine_pixel_measured_gain=exact,old_abs_error=abs(oldgain-exact),aligned_abs_error=abs(newgain-exact)))
out=dict(status='COMPLETE_RETAINED_OWN_MEASURED_COMPONENT_ALIGNMENT_DIAGNOSIS',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_binding=binding,own_snapshot_owner=d['owner'],own_snapshot_step=d['step'],width=width,height=height,CELL=cell,FINE=fine,radius=radius,measured_fine_pixels=int(measured.sum()),old_model_mass=float(old.sum()*cell**2),aligned_model_mass=float(new.sum()*cell**2),fine_model_mass=float(finevalue.sum()*fine**2),old_aligned_l1=float(np.abs(old-new).sum()),relative_l1=float(np.abs(old-new).sum()/max(1e-12,old.sum())),centers=evaluated,old_mean_abs_error=float(np.mean([e['old_abs_error']for e in evaluated])),aligned_mean_abs_error=float(np.mean([e['aligned_abs_error']for e in evaluated])),better_centers=sum(e['aligned_abs_error']<e['old_abs_error']for e in evaluated),worse_centers=sum(e['aligned_abs_error']>e['old_abs_error']for e in evaluated),elapsed_numeric_seconds=time.perf_counter()-start,SDK_imports=0,SDK_frames=0,native_rounds=0,production_candidate=False,limits=['Only measured wall-line component, no inferred solid confidence or original free/visits replay.','Centers are retained public actual drops snapped to same original coarse grid for model diagnosis; they are never loaded into a production planner.','Fine-pixel value is this OWN model field, not truth walls or a game counterfactual score.','Closeness to model pixel values does not prove feasible target ranking, full objective improvement or tournament gain.','Grid quantization of circle boundaries remains a separate approximation after projection alignment.'])
dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k]for k in ['status','measured_fine_pixels','relative_l1','old_model_mass','aligned_model_mass','fine_model_mass','old_mean_abs_error','aligned_mean_abs_error','better_centers','worse_centers','elapsed_numeric_seconds']}))
