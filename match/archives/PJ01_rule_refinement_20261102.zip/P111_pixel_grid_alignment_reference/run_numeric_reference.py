from pathlib import Path
import json,subprocess,hashlib
F=Path(__file__).resolve().parent;R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P111_pixel_grid_alignment_reference_20261102';ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
def remote(code):return subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=code.encode(),capture_output=True)
def keep(name,p):
 dest=F/(name+'.capture.txt');assert not dest.exists();dest.write_bytes(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError('Preserve first numeric reference error '+name)
 return p.stdout
assert not(F/'PROJECTION_ALIGNMENT_FIRST.json').exists()
guard=Path('E:/codex/UAV_rules_astar_restart_20261030/R154_scoped_serial_guard_20261101/check_scoped_serial.py').read_text();keep('SERIAL_FIRST',remote(guard));keep('MKDIR_FIRST',remote('from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n'))
for name in ['check_projection_alignment.py','INPUT_REVIEW_FIRST.json']:
 subprocess.run(['scp','-q',str(F/name),'junhao@10.112.162.60:'+D+'/'],check=True)
answer=keep('NUMERIC_FIRST',subprocess.run(ssh+[R+'/.venv/bin/python',D+'/check_projection_alignment.py'],capture_output=True));subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/PROJECTION_ALIGNMENT_FIRST.json',str(F/'PROJECTION_ALIGNMENT_FIRST.json')],check=True)
result=json.loads((F/'PROJECTION_ALIGNMENT_FIRST.json').read_text());print(json.dumps(dict(status=result['status'],elapsed=result['elapsed_numeric_seconds'],mismatches=[e for e in result['cases']if not e['old_best_matches_world_cell']],SDK_frames=0,native_rounds=0)))
