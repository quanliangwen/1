"""Numeric only: frozen original resize projection vs its own world grid.

Synthetic finite arrays, no SDK/GUI/map data imports or controller calls.
"""
from pathlib import Path
import numpy as np
import cv2,json,math,hashlib,time,datetime
F=Path(__file__).resolve().parent;dest=F/'PROJECTION_ALIGNMENT_FIRST.json';assert not dest.exists();start=time.perf_counter();cases=[]
for width,height,point in [(1250,800,(1000,200)),(1250,800,(100,200)),(1250,800,(600,200)),(1200,900,(1000,200)),(800,600,(600,200)),(512,256,(400,100))]:
 fine=2;cell=16;shape=(math.ceil(height/cell),math.ceil(width/cell));a=np.zeros((math.ceil(height/fine),math.ceil(width/fine)),np.float32);x,y=point;r,c=y//fine,x//fine;a[r,c]=1
 old=cv2.resize(a,(shape[1],shape[0]),interpolation=cv2.INTER_AREA)
 padded=np.zeros((shape[0]*(cell//fine),shape[1]*(cell//fine)),np.float32);padded[:a.shape[0],:a.shape[1]]=a
 aligned=padded.reshape(shape[0],cell//fine,shape[1],cell//fine).mean(axis=(1,3))
 expected=(y//cell,x//cell);old_cells=np.argwhere(old>0).tolist();new_cells=np.argwhere(aligned>0).tolist()
 old_best=tuple(np.unravel_index(np.argmax(old),shape));new_best=tuple(np.unravel_index(np.argmax(aligned),shape));check=new_cells==[list(expected)]and new_best==expected
 cases.append(dict(width=width,height=height,fine=fine,cell=cell,point_pixel=[x,y],point_world=[x-width/2,height/2-y],expected_world_cell=list(expected),shape=list(shape),old_nonzero_cells=old_cells,aligned_nonzero_cells=new_cells,old_best_world=[(old_best[1]+.5)*cell-width/2,height/2-(old_best[0]+.5)*cell],aligned_best_world=[(new_best[1]+.5)*cell-width/2,height/2-(new_best[0]+.5)*cell],old_best_matches_world_cell=old_best==expected,aligned_matches_world_cell=check,old_total=float(old.sum()),aligned_total=float(aligned.sum()),divisible=(width%cell==0 and height%cell==0),divisible_identity=bool(np.array_equal(old,aligned))if width%cell==0 and height%cell==0 else None))
assert all(e['aligned_matches_world_cell']for e in cases)
assert any(not e['old_best_matches_world_cell']for e in cases)
assert all(e['divisible_identity']for e in cases if e['divisible'])
out=dict(status='PROVED_NON_DIVISIBLE_RESIZE_WORLD_CELL_MISMATCH_IN_MODEL_REFERENCE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cases=cases,elapsed_numeric_seconds=time.perf_counter()-start,packages=dict(numpy=np.__version__,opencv=cv2.__version__),SDK_imports=0,SDK_frames=0,native_rounds=0,production_candidate=False,limits=['Only synthetic coordinate association. Does not prove current native selected/dropped points exploit this error or a score change.','Projection padding changes model values of partial cells; values normalization and original world bounds need consistent treatment before integration.','Changing all cv2.resize calls blindly can break unrelated image or sensor semantics. No source modified here.','The underlying inferred solids and model line thickness are separate uncertainties; no official truth is read.'])
dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
