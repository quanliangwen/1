from pathlib import Path
import json,hashlib,ast,datetime
F=Path(__file__).resolve().parent;dest=F/'INPUT_REVIEW_FIRST.json';assert not dest.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
root=F.parent;path=root/'P108_drone_semantic_sector_reference/STATUS.json'
path.write_text(json.dumps(dict(status='STOP_FIXTURE_GL_ERROR_NO_LABEL_RESULTS',first_wrapper_error_preserved=True,second_error_preserved=True,SDK_frames_completed_unverified=True,native_rounds=0),indent=2)+'\n')
snapshot=root/'P76_frame_constraint_review/OWN_PUBLIC_SNAPSHOT_2.json';data=json.loads(snapshot.read_text())
source=Path('E:/codex/PJ01_rule_refinement_20261101/P48_P35_refresh_deferral_candidate/candidate_project/src/swarm_rescue/solutions/coverage_geometry.py');s=source.read_text();ast.parse(s)
assert 'cv2.resize(values,(memory.shape[1],memory.shape[0]),interpolation=cv2.INTER_AREA)'in s
record=dict(status='SOURCE_GRID_ALIGNMENT_HYPOTHESIS_NOT_YET_VERIFIED',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),own_snapshot=str(snapshot),own_snapshot_sha256=sha(snapshot),snapshot_keys=list(data),public_dimensions=dict(width=data.get('width'),height=data.get('height'),CELL=data.get('CELL'),FINE=data.get('FINE')),snapshot_has_free='free'in data,snapshot_has_visits='visits'in data,coverage_source_sha256=sha(source),hypothesis='memory.shape uses ceil(H/CELL),ceil(W/CELL), but geometry_wall_values uses cv2.resize over the physical image extent. When W or H is not divisible by CELL, that resize can attach a model wall value to a different world cell. Check exact synthetic pixels vs original world_to_cell before proposing a rule.',limitation='Snapshot reconstructs render but may omit free/visits required by solids. Do not fake zeros or call that exact layout-model replay. This stage first tests coordinate association only; no model/threshold/SDK modifications.',SDK_frames=0,native_rounds=0)
dest.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
