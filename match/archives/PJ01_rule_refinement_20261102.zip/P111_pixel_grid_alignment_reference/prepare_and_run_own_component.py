from pathlib import Path
import json,subprocess,hashlib,datetime,shutil
F=Path(__file__).resolve().parent;R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P111_pixel_grid_alignment_reference_20261102';ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();dest=F/'OWN_COMPONENT_BINDING_FIRST.json';assert not dest.exists()
sources={'OWN_SNAPSHOT_INPUT.json':F.parent/'P76_frame_constraint_review/OWN_PUBLIC_SNAPSHOT_2.json','PUBLIC_DROPS_INPUT.json':F.parent/'P75_P48_map_layer_diagnosis/P48Audit_A/Map01_red/round1_bombs.json','LINE_SOURCE_REFERENCE.py':Path('E:/codex/PJ01_rule_refinement_20261101/P48_P35_refresh_deferral_candidate/candidate_project/src/swarm_rescue/solutions/line_regularization.py')}
binding=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),inputs={},source_paths={n:str(p)for n,p in sources.items()},scope='Own explicit JSON/public RED bombs/original source only. No NPZ/pickle, official wall grid or BLUE data.')
for n,p in sources.items():assert not(F/n).exists();shutil.copyfile(p,F/n);binding['inputs'][n]=sha(p)
dest.write_text(json.dumps(binding,indent=2)+'\n')
for n in list(sources)+['OWN_COMPONENT_BINDING_FIRST.json','analyze_own_measured_component.py']:
 subprocess.run(['scp','-q',str(F/n),'junhao@10.112.162.60:'+D+'/'],check=True)
run=subprocess.run(ssh+[R+'/.venv/bin/python',D+'/analyze_own_measured_component.py'],capture_output=True);capture=F/'OWN_COMPONENT_FIRST.capture.txt';assert not capture.exists();capture.write_bytes(run.stdout+run.stderr);print(run.stdout.decode(errors='replace'))
if run.returncode:raise RuntimeError('Keep first own-component numerical error')
subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/OWN_MEASURED_COMPONENT_FIRST.json',str(F/'OWN_MEASURED_COMPONENT_FIRST.json')],check=True)
