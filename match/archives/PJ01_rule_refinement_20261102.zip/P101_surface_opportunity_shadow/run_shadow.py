from pathlib import Path
import ast,subprocess,json,time,datetime,hashlib
F=Path(__file__).resolve().parent;R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P101_surface_opportunity_shadow_20261102';ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60'];utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def remote(code):return subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=code.encode(),capture_output=True)
def keep(name,p):
    dest=F/(name+'.capture.txt');assert not dest.exists();dest.write_bytes(p.stdout+p.stderr);print(p.stdout.decode(errors='replace')[-1900:],flush=True)
    if p.returncode:raise RuntimeError('Keep first full-framework shadow error '+name)
def fetch(name):subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+name,str(F/name)],check=True)
def main():
    assert not(F/'STARTED_FIRST.json').exists();pre=json.loads((F/'PREDECLARATION_FIRST.json').read_text());assert all(sha(F/n)==h for n,h in pre['sources'].items())
    guard=Path('E:/codex/UAV_rules_astar_restart_20261030/R154_scoped_serial_guard_20261101/check_scoped_serial.py').read_text();keep('SERIAL_FIRST',remote(guard));keep('MKDIR_FIRST',remote('from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n'))
    (F/'STARTED_FIRST.json').write_text(json.dumps(dict(utc=utc(),finite_hours=14,scope=pre['scope'],native_rounds=0),indent=2)+'\n')
    for name in ['check_full_framework_shadow.py','approach_views_reference.py','WORKSPACE_READY.json','PREDECLARATION_FIRST.json']:
        subprocess.run(['scp','-q',str(F/name),'junhao@10.112.162.60:'+D+'/'],check=True)
    subprocess.run(['scp','-q','E:/codex/UAV_rules_astar_restart_20261030/run_sdk_captured.py','junhao@10.112.162.60:'+D+'/'],check=True)
    src=Path('E:/codex/PJ01_environment_restore_20261101/P35_continuation_after_parent_repair/run_offline.py').read_text();methods='\n'.join(ast.get_source_segment(src,n)for n in ast.parse(src).body if isinstance(n,ast.FunctionDef)and n.name in ['cpu_sample','resource'])
    capacity='from pathlib import Path\nimport os,time,shutil,json,datetime\nR=Path('+repr(R)+')\nD=json.loads((R/"solver_study/framework_screen_20261016/best87_independent_20261025/P37_phase_five_comparison_20261101/PREDECLARATION.json").read_text())\ndef utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()\n'+methods+'\nprint(json.dumps(resource()))\n'
    deadline=time.monotonic()+14*3600;count=0;consecutive=[]
    while time.monotonic()<deadline:
        if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop')
        count+=1;p=remote(capacity);keep('CAPACITY_'+str(count)+'_FIRST',p);row=json.loads(p.stdout);consecutive=consecutive+[row]if row['clean']else[]
        (F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='WAITING_ORIGINAL_CAPACITY',resource=row),indent=2)+'\n')
        if len(consecutive)>=2:break
        time.sleep(60)
    else:raise TimeoutError('Finite shadow capacity wait expired')
    (F/'RESOURCE_TWO_SAMPLE_FIRST.json').write_text(json.dumps(consecutive,indent=2)+'\n');keep('BEFORE_SHADOW_SERIAL_FIRST',remote(guard))
    label=pre['label'];(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='RUNNING_READONLY_FULL_FRAMEWORK_SHADOW',native_rounds=0),indent=2)+'\n')
    keep(label,subprocess.run(ssh+[R+'/.venv/bin/python',D+'/run_sdk_captured.py',D+'/check_full_framework_shadow.py',label,'P48Reference',pre['case'],str(pre['horizon']),str(pre['wall_rate'])],capture_output=True));fetch(label+'.json')
    c=json.loads((F/(label+'.json')).read_text());parent=Path(pre['parent']);assert sha(parent)==pre['parent_sha256'];p=json.loads(parent.read_text());keys=['owner','step','output_sha256','map_score','breakdown']
    checks=dict(all_original_physical_checks=all(c['checks'].values()),all701rows_identical=c['rows']==p['rows'],actual_submissions_identical=[{k:r[k]for k in keys}for r in c['submission_records']]==[{k:r[k]for k in keys}for r in p['submission_records']],all_actor_render_scores_identical=c['map_results']==p['map_results'])
    events=c['surface_events'];report=dict(status='PASS_FULL_FRAMEWORK_READONLY_INPUT'if all(checks.values())else'STOP_SHADOW_INPUT_MISMATCH',utc=utc(),checks=checks,stats=c['surface_stats'],attempts=len(events),helper_admitted=sum(e['helper_admitted']for e in events),existing_scope_admissible=sum(e['admissible_in_existing_scope']for e in events),events=events,contexts=c['surface_contexts'],wall_seconds=c['wall_seconds'],native_rounds=0,controller_changed=False,not_new_game_score=True)
    (F/'SHADOW_REVIEW_FIRST.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='events'}),flush=True)
    if not all(checks.values()):raise RuntimeError('Readonly shadow changed original inputs; do not interpret opportunities')
    for item in c['surface_contexts']:
        fetch(item['file']);fetch(item['image']);assert sha(F/item['file'])==item['source_sha256']
    (F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='COMPLETE_FULL_FRAMEWORK_SHADOW',native_rounds=0),indent=2)+'\n')
if __name__=='__main__':
    try:main()
    except Exception:
        import traceback
        (F/'FIRST_ERROR.json').write_text(json.dumps(dict(utc=utc(),traceback=traceback.format_exc(),no_retry=True),indent=2)+'\n');raise
