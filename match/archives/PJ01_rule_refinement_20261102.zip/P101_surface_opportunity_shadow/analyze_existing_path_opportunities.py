"""Post-hoc author path geometry only; never supplied to a controller."""
from pathlib import Path
import json,hashlib,math,datetime
F=Path(__file__).resolve().parent;dest=F/'EXISTING_PATH_OPPORTUNITIES_FIRST.json';assert not dest.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
review=json.loads((F/'SHADOW_REVIEW_FIRST.json').read_text());assert all(review['checks'].values())
source=F/'WIDE_FULL_FRAMEWORK_SHADOW_FIRST.json';full=json.loads(source.read_text());out=[]
for event in review['events']:
    if not event['admissible_in_existing_scope']:continue
    owner,step=event['owner'],event['step'];probe=event['proposal'];wall=probe['wall'];end=probe['expiry']
    distance=lambda p:math.hypot(p[0]-wall[0],p[1]-wall[1])
    rows=[r for r in full['rows']if step<=r['step']<=end]
    near220=[r for r in rows if distance(r['positions'][owner])<220]
    near190=[r for r in rows if distance(r['positions'][owner])<=190]
    oldgoal=event['original_returned_goal'];goal_distance=None if oldgoal is None else distance(oldgoal)
    spread=0.
    if near220:
        origin=near220[0]['positions'][owner]
        spread=max(math.hypot(r['positions'][owner][0]-origin[0],r['positions'][owner][1]-origin[1])for r in near220)
    out.append(dict(owner=owner,step=step,expiry=end,nominal_new_probe_steps=probe['nominal_steps'],original_goal_distance_to_surface_center=goal_distance,original_goal_already_within190=goal_distance is not None and goal_distance<=190,baseline_first_within220=None if not near220 else near220[0]['step'],baseline_first_within190=None if not near190 else near190[0]['step'],baseline_frames_within220=len(near220),baseline_near_view_position_spread=spread,range_at_admission=distance(rows[0]['positions'][owner])if rows else None))
result=dict(status='PASS_AUTHOR_BASELINE_PATH_GEOMETRY_REVIEW',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=sha(source),events=out,admissible_proposals=len(out),original_goal_within190=sum(r['original_goal_already_within190']for r in out),baseline_reaches190_in_old_window=sum(r['baseline_first_within190']is not None for r in out),baseline_reaches220_in_old_window=sum(r['baseline_first_within220']is not None for r in out),new_physics_frames=0,native_rounds=0,production_input=False,limitations=['Recorded future AUTHOR physics positions are post-hoc evaluation only, never production input.','Range to an own-measured surface center is an observation opportunity, not proof of actual unoccluded near returns or map depiction.','Baseline .05step authored clock and fixed seed are not formal game timing/comparative score evidence.','Do not treat feasible new proposals as useful detours when the original plan already provides near observations.'])
dest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
