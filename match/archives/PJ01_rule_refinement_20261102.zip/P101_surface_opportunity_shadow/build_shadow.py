from pathlib import Path
import ast,json,hashlib,shutil,datetime
F=Path(__file__).resolve().parent;dest=F/'check_full_framework_shadow.py';assert not dest.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
P=F.parent/'P100_surface_completion_reference';e=json.loads((P/'RESULT_FIRST.json').read_text());assert e['status']=='COMPLETE_TWO_COMPLETION_REFERENCES'and all(all(r['checks'].values())for r in e['reviews'])
s=(F.parent/'P85_P48_observed_fragment_output/check_sdk_fragment_flight.py').read_text().replace('P85 final output-only observed fragments','P101 readonly full-framework surface-view opportunity shadow')
needle="TRACE_ENABLED=arm=='P48Trace'";assert s.count(needle)==1
extra='''
from approach_views_reference import propose_views
from swarm_rescue.solutions.scan_geometry import extract_scan_lines
from swarm_rescue.solutions.completion_consensus import _sortie_known_route
import cv2
surface_events=[];surface_contexts=[];surface_stats={}
def shadow_surface_views(drone,step,returning,original_result):
 own=int(drone.identifier or 0);stats=surface_stats.setdefault(own,dict(full_calls=0,ordinary_calls=0,far_candidate_calls=0,expensive_attempts=0))
 stats['full_calls']+=1
 if not ordinary_exploration_scope(drone,step,returning):return
 stats['ordinary_calls']+=1
 raw=drone.lidar_values()
 if raw is None:return
 d=np.asarray(raw,float);a=np.asarray(drone.lidar_rays_angles(),float);excluded=drone.memory.semantic_mask(d,a,drone.semantic_values())
 lines=extract_scan_lines(d,a,excluded)
 far=[(x,y,ids)for x,y,ids in lines if np.count_nonzero((d[ids]>=220)&(d[ids]<285))>=6]
 if not far:return
 stats['far_candidate_calls']+=1
 if stats['expensive_attempts']>=5:return
 stats['expensive_attempts']+=1;started=time.perf_counter();mem=drone.memory;image=mem.render().copy();blocked=mem.blocked().copy();free=mem.free.copy()
 def route(start,goal,walkable,deadline):
  if not walkable[tuple(start)]:return None
  return _sortie_known_route(mem,start,goal,walkable,deadline,max_pops=2048)
 proposal=propose_views(pose=drone.pose,heading=drone.heading,distances=d,angles=a,excluded=excluded,parent_image=image,free=free,blocked=blocked,width=mem.width,height=mem.height,cell=mem.CELL,world_to_cell=mem.world_to_cell,cell_to_world=mem.cell_to_world,route_solver=route,remaining=drone._remaining_steps(),step=step,limit=drone.limit)
 conflicts=[]
 if proposal is not None:
  targets=[mem.world_to_cell(p)for p in proposal['goals']]
  for age,goal,peer_position,peer_id in getattr(mem,'reservations',[]):
   if goal is None or not(peer_id<own and age<80):continue
   gr,gc=mem.world_to_cell(goal)
   if any((r-gr)**2+(c-gc)**2<9 for r,c in targets):conflicts.append(int(peer_id))
 record=dict(owner=own,step=int(step),inventory=int(drone.carried_bombs_count()),remaining=float(drone._remaining_steps()),far_segments=len(far),helper_admitted=proposal is not None,old_hard_lower_id_reservation_conflicts=conflicts,admissible_in_existing_scope=proposal is not None and not conflicts,proposal=proposal,original_returned_goal=None if original_result[1]is None else np.asarray(original_result[1]).tolist(),enclosing_wall_seconds=time.perf_counter()-started)
 surface_events.append(record)
 if proposal is not None and len(surface_contexts)<5:
  index=len(surface_contexts);name='AUTHOR_SURFACE_CONTEXT_'+str(index)+'_FIRST'
  # Only own public author context; reusable numerical input, not official map.
  context=dict(schema='author-public-surface-view-v1',owner=own,step=int(step),pose=drone.pose.tolist(),heading=float(drone.heading),distances=d.tolist(),angles=a.tolist(),excluded=excluded.tolist(),free=free.astype(np.uint8).tolist(),blocked=blocked.astype(np.uint8).tolist(),width=mem.width,height=mem.height,cell=mem.CELL,remaining=float(drone._remaining_steps()),limit=drone.limit,parent_image_file=name+'.png',parent_image_sha256=hashlib.sha256(image.tobytes()).hexdigest(),record=record)
  assert not(F/(name+'.json')).exists();(F/(name+'.json')).write_text(json.dumps(context,separators=(',',':'))+'\\n');assert cv2.imwrite(str(F/(name+'.png')),(image>0).astype(np.uint8)*255)
  surface_contexts.append(dict(file=name+'.json',image=name+'.png',source_sha256=hashlib.sha256((F/(name+'.json')).read_bytes()).hexdigest()))
'''
s=s.replace(needle,needle+extra)
needle='  plan_calls.append(dict(owner=int(self.identifier or 0),step=step,last_plan_step=before,';assert s.count(needle)==1
s=s.replace(needle,'  shadow_surface_views(self,step,returning,result)\n'+needle)
needle='gate_events=gate_events,route_details=route_details,TRACE_ENABLED=TRACE_ENABLED,';assert s.count(needle)==1
s=s.replace(needle,'surface_events=surface_events,surface_stats=surface_stats,surface_contexts=surface_contexts,'+needle)
ast.parse(s);dest.write_text(s)
shutil.copyfile(F.parent/'P98_autonomous_surface_view_reference/approach_views_reference.py',F/'approach_views_reference.py');shutil.copyfile(F.parent/'P91_known_graph_tail_reference/WORKSPACE_READY.json',F/'WORKSPACE_READY.json')
parent=F.parent/'P82_P48_gate_trace/WIDE_PARENT_FIRST.json';data=json.loads(parent.read_text());assert data['physics_steps']==701
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources={n:sha(F/n)for n in ['check_full_framework_shadow.py','approach_views_reference.py','run_shadow.py']},reference_result_sha256=sha(P/'RESULT_FIRST.json'),case='wide_cross_sdk',label='WIDE_FULL_FRAMEWORK_SHADOW_FIRST',horizon=1100,wall_rate=.05,parent=str(parent),parent_sha256=sha(parent),scope='Original P48 full5drone controller and returned plan objects unchanged. Read-only record of ordinary loaded scope, far TLS, existing strict-known/free paths and original lower-id hard target reservation checks; max5 costly helper attempts/actor, max5 own-author reusable contexts.',gates=['All701 recorded frame rows and actual first submission owner/step/imageSHA/map/breakdown identical to retained parent; otherwise stop incomplete observation.','No positive opportunity means no production/native integration by assumption. Positive opportunities are feasibility observations, not improved game score.','Reservation mask affects target admissibility only, never path walkability; no new priority/yield policy.','Original7callbacks/finite controls/health/no real loop hit. No native or official truth, no automatic candidate/five.'],native_rounds=0,new_production_candidate=False)
(F/'PREDECLARATION_FIRST.json').write_text(json.dumps(out,indent=2)+'\n');print('P101 full-framework readonly shadow frozen, no control changes')
