"""Reuse explicit author own-map snapshots to test whether old plans filled targets."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
import cv2
F=Path(__file__).resolve().parent;dest=F/'RETAINED_CONTEXT_PROGRESS_FIRST.json';assert not dest.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
T=F.parent/'PJ01_rules_P100_surface_completion_reference_20261102/target_sections.py';sys.path.insert(0,str(T.parent));from target_sections import target_sections
review=json.loads((F/'SHADOW_REVIEW_FIRST.json').read_text());assert all(review['checks'].values())
contexts=[]
for item in review['contexts']:
    p=F/item['file'];assert sha(p)==item['source_sha256'];c=json.loads(p.read_text());image=(cv2.imread(str(F/c['parent_image_file']),0)>0).astype(np.uint8)
    assert hashlib.sha256(image.tobytes()).hexdigest()==c['parent_image_sha256'];contexts.append((c,image))
rows=[]
for event in review['events']:
    if not event['admissible_in_existing_scope']:continue
    found=[]
    for c,image in contexts:
        if c['owner']==event['owner']and event['step']<c['step']<=event['proposal']['expiry']:
            result=target_sections(image,event['proposal'],c['width'],c['height'],c['cell'])
            found.append(dict(step=c['step'],fraction=result['fraction'],sections=result['represented_sections'],image_sha256=c['parent_image_sha256']))
    rows.append(dict(owner=event['owner'],admission_step=event['step'],expiry=event['proposal']['expiry'],same_owner_later_contexts=found,known_represented_by_step=next((r['step']for r in found if r['fraction']>=.7),None)))
out=dict(status='PASS_REUSED_AUTHOR_CONTEXT_PROGRESS',target_sections_source_sha256=sha(T),rows=rows,targets=len(rows),known_resolved_without_intervention=sum(r['known_represented_by_step']is not None for r in rows),new_physics_frames=0,native_rounds=0,production_input=False,limitations=['Sparse retained context times give latest-known completion bounds, not exact first depiction time.','No matching later snapshot is missing observation, not proof of an unresolved surface.','These are original own author maps, not official map truth or a new rule score.'])
dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
