from pathlib import Path
import ast
F=Path(__file__).resolve().parent;P=F.parent/'P106_goal_preserving_repair_reference'
s=(P/'run_prefix_diagnosis.py').read_text().replace('from known_path_repair import repair_path\n','').replace('P106_goal_preserving_repair_reference','P107_blocking_evidence_provenance').replace('check_same_failed_prefix.py','check_sdk_hit_provenance.py')
s=s.replace("and sha(F/'REFERENCE_METHOD_FIRST.json')==pre['reference_method_sha256']",'')
s=s.replace(",'known_path_repair.py','REFERENCE_METHOD_FIRST.json'",'')
s=s.replace("pfile=Path(pre['failed_input']);assert sha(pfile)==pre['failed_input_sha256'];p=json.loads(pfile.read_text());n=pre['prefix_frames']","pfile=Path(pre['retained_prefix']);assert sha(pfile)==pre['retained_prefix_sha256'];p=json.loads(pfile.read_text());n=pre['prefix_frames']")
s=s.replace("expected64=c['physics_steps']==64)","expected64=c['physics_steps']==64,all5_prefix_maps_identical=c['map_results']==p['map_results'],exact_current_graph=c['event_contexts']==p['event_contexts'],one_actual_provenance=len(c['provenance_contexts'])==1)")
start=s.index(' references=[]\n');end=s.index(" (F/'RESULT_FIRST.json')",start)
s=s[:start]+''' for name in ['AUTHOR_EVENT64_BEARING_FIRST.png','AUTHOR_EVENT64_PARENT_FIRST.png']:fetch(name)
 report=dict(status='COMPLETE_SAME_PREFIX_OWN_HIT_PROVENANCE',utc=utc(),identity_checks=checks,ledger_events=len(c['ledger_events']),raw_observations=len(c['raw_observations']),anchor_events=len(c['anchor_events']),controller_changes=0,native_rounds=0,not_performance=True,limits=['Identity-qualified author prefix only. Own measurement and actual received messages, no extra sensor sampling or production changes.','Ledger provenance must be reconstructed against captured own hit array before interpreting causes.','No ghost-wall or peer/pose attribution assumed in advance.'])
'''+s[end:]
ast.parse(s);(F/'run_provenance.py').write_text(s);print('Same-prefix provenance driver ready, no new controller')
