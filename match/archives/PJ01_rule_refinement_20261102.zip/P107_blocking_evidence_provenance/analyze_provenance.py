from pathlib import Path
from collections import Counter
import json,math,hashlib,datetime
import numpy as np
from PIL import Image
F=Path(__file__).resolve().parent;dest=F/'EVIDENCE_ORIGIN_FIRST.json';assert not dest.exists()
review=json.loads((F/'RESULT_FIRST.json').read_text());assert all(review['identity_checks'].values())
pre=json.loads((F/'PREDECLARATION_FIRST.json').read_text());p=F/(pre['label']+'.json');d=json.loads(p.read_text());snap=d['provenance_contexts'][0];ctx=d['event_contexts'][0];shape=tuple(snap['hit_shape']);size=math.prod(shape)
ledger={};last={};birth={};global_births={};raw={x['sequence']:x for x in d['raw_observations']}
for e in d['ledger_events'][:snap['ledger_cut']]:
 owner=e['owner'];a=ledger.setdefault(owner,np.zeros(size,np.uint8));l=last.setdefault(owner,{});b=birth.setdefault(owner,{})
 ids=np.asarray(e['ids'],int);before=np.asarray(e['old'],np.uint8);after=np.asarray(e['new'],np.uint8)
 assert np.array_equal(a[ids],before),'Unaccounted hit writes; do not interpret source'
 for cell,old,new in zip(ids,before,after):
  cell=int(cell);meta={k:e[k]for k in ['sequence','owner','step','kind','metadata']}
  l[cell]=meta
  if new>=2 and old<2:b[cell]=meta;global_births.setdefault(cell,[]).append(meta)
  elif new<2:b.pop(cell,None)
 a[ids]=after
captured=np.zeros(size,np.uint8);captured[np.asarray(snap['hit_ids'],int)]=snap['hit_values'];owner=snap['owner'];assert np.array_equal(ledger[owner],captured)
row,col=ctx['start'];sample=np.array([(row+.5)*snap['CELL']/snap['FINE'],(col+.5)*snap['CELL']/snap['FINE']]).astype(int)
stable=np.flatnonzero(captured>=2);rr,cc=np.unravel_index(stable,shape);dist=np.hypot(np.maximum(0,np.abs(rr-sample[0])-1),np.maximum(0,np.abs(cc-sample[1])-1))*snap['FINE'];selected=stable[dist<=snap['CELL']*2]
parent=np.asarray(Image.open(F/'AUTHOR_EVENT64_PARENT_FIRST.png'))>0;image=np.asarray(Image.open(F/'AUTHOR_EVENT64_BEARING_FIRST.png'))>0
sources=[]
for cell in selected:
 cell=int(cell);r,c=np.unravel_index(cell,shape);birth_record=birth[owner][cell];candidates=[]
 for origin in global_births.get(cell,[]):
  if origin['kind']!='OBSERVE':continue
  for raw_id in origin['metadata'].get('raw_sequences',[]):
   event=raw[raw_id]
   if cell not in event['changed_ids']:continue
   ranges=np.asarray(event['distances']);angles=np.asarray(event['angles']);excluded=np.asarray(event['excluded'],bool);theta=angles+event['heading'];pose=np.asarray(event['position']);ends=pose+np.column_stack((np.cos(theta),np.sin(theta)))*ranges[:,None]
   rayr=np.floor((snap['height']/2-ends[:,1])/snap['FINE']).astype(int);rayc=np.floor((ends[:,0]+snap['width']/2)/snap['FINE']).astype(int)
   rays=np.flatnonzero((rayr==r)&(rayc==c)&~excluded&(ranges>8)&(ranges<220))
   candidates.append(dict(owner=origin['owner'],step=origin['step'],ledger_sequence=origin['sequence'],position=event['position'],heading=event['heading'],matching_rays=[dict(index=int(i),distance=float(ranges[i]),angle=float(angles[i]),endpoint=ends[i].tolist())for i in rays],semantic=event['semantic']))
 pixelr,pixelc=int(r*snap['FINE']),int(c*snap['FINE']);band=2
 sources.append(dict(fine_id=cell,fine_rc=[int(r),int(c)],world=[float(c*snap['FINE']-snap['width']/2),float(snap['height']/2-r*snap['FINE'])],hit_count=int(captured[cell]),dilated_clearance_distance=float(np.hypot(max(0,abs(r-sample[0])-1),max(0,abs(c-sample[1])-1))*snap['FINE']),current_lifetime_birth=birth_record,last_update=last[owner][cell],global_observe_birth_candidates=candidates,parent_pixels_near=int(parent[max(0,pixelr-band):pixelr+band+1,max(0,pixelc-band):pixelc+band+1].sum()),bearing_pixels_near=int(image[max(0,pixelr-band):pixelr+band+1,max(0,pixelc-band):pixelc+band+1].sum())))
sources.sort(key=lambda s:(s['dilated_clearance_distance'],s['fine_id']))
origin_counts=Counter(x['current_lifetime_birth']['kind']for x in sources);nearest=sources[0]if sources else None
out=dict(status='COMPLETE_EXACT_OWN_HIT_LEDGER_RECONSTRUCTION',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),input_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),full_current_own_hit_array_matches_ledger=True,owner=owner,step=ctx['step'],start=ctx['start'],own_pose=ctx['pose'],coarse_sample_fine_rc=sample.tolist(),original_clearance=float(ctx['clearance'][row][col]),all_stable_evidence_within32px=sources,current_birth_kinds=dict(origin_counts),nearest_dilated_support=nearest,anchor_events=d['anchor_events'],controller_changes=0,native_rounds=0,limits=['A merge birth is the last causal channel into this instance, not proof of the original physical source of the return.','Global own-observation candidates are from separate public author streams and may include coincident cells; only exact ray/cell matches are listed, not invented packet ancestry.','Corrected render pixels and raw path clearance are distinct layers. Neither is treated as author truth here.','No policy mutation or extra public sensor calls; outputs frozen and prefix identity checked.'])
dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status=out['status'],ledger_match=True,stable_nearby=len(sources),birth_kinds=dict(origin_counts),nearest=nearest,anchors=len(d['anchor_events']))))
