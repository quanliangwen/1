from pathlib import Path
import ast,subprocess,json,time,datetime,hashlib
import numpy as np
F=Path(__file__).resolve().parent;R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P107_blocking_evidence_provenance_20261102';ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60'];utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def remote(code):return subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=code.encode(),capture_output=True)
def keep(name,p):
 dest=F/(name+'.capture.txt');assert not dest.exists();dest.write_bytes(p.stdout+p.stderr);print(p.stdout.decode(errors='replace')[-1000:],flush=True)
 if p.returncode:raise RuntimeError('Keep first prefix diagnostic error '+name)
def fetch(name):subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+name,str(F/name)],check=True)
def main():
 assert not(F/'STARTED_FIRST.json').exists();pre=json.loads((F/'PREDECLARATION_FIRST.json').read_text());assert sha(F/'check_sdk_hit_provenance.py')==pre['source_sha256']
 guard=Path('E:/codex/UAV_rules_astar_restart_20261030/R154_scoped_serial_guard_20261101/check_scoped_serial.py').read_text();keep('SERIAL_FIRST',remote(guard));keep('MKDIR_FIRST',remote('from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n'))
 (F/'STARTED_FIRST.json').write_text(json.dumps(dict(utc=utc(),finite_hours=14,readonly=True,native_rounds=0),indent=2)+'\n')
 for name in ['check_sdk_hit_provenance.py','WORKSPACE_READY.json','PREDECLARATION_FIRST.json']:
  subprocess.run(['scp','-q',str(F/name),'junhao@10.112.162.60:'+D+'/'],check=True)
 subprocess.run(['scp','-q','E:/codex/UAV_rules_astar_restart_20261030/run_sdk_captured.py','junhao@10.112.162.60:'+D+'/'],check=True)
 old=Path('E:/codex/PJ01_environment_restore_20261101/P35_continuation_after_parent_repair/run_offline.py').read_text();methods='\n'.join(ast.get_source_segment(old,n)for n in ast.parse(old).body if isinstance(n,ast.FunctionDef)and n.name in ['cpu_sample','resource'])
 capacity='from pathlib import Path\nimport os,time,shutil,json,datetime\nR=Path('+repr(R)+')\nD=json.loads((R/"solver_study/framework_screen_20261016/best87_independent_20261025/P37_phase_five_comparison_20261101/PREDECLARATION.json").read_text())\ndef utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()\n'+methods+'\nprint(json.dumps(resource()))\n'
 deadline=time.monotonic()+14*3600;consecutive=[];count=0
 while time.monotonic()<deadline:
  if(F/'STOP_REQUESTED').exists():raise RuntimeError('Human stop')
  count+=1;p=remote(capacity);keep('CAPACITY_'+str(count)+'_FIRST',p);row=json.loads(p.stdout);consecutive=consecutive+[row]if row['clean']else[]
  (F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='WAITING_ORIGINAL_CAPACITY',resource=row),indent=2)+'\n')
  if len(consecutive)>=2:break
  time.sleep(60)
 else:raise TimeoutError('Finite prefix wait expired')
 (F/'RESOURCE_TWO_SAMPLE_FIRST.json').write_text(json.dumps(consecutive,indent=2)+'\n');keep('BEFORE_PREFIX_SERIAL_FIRST',remote(guard));label=pre['label']
 (F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status='RUNNING_SAME_FAILED64_PREFIX',native_rounds=0),indent=2)+'\n')
 keep(label,subprocess.run(ssh+[R+'/.venv/bin/python',D+'/run_sdk_captured.py',D+'/check_sdk_hit_provenance.py',label,'P105',pre['case'],str(pre['horizon']),str(pre['wall_rate'])],capture_output=True));fetch(label+'.json')
 c=json.loads((F/(label+'.json')).read_text());pfile=Path(pre['retained_prefix']);assert sha(pfile)==pre['retained_prefix_sha256'];p=json.loads(pfile.read_text());n=pre['prefix_frames']
 checks=dict(all64_rows_identical=c['rows']==p['rows'][:n],event_queries_identical=c['event_queries']==[e for e in p['event_queries']if e['step']<=n],issued_arms_identical=c['issued_arms']==[e for e in p['issued_arms']if e['step']<=n],source_identical=c['source_sha256']==p['source_sha256'],exactly_first_event_context=len(c['event_contexts'])==1 and c['event_contexts'][0]['step']==64,expected64=c['physics_steps']==64,all5_prefix_maps_identical=c['map_results']==p['map_results'],exact_current_graph=c['event_contexts']==p['event_contexts'],one_actual_provenance=len(c['provenance_contexts'])==1)
 if not all(checks.values()):
  (F/'IDENTITY_FAILURE_FIRST.json').write_text(json.dumps(checks,indent=2)+'\n');raise RuntimeError('Prefix input mismatch, do not interpret reference')
 for name in ['AUTHOR_EVENT64_BEARING_FIRST.png','AUTHOR_EVENT64_PARENT_FIRST.png']:fetch(name)
 report=dict(status='COMPLETE_SAME_PREFIX_OWN_HIT_PROVENANCE',utc=utc(),identity_checks=checks,ledger_events=len(c['ledger_events']),raw_observations=len(c['raw_observations']),anchor_events=len(c['anchor_events']),controller_changes=0,native_rounds=0,not_performance=True,limits=['Identity-qualified author prefix only. Own measurement and actual received messages, no extra sensor sampling or production changes.','Ledger provenance must be reconstructed against captured own hit array before interpreting causes.','No ghost-wall or peer/pose attribution assumed in advance.'])
 (F/'RESULT_FIRST.json').write_text(json.dumps(report,indent=2)+'\n');(F/'STATUS.json').write_text(json.dumps(dict(utc=utc(),status=report['status'],native_rounds=0),indent=2)+'\n');print(json.dumps(report),flush=True)
if __name__=='__main__':
 try:main()
 except Exception:
  import traceback
  (F/'FIRST_ERROR.json').write_text(json.dumps(dict(utc=utc(),traceback=traceback.format_exc(),no_retry=True),indent=2)+'\n');raise
