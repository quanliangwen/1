from pathlib import Path
import ast,json,hashlib,datetime
F=Path(__file__).resolve().parent;P=F.parent/'P106_goal_preserving_repair_reference';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not(F/'PREDECLARATION_FIRST.json').exists();s=(P/'check_same_failed_prefix.py').read_text();s=s.replace(s.splitlines()[0],'"""Passive own-hit provenance on the identical failed prefix64; no algorithm changes or new score."""')
needle='TRACE_ENABLED=False\n';assert s.count(needle)==1
observer='''TRACE_ENABLED=False
from swarm_rescue.solutions.bearing_memory import BearingMemory
from swarm_rescue.solutions.greedy_mapping import MapMemory
from swarm_rescue.solutions.boundary_anchor import ObservedBoundaryAnchor
ledger_events=[];raw_observations=[];anchor_events=[];tracked_hits={};own_instances={};provenance_contexts=[]
def ledger(mem,kind,metadata):
 key=id(mem);previous=tracked_hits.get(key)
 if previous is None:previous=np.zeros_like(mem.hits)
 ids=np.flatnonzero(previous.ravel()!=mem.hits.ravel())
 if len(ids):
  ledger_events.append(dict(sequence=len(ledger_events),owner=int(mem.identifier),step=int(mem.step),kind=kind,metadata=metadata,ids=ids.tolist(),old=previous.ravel()[ids].tolist(),new=mem.hits.ravel()[ids].tolist()))
 tracked_hits[key]=mem.hits.copy()
raw_core_observe=MapMemory.observe
def observe_core(mem,position,heading,distances,angles,semantic=()):
 before=mem.hits.copy();result=raw_core_observe(mem,position,heading,distances,angles,semantic)
 changed=np.flatnonzero(before.ravel()!=mem.hits.ravel());excluded=mem.semantic_mask(np.asarray(distances),np.asarray(angles),semantic)
 raw_observations.append(dict(sequence=len(raw_observations),owner=int(mem.identifier),step=int(mem.step),position=np.asarray(position).tolist(),heading=float(heading),distances=np.asarray(distances).tolist(),angles=np.asarray(angles).tolist(),excluded=excluded.tolist(),semantic=[dict(kind=getattr(getattr(o,'entity_type',None),'name',''),angle=float(o.angle),distance=float(o.distance))for o in semantic or ()],changed_ids=changed.tolist(),old=before.ravel()[changed].tolist(),new=mem.hits.ravel()[changed].tolist()))
 return result
MapMemory.observe=observe_core
raw_outer_observe=BearingMemory.observe
def observe_outer(mem,*args,**kwargs):
 ledger(mem,'PRE_OBSERVE_RESIDUAL',{})
 result=raw_outer_observe(mem,*args,**kwargs)
 rawids=[r['sequence']for r in raw_observations if r['owner']==int(mem.identifier)and r['step']==int(mem.step)]
 ledger(mem,'OBSERVE',dict(raw_sequences=rawids))
 return result
BearingMemory.observe=observe_outer
raw_outer_merge=BearingMemory.merge
def observe_merge(mem,packet):
 ledger(mem,'PRE_MERGE_RESIDUAL',{})
 own=own_instances.get(id(mem));senders=[]
 if own is not None:
  for _,msg in own.communicator.received_messages:
   if isinstance(msg,dict)and msg.get('map')is packet:senders.append(dict(sender=msg.get('id'),sent=msg.get('step')))
 result=raw_outer_merge(mem,packet);ledger(mem,'MERGE',dict(actual_received_headers=senders))
 return result
BearingMemory.merge=observe_merge
raw_correct=ObservedBoundaryAnchor.correct
def observe_correct(anchor,lines,position,heading,step):
 before=np.asarray(position).copy();result=raw_correct(anchor,lines,position,heading,step)
 own=next((d for d in own_instances.values()if d.boundary_anchor is anchor),None)
 anchor_events.append(dict(owner=None if own is None else int(own.identifier or 0),step=int(step),before=before.tolist(),after=np.asarray(result[0]).tolist(),heading_before=float(heading),heading_after=float(result[1])))
 return result
ObservedBoundaryAnchor.correct=observe_correct
'''
s=s.replace(needle,observer)
needle="  event_contexts.append(dict(owner=int(d.identifier or 0),step=int(step),last_plan_step=int(before),pose=np.asarray(d.pose).tolist(),goal=None if d.goal is None else np.asarray(d.goal).tolist(),waypoints=[np.asarray(p).tolist()for p in d.waypoints],start=list(d.memory.world_to_cell(d.pose)),goal_cell=None if d.goal is None else list(d.memory.world_to_cell(d.goal)),allowed=allowed.astype(int).tolist(),clearance=clearance.tolist(),own_only=True))"
extra='''
  ledger(d.memory,'PRE_EVENT_RESIDUAL',{})
  ids=np.flatnonzero(d.memory.hits.ravel());image,parent=d.memory.bearing_fields()
  import cv2
  for name,img in [('AUTHOR_EVENT64_BEARING_FIRST.png',image),('AUTHOR_EVENT64_PARENT_FIRST.png',parent)]:
   assert not(F/name).exists();assert cv2.imwrite(str(F/name),(img>0).astype(np.uint8)*255)
  provenance_contexts.append(dict(owner=int(d.identifier or 0),step=int(step),ledger_cut=len(ledger_events),width=d.memory.width,height=d.memory.height,FINE=d.memory.FINE,CELL=d.memory.CELL,hit_shape=list(d.memory.hits.shape),hit_ids=ids.tolist(),hit_values=d.memory.hits.ravel()[ids].tolist(),render_sha256=hashlib.sha256(image.tobytes()).hexdigest(),parent_sha256=hashlib.sha256(parent.tobytes()).hexdigest()))'''
assert s.count(needle)==1;s=s.replace(needle,needle+extra)
needle='class MyDroneEval(Original):\n';assert s.count(needle)==1
s=s.replace(needle,needle+''' def control(self):
  result=super().control();ledger(self.memory,'CONTROL_RESIDUAL',{});return result
''')
needle='  result=super()._messages()\n';assert s.count(needle)==1;s=s.replace(needle,needle+"  ledger(self.memory,'AFTER_MESSAGES_RESIDUAL',{})\n")
needle='  pg.add(d,(p,0.));d.enable_bomb_deployer';assert s.count(needle)==1;s=s.replace(needle,'  own_instances[id(d.memory)]=d\n'+needle)
needle='event_contexts=event_contexts,event_queries=event_queries,';assert s.count(needle)==1
s=s.replace(needle,'ledger_events=ledger_events,raw_observations=raw_observations,anchor_events=anchor_events,provenance_contexts=provenance_contexts,event_contexts=event_contexts,event_queries=event_queries,')
ast.parse(s);(F/'check_sdk_hit_provenance.py').write_text(s);(F/'WORKSPACE_READY.json').write_bytes((P/'WORKSPACE_READY.json').read_bytes())
old=json.loads((P/'PREDECLARATION_FIRST.json').read_text());old.update(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=sha(F/'check_sdk_hit_provenance.py'),retained_prefix=str(P/'SAME_FAILED_PREFIX64_FIRST.json'),retained_prefix_sha256=sha(P/'SAME_FAILED_PREFIX64_FIRST.json'),label='SAME_FAILED_PROVENANCE64_FIRST',scope='Same failed source/prefix actions; passive own observe/merge/anchor deltas. All64 rows/events/arms/source/5raw maps identical before interpreting origin. No extra sensor sample, no production change, no native/performance retry.')
old.pop('reference_method_sha256',None)
(F/'PREDECLARATION_FIRST.json').write_text(json.dumps(old,indent=2)+'\n');print('Own evidence provenance source frozen; no SDK started')
