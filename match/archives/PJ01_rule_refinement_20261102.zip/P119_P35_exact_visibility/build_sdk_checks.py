from pathlib import Path
import ast,json,hashlib,datetime
F=Path(__file__).resolve().parent;P=F.parent/'P113_P112_actual_coverage_validation';T=F.parent/'P117_P35_spatial_frame_retention';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not(F/'PREDECLARATION_FIRST.json').exists();assert json.loads((F/'COMPLETE_ROUTE_CONTRACT_FIRST.json').read_text())['status']=='PASS_ACTUAL_COMPLETE_ROUTE_VISIBILITY_CONTRACT'
s=(P/'check_sdk_actual_coverage.py').read_text();s=s.replace(s.splitlines()[0],'"""First P48+exact visibility small SDK closure; actual wall/map/time evaluated only after outputs freeze."""')
needle='gate_events=[];gate_stack={};route_details=[]';assert s.count(needle)==1
audit='''visibility_events=[]
raw_visible=CoordinatedMapMemory._visible
def audit_visible(self,start,end,walkable):
 result=raw_visible(self,start,end,walkable)
 rr,cc=self._line_cells(start,end);old=bool(np.all(walkable[rr,cc]))
 if result and not old:raise AssertionError('Exact visible unexpectedly accepts a sampled-blocked segment')
 if old and not result:visibility_events.append(dict(owner=int(self.identifier),step=int(self.step),start=list(start),end=list(end),original_sampled_accept=old,candidate_accept=bool(result)))
 return result
CoordinatedMapMemory._visible=audit_visible

'''
s=s.replace(needle,audit+needle).replace('coverage_evaluation=coverage_evaluation,projection_events=projection_events,','visibility_events=visibility_events,coverage_evaluation=coverage_evaluation,projection_events=projection_events,');ast.parse(s);(F/'check_sdk_visibility.py').write_text(s)
pre=json.loads((T/'PREDECLARATION_FIRST.json').read_text());pre.update(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=sha(F/'check_sdk_visibility.py'),manifest_sha256=sha(F/'CANDIDATE_MANIFEST_FIRST.json'),method_check_sha256=sha(F/'COMPLETE_ROUTE_CONTRACT_FIRST.json'),preflight_sha256=sha(F/'MECHANISM_PREFLIGHT_FIRST.json'),rule='Only exact crossed-cell check in the existing path smoother, independent original P48. P117/P112 are not stacked.',gate='First failure stops all remaining cases without seed/label/threshold rescue. Actual10bombs, actual submission, original health/physical callbacks and wall limits, map/wall/time/subtotal each nonregress vs retained/fresh original baseline. Exact visibility must actually reject sampled-accepted segments. No new sampled-blocked segment may become accepted. Both cases must pass, one subtotal gain >=0.30 to consider qualification/native single; no automatic native/five.',maximum_author_missions=3)
for c in pre['cases']:
 c['candidate_label']=c['code']+'_P119_EXACT_VISIBILITY_FIRST'
 if not c['retained_parent']:c['parent_label']='URGENT_P48_VISIBILITY_BASELINE_FIRST'
(F/'PREDECLARATION_FIRST.json').write_text(json.dumps(pre,indent=2)+'\n')
driver=(T/'run_sdk_checks.py').read_text().replace('PJ01_rules_P117_P35_spatial_frame_retention_20261102','PJ01_rules_P119_P35_exact_visibility_20261102').replace('check_sdk_retention.py','check_sdk_visibility.py').replace('ACTUAL_METHOD_CHECK_FIRST.json','COMPLETE_ROUTE_CONTRACT_FIRST.json').replace("['P117']","['P119']").replace("('P117','candidate_label')","('P119','candidate_label')").replace("outputs['P117']","outputs['P119']").replace("candidate['frame_retention_events']","candidate['visibility_events']")
start=driver.index('actual_cull=bool(events)');end=driver.index('\n  delta=',start)
driver=driver[:start]+"actual_changed_visibility=bool(events),visibility_contract=all(e['original_sampled_accept']and not e['candidate_accept']for e in events))"+driver[end:]
driver=driver.replace('cull_events=len(events),spatial_cull_events=sum(e[\'spatial_additions\']>0 for e in events),max_kept=max((e[\'after_count\']for e in events),default=0)',"visibility_rejections=len(events)")
driver=driver.replace('RETENTION','VISIBILITY').replace('retention','visibility')
ast.parse(driver);assert "'P117'"not in driver and'frame_retention_events'not in driver
(F/'run_sdk_checks.py').write_text(driver)
prep=(T/'prepare_workspace.py').read_text().replace('workspace_P117','workspace_P119').replace("'P117'","'P119'");ast.parse(prep);(F/'prepare_workspace.py').write_text(prep)
print('Frozen visibility source/protocol/driver; same original baselines, max3 author missions, no automatic native')
