"""Actual complete memory classes and route method, NumPy/CV only, no SDK."""
from pathlib import Path
from types import SimpleNamespace
from fractions import Fraction
import ast,json,hashlib,copy,math,heapq,time,datetime
import numpy as np
import cv2
F=Path(__file__).resolve().parent;dest=F/'COMPLETE_ROUTE_CONTRACT_FIRST.json';assert not dest.exists();decl=json.loads((F/'CANDIDATE_MANIFEST_FIRST.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();C=F/'candidate_project';assert all(sha(C/n)==h for n,h in decl['candidate_files'].items())
meta=json.loads((F.parent/'PJ01_rules_P117_P35_spatial_frame_retention_20261102/WORKSPACE_READY.json').read_text())['versions']['P48Reference'];B=Path(meta['workspace']);assert meta['sources']==decl['parent_files']and all(sha(B/n)==h for n,h in meta['sources'].items())
def classes(root):
 env=dict(np=np,cv2=cv2,math=math,heapq=heapq)
 for name,cls in [('greedy_mapping.py','MapMemory'),('fast_exploration.py','CoordinatedMapMemory')]:
  s=(root/'src/swarm_rescue/solutions'/name).read_text();node=next(n for n in ast.parse(s).body if isinstance(n,ast.ClassDef)and n.name==cls)
  exec(compile(ast.Module(body=[node],type_ignores=[]),'actual_'+cls,'exec'),env)
 return env['CoordinatedMapMemory']
Old,New=classes(B),classes(C)
review=F.parent/'PJ01_rules_P115_render_regression_timeline_20261102'
def cover(a,b):
 r,c=map(int,a);er,ec=map(int,b);dr,dc=abs(er-r),abs(ec-c);sr=0 if r==er else 1 if er>r else-1;sc=0 if c==ec else 1 if ec>c else-1;cells={(r,c)};nr=nc=0
 while(r,c)!=(er,ec):
  if r==er:kind=1
  elif c==ec:kind=-1
  else:
   l=(2*nr+1)*dc;u=(2*nc+1)*dr;kind=-1 if l<u else 1 if l>u else 0
  if kind==0:cells|={(r+sr,c),(r,c+sc)}
  if kind<=0:r+=sr;nr+=1
  if kind>=0:c+=sc;nc+=1
  cells.add((r,c))
 return cells
def slab(a,b,cell):
 lo,hi=Fraction(0),Fraction(1)
 for x,y,k in zip(a,b,cell):
  start=2*x;delta=2*(y-x)
  if delta==0:
   if not 2*k-1<=start<=2*k+1:return False
  else:
   u,v=Fraction(2*k-1-start,delta),Fraction(2*k+1-start,delta);lo=max(lo,min(u,v));hi=min(hi,max(u,v))
   if lo>hi:return False
 return True
start=time.perf_counter();test=New(112,112);oracle_checks=0
for a in [(1,1),(1,4),(3,2),(4,4)]:
 for b in [(r,c)for r in range(1,6)for c in range(1,6)]:
  exact={(r,c)for r in range(7)for c in range(7)if slab(a,b,(r,c))};assert exact==cover(a,b)
  for blocked in [(r,c)for r in range(7)for c in range(7)]:
   m=np.ones((7,7),bool);m[blocked]=False
   assert test._visible(a,b,m)==(blocked not in exact)
   oracle_checks+=1
assert not test._visible((-1,0),(3,3),np.ones((7,7),bool))
fixtures=[]
for kind in ['open','vertical_barrier','gap_wall','corner','unknown_partition','small_box']:
 m=Old(320,240);m.free[:]=True
 if kind=='vertical_barrier':cv2.line(m.hits,(80,12),(80,105),8,2)
 elif kind=='gap_wall':cv2.line(m.hits,(80,0),(80,40),8,2);cv2.line(m.hits,(80,80),(80,119),8,2)
 elif kind=='corner':cv2.line(m.hits,(80,20),(80,80),8,2);cv2.line(m.hits,(80,80),(130,80),8,2)
 elif kind=='unknown_partition':m.free[:,10:]=False
 elif kind=='small_box':cv2.rectangle(m.hits,(70,45),(90,65),8,2)
 fixtures.append((kind,m,np.array([-100.,-40.])))
def unpack(v):
 a=np.zeros(v['shape'],np.dtype(v['dtype']));a.ravel()[v['ids']]=v['values'];return a
for owner in [0,1]:
 for step in [300,360,556]:
  snap=json.loads((review/('AUTHOR_OWN_'+str(owner)+'_STEP_'+str(step)+'.json')).read_text());m=Old(snap['width'],snap['height'],identifier=owner)
  for key in ['hits','free','visits']:setattr(m,key,unpack(snap[key]))
  own=[r for r in snap['frame_records']if r[0]==owner];assert own;pose=np.asarray(max(own,key=lambda r:r[1])[3],float)
  fixtures.append(('own_'+str(owner)+'_'+str(step),m,pose))
cases=[]
for label,template,pose in fixtures:
 for mode in ['ordinary','utility','destination']:
  memories=[];routes=[];goals=[];preserved=[]
  for cls in [Old,New]:
   m=cls(template.width,template.height,identifier=template.identifier,team_size=5)
   for key in ['hits','free','visits']:setattr(m,key,getattr(template,key).copy())
   before=[getattr(m,key).copy()for key in ['hits','free','visits']]
   kwargs={}
   if mode=='utility':kwargs['utility']=np.arange(np.prod(m.shape),dtype=float).reshape(m.shape)+1
   if mode=='destination':kwargs['destination']=np.array([100.,60.])
   route,goal=m.route(pose,**kwargs);memories.append(m);routes.append(route);goals.append(goal);preserved.append(all(np.array_equal(a,getattr(m,k))for a,k in zip(before,['hits','free','visits'])))
  m=memories[1];walkable=(cv2.morphologyEx(m.free.astype(np.uint8),cv2.MORPH_CLOSE,np.ones((3,3),np.uint8)).astype(bool)|m.free)&~m.blocked();s=m.world_to_cell(pose);walkable[s]=True
  pts=[s]+[m.world_to_cell(p)for p in routes[1]]
  safe=all(all(walkable[cell]for cell in cover(a,b))for a,b in zip(pts,pts[1:]));same_goal=(goals[0]is None and goals[1]is None)or(goals[0]is not None and goals[1]is not None and np.array_equal(goals[0],goals[1]))
  oldpts=[s]+[m.world_to_cell(p)for p in routes[0]];old_safe=all(all(walkable[cell]for cell in cover(a,b))for a,b in zip(oldpts,oldpts[1:]))
  checks=dict(goal_identical=same_goal,all_new_segments_cover_only_walkable=safe,input_arrays_unchanged=all(preserved),finite_waypoints=all(np.isfinite(p).all()for p in routes[1]))
  cases.append(dict(fixture=label,mode=mode,checks=checks,original_supercover_safe=old_safe,original_waypoints=len(routes[0]),candidate_waypoints=len(routes[1]),route_changed=not np.array_equal(np.asarray(routes[0]),np.asarray(routes[1]))));assert all(checks.values()),cases[-1]
out=dict(status='PASS_ACTUAL_COMPLETE_ROUTE_VISIBILITY_CONTRACT',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),oracle_blocked_cell_checks=oracle_checks,cases=cases,changed_routes=sum(e['route_changed']for e in cases),original_routes_with_missed_cells=sum(not e['original_supercover_safe']for e in cases),numeric_seconds=time.perf_counter()-start,candidate_source_sha256=decl['candidate_files']['src/swarm_rescue/solutions/fast_exploration.py'],SDK_imports=0,SDK_frames=0,native_rounds=0,limits=['Full actual base memory+route classes, not a synthetic substitute for the planner.','Own snapshot arrays are complete, but default exploration attributes and recorded own pose are explicit numerical inputs, not a replay of the original entire controller state.','Grid-collision consistency is not a guarantee against physical collisions with noisy maps, moving teammates or finite braking.','A safe longer path could reduce scores; actual closed-loop comparison is still required.'])
dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status=out['status'],oracle_checks=oracle_checks,cases=len(cases),changed_routes=out['changed_routes'],original_missed=out['original_routes_with_missed_cells'],numeric_seconds=out['numeric_seconds'])))
