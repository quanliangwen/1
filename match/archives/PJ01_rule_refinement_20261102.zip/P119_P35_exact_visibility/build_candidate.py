from pathlib import Path
import ast,json,hashlib,shutil,datetime
F=Path(__file__).resolve().parent;B=Path('E:/codex/PJ01_rule_refinement_20261101/P48_P35_refresh_deferral_candidate');P=B/'candidate_project';C=F/'candidate_project';assert not C.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((B/'CANDIDATE_MANIFEST_FIRST.json').read_text());assert all(sha(P/n)==h for n,h in old['candidate_files'].items())
evidence=F.parent/'P118_smoothing_grid_contract_diagnosis/RECORDED_SEGMENT_REVIEW_FIRST.json';review=json.loads(evidence.read_text());assert review['summary']['plans_with_additional_nonwalkable_cells']==50
shutil.copytree(P,C,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git'));p=C/'src/swarm_rescue/solutions/fast_exploration.py';s=p.read_text();cl=next(n for n in ast.parse(s).body if isinstance(n,ast.ClassDef)and n.name=='CoordinatedMapMemory');node=next(n for n in cl.body if isinstance(n,ast.FunctionDef)and n.name=='_visible');original=ast.get_source_segment(s,node)
replacement='''def _visible(self, start, end, walkable):
        # Traverse every crossed coarse cell. On a vertex include both
        # orthogonal cells, matching the unchanged graph no-corner-cut rule.
        r,c=map(int,start);er,ec=map(int,end)
        height,width=walkable.shape
        if not(0<=r<height and 0<=er<height and 0<=c<width and 0<=ec<width):return False
        if not walkable[r,c]:return False
        dr,dc=abs(er-r),abs(ec-c)
        sr=0 if r==er else 1 if er>r else -1
        sc=0 if c==ec else 1 if ec>c else -1
        nr=nc=0
        while (r,c)!=(er,ec):
            if r==er:kind=1
            elif c==ec:kind=-1
            else:
                left=(2*nr+1)*dc;right=(2*nc+1)*dr
                kind=-1 if left<right else 1 if left>right else 0
            if kind==0 and (not walkable[r+sr,c] or not walkable[r,c+sc]):return False
            if kind<=0:r+=sr;nr+=1
            if kind>=0:c+=sc;nc+=1
            if not walkable[r,c]:return False
        return True'''
assert s.count(original)==1;s=s.replace(original,replacement);ast.parse(s);p.write_text(s)
files={f.relative_to(C).as_posix():sha(f)for f in C.rglob('*')if f.is_file()};diff=[n for n in sorted(files.keys()|old['candidate_files'].keys())if files.get(n)!=old['candidate_files'].get(n)];assert diff==['src/swarm_rescue/solutions/fast_exploration.py']
out=dict(status='FROZEN_ONE_EXACT_SMOOTHING_VISIBILITY_RULE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent=str(P),parent_files=old['candidate_files'],candidate_files=files,differences=diff,rule='Only CoordinatedMapMemory._visible: exact integer grid traversal including both side cells on vertex ties. The existing search graph, no-corner-cut constraint, goal selection, path smoothing procedure and every mask remain unchanged. This is model-consistency checking, not extra inflation or a new planner.',evidence=str(evidence),evidence_sha256=sha(evidence),conceptual_history_review=['Original code already string-pulls, so adding path smoothing itself is not new.','P68 fixed-goal repair and P73 clearance lowering change graph/path refresh; not included.','P52 inventory cache already tested and lost health, not retried.','P117 bounded frame retention actual12culls across2cases, all rows/maps identical, no gain; not stacked.','P112 grid alignment rejected; not stacked.'],references=['https://www.eecs.yorku.ca/~amana/research/grid.pdf','https://api.nav2.org/actions/jazzy/smoothpath.html'],unchanged=['raw sensing/frame/bearing/rendering/map exchange','P35 phases/P48 model refresh/goal utility','Dijkstra graph costs and targets','all global replanning clocks and lidar motor','geometry fallback visibility method','SDK/req/threads/limits'],req_unchanged=(P/'req.txt').read_bytes()==(C/'req.txt').read_bytes(),native_rounds=0,official_submission=False)
(F/'CANDIDATE_MANIFEST_FIRST.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status=out['status'],differences=diff)))
