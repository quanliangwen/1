from pathlib import Path
import json,datetime
F=Path(__file__).resolve().parent;P=F.parent/'P01_baseline_rules';now=datetime.datetime.now(datetime.timezone.utc).isoformat()
text='''用户最新方向（优先于R189..194及P01新视野规则）：以PJ01为底本，首先移植过去试验中有实测证据的有效规则，逐条加入，不成套换框架或盲目五图。

已核对底本：P01/baseline_project的36个Python文件与已首次客户端核验的F32/PJ01_A source_hashes逐一一致。历史原五图地图均93.2310，完整红分均72.9773；作者构造五机场景R193地图71.2095并非同一组地图，不可直接比较或混为五图均分。

有效性分类与顺序：
1. 第一项P02：终点一致性。F44/J03真实Map03记录48次16..35.78px规划端点纠正、全5机12个owner-target组合、10/10投放无超时。此次只复制当时已实测的geometry_navigation.py（SHA13f5a065daa6216f5d0ab2160d4980f2d629542608e55dd5c16efcfa4c449e9e），PJ01其余35个Python/依赖/映射/融合/运动/布点/退出全部不变。没有移植J03的MILP或精确小库存核心。PJ01已有FleetEndpointRepair会将部分偏差点换成新目标，因此旧实测收益不能直接算作PJ01增益，需新对照。
2. 探索与执行预算：R190作者单机场景实际触发并改善地图/墙分，但它的68步库存模型和16步检查周期属于另一控制器。PJ01已有TerminalValue和路线预算，不能照搬常数，须先核实际决策周期/剩余路线再决定下一条。
3. 目标保留、实际库存确认、墙面补扫等：PJ01原本已包含对应模块，先验证缺口再改，不能把同一规则重复叠一遍称升级。
4. 最短路复用有纯计算正确性/微基准依据，但缺直接整场提分证据，暂不排在当前真实端点契约之前。
5. P01预测视野去重仅18项纯检查和真实Memory构造验证，尚无实赛有效性证据，按用户要求暂缓，不进入P02。
失败/无收益候选如J04最终交换、R182墙点隔离、R184/185未触发运动条件均不套用。R193让行交接仅作者9/10仍失败且PJ01无同样协议，不移植。

P02新底本小检查：原PJ01与单文件修复分别调用真实路由类做10场景对照。5个孤立返回例原终点偏差22.627/32px，修后0；干净例不变；长墙/未知/边界3个反例仍拒绝；原有填满二维命中块的几何模型盲点保留，不能声称物理安全已证明。两版真实NumPy随机扩展/Pandas/OpenCV运算、SDK Launcher/Stats、整数615、原Map01五机构造与独立hits内存通过，物理步数0。

后续仅本轮Map01原版PJ01→P02各一红一蓝，共4native。原SDK e2f022b、原team006、原时限/线程、无外部seed、CPU60/loadcore.4/RAM8GiB/盘12GiB/两次60秒不变；首次真实native失败停链不重试。先各组一次Windows原始字节核验，再看完整红分、地图/墙/时间、投放、双方超时与实际端点日志。不自动五图或晋级；单次无seed观察差不证明稳定因果。

已离线启动UTC03:24:14，服务器H/PJ01_rules_P02_endpoint_20261101/run_offline.py，coordinator2072843/start397380803；Windowscollector92196/UTC03:24:12，14h有限窗口。PID仅历史定位，核实时cmd/start及global锁/registry后行动，不能重复启动。当前预计先原资源两样本等待，启动不等于已有成绩。

旧无限goal与automation90仍PAUSED；C7原UTC04:05:07定时器及收集器已在用户暂停时核身份终止，未启动C7比赛，不恢复或追补。最新两次用户指示授权当前PJ01有限小试，不代表恢复旧R194或自动五图。正式V06/V07/V08不改，不交付/上传新比赛ZIP；服务器INTERNAL_RESEARCH_ONLY.zip只是冻结源内部包，不具官网发布资格。
'''
(F/'分析依据与逐条规则.txt').write_text(text,encoding='utf8')
idx=Path('E:/codex/swarm-eod-literature-analysis/CURRENT_ACTIVE_ANALYSIS.txt')
idx.write_text(f'''LATEST {now}: USER redirect toPJ01 base, proven rules FIRST, one at a time. Current {F}/分析依据与逐条规则.txt. P02 copies exact historically testedJ03geometryNavigation ONLY; originalPJ01other35Py/req/mapping/fusion/motion/layout/exit unchanged.10constructedrealroutecases positive5corrected22..32to0,3negativesreject,densemodelblindspotretained. BothserverABI/SDK/5constructorPASS0physics. FiniteMap01 PJ01_A thenP02_A max4native nowlaunched2072843/start397380803UTC03:24:14, Windowscollector92196launch03:24:12; originalresources, noseed, firstWindowsbytebarrier. DO NOTduplicate; getlatestSTATUS/RESULT/CAMPAIGN_CLIENT_REVIEW. Noautomaticfive/promotion. P01newvisibilityruleDEFERREDbylatestuser. Backgroundgoal/automation90remainPAUSED andC7cancelledbeforestart; currentnew scoped taskauthorized, notoldR194/cadenceresume.\n\n'''+idx.read_text(encoding='utf8'),encoding='utf8')
S=Path('E:/codex/UAV_rules_astar_restart_20261030/PERIODIC_FIVE_MAP_20261031/ROUND_SCHEDULE.json');d=json.loads(S.read_text(encoding='utf8'));assert d['status']=='PAUSED_BY_USER'
d['current_non_cadence_test']=dict(phase='PJ01_rules_P02_endpoint_20261101',status='NEW_SCOPED_USER_PJ01_ONE_RULE_MAP01_COMPARE_RUNNING_OR_WAITING',max_native_rounds=4,automatic_five=False,old_automation_resumed=False)
S.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(status='RECORDED_PJ01_PROVEN_RULE_FIRST_AND_FINITE_MAP01_QUEUE',utc=now),ensure_ascii=False))
