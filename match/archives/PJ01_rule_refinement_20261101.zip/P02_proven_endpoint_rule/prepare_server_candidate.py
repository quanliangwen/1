from pathlib import Path
import json,shutil,hashlib
F=Path(__file__).resolve().parent;H=F.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
old=read(H/'PJ01_rules_P01_20261101/WORKSPACE_READY.json');base=old['versions']['BASELINE'];P=Path(base['workspace']);assert all(sha(P/n)==v for n,v in base['sources'].items())
local=read(F/'CANDIDATE_MANIFEST.json');inp=F/'candidate_project';assert all(sha(inp/n)==v for n,v in local['files'].items())
W=P.parent/'pj01_rules_proven_endpoint_20261101';assert not W.exists();shutil.copytree(P,W,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git','.pytest_cache'))
shutil.copy2(inp/'src/swarm_rescue/solutions/geometry_navigation.py',W/'src/swarm_rescue/solutions/geometry_navigation.py')
files={p.relative_to(W).as_posix():sha(p) for p in (W/'src/swarm_rescue/solutions').iterdir() if p.is_file()};files['req.txt']=sha(W/'req.txt')
changed=sorted(n for n,v in files.items() if base['sources'].get(n)!=v);assert changed==['src/swarm_rescue/solutions/geometry_navigation.py']
assert all(sha(W/n)==v for n,v in base['sdk_files'].items())
out=dict(status='PREPARED_ONE_RULE_PJ01_ORIGINAL_BASELINE',versions={'PJ01':base,'P02':dict(workspace=str(W),sources=files,sdk_files=base['sdk_files'])},changed_files=changed,
    background_goal_and_automation_paused=True,scoped_latest_human_authorization='首先尝试之前测试过程中有效的规则，逐步添加。Only PJ01 plus one previously mechanism-validated endpoint rule. Small controls then at most Map01 RED/BLUE baseline+candidate.',
    automatic_five=False,official_submission_created=False)
(F/'WORKSPACE_READY.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status=out['status'],workspace=str(W),changed_files=changed)))
