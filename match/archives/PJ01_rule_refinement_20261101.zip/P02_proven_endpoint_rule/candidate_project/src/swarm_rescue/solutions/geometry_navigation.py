"""Fallback target routes through fitted sensor walls and inferred solids."""
import json
import numpy as np
from swarm_rescue.solutions.frame_mapping import InferredFrameMemory
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningCache
from swarm_rescue.solutions.coverage_geometry import geometry_wall_values


class GeometryRouteMemory(InferredFrameMemory):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.geometry_cache=GeometryPlanningCache(max_age=120,clearance=22,line_width=8)
        self.geometry_solids=None
        self.geometry_solids_step=-1000

    def route(self,position,identifier=0,peers=(),destination=None,utility=None):
        route,actual=super().route(position,identifier,peers,destination,utility)
        if destination is None or utility is not None: return route,actual
        error=float('inf') if actual is None else float(np.linalg.norm(actual-destination))
        if error<1.0: return route,actual
        step=int(self.step)
        view=self.geometry_cache.get(self,step)
        if self.geometry_solids is None or step-self.geometry_solids_step>=120:
            _,self.geometry_solids=geometry_wall_values(self,round(.12*min(self.width,self.height)),
                                                        return_solids=True,line_width=12)
            self.geometry_solids_step=step
        fallback,closer=view.route_to(position,destination,inferred_solids=self.geometry_solids)
        if closer is not None and np.linalg.norm(closer-destination)<error:
            corrected=float(np.linalg.norm(closer-destination))
            if 1.0<=error<=40.0 and corrected<1.0:
                count=getattr(self,'_exact_endpoint_events',0)
                self._exact_endpoint_events=count+1
                if count<24:
                    print('[EXACT_ENDPOINT] '+json.dumps({'step':step,'owner':int(self.identifier),
                        'ordinary_error':error,'corrected_error':corrected,
                        'target':np.asarray(destination,float).tolist()}),flush=True)
            return fallback,closer
        return route,actual


class GeometryNavigationMixin:
    def __init__(self,identifier=None,misc_data=None,**kwargs):
        super().__init__(identifier=identifier,misc_data=misc_data,**kwargs)
        self.memory=GeometryRouteMemory(*self.size_area,identifier=int(identifier or 0),team_size=self.team_size)
        self.memory.frame_records=self.frame_records
        self.memory.frame_negative=self.frame_negative
