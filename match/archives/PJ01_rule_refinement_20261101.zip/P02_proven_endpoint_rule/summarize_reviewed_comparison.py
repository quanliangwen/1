"""Summarize the completed one-rule comparison; never starts native runs."""
from pathlib import Path
import datetime
import json

F = Path(__file__).resolve().parent
read = lambda name: json.loads((F / name).read_text(encoding="utf-8"))

def main():
    review = read("CAMPAIGN_CLIENT_REVIEW.json")
    assert review["status"] == "PASS" and not review["native_failure"]
    assert read("LOCAL_COLLECTOR_RESULT.json")["status"] == "COMPLETE"
    rows = []
    for group in ("PJ01_A", "P02_A"):
        assert read(group + "/CLIENT_FIRST_RAW_REVIEW.json")["status"] == "PASS"
        d = read(group + "/MECHANISM_REVIEW.json")
        p, b = d["phase"], d["phase"]["map_breakdown"]
        rows.append(dict(
            group=group, total=d["score"], map=p["score_map"],
            wall=p["score_wall"], time=p["score_time"], placed=d["placed"],
            expected=d["expected"], red_steps=d["red_steps"],
            red_wall_seconds=d["red_walltime"], red_wall_hit=d["red_wall_hit"],
            blue_wall_hit=d["blue_wall_hit"],
            endpoint_corrections_minimum=d["observed_endpoint_corrections_minimum"],
            wall_hit_credit=100*b["credit"], false_drawing_penalty_pp=100*b["penalty"],
            missed_wall_penalty_pp=100*(1-b["credit"]),
        ))
    keys = ("total", "map", "wall", "time", "placed", "red_steps", "red_wall_seconds",
            "wall_hit_credit", "false_drawing_penalty_pp", "missed_wall_penalty_pp")
    result = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  scope="One unseeded original Map01 per arm; not five-map ranking or causal proof.",
                  production_changed_files=["geometry_navigation.py"], rows=rows,
                  delta_P02_minus_PJ01={k: rows[1][k]-rows[0][k] for k in keys},
                  new_native_started=False, automatic_five=False)
    (F/"REVIEWED_COMPARISON.json").write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))

if __name__ == "__main__":
    main()
