from pathlib import Path
import ast
F=Path(__file__).resolve().parent
source=Path('E:/codex/UAV_rules_astar_restart_20261030/CADENCE07_J17_control_20261101/collect_offline.py').read_text(encoding='utf8')
s=source.split('def finish(state):')[0]
mark="RF=R+'/solver_study/framework_screen_20261016/best87_independent_20261025/'+F.name;RC=RF"
assert s.count(mark)==1
s=s.replace(mark,"RF=R+'/solver_study/framework_screen_20261016/best87_independent_20261025/PJ01_rules_P02_endpoint_20261101';RC=RF")
s+='''
def finish_scoped(state):
    rows=[]
    for name in ['PJ01_A','P02_A']:
        group=F/name
        assert read(group/'CLIENT_FIRST_RAW_REVIEW.json')['status']=='PASS'
        matrix=read(group/'RESULT.json');assert matrix['complete'] and set(matrix['jobs'])=={'Map01'}
        row=matrix['jobs']['Map01']['rounds'][0];p=row['phase']
        mechanism=read(group/'MECHANISM_REVIEW.json')
        rows.append(dict(version=matrix['version'],group=name,maps=1,native_rounds=2,map='Map01',score=row['full_score'],
            map_score=p['score_map'],wall_score=p['score_wall'],time_score=p['score_time'],placed=row['placed'],expected=row['expected'],
            red_wall_seconds=row['red_walltime'],red_wall_hit=row.get('red_max_walltime_reached',False),blue_wall_hit=row['blue'].get('max_walltime_reached',False),
            actual_endpoint_corrections_minimum=mechanism['observed_endpoint_corrections_minimum']))
    out=dict(status='PASS',campaign_status=state['status'],utc=utc(),native_failure=state['first_native_failure'],rows=rows,
        scope='One originalMap01 RED+BLUE perversion, notfive-mapmean; independent unseeded observations, no automaticretention/promotion.')
    dest=F/'CAMPAIGN_CLIENT_REVIEW.json';save(dest,out);upload(dest,RC+'/'+dest.name)
    save(F/'LOCAL_COLLECTOR_RESULT.json',dict(status='COMPLETE',utc=utc(),starts_native_games=False))
    print(json.dumps(out),flush=True)

def main():
    started=time.monotonic()
    try:
        while time.monotonic()-started<14*3600:
            state=metadata()
            for name in ['PJ01_A','P02_A']:
                group=F/name
                if(group/'RAW_ARCHIVE_RECEIPT.json').exists():review(group)
            if state['status']=='COMPLETE_FINITE_STAGED_CAMPAIGN':
                state=metadata();finish_scoped(state);return
            if state['status'].startswith('STOPPED'):
                save(F/'LOCAL_COLLECTOR_RESULT.json',dict(status='STOPPED_KEEP_FIRST',server_status=state['status'],utc=utc(),starts_native_games=False));return
            time.sleep(3)
        raise TimeoutError('Finite14h collection window exhausted')
    except Exception:
        save(F/'LOCAL_COLLECTOR_RESULT.json',dict(status='FIRST_CLIENT_ERROR_KEEP',utc=utc(),traceback=traceback.format_exc(),starts_native_games=False));raise
if __name__=='__main__':main()
'''
ast.parse(s);p=F/'collect_offline.py';assert not p.exists();p.write_text(s,encoding='utf8')
print('Prepared finite first-byte collector only; starts no games')
