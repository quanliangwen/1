from pathlib import Path
import ast,json,shutil,hashlib,datetime
F=Path(__file__).resolve().parent;P=F.parent/'P01_baseline_rules';read=lambda p:json.loads(p.read_text(encoding='utf8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=read(P/'BASELINE_IDENTITY.json');B=Path(base['baseline_project']);assert all(sha(B/n)==v for n,v in base['files'].items())
old=read(Path('E:/codex/swarm-eod-literature-analysis/F44_route_contract_20261029/J03/BUILD.json'))
assert sha(F/'geometry_navigation.py')==old['source_files']['geometry_navigation.py']
ast.parse((F/'geometry_navigation.py').read_text(encoding='utf8'))
W=F/'candidate_project';assert not W.exists();shutil.copytree(B,W);shutil.copy2(F/'geometry_navigation.py',W/'src/swarm_rescue/solutions/geometry_navigation.py')
files={p.relative_to(W).as_posix():sha(p) for p in W.rglob('*') if p.is_file()};changed=sorted(n for n,v in files.items() if base['files'].get(n)!=v)
assert changed==['src/swarm_rescue/solutions/geometry_navigation.py'] and len(list((W/'src/swarm_rescue/solutions').glob('*.py')))==36
out=dict(status='PREPARED_PJ01_PLUS_ONE_PREVIOUSLY_MECHANISM_VALIDATED_RULE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),candidate_project=str(W),files=files,changed_files=changed,
    historical_exact_rule_geometry_sha256=sha(F/'geometry_navigation.py'),historical_game_evidence='F44J03_Map03_48routecorrections_10of10_noWallhit',
    historical_score_causality_not_claimed=True,all_mapping_fusion_motion_layout_exit_req_same_as_PJ01=True,automatic_five=False,official_submission_created=False)
(F/'CANDIDATE_MANIFEST.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(P/'DEFERRED_BY_USER_PROVEN_RULE_FIRST.txt').write_text('用户要求首先尝试以前测试有效的规则，逐条加入。P01新视野去重仅18纯检查及真实Memory构造通过，无SDK/比赛，不进入当前实赛。保留研究稿及工作区。第一项P02从原PJ0136模块独立复制，仅移植F44实赛48次生效的geometry_navigation终点一致性修复，不含P01去重或J系列整数布局核心。\n',encoding='utf8')
print(json.dumps({k:v for k,v in out.items() if k!='files'},ensure_ascii=False))
