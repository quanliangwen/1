from pathlib import Path
import datetime
import json

F = Path(__file__).resolve().parent
review = json.loads((F/'REVIEWED_COMPARISON.json').read_text(encoding='utf-8'))
assert json.loads((F/'LOCAL_COLLECTOR_RESULT.json').read_text())['status'] == 'COMPLETE'
d = json.loads((F/'P02_A/MECHANISM_REVIEW.json').read_text())
events = d['events']
owners = sorted({e['owner'] for e in events})
pairs = {(e['owner'], tuple(e['target'])) for e in events}
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
text = f'''PJ01逐条移植：P02终点一致性，已完成，{now}

本轮只有geometry_navigation.py改变；其余35个Python及地图、融合、布局、控制、退出、依赖与原版PJ01一致。修复来自F44/J03已有真实使用证据，但该历史证据从未证明移植到PJ01必然提高成绩。

原SDK e2f022b、原team006蓝队、原时限/线程/资源门槛、无外部seed。每版一次原Map01红+蓝，共4native。两组各15份原始文件已分别首次Windows字节核验PASS，CAMPAIGN_CLIENT_REVIEW PASS，无native失败，双方无墙钟hit。不读取BLUE私态，不反序列化数组。

版本       完整红分    地图分    墙体覆盖分  时间分  实际投放  红步骤  红墙钟秒
PJ01       77.917906  97.568493  78.598300  92.7   10/10    1073   68.328918
P02        67.342426  77.507292  88.583902  76.4   10/10    1236   71.050477

实赛端点纠正{len(events)}次，涉及owner{owners}、{len(pairs)}个owner-target组合；这是纠正次数，不是独立任务数或物理定位误差归零。
本轮规划端点机制实际触发，但地图-20.061201、总分-10.575480，时间分-16.3；墙体覆盖+9.985602不能抵消损失。
地图分解：原版信用99.827015-误绘2.258523=97.568493；P02信用79.707119-误绘2.199827=77.507292。退步主要表现为漏画墙体，误绘扣分基本不变。
公开探索轨迹覆盖95.444339→93.944974，只差约1.50个百分点；不能把轨迹覆盖当作地图墙体准确率，也不能从本轮现有记录单独断言漏画全部来自没去探索、定位、地图融合或最终提交哪一项。

判断：P02不保留为PJ01升级，不进入五图、不重跑救分、不向它叠加第二条。原版PJ01保留。每版独立无seed的单次结果不能证明该规则必然导致上述损失，但足够否决当前候选直接晋级。后续仍从原PJ01的独立底本验证其他旧规则。

旧规则证据补核：F50/J06带色噪声定位滤波实际Map02地图97.173986、10/10、无超时，但完整72.715299未达其原75门槛，不能称整版成功或把97.17当PJ01改进。它可以作为建图机制研究依据，需先检查PJ01同样传感/MRO及局部墙面误差，不能直接整套移植。
P01视野去重只有小检查，仍暂缓。原版已有任务租约、实际库存确认、补测与终局预算，不重复添加。

本有限队列及收集器已结束；03:30:59UTC实时串行guard显示锁可用、registry空、无本聊天活动比赛进程，其他CCMCKP工作未动。旧无限goal/automation90仍PAUSED，C7取消，不恢复。正式V06/V07/V08不改，不上传。
'''
(F/'P02结果与不保留结论.txt').write_text(text, encoding='utf-8')
decision = dict(utc=now, status='COMPLETE_REJECT_CURRENT_P02_NO_FIVE',
                review='REVIEWED_COMPARISON.json', retain_PJ01=True,
                endpoint_rule_mechanism_triggered=True, endpoint_corrections=len(events),
                endpoint_owners=owners, endpoint_owner_target_pairs=len(pairs),
                stable_causal_score_effect_established=False, automatically_start_next=False,
                old_automation_resumed=False, official_packages_changed=False)
(F/'RETENTION_DECISION.json').write_text(json.dumps(decision, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
with (F/'分析依据与逐条规则.txt').open('a', encoding='utf-8') as f:
    f.write('\n\n最新完成结论：\n'+text)
idx = Path('E:/codex/swarm-eod-literature-analysis/CURRENT_ACTIVE_ANALYSIS.txt')
idx.write_text(f'''LATEST {now}: PJ01 proven-rule-first P02 comparison COMPLETE, REJECT/no five. Read {F}/P02结果与不保留结论.txt and RETENTION_DECISION.json. PJ01 Map01 total77.917906 map97.568493 wall78.598300 time92.7 10/10; P02 total67.342426 map77.507292 wall88.583902 time76.4 10/10. Both no clockhit,30 raw firstbyte PASS, campaign PASS. Exactendpoint15actual corrections but map loss dominated missed walls, cannot call stable upgrade/causal effect. Keep originalPJ01, do NOTstacknext onfailedP02, no automaticretest/five. No active native, globalguardfree03:30:59UTC. Oldgoal/automation90PAUSED/C7cancelled. P01unprovenvisibility stilldeferred. ProductionV06/V07/V08unchanged.\n\n'''+idx.read_text(encoding='utf-8'), encoding='utf-8')
print(json.dumps(decision, ensure_ascii=False))
