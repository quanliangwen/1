from pathlib import Path
import json,zipfile,shutil,hashlib
F=Path(__file__).resolve().parent;H=F.parent;read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not(F/'PREDECLARATION.json').exists();m=read(F/'WORKSPACE_READY.json')
parent=read(F/'PJ01_ROUTE_FIRST.json');new=read(F/'P02_ROUTE_FIRST.json')
changed=[]
for a,b in zip(parent['constructed_results'],new['constructed_results']):
    assert a['case']==b['case']
    if a['old_fleet_accepts']!=b['old_fleet_accepts']:changed.append(a['case'])
    if a['kind']=='negative_control':assert not b['old_fleet_accepts']
assert changed==[1,2,3,4,5]
old=read(H/'F32_official_sdk_20261028/FIVE_MAP_REBASELINE/PREDECLARATION.json')
d={k:old[k] for k in ['sdk_commit','sdk_files','blue_binding','blue_binding_sha256','resource_gate','frozen_files']}
d.update(phase=F.name,selection=['PJ01','P02'],maps=['Map01'],seed=None,history_delta=False,versions={},max_native_rounds=4,min_native_rounds=4,
    authorization='Latest human asks PJ01 base and add only previously effective rules one at a time. One-rule Map01 baseline+candidate diagnosis after constructed checks. Old goal/90min automation/C7 stay paused.',
    hypothesis='Identical PJ01 sensing/mapping/fusion/motion/layout/exit/req; ONLY historical J03 geometry endpoint fallback before accepting1..40px mismatch.',
    schedule=[dict(version='PJ01',cohort='A',label='sdk_e2f022b_PJ01_RULE_P02_BASE_MAP01_FIRST'),dict(version='P02',cohort='A',label='sdk_e2f022b_PJ01_RULE_P02_ENDPOINT_MAP01_FIRST')],
    automatic_five=False,ranking_promoted=False,qualification_scope='Internal source bundle and current server numerical/SDK/5constructor check only; not competition submission ZIP or official platform release.',
    rule_acceptance='Report actual correction use, map score, wall/time, stock, RED/BLUEwallhits against currentMap01control. No automatic expansion/promotion; single independent no-seed observations are not causal stability proof.',
    inherited_limitation='Filled dense-hit model blind spot remains in both; no physical-safety certificate.')
for version in ['PJ01','P02']:
    w=m['versions'][version];W=Path(w['workspace']);assert all(sha(W/n)==v for n,v in w['sources'].items())
    qual=read(F/('ENTRY_'+version+'_FIRST.json'));assert qual['status']=='PASS_SERVER_RESEARCH_ENTRY_NOT_OFFICIAL_RELEASE' and qual['sources']==w['sources']
    V=F/'versions'/version;V.mkdir(parents=True);S=V/'source';S.mkdir()
    for p in (W/'src/swarm_rescue/solutions').iterdir():
        if p.is_file():shutil.copy2(p,S/p.name)
    shutil.copy2(W/'req.txt',S/'req.txt');files={p.name:sha(p) for p in S.iterdir()}
    z=V/(version+'_INTERNAL_RESEARCH_ONLY.zip')
    with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED) as archive:
        for p in sorted(S.iterdir()):archive.write(p,p.name)
    with zipfile.ZipFile(z) as archive:assert {n:hashlib.sha256(archive.read(n)).hexdigest() for n in archive.namelist()}==files
    d['versions'][version]=dict(original_zip=str(z),original_zip_sha256=sha(z),source=str(S),source_files=files)
    (V/'QUALIFICATION.json').write_text(json.dumps(dict(status='PASS',payload_files_sha256=files,zip_sha256=sha(z),actual_source_entry_receipt=qual,
        official_submission_ready=False,scope=d['qualification_scope']),indent=2)+'\n')
for p in [F/'run_offline.py',F/'PJ01_ROUTE_FIRST.json',F/'P02_ROUTE_FIRST.json',F/'ENTRY_PJ01_FIRST.json',F/'ENTRY_P02_FIRST.json']:
    d['frozen_files'][str(p)]=sha(p)
(F/'PREDECLARATION.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
(F/'CONTRACT_RESULT.json').write_text(json.dumps(dict(status='PASS',changed_constructed_cases=changed,unchanged_negative_controls=3,inherited_dense_hit_limitation=True,only_production_change='geometry_navigation.py',automatic_five=False),indent=2)+'\n')
print(json.dumps(dict(status='PREPARED_MAP01_PAIR_ONLY_NOT_LAUNCHED',max_native=4,maps=['Map01'],selection=d['selection'])))
