from pathlib import Path
import datetime,json
F=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
d=read(F/'LAUNCH.json');c=read(F/'WINDOWS_COLLECTOR_LAUNCH.json');s=read(F/'STATUS.json')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
note=f'''\nLATEST NATIVE LAUNCH {now}: P06已离线启动，覆盖“未有队列”。服务器coordinator{d['pid']}/start{d['starttime_ticks']}、UTC{d['utc']}；Windowscollector{c['pid']}/UTC{c['utc']}，14h有限窗口。run_offline.py为已冻结外部RED-only驱动，通过DRIVER_PREFLIGHT：source/SDK哈希、原资源两样本60秒、单Map02/单RED/noBLUE/noSeed均核对。当前状态{s['status']}，尚无结果，不重复启动。
资源/registry与原冻结F32 evaluator原RED命令不改；actualsource只有原PJ01+只读Mixin。最多1native，不追加BLUE、完整分、排名或五图。native结束后先Windows首次opaque raw字节核验，再读OBS_A/MECHANISM_REVIEW、SHA绑定、实际库存/退出及各类耗时。首native失败保存停链；观察不足不重跑救分。
边界：计时是instrumented call tree，不能把嵌套inclusive相加；exclusivecontrol也包含未细分的原运动/观察/诊断开销。SDK外部物理与传感耗时不在各控制器内，不能把子例缓存倍数冒充整场加速。
只读源码新发现：原PJ01的plan_team_coverage_lns已有reserved_prefixes，以及Greedy/refine的_prepared；旧F37/H01包装函数不保留该接口，不能直接复制。H01纯检查的12例目标顺序相同/CPU改善不是当前PJ01实赛证据；F61/J11实际准备更快但7/10整体失败也不能当整体成功。
若实际profile显示fleet规划占主要时间，先只验证“同一次规划的Dijkstra场复用”这一条，完整保留前缀预算、已接首目标、forbidden mask与目标顺序；图mask/起点/CELL键不同绝不复用，返回副本、64条内存上限、函数异常或嵌套调用恢复、无跨调用历史cache。只做当次派生数据的复用，不带旧启发式/新目标或几何重拟合。不能在本次native运行中开展重计算/改冻结源码。
若瓶颈为融合、位姿或SDK外部，则按profile重新判断，不为已写思路强行集成cache。目标仍ACTIVE。
'''
for n in ['WORKING_HANDOFF_P06.txt','分析依据与下一步小检查.txt']:
    with(F/n).open('a',encoding='utf-8')as f:f.write(note)
idx=Path('E:/codex/swarm-eod-literature-analysis/CURRENT_ACTIVE_ANALYSIS.txt')
idx.write_text(f'''LATEST {now}: P06 RED-only1native diagnostic NOWLAUNCHED {d['pid']}/start{d['starttime_ticks']}UTC{d['utc']}, Windowscollector{c['pid']}UTC{c['utc']}, state{s['status']}. Read{F}/WORKING_HANDOFF_P06.txt LASTappend. NoBLUE/nofullscore/noranking/noauto5. OriginalfrozenF32RED evaluator & allresourcesSDKlimits unchanged; no truth/privatearrays. FirstWindowrawbarrier thenobserveownexit/profile/submittedSHA. DON'Tduplicate waiting/running coordinator or collector. Source/entry/20actualSDK/27transparency checks passed; firstfixturetypo preserved. OldP05/P03/P02done notrestart. Goal/automationACTIVE. Staticaudit foundoldH01wrapperdropscurrentreserved_prefixes API; don'tcopyblindly. Ifprofilefleetdominant, nextonlyDijkstra-in-callmemo, preserveallcurrentbudget/geometry, checksbeforecandidate. NoSDKheavyworkduringnative.\n\n'''+idx.read_text(encoding='utf-8'),encoding='utf-8')
print(json.dumps(dict(status='RECORDED_P06_ONE_RED_NATIVE_LIVE',coordinator=d['pid'],collector=c['pid'],state=s['status'])))
