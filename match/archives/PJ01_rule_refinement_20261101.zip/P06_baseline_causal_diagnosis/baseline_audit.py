"""Own-state read-only diagnostics and inclusive/exclusive timing for PJ01.

No alternative plan, map, control, message, deadline or SDK setting is applied.
Extra instrumentation consumes real CPU and is not assumed to be free.
"""
import hashlib
import json
import time
import numpy as np

def plain(v):
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    if isinstance(v,dict):return {str(k):plain(x)for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [plain(x)for x in v]
    if v is None or isinstance(v,(str,bool,int,float)):return v
    return type(v).__name__

class BaselineAuditMixin:
    def __init__(self,*args,**kwargs):
        self._audit_stats={};self._audit_stack=[];self._audit_last_due=None
        self._audit_due_prints=0;self._audit_place_prints=0;self._audit_finish_printed=False
        super().__init__(*args,**kwargs)

    def _audit_call(self,name,fn,*args,**kwargs):
        start=time.perf_counter();cpu=time.process_time();frame=[name,0.,0.]
        self._audit_stack.append(frame)
        try:return fn(*args,**kwargs)
        finally:
            wall=time.perf_counter()-start;used=time.process_time()-cpu
            assert self._audit_stack.pop()is frame
            item=self._audit_stats.setdefault(name,dict(calls=0,wall_inclusive=0.,wall_exclusive=0.,cpu_inclusive=0.,cpu_exclusive=0.))
            item['calls']+=1;item['wall_inclusive']+=wall;item['wall_exclusive']+=max(0.,wall-frame[1])
            item['cpu_inclusive']+=used;item['cpu_exclusive']+=max(0.,used-frame[2])
            if self._audit_stack:self._audit_stack[-1][1]+=wall;self._audit_stack[-1][2]+=used

    def _audit_emit(self,kind,payload):
        print('[PJ01_BASE_AUDIT] '+json.dumps(dict(kind=kind,owner=int(self.identifier or 0),
            step=int(self.elapsed_timestep),wall=float(self.elapsed_walltime),**plain(payload))),flush=True)

    def _update_pose(self):return self._audit_call('pose_and_frame',super()._update_pose)
    def _messages(self):return self._audit_call('messages_and_map_merge',super()._messages)
    def _plan_route(self,*a,**k):return self._audit_call('plan_route',super()._plan_route,*a,**k)
    def _build_fleet_plan(self,*a,**k):return self._audit_call('fleet_plan',super()._build_fleet_plan,*a,**k)
    def _estimate_coverage_opportunity(self,*a,**k):return self._audit_call('opportunity_model',super()._estimate_coverage_opportunity,*a,**k)

    def _submission_due(self,step):
        due=self._audit_call('submission_check',super()._submission_due,step)
        inventory=int(self.carried_bombs_count());remaining=float(self._remaining_steps())
        certs=dict(getattr(self,'completion_certificates',{}));allcert=all(i in certs for i in range(self.team_size))
        signature=(bool(due),inventory,len(certs),int(max(0.,remaining)//120),bool(getattr(self,'coverage_ready',False)),bool(getattr(self,'_seeking_fusion',False)))
        if (signature!=self._audit_last_due and self._audit_due_prints<32)or due:
            reason=('BUDGET_EXHAUSTED'if due and remaining<=0 else 'ALL_CERTIFICATES'if due and inventory==0 and allcert else
                    'OTHER_TRUE_BRANCH'if due else 'INVENTORY_REMAINS'if inventory>0 else 'CERTIFICATES_PENDING'if not allcert else 'BETTER_PEER_OR_PARENT_FALSE')
            self._audit_emit('SUBMISSION_DECISION',dict(actual_due=bool(due),reason_from_actual_branch_conditions=reason,
              inventory=inventory,remaining=remaining,certificates=certs,coverage_ready=getattr(self,'coverage_ready',None),
              seeking_fusion=getattr(self,'_seeking_fusion',None),model=getattr(self,'coverage_model',{}),
              assignment_goal=getattr(self,'assignment_goal',None),placement_goal=getattr(self,'placement_goal',None),
              assignment_since=getattr(self,'assignment_since',None),assignment_inventory=getattr(self,'assignment_inventory',None),
              fleet_plan_epoch=None if getattr(self,'fleet_plan',None)is None else self.fleet_plan[0],
              last_plan_step=getattr(self,'last_plan_step',None),quality_cache=getattr(self,'_quality_cache',None),
              frame_sources=sorted({int(k[0])for k in getattr(self,'frame_records',{})}),
              merged_packets=int(getattr(self.memory,'bearing_merged_packets',0))))
            self._audit_due_prints+=1;self._audit_last_due=signature
        return due

    def _maybe_place(self,command,step,semantic):
        result=self._audit_call('placement_check',super()._maybe_place,command,step,semantic)
        if command.get('place_bomb')and self._audit_place_prints<32:
            self._audit_emit('ACTUAL_DROP_REQUEST',dict(inventory=int(self.carried_bombs_count()),pose=getattr(self,'pose',None),
                assignment_goal=getattr(self,'assignment_goal',None),placement_goal=getattr(self,'placement_goal',None),
                pending_drop=getattr(self,'pending_drop',None)))
            self._audit_place_prints+=1
        return result

    def submit_exploration_map(self,image):
        data=np.asarray(image)
        self._audit_emit('SUBMIT_IMAGE',dict(shape=list(data.shape),dtype=str(data.dtype),sha256=hashlib.sha256(data.tobytes()).hexdigest(),
            inventory=int(self.carried_bombs_count()),certificates=dict(getattr(self,'completion_certificates',{}))))
        return self._audit_call('submit_api',super().submit_exploration_map,image)

    def control(self):
        command=self._audit_call('control',super().control)
        if getattr(self,'submitted',False)and not self._audit_finish_printed:
            self._audit_emit('PROFILE_FINAL',dict(timing=self._audit_stats,inventory=int(self.carried_bombs_count()),
                scope='Timing categories may nest. Exclusive sums cover only instrumented call-tree regions; no optimality/causality claim.'))
            self._audit_finish_printed=True
        return command
