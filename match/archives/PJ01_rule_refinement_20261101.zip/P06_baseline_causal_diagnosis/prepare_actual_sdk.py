from pathlib import Path
import ast,hashlib,json,shutil,subprocess
F=Path(__file__).resolve().parent;B=F.parent/'P01_baseline_rules/baseline_project';P=F.parent/'P05_finite_output_rule'
assert json.loads((F/'AUDIT_TRANSPARENCY_FIRST.json').read_text())['status']=='PASS_OBSERVER_TRANSPARENCY_CONTRACT_ONLY'
C=F/'candidate_project';assert not C.exists();shutil.copytree(B,C,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
S=C/'src/swarm_rescue/solutions';shutil.copy2(F/'baseline_audit.py',S/'baseline_audit.py')
p=S/'my_drone_eval.py';s=p.read_text(encoding='utf-8');marker='class MyDroneEval(BearingMappingMixin,';assert s.count(marker)==1
p.write_text('from swarm_rescue.solutions.baseline_audit import BaselineAuditMixin\n'+s.replace(marker,'class MyDroneEval(BaselineAuditMixin,BearingMappingMixin,',1),encoding='utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in S.glob('*.py'):ast.parse(p.read_text(encoding='utf-8-sig'))
files={p.relative_to(C).as_posix():sha(p)for p in C.rglob('*')if p.is_file()}
base={p.relative_to(B).as_posix():sha(p)for p in B.rglob('*')if p.is_file()and'__pycache__'not in p.parts}
changed=sorted(n for n,h in files.items()if base.get(n)!=h)
assert changed==['src/swarm_rescue/solutions/baseline_audit.py','src/swarm_rescue/solutions/my_drone_eval.py']
(F/'CANDIDATE_MANIFEST.json').write_text(json.dumps(dict(status='READONLY_ORIGINAL_PJ01_OBSERVER_NOT_ALGORITHM_VARIANT',files=files,changed_files=changed,official_submission_created=False),indent=2)+'\n',encoding='utf-8')
s=(P/'prepare_server.py').read_text(encoding='utf-8').replace('pj01_rules_finite_output_20261101','pj01_rules_baseline_audit_20261101').replace("'P05':dict","'P06':dict").replace('ONE_FINITE_OUTPUT_RULE','READONLY_BASELINE_AUDIT')
(F/'prepare_server.py').write_text(s,encoding='utf-8')
R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P06_baseline_audit_20261101'
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
subprocess.run(ssh+[R+'/.venv/bin/python',H+'/R154_scoped_serial_guard_20261101/check_scoped_serial.py'],check=True)
subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=('from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n').encode(),check=True)
for n in ['candidate_project','CANDIDATE_MANIFEST.json','prepare_server.py','check_real_sdk_observer.py']:
    subprocess.run(['scp','-q','-r',str(F/n),'junhao@10.112.162.60:'+D+'/'],check=True)
subprocess.run(['scp','-q',str(F.parent/'P02_proven_endpoint_rule/qualify_arm.py'),'junhao@10.112.162.60:'+D+'/qualify_arm.py'],check=True)
subprocess.run(ssh+[R+'/.venv/bin/python',D+'/prepare_server.py'],check=True)
subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/WORKSPACE_READY.json',str(F/'WORKSPACE_READY.json')],check=True)
for script,label in [('qualify_arm.py','ENTRY_P06_FIRST'),('check_real_sdk_observer.py','ACTUAL_P06_OBSERVER_FIRST')]:
    subprocess.run(ssh+[R+'/.venv/bin/python',H+'/R154_scoped_serial_guard_20261101/check_scoped_serial.py'],check=True)
    run=subprocess.run(ssh+[R+'/.venv/bin/python',H+'/run_sdk_captured.py',D+'/'+script,label,'P06'],capture_output=True,text=True)
    (F/(label+'.capture.txt')).write_text(run.stdout+run.stderr,encoding='utf-8');print(run.stdout);print(run.stderr)
    if run.returncode:raise SystemExit(run.returncode)
    subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+label+'.json',str(F/(label+'.json'))],check=True)
