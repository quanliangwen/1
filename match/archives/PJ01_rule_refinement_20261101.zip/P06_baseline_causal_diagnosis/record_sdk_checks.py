from pathlib import Path
import datetime,json
F=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
assert read(F/'ENTRY_P06_FIRST.json')['status']=='PASS_SERVER_RESEARCH_ENTRY_NOT_OFFICIAL_RELEASE'
assert read(F/'ACTUAL_P06_OBSERVER_V2.json')['status']=='PASS_REAL_SDK_OBSERVER_ENTRY_AND_INITIAL_BRANCHES'
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
note=f'''\nLATEST {now}: P06实际工程和SDK检查已完成（覆盖上文“尚未建立/尚未检查”）。
candidate_project为原PJ01，只添加baseline_audit.py并在my_drone_eval.py最外层插入BaselineAuditMixin；其余36Py中的35个文件/req/SDK不改，没有P02/P03/P05规则。
服务器阶段H/PJ01_rules_P06_baseline_audit_20261101；workspace ROOT/experiments/target90_20261012/official_workspaces/pj01_rules_baseline_audit_20261101，WORKSPACE_READY版本PJ01/P06。
ENTRY_P06_FIRST：实际整数615/NumPy mtrand随机数/Pandas/OpenCV/SDK Launcher Stats/原Map01五机独立构造PASS。
ACTUAL_P06_OBSERVER_FIRST首次夹具失败（c.__name__in属性拼写），原脚本与capture保留；只更正夹具单token为c.__name__ in，未改算法，ACTUAL_P06_OBSERVER_V2真实SDK20项PASS：实际MRO、5机原BearingMemory类型保留、各机计数栈独立、无P03/P05、五机原提交父方法与观察器初始False分支一致/库存不变。
共27纯透传+20真实初始接口断言，全部0物理步；不能声称真实飞行、终局原因或分数已经验证。没有原生queue/coordinator/collector或LAUNCH.json，下一步仍需安排一次只读基线诊断，不得误当已运行。
期望最高效只做原Map02红队1native（不用BLUE难度/完整分），不改原SDK、计分、时限、线程；沿用冻结F32 evaluator的原RED命令：bash ROOT/run_server.sh -u H/F32_official_sdk_20261028/postscore_visual_evaluator_v2.py --workspace <freshFrozenObserverWorkspace> --map Map02 --mode place --out <newUniqueResult/Map02_red> --rounds 1。无seed。不调用旧parallel_five worker，因为它必然继续BLUE。纯读原worker参数已核。
需先完成有限RED-only外部协调器/同一资源两样本门槛/全局锁registry及首次Windowsopaque raw审核；原run_offline.py可作为文件名供串行guard发现。只读诊断不排行、不补报完整红分、不能把作者mask评分当原图。
具体输出：实际退出due分支/库存/证书/剩余预测/图来源/任务采样；inclusive/exclusive时长；submit图SHA与公开PNG按原0/1↔0/255编码逆变换绑定。还未运行飞行，不能提前得出预算耗尽或融合丢失结论。
不得将新的观察运行当P05救分；原P05保留失败不再晋级。目的归因原PJ01自身的图/预算/任务变化后再选下一规则，使用本机公共状态与收到消息，禁止真图/私有Blue/反序列化原始pickle NPZ。目标保持ACTIVE，普通动作自主继续。
'''
for n in ['WORKING_HANDOFF_P06.txt','分析依据与下一步小检查.txt']:
    with(F/n).open('a',encoding='utf-8')as f:f.write(note)
idx=Path('E:/codex/swarm-eod-literature-analysis/CURRENT_ACTIVE_ANALYSIS.txt')
idx.write_text(f'''LATEST {now}: CurrentP06 BaselineAudit on originalPJ01 source PREPARED, 27puretransparencyPASS + ENTRY_P06_FIRST realABI SDK5constructorsPASS + ACTUAL_P06_OBSERVER_V2 20realinitialbranchchecksPASS. FIRST fixture misspelled__name__in, originalkept, onlyfixturetokenfixed; noalgorithmchange/physics/nativeerror. Read E:/codex/PJ01_rule_refinement_20261101/P06_baseline_causal_diagnosis/WORKING_HANDOFF_P06.txt LAST appended section. ServerH/PJ01_rules_P06_baseline_audit_20261101 workspaceprepared, noLAUNCH/coordinator/collector/nativequeue yet. NEXT preparefinite RED-only1native externalrunner using originalF32evaluatorREDcommand/gates/registry/firstopaqueWindowsreview; noBLUE/complete score/ranking, readonlydiagnosisnotnewalgorithm. Goal andautomationACTIVE, continue notjustpoll. P05failednotpromoted; mathematicalpixelbound provesatleast3.1806observedmapgap existedpreoutput. Noactualtruthread.\n\n'''+idx.read_text(encoding='utf-8'),encoding='utf-8')
print(json.dumps(dict(status='RECORDED_REAL_OBSERVER_ENTRY_READY_NO_FLIGHT_YET',utc=now)))
