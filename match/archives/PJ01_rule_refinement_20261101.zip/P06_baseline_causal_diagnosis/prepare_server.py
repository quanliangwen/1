from pathlib import Path
import hashlib,json,shutil
F=Path(__file__).resolve().parent;H=F.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((H/'PJ01_rules_P02_endpoint_20261101/WORKSPACE_READY.json').read_text())
b=old['versions']['PJ01'];B=Path(b['workspace'])
assert all(sha(B/n)==v for n,v in b['sources'].items())
assert all(sha(B/n)==v for n,v in b['sdk_files'].items())
m=json.loads((F/'CANDIDATE_MANIFEST.json').read_text());C=F/'candidate_project'
assert all(sha(C/n)==v for n,v in m['files'].items())
W=B.parent/'pj01_rules_baseline_audit_20261101';assert not W.exists()
shutil.copytree(B,W,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git'))
for n in m['changed_files']:shutil.copy2(C/n,W/n)
files={p.relative_to(W).as_posix():sha(p) for p in (W/'src/swarm_rescue/solutions').iterdir() if p.is_file()};files['req.txt']=sha(W/'req.txt')
assert sorted(n for n,v in files.items() if b['sources'].get(n)!=v)==m['changed_files']
assert all(sha(W/n)==v for n,v in b['sdk_files'].items())
out=dict(status='PREPARED_PJ01_PLUS_READONLY_BASELINE_AUDIT',versions={'PJ01':b,'P06':dict(workspace=str(W),sources=files,sdk_files=b['sdk_files'])},
 changed_files=m['changed_files'],P02_included=False,official_submission_created=False,
 authorization='2026-11-01 active PJ01 goal. Read-only original-PJ01 diagnostics for pre-output map variation, task inventory, actual termination and call-tree cost. No P02/P03/P05 algorithm rule or extra output pixels; original SDK/limits unchanged. Real branch/entry checks first, diagnostic only, no score promotion.')
(F/'WORKSPACE_READY.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status=out['status'],workspace=str(W))))
