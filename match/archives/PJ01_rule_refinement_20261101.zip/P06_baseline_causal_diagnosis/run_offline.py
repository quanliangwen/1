"""One original-clock RED-only PJ01 observation; never runs BLUE or ranks."""
from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,shutil,subprocess,tarfile,time,traceback
F=Path(__file__).resolve().parent;R=Path('/home/junhao/quan/parallel_test_solver/match');H=F.parent
spec=importlib.util.spec_from_file_location('frozen_native_gate',H/'F32_official_sdk_20261028/FIVE_MAP_REBASELINE/run_offline.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.F=F;b.D=json.loads((F/'PREDECLARATION.json').read_text());b.NAMES=['P06'];b.BLUE=b.D['blue_binding'];b.WBLUE=Path(b.BLUE['blue_workspace'])
b.STATE.update(phase=F.name,completed=[],decisions=[],max_native_rounds=1,blue_native_rounds=0,automatic_five=False,ranking_promoted=False)
def save(name,data):b.save(F/name,data)
def report():save('RESULT.json',dict(b.STATE,scope='Original PJ01 read-only RED-only diagnostic; no BLUE difficulty, full RED score or ranking.'))

def archive(result,group):
    raw={str(p.relative_to(result)):dict(sha256=b.sha(p),bytes=p.stat().st_size)for p in sorted(result.rglob('*'))if p.is_file()}
    b.save(group/'RAW_SHA256.json',raw)
    dest=group/'raw_results.tar.gz'
    with tarfile.open(dest,'x:gz',compresslevel=1)as tar:
        for name in raw:tar.add(result/name,arcname=name,recursive=False)
    b.save(group/'RAW_ARCHIVE_RECEIPT.json',dict(utc=b.utc(),archive=str(dest),sha256=b.sha(dest),manifest_sha256=b.sha(group/'RAW_SHA256.json'),files=len(raw),first_windows_review_pending=True,raw_arrays_loaded=0))

def review_barrier(group):
    start=time.monotonic();receipt=group/'CLIENT_FIRST_RAW_REVIEW.json'
    while not receipt.exists():
        if time.monotonic()-start>7200:raise TimeoutError('First Windows bytes missing, no retry')
        b.state('AWAIT_FIRST_WINDOWS_REVIEW',group=group.name);time.sleep(3)
    proof=json.loads(receipt.read_text());raw=json.loads((group/'RAW_ARCHIVE_RECEIPT.json').read_text())
    assert proof['status']=='PASS'and proof['archive_sha256']==raw['sha256']

def observe(result,group,summary):
    import cv2
    import numpy as np
    rows=summary['rounds'];assert len(rows)==1;row=rows[0]
    events=[]
    for line in (result/'Map02_red/console.log').read_text(errors='replace').splitlines():
        if '[PJ01_BASE_AUDIT] 'in line:events.append(json.loads(line.split('[PJ01_BASE_AUDIT] ',1)[1]))
    exported=cv2.imread(str(result/'Map02_red/round1_red_submitted.png'),cv2.IMREAD_UNCHANGED)
    assert exported is not None
    binary=(exported>0).astype(np.uint8);digest=hashlib.sha256(binary.tobytes()).hexdigest()
    submissions=[e for e in events if e['kind']=='SUBMIT_IMAGE']
    matches=[dict(owner=e['owner'],step=e['step'],sha256=e['sha256'])for e in submissions if e['sha256']==digest and e['shape']==list(binary.shape)and e['dtype']=='uint8']
    final=[e for e in events if e['kind']=='SUBMISSION_DECISION'and e['actual_due']]
    profiles=[e for e in events if e['kind']=='PROFILE_FINAL']
    out=dict(status='PASS_BOUND_OBSERVATION'if matches and final and profiles else 'INCOMPLETE_OBSERVATION_KEEP_NO_RETRY',
      map='Map02',phase=row['phase'],placed=row['placed'],expected=row['expected'],red_steps=row['timestep'],red_wall_seconds=row['walltime'],
      red_max_walltime_reached=row['max_walltime_reached'],image_binding=dict(exporter_inverse='binary0/255 to uint8 0/1',sha256=digest,matches=matches),
      actual_due=final,profiles=profiles,events=events,blue_native_rounds=0,full_red_score=None,
      scope='Own public-state audit and official RED scores only; original frozen SDK/evaluator. No competition truth or private arrays loaded by diagnostics, no BLUE/ranking.')
    b.save(group/'MECHANISM_REVIEW.json',out);return out

def main():
    lease=(F/'coordinator.lock').open('a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not(F/'RUN_ONCE.json').exists()
    save('RUN_ONCE.json',dict(utc=b.utc(),pid=os.getpid(),starttime_ticks=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],driver_sha256=b.sha(__file__),study_sha256=b.sha(F/'PREDECLARATION.json')))
    b.STATE['started_utc']=b.utc();b.validate_frozen();report()
    lock=None;registered=False;log=None;process=None
    try:
        lock=b.acquire_when_ready()
        if lock is None:b.state('STOPPED_BEFORE_NATIVE');report();return
        b.validate_frozen();item=b.D['schedule'][0]
        group=F/'OBS_A';assert not group.exists();group.mkdir()
        result=R/'results/target90_20261012'/('unseeded_'+item['label']);assert not result.exists();result.mkdir()
        workspace=R/'experiments/target90_20261012/official_workspaces'/item['label'];assert not workspace.exists()
        shutil.copytree(Path(b.D['observer_workspace']),workspace,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git','.pytest_cache'))
        assert all(b.sha(workspace/n)==v for n,v in b.D['sdk_files'].items())
        assert all(b.sha(workspace/n)==v for n,v in b.D['observer_sources'].items())
        red=result/'Map02_red';red.mkdir()
        command=['bash',str(R/'run_server.sh'),'-u',b.D['evaluator'],'--workspace',str(workspace),'--map','Map02','--mode','place','--out',str(red),'--rounds','1']
        b.save(group/'GAME_PREDECLARATION.json',dict(utc=b.utc(),map='Map02',mode='place',native_rounds=1,seed=None,command=command,workspace=str(workspace),observer_source_hashes=b.D['observer_sources'],blue_run=False))
        log=(red/'console.log').open('x');process=subprocess.Popen(command,cwd=R,env=b.ENV,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        b.activity_on(item,{'Map02':process});registered=True
        b.save(group/'LAUNCH.json',dict(utc=b.utc(),pid=process.pid,starttime_ticks=Path('/proc',str(process.pid),'stat').read_text().rsplit(')',1)[1].split()[19],result=str(result),command=command))
        started=time.monotonic()
        while process.poll()is None:
            b.state('RUNNING_RED_ONLY_DIAGNOSTIC',current=item,workers={'Map02':process.pid},group='OBS_A')
            if time.monotonic()-started>1800 and not(F/'EXTERNAL_HANG_WATCHDOG.json').exists():
                save('EXTERNAL_HANG_WATCHDOG.json',dict(utc=b.utc(),no_retry=True));b.STATE['first_native_failure']=True
            time.sleep(3)
        log.close();log=None;b.activity_off();registered=False
        summary_file=red/'summary.json';summary=json.loads(summary_file.read_text())if summary_file.exists()else None
        valid=process.returncode==0 and summary and len(summary.get('rounds',[]))==1 and not summary['rounds'][0]['crashed']and not b.STATE['first_native_failure']
        b.validate_frozen();assert all(b.sha(workspace/n)==v for n,v in b.D['observer_sources'].items())
        if valid:assert summary['seed']is None and summary['competition_mode']and not summary['framework_runtime_patched']
        b.save(group/'RESULT.json',dict(utc=b.utc(),complete=bool(valid),red_summary=summary,blue_run=False,full_red_score=None,ranking=False,raw_arrays_loaded=0))
        archive(result,group)
        if not valid:
            b.STATE['first_native_failure']=True;save('FIRST_NATIVE_ERROR.json',dict(returncode=process.returncode,no_retry=True));raise RuntimeError('First actual RED diagnostic failure, no retry')
        review_barrier(group)
        mechanism=observe(result,group,summary)
        b.STATE['completed'].append(dict(version='P06_OBSERVER',group='OBS_A',map='Map02',native_rounds=1,red_phase=summary['rounds'][0]['phase'],placed=summary['rounds'][0]['placed'],expected=summary['rounds'][0]['expected']))
        b.STATE['decisions'].append(dict(observation_status=mechanism['status'],no_algorithm_promotion=True))
        b.state('COMPLETE_RED_ONLY_DIAGNOSTIC',current=None);report()
    except Exception:
        save('FIRST_ERROR.json',dict(utc=b.utc(),traceback=traceback.format_exc(),first_native_failure=b.STATE['first_native_failure'],no_retry=True))
        b.state('STOPPED_FIRST_ERROR_NO_RETRY');report();raise
    finally:
        # A bookkeeping error must not expose the global lease while an owned
        # native process is still running with its original SDK clock.
        while process is not None and process.poll()is None:time.sleep(2)
        if log is not None:log.close()
        if registered:b.activity_off()
        if lock is not None:lock.close()
if __name__=='__main__':main()
