from pathlib import Path
import json,shutil
F=Path(__file__).resolve().parent;p=F/'WORKSPACE_READY.json'
shutil.copy2(p,F/'WORKSPACE_READY_GENERATED_DESCRIPTION_BEFORE_CORRECTION.json')
d=json.loads(p.read_text(encoding='utf-8'));before=json.dumps(d['versions'],sort_keys=True)
d['authorization']='2026-11-01 active PJ01 goal. Read-only baseline diagnostics for pre-output map variation, task inventory, termination and call-tree cost. No P02/P03/P05 algorithm rule, original SDK/limits unchanged; no score promotion.'
d['description_correction']='Generated workspace inherited obsolete P05 prose. Correct descriptive metadata only; exact source and SDK hashes unchanged, initial metadata retained.'
assert json.dumps(d['versions'],sort_keys=True)==before
p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
print('Corrected stale description only; source and SDK hashes unchanged.')
