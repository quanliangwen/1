from pathlib import Path
import subprocess
F=Path(__file__).resolve().parent
s=(F/'check_real_sdk_observer.py').read_text(encoding='utf-8')
assert s.count('c.__name__in[')==1
dest=F/'check_real_sdk_observer_v2.py';assert not dest.exists()
dest.write_text(s.replace('c.__name__in[','c.__name__ in [',1),encoding='utf-8')
(F/'HARNESS_FIRST_ERROR.txt').write_text('ACTUAL_P06_OBSERVER_FIRST failed because the fixture misspelled c.__name__ in as attribute c.__name__in. Original check source/captured stdout kept. V2 changes that single fixture token only, no algorithm source change, no physics/native run. See ACTUAL_P06_OBSERVER_FIRST.capture.txt.\n',encoding='utf-8')
R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P06_baseline_audit_20261101'
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
subprocess.run(ssh+[R+'/.venv/bin/python',H+'/R154_scoped_serial_guard_20261101/check_scoped_serial.py'],check=True)
subprocess.run(['scp','-q',str(dest),'junhao@10.112.162.60:'+D+'/'],check=True)
run=subprocess.run(ssh+[R+'/.venv/bin/python',H+'/run_sdk_captured.py',D+'/'+dest.name,'ACTUAL_P06_OBSERVER_V2','P06'],capture_output=True,text=True)
(F/'ACTUAL_P06_OBSERVER_V2.capture.txt').write_text(run.stdout+run.stderr,encoding='utf-8');print(run.stdout);print(run.stderr)
if run.returncode:raise SystemExit(run.returncode)
subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/ACTUAL_P06_OBSERVER_V2.json',str(F/'ACTUAL_P06_OBSERVER_V2.json')],check=True)
