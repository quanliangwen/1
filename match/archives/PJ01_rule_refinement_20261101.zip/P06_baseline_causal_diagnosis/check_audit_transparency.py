from pathlib import Path
import contextlib,io,json
import numpy as np
from baseline_audit import BaselineAuditMixin
F=Path(__file__).resolve().parent
class Legacy:
    def __init__(self):
        self.identifier=0;self.elapsed_timestep=100;self.elapsed_walltime=10.;self.team_size=5
        self.inventory=1;self.remaining=50.;self.completion_certificates={};self.memory=type('M',(),dict(bearing_merged_packets=0))()
        self.called=[];self.submitted=False;self.token=object()
    def carried_bombs_count(self):return self.inventory
    def _remaining_steps(self):return self.remaining
    def _update_pose(self):self.called.append('pose');return self.token
    def _messages(self):self.called.append('messages');return self.token
    def _plan_route(self,*a,**k):self.called.append(('route',a,k));return self.token
    def _build_fleet_plan(self,*a,**k):self.called.append(('fleet',a,k));return self.token
    def _estimate_coverage_opportunity(self,*a,**k):self.called.append(('model',a,k));return self.token
    def _submission_due(self,step):self.called.append(('due',step));return self.remaining<=0
    def _maybe_place(self,command,step,semantic):self.called.append(('place',step));command['place_bomb']=1;return self.token
    def submit_exploration_map(self,image):self.called.append(('submit',image));self.submitted=True;return self.token
    def control(self):self._update_pose();self._messages();return dict(forward=.2,rotation=0.)
class Probe(BaselineAuditMixin,Legacy):pass
checks=[]
def require(v,n):assert v,n;checks.append(n)
for name,args,kwargs in [('_update_pose',(),{}),('_messages',(),{}),('_plan_route',(12,False,[]),{}),
                        ('_build_fleet_plan',(12,),{}),('_estimate_coverage_opportunity',(12,),{})]:
    p=Probe();result=getattr(p,name)(*args,**kwargs)
    require(result is p.token,name+'_return_identity_preserved');require(len(p.called)==1,name+'_parent_called_once');require(not p._audit_stack,name+'_profile_stack_closed')
with contextlib.redirect_stdout(io.StringIO()):
    p=Probe();require(p._submission_due(100)is False,'false_due_preserved');require(p.inventory==1 and p.remaining==50 and p.completion_certificates=={},'due_logging_does_not_change_input_state')
    p.remaining=0;require(p._submission_due(101)is True,'true_budget_due_preserved')
    require(p.called==[('due',100),('due',101)],'due_parent_exactly_once_per_call')
    p=Probe();command={};require(p._maybe_place(command,100,[])is p.token and command=={'place_bomb':1},'actual_command_mutation_and_parent_return_preserved')
    image=np.zeros((8,8),np.uint8);old=image.copy();require(p.submit_exploration_map(image)is p.token,'submit_return_identity_preserved')
    require(p.called[-1][1]is image and np.array_equal(image,old),'submit_exact_original_array_object_preserved')
    p=Probe();require(p.control()==dict(forward=.2,rotation=0.),'nested_control_payload_preserved');require(p.called==['pose','messages'],'nested_parent_call_order_preserved')
    require(p._audit_stats['control']['wall_inclusive']>=p._audit_stats['pose_and_frame']['wall_inclusive'],'nested_timing_contains_child')
p=Probe()
def fail():raise ValueError('EXPECTED_TEST_EXCEPTION')
try:p._audit_call('exception_test',fail)
except ValueError as e:require(str(e)=='EXPECTED_TEST_EXCEPTION','parent_exception_propagated')
else:raise AssertionError('Exception swallowed')
require(not p._audit_stack and p._audit_stats['exception_test']['calls']==1,'exception_path_stack_and_count_valid')
out=dict(status='PASS_OBSERVER_TRANSPARENCY_CONTRACT_ONLY',checks=checks,physics_steps=0,native_rounds=0,real_SDK_class_check_pending=True)
(F/'AUDIT_TRANSPARENCY_FIRST.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(status=out['status'],checks=len(checks))))
