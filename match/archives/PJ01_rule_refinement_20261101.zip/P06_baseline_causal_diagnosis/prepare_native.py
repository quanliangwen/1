from pathlib import Path
import hashlib,json,shutil,zipfile
F=Path(__file__).resolve().parent;H=F.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not(F/'PREDECLARATION.json').exists()
m=read(F/'WORKSPACE_READY.json')['versions']['P06'];W=Path(m['workspace'])
entry=read(F/'ENTRY_P06_FIRST.json');actual=read(F/'ACTUAL_P06_OBSERVER_V2.json')
assert entry['status']=='PASS_SERVER_RESEARCH_ENTRY_NOT_OFFICIAL_RELEASE'and entry['sources']==m['sources']
assert actual['status']=='PASS_REAL_SDK_OBSERVER_ENTRY_AND_INITIAL_BRANCHES'and actual['source_sha256']==m['sources']
assert all(sha(W/n)==h for n,h in m['sources'].items())and all(sha(W/n)==h for n,h in m['sdk_files'].items())
old=read(H/'F32_official_sdk_20261028/FIVE_MAP_REBASELINE/PREDECLARATION.json')
d={k:old[k]for k in ['sdk_commit','sdk_files','blue_binding','blue_binding_sha256','resource_gate','frozen_files']}
d.update(phase=F.name,selection=['P06'],maps=['Map02'],seed=None,history_delta=False,versions={},max_native_rounds=1,blue_native_rounds=0,
 schedule=[dict(version='P06',cohort='OBS',label='sdk_e2f022b_PJ01_P06_BASELINE_OBSERVATION_MAP02_FIRST')],
 observer_workspace=str(W),observer_sources=m['sources'],evaluator=str(H/'F32_official_sdk_20261028/postscore_visual_evaluator_v2.py'),
 authorization='Active human goal: evidence-led originalPJ01 one-rule-at-a-time. Need actual cause/cost data before another algorithm change. Exactly one original-clock RED-only diagnostic, no BLUE or score promotion.',
 questions=['Actual termination due branch and carried inventory','Received map/own frame provenance versus submission image owner','Inclusive/exclusive measured planning/merging/pose costs'],
 decision_scope='Observe only; no hypothesis of score improvement, no full RED score, no five-map rank, no retry or automatic expansion.',automatic_five=False)
V=F/'versions/P06';V.mkdir(parents=True);S=V/'source';S.mkdir()
for p in (W/'src/swarm_rescue/solutions').iterdir():
    if p.is_file():shutil.copy2(p,S/p.name)
shutil.copy2(W/'req.txt',S/'req.txt');files={p.name:sha(p)for p in S.iterdir()}
z=V/'P06_OBSERVER_INTERNAL_ONLY.zip'
with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED)as archive:
    for p in sorted(S.iterdir()):archive.write(p,p.name)
with zipfile.ZipFile(z)as archive:assert{n:hashlib.sha256(archive.read(n)).hexdigest()for n in archive.namelist()}==files
d['versions']['P06']=dict(original_zip=str(z),original_zip_sha256=sha(z),source=str(S),source_files=files)
(V/'QUALIFICATION.json').write_text(json.dumps(dict(status='PASS',payload_files_sha256=files,zip_sha256=sha(z),actual_source_entry_receipt=entry,official_submission_ready=False),indent=2)+'\n')
for p in [F/'run_offline.py',F/'ENTRY_P06_FIRST.json',F/'ACTUAL_P06_OBSERVER_V2.json']:
    d['frozen_files'][str(p)]=sha(p)
(F/'PREDECLARATION.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(dict(status='PREPARED_RED_ONLY_DIAGNOSTIC_NOT_STARTED',max_native=1,blue_native=0,workspace=str(W),payload_sha256=sha(z))))
