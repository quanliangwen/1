"""Reviewed own-state timing/exit analysis, never loads private arrays or truth."""
from pathlib import Path
import datetime,json
F=Path(__file__).resolve().parent
read=lambda n:json.loads((F/n).read_text(encoding='utf-8'))
assert read('LOCAL_COLLECTOR_RESULT.json')['status']=='COMPLETE'
assert read('CAMPAIGN_CLIENT_REVIEW.json')['status']=='PASS'
assert read('OBS_A/CLIENT_FIRST_RAW_REVIEW.json')['status']=='PASS'
d=read('OBS_A/MECHANISM_REVIEW.json');p=d['phase'];b=p['map_breakdown']
profiles={int(e['owner']):e for e in d['profiles']}
exits={int(e['owner']):e for e in d['actual_due']}
last_observed={}
for event in d['events']:
    if event['kind']=='SUBMISSION_DECISION':last_observed[int(event['owner'])]=event
owners=[];totals={};conservation=[]
for owner,e in sorted(profiles.items()):
    stats=e['timing'];control=stats.get('control',{})
    summed=sum(v['wall_exclusive']for v in stats.values())
    conservation.append(dict(owner=owner,exclusive_sum=summed,control_inclusive=control.get('wall_inclusive'),
       absolute_difference=abs(summed-control.get('wall_inclusive',0.))))
    for key,v in stats.items():
        r=totals.setdefault(key,dict(calls=0,wall_inclusive=0.,wall_exclusive=0.,cpu_inclusive=0.,cpu_exclusive=0.))
        for n in r:r[n]+=v[n]
    stop=exits.get(owner)
    owners.append(dict(owner=owner,actual_inventory=e['inventory'],final_actual_due=stop,
       profile_control_calls=control.get('calls'),profile_control_wall=control.get('wall_inclusive')))
ranking=sorted([dict(category=k,**v)for k,v in totals.items()],key=lambda v:-v['wall_exclusive'])
top_level_wall=sum(e['timing'].get('control',{}).get('wall_inclusive',0.)for e in profiles.values())
matches=d['image_binding']['matches'];selected=sorted({x['owner']for x in matches})
out=dict(status='ANALYZED_REVIEWED_RED_ONLY_OBSERVATION',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 observation_status=d['status'],map='Map02',map_score=p['score_map'],wall_score=p['score_wall'],time_score=p['score_time'],
 map_credit_pp=100*b['credit'],map_missing_loss_pp=100*(1-b['credit']),map_false_drawing_penalty_pp=100*b['penalty'],
 placed=d['placed'],expected=d['expected'],red_steps=d['red_steps'],red_wall_seconds=d['red_wall_seconds'],
 red_max_walltime_reached=d['red_max_walltime_reached'],bound_map_owners=selected,image_binding=d['image_binding'],
 final_by_owner=owners,last_sampled_decisions_by_owner=last_observed,
 profile_owners_present=sorted(profiles),profile_owners_missing=sorted(set(range(5))-set(profiles)),
 all_five_profiles_available=len(profiles)==5,global_timing_bottleneck_established=False,
 timing_by_exclusive_cost=ranking,timing_conservation=conservation,
 total_profiled_control_wall=top_level_wall,whole_red_minus_profiled_control=d['red_wall_seconds']-top_level_wall,
 conservation_within_1e_5=all(x['absolute_difference']<1e-5 for x in conservation),
 direct_budget_exit_owners=sorted(k for k,e in exits.items()if e['reason_from_actual_branch_conditions']=='BUDGET_EXHAUSTED'),
 direct_empty_certificate_exit_owners=sorted(k for k,e in exits.items()if e['reason_from_actual_branch_conditions']=='ALL_CERTIFICATES'),
 all_profiled_final_inventories_empty=bool(owners)and all(x['actual_inventory']==0 for x in owners),
 prior_P05_exit_causally_reconstructed=False,full_red_score=None,blue_runs=0,ranking_promoted=False,
 limits=['One independent unseeded RED run, cannot reconstruct old P05 hidden states.',
  'Calls are wrapper-entry counts, not unique models or independent plans.',
  'Exclusive control includes uninstrumented original driving/observation and audit work; whole-red remainder also includes SDK and reporting.',
  'Only the submitting owner prints PROFILE_FINAL. Missing owners make the whole-red remainder unprofiled controllers PLUS SDK/reporting, not a measured SDK-only cost.',
  'Frame source ids and packet counts do not prove each wall coordinate accurate or every message fresh.',
  'Only final submitted image is SHA bound; no ground-truth grid/private arrays read.'])
(F/'DIAGNOSIS_RESULT.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in out.items()if k not in ['final_by_owner','limits']},ensure_ascii=False))
