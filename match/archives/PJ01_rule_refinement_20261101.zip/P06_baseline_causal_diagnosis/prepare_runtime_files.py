from pathlib import Path
F=Path(__file__).resolve().parent;P=F.parent/'P05_finite_output_rule'
s=(P/'collect_offline.py').read_text(encoding='utf-8').split('def finish_scoped')[0]
s=s.replace('PJ01_rules_P05_finite_output_20261101','PJ01_rules_P06_baseline_audit_20261101')
s+='''
def main():
    started=time.monotonic()
    try:
        while time.monotonic()-started<14*3600:
            state=metadata();group=F/'OBS_A'
            if(group/'RAW_ARCHIVE_RECEIPT.json').exists():review(group)
            if state['status']=='COMPLETE_RED_ONLY_DIAGNOSTIC':
                state=metadata();d=read(group/'MECHANISM_REVIEW.json')
                assert read(group/'CLIENT_FIRST_RAW_REVIEW.json')['status']=='PASS'
                out=dict(status='PASS',utc=utc(),native_failure=state['first_native_failure'],native_rounds=1,blue_native_rounds=0,
                    map='Map02',map_score=d['phase']['score_map'],wall_score=d['phase']['score_wall'],time_score=d['phase']['score_time'],
                    placed=d['placed'],expected=d['expected'],red_wall_seconds=d['red_wall_seconds'],red_steps=d['red_steps'],
                    red_max_walltime_reached=d['red_max_walltime_reached'],observation_status=d['status'],image_binding=d['image_binding'],
                    full_red_score=None,ranking=False,scope='RED-only originalPJ01 observer, not a new algorithm or full-score ranking.')
                dest=F/'CAMPAIGN_CLIENT_REVIEW.json';save(dest,out);upload(dest,RC+'/'+dest.name)
                save(F/'LOCAL_COLLECTOR_RESULT.json',dict(status='COMPLETE',utc=utc(),starts_native_games=False))
                print(json.dumps(out),flush=True);return
            if state['status'].startswith('STOPPED'):
                save(F/'LOCAL_COLLECTOR_RESULT.json',dict(status='STOPPED_KEEP_FIRST',server_status=state['status'],utc=utc(),starts_native_games=False));return
            time.sleep(3)
        raise TimeoutError('Finite14h collection exhausted')
    except Exception:
        save(F/'LOCAL_COLLECTOR_RESULT.json',dict(status='FIRST_CLIENT_ERROR_KEEP',utc=utc(),traceback=traceback.format_exc(),starts_native_games=False));raise
if __name__=='__main__':main()
'''
(F/'collect_offline.py').write_text(s,encoding='utf-8')
for n in ['start_local_collector.py','launch_campaign.py']:
    s=(P/n).read_text(encoding='utf-8').replace('max_native_rounds=2','max_native_rounds=1').replace('SCOPED_PJ01_SINGLE_MAP_COMPARISON_LAUNCHED','READONLY_PJ01_RED_ONLY_DIAGNOSTIC_LAUNCHED')
    (F/n).write_text(s,encoding='utf-8')
print('Prepared P06 finite RED-only collection and launch files; no native start.')
