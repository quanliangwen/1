from pathlib import Path
import datetime,json
F=Path(__file__).resolve().parent;P=F.parent/'P05_finite_output_rule'
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
text=f'''最新UTC{now}，持续目标ACTIVE。当前P06：先补观测和归因缺口，不直接追加算法规则/五图。

P05已完整结束：原资源Map02仅红蓝各一局，15份原始文件首次Windows字节核验PASS、CAMPAIGN PASS，无native错误。
P05完整70.898657、地图92.287926、墙体覆盖73.701472、时间100、9/10；RED2073步176.4088秒，双方无官方墙钟hit。
复用刚完成原PJ01对照：完整74.795606、图95.625739、墙84.833681、时间100、10枚、1732步123.6507秒。原控制数据/SDK/对手/时限/线程不变，但独立无seed，不能当同输入因果。
P05有5条最终补图日志：owner0/1/2/3/4分别增加400/0/84/12/256像素，同一步2073提交。冻结评测器按无人机列表取第一个非空提交，按构造顺序推定0号计分；未记录图像SHA，不能说已精确字节绑定。
有限段支持计算5机累计3.95058秒；总红墙钟比对照长52.7581秒。不能直接把全部耗时或漏投归为该支持计算，额外计算也可能间接改变预算/轨迹，仍需真实分支观测。

关键归因证据（不读取竞赛真图）：
1. 复核原SDK map_exploration_scoring.py默认：墙面命中信用按exact像素，单个误绘像素charge<=1，penalty_weight=.2，surface_pixels为分母；地图单项w_map1/w_time0。
2. 对同一原图P只并入K个新像素Q，信用不能下降；地图变化必在[-100*.2K/N,100K/N]。已用原SDK评分器在8个独立作者掩膜验证，未读任何竞赛真图或NPZ/pickle。
3. 本局任何提交者新增最多400、官方分项N=50895，因此输出规则的直接同输入地图效果被夹在[-.157186,+.785932]分。
4. P05真实图92.287926对应的补图前原图必在[91.501994,92.445112]；与上一局原PJ0195.625739相比至少3.180627分差已在输出前形成。误绘差至少1.483014分、信用差至少1.697613分也不能全由薄并集本身造成。
5. 规则仍未过事前地图+.5/总不退/10枚门槛，不晋级、不五图、不重跑救分；但应记录“当前候选未证实且整体失败”，不能把独立两局-3.3378直接叫该渲染算子的因果损失。

下一实质步骤：只读观察器，不叠任何已淘汰规则。
baseline_audit.py准备完成：保留原PJ01决策返回值和参数/异常；记录本人实际退出True/False、当前库存、剩余预测、完成证书、覆盖模型、融合状态/任务/图来源；记录原submit传入图像SHA（用于公开PNG逆编码绑定），逐类记录控制/位姿/消息融合/路径/规划/模型的包含与排除子调用耗时。只读本机实际公共状态和已收消息，不真图/BLUE私态/队友对象，不改变截止或提交选择。
27项纯透传检查PASS，包含父方法恰调一次、返回对象/命令/原图对象不变、异常原样传播、嵌套计时栈清理。此检查使用控制夹具，不是真实SDK或物理闭环。
尚未建立P06候选工程、服务器workspace、SDK资格检查或待跑队列。不要把27项检查说成实际MRO/五机构造通过，也不要直接开native。
先从原PJ01独立底本加只读Mixin并做实际SDK类/入口/五机构造与预算分支小检查，再判断是否需原条件单Map02红队诊断（只查红队地图/投放/时限，无需BLUE难度；该诊断不是排名或新版算法）。保持原SDK/计分/物理，不为同输入影子评分更换冻结评测器或加载竞赛真图。
目标是定位图/任务和预算的实际缺口后再改下一条旧有用规则，不以常数/seed堆实验。

原P05coordinator2121706/start397673276和Windowscollector94968已正常结束，不可重启；P03/P02也已结束。执行前再核实际/proc命令/start、全局serial锁和registry，等待也算占用。原门槛CPU<=60/loadcore<=.4/RAM8GiB/盘12GiB/两样本60秒，SDK e2f022b/team006/线程时限/无外部seed，高负载旧授权耗尽。
正式V06/V07/V08不改、不发布。raw首Windows每组一次，不重新下载核验旧档，不反序列化数组。C7取消，无固定90分钟盲跑五图。用户新停止立即暂停。
'''
(F/'分析依据与下一步小检查.txt').write_text(text,encoding='utf-8')
(F/'WORKING_HANDOFF_P06.txt').write_text(text,encoding='utf-8')
decision=dict(status='P05_NOT_PROMOTED_NO_FIVE_CAUSAL_EFFECT_UNRESOLVED',utc=now,
 actual_score=70.89865739597266,actual_map=92.28792581540426,placed=9,
 direct_same_input_union_delta_bound=[-.1571863640829158,.785931820414579],minimum_gap_before_output=3.1806269341290943,
 goal_active=True,next_phase='P06_baseline_causal_diagnosis',native_queue_active=False,
 next_native_not_launched=True,readonly_diagnostic_contract_checks=27,actual_SDK_check_pending=True)
(P/'RETENTION_DECISION.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
(P/'P05结果与归因界限.txt').write_text(text.split('下一实质步骤')[0],encoding='utf-8')
with(P/'WORKING_HANDOFF_P05.txt').open('a',encoding='utf-8')as f:f.write('\nLATEST COMPLETE; nextP06:\n'+text)
idx=Path('E:/codex/swarm-eod-literature-analysis/CURRENT_ACTIVE_ANALYSIS.txt')
idx.write_text(f'''LATEST {now}: GoalACTIVE, current{F}/WORKING_HANDOFF_P06.txt. P05 COMPLETE notpromoted/no5, 15rawfirstPASS,noNativeError: full70.898657 map92.287926 wall73.701472 time100 q9of10 red2073steps176.4088sec/nohits. All5outputlogs maxadded400. SDKexactscoreformula gives own same-input thinunion effect[-.157186,+.785932], so preoutputmap<=92.445112; at least3.180627 observedmapgap alreadybeforeoutput, cannot blameall3.34loss onoutputoperator. P03/P02alsofinishedreject, originalPJ01basekept. P06readonly own branch/profile/submittedSHA observer prepared and27puretransparencyPASS, no candidate/workspace/realSDKcheck/nativerun yet. NEXT actualPJ01SDKadapter checks then decide necessary RED-only diagnostic, no blindnewrule/five. No activequeue; neverrestartP05old2121706/94968 oroldC7. OriginalresourcesSDKblueclocks frozen, no truth/privatearrays/BLUEstate; no officialrelease. Continue evidence-led work, don'tonlypollCOMPLETE.\n\n'''+idx.read_text(encoding='utf-8'),encoding='utf-8')
print(json.dumps(decision))
