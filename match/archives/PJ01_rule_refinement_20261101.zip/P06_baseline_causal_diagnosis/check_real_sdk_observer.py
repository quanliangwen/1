from pathlib import Path
import contextlib,io,json,sys
F=Path(__file__).resolve().parent;label,arm=sys.argv[1:]
m=json.loads((F/'WORKSPACE_READY.json').read_text())['versions'][arm];W=Path(m['workspace']);sys.path.insert(0,str(W/'src'))
import pyglet
from swarm_rescue.solutions.my_drone_eval import MyDroneEval
from swarm_rescue.solutions.bearing_memory import BearingMemory
from swarm_rescue.solutions.baseline_audit import BaselineAuditMixin
from swarm_rescue.solutions.completion_consensus import CompletionConsensusMixin
from swarm_rescue.maps.map_01 import Map01
window=pyglet.window.Window(width=1,height=1,visible=False)
checks=[]
def require(v,n):assert v,n;checks.append(n)
try:
    arena=Map01(drone_type=MyDroneEval,number_drones=5)
    require(MyDroneEval.__mro__[1]is BaselineAuditMixin,'actual_entry_first_MRO_is_observer')
    require(all(type(d.memory)is BearingMemory for d in arena.drones),'all_five_original_PJ01_memory_classes_retained')
    require(len({id(d._audit_stats)for d in arena.drones})==5,'all_five_profile_counters_independent')
    require(len({id(d._audit_stack)for d in arena.drones})==5,'all_five_nested_stacks_independent')
    require(not any(c.__name__in['ColoredPoseMixin','FiniteOutputMixin']for c in MyDroneEval.__mro__),'failed_P03_P05_modules_absent')
    rows=[]
    with contextlib.redirect_stdout(io.StringIO()):
        for d in arena.drones:
            step=int(d.elapsed_timestep);before=int(d.carried_bombs_count())
            expected=CompletionConsensusMixin._submission_due(d,step)
            actual=d._submission_due(step)
            require(actual==expected,'owner'+str(d.identifier)+'_actual_submission_method_matches_parent')
            require(int(d.carried_bombs_count())==before,'owner'+str(d.identifier)+'_inventory_unchanged')
            require(not d._audit_stack,'owner'+str(d.identifier)+'_real_stack_closed')
            rows.append(dict(owner=int(d.identifier),inventory=before,due=actual,remaining=d._remaining_steps()))
finally:window.close()
out=dict(status='PASS_REAL_SDK_OBSERVER_ENTRY_AND_INITIAL_BRANCHES',checks=checks,rows=rows,
 source_sha256=m['sources'],physics_steps=0,native_rounds=0,
 limitation='Real SDK five constructors and initial due branch only; not actual executed-flight loop, terminal budget diagnosis or score evidence.')
(F/(label+'.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status=out['status'],checks=len(checks),rows=rows)))
