from pathlib import Path
import json,datetime
ROOT=Path('E:/codex/PJ01_rule_refinement_20261101')
F=ROOT/'P26_budgeted_arrival_single'; N=ROOT/'P27_traversed_free_evidence';N.mkdir(exist_ok=True)
receipt=json.loads((F/'CAMPAIGN_CLIENT_REVIEW.json').read_text(encoding='utf-8'))
row=receipt['rows'][0]
assert receipt['status']=='PASS' and not row['pass_gate'] and not receipt['native_failure']
decision=dict(status='FAILED_FIXED_NATIVE_SCORE_GATE_NO_FIVE_NO_PROMOTION',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 score=row['score'],map_score=row['map_score'],wall_score=row['wall_score'],time_score=row['time_score'],placed=row['placed'],
 actual_confirmed_finer_releases=row['actual_rule_event_count'],native_failure=False,native_queue_active=False,
 reason='Complete RED score 74.53854 is below the unchanged predeclared 75 floor. Actual rule execution is not sufficient evidence of score improvement.',
 next_stage='P27_traversed_free_evidence',goal_remains_active=True,
 limits=['One unseeded Map02 observation, no causal paired performance claim.','No further P26 rerun or arrival-threshold tuning to rescue this score.','No five-map ranking/promotion or official submission.'])
(F/'RETENTION_DECISION.json').write_text(json.dumps(decision,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report='''P26最终结论：实际单图完成，固定分数门槛失败，不五图、不晋级、不重跑。
完整分74.5385396984，地图96.0262502379，墙覆盖82.4670728971，时间100，10/10枚；RED176.400678秒/1949步，双方无墙钟hit，无native失败。
15份raw首次Windows字节核验与CAMPAIGN PASS；不得重复raw核验。9枚实际细化后库存确认，末枚预算保护恢复原12px。五机最终均走原预算耗尽提交分支。
最终图地图门槛通过，但完整分<预设75。相对历史PJ01同图74.79560585仅独立观察差-0.25707，不构成因果配对；墙项减分抵消地图项增分。
新增审计用匿名公开弹药与本机库存确认请求做最小费用几何匹配，最优/次优差和间隔界显式保留。平均估计距目标7.1715、真实弹药距目标11.2452、真实弹药距请求估计位姿5.8584px。不是官方owner标签，不冒称上一版到达误差已改善。
最终RED预测墙像素在计划目标覆盖72386、实际弹药覆盖69638，差2748；它只是含误绘的最终预测图，不能等同计分真墙或规划时目标。定位/图框偏差仍影响精细到达，继续缩小阈值缺少提分依据。
下一步P27先做只读真实轨迹与最终预测墙矛盾检查，再研究能否用本机公共可得证据安全纠正，不以真值轨迹作为生产输入。生产修改与原生新队列均尚未创建。
旧coordinator2401274/worker2403090和Windowscollector90656均已实际核实结束，不能按旧PID启动/终止。其他任务不动。
'''
(F/'最终结论与后续依据.txt').write_text(report,encoding='utf-8')
prompt='''继续用户明确授权的ACTIVE原PJ01得分优先迭代，直到用户停止。当前阶段P27_traversed_free_evidence，先读E:/codex/AGENTS.md、E:/codex/swarm-eod-literature-analysis/CURRENT_ACTIVE_ANALYSIS.txt及P27本阶段交接/分析。最终以同条件完整RED五图均分为准；原PJ01独立底本，一次一条规则，文献/源码/反例/真实SDK小闭环先行，有希望才正式单图，再决定同期五图。必要补扫/绕障/汇合允许，不以直线/少重叠或单项代理代替总分。不spawn代理，旧match7不恢复，普通决策自主，不自行暂停/完成目标。
P26已完整结束，15raw首次Windows与CAMPAIGN PASS，无native失败；完整74.5385396984/地图96.0262502379/墙82.4670728971/时间100、10/10、双无墙钟hit、RED176.4007s1949步。实际9枚细化接近后库存确认，但固定完整>=75失败，因此不五图、不晋级、不重跑/改seed或label、不调到达阈值救分。RETENTION_DECISION和最终结论见P26。冻结INITFIX ZIP1e661794cc589a11d3126e3c02ee9553c7f2ed13977a40f79490636698851ded仅研究，正式包/维护池不变。旧coordinator2401274/worker2403090/Windows90656已实核结束，不恢复。平均估计目标误差7.17而真实弹药11.25px，定位/坐标偏差仍影响到达；匿名公开弹药几何匹配有最优次优差/分离界，只是推断非owner标签，最终预测图覆盖不是官方真墙分。
P27下一实质分析：检查最终提交图是否把实际走过的区域画成墙。已读冻结SDK reporting/explored_map.py update_drones，_explo_pts来自drone.true_position四舍五入到像素；仅用于离线公开轨迹诊断，不进入生产。先对已首次审核的public_visual和RED提交PNG做中心像素矛盾、保守样本足迹检查，明确离散/采样/坐标/接触模型限制；不要读取真图/NPZ或BLUE私态。再查原renderer是否已有visits/nonwall保护以及多层拟合墙是否能重添；不能简单清空16px visited格（栅格量化与GPS误差会抹真墙）。若有实际幅度再用本机公共观测的有界定位不确定性/已走足迹证据设计一条可共享兼容规则，正反例/真实SDK验证安全与开销，不能把公开true轨迹当生产输入。不重复失败P04/P05泛化有限墙输出，不盲目叠加旧失败规则。当前无新的native队列或候选包，先核状态再安排，勿只轮询COMPLETE。
历史P21cache刷新作者合同36PASS但真实U传感未误判实体、未触发，保留机制FAIL不native；P22单点oracle原完整供应器已修复局部market低收益，无需重复qualitygate；P23证实同次投放脉冲刹车不改当前弹药位置；P24/P25作者代理距离改善18.33/19.34%未达20%门槛，原FAIL保留。P26透明专家分流只允许一次完整score诊断，现已失败。P18去重69.6737被淘汰；P16后备76.0843但0触发不归因；P14保持72.8768/9枚淘汰；不得叠加。
SSH junhao@10.112.162.60；ROOT=/home/junhao/quan/parallel_test_solver/match；H=ROOT/solver_study/framework_screen_20261016/best87_independent_20261025；Python仅ROOT/.venv/bin/python。原生启动前核H/R154_scoped_serial_guard_20261101/check_scoped_serial.py、/proc实际cmd/start、ROOT/solver_study/serial_evaluation.lock、heuristic_20261016.json及所有等待coordinator（等待也占唯一调度），其他项目不动。原资源CPU<=60/loadcore<=.4/RAM8GiB/盘12GiB/两样本60秒，SDK e2f022b/team006LBBDRescue/原线程时限/无外seed不改，旧高负载授权已耗尽。作者seed615不是比赛reroll。首native失败保留停链，不自动重试；每组raw只首次WindowsSHA一次，NPZ/pickle只不透明字节不反序列化，BLUE私有日志不读。
生产只己方公共传感与实际收到消息，不读真图/队友对象/BLUE私态/历史评测输入，不硬编码地图坐标。所有新文件E:/codex任务目录。任何新正式包先SUBMISSION_POLICY实际ZIP615/ABI/SDK/平铺检查，不自动官网上传；V06/V07/V08和维护池不变。每次记录依据/实质修改/小测/原错/晋级淘汰；目标与自动化90保持ACTIVE，90分钟heartbeat不是强制全量。状态不变安静，仅机制结论/结果/失败/需人类决策通知。用户停止立即暂停后续调度。
'''
for path in [ROOT.parent/'swarm-eod-literature-analysis/CURRENT_ACTIVE_ANALYSIS.txt',N/'WORKING_HANDOFF_P27.txt',N/'AUTOMATION_PROMPT.txt']:
 path.write_text(prompt,encoding='utf-8')
(F/'WORKING_HANDOFF_P26.txt').write_text(report+'\n最新接续P27：\n'+prompt,encoding='utf-8')
(F/'AUTOMATION_PROMPT.txt').write_text(prompt,encoding='utf-8')
print(json.dumps(decision,ensure_ascii=False))
