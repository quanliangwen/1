"""Read reviewed public/own results only; no native scheduling or array loads."""
from pathlib import Path
import datetime,json
F=Path(__file__).resolve().parent
read=lambda n:json.loads((F/n).read_text(encoding='utf-8'))
review=read('CAMPAIGN_CLIENT_REVIEW.json')
assert review['status']=='PASS' and not review['native_failure']
assert read('LOCAL_COLLECTOR_RESULT.json')['status']=='COMPLETE'
rows=[]
for group in ['PJ01_A','P03_A']:
    assert read(group+'/CLIENT_FIRST_RAW_REVIEW.json')['status']=='PASS'
    d=read(group+'/MECHANISM_REVIEW.json');p=d['phase'];b=p['map_breakdown']
    raw=read(group+'/RESULT.json')['jobs']['Map02']['rounds'][0]
    rows.append(dict(version=d['version'],map='Map02',total=d['score'],map_score=p['score_map'],wall=p['score_wall'],time=p['score_time'],
      trajectory_coverage=p['score_exploration_trajectory'],placed=d['placed'],expected=d['expected'],red_steps=d['red_steps'],red_wall_seconds=d['red_walltime'],
      red_wall_hit=d['red_wall_hit'],blue_wall_hit=d['blue_wall_hit'],blue_disposed=raw['blue']['disposed'],blue_steps=raw['blue']['timestep'],
      map_credit_pp=100*b['credit'],map_false_drawing_penalty_pp=100*b['penalty'],wall_hits=b['wall_hits'],wall_pixels=b['wall_pixels']))
events=read('P03_A/MECHANISM_REVIEW.json')['events']
initialized=sorted({e['owner'] for e in events if e['event']=='INITIALIZED'})
periodic=sorted({e['owner'] for e in events if e['event']=='PERIODIC' and e['updates']>0})
last={}
for e in events:
    if e['owner'] not in last or e['step']>last[e['owner']]['step']:last[e['owner']]=e
delta={k:rows[1][k]-rows[0][k] for k in ['total','map_score','wall','time','trajectory_coverage','placed','red_steps','red_wall_seconds','map_credit_pp','map_false_drawing_penalty_pp']}
gate=dict(all_five_filters_actual_initialized=initialized==list(range(5)),all_five_periodic_updates=periodic==list(range(5)),
          map_gain_at_least_half_point=delta['map_score']>=.5,full_not_below_contemporary_PJ01=delta['total']>=0,
          all10_placed=rows[1]['placed']==rows[1]['expected']==10,
          no_red_blue_clock_hits=not(rows[1]['red_wall_hit'] or rows[1]['blue_wall_hit']))
result=dict(status='PASS_REVIEWED_OBSERVATION',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 rows=rows,delta_P03_minus_PJ01=delta,initialized=initialized,periodic=periodic,last_filter_events=last,
 gate=gate,eligible_for_five_map_consideration=all(gate.values()),automatic_five_started=False,
 stable_causal_effect_established=False,scope='Two independent unseeded original Map02 runs, not ranking or stable causal proof; own filter diagnostics and public score only.')
(F/'REVIEWED_COMPARISON.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
lines=['P03：原PJ01单条定位滤波规则Map02对照（完整原生红蓝，首次原始字节核验通过）','',
 '版本 | 完整红分 | 地图 | 墙体覆盖 | 时间 | 投放 | 红步数 | 红墙钟秒 | 双方超时']
for r in rows:
    lines.append(f"{r['version']} | {r['total']:.6f} | {r['map_score']:.6f} | {r['wall']:.6f} | {r['time']:.4f} | {r['placed']}/{r['expected']} | {r['red_steps']} | {r['red_wall_seconds']:.4f} | {r['red_wall_hit']}/{r['blue_wall_hit']}")
lines+=['','地图变化（P03-PJ01）：'+json.dumps(delta,ensure_ascii=False),
 '实际滤波初始化owner：'+str(initialized)+'；实际周期更新owner：'+str(periodic),
 '固定小试门槛：'+json.dumps(gate,ensure_ascii=False),
 '达到进入五图前进一步分析条件：'+str(result['eligible_for_five_map_consideration']),
 '本脚本不会启动五图。每版仅一局、无外部seed，不能证明因果或稳定提分。完整分及双方超时如实报告，不把地图小检查当原生成绩。']
(F/'Map02对照分析.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='last_filter_events'},ensure_ascii=False))
