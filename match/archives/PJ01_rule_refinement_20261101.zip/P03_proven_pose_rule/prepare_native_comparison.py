from pathlib import Path
import json,zipfile,shutil,hashlib
F=Path(__file__).resolve().parent;H=F.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not(F/'PREDECLARATION.json').exists()
m=read(F/'WORKSPACE_READY.json')
assert read(F/'POSE_MAPPING_CHECK.json')['status']=='PASS'
assert read(F/'METHOD_P03_FIRST.json')['status']=='PASS'
old=read(H/'F32_official_sdk_20261028/FIVE_MAP_REBASELINE/PREDECLARATION.json')
d={k:old[k] for k in ['sdk_commit','sdk_files','blue_binding','blue_binding_sha256','resource_gate','frozen_files']}
d.update(phase=F.name,selection=['PJ01','P03'],maps=['Map02'],seed=None,history_delta=False,versions={},max_native_rounds=4,min_native_rounds=4,
 authorization='2026-11-01 human: resume PJ01 base map-first iteration, one historically map-helpful rule at a time; analysis then small tests, five only with improvement.',
 hypothesis='One colored-sensor pose-estimation rule, preserving original PJ01 layout/planning/movement/map renderer/fusion/completion/req. P02 absent. Three interface files, one logic rule.',
 schedule=[dict(version='PJ01',cohort='A',label='sdk_e2f022b_PJ01_RULE_P03_BASE_MAP02_FIRST'),dict(version='P03',cohort='A',label='sdk_e2f022b_PJ01_RULE_P03_POSE_MAP02_FIRST')],
 automatic_five=False,ranking_promoted=False,
 rule_acceptance=dict(all_five_filters_actual_initialized=True,actual_periodic_updates=True,map_score_gain_at_least=0.5,
     all10_placed=True,red_blue_no_wallclock_hit=True,complete_score_not_below_current_PJ01=True),
 qualification_scope='Internal source bundle and current server numeric/SDK/5constructor plus real-method checks; not official competition release.',
 inherited_limitation='EKF is local Gaussian approximation with original boundary correction feedback. Constructed ideal ranges and independent unseeded matches do not prove global game optimality or causal stable improvement.')
for version in d['selection']:
    w=m['versions'][version];W=Path(w['workspace']);assert all(sha(W/n)==v for n,v in w['sources'].items())
    qual=read(F/('ENTRY_'+version+'_FIRST.json'));assert qual['status']=='PASS_SERVER_RESEARCH_ENTRY_NOT_OFFICIAL_RELEASE' and qual['sources']==w['sources']
    V=F/'versions'/version;V.mkdir(parents=True);S=V/'source';S.mkdir()
    for p in (W/'src/swarm_rescue/solutions').iterdir():
        if p.is_file():shutil.copy2(p,S/p.name)
    shutil.copy2(W/'req.txt',S/'req.txt');files={p.name:sha(p) for p in S.iterdir()}
    z=V/(version+'_INTERNAL_RESEARCH_ONLY.zip')
    with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED) as archive:
        for p in sorted(S.iterdir()):archive.write(p,p.name)
    with zipfile.ZipFile(z) as archive:assert {n:hashlib.sha256(archive.read(n)).hexdigest() for n in archive.namelist()}==files
    d['versions'][version]=dict(original_zip=str(z),original_zip_sha256=sha(z),source=str(S),source_files=files)
    (V/'QUALIFICATION.json').write_text(json.dumps(dict(status='PASS',payload_files_sha256=files,zip_sha256=sha(z),actual_source_entry_receipt=qual,
        official_submission_ready=False,scope=d['qualification_scope']),indent=2)+'\n')
for p in [F/'run_offline.py',F/'METHOD_P03_FIRST.json',F/'POSE_MAPPING_CHECK.json',F/'ENTRY_PJ01_FIRST.json',F/'ENTRY_P03_FIRST.json']:
    d['frozen_files'][str(p)]=sha(p)
(F/'PREDECLARATION.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='PREPARED_MAP02_PAIR_ONLY_NOT_LAUNCHED',max_native=4,selection=d['selection'],gate=d['rule_acceptance'])))
