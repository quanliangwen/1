"""Small same-input CPU check, no SDK/native and no accuracy inference."""
from pathlib import Path
from types import SimpleNamespace
import ast,importlib.util,json,math,time
import numpy as np
F=Path(__file__).resolve().parent
B=F.parent/'P01_baseline_rules/baseline_project/src/swarm_rescue/solutions'
spec=importlib.util.spec_from_file_location('candidate_colored',F/'candidate_project/src/swarm_rescue/solutions/colored_pose.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
tree=ast.parse((B/'greedy_mapping.py').read_text(encoding='utf-8'))
c=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='GreedyMappingDrone')
f=next(n for n in c.body if isinstance(n,ast.FunctionDef) and n.name=='_update_pose')
ns=dict(np=np,math=math,wrap_angle=m.wrap)
exec(compile(ast.unparse(f),'actual_PJ01_pose_method','exec'),ns)
base=ns['_update_pose']
n=2000;t=np.arange(n)
gps=np.column_stack((3*np.sin(t*.01),3*np.cos(t*.01)));comp=.03*np.sin(t*.01)
odom=np.zeros((n,3))
def run(kind):
    if kind=='baseline':
        p=SimpleNamespace(pose=None,heading=0.,heading_initialized=False,rally=None)
        p.measured_gps_position=lambda:p.g;p.measured_compass_angle=lambda:p.c;p.odometer_values=lambda:p.o
    else:p=m.ColoredPoseFilter()
    start=time.process_time()
    for k in range(n):
        if kind=='baseline':p.g=gps[k];p.c=comp[k];p.o=odom[k];base(p)
        else:p.update(gps[k],comp[k],odom[k])
    return time.process_time()-start
run('baseline');run('filter')
runs=[dict(kind=k,cpu_seconds=run(k)) for k in ['baseline','filter','filter','baseline']]
cost={k:float(np.mean([r['cpu_seconds'] for r in runs if r['kind']==k]))/n for k in ['baseline','filter']}
out=dict(status='MEASURED_NOT_GAME_BENCHMARK',updates_per_run=n,order='ABBA',runs=runs,mean_cpu_seconds_per_update=cost,
 additional_cpu_seconds_for_5_drones_2000_steps=(cost['filter']-cost['baseline'])*5*2000,
 scope='Local same-input actual baseline method versus candidate filter; no SDK, native, mapping, collision or full-runtime acceleration claim.')
(F/'POSE_RUNTIME_CHECK.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps(out))
