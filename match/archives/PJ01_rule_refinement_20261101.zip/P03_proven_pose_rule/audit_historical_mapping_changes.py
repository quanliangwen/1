from pathlib import Path
import difflib,hashlib,json
F=Path(__file__).resolve().parent
B=F.parent/'P01_baseline_rules/baseline_project/src/swarm_rescue/solutions'
J=Path('E:/codex/J17_gurobi_team615_red_v08_20261030/source/solutions')
names=['greedy_mapping.py','bearing_memory.py','bearing_core.py','anchor_mapping.py','boundary_anchor.py','frame_mapping.py',
       'line_regularization.py','rectangular_boundary.py','scan_geometry.py','short_wall_support.py','active_coverage.py','joint_survey.py','completion_consensus.py','terminal_value.py']
rows=[];diffs=[]
for name in names:
    a,b=B/name,J/name
    assert a.exists() and b.exists(),name
    same=a.read_bytes()==b.read_bytes()
    rows.append(dict(file=name,identical=same,baseline_sha256=hashlib.sha256(a.read_bytes()).hexdigest(),J17_sha256=hashlib.sha256(b.read_bytes()).hexdigest()))
    if not same:
        diffs.extend(difflib.unified_diff(a.read_text(encoding='utf-8-sig').splitlines(),b.read_text(encoding='utf-8-sig').splitlines(),fromfile='PJ01/'+name,tofile='J17/'+name,lineterm=''))
(F/'HISTORICAL_MAPPING_SOURCE_AUDIT.json').write_text(json.dumps(dict(status='SOURCE_COMPARISON_ONLY_NOT_EFFECT_PROOF',files=rows),indent=2)+'\n',encoding='utf-8')
(F/'历史建图模块差异.txt').write_text('\n'.join(diffs)+'\n',encoding='utf-8')
print(json.dumps(dict(identical=[r['file'] for r in rows if r['identical']],different=[r['file'] for r in rows if not r['identical']]),ensure_ascii=False))
