from pathlib import Path
import ast, datetime, hashlib, json, shutil

F=Path(__file__).resolve().parent
ROOT=F.parent
B=ROOT/'P01_baseline_rules/baseline_project'
OLD=Path('E:/codex/swarm-eod-literature-analysis/F50_colored_sensor_estimation_20261030')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
out=F/'candidate_project'
assert not out.exists()
shutil.copytree(B,out,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
S=out/'src/swarm_rescue/solutions'
reference=(OLD/'colored_pose_reference.py').read_text(encoding='utf-8')
mixin=(OLD/'colored_pose_mixin.txt').read_text(encoding='utf-8')
(S/'colored_pose.py').write_text(reference+mixin,encoding='utf-8')
p=S/'my_drone_eval.py';s=p.read_text(encoding='utf-8')
old='ExplorationMotionMixin,CoveragePlacementDrone'
assert s.count(old)==1
p.write_text('from swarm_rescue.solutions.colored_pose import ColoredPoseMixin\n'+s.replace(old,'ExplorationMotionMixin,ColoredPoseMixin,CoveragePlacementDrone',1),encoding='utf-8')
p=S/'anchor_mapping.py';s=p.read_text(encoding='utf-8')
old='self.pose,self.heading,_ = self.boundary_anchor.correct(lines,self.pose,self.heading,int(self.elapsed_timestep))'
assert s.count(old)==1
p.write_text(s.replace(old,'self.pose,self.heading,anchor_used = self.boundary_anchor.correct(lines,self.pose,self.heading,int(self.elapsed_timestep))\n        if anchor_used and hasattr(self,"_colored_accept_anchor"):\n            self._colored_accept_anchor()',1),encoding='utf-8')
for p in S.glob('*.py'):ast.parse(p.read_text(encoding='utf-8-sig'))
files={p.relative_to(out).as_posix():sha(p) for p in out.rglob('*') if p.is_file()}
base={p.relative_to(B).as_posix():sha(p) for p in B.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
changes=sorted(n for n,h in files.items() if base.get(n)!=h)
assert changes==['src/swarm_rescue/solutions/anchor_mapping.py','src/swarm_rescue/solutions/colored_pose.py','src/swarm_rescue/solutions/my_drone_eval.py']
assert sha(S/'geometry_navigation.py')==sha(B/'src/swarm_rescue/solutions/geometry_navigation.py')
manifest=dict(status='PREPARED_ONE_POSE_ESTIMATION_RULE_NOT_NATIVE_QUALIFIED',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 candidate_project=str(out),files=files,changed_files=changes,original_PJ01_base=True,P02_included=False,
 historical_reference_sha256=sha(OLD/'colored_pose_reference.py'),historical_mixin_sha256=sha(OLD/'colored_pose_mixin.txt'),
 unchanged_mapping_fusion_motion_layout_exit_req=True,official_submission_created=False)
(F/'CANDIDATE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
# Pure same-input generated-room check adapted only to PJ01 paths, 8 declared cases.
test=(OLD/'check_pose_mapping.py').read_text(encoding='utf-8')
test=test.replace('from colored_pose_reference import ColoredPoseFilter,wrap',
 'import sys\nsys.path.insert(0,str(Path(__file__).resolve().parent/"candidate_project/src/swarm_rescue/solutions"))\nfrom colored_pose import ColoredPoseFilter,wrap')
start="S=Path('/home/junhao/quan/parallel_test_solver/match/experiments/target90_20261012/official_workspaces/f48_J05_actual_zip_check/src/swarm_rescue/solutions')"
assert start in test
test=test.replace(start,'S=Path('+repr(str(B/'src/swarm_rescue/solutions'))+')')
test=test.replace('for seed in range(8)','for seed in range(2)')
test=test.replace("(F/'colored_pose_reference.py').read_bytes()","(F/'candidate_project/src/swarm_rescue/solutions/colored_pose.py').read_bytes()")
test=test.replace('all32 cases','all8 predeclared cases')
(F/'check_same_input_wall_error.py').write_text(test,encoding='utf-8')
# Reuse actual-method contract harness, later bound to this workspace and manifest.
test=(OLD/'check_candidate_contract.py').read_text(encoding='utf-8')
test=test.replace("F=R/'solver_study/framework_screen_20261016/best87_independent_20261025/F50_colored_sensor_estimation_20261030'",'F=Path(__file__).resolve().parent')
test=test.replace("b=json.loads((F/'J06/BUILD.json').read_text());sys.path.insert(0,str(Path(b['workspace'])/'src'))", "arm=sys.argv[1];b=json.loads((F/'WORKSPACE_READY.json').read_text())['versions'][arm];sys.path.insert(0,str(Path(b['workspace'])/'src'))")
test=test.replace("zip_sha256=b['zip_sha256']",'sources=b["sources"]')
test=test.replace("(F/'J06/CANDIDATE_CONTRACT_CHECK.json')","(F/'P03_ACTUAL_METHOD_CHECK.json')")
(F/'check_actual_methods.py').write_text(test,encoding='utf-8')
print(json.dumps(dict(status=manifest['status'],changes=changes)))
