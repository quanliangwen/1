from pathlib import Path
import datetime,json
F=Path(__file__).resolve().parent
d=json.loads((F/'REVIEWED_COMPARISON.json').read_text(encoding='utf-8'))
assert not d['eligible_for_five_map_consideration']
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
text=f'''P03已完成，不保留、不扩五图；UTC{now}。
原PJ01Map02：完整74.795606，地图95.625739，墙84.833681，时间100，10/10，1732步/123.6507秒。
P03单条滤波：完整73.114139，地图93.828117，墙80.920405，时间100，10/10，1542步/136.9499秒。
两版红蓝无墙钟hit，蓝队各清10/10。30原始文件首次Windows字节核验PASS，CAMPAIGN PASS，无native错误。未重跑未改seed。
5机滤波全初始化、全有周期更新，共35条诊断；末次每机1440更新、锚点反馈88/212/80/266/134。数值未见非有限异常，但滤波协方差不是物理定位真值。
实际地图变化：误绘扣分2.880990→1.863012（减少1.017978），墙体信用98.506730→95.691129（减少2.815601），净地图-1.797622。轨迹探索100→99.99882，不能用轨迹面积解释全部墙体损失。
红步数少190但墙钟增加13.2993秒；本地ABBA仅滤波计算额外约0.3125CPU秒/5机2000步的微基准，不足以证明实际这13秒来自小矩阵滤波。地图/路径/融合计算与行为均可间接变化；两局无外部seed，不能声称已因果隔离每个原因。
结论：历史单局97.17和8个同输入生成墙面检查均不是当前PJ01实赛改善保证。本候选没有达事前门槛，不为了凑五图扩跑，不调噪声/标签追分。原PJ01底本保留，不叠P02/P03。

继续研究方向：从原PJ01检查旧R150/R158“仅输出端有限实测墙段支持”是否还有未覆盖的功能缺口。先实际Memory、相同观测、原SDK评分作静态影子对照；禁止改变当前导航/布点/通信/退出，也不能把模拟场景成绩当五图。基线已有TLS/Hough/多视向等，若重复或无收益，直接记为不适用，不建立比赛候选。
目标及automation90继续ACTIVE，旧C7不恢复，正式包不改。
'''
(F/'P03不保留与后续分析.txt').write_text(text,encoding='utf-8')
(F/'RETENTION_DECISION.json').write_text(json.dumps(dict(status='REJECT_P03_NO_FIVE',utc=now,retain_original_PJ01=True,
 map_delta=d['delta_P03_minus_PJ01']['map_score'],full_delta=d['delta_P03_minus_PJ01']['total'],
 first_byte_files=30,native_failure=False,goal_remains_active=True,next_phase='P04_existing_finite_wall_audit',new_native_started=False),indent=2)+'\n',encoding='utf-8')
with(F/'分析依据与测试记录.txt').open('a',encoding='utf-8')as f:f.write('\n\n'+text)
with(F/'WORKING_HANDOFF_P03.txt').open('a',encoding='utf-8')as f:f.write('\nLATEST COMPLETE: '+text)
print(json.dumps(dict(status='RECORDED_REJECT_P03_CONTINUE_ANALYSIS',utc=now)))
