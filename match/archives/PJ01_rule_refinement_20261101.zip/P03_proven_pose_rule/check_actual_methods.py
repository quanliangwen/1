from pathlib import Path
from types import SimpleNamespace
import ast,contextlib,hashlib,io,json,math,sys
import numpy as np
R=Path('/home/junhao/quan/parallel_test_solver/match')
F=Path(__file__).resolve().parent
label,arm=sys.argv[1:];b=json.loads((F/'WORKSPACE_READY.json').read_text())['versions'][arm];sys.path.insert(0,str(Path(b['workspace'])/'src'))
from swarm_rescue.solutions.colored_pose import ColoredPoseFilter,ColoredPoseMixin,wrap
from swarm_rescue.solutions.anchor_mapping import AnchoredMappingMixin
from swarm_rescue.solutions.greedy_mapping import GreedyMappingDrone
from swarm_rescue.solutions.my_drone_eval import MyDroneEval
checks=[]
def require(v,n):assert v,n;checks.append(n)
f=ColoredPoseFilter();require(f.update(None,None,None)==(None,None),'no_invented_pose_without_initial_observations')
f.initialize([2.,3.],.2);f.x[3:]=[4.,-2.,.03];old=f.x.copy();P=f.P.copy()
f.update(None,None,[0.,0.,0.]);require(np.allclose(f.x[3:],old[3:]),'disabled_noise_bias_frozen')
before=f.x.copy();P=f.P.copy();obs=np.array([f.x[0]+f.x[3],f.x[1]+f.x[4],wrap(f.x[2]+f.x[5])])
f.reanchor([1.,2.],-.1)
require(np.allclose([f.x[0]+f.x[3],f.x[1]+f.x[4],wrap(f.x[2]+f.x[5])],obs),'anchor_preserves_current_absolute_observation')
require(np.array_equal(f.P,P),'anchor_does_not_add_fake_information')
require(np.allclose(f.x[:3],[1.,2.,-.1]),'anchor_sets_exported_pose_without_next_step_reversion')
f=ColoredPoseFilter();f.initialize([0.,0.],0.);mean=np.zeros(2);cov=np.array([[25.,-25.],[-25.,25.]])
A=np.diag([1.,.98]);Q=np.diag([.04,25*(1-.98**2)]);H=np.array([1.,1.])
for t in range(100):
    z=math.sin(t*.1)*3
    mean=A@mean;cov=A@cov@A.T+Q;s=float(H@cov@H+1e-10);gain=cov@H/s
    mean+=gain*(z-H@mean);cov=cov-np.outer(gain,H@cov)
    f.update([z,0.],0.,[0.,0.,0.])
    require(np.allclose(f.x[[0,3]],mean,atol=1e-9) and np.allclose(f.P[np.ix_([0,3],[0,3])],cov,atol=1e-9),f'independent_scalar_KF_step{t}')
owners=[c.__name__ for c in MyDroneEval.__mro__ if '_update_pose' in c.__dict__]
print('ACTUAL_UPDATE_OWNERS',owners,flush=True)
require(owners==['ActiveCoverageMixin','FrameMappingMixin','AnchoredMappingMixin','ColoredPoseMixin','GreedyMappingDrone'],'actual_pose_update_MRO_keeps_active_frame_and_anchor_order')
class Legacy:
    _update_pose=GreedyMappingDrone._update_pose
    def measured_gps_position(self):return self.gps
    def measured_compass_angle(self):return self.compass
    def odometer_values(self):return self.odom
class Probe(ColoredPoseMixin,Legacy):
    def __init__(self):
        self.identifier=0;self.elapsed_timestep=2;self.pose=None;self.heading=0.;self.heading_initialized=False;self.rally=None
        self._colored_pose_filter=ColoredPoseFilter();self._colored_pose_updates=self._colored_anchor_updates=self._colored_odom_recoveries=0;self._colored_last_odom_valid=False
        self.gps=None;self.compass=.3;self.odom=np.zeros(3)
p=Probe()
with contextlib.redirect_stdout(io.StringIO()):
 p._update_pose();require(p.pose is None and p.heading_initialized,'legacy_compass_only_initialization_retained')
 p.gps=np.array([1.,2.]);p._update_pose()
 require(p._colored_pose_filter.x is not None and np.allclose(p.pose,[1.,2.]),'smooth_initialization_when_GPS_returns')
 p.odom=None;p.gps=np.array([2.,2.]);p._update_pose();p.odom=np.array([1000.,0.,0.]);p._update_pose()
 require(p._colored_odom_recoveries==1 and np.linalg.norm(p.pose)<20,'cumulative_recovery_odometry_not_double_counted')
 p._update_pose();require(p._colored_odom_recoveries==1,'normal_odometry_resumes_after_single_recovery')
class AnchorProbe(AnchoredMappingMixin,Probe):
    def __init__(self):
        Probe.__init__(self)
        self.boundary_anchor=SimpleNamespace(correct=lambda lines,pos,head,step:(pos+np.array([.5,-.25]),wrap(head+.01),True))
    def lidar_values(self):return np.ones(180)*100
    def lidar_rays_angles(self):return np.linspace(-math.pi,math.pi,180,endpoint=False)
    def semantic_values(self):return []
    memory=SimpleNamespace(semantic_mask=lambda *args:np.zeros(180,bool))
p=AnchorProbe();p.gps=np.zeros(2);p.compass=0.
with contextlib.redirect_stdout(io.StringIO()):
 p._update_pose();p.elapsed_timestep=4;p._update_pose()
require(p._colored_anchor_updates==1,'actual_existing_anchor_calls_feedback_once')
require(np.allclose(p.pose,p._colored_pose_filter.x[:2]) and abs(wrap(p.heading-p._colored_pose_filter.x[2]))<1e-12,'actual_anchor_export_and_filter_state_consistent')
require(p._colored_pose_filter is not Probe()._colored_pose_filter,'independent_per_drone_filter_state')
out=dict(status='PASS',sources=b["sources"],checks=checks,actual_update_MRO=owners,native_games=0,
    scope='Actual candidate methods, unchanged parent initialization, actual anchor call, independent scalar KF reference; no physical dynamics or game-score proof.')
(F/(label+'.json')).write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(status='PASS',checks=len(checks),sources=b["sources"],MRO=owners)))
