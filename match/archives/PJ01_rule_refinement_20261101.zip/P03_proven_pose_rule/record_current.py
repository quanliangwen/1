from pathlib import Path
import datetime,json
F=Path(__file__).resolve().parent
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
text=f'''最新目标已由用户在应用内修改并恢复ACTIVE，核实于UTC2026-11-01 03:53:53之后；automation90也已更新为PJ01地图精度优先并ACTIVE。当前普通决策和持续研究已授权，直到用户停止。旧C7取消，不恢复固定90分钟盲目五图。

当前P03：以原PJ0136Py底本（与F32 source_hashes逐项一致）单独适配F50/J06有色噪声定位滤波规则。不含失败P02，不含J系列MILP/QP，不改原探索/任务/运动/地图渲染/融合/布局/退出/依赖。一个逻辑规则需要3处源码接口：新增colored_pose.py、my_drone_eval.py插入滤波Mixin、anchor_mapping.py将原边界均值校正反馈到滤波状态。地图与规划会因定位输入变化而间接受影响，不能声称下游行为完全不变。

选择依据：历史J06实际Map02地图97.173986、10/10、双方无超时，但总72.715299未达当时75门槛；只作为建图机制证据，不叫整版成功。GPS/罗盘SDK具有相关噪声，原固定比例融合与此不同；增广EKF显式估计位置/方向及偏置。局部线性化、高斯近似，不是精确后验，也不保证每局改善。

先做小检查，已完成：
1. 原PJ01实际基类位姿更新AST，与新滤波在相同8个预定生成房间输入场景比较。8/8墙面法向误差改善。启用原边界锚点时，椭圆两例均值6.73834→1.62019px，往返5.63231→1.20598px；理想激光仅隔离定位误差，无真实比赛地图或动态碰撞，不能当实赛分。
2. 真实候选类113条断言PASS，其中100为同一个独立标量KF连续100步，不是113个独立场景。实际MRO保留Active/Frame/Anchor/Colored/Greedy顺序；检查部分传感初始化、禁用噪声过程冻结、里程计恢复累计量不重复积分、锚点不伪增信息/均值一致、各机滤波状态独立。
3. 两版真实NumPy mtrand/随机数、Pandas/OpenCV操作、SDK Launcher/Stats、整数615、原Map01五机独立构造PASS，0物理步、不安装新依赖，不是官网发布检查。

预先固定下一小试：原Map02先PJ01_A后P03_A，各红蓝一局，共4native。地图分较同期原PJ01至少+0.5、总分不低于同期原PJ01、10/10、双方无墙钟超时、五机实际初始化并周期更新，才有扩五图的依据；不自动扩，先分析分项和实际触发。单次无种子差不能证明因果稳定；失败不重跑/改label救分，首native错误停链保留。

UTC03:53:55已启动服务器coordinator2098841/start397558937，Windowscollector89104/UTC03:53:53，14h有限收集窗口。服务器阶段H/PJ01_rules_P03_pose_20261101，原全局锁/registry核空后启动；等待也占本聊天唯一调度。原资源CPU<=60/loadcore<=.4/RAM8GiB/盘12GiB/两样本60秒，SDK e2f022b/team006/原时限线程不变，无外部seed。不要重复启动。
注意启动回执/驱动保留的builtin_goal_edit_resume_pending是准备时的历史字段；已被用户实际ACTIVE与本文件覆盖，不修改冻结驱动救正该行政字段。后续读实时get_goal。

原始文件首Windows字节审每组一次，不反序列化NPZ/pickle、不读BLUE私态；生产只本机观测和实收消息。正式V06/V07/V08及依赖不改，不发布上传。
'''
(F/'分析依据与测试记录.txt').write_text(text,encoding='utf-8')
(F/'WORKING_HANDOFF_P03.txt').write_text(f'''LATEST {now}: PJ01地图精度逐条规则持续目标ACTIVE（用户已在应用改目标并恢复）；automation90 ACTIVE。当前P03真实Map02原版+滤波单规则有限对照已启动，max4native，无自动五图。先读分析依据与测试记录.txt、STATUS/RESULT/CAMPAIGN_CLIENT_REVIEW。coordinator2098841/start397558937 UTC03:53:55，Windowscollector89104 UTC03:53:53，先核实际cmd/start/锁/registry，不重启。
8个同输入生成墙面检查PASS，实际类113断言及两版ABI/SDK5constructorPASS。原版PJ0136Py不含失败P02，P03只加有色噪声位姿滤波，3个接口文件，不带MILP/QP，不改依赖。候选冻结勿运行中修改。
固定小试门槛：五机实际初始化和周期更新、map_gain>=0.5、total>=同期PJ01、10/10、双方无墙钟hit；通过先分析分项有希望才新建同期五图，失败保存不重跑救分。首native失败停链。原SDK/蓝队/时限/线程/资源门槛不改。
P02已完成并拒绝，不重跑不叠加；P01未证明暂缓，旧R194和C7不恢复。当前目标持续研究，不在本阶段结束后只轮询COMPLETE，应消化结果和旧规则依据推进下一独立规则。用户新停止立即暂停。
启动回执的builtin_goal_edit_resume_pending是准备时旧字段，实时goal已ACTIVE，以最新用户和本文件为准。原始字节审核每组一次，不读取BLUE私态或反序列化数组。正式提交包不改。
''',encoding='utf-8')
idx=Path('E:/codex/swarm-eod-literature-analysis/CURRENT_ACTIVE_ANALYSIS.txt')
idx.write_text(f'''LATEST {now}: USER UPDATED AND RESUMED BUILTIN GOAL ACTIVE, automation90ACTIVE now PJ01 map-first proven-rules-one-at-time. Current{F}/WORKING_HANDOFF_P03.txt. P03 only colored pose rule on originalPJ01, failedP02absent. Sameinput8wallschecks and actual113assertions(100sameKFsteps), ABI/SDK5constructorsPASS. FiniteMap02 PJ01_A thenP03_A max4native launched2098841/start397558937UTC03:53:55, Windowscollector89104UTC03:53:53, doNOTduplicate. OriginalresourcesSDKblueclocks unchanged. Gate map+.5/fullnotlower/10of10/nohits/5filtersactual; noautomaticfive. Oncecomplete analyze and continue evidence-led rule work; noidleCOMPLETEpolling. OldC7cancelled,no90minblindfive,noR194/P01resume. Launchpending-goalflag is historical; realusergoalACTIVE supersedes.\n\n'''+idx.read_text(encoding='utf-8'),encoding='utf-8')
schedule=Path('E:/codex/UAV_rules_astar_restart_20261030/PERIODIC_FIVE_MAP_20261031/ROUND_SCHEDULE.json')
d=json.loads(schedule.read_text(encoding='utf-8'))
d.update(status='SUPERSEDED_BY_ACTIVE_PJ01_RULE_GOAL',next_due=None,
 current_non_cadence_test=dict(phase='PJ01_rules_P03_pose_20261101',status='FINITE_MAP02_COMPARE_ACTIVE',max_native_rounds=4,automatic_five=False),
 latest_goal='ACTIVE_PJ01_MAP_FIRST_ONE_PROVEN_RULE_AT_A_TIME',old_cadence_restored=False)
schedule.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status='RECORDED_P03_AND_GOAL_ACTIVE',utc=now)))
