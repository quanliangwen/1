from pathlib import Path
F=Path(__file__).resolve().parent;P=F.parent/'P02_proven_endpoint_rule'
s=(P/'run_offline.py').read_text(encoding='utf-8').replace('P02','P03').replace('Map01','Map02')
s=s.replace("'[EXACT_ENDPOINT] '","'[COLORED_POSE] '")
s=s.replace('observed_endpoint_corrections_minimum','pose_event_count')
s=s.replace('old_automation_resumed=False','automation90_active=True,builtin_goal_edit_resume_pending=True')
(F/'run_offline.py').write_text(s,encoding='utf-8')
s=(P/'collect_offline.py').read_text(encoding='utf-8').replace('PJ01_rules_P02_endpoint_20261101','PJ01_rules_P03_pose_20261101').replace('P02','P03').replace('Map01','Map02')
s=s.replace('actual_endpoint_corrections_minimum','actual_pose_event_count').replace('observed_endpoint_corrections_minimum','pose_event_count')
(F/'collect_offline.py').write_text(s,encoding='utf-8')
for name in ['start_local_collector.py','launch_campaign.py']:
    s=(P/name).read_text(encoding='utf-8').replace('old_automation_resumed=False','automation90_active=True,builtin_goal_edit_resume_pending=True')
    (F/name).write_text(s,encoding='utf-8')
print('Prepared one-rule Map02 finite driver and first-byte collector; no runs started.')
