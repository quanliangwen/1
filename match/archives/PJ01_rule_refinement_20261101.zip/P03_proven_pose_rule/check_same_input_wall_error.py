from pathlib import Path
from types import SimpleNamespace
import ast,importlib.util,json,math,time,hashlib
import numpy as np
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/"candidate_project/src/swarm_rescue/solutions"))
from colored_pose import ColoredPoseFilter,wrap
F=Path(__file__).resolve().parent
S=Path('E:\\codex\\PJ01_rule_refinement_20261101\\P01_baseline_rules\\baseline_project\\src\\swarm_rescue\\solutions')
def load(name):
    spec=importlib.util.spec_from_file_location(name,S/(name+'.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
anchor_type=load('boundary_anchor').ObservedBoundaryAnchor
extract_lines=load('scan_geometry').extract_scan_lines
tree=ast.parse((S/'greedy_mapping.py').read_text());c=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='GreedyMappingDrone')
f=next(n for n in c.body if isinstance(n,ast.FunctionDef) and n.name=='_update_pose')
ns={'np':np,'math':math,'wrap_angle':wrap};exec(compile(ast.unparse(f),'actual_baseline','exec'),ns);baseline=ns['_update_pose']
angles=np.linspace(-math.pi,math.pi,180,endpoint=False)
def scan(position,heading):
    directions=np.column_stack((np.cos(angles+heading),np.sin(angles+heading)))
    # Generated rectangular room only; not any competition map.
    # Inner faces of a 6px boundary, matching the actual anchor's convention.
    bounds=np.array([397.,297.]);target=np.where(directions>=0,bounds,-bounds)
    ds=np.divide(target-position,directions,out=np.full_like(directions,np.inf),where=np.abs(directions)>1e-10)
    axes=np.argmin(ds,axis=1);distance=ds[np.arange(len(ds)),axes]
    return np.minimum(distance,300.),axes
def run(kind,seed,anchored):
    n=800;tt=np.arange(n)
    if kind=='ellipse':p=np.column_stack((230*np.cos(tt*.012),150*np.sin(tt*.012)));theta=np.array([wrap(t*.016) for t in tt])
    else:p=np.column_stack((240*np.sin(tt*.010),np.zeros(n)));theta=np.zeros(n)
    rng=np.random.default_rng(2000+seed);gb=np.zeros(2);cb=0.
    a=SimpleNamespace(pose=None,heading=0.,heading_initialized=False,rally=None)
    a.measured_gps_position=lambda:a.gps;a.measured_compass_angle=lambda:a.compass;a.odometer_values=lambda:a.odom
    k=ColoredPoseFilter();anchors=[anchor_type(800,600),anchor_type(800,600)]
    err=[[],[]];pos=[[],[]];corrections=[0,0]
    for t in range(n):
        delta=p[t]-p[t-1] if t else np.zeros(2);prevtheta=theta[t-1] if t else theta[t]
        gb=.98*gb+rng.normal(0,5*math.sqrt(1-.98**2),2);cb=.98*cb+rng.normal(0,math.radians(4)*math.sqrt(1-.98**2))
        gps=p[t]+gb;compass=wrap(theta[t]+cb)
        odom=np.array([np.linalg.norm(delta)+rng.normal(0,.2),wrap(math.atan2(delta[1],delta[0])-prevtheta+rng.normal(0,math.radians(8))),wrap(theta[t]-prevtheta+rng.normal(0,math.radians(1)))])
        a.gps=gps;a.compass=compass;a.odom=odom;baseline(a);kp,kh=k.update(gps,compass,odom)
        distances,axes=scan(p[t],theta[t]);lines=extract_lines(distances,angles)
        states=[(a.pose,a.heading),(kp,kh)]
        if anchored and t%4==0:
            new=[]
            for index,(point,head) in enumerate(states):
                point,head,changed=anchors[index].correct(lines,point,head,t)
                corrections[index]+=int(changed);new.append((point,head))
            a.pose,a.heading=new[0];k.reanchor(*new[1]);states=new
        if t>=100:
            valid=(distances<220)&(distances>12)
            for index,(point,head) in enumerate(states):
                endpoints=point+distances[valid,None]*np.column_stack((np.cos(angles[valid]+head),np.sin(angles[valid]+head)))
                truth_ends=p[t]+distances[valid,None]*np.column_stack((np.cos(angles[valid]+theta[t]),np.sin(angles[valid]+theta[t])))
                normal_error=np.abs((endpoints-truth_ends)[np.arange(len(endpoints)),axes[valid]])
                err[index].extend(normal_error.tolist());pos[index].append(float(np.linalg.norm(point-p[t])))
    return dict(kind=kind,seed=seed,anchored=anchored,samples=len(err[0]),actual_anchor_corrections=corrections,
        baseline_wall_normal_rmse=float(np.sqrt(np.mean(np.square(err[0])))),filter_wall_normal_rmse=float(np.sqrt(np.mean(np.square(err[1])))),
        baseline_position_rmse=float(np.sqrt(np.mean(np.square(pos[0])))),filter_position_rmse=float(np.sqrt(np.mean(np.square(pos[1])))))
started=time.perf_counter();runs=[run(kind,seed,anchored) for kind in ['ellipse','reciprocating'] for anchored in [False,True] for seed in range(2)]
summary=[]
for kind in ['ellipse','reciprocating']:
 for anchored in [False,True]:
    rs=[r for r in runs if r['kind']==kind and r['anchored']==anchored]
    summary.append(dict(kind=kind,anchored=anchored,runs=len(rs),wall_rmse_wins=sum(r['filter_wall_normal_rmse']<r['baseline_wall_normal_rmse'] for r in rs),
        baseline_wall_normal_rmse=float(np.mean([r['baseline_wall_normal_rmse'] for r in rs])),
        filter_wall_normal_rmse=float(np.mean([r['filter_wall_normal_rmse'] for r in rs])),
        actual_anchor_corrections=np.sum([r['actual_anchor_corrections'] for r in rs],axis=0).tolist()))
out=dict(status='PASS',summary=summary,runs=runs,elapsed_seconds=time.perf_counter()-started,native_games=0,production_changed=False,
    reference_sha256=hashlib.sha256((F/'candidate_project/src/swarm_rescue/solutions/colored_pose.py').read_bytes()).hexdigest(),
    scope='Generated rectangular walls, ideal ranges to isolate pose error, actual line extractor and boundary anchor, declared noise and all8 predeclared cases. No physical dynamics, real map, semantic noise, private state, mapping raster or game-score inference.')
(F/'POSE_MAPPING_CHECK.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='runs'}))
