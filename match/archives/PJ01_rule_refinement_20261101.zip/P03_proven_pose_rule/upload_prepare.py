from pathlib import Path
import subprocess,json
F=Path(__file__).resolve().parent
R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P03_pose_20261101'
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
subprocess.run(ssh+[R+'/.venv/bin/python',H+'/R154_scoped_serial_guard_20261101/check_scoped_serial.py'],check=True)
code='from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n'
subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=code.encode(),check=True)
for n in ['candidate_project','CANDIDATE_MANIFEST.json','prepare_server.py','check_actual_methods.py','POSE_MAPPING_CHECK.json']:
    subprocess.run(['scp','-q','-r',str(F/n),'junhao@10.112.162.60:'+D+'/'],check=True)
subprocess.run(['scp','-q',str(F.parent/'P02_proven_endpoint_rule/qualify_arm.py'),'junhao@10.112.162.60:'+D+'/qualify_arm.py'],check=True)
subprocess.run(ssh+[R+'/.venv/bin/python',D+'/prepare_server.py'],check=True)
subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/WORKSPACE_READY.json',str(F/'WORKSPACE_READY.json')],check=True)
print(json.dumps(dict(status='SERVER_PREPARED_NO_NATIVE_STARTED',phase=D)))
