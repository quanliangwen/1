from pathlib import Path
import json
F=Path(__file__).resolve().parent
R=Path('E:/codex/swarm-eod-literature-analysis/F32_official_sdk_20261028/FIVE_MAP_REBASELINE/PJ01_A/RESULT.json')
matrix=json.loads(R.read_text(encoding='utf-8'))
rows=[]
for name,j in sorted(matrix['jobs'].items()):
    r=j['rounds'][0];p=r['phase'];b=p['map_breakdown']
    rows.append(dict(map=name,total=r['full_score'],map_score=p['score_map'],trajectory=p['score_exploration_trajectory'],
      wall_credit=100*b['credit'],missed_wall_loss=100*(1-b['credit']),false_drawing_penalty=100*b['penalty'],
      placed=r['placed'],red_steps=r['red_steps'],red_wall_seconds=r['red_walltime']))
out=dict(status='READ_OLD_ALREADY_REVIEWED_METADATA_ONLY',scope='Historical original PJ01 five maps, no new archive reads or causal comparison to current runs.',rows=rows)
(F/'BASELINE_MAP_ERROR_AUDIT.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,ensure_ascii=False))
