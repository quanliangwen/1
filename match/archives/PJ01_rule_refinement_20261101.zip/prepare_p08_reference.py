from pathlib import Path
import json,hashlib
F=Path(__file__).resolve().parent/'P08_empty_drone_wall_probe';assert not F.exists();F.mkdir()
P=F.parent/'P07_wall_evidence_closeup'
s=(P/'V3/candidate_project/src/swarm_rescue/solutions/wall_probe_reference.py').read_text()
s=s.replace('from swarm_rescue.solutions.finite_wall_support import from_actual_scan','from finite_wall_support import from_actual_scan')
s=s.replace('class LastCertificateGate:', 'class EmptyDroneProbeGate:')
old="        if not other_certificates_complete:\n            self.state='SKIPPED';self.reason='OTHER_TEAM_WORK_NOT_CERTIFIED';return True\n"
assert s.count(old)==1;s=s.replace(old,'')
s=s.replace('"""True permits original certificate logic; False withholds it finitely."""','"""Own empty drone may try once without waiting for peers certificates.\n\n    Caller must separately reserve a known rally return if team work remains.\n    Existing inventory messages remain true; no peer certificate prerequisite.\n    """')
(F/'empty_probe_reference.py').write_text(s,encoding='utf-8')
(F/'finite_wall_support.py').write_bytes((P/'finite_wall_support.py').read_bytes())
note='''P08 reference only, no controller integration or native schedule.
P07 actualMap02 all5 gate refusals happened before wall/route check because each empty drone lacked other4 completion certificates. Original source frozen and nofive.
One revised wall closeup rule on independent originalPJ01: own inventory0 admits one bounded own-evidence task without waiting for others certificates, but still delays only own certificate and keeps inventory messages true. No mutual wait. Require known rally return budget while others still working, preserve empty-coordinator peer allocation service and original motion. New scans must really be mapped; max96 and half usable budget and time-best boundary guards unchanged.
First pure counterchecks: independent5nodes simultaneous/non-simultaneous inventory changes, no waiting for others, expiry even lostpeer/walls, existing certificate no retraction, witness age/knownfree inherited. Then actual SDK own unknown/blocked rally path, budget and other-drone still-carrying endgame tests. No sourcecandidate/workspace/native yet; pure clocks are contracts, not physical or scoreproof.
'''
(F/'分析依据与预先检查.txt').write_text(note,encoding='utf-8')
print(json.dumps(dict(status='P08_REFERENCE_PREPARED_ONLY',native_queue=False)))
