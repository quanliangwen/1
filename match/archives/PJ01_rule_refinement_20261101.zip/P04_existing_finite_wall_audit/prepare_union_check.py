from pathlib import Path
import json,subprocess
F=Path(__file__).resolve().parent
old='''    shadow=copy.copy(probe.memory);shadow.hits=support.overlay(probe.memory.hits)
    nonwall=getattr(shadow,'nonwall_mask',None)
    if nonwall is not None:shadow.hits[np.asarray(nonwall,bool)]=0
    alternate=BearingMemory.render(shadow).copy()'''
new='''    shadow=copy.copy(probe.memory);shadow.hits=probe.memory.hits.copy()
    alternate,union_audit=thin_output_union(original,support.counts,fine=probe.memory.FINE,cell=probe.memory.CELL,
        nonwall=getattr(probe.memory,'nonwall_mask',None))
    assert np.all(alternate>=original),"Original wall pixels removed"
'''
assert not(F/'UNION_PREDECLARATION.json').exists()
(F/'UNION_PREDECLARATION.json').write_text(json.dumps(dict(
 reason='Direct re-fit loses high-baseline geometry. Preserve parent pixels and fit geometry exactly; add thin measured patches outside existing wall neighborhood and original frame-authority band.',
 thresholds=dict(repeated_support_min=2,separation_px='2*baseline_CELL',boundary_band_px='2*baseline_CELL',output_thickness='original_FINE'),
 evidence_scope='Same12 authored input cases, fixed seeds and routes preserved. New output rule only; no production candidate/native.',
 advance_criterion='At least one incomplete-case map gain, complete-case worst loss<=0.5, original pixel set preserved in every case; inspect counterexamples before further SDK integration.'),indent=2)+'\n',encoding='utf-8')
outputs=[]
for src,name in [('check_actual_pj01_memory_shadow.py','check_union_original8.py'),('check_ceiling_countercases.py','check_union_ceiling4.py')]:
    s=(F/src).read_text(encoding='utf-8');assert old in s
    s=s.replace('from finite_wall_support import FiniteWallSupport,from_actual_scan','from finite_wall_support import FiniteWallSupport,from_actual_scan\nfrom thin_output_union import thin_output_union',1)
    s=s.replace(old,new,1)
    s=s.replace('baseline_state_arrays_unchanged=True,','union_audit=union_audit,baseline_state_arrays_unchanged=True,',1)
    (F/name).write_text(s,encoding='utf-8');outputs.append(name)
R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P04_finite_wall_audit_20261101'
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
subprocess.run(ssh+[R+'/.venv/bin/python',H+'/R154_scoped_serial_guard_20261101/check_scoped_serial.py'],check=True)
for name in ['thin_output_union.py','UNION_PREDECLARATION.json']+outputs:
    subprocess.run(['scp','-q',str(F/name),'junhao@10.112.162.60:'+D+'/'],check=True)
for script,label in [(outputs[0],'THIN_UNION_ORIGINAL8_FIRST'),(outputs[1],'THIN_UNION_CEILING4_FIRST')]:
    run=subprocess.run(ssh+[R+'/.venv/bin/python',H+'/run_sdk_captured.py',D+'/'+script,label],capture_output=True,text=True)
    (F/(label+'.capture.txt')).write_text(run.stdout+run.stderr,encoding='utf-8');print(run.stdout);print(run.stderr)
    if run.returncode:raise SystemExit(run.returncode)
    subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+label+'.json',str(F/(label+'.json'))],check=True)
print('Same12 input countercases checked, no physical games/production changes.')
