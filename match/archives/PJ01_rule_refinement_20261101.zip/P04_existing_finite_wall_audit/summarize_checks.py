from pathlib import Path
import json
F=Path(__file__).resolve().parent
names=['MEMORY_SHADOW_FIRST','CEILING_COUNTER_FIRST','THIN_UNION_ORIGINAL8_FIRST','THIN_UNION_CEILING4_FIRST']
read=lambda name:json.loads((F/(name+'.json')).read_text(encoding='utf-8'))
summary=[]
for n in names:
    d=read(n)
    summary.append(dict(test=n,minimum=d['minimum_map_delta'],mean=d['mean_map_delta'],positive=d['positive_cases'],negative=d['negative_cases'],
      rows=[dict(case=r['case'],baseline=r['baseline']['map_score'],shadow=r['shadow']['map_score'],delta=r['map_delta'],
                 credit_delta=100*(r['shadow']['credit']-r['baseline']['credit']),
                 false_drawing_delta=100*(r['shadow']['penalty']-r['baseline']['penalty']),
                 new_pixels=r.get('union_audit',{}).get('added_pixels')) for r in d['rows']]))
out=dict(status='ANALYZED_STATIC_SAME_INPUT_RULE_CHECKS',summary=summary,
 direct_refit_rejected=True,thin_union_passes_declared_static_gate=read(names[2])['positive_cases']>=1 and read(names[3])['minimum_map_delta']>=-.5,
 native_rounds=0,production_candidate=False)
(F/'CHECKS_COMPARISON.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,ensure_ascii=False))
