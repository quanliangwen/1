"""Measured finite support as a thin union, without refitting original walls.

Reference only. Threshold2 is baseline repeated-hit minimum; two coarse cells
are the separation/boundary band. No game truth, quality oracle or map id.
"""
import cv2
import numpy as np

def thin_output_union(parent,support,*,fine,cell,nonwall=None):
    image=np.asarray(parent);counts=np.asarray(support)
    if image.ndim!=2 or image.dtype!=np.uint8 or not np.isin(image,[0,1]).all():
        raise ValueError('Original binary uint8 output required')
    if type(fine)is not int or fine<=0 or type(cell)is not int or cell<=0:
        raise ValueError('Original positive integer pixel scales required')
    h,w=image.shape
    if counts.shape!=((h+fine-1)//fine,(w+fine-1)//fine) or counts.dtype.kind not in 'ui':
        raise ValueError('Own finite support must match original fine grid')
    patch=(counts>=2).astype(np.uint8)
    if nonwall is not None:
        banned=np.asarray(nonwall,bool)
        if banned.shape!=patch.shape:raise ValueError('Nonwall mask grid mismatch')
        patch[banned]=0
    patch=np.repeat(np.repeat(patch,fine,axis=0),fine,axis=1)[:h,:w]
    separation=2*cell
    nearby=cv2.dilate(image,np.ones((2*separation+1,2*separation+1),np.uint8))
    patch[nearby>0]=0
    # Match the inherited measured-bearing renderer's authority at arena edges.
    band=2*cell
    patch[:band,:]=0;patch[-band:,:]=0;patch[:,:band]=0;patch[:,-band:]=0
    out=np.maximum(image,patch)
    assert np.all(out>=image)
    return out,dict(added_pixels=int(np.count_nonzero((out>0)&(image==0))),
                   original_pixels_preserved=True,repeated_support_min=2,separation_px=separation,
                   boundary_band_px=band,claim='Repeated support, not independent probabilistic confidence')
