"""Existing finite-wall rule, same-input shadow of real PJ01 memory only.

Authored sensor-input cases, real baseline pose/frame/anchor/memory/render and
SDK post-score. No controller changes, no physical game or true-map runtime use.
"""
from pathlib import Path
import contextlib,copy,hashlib,io,json,math,sys,time
import numpy as np
F=Path(__file__).resolve().parent;label=sys.argv[1]
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
m=json.loads((H/'PJ01_rules_P03_pose_20261101/WORKSPACE_READY.json').read_text())['versions']['PJ01']
W=Path(m['workspace']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(W/n)==h for n,h in m['sources'].items())
assert all(sha(W/n)==h for n,h in m['sdk_files'].items())
sys.path.insert(0,str(W/'src'))
import cv2
from swarm_rescue.solutions.greedy_mapping import GreedyMappingDrone
from swarm_rescue.solutions.frame_mapping import FrameMappingMixin
from swarm_rescue.solutions.anchor_mapping import AnchoredMappingMixin
from swarm_rescue.solutions.bearing_memory import BearingMemory
from swarm_rescue.solutions.boundary_anchor import ObservedBoundaryAnchor
from swarm_rescue.simulation.reporting.place_score_manager import PlaceScoreManager,rasterize_world_polygons
from finite_wall_support import FiniteWallSupport,from_actual_scan

WIDTH,HEIGHT=640,480
ANGLES=np.linspace(-math.pi,math.pi,180,endpoint=False)
class Probe(FrameMappingMixin,AnchoredMappingMixin,GreedyMappingDrone):
    def __init__(self):
        self.clock=0;self.pose=None;self.heading=0.;self.heading_initialized=False;self.rally=None
        self.memory=BearingMemory(WIDTH,HEIGHT,identifier=0,team_size=5)
        self.boundary_anchor=ObservedBoundaryAnchor(WIDTH,HEIGHT)
        self.frame_records={};self.frame_negative={}
        self.memory.frame_records=self.frame_records;self.memory.frame_negative=self.frame_negative
    @property
    def identifier(self):return 0
    @property
    def elapsed_timestep(self):return self.clock
    def measured_gps_position(self):return self.gps
    def measured_compass_angle(self):return self.compass
    def odometer_values(self):return self.odom
    def lidar_values(self):return self.ranges
    def lidar_rays_angles(self):return ANGLES
    def semantic_values(self):return []

def rect(x0,y0,x1,y1):return [[x0,y0],[x1,y0],[x1,y1],[x0,y1]]
def scene(kind):
    polys=[rect(-323,-243,323,-237),rect(-323,237,323,243),rect(-323,-243,-317,243),rect(317,-243,323,243)]
    if kind=='doorway':polys += [rect(-260,97,-60,103),rect(60,97,260,103)]
    return polys

def scan(p,heading,polygons):
    directions=np.column_stack((np.cos(ANGLES+heading),np.sin(ANGLES+heading)))
    out=np.full(len(ANGLES),300.)
    for poly in polygons:
        box=np.asarray(poly);lo=box.min(axis=0);hi=box.max(axis=0)
        ta=np.divide(lo-p,directions,out=np.full_like(directions,-np.inf),where=np.abs(directions)>1e-12)
        tb=np.divide(hi-p,directions,out=np.full_like(directions,np.inf),where=np.abs(directions)>1e-12)
        enter=np.minimum(ta,tb).max(axis=1);leave=np.maximum(ta,tb).min(axis=1)
        good=(leave>=np.maximum(enter,0.))&(enter>0)
        out=np.minimum(out,np.where(good,enter,300.))
    return out

def path(kind):
    points=([[-180,-120],[0,-120],[0,160],[180,160],[0,160],[0,-120]] if kind=='full' else
            [[-180,-130],[0,-130],[180,-130],[0,-130],[-180,-130]])
    return np.concatenate([np.linspace(a,b,40,endpoint=False) for a,b in zip(points[:-1],points[1:])])

def arrays(memory):
    return {n:v.copy() for n,v in memory.__dict__.items() if isinstance(v,np.ndarray)}

def score_after_freeze(polys,pred):
    truth=rasterize_world_polygons(polys,WIDTH,HEIGHT)
    boundary=rasterize_world_polygons(polys[:4],WIDTH,HEIGHT)
    p=PlaceScoreManager().compute_phase1_score(truth,pred,elapsed_walltime=1.,max_walltime_limit=90,
        score_exploration_trajectory=0.,placed_count=0,expected_count=10,has_crashed=False,bomb_positions=[],
        elapsed_timestep=200,max_timestep_limit=1000,wall_grid=truth,boundary_grid=boundary)
    return dict(map_score=p.score_map,credit=p.map_breakdown['credit'],penalty=p.map_breakdown['penalty'])

def run(kind,route,noisy,seed):
    polys=scene(kind);positions=path(route);rng=np.random.default_rng(seed)
    probe=Probe();support=FiniteWallSupport(WIDTH,HEIGHT,fine=probe.memory.FINE)
    gpsbias=np.zeros(2);cbias=0.;head=0.;far_supported=0
    started=time.perf_counter()
    for t,p in enumerate(positions):
        delta=p-positions[t-1] if t else np.zeros(2)
        if noisy:
            gpsbias=.98*gpsbias+rng.normal(0,5*math.sqrt(1-.98**2),2)
            cbias=.98*cbias+rng.normal(0,math.radians(4)*math.sqrt(1-.98**2))
        probe.clock=t;probe.gps=p+gpsbias;probe.compass=cbias
        probe.odom=np.array([np.linalg.norm(delta)+(rng.normal(0,.2) if noisy else 0),
             math.atan2(delta[1],delta[0])+(rng.normal(0,math.radians(8)) if noisy else 0),
             rng.normal(0,math.radians(1)) if noisy else 0])
        probe.ranges=scan(p,head,polys)
        if noisy:probe.ranges=np.clip(probe.ranges+rng.normal(0,1.,len(ANGLES)),0,300)
        # Real baseline methods receive only authored public observation inputs.
        probe._update_pose()
        if t%4==0:
            probe.memory.step=t
            probe.memory.observe(probe.pose,probe.heading,probe.ranges,ANGLES,[])
            excluded=probe.memory.semantic_mask(probe.ranges,ANGLES,[])
            segments=from_actual_scan(probe.pose,probe.heading,probe.ranges,ANGLES,excluded)
            far_supported+=int(np.count_nonzero((probe.ranges>=220)&(probe.ranges<280)))
            support.update(step=t,pose=probe.pose,heading=probe.heading,segments=segments)
    before=arrays(probe.memory);original=probe.memory.render().copy()
    shadow=copy.copy(probe.memory);shadow.hits=support.overlay(probe.memory.hits)
    nonwall=getattr(shadow,'nonwall_mask',None)
    if nonwall is not None:shadow.hits[np.asarray(nonwall,bool)]=0
    alternate=BearingMemory.render(shadow).copy()
    assert all(np.array_equal(v,getattr(probe.memory,k)) for k,v in before.items()),'Baseline memory arrays changed'
    assert shadow.hits is not probe.memory.hits
    # Freeze outputs before post-score accesses authored truth.
    for image in [original,alternate]:assert image.shape==(HEIGHT,WIDTH) and set(np.unique(image)).issubset({0,1})
    orig_score=score_after_freeze(polys,original);alt_score=score_after_freeze(polys,alternate)
    name=f'{kind}_{route}_{"noise" if noisy else "clean"}'
    cv2.imwrite(str(F/(label+'_'+name+'_original.png')),original*255)
    cv2.imwrite(str(F/(label+'_'+name+'_shadow.png')),alternate*255)
    return dict(case=name,seed=seed,baseline=orig_score,shadow=alt_score,map_delta=alt_score['map_score']-orig_score['map_score'],
       observed_frames=len(support.active),support_views=support.views,far_return_count=far_supported,
       extra_hit_cells=int(np.count_nonzero(shadow.hits>probe.memory.hits)),frame_records=len(probe.frame_records),
       baseline_state_arrays_unchanged=True,seconds=time.perf_counter()-started)

started=time.perf_counter();rows=[]
with contextlib.redirect_stdout(io.StringIO()):
    for kind in ['closed','doorway']:
        for route in ['full','partial']:
            for noisy in [False,True]:rows.append(run(kind,route,noisy,615+len(rows)))
out=dict(status='COMPLETED_STATIC_ACTUAL_PJ01_MEMORY_SHADOW_NOT_GAME',rows=rows,
 source_sha256=m['sources'],finite_support_sha256=sha(F/'finite_wall_support.py'),
 minimum_map_delta=min(r['map_delta'] for r in rows),mean_map_delta=float(np.mean([r['map_delta'] for r in rows])),
 positive_cases=sum(r['map_delta']>1e-8 for r in rows),negative_cases=sum(r['map_delta']<-1e-8 for r in rows),
 mechanical_isolation_pass=all(r['baseline_state_arrays_unchanged'] for r in rows),seconds=time.perf_counter()-started,
 physics_steps=0,native_rounds=0,production_modified=False,
 scope='8 predeclared authored same-input scenes. Real PJ01 pose/frame/anchor/memory/render and frozen SDK post-score. Not an actual drone dynamics loop, game score, five-map average or production candidate. Far-return line support uses same actually supplied rays, no true map input.')
(F/(label+'.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['source_sha256','rows']}))
print(json.dumps(rows))
