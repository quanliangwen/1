from pathlib import Path
import hashlib,json,shutil,subprocess
F=Path(__file__).resolve().parent
old=Path('E:/codex/UAV_rules_astar_restart_20261030/R147_finite_observed_wall_support_20261101/finite_wall_support.py')
assert not(F/'finite_wall_support.py').exists();shutil.copy2(old,F/'finite_wall_support.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(F/'finite_wall_support.py')==sha(old)
d=dict(stage='P04_REFERENCE_ONLY',old_rule_sha256=sha(old),production_candidate=False,
 hypothesis='PJ01 raw wall hits require range<220, old finite observed support accepts actual range<280. Test whether any gap remains after original frame/anchor/TLS/bearing rendering, with exactly same input and original control state.',
 cases=[dict(room=k,route=r,noise=n,seed=615+i) for i,(k,r,n) in enumerate((k,r,n) for k in ['closed','doorway'] for r in ['full','partial'] for n in [False,True])],
 input_noise=dict(GPS_AR=.98,GPS_stationary_sd=5,compass_AR=.98,compass_sd_degrees=4,odometer_distance_sd=.2,odometer_direction_sd_degrees=8,odometer_turn_sd_degrees=1,range_sd=1),
 scope='Authored input diagnostic, no physical SDK trajectory, no full game/no BLUE. SDK scoring after outputs frozen, baseline arrays must be unchanged. Retain all8, no post-result scene or threshold selection.',
 go_decision='Require evidence of non-redundant map gain with no substantial counterexample before any candidate integration; no native scheduling in this script.')
(F/'PREDECLARATION.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P04_finite_wall_audit_20261101'
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
subprocess.run(ssh+[R+'/.venv/bin/python',H+'/R154_scoped_serial_guard_20261101/check_scoped_serial.py'],check=True)
subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=('from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n').encode(),check=True)
for name in ['finite_wall_support.py','check_actual_pj01_memory_shadow.py','PREDECLARATION.json']:
    subprocess.run(['scp','-q',str(F/name),'junhao@10.112.162.60:'+D+'/'],check=True)
run=subprocess.run(ssh+[R+'/.venv/bin/python',H+'/run_sdk_captured.py',D+'/check_actual_pj01_memory_shadow.py','MEMORY_SHADOW_FIRST'],capture_output=True,text=True)
(F/'FIRST_RUN_CAPTURE.txt').write_text(run.stdout+run.stderr,encoding='utf-8');print(run.stdout);print(run.stderr)
if run.returncode:raise SystemExit(run.returncode)
subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/MEMORY_SHADOW_FIRST.json',str(F/'MEMORY_SHADOW_FIRST.json')],check=True)
print('Finished actual-memory static diagnostic, 0 native rounds.')
