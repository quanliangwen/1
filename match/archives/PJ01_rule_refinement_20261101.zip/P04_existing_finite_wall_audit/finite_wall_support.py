"""Finite observed line support, for read-only mapping diagnosis first.

TLS solves the given isotropic point-set least-squares model. Segment grouping
and thresholds are engineering rules, not statistically complete weighted ML.
No wall-axis prior, hidden geometry, route, inventory or message API.
"""
from collections import deque
import math
import numpy as np

def fit_finite_segment(indices,points,*,min_points=6,min_length=40.,median_residual=3.5,max_residual=8.):
    ids=np.asarray(indices);p=np.asarray(points,float)
    if ids.ndim!=1 or p.shape!=(len(ids),2) or len(p)<min_points or not np.isfinite(p).all():return None
    if ids.dtype.kind not in 'iu' or (len(ids)>1 and not np.all(np.diff(ids)==1)):return None
    gaps=np.linalg.norm(np.diff(p,axis=0),axis=1)
    if gaps.max(initial=0)>24.:return None
    center=p.mean(axis=0);_,s,v=np.linalg.svd(p-center,full_matrices=False)
    if len(s)<2 or s[0]<1e-9:return None
    axis=v[0];along=(p-center)@axis;normal=np.array([-axis[1],axis[0]]);res=np.abs((p-center)@normal)
    if np.median(res)>median_residual or res.max()>max_residual:return None
    lo,hi=np.percentile(along,[5,95])
    if hi-lo<min_length:return None
    return dict(start=center+lo*axis,end=center+hi*axis,indices=ids.copy(),points=p.copy(),
        median_residual=float(np.median(res)),max_residual=float(res.max()),length=float(hi-lo),
        model='Finite isotropic TLS on one contiguous measured return group; clipped5..95percentiles, no extrapolation')

def extract_finite_segments(indices,points,*,max_segments=64,max_splits=128):
    ids=np.asarray(indices);p=np.asarray(points,float)
    if ids.ndim!=1 or p.shape!=(len(ids),2) or ids.dtype.kind not in 'iu' or not np.isfinite(p).all():raise ValueError('Actual finite parallel scan indices/points required')
    if len(ids)>1 and not np.all(np.diff(ids)>0):raise ValueError('Actual ordered unique indices required')
    if not len(ids):return []
    cuts=np.flatnonzero((np.diff(ids)!=1)|(np.linalg.norm(np.diff(p,axis=0),axis=1)>24.))+1
    groups=list(zip(np.split(ids,cuts),np.split(p,cuts)));out=[];used=0
    while groups and len(out)<max_segments and used<max_splits:
        ix,xy=groups.pop(0);used+=1
        if len(ix)<6:continue
        fit=fit_finite_segment(ix,xy)
        if fit is not None:out.append(fit);continue
        if len(ix)<12:continue
        chord=xy[-1]-xy[0];length=float(np.linalg.norm(chord))
        if length<1e-9:continue
        normal=np.array([-chord[1],chord[0]])/length
        # Splits retain both measured subsets. Never connect an excluded ray.
        residual=np.abs((xy-xy[0])@normal);eligible=np.arange(5,len(ix)-5)
        split=int(eligible[np.argmax(residual[eligible])])
        if residual[split]<=8.:continue
        groups[:0]=[(ix[:split+1],xy[:split+1]),(ix[split:],xy[split:])]
    return out

def from_actual_scan(pose,heading,distances,angles,excluded):
    p=np.asarray(pose,float);d=np.asarray(distances,float);a=np.asarray(angles,float);bad=np.asarray(excluded,bool)
    if p.shape!=(2,) or d.ndim!=1 or a.shape!=d.shape or bad.shape!=d.shape or not np.isfinite(p).all() or not math.isfinite(heading):raise ValueError('Actual own scan arrays required')
    keep=np.isfinite(d)&np.isfinite(a)&(d>8)&(d<280)&~bad
    ids=np.flatnonzero(keep);theta=heading+a[ids]
    points=p+d[ids,None]*np.column_stack((np.cos(theta),np.sin(theta)))
    return extract_finite_segments(ids,points)

class FiniteWallSupport:
    def __init__(self,width,height,*,fine=2,window=25,motion=16.,turn_degrees=8.):
        self.width=width;self.height=height;self.fine=fine;self.shape=(math.ceil(height/fine),math.ceil(width/fine))
        self.window=window;self.motion=motion;self.turn=math.radians(turn_degrees)
        self.counts=np.zeros(self.shape,np.uint32);self.active=deque();self.origin=None;self.heading=None;self.last=-1;self.views=0
    def update(self,*,step,pose,heading,segments):
        if type(step)is not int or step<=self.last:raise ValueError('Unique actual fresh scan epoch required')
        p=np.asarray(pose,float)
        if p.shape!=(2,) or not np.isfinite(p).all() or not math.isfinite(heading):raise ValueError('Actual finite pose required')
        changed=self.origin is None or np.linalg.norm(p-self.origin)>=self.motion or abs((heading-self.heading+math.pi)%(2*math.pi)-math.pi)>=self.turn
        if changed:self.origin=p.copy();self.heading=heading;self.active.clear();self.views+=1
        cells=[]
        for seg in segments:
            # Endpoints come only from the accepted finite observed group.
            a,b=seg['start'],seg['end'];n=max(2,int(np.ceil(np.linalg.norm(b-a)))+1)
            z=a+(b-a)*np.linspace(0,1,n)[:,None]
            r=np.floor((self.height/2-z[:,1])/self.fine).astype(int);c=np.floor((z[:,0]+self.width/2)/self.fine).astype(int)
            valid=(r>=0)&(c>=0)&(r<self.shape[0])&(c<self.shape[1]);cells.extend((r[valid]*self.shape[1]+c[valid]).tolist())
        ids=np.unique(np.asarray(cells,int));flat=self.counts.ravel()
        if len(self.active)>=self.window:flat[self.active.popleft()]-=1
        flat[ids]+=1;self.active.append(ids);self.last=step
        return dict(step=step,new_view=changed,views=self.views,finite_segments=len(segments),unique_supported_cells=len(ids),held_frames=len(self.active))
    def overlay(self,raw_own_counts):
        raw=np.asarray(raw_own_counts)
        if raw.shape!=self.shape or raw.dtype!=np.uint8:raise ValueError('Existing actual own uint8 source snapshot required')
        # Interpolation is alternative support, never added as independent votes.
        return np.maximum(raw,np.minimum(32,self.counts).astype(np.uint8))
