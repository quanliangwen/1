"""Add a separately declared countercheck after the original8, preserve FIRST."""
from pathlib import Path
import json,subprocess
F=Path(__file__).resolve().parent
declaration=dict(reason='Original8 improve incomplete maps, but doorway_full_noise increases false-drawing penalty by4.16pp. Need high-baseline near-complete observation counterexamples before integration.',
 cases=[dict(room=k,route='complete',noise=n,seed=9001+i) for i,(k,n) in enumerate((k,n)for k in ['closed','doorway']for n in [False,True])],
 criterion='If a near-complete baseline loses >0.5 map points, do not directly integrate old finite overlay; report every case, no threshold tuning or native retry.',
 production_source_changed=False,original8_results_preserved=True)
(F/'CEILING_PREDECLARATION.json').write_text(json.dumps(declaration,indent=2)+'\n',encoding='utf-8')
s=(F/'check_actual_pj01_memory_shadow.py').read_text(encoding='utf-8')
old='def path(kind):\n    points='
new='''def path(kind):
    if kind=='complete':
        anchors=[[-220,-160],[220,-160],[0,-160],[0,160],[220,160],[-220,160],[0,160],[0,-160],[-220,-160]]
        return np.tile(np.concatenate([np.linspace(a,b,50,endpoint=False) for a,b in zip(anchors[:-1],anchors[1:])]),(2,1))
    points='''
assert old in s;s=s.replace(old,new,1)
s=s.replace('started=time.perf_counter()\n    for t,p','started=time.perf_counter();finite_seconds=0.\n    for t,p',1)
s=s.replace('            segments=from_actual_scan','            extra_started=time.perf_counter()\n            segments=from_actual_scan',1)
s=s.replace('support.update(step=t,pose=probe.pose,heading=probe.heading,segments=segments)','support.update(step=t,pose=probe.pose,heading=probe.heading,segments=segments)\n            finite_seconds+=time.perf_counter()-extra_started',1)
s=s.replace('baseline_state_arrays_unchanged=True,seconds=','baseline_state_arrays_unchanged=True,finite_support_seconds=finite_seconds,seconds=',1)
s=s.replace("for route in ['full','partial']:","for route in ['complete']:")
s=s.replace('615+len(rows)','9001+len(rows)')
s=s.replace('8 predeclared authored same-input scenes','4 separately predeclared near-complete authored same-input countercases')
s=s.replace('COMPLETED_STATIC_ACTUAL_PJ01_MEMORY_SHADOW_NOT_GAME','COMPLETED_CEILING_COUNTERCHECK_NOT_GAME')
dest=F/'check_ceiling_countercases.py';assert not dest.exists();dest.write_text(s,encoding='utf-8')
R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P04_finite_wall_audit_20261101'
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
subprocess.run(ssh+[R+'/.venv/bin/python',H+'/R154_scoped_serial_guard_20261101/check_scoped_serial.py'],check=True)
for name in ['check_ceiling_countercases.py','CEILING_PREDECLARATION.json']:subprocess.run(['scp','-q',str(F/name),'junhao@10.112.162.60:'+D+'/'],check=True)
run=subprocess.run(ssh+[R+'/.venv/bin/python',H+'/run_sdk_captured.py',D+'/check_ceiling_countercases.py','CEILING_COUNTER_FIRST'],capture_output=True,text=True)
(F/'CEILING_FIRST_RUN_CAPTURE.txt').write_text(run.stdout+run.stderr,encoding='utf-8');print(run.stdout);print(run.stderr)
if run.returncode:raise SystemExit(run.returncode)
subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/CEILING_COUNTER_FIRST.json',str(F/'CEILING_COUNTER_FIRST.json')],check=True)
print('Finished4 separately-declared ceiling cases; no production changes/native.')
