from pathlib import Path
import shutil,json,hashlib,datetime
F=Path(__file__).resolve().parent;H=F.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,manifest in [('baseline_project','BASELINE_IDENTITY.json'),('candidate_project','CANDIDATE_MANIFEST.json')]:
    d=read(F/manifest);files=d['files'];assert all(sha(F/n/p)==v for p,v in files.items())
old=read(H/'R193_stopped_passing_pair_handoff_20261101/WORKSPACE_READY.json');P=Path(old['workspace'])
assert all(sha(P/n)==v for n,v in old['sdk_files'].items())
pause=read(H/'CADENCE07_J17_control_20261101/USER_PAUSE_RUNTIME_AUDIT_20261101.json');assert not pause['remaining_own_processes']
assert (H/'CADENCE07_J17_control_20261101/STOP_REQUESTED').exists()
workspaces={}
for version,name in [('BASELINE','pj01_rules_baseline_20261101'),('P01','pj01_rules_visible_reservation_20261101')]:
    W=P.parent/name;assert not W.exists()
    def ignore(folder,names):
        excluded=[n for n in names if n in ['__pycache__','.git','.pytest_cache'] or n.endswith('.pyc')]
        if Path(folder)==P/'src/swarm_rescue':excluded+=['solutions']
        return excluded
    shutil.copytree(P,W,ignore=ignore)
    inp=F/('baseline_project' if version=='BASELINE' else 'candidate_project')
    shutil.copytree(inp/'src/swarm_rescue/solutions',W/'src/swarm_rescue/solutions');shutil.copy2(inp/'req.txt',W/'req.txt')
    files={p.relative_to(W).as_posix():sha(p) for p in (W/'src/swarm_rescue/solutions').rglob('*') if p.is_file()};files['req.txt']=sha(W/'req.txt')
    assert all(sha(W/n)==v for n,v in old['sdk_files'].items())
    workspaces[version]=dict(workspace=str(W),sources=files,sdk_files=old['sdk_files'])
out=dict(status='PREPARED_PJ01_BASE_AND_ONE_RULE_SAME_FROZEN_SDK',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),versions=workspaces,
    authorization='User latest: 不对啊为什么地图分数这么低 或者我们只用PJ01的算法基础进行规则的制订 按照上述我提到的规则进行尝试',
    old_background_goal_and_automation_remain_paused=True,automatic_five=False,official_submission_created=False)
(F/'WORKSPACE_READY.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=out['status'],workspaces={v:d['workspace'] for v,d in workspaces.items()},automatic_five=False)))
