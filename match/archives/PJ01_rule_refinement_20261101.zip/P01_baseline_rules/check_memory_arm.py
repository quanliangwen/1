from pathlib import Path
import sys,json,hashlib
import numpy as np
F=Path(__file__).resolve().parent;label,arm=sys.argv[1:];m=json.loads((F/'WORKSPACE_READY.json').read_text())['versions'][arm];W=Path(m['workspace']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(W/n)==v for n,v in m['sources'].items())
sys.path.insert(0,str(W/'src'))
from swarm_rescue.solutions.bearing_memory import BearingMemory
from swarm_rescue.solutions.fast_exploration import CoordinatedMapMemory
from swarm_rescue.solutions.my_drone_eval import MyDroneEval
mem=BearingMemory(960,640,identifier=1,team_size=2)
angles=np.linspace(-np.pi,np.pi,360,endpoint=False);base=120+20*np.cos(2*angles)
for step in range(1,9):
    mem.step=step;mem.observe(np.array([step*.5,step*.3]),.01*step,base+.3*np.sin(angles*5+step),angles,[])
fields={n:sha_array for n,sha_array in []}
for n,a in [('hits',mem.hits),('free',mem.free),('bearing_bits',mem.bearing_bits),('render',mem.render())]:fields[n]=hashlib.sha256(a.tobytes()).hexdigest()
nav=BearingMemory(960,640,identifier=1,team_size=2);nav.step=100;nav.free[:]=True;nav.free[4:12,44:57]=False;nav.free[28:36,44:57]=False
pos=nav.cell_to_world((20,38));nav.origin=pos.copy()
route,goal=nav.route(pos);disabled=dict(goal=None if goal is None else goal.tolist(),route=[p.tolist() for p in route])
default_unknown=np.ones(nav.shape,np.float32)
checks={'source_frozen':True,'map_has_real_current_input':bool(mem.hits.any()),'factory_correct':MyDroneEval.__name__=='MyDroneEval'}
if arm=='P01':
    from types import SimpleNamespace,MethodType
    from swarm_rescue.solutions.pj01_scan_rules import VisibleReservationRuleMixin
    from swarm_rescue.solutions.visible_reservation_field import VisibleReservationField
    state=SimpleNamespace(memory=nav,rule_exploration_claims={0:(100,nav.cell_to_world((13,44)))},identifier=1,rule_visibility=VisibleReservationField(),rule_visibility_events=[],_rule_ordinary_exploration=lambda:True)
    nav.information_weight_provider=MethodType(VisibleReservationRuleMixin._rule_unknown_weights,state)
    weighted=nav._information_weights(default_unknown);checks['actual_provider_suppresses_expected_shared_unknown']=weighted.min()<1 and state.rule_visibility_events[-1]['discounted_unknown_cells']>0
    before=nav.hits.copy(),nav.free.copy();nav.exploration_goal=None
    active_route,active_goal=nav.route(pos)
    checks['ranking_never_alters_own_map']=np.array_equal(nav.hits,before[0]) and np.array_equal(nav.free,before[1])
    state.rule_exploration_claims={0:(83,nav.cell_to_world((13,44)))}
    checks['actual_provider_expired_claim_exact_identity']=np.array_equal(nav._information_weights(default_unknown),default_unknown)
    state._rule_ordinary_exploration=lambda:False
    checks['committed_placement_phase_exact_identity']=nav._information_weights(default_unknown) is default_unknown
    nav.information_weight_provider=None
    checks['default_extension_hook_exact_identity']=nav._information_weights(default_unknown) is default_unknown
    active=dict(goal=None if active_goal is None else active_goal.tolist(),route=[p.tolist() for p in active_route])
else:active=None
out=dict(status='PASS_REAL_PJ01_MEMORY_METHODS' if all(checks.values()) else 'FAIL_KEEP_FIRST',arm=arm,checks={k:bool(v) for k,v in checks.items()},mapping_fields=fields,disabled_route=disabled,active_rule_route=active,
    scope='Actual PJ01 observe/render and route methods on constructed observations, no SDK physics or original-map score. Baseline vs P01 mapping hashes/default routes must compare outside subprocess.')
p=F/(label+'.json');assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
raise SystemExit(0 if all(checks.values()) else 1)
