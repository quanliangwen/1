"""One optional soft exploration rule on the unchanged PJ01 controller."""
import cv2
import numpy as np
from swarm_rescue.solutions.visible_reservation_field import VisibleReservationField


class VisibleReservationRuleMixin:
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.rule_exploration_claims={};self.rule_visibility_events=[]
        self.rule_visibility=VisibleReservationField(cell_size=self.memory.CELL,horizon=240.)
        self.memory.information_weight_provider=self._rule_unknown_weights

    def _rule_ordinary_exploration(self):
        return bool(not self.submitted and not self.coverage_ready and not self._seeking_fusion
            and self.placement_goal is None and self.assignment_goal is None and int(self.carried_bombs_count())>0)

    def define_message_for_all(self):
        packet=super().define_message_for_all();claim=None
        if hasattr(self,'rule_exploration_claims') and self._rule_ordinary_exploration() and self.goal is not None and len(self.waypoints):
            p=np.asarray(self.goal,float)
            if p.shape==(2,) and np.isfinite(p).all():claim=dict(role='ordinary_exploration',goal=p.copy())
        packet['rule_exploration_claim']=claim
        return packet

    def _messages(self):
        super()._messages()
        if not hasattr(self,'rule_exploration_claims'):return
        now=int(self.elapsed_timestep);own=int(self.identifier or 0)
        for _,msg in self.communicator.received_messages:
            if not isinstance(msg,dict) or msg.get('kind')!='greedy-map-v1':continue
            sender,stamp=msg.get('id'),msg.get('step')
            if type(sender)is not int or not 0<=sender<self.team_size or sender==own or type(stamp)is not int or not 0<=now-stamp<=16:continue
            accepted=self.peers.get(sender)
            if accepted is None or accepted[0]!=stamp:continue
            claim=msg.get('rule_exploration_claim')
            if claim is None:self.rule_exploration_claims.pop(sender,None);continue
            if not isinstance(claim,dict) or claim.get('role')!='ordinary_exploration':continue
            try:p=np.asarray(claim.get('goal'),float)
            except (TypeError,ValueError):continue
            if p.shape!=(2,) or not np.isfinite(p).all() or (np.abs(p)>=np.asarray(self.size_area)/2).any():continue
            old=self.rule_exploration_claims.get(sender)
            if old is None or stamp>old[0]:self.rule_exploration_claims[sender]=(stamp,p.copy())

    def _rule_unknown_weights(self,unknown):
        if not self._rule_ordinary_exploration() or not self.rule_exploration_claims:return unknown
        memory=self.memory;claims=[];now=int(memory.step)
        for owner,(stamp,point) in self.rule_exploration_claims.items():
            if owner>=int(self.identifier or 0) or not 0<=now-stamp<=16:continue
            cell=memory.world_to_cell(point)
            if not memory.free[cell]:continue  # A received plan is not own free-space evidence.
            claims.append((owner,stamp,cell))
        if not claims:return unknown
        opaque=cv2.resize((memory.hits>=2).astype(np.float32),(memory.shape[1],memory.shape[0]),interpolation=cv2.INTER_AREA)>=.035
        values,report=self.rule_visibility.weights(unknown,opaque,claims,owner=int(self.identifier or 0),now=now)
        self.rule_visibility_events.append(dict(step=now,**report));self.rule_visibility_events=self.rule_visibility_events[-128:]
        return values
