"""Soft task utility from actually received exploration goals; never mapping.

LOS is exact for the given coarse occupied-cell model using closed supercover
between cell centres. Unknown hidden occlusion is not known: resulting views
are predictions only, never an observation, completion or motion permission.
"""
import math
import numpy as np


def closed_line_offsets(end):
    er,ec=map(int,end);r=c=0;out=[(0,0)];sr=0 if er==0 else (1 if er>0 else -1);sc=0 if ec==0 else (1 if ec>0 else -1)
    dr=math.inf if er==0 else 1/abs(er);dc=math.inf if ec==0 else 1/abs(ec);tr=dr/2;tc=dc/2
    while (r,c)!=(er,ec):
        if abs(tr-tc)<=1e-12:
            out.extend([(r+sr,c),(r,c+sc)]);r+=sr;c+=sc;out.append((r,c));tr+=dr;tc+=dc
        elif tr<tc:r+=sr;out.append((r,c));tr+=dr
        else:c+=sc;out.append((r,c));tc+=dc
    return tuple(dict.fromkeys(out))


class VisibleReservationField:
    def __init__(self,cell_size=16.,horizon=240.,retained_weight=.3):
        if not 0<cell_size or not 0<horizon or not 0<retained_weight<=1 or not np.isfinite([cell_size,horizon,retained_weight]).all():raise ValueError('Finite positive utility model required')
        self.cell_size=float(cell_size);self.horizon=float(horizon);self.retained_weight=float(retained_weight)
        radius=int(math.ceil(horizon/cell_size))
        if radius>24:raise ValueError('Bounded coarse visibility template only')
        ends=[(r,c) for r in range(-radius,radius+1) for c in range(-radius,radius+1) if math.hypot(r,c)*cell_size<=horizon]
        rays=[closed_line_offsets(e) for e in ends];length=max(map(len,rays));index=np.zeros((len(rays),length,2),np.int16);valid=np.zeros(index.shape[:2],bool)
        for i,ray in enumerate(rays):index[i,:len(ray)]=ray;valid[i,:len(ray)]=True
        self.ends=np.asarray(ends,np.int16);self.rays=index;self.valid=valid
        for array in [self.ends,self.rays,self.valid]:array.flags.writeable=False

    def expected_view(self,opaque,goal):
        wall=np.asarray(opaque,bool);r,c=map(int,goal)
        if wall.ndim!=2 or not 0<=r<wall.shape[0] or not 0<=c<wall.shape[1] or wall[r,c]:return np.zeros(wall.shape,bool)
        rows=self.rays[:,:,0].astype(int)+r;cols=self.rays[:,:,1].astype(int)+c
        inside=(rows>=0)&(cols>=0)&(rows<wall.shape[0])&(cols<wall.shape[1]);hit=np.zeros(rows.shape,bool)
        where=self.valid&inside;hit[where]=wall[rows[where],cols[where]]
        clear=~np.any((hit|~inside)&self.valid,axis=1)
        er=self.ends[:,0].astype(int)+r;ec=self.ends[:,1].astype(int)+c
        take=clear&(er>=0)&(ec>=0)&(er<wall.shape[0])&(ec<wall.shape[1]);mask=np.zeros(wall.shape,bool);mask[er[take],ec[take]]=True
        return mask

    def weights(self,unknown,opaque,claims,*,owner,now,max_age=16):
        values=np.asarray(unknown);wall=np.asarray(opaque,bool)
        if values.ndim!=2 or wall.shape!=values.shape or not np.isfinite(values).all() or np.any(values<0) or type(owner)is not int or type(now)is not int:raise ValueError('Actual finite own coarse information field required')
        covered=np.zeros(values.shape,bool);accepted=[]
        for peer,stamp,goal in claims:
            if type(peer)is not int or not 0<=peer<owner or type(stamp)is not int or not 0<=now-stamp<=max_age:continue
            q=np.asarray(goal)
            if q.shape!=(2,) or q.dtype.kind not in 'iu' or not 0<=q[0]<wall.shape[0] or not 0<=q[1]<wall.shape[1] or wall[tuple(q)]:continue
            covered|=self.expected_view(wall,q);accepted.append(peer)
        factor=np.where(covered,self.retained_weight,1.).astype(np.float32)
        result=values*factor
        return result,dict(accepted_lower_priority_peers=sorted(set(accepted)),discounted_unknown_cells=int(np.count_nonzero(covered&(values>0))),
            information_mass_before=float(values.sum()),information_mass_after=float(result.sum()),map_writes=False,completion_claim=False,motion_permission=False,
            scope='Soft ranking model only; unknown occlusion can invalidate a predicted view. No hard territorial/diameter separation or removal of observations.')
