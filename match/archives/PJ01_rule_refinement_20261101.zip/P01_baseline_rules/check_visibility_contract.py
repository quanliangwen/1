from pathlib import Path
import json,hashlib,numpy as np
from visible_reservation_field import VisibleReservationField,closed_line_offsets
F=Path(__file__).resolve().parent;field=VisibleReservationField();wall=np.zeros((70,70),bool);unknown=np.ones(wall.shape,np.float32)
u=unknown.copy();w=wall.copy();checks={}
a,meta=field.weights(unknown,wall,[],owner=1,now=100)
checks['no_actual_claim_exact_identity']=np.array_equal(a,unknown)
a,meta=field.weights(unknown,wall,[(0,100,(30,30))],owner=1,now=100)
checks['fresh_lower_goal_discount']=abs(float(a[30,30])-.3)<1e-6 and meta['discounted_unknown_cells']>0
checks['outside_effective240_radius_unchanged']=a[30,46]==1 and a[30,45]<1
checks['positive_weight_not_wall_or_frontier_deleted']=a.min()>.29 and not meta['map_writes'] and not meta['completion_claim'] and not meta['motion_permission']
b,_=field.weights(unknown,wall,[(0,100,(30,30)),(1,100,(30,30))],owner=2,now=100)
checks['multiple_claims_union_not_multiplicative']=np.array_equal(a,b)
for name,claims in [('old',[(0,83,(30,30))]),('future',[(0,101,(30,30))]),('higher',[(2,100,(30,30))]),('own',[(1,100,(30,30))]),('out_of_bounds',[(0,100,(-1,30))])]:
    b,_=field.weights(unknown,wall,claims,owner=1,now=100);checks['ignore_'+name]=np.array_equal(b,unknown)
wall[:,35]=True
b,meta=field.weights(unknown,wall,[(0,100,(30,30))],owner=1,now=100)
checks['known_wall_protects_other_side_value']=b[30,40]==1 and b[30,34]<1
wall2=np.zeros((10,10),bool);wall2[4,5]=True
view=field.expected_view(wall2,(4,4))
checks['closed_corner_contact_known_wall_blocks_diagonal']=not view[5,5]
checks['line_supercover_both_corner_neighbors']=(1,0) in closed_line_offsets((1,1)) and (0,1) in closed_line_offsets((1,1))
b,_=field.weights(unknown,wall,[(0,100,(30,35))],owner=1,now=100)
checks['occupied_claim_goal_ignored']=np.array_equal(b,unknown)
checks['own_arrays_unchanged']=np.array_equal(unknown,u) and np.array_equal(wall[:,0],w[:,0]) and np.all(wall[:,35])
checks['immutable_geometry_template']=not field.ends.flags.writeable and not field.rays.flags.writeable and not field.valid.flags.writeable
small=VisibleReservationField(cell_size=16,horizon=16);mask=small.expected_view(np.zeros((5,5),bool),(2,2))
checks['circle_not_square_scanning_footprint']=mask.sum()==5 and not mask[1,1]
checks['hidden_unknown_wall_is_not_observation']=meta['scope'].startswith('Soft ranking model')
out=dict(status='PASS_SOFT_VISIBLE_RESERVATION_UTILITY_ONLY' if all(checks.values()) else 'FAIL_KEEP_FIRST',checks={k:bool(v) for k,v in checks.items()},
    source_sha256=hashlib.sha256((F/'visible_reservation_field.py').read_bytes()).hexdigest(),scope='Pure model; no SDK integration, map gains or physical separation proved. Known wall occlusion respected; future hidden walls still unknown.')
p=F/'VISIBILITY_CONTRACT_FIRST.json';assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(status=out['status'],checks=len(checks),failed=[k for k,v in checks.items() if not v])))
raise SystemExit(0 if all(checks.values()) else 1)
