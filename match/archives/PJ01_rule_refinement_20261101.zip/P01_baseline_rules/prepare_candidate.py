from pathlib import Path
import json,ast,shutil,hashlib,datetime
F=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_text(encoding='utf8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=read(F/'BASELINE_IDENTITY.json');assert base['status']=='PASS_ALL36_PYTHON_SAME_AS_REVIEWED_PJ01_F32'
B=Path(base['baseline_project']);assert all(sha(B/n)==v for n,v in base['files'].items())
c=read(F/'VISIBILITY_CONTRACT_FIRST.json');assert c['status']=='PASS_SOFT_VISIBLE_RESERVATION_UTILITY_ONLY' and sha(F/'visible_reservation_field.py')==c['source_sha256']
W=F/'candidate_project';assert not W.exists();shutil.copytree(B,W)
S=W/'src/swarm_rescue/solutions'
for n in ['visible_reservation_field.py','pj01_scan_rules.py']:ast.parse((F/n).read_text(encoding='utf8'));shutil.copy2(F/n,S/n)
p=S/'fast_exploration.py';s=p.read_text(encoding='utf8');mark='    def clearance(self):';assert s.count(mark)==1
s=s.replace(mark,'''    def _information_weights(self,unknown):
        provider=getattr(self,'information_weight_provider',None)
        return unknown if provider is None else provider(unknown)

'''+mark)
mark='gain = cv2.boxFilter(unknown, -1, (information_window, information_window),';assert s.count(mark)==1
s=s.replace(mark,'gain = cv2.boxFilter(self._information_weights(unknown), -1, (information_window, information_window),')
ast.parse(s);p.write_text(s,encoding='utf8')
p=S/'fast_exploration_edges.py';s=p.read_text(encoding='utf8');mark='information = cv2.boxFilter(unknown, -1, (13, 13),';assert s.count(mark)==1
s=s.replace(mark,'information = cv2.boxFilter(self._information_weights(unknown), -1, (13, 13),');ast.parse(s);p.write_text(s,encoding='utf8')
p=S/'my_drone_eval.py';s=p.read_text(encoding='utf8');s=s.replace('class MyDroneEval(','class _PJ01BaselineDrone(')
mark='def drone_class_for_mode(mode):';assert s.count(mark)==1
s=s.replace(mark,'''from swarm_rescue.solutions.pj01_scan_rules import VisibleReservationRuleMixin

class MyDroneEval(VisibleReservationRuleMixin,_PJ01BaselineDrone):
    pass

'''+mark);ast.parse(s);p.write_text(s,encoding='utf8')
files={p.relative_to(W).as_posix():sha(p) for p in W.rglob('*') if p.is_file()};changed=sorted(n for n,v in files.items() if base['files'].get(n)!=v)
assert len(changed)==5
unchanged=[n for n in base['files'] if n not in changed];assert all(sha(W/n)==base['files'][n] for n in unchanged)
out=dict(status='PREPARED_PJ01_SINGLE_RULE_NOT_SCORE_QUALIFIED',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),candidate_project=str(W),files=files,changed_files=changed,
    python_files=len(list(S.glob('*.py'))),original_python_files_unchanged=33,mapping_sensing_fusion_motion_layout_exit_unchanged=True,
    original_python_count=36,official_zip_created=False,new_dependency=False,automatic_five=False,SDK_started=False)
(F/'CANDIDATE_MANIFEST.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in out.items() if k!='files'},ensure_ascii=False))
