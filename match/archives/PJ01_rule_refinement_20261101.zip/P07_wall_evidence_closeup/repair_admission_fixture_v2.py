from pathlib import Path
import subprocess
F=Path(__file__).resolve().parent
R='/home/junhao/quan/parallel_test_solver/match'
H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025'
D=H+'/PJ01_rules_P07_wall_closeup_20261101'
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
subprocess.run(ssh+[R+'/.venv/bin/python',H+'/R154_scoped_serial_guard_20261101/check_scoped_serial.py'],check=True)
for original,label in [('check_admit_original8.py','ADMIT_ORIGINAL8_V2'),('check_admit_complete4.py','ADMIT_COMPLETE4_V2')]:
    src=(F/original).read_text(encoding='utf-8')
    src=src.replace("walk=probe.memory.free&~geometry.blocked();path=request['path']", "walk=probe.memory.free&~geometry.blocked();probe_path=request['path']")
    src=src.replace('for c in path[1:]', 'for c in probe_path[1:]').replace('zip(path,path[1:])','zip(probe_path,probe_path[1:])')
    target=F/(Path(original).stem+'_v2.py')
    assert not target.exists()
    target.write_text(src,encoding='utf-8')
    subprocess.run(['scp','-q',str(target),'junhao@10.112.162.60:'+D+'/'],check=True)
    run=subprocess.run(ssh+[R+'/.venv/bin/python',H+'/run_sdk_captured.py',D+'/'+target.name,label],capture_output=True,text=True)
    (F/(label+'.capture.txt')).write_text(run.stdout+run.stderr,encoding='utf-8')
    print(run.stdout);print(run.stderr)
    if run.returncode:raise SystemExit(run.returncode)
    subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+label+'.json',str(F/(label+'.json'))],check=True)
