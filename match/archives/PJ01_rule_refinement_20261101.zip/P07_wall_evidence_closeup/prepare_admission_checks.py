from pathlib import Path
import json,subprocess
F=Path(__file__).resolve().parent;A=F.parent/'P04_existing_finite_wall_audit'
tail='''
    before=arrays(probe.memory)
    original=probe.memory.render().copy()
    geometry=GeometryPlanningMemory(probe.memory)
    excluded=probe.memory.semantic_mask(probe.ranges,ANGLES,[])
    def solver(source,target,walkable,deadline):
        return _sortie_known_route(probe.memory,source,target,walkable,deadline,max_pops=2048)
    args=dict(pose=probe.pose,heading=probe.heading,distances=probe.ranges,angles=ANGLES,excluded=excluded,
        parent_image=original,free=probe.memory.free,blocked=geometry.blocked(),width=WIDTH,height=HEIGHT,
        cell=probe.memory.CELL,fine=probe.memory.FINE,world_to_cell=probe.memory.world_to_cell,
        cell_to_world=probe.memory.cell_to_world,route_solver=solver,remaining=500.,step=probe.clock,limit=2000)
    request=select_probe(**args,deadline=time.perf_counter()+.1)
    negative=[]
    for name,overrides in [('all_painted',dict(parent_image=np.ones_like(original))),
      ('unknown',dict(free=np.zeros_like(probe.memory.free))),('blocked',dict(blocked=np.ones_like(probe.memory.free))),
      ('short_budget',dict(remaining=20.)),('time_bonus_boundary',dict(step=999,limit=2000)),
      ('semantic_excluded',dict(excluded=np.ones_like(excluded))),
      ('route_abstains',dict(route_solver=lambda *a:None)),('expired_computation',dict(deadline=time.perf_counter()-1))]:
        item=dict(args,**overrides)
        result=select_probe(**item)
        assert result is None,(name,result)
        negative.append(name)
    assert all(np.array_equal(v,getattr(probe.memory,k))for k,v in before.items())
    if request is not None:
        walk=probe.memory.free&~geometry.blocked();path=request['path']
        assert all(walk[tuple(c)]for c in path[1:])
        for a,b in zip(path,path[1:]):
            dr,dc=b[0]-a[0],b[1]-a[1]
            assert max(abs(dr),abs(dc))==1
            if dr and dc:assert walk[a[0]+dr,a[1]]and walk[a[0],a[1]+dc]
        assert request['needed_steps']<=96 and request['needed_steps']<=500/2
    return dict(case=f'{kind}_{route}_{"noise"if noisy else"clean"}',admitted=request is not None,probe=request,
        negative_controls=negative,original_memory_arrays_unchanged=True,actual_Memory_and_known_Astar_used=True)

started=time.perf_counter();rows=[]
with contextlib.redirect_stdout(io.StringIO()):
    for kind in ['closed','doorway']:
        for route in ROUTES:
            for noisy in [False,True]:rows.append(run(kind,route,noisy,SEED+len(rows)))
out=dict(status='PASS_ACTUAL_KNOWN_ROUTE_ADMISSION_AND_ABSTENTION',rows=rows,admitted_cases=sum(r['admitted']for r in rows),
    seconds=time.perf_counter()-started,physics_steps=0,native_rounds=0,production_integrated=False,
    scope='Real originalPJ01 pose/frame/Memory/render/GeometryPlanningMemory and inherited bounded Astar on raw known-free cells. Authored sensor streams; no physical traversal, new sensor incorporation or map gain proved.')
(F/(label+'.json')).write_text(json.dumps(out,indent=2)+'\\n');print(json.dumps({k:v for k,v in out.items()if k!='rows'}));print(json.dumps(rows))
'''
for src,name,routes,seed in [('check_actual_pj01_memory_shadow.py','check_admit_original8.py',['full','partial'],615),
                           ('check_ceiling_countercases.py','check_admit_complete4.py',['complete'],9001)]:
    s=(A/src).read_text(encoding='utf-8')
    s=s[:s.index('    before=arrays(probe.memory)')]
    s=s.replace('from finite_wall_support import FiniteWallSupport,from_actual_scan',
       'from finite_wall_support import FiniteWallSupport,from_actual_scan\nfrom wall_probe_reference import select_probe\nfrom swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory\nfrom swarm_rescue.solutions.completion_consensus import _sortie_known_route')
    s+=tail.replace('ROUTES',repr(routes)).replace('SEED',str(seed))
    (F/name).write_text(s,encoding='utf-8')
declaration=dict(status='REFERENCE_ONLY_NOT_CANDIDATE',cases='same authored original8+complete4 streams',
 inherited_values=dict(raw_hit_cutoff=220,old_finite_range_max=280,edge_survey_standoff=190,max_probe_steps=96,extra_reserve_steps=48),
 checks='Raw-known-free mask + inherited22px geometry block + original bounded Astar; no corner cuts, no unknown traversal, budget/semantic/no-evidence negatives. No new action/source integrated.')
(F/'ADMISSION_PREDECLARATION.json').write_text(json.dumps(declaration,indent=2)+'\n',encoding='utf-8')
R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P07_wall_closeup_20261101'
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
subprocess.run(ssh+[R+'/.venv/bin/python',H+'/R154_scoped_serial_guard_20261101/check_scoped_serial.py'],check=True)
subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=('from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n').encode(),check=True)
for n in ['wall_probe_reference.py','finite_wall_support.py','ADMISSION_PREDECLARATION.json','GATE_CHECK_FIRST.json','check_admit_original8.py','check_admit_complete4.py']:
    subprocess.run(['scp','-q',str(F/n),'junhao@10.112.162.60:'+D+'/'],check=True)
for script,label in [('check_admit_original8.py','ADMIT_ORIGINAL8_FIRST'),('check_admit_complete4.py','ADMIT_COMPLETE4_FIRST')]:
    run=subprocess.run(ssh+[R+'/.venv/bin/python',H+'/run_sdk_captured.py',D+'/'+script,label],capture_output=True,text=True)
    (F/(label+'.capture.txt')).write_text(run.stdout+run.stderr,encoding='utf-8');print(run.stdout);print(run.stderr)
    if run.returncode:raise SystemExit(run.returncode)
    subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+label+'.json',str(F/(label+'.json'))],check=True)
