"""Existing finite-wall rule, same-input shadow of real PJ01 memory only.

Authored sensor-input cases, real baseline pose/frame/anchor/memory/render and
SDK post-score. No controller changes, no physical game or true-map runtime use.
"""
from pathlib import Path
import contextlib,copy,hashlib,io,json,math,sys,time
import numpy as np
F=Path(__file__).resolve().parent;label=sys.argv[1]
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
m=json.loads((H/'PJ01_rules_P03_pose_20261101/WORKSPACE_READY.json').read_text())['versions']['PJ01']
W=Path(m['workspace']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(W/n)==h for n,h in m['sources'].items())
assert all(sha(W/n)==h for n,h in m['sdk_files'].items())
sys.path.insert(0,str(W/'src'))
import cv2
from swarm_rescue.solutions.greedy_mapping import GreedyMappingDrone
from swarm_rescue.solutions.frame_mapping import FrameMappingMixin
from swarm_rescue.solutions.anchor_mapping import AnchoredMappingMixin
from swarm_rescue.solutions.bearing_memory import BearingMemory
from swarm_rescue.solutions.boundary_anchor import ObservedBoundaryAnchor
from swarm_rescue.simulation.reporting.place_score_manager import PlaceScoreManager,rasterize_world_polygons
from finite_wall_support import FiniteWallSupport,from_actual_scan
from wall_probe_reference import select_probe
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
from swarm_rescue.solutions.completion_consensus import _sortie_known_route

WIDTH,HEIGHT=640,480
ANGLES=np.linspace(-math.pi,math.pi,180,endpoint=False)
class Probe(FrameMappingMixin,AnchoredMappingMixin,GreedyMappingDrone):
    def __init__(self):
        self.clock=0;self.pose=None;self.heading=0.;self.heading_initialized=False;self.rally=None
        self.memory=BearingMemory(WIDTH,HEIGHT,identifier=0,team_size=5)
        self.boundary_anchor=ObservedBoundaryAnchor(WIDTH,HEIGHT)
        self.frame_records={};self.frame_negative={}
        self.memory.frame_records=self.frame_records;self.memory.frame_negative=self.frame_negative
    @property
    def identifier(self):return 0
    @property
    def elapsed_timestep(self):return self.clock
    def measured_gps_position(self):return self.gps
    def measured_compass_angle(self):return self.compass
    def odometer_values(self):return self.odom
    def lidar_values(self):return self.ranges
    def lidar_rays_angles(self):return ANGLES
    def semantic_values(self):return []

def rect(x0,y0,x1,y1):return [[x0,y0],[x1,y0],[x1,y1],[x0,y1]]
def scene(kind):
    polys=[rect(-323,-243,323,-237),rect(-323,237,323,243),rect(-323,-243,-317,243),rect(317,-243,323,243)]
    if kind=='doorway':polys += [rect(-260,97,-60,103),rect(60,97,260,103)]
    return polys

def scan(p,heading,polygons):
    directions=np.column_stack((np.cos(ANGLES+heading),np.sin(ANGLES+heading)))
    out=np.full(len(ANGLES),300.)
    for poly in polygons:
        box=np.asarray(poly);lo=box.min(axis=0);hi=box.max(axis=0)
        ta=np.divide(lo-p,directions,out=np.full_like(directions,-np.inf),where=np.abs(directions)>1e-12)
        tb=np.divide(hi-p,directions,out=np.full_like(directions,np.inf),where=np.abs(directions)>1e-12)
        enter=np.minimum(ta,tb).max(axis=1);leave=np.maximum(ta,tb).min(axis=1)
        good=(leave>=np.maximum(enter,0.))&(enter>0)
        out=np.minimum(out,np.where(good,enter,300.))
    return out

def path(kind):
    points=([[-180,-120],[0,-120],[0,160],[180,160],[0,160],[0,-120]] if kind=='full' else
            [[-180,-130],[0,-130],[180,-130],[0,-130],[-180,-130]])
    return np.concatenate([np.linspace(a,b,40,endpoint=False) for a,b in zip(points[:-1],points[1:])])

def arrays(memory):
    return {n:v.copy() for n,v in memory.__dict__.items() if isinstance(v,np.ndarray)}

def score_after_freeze(polys,pred):
    truth=rasterize_world_polygons(polys,WIDTH,HEIGHT)
    boundary=rasterize_world_polygons(polys[:4],WIDTH,HEIGHT)
    p=PlaceScoreManager().compute_phase1_score(truth,pred,elapsed_walltime=1.,max_walltime_limit=90,
        score_exploration_trajectory=0.,placed_count=0,expected_count=10,has_crashed=False,bomb_positions=[],
        elapsed_timestep=200,max_timestep_limit=1000,wall_grid=truth,boundary_grid=boundary)
    return dict(map_score=p.score_map,credit=p.map_breakdown['credit'],penalty=p.map_breakdown['penalty'])

def run(kind,route,noisy,seed):
    polys=scene(kind);positions=path(route);rng=np.random.default_rng(seed)
    probe=Probe();support=FiniteWallSupport(WIDTH,HEIGHT,fine=probe.memory.FINE)
    gpsbias=np.zeros(2);cbias=0.;head=0.;far_supported=0
    started=time.perf_counter()
    for t,p in enumerate(positions):
        delta=p-positions[t-1] if t else np.zeros(2)
        if noisy:
            gpsbias=.98*gpsbias+rng.normal(0,5*math.sqrt(1-.98**2),2)
            cbias=.98*cbias+rng.normal(0,math.radians(4)*math.sqrt(1-.98**2))
        probe.clock=t;probe.gps=p+gpsbias;probe.compass=cbias
        probe.odom=np.array([np.linalg.norm(delta)+(rng.normal(0,.2) if noisy else 0),
             math.atan2(delta[1],delta[0])+(rng.normal(0,math.radians(8)) if noisy else 0),
             rng.normal(0,math.radians(1)) if noisy else 0])
        probe.ranges=scan(p,head,polys)
        if noisy:probe.ranges=np.clip(probe.ranges+rng.normal(0,1.,len(ANGLES)),0,300)
        # Real baseline methods receive only authored public observation inputs.
        probe._update_pose()
        if t%4==0:
            probe.memory.step=t
            probe.memory.observe(probe.pose,probe.heading,probe.ranges,ANGLES,[])
            excluded=probe.memory.semantic_mask(probe.ranges,ANGLES,[])
            segments=from_actual_scan(probe.pose,probe.heading,probe.ranges,ANGLES,excluded)
            far_supported+=int(np.count_nonzero((probe.ranges>=220)&(probe.ranges<280)))
            support.update(step=t,pose=probe.pose,heading=probe.heading,segments=segments)

    before=arrays(probe.memory)
    original=probe.memory.render().copy()
    geometry=GeometryPlanningMemory(probe.memory)
    excluded=probe.memory.semantic_mask(probe.ranges,ANGLES,[])
    def solver(source,target,walkable,deadline):
        return _sortie_known_route(probe.memory,source,target,walkable,deadline,max_pops=2048)
    args=dict(pose=probe.pose,heading=probe.heading,distances=probe.ranges,angles=ANGLES,excluded=excluded,
        parent_image=original,free=probe.memory.free,blocked=geometry.blocked(),width=WIDTH,height=HEIGHT,
        cell=probe.memory.CELL,fine=probe.memory.FINE,world_to_cell=probe.memory.world_to_cell,
        cell_to_world=probe.memory.cell_to_world,route_solver=solver,remaining=500.,step=probe.clock,limit=2000)
    request=select_probe(**args,deadline=time.perf_counter()+.1)
    negative=[]
    for name,overrides in [('all_painted',dict(parent_image=np.ones_like(original))),
      ('unknown',dict(free=np.zeros_like(probe.memory.free))),('blocked',dict(blocked=np.ones_like(probe.memory.free))),
      ('short_budget',dict(remaining=20.)),('time_bonus_boundary',dict(step=999,limit=2000)),
      ('semantic_excluded',dict(excluded=np.ones_like(excluded))),
      ('route_abstains',dict(route_solver=lambda *a:None)),('expired_computation',dict(deadline=time.perf_counter()-1))]:
        item=dict(args,**overrides)
        result=select_probe(**item)
        assert result is None,(name,result)
        negative.append(name)
    assert all(np.array_equal(v,getattr(probe.memory,k))for k,v in before.items())
    if request is not None:
        walk=probe.memory.free&~geometry.blocked();path=request['path']
        assert all(walk[tuple(c)]for c in path[1:])
        for a,b in zip(path,path[1:]):
            dr,dc=b[0]-a[0],b[1]-a[1]
            assert max(abs(dr),abs(dc))==1
            if dr and dc:assert walk[a[0]+dr,a[1]]and walk[a[0],a[1]+dc]
        assert request['needed_steps']<=96 and request['needed_steps']<=500/2
    return dict(case=f'{kind}_{route}_{"noise"if noisy else"clean"}',admitted=request is not None,probe=request,
        negative_controls=negative,original_memory_arrays_unchanged=True,actual_Memory_and_known_Astar_used=True)

started=time.perf_counter();rows=[]
with contextlib.redirect_stdout(io.StringIO()):
    for kind in ['closed','doorway']:
        for route in ['full', 'partial']:
            for noisy in [False,True]:rows.append(run(kind,route,noisy,615+len(rows)))
out=dict(status='PASS_ACTUAL_KNOWN_ROUTE_ADMISSION_AND_ABSTENTION',rows=rows,admitted_cases=sum(r['admitted']for r in rows),
    seconds=time.perf_counter()-started,physics_steps=0,native_rounds=0,production_integrated=False,
    scope='Real originalPJ01 pose/frame/Memory/render/GeometryPlanningMemory and inherited bounded Astar on raw known-free cells. Authored sensor streams; no physical traversal, new sensor incorporation or map gain proved.')
(F/(label+'.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='rows'}));print(json.dumps(rows))
