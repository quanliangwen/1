from pathlib import Path
import json,time,math
import numpy as np
from wall_probe_reference_v2 import select_probe
F=Path(__file__).resolve().parent;out=F/'WITNESS_CONTRACT_FIRST.json';assert not out.exists()
checks=[]
def require(v,name):assert v,name;checks.append(name)
pose=np.array([-160.,-130.]);angles=np.linspace(-math.pi,math.pi,180,endpoint=False)
rays=np.full(180,300.);up=np.sin(angles)>0
hit=np.full(180,math.inf);hit[up]=230/np.sin(angles[up]);x=pose[0]+hit*np.cos(angles)
valid=up&(x>=-260)&(x<=-60)&(hit<280);rays[valid]=hit[valid]
free=np.ones((30,40),bool);blocked=np.zeros_like(free);image=np.zeros((480,640),np.uint8)
def world_to_cell(p):return(int((240-p[1])//16),int((p[0]+320)//16))
def cell_to_world(c):return np.array([(c[1]+.5)*16-320,240-(c[0]+.5)*16])
def solver(a,b,walk,deadline):
    if a[1]!=b[1]:return None
    sign=1 if b[0]>a[0]else -1
    return[(r,a[1])for r in range(a[0],b[0]+sign,sign)]
witness=dict(step=100,pose=pose.copy(),heading=0.,distances=rays.copy(),angles=angles.copy(),excluded=np.zeros(180,bool))
args=dict(pose=pose,heading=0.,distances=np.full(180,12.),angles=angles,excluded=np.ones(180,bool),
    parent_image=image,free=free,blocked=blocked,width=640,height=480,cell=16,fine=2,world_to_cell=world_to_cell,
    cell_to_world=cell_to_world,route_solver=solver,remaining=500,step=101,limit=2000)
before=[a.copy()for a in [pose,rays,angles,free,blocked,image]]
require(select_probe(**args)is None,'live_bomb_shadow_has_no_fabricated_wall')
request=select_probe(**args,pre_place_witness=witness)
require(request is not None,'fresh_own_pre_place_wall_can_support_known_route')
require(select_probe(**dict(args,step=124),pre_place_witness=witness)is not None,'exact24step_owned_witness_boundary_allowed')
for name,change in [('expired',dict(step=75)),('future',dict(step=102)),('invalid_epoch_type',dict(step=100.)),
    ('nonfinite_pose',dict(pose=[float('nan'),0])),('wrong_pose_shape',dict(pose=[0])),
    ('nonfinite_heading',dict(heading=float('inf'))),('mismatched_ray_angles',dict(angles=angles[:-1])),
    ('mismatched_semantic_mask',dict(excluded=[False])),('all_semantic_excluded',dict(excluded=np.ones(180,bool)) )]:
    require(select_probe(**args,pre_place_witness=dict(witness,**change))is None,name+'_abstains')
missing=dict(witness);del missing['distances']
require(select_probe(**args,pre_place_witness=missing)is None,'missing_owned_scan_field_abstains')
require(select_probe(**args,pre_place_witness=[])is None,'non_dictionary_witness_abstains')
for name,change in [('unknown',dict(free=np.zeros_like(free))),('blocked',dict(blocked=np.ones_like(blocked))),
    ('map_already_painted',dict(parent_image=np.ones_like(image))),('short_budget',dict(remaining=10)),
    ('late_time_bonus',dict(step=999,pre_place_witness=dict(witness,step=998))),
    ('no_route',dict(route_solver=lambda*a:None)),('expired_compute',dict(deadline=time.perf_counter()-1))]:
    item=dict(args,pre_place_witness=witness);item.update(change)
    require(select_probe(**item)is None,name+'_not_overridden_by_cached_witness')
require(all(np.array_equal(a,b)for a,b in zip(before,[pose,rays,angles,free,blocked,image])),'caller_arrays_not_modified')
result=dict(status='PASS_OWN_WITNESS_VALIDATION_REFERENCE_ONLY',checks=checks,request=request,native_rounds=0,physics_steps=0,
    scope='Authored masks and simple column-route stub; real original Astar/sensors/physics are independently checked in SDK fixtures.')
out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(status=result['status'],checks=len(checks))))
