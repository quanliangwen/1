from pathlib import Path
import json,datetime,subprocess
F=Path(__file__).resolve().parent;A=F/'FINAL';now=datetime.datetime.now(datetime.timezone.utc).isoformat()
R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P07_wall_closeup_20261101/FINAL'
subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/LAUNCH.json',str(A/'LAUNCH.json')],check=True)
l=json.loads((A/'LAUNCH.json').read_text());c=json.loads((A/'WINDOWS_COLLECTOR_LAUNCH.json').read_text())
note=f'''LATEST {now}，当前P07/FINAL原资源单Map02 RED机制筛选已离线安排，不是五图。覆盖前文“未有生产候选/尚未接入SDK”。
阶段E:/codex/PJ01_rule_refinement_20261101/P07_wall_evidence_closeup/FINAL；服务器H/PJ01_rules_P07_wall_closeup_20261101/FINAL。
服务器coordinator{l['pid']}/start{l['starttime_ticks']}/UTC{l['utc']}；Windowscollector{c['pid']}/UTC{c['utc']}，有限14h收集。它已占用本聊天唯一调度，等待也不得并开。不照旧PID操作，先核实际/proc命令与start/STATUS/全局serial锁和registry。
只1次RED/noBLUE，原SDK e2f022b、原线程/时限/无外部seed和原CPU<=60/loadcore<=.4/RAM8GiB/盘12GiB/两样本60秒保持。高负载旧授权均耗尽。内部ZIP SHA79bdbc0083720b4e366d6762bd88f3f1bae2052587bea1e7b3c4e600a29daca3，不是官网包。

本轮已完成实质分析/小检查而非盲跑：
1 原参考真实SDK运动层4例：无弹遮挡2例13步取得168/172新扫描并写入原memory，作者地图+.705/+.458；真实刚投弹后2例因全激光遮挡被拒绝。第一FAIL保留，不伪称全通过。
2 同一墙面补扫规则改为可用请求最后一次投放前的本机实际扫描，最多24步有效，不替换原激光数组、不增低层避弹规则。4例均13步完成，地图+.705/+.458/1.053/.600；真实投放弹药0位移/健康不降。只是运动层与受控证书前提，无真实无线证书证明。
3 接入真实5控制器/原control/实际无线消息/官方7回调：原PJ01两例161步提交。P07初版同样直接提交，未触发，保留FULL_SDK_P07_FIRST的FAIL。只读逐过滤诊断查出2条合法已知路线和空32px地图支撑窗口，却被某条219.636px噪声测距导致“所有段内ray都>=220”拒绝；不是接单/通信或实际投放失败。
4 独立V3只把ALL FAR改为至少6条实际>=220支撑，保留TLS最少6点/长度40/误差8、中心220..280、原图32px空窗口、原known-free A*及时间/库存/间距/原地图。V3真实5控制器clean/noise均通过：实际1颗投放、无线收到其他4证书，最后0号仅暂缓自己的证书，168/172两次新扫描在Memory中后172提交。相较原PJ01同作者输入图+.646865/+.384724，时间分均满(作者步数/不是native分)。真实弹药0位移/无人机健康50。4个近完整图均不触发，原8只有2例触发，96负控均拒绝；22见证有效性+21完成门契约PASS。单位网格stub首版把浮点边界邻列当不可达，失败脚本保留，V2仅修fixture合法正交路线，未改算法。
5 FINAL仅加只读submit SHA/owner/shape/dtype记录便于公开PNG绑定；与V3逻辑相同。实际整数615/NumPy mtrand随机/Pandas/cv2/SDK入口/5机独立构造PASS，再次完整5控制器两例PASS且源绑定。original PJ01独立底本5Py差异：入口、completion刹停条件新增active例外、新补扫Mixin、原有限段提案helper和选择/有界完成门。不含已淘汰P02/P03/P05，不改mapper/原路线/布点/依赖/SDK。

固定单图门槛：实际准入+2次新的本机近距扫描已经写图+提交PNG SHA绑定，10/10、RED无墙钟hit、图>=95.9871008172(刚完成原PJ01只读P06图95.4871+.5)、墙>=71.5212925722、时间100。只是独立无seed筛选，不是同输入因果或完整排名。仅通过也不自动五图；先看机制和收益幅度，再决定必要BLUE/同期五图。失败不改门槛、不换标签/seed重试救分。
先等首Windows原始opaque字节审核，再读FINAL/OBS_A/MECHANISM_REVIEW与CAMPAIGN_CLIENT_REVIEW。Collector每组只审核一次，NPZ/pickle不反序列化，只摘要公开图/本机日志/官方分项，不读竞赛真图/BLUE私态。完整红分null，不能拿RED阶段partial总分当完整得分。
原P06已9raw首Windows/CAMPAIGN PASS，图95.4871/墙71.5213/时间100/10枚/1453步116.4374秒，唯一提交者2号图SHA绑定，库存0/全证书/余量541.433步，非本次预算耗尽。只有2号最终profile16.2963sec，不可把剩100.1411秒当纯SDK或全队瓶颈。原2141472/97476已结束，不重启。
目标持续ACTIVE，原生运行时不叠重SDK计算，可继续轻量代码/证据分析；90分钟仅接续不强制五图。C7取消，旧测试/正式V06V07V08不动不发布。用户停止立即暂停后续调度。
'''
with(F/'WORKING_HANDOFF_P07.txt').open('a',encoding='utf-8')as h:h.write('\n'+note)
(A/'WORKING_HANDOFF_P07_FINAL.txt').write_text(note,encoding='utf-8')
with(F/'分析依据与小检查结论.txt').open('a',encoding='utf-8')as h:h.write('\n'+note)
idx=Path('E:/codex/swarm-eod-literature-analysis/CURRENT_ACTIVE_ANALYSIS.txt');idx.write_text(note+'\nHISTORY\n'+idx.read_text(encoding='utf-8'),encoding='utf-8')
(F/'AUTOMATION_PROMPT.txt').write_text('继续用户明确ACTIVE的原PJ01地图精度优先持续目标，直到用户停止。先读E:/codex/AGENTS.md、E:/codex/swarm-eod-literature-analysis/CURRENT_ACTIVE_ANALYSIS.txt、E:/codex/PJ01_rule_refinement_20261101/P07_wall_evidence_closeup/WORKING_HANDOFF_P07.txt最后追加部分与FINAL最新STATUS/RESULT/MECHANISM_REVIEW/CAMPAIGN_CLIENT_REVIEW。实际文件覆盖快照。每次实质分析/必要修改和小检查，不只轮询COMPLETE；一次只加一条，先有希望才原单图，真实地图改善才考虑同期五图。不放弃目标、不自行暂停或完成。\n\n'+note,encoding='utf-8')
print(json.dumps(dict(status='P07_NATIVE_LAUNCH_AND_EVIDENCE_RECORDED',pid=l['pid'])))
