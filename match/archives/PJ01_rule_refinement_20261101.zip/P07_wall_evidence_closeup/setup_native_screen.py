from pathlib import Path
import subprocess,ast,json
F=Path(__file__).resolve().parent/'FINAL';R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P07_wall_closeup_20261101/FINAL'
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
for n in ['run_offline.py','prepare_native.py','validate_driver.py','collect_offline.py','launch_campaign.py','start_local_collector.py']:ast.parse((F/n).read_text())
subprocess.run(ssh+[R+'/.venv/bin/python',H+'/R154_scoped_serial_guard_20261101/check_scoped_serial.py'],check=True)
for n in ['run_offline.py','prepare_native.py','validate_driver.py','launch_campaign.py']:
    subprocess.run(['scp','-q',str(F/n),'junhao@10.112.162.60:'+D+'/'],check=True)
for n in ['prepare_native.py','validate_driver.py']:
    subprocess.run(ssh+[R+'/.venv/bin/python',D+'/'+n],check=True)
for n in ['PREDECLARATION.json','DRIVER_PREFLIGHT.json']:
    subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+n,str(F/n)],check=True)
print(json.dumps(dict(status='P07_SCREEN_PREFLIGHT_COMPLETE_NO_NATIVE_STARTED')))
