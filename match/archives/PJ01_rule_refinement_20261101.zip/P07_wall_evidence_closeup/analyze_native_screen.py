from pathlib import Path
import json,datetime
F=Path(__file__).resolve().parent;A=F/'FINAL';P=F.parent/'P06_baseline_causal_diagnosis'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
assert read(A/'CAMPAIGN_CLIENT_REVIEW.json')['status']=='PASS'
assert not read(A/'CAMPAIGN_CLIENT_REVIEW.json')['native_failure']
assert read(A/'OBS_A/CLIENT_FIRST_RAW_REVIEW.json')['status']=='PASS'
d=read(A/'OBS_A/MECHANISM_REVIEW.json');b=read(P/'DIAGNOSIS_RESULT.json')
p=d['phase'];mb=p['map_breakdown']
changes=dict(map=p['score_map']-b['map_score'],wall=p['score_wall']-b['wall_score'],time=p['score_time']-b['time_score'],
    credit_pp=100*mb['credit']-b['map_credit_pp'],false_penalty_pp=100*mb['penalty']-b['map_false_drawing_penalty_pp'])
changes['controlled_weighted_score']=.5*changes['map']+.2*changes['wall']+.1*changes['time']
out=dict(status='REVIEWED_P07_RED_ONLY_SCREEN',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    map_score=p['score_map'],wall_score=p['score_wall'],time_score=p['score_time'],placed=d['placed'],expected=d['expected'],
    steps=d['red_steps'],wall_seconds=d['red_wall_seconds'],RED_wall_clock_hit=d['red_max_walltime_reached'],
    controlled_components_weighted_sum=.5*p['score_map']+.2*p['score_wall']+.1*p['score_time'],
    full_red_score=None,BLUE_runs=0,rank_promoted=False,automatic_five=False,
    delta_vs_previous_independent_PJ01_RED=changes,pass_screen=d['pass_screen'],screen_conditions=d['screen_conditions'],
    image_binding=d['image_binding'],admitted=d['admitted'],completed=d['completed'],all_gate_events=d['events'],
    interpretation='Own rule-stage logs and official publicly exposed scores. Independent unseeded score difference cannot establish a causal effect or stable improvement. Controlled-components sum excludes BLUE20% and is NOT full score.',
    decision='ANALYZE_BEFORE_EXPANSION'if d['pass_screen']else'NO_FIVE_NO_RETRY_ANALYZE_FAILURE')
(A/'REVIEWED_SCREEN_RESULT.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
text=f'''P07 Map02 RED单图已完成并首次Windows原始字节核验PASS，无native错误。
地图{p['score_map']:.8f}、墙体覆盖{p['score_wall']:.8f}、时间{p['score_time']:.4f}、投放{d['placed']}/{d['expected']}，{d['red_steps']}步/{d['red_wall_seconds']:.4f}秒、RED wallhit={d['red_max_walltime_reached']}。
未跑BLUE，完整红分null；可控三项(.5地图+.2墙+.1时间)={out['controlled_components_weighted_sum']:.8f}/80，不得当完整分或五图均分。
与刚完成独立原PJ01诊断差：地图{changes['map']:+.6f}、墙{changes['wall']:+.6f}、时间{changes['time']:+.6f}；地图信用{changes['credit_pp']:+.6f}pp/误绘惩罚{changes['false_penalty_pp']:+.6f}pp。无外部seed，只是观察差，不宣称纯规则因果收益。
实际准入次数{len(d['admitted'])}，2次新扫描写图完成事件{len(d['completed'])}，提交图与公开PNG SHA绑定{d['image_binding']['matches']}。
固定门槛pass={d['pass_screen']}；具体{json.dumps(d['screen_conditions'],ensure_ascii=False)}。
结论{out['decision']}。不自动五图/重跑/换seed；先分析实际阶段与分项。原PJ01仍独立底本，目标保持ACTIVE。
'''
(A/'单图结果与下一步分析.txt').write_text(text,encoding='utf-8')
print(text)
