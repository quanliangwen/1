"""5 actual PJ01 controllers, authored end-of-placement snapshot only.

Four peers start empty; own last1bomb and authored prior own sensing history.
Completion certs must arrive via real SDK communicators. Only initial mission
context is fixed; actual control(), map, messages and placement run unchanged.
Not whole exploration, native maps, BLUE or stable score validation.
"""
from pathlib import Path
from types import SimpleNamespace
import contextlib,io,json,sys,time,hashlib,inspect,fcntl,traceback
import numpy as np
F=Path(__file__).resolve().parent;label,arm=sys.argv[1:]
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
m=json.loads((F/'WORKSPACE_READY.json').read_text())['versions'][arm];W=Path(m['workspace'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(W/n)==h for n,h in m['sources'].items())and all(sha(W/n)==h for n,h in m['sdk_files'].items())
sys.path.insert(0,str(W/'src'))
from swarm_rescue.solutions.my_drone_eval import MyDroneEval
assert Path(inspect.getfile(MyDroneEval)).resolve().is_relative_to(W/'src')
from swarm_rescue.simulation.gui_map.playground import Playground
from swarm_rescue.simulation.gui_map.closed_playground import ClosedPlayground
from swarm_rescue.simulation.elements.normal_wall import NormalWall
from swarm_rescue.simulation.elements.disposal_center import DisposalCenter
from swarm_rescue.simulation.utils.misc_data import MiscData
from swarm_rescue.simulation.reporting.place_score_manager import walls_only_grid
from swarm_rescue.tools.map_exploration_scoring import MapExplorationScorer,breakdown_to_dict

import swarm_rescue.solutions.wall_closeup_mixin as observed_module
from swarm_rescue.solutions.finite_wall_support import from_actual_scan
from swarm_rescue.solutions.completion_consensus import _sortie_known_route
captured=[];original_select=observed_module.select_probe
def trace_select(**kw):
    result=original_select(**kw)
    frozen=dict(kw)
    for k,v in list(frozen.items()):
        if isinstance(v,np.ndarray):frozen[k]=v.copy()
    frozen['result']=result;captured.append(frozen)
    return result
observed_module.select_probe=trace_select

source=(F/'check_admit_original8_v2.py').read_text()
source=source[:source.index('    before=arrays(probe.memory)')]+"    return probe,polys,positions[-1].copy()\n"
space={'__file__':str(F/'check_admit_original8_v2.py')};exec(compile(source,'authored_warmup_fixture','exec'),space)

class OfficialInteractionPlayground(Playground):
    _handle_interactions=ClosedPlayground._handle_interactions
    get_closest_drone=ClosedPlayground.get_closest_drone

def one_case(noisy):
    np.random.seed(615)
    warm,_,physical_start=space['run']('doorway','partial',noisy,621+int(noisy))
    pg=OfficialInteractionPlayground(size=(640,480))
    for a,b in [((-320.,-240.),(320.,-240.)),((320.,-240.),(320.,240.)),
      ((320.,240.),(-320.,240.)),((-320.,240.),(-320.,-240.)),
      ((-260.,100.),(-60.,100.)),((60.,100.),(260.,100.))]:
        wall=NormalWall(a,b);pg.add(wall,wall.wall_coordinates)
    center=DisposalCenter(size=(24,24));pg.add(center,((250.,-170.),0.))
    fixture=SimpleNamespace(disposal_center=center,_bombs=[],_number_bombs=0,playground=pg)
    drones=[];positions=[physical_start,(-250.,-180.),(-220.,-200.),(-120.,-200.),(-80.,-170.)]
    for i,p in enumerate(positions):
        d=MyDroneEval(i,misc_data=MiscData(size_area=(640,480),number_drones=5,max_timestep_limit=2000,max_walltime_limit=90))
        pg.add(d,(tuple(p),0.));d.enable_bomb_deployer(fixture,1 if i==0 else 0);d.set_competition_mode(True);drones.append(d)
    pg.reset();d=drones[0]
    for name in ['memory','pose','heading','heading_initialized','rally','boundary_anchor','frame_records','frame_negative']:
        setattr(d,name,getattr(warm,name))
    d.placement_goal=d.pose.copy();d.assignment_goal=d.pose.copy();d.assignment_inventory=1;d.assignment_since=160
    d.waypoints=[d.pose.copy()];d.last_plan_step=160;d.coverage_ready=True
    initial=d.memory.render().copy();start=time.perf_counter();rows=[];submissions=[];first_bomb=None
    for owner,drone in enumerate(drones):
        original_submit=drone.submit_exploration_map
        def observed_submit(image,owner=owner,drone=drone,original_submit=original_submit):
            submissions.append(dict(owner=owner,step=int(drone.elapsed_timestep),image=image.copy(),
                certificates=dict(drone.completion_certificates),inventory=int(drone.carried_bombs_count())))
            return original_submit(image)
        drone.submit_exploration_map=observed_submit
    try:
        for offset in range(104):
            step=160+offset;commands={};messages={}
            for drone in drones:
                drone.elapsed_timestep=step;drone.elapsed_walltime=time.perf_counter()-start
                commands[drone]=drone.control()
                messages[drone]={drone.communicator:(None,drone.define_message_for_all())}
            pg.step(commands,messages)
            if fixture._bombs and first_bomb is None:first_bomb=np.asarray(fixture._bombs[0].true_position()).copy()
            rows.append(dict(step=step,positions=[list(x.base._pm_body.position)for x in drones],
                health=[x.drone_health for x in drones],inventory=[int(x.carried_bombs_count())for x in drones],
                certs=[dict(x.completion_certificates)for x in drones],received=[len(x.communicator.received_messages)for x in drones],
                gates=[getattr(getattr(x,'_wall_closeup_gate',None),'state',None)for x in drones],
                commands=[commands[x]for x in drones],submitted=[x.submitted for x in drones]))
            if submissions:break
        # All public submitted images frozen before authored truth read.
        truth=walls_only_grid(pg);scorer=MapExplorationScorer();before=scorer.score(truth,initial,0.)
        final=[]
        for s in submissions:
            score=scorer.score(truth,s.pop('image'),0.)
            final.append(dict(**s,map_score=score.score,breakdown=breakdown_to_dict(score)))
        gate=getattr(d,'_wall_closeup_gate',None)
        return dict(noisy_authored_history=noisy,initial_own_map=before.score,submissions=final,
            gate_state=getattr(gate,'state',None),gate_reason=getattr(gate,'reason',None),
            gate_seen=sorted(gate.seen)if gate else[],gate_request=getattr(gate,'probe',None),
            own_witness_captured=getattr(d,'_wall_closeup_pre_place',None)is not None,
            probe_events=getattr(d,'_wall_closeup_events',[]),actual_placement=len(fixture._bombs),
            bomb_displacement=float(np.linalg.norm(np.asarray(fixture._bombs[0].true_position())-first_bomb))if first_bomb is not None else None,
            final_inventory=[int(x.carried_bombs_count())for x in drones],
            five_independent_maps=len({id(x.memory.hits)for x in drones})==5,
            exact_official7_callbacks=type(pg)._handle_interactions is ClosedPlayground._handle_interactions and len(pg.space._handlers)==7,
            min_health=min(min(x['health'])for x in rows),rows=rows,steps=len(rows),seconds=time.perf_counter()-start)
    finally:pg.cleanup();pg.close_window()

dest=F/(label+'.json');assert not dest.exists()
lock=(R/'solver_study/serial_evaluation.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
    with contextlib.redirect_stdout(io.StringIO()):rows=[one_case(False),one_case(True)]
    audits=[]
    for k in captured:
        w=k.get('pre_place_witness');p=np.asarray(k['pose'])
        segments=from_actual_scan(w['pose']if w else p,w['heading']if w else k['heading'],
            w['distances']if w else k['distances'],w['angles']if w else k['angles'],w['excluded']if w else k['excluded'])
        d=np.asarray(w['distances']if w else k['distances']);facts=[]
        for segment in segments:
            wall=.5*(segment['start']+segment['end']);delta=wall-p;distance=float(np.linalg.norm(delta))
            row=int(np.floor(k['height']/2-wall[1]));col=int(np.floor(wall[0]+k['width']/2))
            wanted=p+delta*(distance-190)/max(distance,1e-9)
            source=k['world_to_cell'](p);target=k['world_to_cell'](wanted)
            walk=k['free']&~k['blocked'];band=2*k['cell']
            path=k['route_solver'](source,target,walk,time.perf_counter()+.1)
            facts.append(dict(wall=wall.tolist(),all_original_rays_far=bool(np.all(d[segment['indices']]>=220)),
                range_now=distance,original_ray_min=float(d[segment['indices']].min()),source=source,target=target,
                raw_known_target=bool(k['free'][target]),geometry_blocked_target=bool(k['blocked'][target]),
                existing_wall_pixels_in_band=int(np.count_nonzero(k['parent_image'][max(0,row-band):min(k['height'],row+band+1),max(0,col-band):min(k['width'],col+band+1)])),
                path_exists=path is not None,path=path))
        audits.append(dict(step=k['step'],witness=w is not None,witness_step=w['step']if w else None,
            pose=p.tolist(),result=k['result'],available=min(96,k['remaining']/2,.5*k['limit']-k['step']-24),segments=facts))
    (F/(label+'_ADMISSION_TRACE.json')).write_text(json.dumps(audits,indent=2,default=lambda x:x.item()if isinstance(x,np.generic)else x.tolist())+'\n')
    checks=dict(exact_official_interactions=all(r['exact_official7_callbacks']for r in rows),
        no_damage=all(r['min_health']==50 for r in rows),actual1bomb_each=all(r['actual_placement']==1 for r in rows),
        all_stock_empty=all(r['final_inventory']==[0]*5 for r in rows),all_submit=all(bool(r['submissions'])for r in rows),
        certificates_carried_by_actual_radio=all(any(x['received'][0]>0 and len(x['certs'][0])>=4 for x in r['rows'])for r in rows),
        no_bomb_push=all(r['bomb_displacement']is not None and r['bomb_displacement']<1e-8 for r in rows),
        five_memory_instances=all(r['five_independent_maps']for r in rows))
    if arm=='P07':
        checks.update(actual_pre_drop_capture=all(r['own_witness_captured']for r in rows),
            actual_new_mapped_scans=all(r['gate_reason']=='TWO_FRESH_OWN_SCANS_INCORPORATED'and len(r['gate_seen'])>=2 for r in rows),
            actual_delayed_certificate=all(any(x['gates'][0]=='ACTIVE'and 0 not in x['certs'][0]for x in r['rows'])for r in rows))
    out=dict(status='PASS_ACTUAL_FIVE_CONTROLLER_ENDGAME_ONLY'if all(checks.values())else'FAIL_KEEP_FULL_INTEGRATION_EVIDENCE',
        checks=checks,arm=arm,rows=rows,source_sha256=m['sources'],native_rounds=0,scope=__doc__,
        public_getters_overridden=False,ordinary_controller_control_method_unchanged=True)
    dest.write_text(json.dumps(out,indent=2,default=lambda x:x.item()if isinstance(x,np.generic)else x.tolist())+'\n')
    print(json.dumps(dict(status=out['status'],checks=checks,cases=[{k:v for k,v in r.items()if k not in ['rows','probe_events','gate_request']}for r in rows])))
except Exception:
    (F/(label+'_ERROR.txt')).write_text(traceback.format_exc());raise
finally:fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
