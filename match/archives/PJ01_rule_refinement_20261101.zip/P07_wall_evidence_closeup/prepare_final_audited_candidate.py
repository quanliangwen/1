from pathlib import Path
import shutil,hashlib,json,ast
F=Path(__file__).resolve().parent;V=F/'V3';A=F/'FINAL';assert not A.exists();A.mkdir()
assert json.loads((V/'FULL_SDK_P07_V3_FIRST.json').read_text())['status']=='PASS_ACTUAL_FIVE_CONTROLLER_ENDGAME_ONLY'
C=A/'candidate_project';shutil.copytree(V/'candidate_project',C,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
p=C/'src/swarm_rescue/solutions/wall_closeup_mixin.py';s=p.read_text().replace('import json,time','import json,time,hashlib')
marker='    def _maybe_place(self,command,step,semantic):'
method='''    def submit_exploration_map(self,image):
        view=np.asarray(image)
        self._wall_closeup_log('SUBMIT_IMAGE',shape=list(view.shape),dtype=str(view.dtype),
            sha256=hashlib.sha256(view.tobytes()).hexdigest(),inventory=int(self.carried_bombs_count()),
            certificate_owners=sorted(self.completion_certificates))
        return super().submit_exploration_map(image)

'''
assert s.count(marker)==1;p.write_text(s.replace(marker,method+marker),encoding='utf-8')
for p in(C/'src/swarm_rescue/solutions').glob('*.py'):ast.parse(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((V/'CANDIDATE_MANIFEST.json').read_text());m['files']={p.relative_to(C).as_posix():sha(p)for p in C.rglob('*')if p.is_file()}
m['status']='PJ01_PLUS_ONE_CLOSEUP_RULE_AND_READONLY_SUBMIT_SHA_PENDING_CHECK'
m['audit_only_change']='Before original submit API, hash the same original array and log owner/dtype/shape. Delegate unchanged object exactly once. No mapping, rule, route, message or clock change versus V3.'
(A/'CANDIDATE_MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n')
for n in ['qualify_arm.py','check_full_sdk_closeup.py','check_admit_original8_v2.py','finite_wall_support.py','wall_probe_reference.py','check_actual_original8.py','check_actual_complete4.py','check_witness_contract.py','check_gate.py']:
    shutil.copy2(V/n,A/n)
s=(V/'prepare_server.py').read_text().replace('pj01_rules_wall_closeup_v3_20261101','pj01_rules_wall_closeup_final_20261101')
(A/'prepare_server.py').write_text(s,encoding='utf-8')
note=dict(scope='Same V3 algorithm plus read-only submission SHA audit for binding actual publicPNG to owner. Requalify before any native.',
    v3_authored_closedloop_map_delta=[.6468646720803548,.3847241795102434],actual_radio=True,actual1bomb=True,own_fresh_mapped_scans=[168,172],own_certificate_released=172,original_submit=161,
    original8_countercheck_admitted=2,complete4_admitted=0,negative_controls=96,witness_contract_checks=22,gate_contract_checks=21,
    limitations='Authored partial room only, not original5maps; false-drawing cost increased but added recall outweighed it in both. No broad denoising/unknown filling or full map guarantee.',
    next_native_scope='Only original-condition Map02RED1native after final qualification. No automaticBLUE or five, fixed score/map/inventory/time gates and first byte review.')
(A/'PRE_NATIVE_EVIDENCE.json').write_text(json.dumps(note,indent=2)+'\n')
print(json.dumps(note))
