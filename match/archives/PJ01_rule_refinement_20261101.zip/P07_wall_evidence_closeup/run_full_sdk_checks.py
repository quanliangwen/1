from pathlib import Path
import subprocess,json
F=Path(__file__).resolve().parent
R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P07_wall_closeup_20261101'
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
declaration=dict(scope='Authored end-of-placement 5real controllers/real communicators/official7callbacks; actual original and P07 SDK source arms, each clean/noisy prior own-history2cases. Fixed authored seed615, no official native.',
 tests='Each real1bomb/empty5stocks/real message completion/actual submit/bomb stays/health. P07 captured actual pre-last-place scan, own cert withheld until2new written scans. Compare actual submitted map to original fixture afterwards, not native rank.',
 controls='Original low-level control(), own sensor getters, SDK/dependencies unchanged. Only initial fixture mission context: one last legal current-position target, other4empty, own prior author-sensing memory.',
 continue_if='No integration error; all safety/actual-stage checks pass, same authored map improves in both, then independent additional negatives before native.')
(F/'FULL_SDK_PREDECLARATION.json').write_text(json.dumps(declaration,indent=2)+'\n')
subprocess.run(ssh+[R+'/.venv/bin/python',H+'/R154_scoped_serial_guard_20261101/check_scoped_serial.py'],check=True)
for n in ['check_full_sdk_closeup.py','FULL_SDK_PREDECLARATION.json']:
    subprocess.run(['scp','-q',str(F/n),'junhao@10.112.162.60:'+D+'/'],check=True)
for arm in ['PJ01','P07']:
    label='FULL_SDK_'+arm+'_FIRST'
    run=subprocess.run(ssh+[R+'/.venv/bin/python',H+'/run_sdk_captured.py',D+'/check_full_sdk_closeup.py',label,arm],capture_output=True,text=True)
    (F/(label+'.capture.txt')).write_text(run.stdout+run.stderr,encoding='utf-8');print(run.stdout);print(run.stderr)
    if run.returncode:raise SystemExit(run.returncode)
    subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+label+'.json',str(F/(label+'.json'))],check=True)
