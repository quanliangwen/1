from pathlib import Path
import datetime,json,subprocess
F=Path(__file__).resolve().parent;A=F/'FINAL';d=json.loads((A/'REVIEWED_SCREEN_RESULT.json').read_text());now=datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not d['pass_screen']and not d['admitted']
note=f'''LATEST COMPLETE {now}: P07/FINAL已全部结束，不恢复原2176730/start397965283或Windows96516。9raw首次Windows/CAMPAIGN PASS，无native失败。Map02 RED图96.3040374177、墙82.8744540919、时间100、10/10、1274步86.216738秒、无RED wallhit；没有BLUE，完整红分null。公开PNG与0号提交图SHA b4ade01f4fb81b2874ba2d0e100c0dbb9aa3de4aac2efff488ec2220a4fd3989唯一匹配。对P06独立观察图+.816937/墙+11.353162，但0次补扫准入、0次新扫描补扫完成，不能算规则改善。事前机制门槛失败，不五图、不晋级、不重跑。
实际未触发原因已经由己方日志定位：4号986、1号1048、2号1094、3号1113、0号1170步分别空载时，都还没有收到其余4机全部完成证书，因此各自OTHER_TEAM_WORK_NOT_CERTIFIED永久SKIPPED。0号虽是本局最后投完者，它在1170仍缺队友完成消息；到1274真正收齐已持自己的证书，不可撤回。故不是已经证明没有可扫墙或路线/预算拒绝，而是所有实例都在几何准入前被通信/资格条件挡住。余量1262..1504步，排除这个分支的直接预算不足。自己库存清空≠自己实时知道全队都完成；上一P06最后2号恰好已有其他证书，并非通用时间规律。
下一研究P08_empty_drone_wall_probe（尚未建立/接入/原生）：不要再等“收到全队其他完成证书”才第一次检查自己墙面证据，改为自己真实库存清空时只做一次有界局部补扫评估。别撤回已发证书或让多个空载机互等，保留消息库存真值/原空载协调者服务。因为其他人可能仍在布点，必须额外保留已知回集合点路径预算、未观测路线拒绝、任务服务与时间保护。原PJ01独立底本，仍只一条墙面补扫规则，不叠P02/P03/P05/P07失败门。
先实际SDK小检查：其他机仍携弹时的本机补扫/真实无线库存与证书，所有机同时清空的无死锁有界截止，已知返回路径/预算不足拒绝，近完整图拒绝，原布点/运动仍有效；再决定是否有希望建独立candidate/单图。不能为了触发直接删除资格分支并跑五图，也不能从本次分数上涨推断有效。
F48/J05有界前期融合旧成绩不能当当前地图改善证据；P07此前作者场景的+.646865/+.384724只说明局部机制可行，不能覆盖本次真实资格失败。所有首次错误与完整原生记录保留。
目标保持ACTIVE，离线接续90仍启用。原SDK e2f022b/team006/时限线程和CPU<=60/loadcore<=.4/RAM8GiB/盘12GiB/两样本60秒，不恢复旧高负载授权，不反序列化NPZ/pickle/真图/BLUE私态。正式包不改。用户停止立即暂停。
'''
for p in [F/'WORKING_HANDOFF_P07.txt',F/'分析依据与小检查结论.txt',A/'WORKING_HANDOFF_P07_FINAL.txt']:
    with p.open('a',encoding='utf-8')as h:h.write('\n'+note)
(A/'P07_NOT_PROMOTED.txt').write_text(note,encoding='utf-8')
idx=Path('E:/codex/swarm-eod-literature-analysis/CURRENT_ACTIVE_ANALYSIS.txt');idx.write_text(note+'\nHISTORY\n'+idx.read_text(encoding='utf-8'),encoding='utf-8')
(F/'AUTOMATION_PROMPT.txt').write_text('继续用户明确ACTIVE的原PJ01地图精度优先持续目标，直到用户停止。先读E:/codex/AGENTS.md、E:/codex/swarm-eod-literature-analysis/CURRENT_ACTIVE_ANALYSIS.txt与E:/codex/PJ01_rule_refinement_20261101/P07_wall_evidence_closeup/WORKING_HANDOFF_P07.txt最新追加及可能新建的P08目录/交接。每次实质分析与必要小测试，不只轮询COMPLETE；原PJ01独立底本，一次一条旧有用规则，有希望才单图、真实改善才五图，不重跑救分、不自行完成或暂停。\n\n'+note,encoding='utf-8')
print(json.dumps(dict(status='P07_REJECTED_NATIVE_QUALIFICATION_NEVER_ADMITTED',next='P08_bounded_empty_own_wall_probe_analysis')))
