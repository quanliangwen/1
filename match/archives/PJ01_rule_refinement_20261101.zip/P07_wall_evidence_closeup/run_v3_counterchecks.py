from pathlib import Path
import subprocess
F=Path(__file__).resolve().parent/'V3';R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P07_wall_closeup_20261101/V3'
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
subprocess.run(ssh+[R+'/.venv/bin/python',H+'/R154_scoped_serial_guard_20261101/check_scoped_serial.py'],check=True)
for script,label,output in [('check_actual_original8.py','V3_ORIGINAL8_FIRST','V3_ORIGINAL8_FIRST.json'),('check_actual_complete4.py','V3_COMPLETE4_FIRST','V3_COMPLETE4_FIRST.json'),('check_witness_contract.py','V3_WITNESS_FIRST','WITNESS_CONTRACT_V3_FIRST.json'),('check_gate.py','V3_GATE_FIRST','GATE_V3_FIRST.json')]:
    subprocess.run(['scp','-q',str(F/script),'junhao@10.112.162.60:'+D+'/'],check=True)
    run=subprocess.run(ssh+[R+'/.venv/bin/python',H+'/run_sdk_captured.py',D+'/'+script,label],capture_output=True,text=True)
    (F/(label+'.capture.txt')).write_text(run.stdout+run.stderr,encoding='utf-8');print(run.stdout);print(run.stderr)
    if run.returncode:raise SystemExit(run.returncode)
    subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+output,str(F/output)],check=True)
