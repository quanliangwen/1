from pathlib import Path
import subprocess,json,datetime
F=Path(__file__).resolve().parent
R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025'
D=H+'/PJ01_rules_P07_wall_closeup_20261101'
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
pre=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='4 authored motion-layer cases only, not production integration/native',
    cases='same original doorway partial clean/noisy history each without bomb and after real1bomb drop',
    controls='Original PJ01 pose/map/drive, SDK public getters not overridden, exact7 official interaction callbacks, <=96 live steps. Gate receives controlled all-other-certificates=True.',
    tests='Actual near scan mapped2epochs, real displacement, map nonregression and at least one>=.5gain, no health loss, no bomb movement, empty inventory.',
    no_native_seed_or_competition_maps=True,truth_read='authored walls only after initial/final images frozen')
(F/'PHYSICAL_PREDECLARATION.json').write_text(json.dumps(pre,indent=2)+'\n',encoding='utf-8')
subprocess.run(ssh+[R+'/.venv/bin/python',H+'/R154_scoped_serial_guard_20261101/check_scoped_serial.py'],check=True)
for n in ['PHYSICAL_PREDECLARATION.json','check_physical_reference.py']:
    subprocess.run(['scp','-q',str(F/n),'junhao@10.112.162.60:'+D+'/'],check=True)
label='PHYSICAL_REFERENCE_FIRST'
run=subprocess.run(ssh+[R+'/.venv/bin/python',H+'/run_sdk_captured.py',D+'/check_physical_reference.py',label],capture_output=True,text=True)
(F/(label+'.capture.txt')).write_text(run.stdout+run.stderr,encoding='utf-8');print(run.stdout);print(run.stderr)
if run.returncode:raise SystemExit(run.returncode)
subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+label+'.json',str(F/(label+'.json'))],check=True)
