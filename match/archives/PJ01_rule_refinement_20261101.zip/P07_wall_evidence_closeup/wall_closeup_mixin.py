"""One finite own-wall closeup before the last inventory certificate.

No new message schema, mapper, placement objective or low-level controller.
Only own public sensors and actually received completion certificates are used.
"""
import json,time
import numpy as np
from swarm_rescue.solutions.wall_probe_reference import select_probe,scan_matches,LastCertificateGate
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
from swarm_rescue.solutions.completion_consensus import _sortie_known_route

class WallCloseupMixin:
    def __init__(self,identifier=None,misc_data=None,**kwargs):
        super().__init__(identifier=identifier,misc_data=misc_data,**kwargs)
        self._wall_closeup_gate=LastCertificateGate()
        self._wall_closeup_pose_step=None
        self._wall_closeup_pre_place=None
        self._wall_closeup_events=[]

    @property
    def _wall_closeup_motion(self):return self._wall_closeup_gate.active

    def _wall_closeup_log(self,event,**fields):
        row=dict(event=event,owner=int(self.identifier or 0),step=int(self.elapsed_timestep),**fields)
        self._wall_closeup_events.append(row)
        print('[WALL_CLOSEUP] '+json.dumps(row),flush=True)

    def _maybe_place(self,command,step,semantic):
        super()._maybe_place(command,step,semantic)
        if command.get('place_bomb')!=1 or int(self.carried_bombs_count())!=1 or self.pose is None:return
        distances=self.lidar_values()
        if distances is None:return
        d=np.asarray(distances,float);a=np.asarray(self.lidar_rays_angles(),float)
        if d.ndim!=1 or a.shape!=d.shape:return
        self._wall_closeup_pre_place=dict(step=int(step),pose=self.pose.copy(),heading=float(self.heading),
            distances=d.copy(),angles=a.copy(),excluded=self.memory.semantic_mask(d,a,semantic).copy())

    def _update_pose(self):
        super()._update_pose()
        step=int(self.elapsed_timestep)
        if self.pose is None:return
        self._wall_closeup_pose_step=step
        if not self._wall_closeup_gate.active or step%4:return
        distances=self.lidar_values()
        if distances is None:return
        angles=np.asarray(self.lidar_rays_angles(),float)
        matches=scan_matches(pose=self.pose,heading=self.heading,distances=distances,angles=angles,
            excluded=self.memory.semantic_mask(distances,angles,self.semantic_values()),
            wall=self._wall_closeup_gate.probe['wall'])
        self._wall_closeup_gate.record_own_scan(epoch=step,now=step,matches=matches)

    def _wall_closeup_admit(self,step):
        distances=self.lidar_values()
        if distances is None:return None
        angles=np.asarray(self.lidar_rays_angles(),float)
        geometry=GeometryPlanningMemory(self.memory)
        parent=self.memory.render()
        deadline=time.perf_counter()+.05
        def route_solver(s,t,walkable,until):
            return _sortie_known_route(self.memory,s,t,walkable,until,max_pops=2048)
        args=dict(pose=self.pose,heading=self.heading,distances=distances,angles=angles,
            excluded=self.memory.semantic_mask(distances,angles,self.semantic_values()),parent_image=parent,
            free=self.memory.free,blocked=geometry.blocked(),width=self.memory.width,height=self.memory.height,
            cell=self.memory.CELL,fine=self.memory.FINE,world_to_cell=self.memory.world_to_cell,
            cell_to_world=self.memory.cell_to_world,route_solver=route_solver,
            remaining=float(self._remaining_steps()),step=int(step),limit=self.limit,deadline=deadline)
        request=select_probe(**args)
        source='CURRENT_OWN_SCAN'
        if request is None and self._wall_closeup_pre_place is not None:
            request=select_probe(**args,pre_place_witness=self._wall_closeup_pre_place)
            source='OWN_PRE_FINAL_PLACE_SCAN'
        if request is not None:
            request['evidence_source']=source
            self.last_plan_step=-1000
        return request

    def _record_own_completion(self,step):
        gate=self._wall_closeup_gate;own=int(self.identifier or 0)
        before=gate.state
        allow=gate.allow_parent(step=int(step),inventory=int(self.carried_bombs_count()),
            own_certified=own in self.completion_certificates,
            other_certificates_complete=all(j in self.completion_certificates for j in range(self.team_size)if j!=own),
            pose_fresh=self._wall_closeup_pose_step==int(step),remaining=float(self._remaining_steps()),
            own_map_observed_epoch=getattr(self.memory,'_bearing_frame_step',None)or -1,
            admit=lambda:self._wall_closeup_admit(step))
        if gate.state!=before:
            self._wall_closeup_log('GATE_STATE',before=before,state=gate.state,reason=gate.reason,
                request=gate.probe,own_mapped_epoch=getattr(self.memory,'_bearing_frame_step',None),
                near_scan_epochs=sorted(gate.seen),remaining=float(self._remaining_steps()))
        if allow:return super()._record_own_completion(step)

    def _sortie_can_depart(self,step):
        if self._wall_closeup_gate.state in ('WAIT_ADMISSION','ACTIVE'):return False
        return super()._sortie_can_depart(step)

    def _plan_route(self,step,returning,peer_goals):
        gate=self._wall_closeup_gate
        if gate.active:
            # Retain original empty-coordinator service; no new fleet objective.
            self._build_fleet_plan(step)
            self.placement_goal=None
            walk=self.memory.free&~GeometryPlanningMemory(self.memory).blocked()
            cells=_sortie_known_route(self.memory,self.memory.world_to_cell(self.pose),
                self.memory.world_to_cell(gate.probe['goal']),walk,time.perf_counter()+.05,max_pops=2048)
            if cells is not None:
                goal=np.asarray(gate.probe['goal'],float)
                return [self.memory.cell_to_world(c)for c in cells[1:]]or[goal.copy()],goal.copy()
            gate.abort('LIVE_KNOWN_ROUTE_LOST')
            self._wall_closeup_log('ROUTE_ABSTENTION',reason=gate.reason)
        return super()._plan_route(step,returning,peer_goals)
