from pathlib import Path
import hashlib,json,subprocess,shutil,ast
F=Path(__file__).resolve().parent;C=F/'candidate_project'
assert not(F/'WORKSPACE_READY.json').exists()
# Still unqualified/unfrozen: fix positional-constructor support before SDK entry.
shutil.copy2(F/'CANDIDATE_MANIFEST.json',F/'CANDIDATE_MANIFEST_BEFORE_CONSTRUCTOR_FIX.json')
shutil.copy2(F/'wall_closeup_mixin.py',C/'src/swarm_rescue/solutions/wall_closeup_mixin.py')
for p in(C/'src/swarm_rescue/solutions').glob('*.py'):ast.parse(p.read_text(encoding='utf-8-sig'))
m=json.loads((F/'CANDIDATE_MANIFEST.json').read_text());m['files']={p.relative_to(C).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in C.rglob('*')if p.is_file()}
(F/'CANDIDATE_MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n')
R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P07_wall_closeup_20261101'
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
subprocess.run(ssh+[R+'/.venv/bin/python',H+'/R154_scoped_serial_guard_20261101/check_scoped_serial.py'],check=True)
for n in ['candidate_project','CANDIDATE_MANIFEST.json','prepare_server.py']:
    subprocess.run(['scp','-q','-r',str(F/n),'junhao@10.112.162.60:'+D+'/'],check=True)
subprocess.run(['scp','-q',str(F.parent/'P02_proven_endpoint_rule/qualify_arm.py'),'junhao@10.112.162.60:'+D+'/qualify_arm.py'],check=True)
subprocess.run(ssh+[R+'/.venv/bin/python',D+'/prepare_server.py'],check=True)
subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/WORKSPACE_READY.json',str(F/'WORKSPACE_READY.json')],check=True)
label='ENTRY_P07_FIRST';run=subprocess.run(ssh+[R+'/.venv/bin/python',H+'/run_sdk_captured.py',D+'/qualify_arm.py',label,'P07'],capture_output=True,text=True)
(F/(label+'.capture.txt')).write_text(run.stdout+run.stderr,encoding='utf-8');print(run.stdout);print(run.stderr)
if run.returncode:raise SystemExit(run.returncode)
subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+label+'.json',str(F/(label+'.json'))],check=True)
