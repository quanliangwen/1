from pathlib import Path
import json,shutil,hashlib
F=Path(__file__).resolve().parent;H=F.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((H/'PJ01_rules_P03_pose_20261101/WORKSPACE_READY.json').read_text())['versions']['PJ01'];B=Path(b['workspace'])
assert all(sha(B/n)==h for n,h in b['sources'].items())and all(sha(B/n)==h for n,h in b['sdk_files'].items())
m=json.loads((F/'CANDIDATE_MANIFEST.json').read_text());C=F/'candidate_project'
assert all(sha(C/n)==h for n,h in m['files'].items())
W=B.parent/'pj01_rules_wall_closeup_20261101';assert not W.exists()
shutil.copytree(B,W,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git'))
for n in m['changed_files']:shutil.copy2(C/n,W/n)
files={p.relative_to(W).as_posix():sha(p)for p in(W/'src/swarm_rescue/solutions').iterdir()if p.is_file()};files['req.txt']=sha(W/'req.txt')
assert sorted(n for n,h in files.items()if b['sources'].get(n)!=h)==m['changed_files']
assert all(sha(W/n)==h for n,h in b['sdk_files'].items())
out=dict(status='PREPARED_PJ01_PLUS_ONE_BOUNDED_WALL_CLOSEUP_RULE',versions={'PJ01':b,'P07':dict(workspace=str(W),sources=files,sdk_files=b['sdk_files'])},
 changed_files=m['changed_files'],authorization='User active originalPJ01 one-rule tests. Only bounded before-last-certificate own-wall closeup, no P02/P03/P05, unchanged native SDK/resources/deps. Full integration qualification pending.',official_submission_created=False)
(F/'WORKSPACE_READY.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status=out['status'],workspace=str(W))))
