from pathlib import Path
import json,hashlib
F=Path(__file__).resolve().parent
s=(F/'wall_probe_reference.py').read_text()
s=s.replace('remaining,step,limit,deadline=None):','remaining,step,limit,deadline=None,pre_place_witness=None):')
s=s.replace('segments=from_actual_scan(position,float(heading),distances,angles,excluded)', '''if pre_place_witness is None:
        witness_position=position;witness_heading=heading
        witness_distances=distances;witness_angles=angles;witness_excluded=excluded
    else:
        witness=pre_place_witness
        epoch=witness.get('step')
        if type(epoch)is not int or not 0<=int(step)-epoch<=24:return None
        witness_position=np.asarray(witness['pose'],float)
        witness_heading=witness['heading'];witness_distances=witness['distances']
        witness_angles=witness['angles'];witness_excluded=witness['excluded']
        if witness_position.shape!=(2,)or not np.isfinite(witness_position).all():return None
    segments=from_actual_scan(witness_position,float(witness_heading),witness_distances,witness_angles,witness_excluded)''')
s=s.replace('d=np.asarray(distances,float)','d=np.asarray(witness_distances,float)',1)
out=F/'wall_probe_reference_v2.py';assert not out.exists();out.write_text(s,encoding='utf-8')
s=(F/'check_physical_reference.py').read_text()
s=s.replace('from wall_probe_reference import select_probe,scan_matches,LastCertificateGate','from wall_probe_reference_v2 import select_probe,scan_matches,LastCertificateGate')
s=s.replace('if with_bomb:\n            command=', '''pre_place_witness=None
        if with_bomb:
            d.elapsed_timestep=159;d.elapsed_walltime=0.
            d._update_pose()
            before_ranges=np.asarray(d.lidar_values(),float).copy()
            before_angles=np.asarray(d.lidar_rays_angles(),float).copy()
            pre_place_witness=dict(step=159,pose=d.pose.copy(),heading=d.heading,
                distances=before_ranges,angles=before_angles,
                excluded=d.memory.semantic_mask(before_ranges,before_angles,d.semantic_values()))
            command=''')
s=s.replace('deadline=time.perf_counter()+.1)','deadline=time.perf_counter()+.1,pre_place_witness=pre_place_witness)')
s=s.replace("admission=admission,reason=gate.reason", "pre_place_actual_sdk_witness=pre_place_witness is not None,admission=admission,reason=gate.reason")
out=F/'check_physical_witness_v2.py';assert not out.exists();out.write_text(s,encoding='utf-8')
declaration=dict(status='REFERENCE_ONLY',first_physical_failure='Freshly dropped actual bomb occludes live rays. Both no-bomb closeups passed own2mappedscans, with-bomb both abstained.',
    change='At most24step own real observation immediately before final place request may support the target. No fabricated range replacement or new low-level drive. Completion still needs2distinct new near scans already mapped.',
    same_cases='Original4 authored motion-layer fixtures unchanged except actual pre-drop SDK scan capture, fixed authored seeds.',
    controls='Expired/future/malformed witness and semantic-only/unknown/blocked/budget tests next; physical test same predeclared checks.',
    original_source_sha256=hashlib.sha256((F/'wall_probe_reference.py').read_bytes()).hexdigest(),
    native_rounds=0,controller_integrated=False)
(F/'WITNESS_V2_PREDECLARATION.json').write_text(json.dumps(declaration,indent=2)+'\n')
print(json.dumps(declaration))
