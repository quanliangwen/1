from pathlib import Path
import shutil,json,hashlib,ast
F=Path(__file__).resolve().parent;V=F/'V3';assert not V.exists();V.mkdir()
C=V/'candidate_project';shutil.copytree(F/'candidate_project',C,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
p=C/'src/swarm_rescue/solutions/wall_probe_reference.py';s=p.read_text()
old='if np.any(d[ids]<220.):continue';new='if np.count_nonzero(d[ids]>=220.)<6:continue'
assert s.count(old)==1;p.write_text(s.replace(old,new),encoding='utf-8')
for p in(C/'src/swarm_rescue/solutions').glob('*.py'):ast.parse(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((F/'CANDIDATE_MANIFEST.json').read_text());m['files']={p.relative_to(C).as_posix():sha(p)for p in C.rglob('*')if p.is_file()}
m['status']='P07_V3_MIN6_FAR_SUPPORT_NOT_ALL_RAYS_CANDIDATE_UNQUALIFIED'
m['reason']='Full5controller trace: actual220px guard rejects unsupported feasible target because1ray is219.636px. Keep actual220 threshold, require>=6measured far rays on finiteTLS segment and empty32px target-image support.'
(V/'CANDIDATE_MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n')
for n in ['qualify_arm.py','check_full_sdk_closeup.py','check_admit_original8_v2.py']:
    src=F/n if(F/n).exists()else F.parent/'P02_proven_endpoint_rule'/n
    shutil.copy2(src,V/n)
# Authored warmup import uses this old pure helper, not production selector.
for n in ['finite_wall_support.py','wall_probe_reference.py']:shutil.copy2(F/n,V/n)
s=(F/'prepare_server.py').read_text().replace('F=Path(__file__).resolve().parent;H=F.parent;',"F=Path(__file__).resolve().parent;H=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025');")
s=s.replace("'pj01_rules_wall_closeup_20261101'","'pj01_rules_wall_closeup_v3_20261101'")
(V/'prepare_server.py').write_text(s)
note=dict(first_full5_failure='Both valid far walls rejected due1originalray219.6364297<220 though currentsegmentcenter236/229px, rawknownroute exists, parentimagebandempty. Actual radio/drop safe, but no closeup or map gain.',
    v3_single_change='Require>=6actual>=220px rays, not all segment rays; unchanged TLS40px/residual8, center220..280, empty32px image band, knownfree Astar, budgets/near2mappedframes.',
    before_native='Requalify source/SDK ABI/full5controllers, additional refusal/completion checks. Not a rerun of any native score.',
    no_native_queue=True)
(V/'ANALYSIS_AND_PREDECLARATION.json').write_text(json.dumps(note,indent=2)+'\n')
print(json.dumps(note))
