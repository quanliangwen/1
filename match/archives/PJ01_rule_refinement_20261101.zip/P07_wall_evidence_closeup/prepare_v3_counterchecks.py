from pathlib import Path
F=Path(__file__).resolve().parent;V=F/'V3'
for src,target in [('check_admit_original8_v2.py','check_actual_original8.py'),('check_admit_complete4.py','check_actual_complete4.py')]:
    s=(F/src).read_text()
    s=s.replace("m=json.loads((H/'PJ01_rules_P03_pose_20261101/WORKSPACE_READY.json').read_text())['versions']['PJ01']", "m=json.loads((F/'WORKSPACE_READY.json').read_text())['versions']['P07']")
    s=s.replace('from wall_probe_reference import select_probe','from swarm_rescue.solutions.wall_probe_reference import select_probe')
    # Complete4 original never ran before V2 fix; fix same variable shadow only.
    s=s.replace("walk=probe.memory.free&~geometry.blocked();path=request['path']","walk=probe.memory.free&~geometry.blocked();probe_path=request['path']")
    s=s.replace('for c in path[1:]','for c in probe_path[1:]').replace('zip(path,path[1:])','zip(probe_path,probe_path[1:])')
    (V/target).write_text(s,encoding='utf-8')
prefix="import sys,json\nfrom pathlib import Path\n_F=Path(__file__).resolve().parent\n_w=json.loads((_F/'WORKSPACE_READY.json').read_text())['versions']['P07']['workspace']\nsys.path.insert(0,str(Path(_w)/'src'))\n"
s=(F/'check_witness_contract_v2.py').read_text().replace('from wall_probe_reference_v2 import select_probe','from swarm_rescue.solutions.wall_probe_reference import select_probe').replace('WITNESS_CONTRACT_V2.json','WITNESS_CONTRACT_V3_FIRST.json')
(V/'check_witness_contract.py').write_text(prefix+s,encoding='utf-8')
s=(F/'check_gate.py').read_text().replace('from wall_probe_reference import LastCertificateGate,scan_matches','from swarm_rescue.solutions.wall_probe_reference import LastCertificateGate,scan_matches').replace('GATE_CHECK_FIRST.json','GATE_V3_FIRST.json')
(V/'check_gate.py').write_text(prefix+s,encoding='utf-8')
