from pathlib import Path
import json,datetime
F=Path(__file__).resolve().parent;P=F.parent/'P06_baseline_causal_diagnosis'
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
text=f'''最新UTC {now}：目标ACTIVE，当前P07墙面证据补扫，小检查阶段。没有原生队列，不重启旧P06。

P06原PJ01只读诊断已完成，OBS_A共9raw首次Windows及CAMPAIGN PASS，原生错误False。
Map02红队单局：地图95.4871008172、墙体覆盖71.5212925722、时间100、投放10/10，1453步116.4374099秒，无RED墙钟hit。未跑BLUE，完整红分null，不作为新版排名。
公开PNG按0/255逆编码到原提交0/1数组后，SHA与2号唯一提交图完全相同。该机是在库存0、收到其余4机完成证书并记录自身证书后提交，余量541.433步，known=.9988304、map来源5、合包1445次。本次不是直接预算耗尽，但不能回溯解释上一P05库存9/10。
地图信用97.58325965，缺墙损失2.41674035pp，误绘惩罚2.09615883pp。已知自由面积接近100%不等于墙面准确。
重要观测局限：只有提交者2号输出PROFILE_FINAL，控制16.2963秒；其余4机最终profile缺失。因此116.4374减16.2963剩100.1411秒包括未记录的4机控制器与SDK/报告，绝不是已测SDK-only开销，未确定全队瓶颈。其他4机due采样日志已在845步耗尽，不把最后采样库存2当终局库存；实际10/10与完成证书为终局证据。
原首版DIAGNOSIS_RESULT保留，修正profile观测范围的新版文件已写，未重跑比赛。

P07为什么尝试：原PJ01空载SORTIE面向未知自由边界；最后一个库存清空后会立即发完成证书，可能在有余量时结束。P04旧有限墙段规则同输入有改善但重拟合反例严重，P05薄并集又整体失败。因此先验证靠近真实观测到、原图未解释的远墙，而不是再改渲染器或复制失败规则。
仅参考原PJ01已有效模块：远墙有限段TLS证据、原220px写图范围、原190px边界观察距离、原已知自由网格A*。只允许最后一个尚无自己证书且已收到其余4机实际证书的空载机一次机会。总额<=96步、<=预测余量一半、距时间满分边界留24步。无证据/未知/阻塞/不可达/超时则保留原流程。不加入地图坐标/比赛真图/BLUE私态。
参考完成门：不是到点即成功，必须两次新的近距离实际墙扫描，并且各自已经写入本机memory，才释放自己完成证书；断联/超时/预算耗尽有界放行，不撤回已发证书。21项纯状态契约PASS。
ADMIT_ORIGINAL8_FIRST测试夹具出现path局部变量遮蔽函数名的UnboundLocalError；原源码/输出保留，只修夹具probe_path变量，未改规则，未进入正式native。
V2实际原PJ01 pose/frame/Memory/render/GeometryPlanningMemory/继承A*检查：原8案例中仅doorway_partial_clean与noise两例准入，路线44.50/40.22px，预计71/69步；其他6例不触发。完整4反例全部不触发；每例8个负控均拒绝，共96负控，无原memory数组变化。所有0物理步/0native，不能称真实移动/写图或提分通过。
下一实质步骤：实际冻结SDK、官方7交互回调的作者场景闭环，验证原运动执行、两次近墙扫描实际写图、有限完成，并检查运动是否推移刚投弹药。当前只有wall_probe_reference.py与小检查，尚无生产候选/实际工程/比赛队列。不要根据static PASS直接五图。
若原运动或地图重绘反例不通过，保留失败，先分析不强行集成。只有有希望才从原PJ01独立底本集成一条逻辑规则、实际SDK接口和原资源单图，然后据改善决定五图。

原P06 coordinator2141472/start397784477及Windowscollector97476已结束，P05/P03/P02也结束，不凭旧PID操作。只本聊天单一调度，SDK前核scoped guard/实际/proc/锁registry，等待队列也占用，不动其他CCMCKP任务。
原资源CPU<=60/loadcore<=.4/RAM8GiB/盘12GiB/两样本60秒，SDK e2f022b/team006/原线程时限/无externalSeed；高负载授权耗尽。NPZ/pickle不反序列化，仅不透明字节SHA，每组首次Windows一次，不读BLUE私态或竞赛真图。作者truth仅冻结输出后评分，不能当五图分数。
保持ACTIVE持续实质分析，90分钟仅接续唤醒，不强制盲跑五图；旧C7取消。正式V06/V07/V08不变不自动发布。用户新停止立即暂停。
'''
(F/'分析依据与小检查结论.txt').write_text(text,encoding='utf-8')
(F/'WORKING_HANDOFF_P07.txt').write_text(text,encoding='utf-8')
with(P/'WORKING_HANDOFF_P06.txt').open('a',encoding='utf-8')as h:h.write('\nLATEST COMPLETE (supersedes RUNNING):\n'+text)
idx=Path('E:/codex/swarm-eod-literature-analysis/CURRENT_ACTIVE_ANALYSIS.txt')
old=idx.read_text(encoding='utf-8');idx.write_text(text+'\n\nHISTORY:\n'+old,encoding='utf-8')
(F/'AUTOMATION_PROMPT.txt').write_text('继续用户明确ACTIVE的原PJ01地图精度优先持续目标，直到用户停止。先读E:/codex/AGENTS.md、E:/codex/swarm-eod-literature-analysis/CURRENT_ACTIVE_ANALYSIS.txt与E:/codex/PJ01_rule_refinement_20261101/P07_wall_evidence_closeup/WORKING_HANDOFF_P07.txt及最新结果，实际文件覆盖旧状态。\n\n'+text,encoding='utf-8')
print(json.dumps(dict(status='P06_COMPLETE_P07_REFERENCE_CHECKED_NO_NATIVE_QUEUE',utc=now)))
