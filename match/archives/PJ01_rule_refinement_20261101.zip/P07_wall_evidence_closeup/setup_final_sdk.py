from pathlib import Path
import subprocess
F=Path(__file__).resolve().parent/'FINAL';R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P07_wall_closeup_20261101/FINAL'
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
subprocess.run(ssh+[R+'/.venv/bin/python',H+'/R154_scoped_serial_guard_20261101/check_scoped_serial.py'],check=True)
subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=('from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n').encode(),check=True)
for n in ['candidate_project','CANDIDATE_MANIFEST.json','prepare_server.py','qualify_arm.py','check_full_sdk_closeup.py','check_admit_original8_v2.py','finite_wall_support.py','wall_probe_reference.py','PRE_NATIVE_EVIDENCE.json']:
    subprocess.run(['scp','-q','-r',str(F/n),'junhao@10.112.162.60:'+D+'/'],check=True)
subprocess.run(ssh+[R+'/.venv/bin/python',D+'/prepare_server.py'],check=True)
subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/WORKSPACE_READY.json',str(F/'WORKSPACE_READY.json')],check=True)
for script,label in [('qualify_arm.py','ENTRY_P07_FINAL_FIRST'),('check_full_sdk_closeup.py','FULL_SDK_P07_FINAL_FIRST')]:
    run=subprocess.run(ssh+[R+'/.venv/bin/python',H+'/run_sdk_captured.py',D+'/'+script,label,'P07'],capture_output=True,text=True)
    (F/(label+'.capture.txt')).write_text(run.stdout+run.stderr,encoding='utf-8');print(run.stdout);print(run.stderr)
    if run.returncode:raise SystemExit(run.returncode)
    subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/'+label+'.json',str(F/(label+'.json'))],check=True)
