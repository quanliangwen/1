from pathlib import Path
F=Path(__file__).resolve().parent
(F/'WITNESS_CONTRACT_FIRST_ERROR.txt').write_text('First unit fixture failed fresh_own_pre_place_wall_can_support_known_route: its route stub incorrectly rejected legal target in adjacent column at a16px floating grid boundary. Original selector/source/test preserved. Actual inherited Astar independently used in SDK tests. Fix fixture only to valid orthogonal grid path.\n')
s=(F/'check_witness_contract.py').read_text()
s=s.replace("WITNESS_CONTRACT_FIRST.json","WITNESS_CONTRACT_V2.json")
s=s.replace("    if a[1]!=b[1]:return None\n    sign=1 if b[0]>a[0]else -1\n    return[(r,a[1])for r in range(a[0],b[0]+sign,sign)]",'''    path=[a];r,c=a
    while c!=b[1]:
        c+=1 if b[1]>c else -1
        if not walk[r,c]:return None
        path.append((r,c))
    while r!=b[0]:
        r+=1 if b[0]>r else -1
        if not walk[r,c]:return None
        path.append((r,c))
    return path''')
assert 'if a[1]!=b[1]'not in s
out=F/'check_witness_contract_v2.py';assert not out.exists();out.write_text(s,encoding='utf-8')
