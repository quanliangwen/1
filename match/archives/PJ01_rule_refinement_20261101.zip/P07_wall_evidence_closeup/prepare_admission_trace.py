from pathlib import Path
F=Path(__file__).resolve().parent
s=(F/'check_full_sdk_closeup.py').read_text()
marker='source=(F/\'check_admit_original8_v2.py\').read_text()'
hook='''import swarm_rescue.solutions.wall_closeup_mixin as observed_module
from swarm_rescue.solutions.finite_wall_support import from_actual_scan
from swarm_rescue.solutions.completion_consensus import _sortie_known_route
captured=[];original_select=observed_module.select_probe
def trace_select(**kw):
    result=original_select(**kw)
    frozen=dict(kw)
    for k,v in list(frozen.items()):
        if isinstance(v,np.ndarray):frozen[k]=v.copy()
    frozen['result']=result;captured.append(frozen)
    return result
observed_module.select_probe=trace_select

'''
assert s.count(marker)==1;s=s.replace(marker,hook+marker)
marker='    checks=dict(exact_official_interactions='
analysis='''    audits=[]
    for k in captured:
        w=k.get('pre_place_witness');p=np.asarray(k['pose'])
        segments=from_actual_scan(w['pose']if w else p,w['heading']if w else k['heading'],
            w['distances']if w else k['distances'],w['angles']if w else k['angles'],w['excluded']if w else k['excluded'])
        d=np.asarray(w['distances']if w else k['distances']);facts=[]
        for segment in segments:
            wall=.5*(segment['start']+segment['end']);delta=wall-p;distance=float(np.linalg.norm(delta))
            row=int(np.floor(k['height']/2-wall[1]));col=int(np.floor(wall[0]+k['width']/2))
            wanted=p+delta*(distance-190)/max(distance,1e-9)
            source=k['world_to_cell'](p);target=k['world_to_cell'](wanted)
            walk=k['free']&~k['blocked'];band=2*k['cell']
            path=k['route_solver'](source,target,walk,time.perf_counter()+.1)
            facts.append(dict(wall=wall.tolist(),all_original_rays_far=bool(np.all(d[segment['indices']]>=220)),
                range_now=distance,original_ray_min=float(d[segment['indices']].min()),source=source,target=target,
                raw_known_target=bool(k['free'][target]),geometry_blocked_target=bool(k['blocked'][target]),
                existing_wall_pixels_in_band=int(np.count_nonzero(k['parent_image'][max(0,row-band):min(k['height'],row+band+1),max(0,col-band):min(k['width'],col+band+1)])),
                path_exists=path is not None,path=path))
        audits.append(dict(step=k['step'],witness=w is not None,witness_step=w['step']if w else None,
            pose=p.tolist(),result=k['result'],available=min(96,k['remaining']/2,.5*k['limit']-k['step']-24),segments=facts))
    (F/(label+'_ADMISSION_TRACE.json')).write_text(json.dumps(audits,indent=2,default=lambda x:x.item()if isinstance(x,np.generic)else x.tolist())+'\\n')
'''
assert s.count(marker)==1;s=s.replace(marker,analysis+marker)
out=F/'check_full_admission_trace.py';assert not out.exists();out.write_text(s,encoding='utf-8')
