from pathlib import Path
import json
F=Path(__file__).resolve().parent;A=F/'FINAL';P=F.parent/'P06_baseline_causal_diagnosis'
H='/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025'
s=(P/'run_offline.py').read_text().replace("H=F.parent",'H=Path('+repr(H)+')').replace("['P06']","['P07']").replace("version='P06_OBSERVER'","version='P07_CLOSEUP'")
s=s.replace('One original-clock RED-only PJ01 observation; never runs BLUE or ranks.','One original-clock RED-only PJ01 plus bounded closeup; no automatic BLUE/five/rank.')
s=s.replace('Original PJ01 read-only RED-only diagnostic; no BLUE difficulty, full RED score or ranking.','P07 wall-closeup RED-only screen; no BLUE difficulty, full RED score or ranking.')
start=s.index('def observe(');end=s.index('\ndef main():',start)
observe='''def observe(result,group,summary):
    import cv2
    import numpy as np
    row=summary['rounds'][0];events=[]
    for line in (result/'Map02_red/console.log').read_text(errors='replace').splitlines():
        if '[WALL_CLOSEUP] 'in line:events.append(json.loads(line.split('[WALL_CLOSEUP] ',1)[1]))
    exported=cv2.imread(str(result/'Map02_red/round1_red_submitted.png'),cv2.IMREAD_UNCHANGED)
    assert exported is not None
    binary=(exported>0).astype(np.uint8);digest=hashlib.sha256(binary.tobytes()).hexdigest()
    submitted=[e for e in events if e['event']=='SUBMIT_IMAGE']
    matches=[dict(owner=e['owner'],step=e['step'],sha256=e['sha256'])for e in submitted if e['sha256']==digest and e['shape']==list(binary.shape)and e['dtype']=='uint8']
    admitted=[e for e in events if e.get('state')=='ACTIVE']
    completed=[e for e in events if e.get('reason')=='TWO_FRESH_OWN_SCANS_INCORPORATED']
    mapped=bool(completed)and all(len(e['near_scan_epochs'])>=2 and max(e['near_scan_epochs'])<=e['own_mapped_epoch']for e in completed)
    gate=b.D['screen_gate'];phase=row['phase']
    conditions=dict(actual_closeup_admitted=bool(admitted),actual_two_new_own_scans_incorporated=mapped,
        image_owner_bound=bool(matches),all10placed=row['placed']==row['expected']==10,
        no_RED_wall_clock_hit=not row['max_walltime_reached'],map_improvement=phase['score_map']>=gate['map_min'],
        wall_nonregression=phase['score_wall']>=gate['wall_min'],time_still100=phase['score_time']>=100.-1e-8)
    out=dict(status='PASS_BOUND_CLOSEUP_OBSERVATION'if matches else'INCOMPLETE_OBSERVATION_KEEP_NO_RETRY',
        phase=phase,placed=row['placed'],expected=row['expected'],red_steps=row['timestep'],red_wall_seconds=row['walltime'],
        red_max_walltime_reached=row['max_walltime_reached'],image_binding=dict(exporter_inverse='binary0/255 to uint8 0/1',sha256=digest,matches=matches),
        screen_conditions=conditions,pass_screen=all(conditions.values()),admitted=admitted,completed=completed,events=events,
        full_red_score=None,blue_native_rounds=0,automatic_five=False,
        comparison_scope='Independent unseeded run versus P06 originalPJ01 read-only Map02 reference, not same-observation causal comparison or full ranking.',
        scope='Unchanged official score/publicPNG and own public-state log only; no competition truth/private arrays/BLUE read.')
    b.save(group/'MECHANISM_REVIEW.json',out);return out
'''
s=s[:start]+observe+s[end:]
s=s.replace("dict(observation_status=mechanism['status'],no_algorithm_promotion=True)","dict(observation_status=mechanism['status'],pass_screen=mechanism['pass_screen'],automatic_five=False,no_algorithm_promotion=True)")
(A/'run_offline.py').write_text(s,encoding='utf-8')
s=(P/'collect_offline.py').read_text().replace('PJ01_rules_P06_baseline_audit_20261101','PJ01_rules_P07_wall_closeup_20261101/FINAL').replace('RED-only originalPJ01 observer, not a new algorithm or full-score ranking.','RED-only P07 mechanism screen, no full-score ranking.')
s=s.replace("full_red_score=None,ranking=False,scope=", "full_red_score=None,ranking=False,pass_screen=d['pass_screen'],screen_conditions=d['screen_conditions'],scope=")
(A/'collect_offline.py').write_text(s,encoding='utf-8')
for n in ['start_local_collector.py','launch_campaign.py','validate_driver.py']:
    s=(P/n).read_text().replace('preflight_P06','preflight_P07').replace('READONLY_PJ01_RED_ONLY_DIAGNOSTIC_LAUNCHED','P07_RED_ONLY_MECHANISM_SCREEN_LAUNCHED')
    s=s.replace('H=F.parent','H=Path('+repr(H)+')')
    (A/n).write_text(s,encoding='utf-8')
