"""Authored motion-layer check, not an integrated controller or native game.

Original own pose/map/drive, actual SDK sensors/physics and exact7 official
callbacks. Warmup uses authored observation history; all live getters remain
unmodified. Certificate preconditions are controlled fixtures, not proven
over radio. Authored wall truth is read only AFTER all outputs are frozen.
"""
from pathlib import Path
from types import SimpleNamespace
import contextlib,io,json,sys,time,math,fcntl,hashlib,traceback
import numpy as np
F=Path(__file__).resolve().parent;label=sys.argv[1]
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
dest=F/(label+'.json');assert not dest.exists()
source=(F/'check_admit_original8_v2.py').read_text()
source=source[:source.index('    before=arrays(probe.memory)')]+"    return probe,polys,positions[-1].copy()\n"
space={'__file__':str(F/'check_admit_original8_v2.py')};exec(compile(source,'authored_warmup_fixture','exec'),space)
from swarm_rescue.solutions.my_drone_eval import MyDroneEval
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
from swarm_rescue.solutions.completion_consensus import _sortie_known_route
from swarm_rescue.simulation.gui_map.playground import Playground
from swarm_rescue.simulation.gui_map.closed_playground import ClosedPlayground
from swarm_rescue.simulation.elements.normal_wall import NormalWall
from swarm_rescue.simulation.elements.disposal_center import DisposalCenter
from swarm_rescue.simulation.utils.misc_data import MiscData
from swarm_rescue.simulation.reporting.place_score_manager import walls_only_grid
from swarm_rescue.tools.map_exploration_scoring import MapExplorationScorer,breakdown_to_dict
from wall_probe_reference_v2 import select_probe,scan_matches,LastCertificateGate

class OfficialInteractionPlayground(Playground):
    _handle_interactions=ClosedPlayground._handle_interactions
    get_closest_drone=ClosedPlayground.get_closest_drone

def run_case(noisy,with_bomb,enabled):
    # Fixed authored fixture seeds, never injected into native evaluation.
    np.random.seed(615)
    warm,polys,physical_start=space['run']('doorway','partial',noisy,621+int(noisy))
    pg=OfficialInteractionPlayground(size=(640,480))
    for a,b in [((-320.,-240.),(320.,-240.)),((320.,-240.),(320.,240.)),
      ((320.,240.),(-320.,240.)),((-320.,240.),(-320.,-240.)),
      ((-260.,100.),(-60.,100.)),((60.,100.),(260.,100.))]:
        wall=NormalWall(a,b);pg.add(wall,wall.wall_coordinates)
    center=DisposalCenter(size=(24,24));pg.add(center,((250.,-170.),0.))
    fixture=SimpleNamespace(disposal_center=center,_bombs=[],_number_bombs=0,playground=pg)
    d=MyDroneEval(0,misc_data=MiscData(size_area=(640,480),number_drones=5,max_timestep_limit=2000,max_walltime_limit=90))
    pg.add(d,(tuple(physical_start),0.));d.enable_bomb_deployer(fixture,int(with_bomb));d.set_competition_mode(True)
    pg.reset()
    for name in ['memory','pose','heading','heading_initialized','rally','boundary_anchor','frame_records','frame_negative']:
        setattr(d,name,getattr(warm,name))
    d.placement_goal=None;d.escape_until=-1
    gate=LastCertificateGate();rows=[];admission=None;initial_bomb=None;minimum_health=50;started=time.perf_counter()
    initial=d.memory.render().copy();ack=None;scan_frames=[]
    try:
        pre_place_witness=None
        if with_bomb:
            d.elapsed_timestep=159;d.elapsed_walltime=0.
            d._update_pose()
            before_ranges=np.asarray(d.lidar_values(),float).copy()
            before_angles=np.asarray(d.lidar_rays_angles(),float).copy()
            pre_place_witness=dict(step=159,pose=d.pose.copy(),heading=d.heading,
                distances=before_ranges,angles=before_angles,
                excluded=d.memory.semantic_mask(before_ranges,before_angles,d.semantic_values()))
            command=d._empty_command();command['place_bomb']=1
            pg.step({d:command},{})
            assert d.carried_bombs_count()==0 and len(fixture._bombs)==1,'Fixture actual placement failed'
            initial_bomb=np.asarray(fixture._bombs[0].true_position()).copy()
        for offset in range(96):
            step=160+offset;d.elapsed_timestep=step;d.elapsed_walltime=time.perf_counter()-started
            d._update_pose();d.memory.step=step
            ranges=d.lidar_values();angles=np.asarray(d.lidar_rays_angles(),float);semantic=d.semantic_values()
            if ranges is not None and step%4==0:d.memory.observe(d.pose,d.heading,ranges,angles,semantic)
            before_state=gate.state
            def admit():
                if ranges is None:return None
                geometry=GeometryPlanningMemory(d.memory)
                def solver(s,t,walk,deadline):return _sortie_known_route(d.memory,s,t,walk,deadline,max_pops=2048)
                return select_probe(pose=d.pose,heading=d.heading,distances=ranges,angles=angles,
                    excluded=d.memory.semantic_mask(ranges,angles,semantic),parent_image=d.memory.render(),
                    free=d.memory.free,blocked=geometry.blocked(),width=640,height=480,cell=d.memory.CELL,fine=d.memory.FINE,
                    world_to_cell=d.memory.world_to_cell,cell_to_world=d.memory.cell_to_world,route_solver=solver,
                    remaining=500.,step=step,limit=2000,deadline=time.perf_counter()+.1,pre_place_witness=pre_place_witness)
            if gate.active and ranges is not None and step%4==0:
                matches=scan_matches(pose=d.pose,heading=d.heading,distances=ranges,angles=angles,
                    excluded=d.memory.semantic_mask(ranges,angles,semantic),wall=gate.probe['wall'])
                gate.record_own_scan(epoch=step,now=step,matches=matches)
                if matches:scan_frames.append(dict(step=step,map_observed_epoch=d.memory._bearing_frame_step))
            allow=gate.allow_parent(step=step,inventory=int(d.carried_bombs_count()),own_certified=False,
                other_certificates_complete=True,pose_fresh=True,remaining=500.,
                own_map_observed_epoch=d.memory._bearing_frame_step or -1,admit=admit) if enabled else True
            if before_state!='ACTIVE' and gate.active:admission=dict(gate.probe)
            command=d._empty_command()
            if gate.active:
                walk=d.memory.free&~GeometryPlanningMemory(d.memory).blocked()
                cells=_sortie_known_route(d.memory,d.memory.world_to_cell(d.pose),d.memory.world_to_cell(gate.probe['goal']),
                    walk,time.perf_counter()+.05,max_pops=2048)
                if cells is None:gate.abort('LIVE_KNOWN_ROUTE_LOST')
                else:
                    d.waypoints=[d.memory.cell_to_world(c)for c in cells[1:]]or[np.asarray(gate.probe['goal'])]
                    d.goal=np.asarray(gate.probe['goal']);command=d._drive(np.asarray(ranges),angles,semantic)
            if enabled and allow and gate.state in ('DONE','SKIPPED'):ack=step
            pg.step({d:command},{})
            minimum_health=min(minimum_health,d.drone_health)
            rows.append(dict(step=step,physical_position=list(d.base._pm_body.position),own_pose=d.pose.copy(),
                state=gate.state,reason=gate.reason,command=command,own_map_epoch=d.memory._bearing_frame_step,
                inventory=int(d.carried_bombs_count())))
            if ack is not None or(enabled and gate.state=='DONE'):break
        final=d.memory.render().copy()
        # Outputs frozen above. Post-hoc fixture-only measurements below.
        truth=walls_only_grid(pg);scorer=MapExplorationScorer()
        before_score=scorer.score(truth,initial,0.);after_score=scorer.score(truth,final,0.)
        callbacks=sorted(getattr(h.pre_solve,'__name__','')for h in pg.space._handlers.values())
        bomb_moved=float(np.linalg.norm(np.asarray(fixture._bombs[0].true_position())-initial_bomb))if with_bomb else None
        return dict(noisy_authored_history=noisy,real_placed_bomb=with_bomb,probe_enabled=enabled,
            pre_place_actual_sdk_witness=pre_place_witness is not None,admission=admission,reason=gate.reason,ack_step=ack,steps=len(rows),health_min=minimum_health,
            displacement=float(np.linalg.norm(np.asarray(d.base._pm_body.position)-physical_start)),
            bomb_displacement=bomb_moved,bomb_ignore_drone_collisions=getattr(fixture._bombs[0],'ignore_drone_collisions',None)if with_bomb else None,
            actual_inventory=int(d.carried_bombs_count()),new_scans=scan_frames,
            map_before=before_score.score,map_after=after_score.score,map_delta=after_score.score-before_score.score,
            before_breakdown=breakdown_to_dict(before_score),after_breakdown=breakdown_to_dict(after_score),
            changed_pixels=int(np.count_nonzero(initial!=final)),callback_names=callbacks,
            exact_official_interaction_method=type(pg)._handle_interactions is ClosedPlayground._handle_interactions,
            rows=rows,wall_seconds=time.perf_counter()-started)
    finally:pg.cleanup();pg.close_window()

lock=(R/'solver_study/serial_evaluation.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
    with contextlib.redirect_stdout(io.StringIO()):
        rows=[run_case(noisy,bomb,True)for noisy,bomb in [(False,False),(True,False),(False,True),(True,True)]]
    checks=dict(all_actual_official7_callbacks=all(r['exact_official_interaction_method']and len(r['callback_names'])==7 for r in rows),
        all_admit=all(r['admission']is not None for r in rows),all_two_fresh_scans_written=all(r['reason']=='TWO_FRESH_OWN_SCANS_INCORPORATED'and len(r['new_scans'])>=2 for r in rows),
        health_unchanged=all(r['health_min']==50 for r in rows),bombs_not_pushed=all(r['bomb_displacement']is None or r['bomb_displacement']<1e-8 for r in rows),
        no_inventory_remaining=all(r['actual_inventory']==0 for r in rows),within96steps=all(r['steps']<=96 for r in rows),
        all_map_nonregression=all(r['map_delta']>=-1e-8 for r in rows),some_map_improves=any(r['map_delta']>=.5 for r in rows))
    out=dict(status='PASS_AUTHORED_MOTION_LAYER_ONLY'if all(checks.values())else'FAIL_KEEP_MECHANISM_EVIDENCE',checks=checks,rows=rows,
        scope=__doc__,native_rounds=0,controller_integrated=False,production_promoted=False,
        fixture_precondition='Other4 certificates are controlled gate inputs, not radio-delivered certificates. Explicit own-motion closure only.',
        source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in F.glob('*.py')})
    dest.write_text(json.dumps(out,indent=2,default=lambda x:x.item()if isinstance(x,np.generic)else x.tolist())+'\n')
    print(json.dumps(dict(status=out['status'],checks=checks,cases=[{k:v for k,v in r.items()if k not in ['rows','before_breakdown','after_breakdown','admission','callback_names','new_scans']}for r in rows])))
except Exception:
    (F/(label+'_ERROR.txt')).write_text(traceback.format_exc());raise
finally:fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
