from pathlib import Path
import json
import numpy as np
from wall_probe_reference import LastCertificateGate,scan_matches
F=Path(__file__).resolve().parent
checks=[]
def require(v,n):assert v,n;checks.append(n)
context=dict(step=100,inventory=0,own_certified=False,other_certificates_complete=True,pose_fresh=True,remaining=500.,own_map_observed_epoch=96)
def offer(g,**kw):
    c=dict(context,**kw);return g.allow_parent(**c,admit=lambda:dict(admission_step=c['step'],expiry=c['step']+80))
g=LastCertificateGate();require(offer(g,inventory=2),'carrying_inventory_never_delayed');require(g.state=='UNDECIDED','inventory_check_does_not_consume_future_probe')
g=LastCertificateGate();require(offer(g,own_certified=True),'existing_certificate_never_retracted')
g=LastCertificateGate();require(offer(g,other_certificates_complete=False)and g.state=='SKIPPED','other_team_work_not_delayed')
g=LastCertificateGate();require(offer(g,remaining=0)and not g.active,'original_budget_guard_unchanged')
g=LastCertificateGate();require(not offer(g,pose_fresh=False),'one_control_grace_for_fresh_pose');require(offer(g,step=104,pose_fresh=False),'pose_grace_bounded_by4steps')
g=LastCertificateGate();require(not offer(g)and g.active,'supported_probe_withholds_last_certificate')
g.record_own_scan(epoch=104,now=104,matches=True)
require(not offer(g,step=104,own_map_observed_epoch=100),'unincorporated_scan_not_completion')
g.record_own_scan(epoch=104,now=105,matches=True)
require(not offer(g,step=105,own_map_observed_epoch=104),'same_scan_epoch_cannot_count_twice')
g.record_own_scan(epoch=108,now=108,matches=True)
require(not offer(g,step=108,own_map_observed_epoch=104),'second_unincorporated_scan_still_pending')
require(offer(g,step=109,own_map_observed_epoch=108)and g.reason=='TWO_FRESH_OWN_SCANS_INCORPORATED','only_two_fresh_own_mapped_frames_complete')
require(offer(g,step=110)and not g.active,'completed_probe_not_rearmed')
g=LastCertificateGate();offer(g);require(offer(g,step=180)and g.reason=='PROBE_EXPIRED_NO_RENEWAL','expiry_not_extended_by_repeated_checks')
g=LastCertificateGate();offer(g);require(offer(g,step=120,remaining=0),'budget_protection_interrupts_active_probe')
g=LastCertificateGate();offer(g);require(offer(g,step=120,inventory=1)and not g.active,'new_inventory_takes_priority')
g=LastCertificateGate();offer(g);g.record_own_scan(epoch=200,now=101,matches=True);require(not g.seen,'future_sensor_epoch_rejected')
c=dict(context);g=LastCertificateGate();require(g.allow_parent(**c,admit=lambda:None),'no_admissible_probe_calls_original_completion')
a=np.linspace(-.1,.1,9);d=190/np.cos(a);p=np.zeros(2);wall=np.array([190.,0.]);excluded=np.zeros(9,bool)
require(scan_matches(pose=p,heading=0.,distances=d,angles=a,excluded=excluded,wall=wall),'actual_near_range_contiguous_wall_rays_match')
require(not scan_matches(pose=p,heading=0.,distances=250/np.cos(a),angles=a,excluded=excluded,wall=[250.,0.]),'far_old_hit_not_completion')
excluded[:]=True;require(not scan_matches(pose=p,heading=0.,distances=d,angles=a,excluded=excluded,wall=wall),'excluded_semantic_rays_not_completion')
out=dict(status='PASS_BOUNDED_LAST_CERTIFICATE_REFERENCE',checks=checks,native_rounds=0,production_integrated=False,
 scope='State-machine and own-observation contracts only. No SDK route, physical control or score gain established.')
(F/'GATE_CHECK_FIRST.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(status=out['status'],checks=len(checks))))
