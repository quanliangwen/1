"""Message-causal completion, with inventory-empty coordinators still serving peers.

All completion certificates travel alongside the corresponding merged sensor
packet. A cached packet is invalidated whenever a new certificate is learned.
No peer objects, global runtime state or absolute explored-area cutoff is used.
"""
import math
import heapq
import time
import cv2
import numpy as np
from swarm_rescue.solutions.greedy_mapping import GreedyMappingDrone


def _sortie_known_route(memory, start, goal, walkable, deadline, max_pops=8192):
    """Bounded exact known-cell path; timeout is an abstention, never a shortcut."""
    start, goal = tuple(start), tuple(goal)
    rows, cols = walkable.shape
    if not (0 <= goal[0] < rows and 0 <= goal[1] < cols and walkable[goal]):
        return None
    allowed = walkable.copy()
    allowed[start] = True  # the observed robot footprint is authoritative here

    def heuristic(cell):
        dr, dc = abs(cell[0] - goal[0]), abs(cell[1] - goal[1])
        return max(dr, dc) + (math.sqrt(2.) - 1.) * min(dr, dc)

    best = {start: 0.}
    parent = {}
    queue = [(heuristic(start), 0., start)]
    popped = 0
    while queue and popped < max_pops:
        if popped % 64 == 0 and time.perf_counter() >= deadline:
            return None
        _, cost, cell = heapq.heappop(queue)
        if cost > best[cell]:
            continue
        popped += 1
        if cell == goal:
            cells = [goal]
            while cells[-1] != start:
                cells.append(parent[cells[-1]])
            cells.reverse()
            return cells
        row, col = cell
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1),
                       (1, 1), (1, -1), (-1, 1), (-1, -1)):
            nr, nc = row + dr, col + dc
            if not (0 <= nr < rows and 0 <= nc < cols and allowed[nr, nc]):
                continue
            if dr and dc and (not allowed[row + dr, col] or not allowed[row, col + dc]):
                continue
            neighbor = (nr, nc)
            proposal = cost + (math.sqrt(2.) if dr and dc else 1.)
            if proposal < best.get(neighbor, math.inf):
                best[neighbor] = proposal
                parent[neighbor] = cell
                heapq.heappush(queue, (proposal + heuristic(neighbor), proposal, neighbor))
    return None


class CompletionConsensusMixin:
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.completion_certificates = {}
        # Empty drones can perform finite map sorties between actual relay
        # visits. The leader stays at rally to keep placement coordination.
        self._sortie_state = 'RETURN'
        self._sortie_goal = None
        self._sortie_docked_step = None
        self._sortie_expiry = -1
        self._sortie_return_steps = 0.

    @staticmethod
    def _sortie_path_length(position, route):
        points = [np.asarray(position, dtype=float)] + [np.asarray(p, dtype=float) for p in route]
        return sum(float(np.linalg.norm(b - a)) for a, b in zip(points, points[1:]))

    def _sortie_return(self, step):
        self._sortie_state = 'RETURN'
        self._sortie_goal = None
        self._sortie_expiry = -1
        self._sortie_return_steps = 0.
        self._sortie_docked_step = None

    def _sortie_can_depart(self, step):
        own = int(self.identifier or 0)
        active = [peer for peer, (stamp, position, _) in self.fleet_states.items()
                  if position is not None and 0 <= step - stamp < self.STATE_FRESH_STEPS]
        if not active or own == min(active):
            return False
        if all(peer in self.completion_certificates for peer in range(self.team_size)):
            return False
        docked = self._sortie_docked_step
        if docked is None or step - docked < 24:
            return False
        # An actual map-bearing message after this dock is required. Missing
        # radio contacts never stand in for a teammate's private state.
        return any(peer != own and docked < stamp <= step and step - stamp < 100
                   for peer, stamp in self.last_peer_step.items())

    def _sortie_admit(self, step, peer_goals):
        deadline = time.perf_counter() + .35
        remaining = float(self._remaining_steps())
        if remaining <= 96 or self.rally is None or self.pose is None:
            return None
        memory = self.memory
        blocked = memory.blocked()
        walkable = memory.free & ~blocked
        unknown = ~memory.free & ~blocked
        if not unknown.any() or time.perf_counter() >= deadline:
            return None
        frontier = walkable & (cv2.dilate(unknown.astype(np.uint8), np.ones((3, 3), np.uint8)) > 0)
        if not frontier.any():
            return None
        proxy = cv2.boxFilter(unknown.astype(np.float32), -1, (9, 9),
                              normalize=False, borderType=cv2.BORDER_CONSTANT)
        source = memory.world_to_cell(self.pose)
        if (source != memory.world_to_cell(self.rally) or not walkable[source]):
            return None
        rr, cc = np.indices(memory.shape)
        metric = np.hypot(rr - source[0], cc - source[1])
        rank = proxy / (4. + metric)
        rank[~frontier] = -np.inf
        rank[metric < 2.] = -np.inf
        for goal in peer_goals:
            if goal is not None:
                pr, pc = memory.world_to_cell(goal)
                rank[(rr-pr)**2 + (cc-pc)**2 < 16] = -np.inf
        if not np.isfinite(rank).any():
            return None
        flat = rank.ravel()
        candidate_count = min(64, flat.size)
        top = np.argpartition(flat, -candidate_count)[-candidate_count:]
        top = sorted(top, key=lambda index: (-flat[index], int(index)))
        chosen = None
        tested = []
        for index in top:
            if len(tested) >= 12 or time.perf_counter() >= deadline:
                break
            if not np.isfinite(flat[index]) or flat[index] <= 0:
                break
            cell = tuple(int(v) for v in np.unravel_index(int(index), memory.shape))
            if any((cell[0]-other[0])**2 + (cell[1]-other[1])**2 < 9 for other in tested):
                continue
            tested.append(cell)
            path = _sortie_known_route(memory, source, cell, walkable, deadline)
            if path is not None:
                chosen = path
                break
        if chosen is None:
            return None
        goal = memory.cell_to_world(chosen[-1])
        route = [memory.cell_to_world(cell) for cell in chosen[1:]]
        outward = self._sortie_path_length(self.pose, route)
        # The known graph is undirected: reversing the certified outward path
        # is a return certificate without another Dijkstra invocation.
        returning = outward
        demand = (outward + returning) / 2. + 48.
        if demand > min(remaining - 24., remaining / 2.):
            return None
        self._sortie_state = 'SORTIE'
        self._sortie_goal = np.asarray(goal, dtype=float).copy()
        self._sortie_expiry = step + int(np.ceil(outward / 2. + 24.))
        self._sortie_return_steps = returning / 2. + 24.
        return route, self._sortie_goal.copy()

    def _record_own_completion(self, step):
        own = int(self.identifier or 0)
        if int(self.carried_bombs_count()) == 0 and own not in self.completion_certificates:
            self.completion_certificates[own] = int(step)
            self.cached_packet = None

    def define_message_for_all(self):
        self._record_own_completion(int(self.elapsed_timestep))
        # The parent's normal packet builder now includes every sensor map
        # whose certificate this instance has acknowledged.
        message = super().define_message_for_all()
        message['completion_certificates'] = dict(self.completion_certificates)
        return message

    def _messages(self):
        super()._messages()
        step = int(self.elapsed_timestep)
        for _, message in self.communicator.received_messages:
            if not isinstance(message, dict) or message.get('kind') != 'greedy-map-v1':
                continue
            sender, sent = message.get('id'), message.get('step')
            if (not isinstance(sender, int) or not 0 <= sender < self.team_size
                    or not isinstance(sent, int) or not 0 <= sent <= step
                    or self.last_peer_step.get(sender) != sent or 'map' not in message):
                continue
            certificates = message.get('completion_certificates', {})
            if not isinstance(certificates, dict):
                continue
            for origin, stamp in certificates.items():
                if (not isinstance(origin, int) or not 0 <= origin < self.team_size
                        or not isinstance(stamp, int) or not 0 <= stamp <= sent):
                    continue
                if origin == int(self.identifier or 0):
                    continue
                if origin not in self.completion_certificates:
                    self.completion_certificates[origin] = stamp
                    # A relayed certificate must never outrun its map payload.
                    self.cached_packet = None
        self._record_own_completion(step)

    def _plan_route(self, step, returning, peer_goals):
        if int(self.carried_bombs_count()) == 0:
            # Leadership depends on received fresh state, not inventory. An
            # elected empty coordinator must still allocate its peers' slots.
            self._build_fleet_plan(step)
            self.placement_goal = None
            if self.pose is None or self.rally is None:
                self._sortie_return(step)
                return GreedyMappingDrone._plan_route(self, step, True, peer_goals)
            if self._sortie_state == 'SORTIE':
                goal = self._sortie_goal
                finished = (goal is None or step >= self._sortie_expiry or
                            np.linalg.norm(self.pose - goal) < 24 or
                            self._remaining_steps() <= self._sortie_return_steps + 24 or
                            all(peer in self.completion_certificates for peer in range(self.team_size)))
                if not finished:
                    deadline = time.perf_counter() + .05
                    walkable = self.memory.free & ~self.memory.blocked()
                    cells = _sortie_known_route(self.memory,
                        self.memory.world_to_cell(self.pose),
                        self.memory.world_to_cell(goal), walkable, deadline, max_pops=2048)
                    if cells is not None:
                        route = [self.memory.cell_to_world(cell) for cell in cells[1:]]
                        return route or [goal.copy()], goal.copy()
                self._sortie_return(step)
            if np.linalg.norm(self.pose - self.rally) < 40:
                if self._sortie_state != 'DOCK':
                    self._sortie_state = 'DOCK'
                    self._sortie_docked_step = step
                    self.cached_packet = None
                if self._sortie_can_depart(step):
                    try:
                        admitted = self._sortie_admit(step, peer_goals)
                    except (ValueError, TypeError, IndexError, KeyError, OverflowError):
                        admitted = None
                    if admitted is not None:
                        return admitted
            else:
                self._sortie_return(step)
            return GreedyMappingDrone._plan_route(self, step, True, peer_goals)
        return super()._plan_route(step, returning, peer_goals)

    def _submission_due(self, step):
        if self._remaining_steps() <= 0:
            return True
        self._record_own_completion(step)
        if int(self.carried_bombs_count()) != 0:
            return False
        if not all(i in self.completion_certificates for i in range(self.team_size)):
            return False
        own = int(self.identifier or 0)
        quality = self._map_quality()
        better = any(0 <= step - ts < self.STATE_FRESH_STEPS
            and (known, occupied, -peer) > (*quality, -own)
            for peer, (ts, known, occupied) in self.map_quality_records.items() if peer != own)
        return not better

    def control(self):
        command = super().control()
        if (self.submitted or self.pose is None or self.rally is None
                or int(self.carried_bombs_count()) != 0
                or self._sortie_state == 'SORTIE'
                or getattr(self, '_wall_closeup_motion', False)
                or np.linalg.norm(self.pose - self.rally) >= 40):
            return command
        # Remain within radio range without orbiting the rendezvous while
        # waiting for the remaining completion maps. Only public odometry.
        velocity = self.measured_velocity()
        if velocity is None or not np.isfinite(velocity).all():
            velocity = np.zeros(2)
        cosine, sine = math.cos(self.heading), math.sin(self.heading)
        command.update(forward=float(np.clip(-(velocity[0]*cosine + velocity[1]*sine)/5.5, -1, 1)),
            lateral=float(np.clip(-(-velocity[0]*sine + velocity[1]*cosine)/5.5, -1, 1)),
            rotation=0., grasper=0, place_bomb=0)
        return command
