"""Reference only: one bounded known-free close-up before last certificate.

Uses inherited 220px hit range, 190px edge-survey standoff, finite measured
segments, and original known-cell A*. No private state, map id or score oracle.
"""
import math
import time
import numpy as np
from swarm_rescue.solutions.finite_wall_support import from_actual_scan

def select_probe(*,pose,heading,distances,angles,excluded,parent_image,free,blocked,
                 width,height,cell,fine,world_to_cell,cell_to_world,route_solver,
                 remaining,step,limit,deadline=None,pre_place_witness=None):
    now=time.perf_counter()
    deadline=now+.05 if deadline is None else deadline
    available=min(96.,float(remaining)/2.,.5*float(limit)-int(step)-24.)
    if available<48 or now>=deadline:return None
    position=np.asarray(pose,float);image=np.asarray(parent_image)
    raw_free=np.asarray(free,bool);obstacles=np.asarray(blocked,bool)
    if position.shape!=(2,)or not np.isfinite(position).all()or image.shape!=(height,width):return None
    if raw_free.shape!=obstacles.shape:return None
    walkable=raw_free&~obstacles
    if pre_place_witness is None:
        witness_position=position;witness_heading=heading
        witness_distances=distances;witness_angles=angles;witness_excluded=excluded
    else:
        witness=pre_place_witness
        if not isinstance(witness,dict):return None
        epoch=witness.get('step')
        if type(epoch)is not int or not 0<=int(step)-epoch<=24:return None
        try:
            witness_position=np.asarray(witness['pose'],float)
            witness_heading=float(witness['heading']);witness_distances=np.asarray(witness['distances'],float)
            witness_angles=np.asarray(witness['angles'],float);witness_excluded=np.asarray(witness['excluded'],bool)
        except(KeyError,TypeError,ValueError,OverflowError):return None
        if witness_position.shape!=(2,)or not np.isfinite(witness_position).all():return None
        if not math.isfinite(witness_heading)or witness_distances.ndim!=1 or witness_angles.shape!=witness_distances.shape or witness_excluded.shape!=witness_distances.shape:return None
    segments=from_actual_scan(witness_position,float(witness_heading),witness_distances,witness_angles,witness_excluded)
    source=tuple(world_to_cell(position));best=None;tested=0;complete=True
    d=np.asarray(witness_distances,float)
    for segment in segments:
        if time.perf_counter()>=deadline:complete=False;break
        ids=segment['indices']
        if np.count_nonzero(d[ids]>=220.)<6:continue
        wall=.5*(segment['start']+segment['end']);vector=wall-position;distance=float(np.linalg.norm(vector))
        if not 220.<=distance<280.:continue
        r=int(math.floor(height/2-wall[1]));c=int(math.floor(wall[0]+width/2))
        if not(0<=r<height and 0<=c<width):continue
        band=2*cell
        if np.any(image[max(0,r-band):min(height,r+band+1),max(0,c-band):min(width,c+band+1)]):continue
        wanted=position+vector*(distance-190.)/distance
        if not(-width/2<wanted[0]<width/2 and -height/2<wanted[1]<height/2):continue
        target=tuple(world_to_cell(wanted));goal=np.asarray(cell_to_world(target),float)
        if target==source or not(0<=target[0]<walkable.shape[0]and 0<=target[1]<walkable.shape[1]and walkable[target]):continue
        if not 48.<=np.linalg.norm(wall-goal)<220.-fine:continue
        tested+=1
        path=route_solver(source,target,walkable,deadline)
        if path is None:continue
        points=[position]+[np.asarray(cell_to_world(z),float)for z in path[1:]]
        length=sum(float(np.linalg.norm(b-a))for a,b in zip(points,points[1:]))
        demand=math.ceil(length/2.)+48.
        if demand>available:continue
        record=dict(goal=goal.tolist(),wall=wall.tolist(),range_before=distance,
            original_ray_indices=ids.tolist(),path=[list(z)for z in path],length=length,
            needed_steps=demand,admission_step=int(step),expiry=int(step)+int(math.floor(available)),
            standoff=190.,incorporation_range=220.,incorporated_scan_frames_required=2)
        if best is None or(length,record['goal'])<(best['length'],best['goal']):best=record
    if best is not None:best.update(candidates_tested=tested,all_measured_candidates_enumerated=complete)
    return best

def scan_matches(*,pose,heading,distances,angles,excluded,wall):
    p=np.asarray(pose,float);d=np.asarray(distances,float);a=np.asarray(angles,float);e=np.asarray(excluded,bool)
    if p.shape!=(2,)or d.ndim!=1 or d.shape!=a.shape or e.shape!=d.shape:return False
    theta=float(heading)+a
    ends=p+d[:,None]*np.column_stack((np.cos(theta),np.sin(theta)))
    good=np.isfinite(d)&(d>8)&(d<220.)&~e&(np.linalg.norm(ends-np.asarray(wall,float),axis=1)<=32.)
    # Three contiguous actual wall rays, never bridge a semantic exclusion.
    return len(good)>=3 and bool(np.any(good[:-2]&good[1:-1]&good[2:]))

class LastCertificateGate:
    """True permits original certificate logic; False withholds it finitely."""
    def __init__(self):
        self.state='UNDECIDED';self.reason=None;self.wait_started=None;self.probe=None;self.seen=set()
    @property
    def active(self):return self.state=='ACTIVE'
    def record_own_scan(self,*,epoch,now,matches):
        if type(epoch)is not int or epoch<0 or epoch>now:return
        if self.active and matches and epoch>self.probe['admission_step']:self.seen.add(epoch)
    def abort(self,reason):self.state='DONE';self.reason=reason
    def allow_parent(self,*,step,inventory,own_certified,other_certificates_complete,
                     pose_fresh,remaining,own_map_observed_epoch,admit):
        if own_certified:
            if self.active:self.abort('ALREADY_CERTIFIED_NO_RETRACTION')
            return True
        if inventory>0:
            if self.active:self.abort('INVENTORY_PRIORITY')
            return True
        if remaining<=0:self.abort('ORIGINAL_BUDGET_PROTECTION');return True
        if self.state in ['DONE','SKIPPED']:return True
        if not other_certificates_complete:
            self.state='SKIPPED';self.reason='OTHER_TEAM_WORK_NOT_CERTIFIED';return True
        if self.state=='UNDECIDED':self.state='WAIT_ADMISSION';self.wait_started=int(step)
        if self.state=='WAIT_ADMISSION':
            if pose_fresh:
                self.probe=admit()
                if self.probe is None:self.state='SKIPPED';self.reason='NO_SUPPORTED_FEASIBLE_PROBE';return True
                self.state='ACTIVE';self.reason='BOUNDED_MEASURED_WALL_CLOSEUP'
            elif step-self.wait_started>=4:self.abort('NO_FRESH_POSE_GRACE_EXPIRED');return True
            else:return False
        if self.active:
            incorporated=[t for t in self.seen if t<=own_map_observed_epoch and t<=step]
            if len(incorporated)>=2:self.abort('TWO_FRESH_OWN_SCANS_INCORPORATED');return True
            if step>=self.probe['expiry']:self.abort('PROBE_EXPIRED_NO_RENEWAL');return True
            return False
        return True
