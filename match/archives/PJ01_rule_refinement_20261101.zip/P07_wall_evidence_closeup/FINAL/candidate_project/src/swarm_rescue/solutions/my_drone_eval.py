from swarm_rescue.solutions.wall_closeup_mixin import WallCloseupMixin
from swarm_rescue.solutions.terminal_value import TerminalValueMixin
from swarm_rescue.solutions.bearing_memory import BearingMappingMixin
from swarm_rescue.solutions.completion_consensus import CompletionConsensusMixin
from swarm_rescue.solutions.counterfactual_commitment import CounterfactualCommitmentMixin
from swarm_rescue.solutions.joint_survey import JointSurveyCoverMixin
from swarm_rescue.solutions.active_coverage import ActiveCoverageMixin
"""Sensor-only red-team controller: exploration, coverage allocation, mapping."""
from swarm_rescue.solutions.geometry_navigation import GeometryNavigationMixin
from swarm_rescue.solutions.frame_mapping import FrameMappingMixin
from swarm_rescue.solutions.coverage_placement import CoveragePlacementDrone
from swarm_rescue.solutions.fast_exploration import ExplorationMotionMixin
from swarm_rescue.solutions.fleet_mission import FleetCoverageMixin
from swarm_rescue.solutions.anchor_mapping import AnchoredMappingMixin
from swarm_rescue.solutions.centre_geometry_review import ReviewedCentreGeometryMixin
from swarm_rescue.solutions.fleet_endpoint_repair import FleetEndpointRepairMixin

class MyDroneEval(WallCloseupMixin,BearingMappingMixin,TerminalValueMixin,CompletionConsensusMixin,CounterfactualCommitmentMixin,JointSurveyCoverMixin,ActiveCoverageMixin,GeometryNavigationMixin,FrameMappingMixin,FleetEndpointRepairMixin,ReviewedCentreGeometryMixin,FleetCoverageMixin,AnchoredMappingMixin,ExplorationMotionMixin,CoveragePlacementDrone):
    CLEAR_NONWALL_HITS=True

def drone_class_for_mode(mode):
    if str(mode).lower()!='place': raise ValueError('Red-team place mode only')
    return MyDroneEval
