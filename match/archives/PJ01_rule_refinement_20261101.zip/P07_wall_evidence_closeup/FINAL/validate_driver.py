from pathlib import Path
import ast,importlib.util,json
F=Path(__file__).resolve().parent
for n in ['run_offline.py','prepare_native.py']:ast.parse((F/n).read_text())
spec=importlib.util.spec_from_file_location('preflight_P07',F/'run_offline.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.b.validate_frozen();d=m.b.D
assert d['maps']==['Map02']and d['max_native_rounds']==1 and d['blue_native_rounds']==0 and d['seed']is None
assert len(d['schedule'])==1 and not(F/'RUN_ONCE.json').exists()
assert d['resource_gate']['cpu_busy_max']==60 and d['resource_gate']['load_per_cpu_max']==.4
assert d['resource_gate']['interval_seconds']==60 and d['resource_gate']['consecutive_samples']==2
out=dict(status='PASS_FROZEN_RED_ONLY_DRIVER_PREFLIGHT',native_games_started=0,SDK_and_source_hashes_match=True,resource_gate_unchanged=True,blue_run=False)
(F/'DRIVER_PREFLIGHT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
