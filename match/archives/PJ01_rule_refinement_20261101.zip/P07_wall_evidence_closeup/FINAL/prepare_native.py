from pathlib import Path
import hashlib,json,shutil,zipfile
F=Path(__file__).resolve().parent;R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not(F/'PREDECLARATION.json').exists()
m=read(F/'WORKSPACE_READY.json')['versions']['P07'];W=Path(m['workspace'])
entry=read(F/'ENTRY_P07_FINAL_FIRST.json');full=read(F/'FULL_SDK_P07_FINAL_FIRST.json')
assert entry['status']=='PASS_SERVER_RESEARCH_ENTRY_NOT_OFFICIAL_RELEASE'and entry['sources']==m['sources']
assert full['status']=='PASS_ACTUAL_FIVE_CONTROLLER_ENDGAME_ONLY'and full['source_sha256']==m['sources']
assert all(sha(W/n)==h for n,h in m['sources'].items())and all(sha(W/n)==h for n,h in m['sdk_files'].items())
v3=read(F.parent/'V3/FULL_SDK_P07_V3_FIRST.json');control=read(F.parent/'FULL_SDK_PJ01_FIRST.json')
assert all(b['submissions'][0]['map_score']>a['submissions'][0]['map_score']for a,b in zip(control['rows'],full['rows']))
old=read(H/'F32_official_sdk_20261028/FIVE_MAP_REBASELINE/PREDECLARATION.json')
d={k:old[k]for k in ['sdk_commit','sdk_files','blue_binding','blue_binding_sha256','resource_gate','frozen_files']}
d.update(phase='PJ01_rules_P07_wall_closeup_20261101_FINAL',selection=['P07'],maps=['Map02'],seed=None,history_delta=False,versions={},max_native_rounds=1,blue_native_rounds=0,
 schedule=[dict(version='P07',cohort='OBS',label='sdk_e2f022b_PJ01_P07_LAST_WALL_CLOSEUP_MAP02_FIRST')],observer_workspace=str(W),observer_sources=m['sources'],
 evaluator=str(H/'F32_official_sdk_20261028/postscore_visual_evaluator_v2.py'),automatic_five=False,
 authorization='Active human originalPJ01 one-rule refinement. Own measured-wall closeup passed bounded/refusal and actual5controller endgame checks. Exactly1 original-clock RED mechanism screen, no automaticBLUE/five/rank.',
 screen_gate=dict(reference='P06 originalPJ01 read-only independent Map02',map_min=95.4871008172463+.5,wall_min=71.52129257219796,time_min=100,inventory=10,
   mechanism='Actual admitted wall probe and >=2fresh own near scans already incorporated before completion; SHA-bound public submitted image; no RED wallhit.'),
 decision_scope='Independent unseeded Map02 screen only. No full red score, no automatic five or retry. First native failure stops chain; pass is hope, not proof of causal/stable improvement.')
V=F/'versions/P07';V.mkdir(parents=True);S=V/'source';S.mkdir()
for p in(W/'src/swarm_rescue/solutions').iterdir():
    if p.is_file():shutil.copy2(p,S/p.name)
shutil.copy2(W/'req.txt',S/'req.txt');files={p.name:sha(p)for p in S.iterdir()}
z=V/'P07_CLOSEUP_INTERNAL_ONLY.zip'
with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED)as a:
    for p in sorted(S.iterdir()):a.write(p,p.name)
with zipfile.ZipFile(z)as a:assert{n:hashlib.sha256(a.read(n)).hexdigest()for n in a.namelist()}==files
d['versions']['P07']=dict(original_zip=str(z),original_zip_sha256=sha(z),source=str(S),source_files=files)
(V/'QUALIFICATION.json').write_text(json.dumps(dict(status='PASS',payload_files_sha256=files,zip_sha256=sha(z),actual_source_entry_receipt=entry,official_submission_ready=False),indent=2)+'\n')
for p in [F/'run_offline.py',F/'ENTRY_P07_FINAL_FIRST.json',F/'FULL_SDK_P07_FINAL_FIRST.json',F/'PRE_NATIVE_EVIDENCE.json']:
    d['frozen_files'][str(p)]=sha(p)
(F/'PREDECLARATION.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(dict(status='PREPARED_P07_RED_ONLY_SCREEN_NOT_STARTED',max_native=1,blue_native=0,workspace=str(W),zip_sha256=sha(z),screen_gate=d['screen_gate'])))
