from pathlib import Path
import shutil,hashlib,json,ast
F=Path(__file__).resolve().parent;B=F.parent/'P01_baseline_rules/baseline_project';C=F/'candidate_project'
assert not C.exists();assert json.loads((F/'PHYSICAL_WITNESS_V2_FIRST.json').read_text())['status']=='PASS_AUTHORED_MOTION_LAYER_ONLY'
shutil.copytree(B,C,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
S=C/'src/swarm_rescue/solutions'
for n in ['wall_closeup_mixin.py','finite_wall_support.py']:shutil.copy2(F/n,S/n)
s=(F/'wall_probe_reference_v2.py').read_text().replace('from finite_wall_support import from_actual_scan','from swarm_rescue.solutions.finite_wall_support import from_actual_scan')
(S/'wall_probe_reference.py').write_text(s,encoding='utf-8')
p=S/'my_drone_eval.py';s=p.read_text();marker='class MyDroneEval(BearingMappingMixin,';assert s.count(marker)==1
p.write_text('from swarm_rescue.solutions.wall_closeup_mixin import WallCloseupMixin\n'+s.replace(marker,'class MyDroneEval(WallCloseupMixin,BearingMappingMixin,',1),encoding='utf-8')
p=S/'completion_consensus.py';s=p.read_text();marker="or self._sortie_state == 'SORTIE'";assert s.count(marker)==1
p.write_text(s.replace(marker,marker+"\n                or getattr(self, '_wall_closeup_motion', False)",1),encoding='utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in S.glob('*.py'):ast.parse(p.read_text(encoding='utf-8-sig'))
files={p.relative_to(C).as_posix():sha(p)for p in C.rglob('*')if p.is_file()}
base={p.relative_to(B).as_posix():sha(p)for p in B.rglob('*')if p.is_file()and'__pycache__'not in p.parts}
changed=sorted(n for n,h in files.items()if base.get(n)!=h)
assert changed==['src/swarm_rescue/solutions/'+n for n in ['completion_consensus.py','finite_wall_support.py','my_drone_eval.py','wall_closeup_mixin.py','wall_probe_reference.py']]
manifest=dict(status='PJ01_PLUS_ONE_BOUNDED_WALL_CLOSEUP_RULE_CANDIDATE_NOT_QUALIFIED',files=files,changed_files=changed,
    unchanged_mapper_navigation_planner=True,failed_P02_P03_P05_absent=True,official_submission_created=False,
    scope='4 authored motion-layer closures passed; full controller MRO/radio/completion/budget integration not yet checked. No native schedule.')
(F/'CANDIDATE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in manifest.items()if k!='files'}))
