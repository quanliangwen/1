from pathlib import Path
import subprocess
F=Path(__file__).resolve().parent;P=F.parent/'P03_proven_pose_rule'
s=(P/'prepare_server.py').read_text(encoding='utf-8').replace('pj01_rules_proven_pose_20261101','pj01_rules_finite_output_20261101').replace("'P03':dict", "'P05':dict").replace('ONE_COLORED_POSE_RULE','ONE_FINITE_OUTPUT_RULE')
s=s.replace('One previously map-helpful rule at a time, small checks first, full five only if improved. Automation90 ACTIVE; builtin goal edit/resume pending human UI.','One previous output-only finite wall rule, adapted to preserve original geometry after counterchecks. Goal and automation ACTIVE. No P02/P03, only map-output support. Small single-map only after contract and entry qualification.')
(F/'prepare_server.py').write_text(s,encoding='utf-8')
R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/PJ01_rules_P05_finite_output_20261101'
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
subprocess.run(ssh+[R+'/.venv/bin/python',H+'/R154_scoped_serial_guard_20261101/check_scoped_serial.py'],check=True)
subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=('from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n').encode(),check=True)
for n in ['candidate_project','CANDIDATE_MANIFEST.json','prepare_server.py','check_actual_contract.py']:
    subprocess.run(['scp','-q','-r',str(F/n),'junhao@10.112.162.60:'+D+'/'],check=True)
subprocess.run(['scp','-q',str(P/'qualify_arm.py')if(P/'qualify_arm.py').exists()else str(F.parent/'P02_proven_endpoint_rule/qualify_arm.py'),'junhao@10.112.162.60:'+D+'/qualify_arm.py'],check=True)
subprocess.run(ssh+[R+'/.venv/bin/python',D+'/prepare_server.py'],check=True)
subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/WORKSPACE_READY.json',str(F/'WORKSPACE_READY.json')],check=True)
run=subprocess.run(ssh+[R+'/.venv/bin/python',H+'/run_sdk_captured.py',D+'/check_actual_contract.py','CONTRACT_P05_FIRST','P05'],capture_output=True,text=True)
(F/'CONTRACT_FIRST_CAPTURE.txt').write_text(run.stdout+run.stderr,encoding='utf-8');print(run.stdout);print(run.stderr)
if run.returncode:raise SystemExit(run.returncode)
subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/CONTRACT_P05_FIRST.json',str(F/'CONTRACT_P05_FIRST.json')],check=True)
