from pathlib import Path
import hashlib,json,shutil,zipfile
F=Path(__file__).resolve().parent;H=F.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
P=H/'PJ01_rules_P03_pose_20261101';A=H/'PJ01_rules_P04_finite_wall_audit_20261101'
assert not(F/'PREDECLARATION.json').exists()
m=read(F/'WORKSPACE_READY.json');contract=read(F/'CONTRACT_P05_FIRST.json')
assert contract['status']=='PASS_ACTUAL_OUTPUT_ADAPTER_CONTRACT'
for name in ['THIN_UNION_ORIGINAL8_FIRST','THIN_UNION_CEILING4_FIRST']:assert read(A/(name+'.json'))['mechanical_isolation_pass']
assert read(A/'THIN_UNION_ORIGINAL8_FIRST.json')['positive_cases']>=1
assert read(A/'THIN_UNION_CEILING4_FIRST.json')['minimum_map_delta']>=-.5
control=read(P/'PJ01_A/MECHANISM_REVIEW.json');proof=read(P/'PJ01_A/CLIENT_FIRST_RAW_REVIEW.json');assert proof['status']=='PASS'
assert control['version']=='PJ01'and control['placed']==10 and not(control['red_wall_hit']or control['blue_wall_hit'])
old=read(H/'F32_official_sdk_20261028/FIVE_MAP_REBASELINE/PREDECLARATION.json')
d={k:old[k]for k in ['sdk_commit','sdk_files','blue_binding','blue_binding_sha256','resource_gate','frozen_files']}
d.update(phase=F.name,selection=['P05'],maps=['Map02'],seed=None,history_delta=False,versions={},max_native_rounds=2,min_native_rounds=2,
 schedule=[dict(version='P05',cohort='A',label='sdk_e2f022b_PJ01_RULE_P05_FINITE_OUTPUT_MAP02_FIRST')],
 authorization='2026-11-01 active PJ01 map-first goal: one useful past rule, analyze and small checks first. Current single-rule output union passed12 static and40actual contract checks. SingleMap02redblue only; no automaticfive.',
 hypothesis='Keep original PJ01 control-state/packet/planning input arrays; only submit-time thin finite measured support union. Runtime overhead can indirectly affect measured wallclock decisions. P02/P03 absent.',
 reference_control=dict(phase=P.name,group='PJ01_A',observed_complete_score=control['score'],observed_map_score=control['phase']['score_map'],
  mechanism_review=str(P/'PJ01_A/MECHANISM_REVIEW.json'),first_byte_receipt=str(P/'PJ01_A/CLIENT_FIRST_RAW_REVIEW.json'),
  first_byte_archive_sha256=proof['archive_sha256'],source=dict(read(P/'PREDECLARATION.json')['versions']['PJ01']),
  scope='Reuse just-completed originalPJ01 Map02 control, no repeated archive download/native baseline. Independent unseeded runs, no causal-stability claim.'),
 rule_acceptance=dict(actual_nonzero_output_addition=True,map_gain_at_least=.5,full_not_below_reference=True,all10_placed=True,no_red_blue_wallclock_hit=True),
 automatic_five=False,ranking_promoted=False,qualification_scope='Current server numerical/SDK5constructor/actual memory packet planner contract, internal payload only; not official competition release.')
version='P05';w=m['versions'][version];W=Path(w['workspace'])
assert all(sha(W/n)==v for n,v in w['sources'].items())
qual=read(F/'ENTRY_P05_FIRST.json');assert qual['status']=='PASS_SERVER_RESEARCH_ENTRY_NOT_OFFICIAL_RELEASE'and qual['sources']==w['sources']
V=F/'versions'/version;V.mkdir(parents=True);S=V/'source';S.mkdir()
for p in (W/'src/swarm_rescue/solutions').iterdir():
    if p.is_file():shutil.copy2(p,S/p.name)
shutil.copy2(W/'req.txt',S/'req.txt');files={p.name:sha(p)for p in S.iterdir()}
z=V/'P05_INTERNAL_RESEARCH_ONLY.zip'
with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED)as archive:
    for p in sorted(S.iterdir()):archive.write(p,p.name)
with zipfile.ZipFile(z)as archive:assert{n:hashlib.sha256(archive.read(n)).hexdigest()for n in archive.namelist()}==files
d['versions'][version]=dict(original_zip=str(z),original_zip_sha256=sha(z),source=str(S),source_files=files)
(V/'QUALIFICATION.json').write_text(json.dumps(dict(status='PASS',payload_files_sha256=files,zip_sha256=sha(z),actual_source_entry_receipt=qual,official_submission_ready=False),indent=2)+'\n')
for p in [F/'run_offline.py',F/'CONTRACT_P05_FIRST.json',F/'ENTRY_P05_FIRST.json',P/'PJ01_A/MECHANISM_REVIEW.json',P/'PJ01_A/CLIENT_FIRST_RAW_REVIEW.json',A/'THIN_UNION_ORIGINAL8_FIRST.json',A/'THIN_UNION_CEILING4_FIRST.json']:
    d['frozen_files'][str(p)]=sha(p)
(F/'PREDECLARATION.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(dict(status='PREPARED_P05_MAP02_ONLY_NOT_LAUNCHED',max_native=2,reference_map=control['phase']['score_map'],reference_full=control['score'],candidate_sha=sha(z))))
