from pathlib import Path
import datetime,json
F=Path(__file__).resolve().parent
d=json.loads((F/'REVIEWED_COMPARISON.json').read_text(encoding='utf-8'))
baseline,candidate=d['rows'];events=d['events']
k=max(e['added_pixels']for e in events)
mech=json.loads((F/'P05_A/MECHANISM_REVIEW.json').read_text(encoding='utf-8'))
n=mech['phase']['map_breakdown']['wall_pixels']
loss=100*.2*k/n;gain=100*k/n
parent_interval=[candidate['map_score']-gain,candidate['map_score']+loss]
out=dict(status='DERIVED_RECALL_MONOTONICITY_AND_MAX_UNION_EFFECT',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 maximum_added_pixels_across_all_submitted_owners=k,reported_wall_surface_pixels=n,
 same_input_union_rule_effect_interval_pp=[-loss,gain],same_run_original_parent_map_score_interval=parent_interval,
 minimum_pre_output_map_gap_to_previous_control=baseline['map_score']-parent_interval[1],
 minimum_pre_output_extra_false_drawing_vs_control=candidate['false_drawing_pp']-loss-baseline['false_drawing_pp'],
 maximum_possible_original_credit=candidate['map_credit_pp'],minimum_pre_output_credit_gap_to_control=baseline['map_credit_pp']-candidate['map_credit_pp'],
 logged_finite_support_seconds_all_owners=sum(e['finite_support_seconds']for e in events),
 observed_total_red_wall_difference=candidate['red_wall_seconds']-baseline['red_wall_seconds'],
 caveat='Conditional on exact logged implementation and submitted binary union. Bounds do not identify the actual sign, and do not attribute trajectory/fusion/clock effects. No actual competition truth or private arrays loaded.')
(F/'ACTUAL_UNION_EFFECT_BOUND.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(out,ensure_ascii=False))
