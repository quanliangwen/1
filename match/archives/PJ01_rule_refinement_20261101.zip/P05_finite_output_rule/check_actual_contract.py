from pathlib import Path
from types import SimpleNamespace
import contextlib,io,json,sys
import numpy as np
F=Path(__file__).resolve().parent;label,arm=sys.argv[1:]
m=json.loads((F/'WORKSPACE_READY.json').read_text())['versions'][arm];W=Path(m['workspace']);sys.path.insert(0,str(W/'src'))
from swarm_rescue.solutions.bearing_memory import BearingMemory
from swarm_rescue.solutions.finite_output import FiniteOutputMemory
from swarm_rescue.solutions.thin_output_union import thin_output_union
from swarm_rescue.solutions.my_drone_eval import MyDroneEval
checks=[]
def require(v,name):assert v,name;checks.append(name)
def same(a,b):
    if isinstance(a,np.ndarray):return isinstance(b,np.ndarray)and np.array_equal(a,b)
    if isinstance(a,(list,tuple)):return type(a)is type(b)and len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
    return a==b
base=BearingMemory(640,480,identifier=0,team_size=5)
new=FiniteOutputMemory(640,480,identifier=0,team_size=5)
for memory in [base,new]:memory.frame_records={};memory.frame_negative={}
angles=np.linspace(-np.pi,np.pi,180,endpoint=False)
for t in range(12):
    pos=np.array([-22.+4*t,-100.]);sine=np.sin(angles)
    distances=np.where(sine>1e-9,np.divide(200.,sine,out=np.ones_like(sine)*300,where=sine>1e-9),300.)
    distances=np.minimum(distances,300.)
    semantic=[SimpleNamespace(entity_type=SimpleNamespace(name='BOMB'),angle=np.pi/2,distance=200.)]if t==5 else []
    for memory in [base,new]:memory.step=t*4;memory.observe(pos,0.,distances,angles,semantic)
    require(all(np.array_equal(v,getattr(new,k))for k,v in base.__dict__.items()if isinstance(v,np.ndarray)),f'observation{t}_baseline_arrays_identical')
    require(same(base.packet(),new.packet()),f'observation{t}_actual_packet_identical')
require(new._output_support_frames==12,'only12_actual_observation_epochs_counted')
require(new._output_support_segments>0,'actual_finite_segment_collection_triggered')
new.observe(pos,0.,distances,angles,semantic)
require(new._output_support_frames==12,'duplicate_epoch_adds_no_new_output_vote')
# Duplicate observe above also legitimately changes parent raw hits; restore
# equality with exactly the same public parent observation before comparisons.
base.observe(pos,0.,distances,angles,semantic)
values=np.ones(base.shape,np.float32)
with contextlib.redirect_stdout(io.StringIO()):
    va=base.bearing_wall_values(values);vb=new.bearing_wall_values(values)
    require(np.array_equal(va,vb),'actual_planner_wall_value_interface_unchanged')
    old_image=BearingMemory.render(new).copy();before={k:v.copy()for k,v in new.__dict__.items()if isinstance(v,np.ndarray)}
    new_image=new.render()
require(np.all(new_image>=old_image),'render_preserves_every_original_pixel')
require(all(np.array_equal(v,getattr(new,k))for k,v in before.items()),'render_does_not_mutate_navigation_arrays')
require(same(base.packet(),new.packet()),'render_does_not_change_actual_packet')
require(MyDroneEval.__mro__[1].__name__=='FiniteOutputMixin','actual_entry_MRO_uses_one_output_adapter')
require(not any(c.__name__=='ColoredPoseMixin'for c in MyDroneEval.__mro__),'failed_P03_pose_rule_absent')
others=[FiniteOutputMemory(640,480,identifier=i,team_size=5)for i in range(5)]
require(len({id(v._output_support.counts)for v in others})==5,'five_independent_output_support_arrays')
parent=np.zeros((160,160),np.uint8);parent[50:52,50:52]=1;counts=np.zeros((80,80),np.uint32)
out,a=thin_output_union(parent,counts,fine=2,cell=16);require(np.array_equal(out,parent),'no_support_no_output_change')
counts[60,60]=1;out,a=thin_output_union(parent,counts,fine=2,cell=16);require(np.array_equal(out,parent),'single_support_not_promoted')
counts[60,60]=2;out,a=thin_output_union(parent,counts,fine=2,cell=16);require(a['added_pixels']==4,'repeated_far_support_adds_only_one_fine_cell')
require(np.all(out>=parent),'original_wall_geometry_never_removed')
banned=np.zeros_like(counts,bool);banned[60,60]=True
out,a=thin_output_union(parent,counts,fine=2,cell=16,nonwall=banned);require(np.array_equal(out,parent),'actual_nonwall_mask_remains_authoritative')
counts[:]=0;counts[25,30]=2;counts[0,40]=2
out,a=thin_output_union(parent,counts,fine=2,cell=16);require(np.array_equal(out,parent),'existing_wall_neighborhood_and_frame_band_protected')
result=dict(status='PASS_ACTUAL_OUTPUT_ADAPTER_CONTRACT',checks=checks,source_sha256=m['sources'],
 frames=new._output_support_frames,segments=new._output_support_segments,
 native_rounds=0,physics_steps=0,scope='Actual candidate memory/packet/planner/render methods plus output invariants; same public observations and clocks, no physical trajectory or game-score claim.')
(F/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],checks=len(checks),frames=result['frames'],segments=result['segments'])))
