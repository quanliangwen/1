from pathlib import Path
import subprocess
F=Path(__file__).resolve().parent
R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025'
code='''from pathlib import Path
files=[Path(H)/'F32_official_sdk_20261028/postscore_visual_evaluator_v2.py',Path(H)/'F32_official_sdk_20261028/public_visual_export_v2.py']
for p in files:
 lines=p.read_text().splitlines();selected=set()
 for i,s in enumerate(lines):
  if any(k in s for k in ['submitted_map','explored_map','exploration_map','_submitted','submitter']):selected.update(range(max(0,i-3),min(len(lines),i+5)))
 print(str(p))
 for i in sorted(selected):print(str(i+1)+': '+lines[i])
'''.replace('Path(H)', 'Path('+repr(H)+')')
run=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60',R+'/.venv/bin/python','-'],input=code,text=True,capture_output=True,timeout=25)
(F/'SUBMISSION_SOURCE_CONTRACT.txt').write_text(run.stdout+run.stderr,encoding='utf-8');print(run.stdout);print(run.stderr)
raise SystemExit(run.returncode)
