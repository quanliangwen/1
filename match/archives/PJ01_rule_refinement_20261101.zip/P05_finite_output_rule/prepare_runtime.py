from pathlib import Path
F=Path(__file__).resolve().parent;P=F.parent/'P03_proven_pose_rule'
s=(P/'run_offline.py').read_text(encoding='utf-8').replace('max4','max2').replace('P03','P05')
s=s.replace('max_native_rounds=4','max_native_rounds=2').replace('[COLORED_POSE]','[FINITE_OUTPUT]').replace('pose_event_count','output_event_count')
s=s.replace('builtin_goal_edit_resume_pending=True','builtin_goal_active=True')
(F/'run_offline.py').write_text(s,encoding='utf-8')
s=(P/'collect_offline.py').read_text(encoding='utf-8').replace('PJ01_rules_P03_pose_20261101','PJ01_rules_P05_finite_output_20261101').replace('P03','P05')
s=s.replace("['PJ01_A','P05_A']","['P05_A']").replace('pose_event_count','output_event_count')
(F/'collect_offline.py').write_text(s,encoding='utf-8')
for n in ['start_local_collector.py','launch_campaign.py']:
    s=(P/n).read_text(encoding='utf-8').replace('max_native_rounds=4','max_native_rounds=2').replace('builtin_goal_edit_resume_pending=True','builtin_goal_active=True')
    (F/n).write_text(s,encoding='utf-8')
print('Prepared finite P05 Map02 only, max2 native; no games started.')
