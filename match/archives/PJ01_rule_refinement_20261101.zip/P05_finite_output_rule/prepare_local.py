from pathlib import Path
import ast,hashlib,json,shutil
F=Path(__file__).resolve().parent;B=F.parent/'P01_baseline_rules/baseline_project';A=F.parent/'P04_existing_finite_wall_audit'
read=lambda p:json.loads(p.read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert read(A/'CHECKS_COMPARISON.json')['thin_union_passes_declared_static_gate']
C=F/'candidate_project';assert not C.exists();shutil.copytree(B,C,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
S=C/'src/swarm_rescue/solutions'
for name in ['finite_wall_support.py','thin_output_union.py']:shutil.copy2(A/name,S/name)
shutil.copy2(F/'finite_output.py',S/'finite_output.py')
p=S/'my_drone_eval.py';s=p.read_text(encoding='utf-8')
marker='class MyDroneEval(BearingMappingMixin,';assert s.count(marker)==1
s='from swarm_rescue.solutions.finite_output import FiniteOutputMixin\n'+s.replace(marker,'class MyDroneEval(FiniteOutputMixin,BearingMappingMixin,',1)
p.write_text(s,encoding='utf-8')
for p in S.glob('*.py'):ast.parse(p.read_text(encoding='utf-8-sig'))
files={p.relative_to(C).as_posix():sha(p)for p in C.rglob('*')if p.is_file()}
base={p.relative_to(B).as_posix():sha(p)for p in B.rglob('*')if p.is_file()and'__pycache__'not in p.parts}
changed=sorted(n for n,v in files.items()if base.get(n)!=v)
assert changed==['src/swarm_rescue/solutions/finite_output.py','src/swarm_rescue/solutions/finite_wall_support.py','src/swarm_rescue/solutions/my_drone_eval.py','src/swarm_rescue/solutions/thin_output_union.py']
out=dict(status='PREPARED_ONE_OUTPUT_RULE_NOT_SDK_QUALIFIED',files=files,changed_files=changed,candidate_project=str(C),
 base='OriginalPJ0136Py',P02_included=False,P03_included=False,only_one_logical_rule=True,
 control_map_arrays_and_packets_unchanged_design=True,extra_runtime_may_indirectly_change_wallclock_decisions=True,
 static_same_input_tests=dict(original8_positive=4,original8_unchanged=4,ceiling4_unchanged=4,not_game_scores=True),official_submission_ready=False)
(F/'CANDIDATE_MANIFEST.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=out['status'],changed_files=changed)))
