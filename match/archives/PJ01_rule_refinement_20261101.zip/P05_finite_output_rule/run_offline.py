"""Latest human-scoped PJ01 one-rule single-map comparison, max2 native."""
from pathlib import Path
import importlib.util,json,fcntl,os,time,traceback
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025';F=Path(__file__).resolve().parent
P=H/'F32_official_sdk_20261028/FIVE_MAP_REBASELINE'
spec=importlib.util.spec_from_file_location('original_frozen_runner',P/'run_offline.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.F=F;b.D=json.loads((F/'PREDECLARATION.json').read_text());b.NAMES=b.D['selection'];b.BLUE=b.D['blue_binding'];b.WBLUE=Path(b.BLUE['blue_workspace'])
b.STATE.update(phase=F.name,completed=[],decisions=[],max_native_rounds=2,automatic_five=False)
original_state=b.state
def state(status,**kw):original_state('RUNNING_SINGLE_MAP_COMPARISON' if status=='RUNNING_FIVE_MAPS' else status,**kw)
b.state=state
def summarize():
    b.save(F/'RESULT.json',dict(b.STATE,automatic_five=False,ranking_promoted=False,automation90_active=True,builtin_goal_active=True))
b.summarize=summarize
def first_review(group):
    p=group/'CLIENT_FIRST_RAW_REVIEW.json';start=time.monotonic()
    while not p.exists():
        if b.stop_requested():raise RuntimeError('Human stop during first client review')
        if time.monotonic()-start>7200:raise TimeoutError('First Windows byte review missing; no next native')
        state('AWAIT_FIRST_WINDOWS_REVIEW',group=group.name);time.sleep(5)
    proof=json.loads(p.read_text());raw=json.loads((group/'RAW_ARCHIVE_RECEIPT.json').read_text())
    assert proof['status']=='PASS' and proof['archive_sha256']==raw['sha256']
def mechanism(item):
    G=F/(item['version']+'_'+item['cohort']);matrix=json.loads((G/'RESULT.json').read_text());row=matrix['jobs']['Map02']['rounds'][0]
    result=Path(json.loads((G/'LAUNCH.json').read_text())['result']);events=[]
    for line in (result/'Map02_red/console.log').read_text(errors='replace').splitlines():
        if '[FINITE_OUTPUT] ' in line:events.append(json.loads(line.split('[FINITE_OUTPUT] ',1)[1]))
    out=dict(version=item['version'],map='Map02',score=row['full_score'],phase=row['phase'],placed=row['placed'],expected=row['expected'],
        red_wall_hit=row.get('red_max_walltime_reached',False),blue_wall_hit=row['blue'].get('max_walltime_reached',False),
        output_event_count=len(events),events=events,red_walltime=row['red_walltime'],red_steps=row['red_steps'],
        scope='Unseeded original Map02 only; no five-map mean or stable improvement claim. No private BLUE console/arrays read.')
    b.save(G/'MECHANISM_REVIEW.json',out);return out
def main():
    lease=(F/'coordinator.lock').open('a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not(F/'RUN_ONCE.json').exists();b.save(F/'RUN_ONCE.json',dict(utc=b.utc(),pid=os.getpid(),starttime_ticks=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],driver_sha256=b.sha(__file__),predeclaration_sha256=b.sha(F/'PREDECLARATION.json')))
    b.STATE['started_utc']=b.utc();b.validate_frozen();summarize()
    try:
        for item in b.D['schedule']:
            if b.stop_requested():state('STOPPED_BEFORE_NEXT_GROUP');summarize();return
            if not b.run_cohort(item):state('STOPPED_BEFORE_NATIVE_START');summarize();return
            G=F/(item['version']+'_'+item['cohort']);first_review(G);b.STATE['decisions'].append(mechanism(item));summarize()
        state('COMPLETE_FINITE_STAGED_CAMPAIGN',current=None);summarize()
    except Exception:
        b.save(F/'FIRST_ERROR.json',dict(utc=b.utc(),traceback=traceback.format_exc(),first_native_failure=b.STATE['first_native_failure'],no_retry=True));state('STOPPED_FIRST_ERROR_NO_RETRY');summarize();raise
if __name__=='__main__':main()
