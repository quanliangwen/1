"""Validate the pure-pixel union bound with authored masks and official scorer.

Never loads competition truth, NPZ or pickle. Uses only public reported N,K
after checking the default scorer on independently authored pixel masks.
"""
from pathlib import Path
import json,sys
import numpy as np
F=Path(__file__).resolve().parent;label=sys.argv[1]
m=json.loads((F/'WORKSPACE_READY.json').read_text())['versions']['PJ01'];W=Path(m['workspace']);sys.path.insert(0,str(W/'src'))
from swarm_rescue.tools.map_exploration_scoring import MapExplorationScorer
scorer=MapExplorationScorer();cfg=scorer.config
assert cfg.w_map==1 and cfg.w_time==0 and cfg.w_wall==1 and cfg.w_interior==0
assert cfg.penalty_weight==.2 and cfg.penalty_cap==1
rows=[];rng=np.random.default_rng(615)
truth=np.zeros((160,200),np.uint8);truth[20:26,10:190]=1;truth[90:96,10:190]=1;truth[20:96,10:16]=1
for density in [.25,.90]:
    for k in [1,4,16,400]:
        baseline=(truth*(rng.random(truth.shape)<density)).astype(np.uint8)
        stray=rng.choice(baseline.size,size=100,replace=False);baseline.ravel()[stray]=1
        remaining=np.flatnonzero(baseline.ravel()==0);added=rng.choice(remaining,size=k,replace=False)
        alternate=baseline.copy();alternate.ravel()[added]=1
        a=scorer.score(truth,baseline,0);b=scorer.score(truth,alternate,0)
        n=a.surface_pixels;low=-100*cfg.penalty_weight*cfg.penalty_cap*k/n;high=100*k/n
        delta=b.score-a.score
        assert b.credit+1e-10>=a.credit
        assert low-1e-5<=delta<=high+1e-5,(density,k,delta,low,high)
        rows.append(dict(density=density,added=k,delta=delta,lower=low,upper=high,credit_monotone=True))
out=dict(status='PASS_OFFICIAL_SCORER_UNION_BOUND_ON8_AUTHORED_MASKS',checks=rows,
 formula='For unchanged input parent P and union Q=P union A, K=|A\\P|, N=wall-surface pixels: -100*.2*K/N <= S(Q)-S(P) <=100*K/N; credit cannot fall. Clipping to[0,100] preserves these bounds.',
 competition_truth_loaded=False,native_rounds=0,production_modified=False)
(F/(label+'.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status=out['status'],cases=len(rows),competition_truth_loaded=False)))
