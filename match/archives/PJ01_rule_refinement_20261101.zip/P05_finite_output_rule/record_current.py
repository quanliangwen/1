from pathlib import Path
import datetime,json
F=Path(__file__).resolve().parent;A=F.parent/'P04_existing_finite_wall_audit'
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
text=f'''P05：原PJ01上的单条“仅提交图有限实测墙段补充”规则。记录UTC{now}。

用户目标和automation90均ACTIVE，持续分析改进直到用户停止。原PJ01独立底本，P02/P03均已拒绝，不叠加。P03实赛地图95.625739→93.828117、完整74.795606→73.114139，虽误绘少1.018但墙命中少2.816，10/10无超时；30raw首次核验PASS，不五图不重跑。

分析依据与小检查顺序：
1. 旧R150/R158仅输出端有限墙段支持有同轨迹地图改善的局部SDK证据；但另一框架，不能直接算PJ01改善。
2. 核到PJ01原始墙点只收<220px，而旧有限墙段规则使用同一真实激光的<280px连续回波；有潜在信息缺口，但PJ01已有原TLS/Hough/边界框架/多方向墙支持，先实际类检查。
3. P04在原PJ01真实pose/frame/anchor/Memory/render和原SDK评分上做8个预定同输入作者场景，直接把有限支持并入hits后重拟合，8例都提高（+3.06..28.28）；原控制数组不改。但随后单独事前固定的4个高精度反例全部退步（-0.23..-6.85），最差信用也下降0.698，误绘多6.155。由此拒绝直接重拟合接法，未开任何比赛。它们是静态输入作者场景，不是比赛地图或实赛分。
4. 针对新旧几何冲突，改为保留原提交图每个像素，有限支持只作薄层集合并集；不能移动、加粗或重新拟合旧墙。原细格2px、重复支持>=2，距旧墙2个原粗格32px外才补，边界2个粗格32px区仍由原边界/开口先验支配，原nonwall mask保留权威。支持次数不冒充独立概率置信度。
5. 相同原8输入，薄层并集4改善/4不变，无退步；原4高精度反例全不变。原像素全保留是结构性质，不保证地图总分不降，因为新增误绘仍可能扣分。固定参数与反例全部保留，未挑seed删失败。

P05生产适配只有4文件：my_drone_eval.py在原MRO外层加FiniteOutputMixin；新增finite_output.py、历史finite_wall_support.py、已检查thin_output_union.py。原PJ01全部36个既有Python除入口外不改；没有终点修复、滤波、MILP、QP或旧A*规则框架。Memory观察先原方法一次，再将同一公共输入送到独立有限支持数组；发包、导航hits/free/visits/blocked、原bearing_wall_values不接该数组。仅原control提交时调用render，原渲染后作薄层并集。不读真图/队友对象/BLUE私态，不新增消息字段。

实际40条接口与属性检查PASS（其中24是12次观察的数组/通信包核对，不是40独立场景）：真实Memory观察/packet/规划墙值/提交图、重复epoch不增加补图票、原像素保留、不变通信/规划数组、nonwall/边界/近墙保护、5机独立支持实例、MRO无滤波。真实NumPy mtrand/随机数/Pandas/OpenCV/SDK入口/整数615/原Map01五构造PASS，均0物理步。这些支持进入一次完整原条件单图闭环，不是原生成绩或官网发布检查。

原资源Map02 P05红蓝各一局，最多2native，UTC04:12:58已启动：coordinator2121706/start397673276；Windowscollector94968/UTC04:12:56，14h有限收集。先核实时/proc命令/start、锁、registry，不重复启动等待/活动队列。原SDK e2f022b/team006/限时线程/无外部seed、CPU60/loadcore.4/RAM8GiB/盘12GiB/两样本60秒不变。
复用刚完成且已首审的P03阶段原PJ01Map02对照（地图95.625739、完整74.795606），源码相同、无需重复下载原始归档或重跑原版；不同随机局只描述观察差，不称同seed配对因果。
事前小试门槛：实际FINITE_OUTPUT新增像素>=1、地图较对照至少+.5、完整分不低于对照、10/10、双方无墙钟hit。达到也先分析机制与分项才安排新同期完整五图；不自动扩、不调门槛救分。首native错误停链保存，不重试。
内层额外计算仍消耗真实墙钟，可能间接影响预算/终止；不能声称整场运动或成绩必然不变。

正式V06/V07/V08及依赖不改，不发布上传。原始NPZ/pickle只字节首核，不反序列化，不读BLUE私有日志。C7取消、原固定90分钟全量对照不恢复。
'''
(F/'分析依据与测试记录.txt').write_text(text,encoding='utf-8')
(A/'小测试结论与不直接移植原因.txt').write_text(text.split('P05生产适配')[0],encoding='utf-8')
(F/'WORKING_HANDOFF_P05.txt').write_text(f'''LATEST {now}: 当前P05_finite_output_rule，持续目标及automation90 ACTIVE。先读分析依据与测试记录.txt、STATUS/RESULT/CAMPAIGN_CLIENT_REVIEW。
原PJ01独立底本，单条提交图有限支持薄并集规则；P02/P03失败均不叠加。P03实际Map02总73.114139/地图93.828117，不五图不重跑。P04旧有限支持重拟合虽原8例全提高，但高精度4反例全退步最差-6.85，因此拒绝该接法。
新薄并集保留所有原像素，离旧墙32px且避边界32px才补2px实测连续段，同12输入4提高/8不变；真实40断言/实际ABI SDK5constructorsPASS。是建图输出规则，原导航/通信/布局数组不变，额外计算墙钟仍可能影响预算。4文件差异，源码/内部ZIP已冻结不能运行中改。
原Map02单候选最多2native已离线启动2121706/start397673276UTC04:12:58，Windowscollector94968UTC04:12:56。先核实时cmd/start/锁/registry，等待也占用，不重复队列。复用P03里已审原PJ01Map02控制：图95.625739/总74.795606；不重复审旧归档。
门槛实际有新增像素、图>=96.125739、总>=74.795606、10枚/双方无hit。首真实失败保存停链，不重试救分；通过先分析才完整同期五图，不自动扩。低分停止候选，继续证据导向下一规则，不只轮询COMPLETE。
SDK e2f022b/team006/原线程时限/资源两样本门槛不变，旧高负载授权耗尽。原始数组只字节不反序列化，无BLUE私态/真图决策/硬编码坐标。正式包不改，用户停止立即暂停。
''',encoding='utf-8')
idx=Path('E:/codex/swarm-eod-literature-analysis/CURRENT_ACTIVE_ANALYSIS.txt')
idx.write_text(f'''LATEST {now}: Goal andautomation90 ACTIVE; current{F}/WORKING_HANDOFF_P05.txt. P03finishedreject map95.625739→93.828117 total74.795606→73.114139,30rawfirstPASS. P04directfiniteoverlay8positiveBUT4ceilingnegativeworst-6.85, reject; thinunion preservesallparentpixels andsame12cases4improve8same. P05oneoutputrule40actualchecks/ABI/SDK5constructorsPASS, baselinePJ01 noP02/P03, noMILP/QP. SingleMap02P05redblue max2native launched2121706/start397673276UTC04:12:58, Windowscollector94968UTC04:12:56, don'tduplicate. ReusejustreviewedP03PJ01Map02control. Gate actualadded>0,map+.5,totalnotlower,10of10/nohits. OriginalSDKblueclocksresourceunchanged. Noautomaticfive orrelease. C7cancelled/no90minblindfive. Oncecomplete analyze andcontinue evidence-driven rules.\n\n'''+idx.read_text(encoding='utf-8'),encoding='utf-8')
print(json.dumps(dict(status='RECORDED_P05_ACTIVE_SINGLE_MAP_AND_COUNTEREXAMPLES',utc=now)))
