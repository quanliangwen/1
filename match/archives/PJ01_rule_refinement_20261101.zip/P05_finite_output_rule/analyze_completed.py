from pathlib import Path
import datetime,json
F=Path(__file__).resolve().parent;P=F.parent/'P03_proven_pose_rule'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
assert read(F/'CAMPAIGN_CLIENT_REVIEW.json')['status']=='PASS'
assert read(F/'LOCAL_COLLECTOR_RESULT.json')['status']=='COMPLETE'
assert read(F/'P05_A/CLIENT_FIRST_RAW_REVIEW.json')['status']=='PASS'
baseline=read(P/'PJ01_A/MECHANISM_REVIEW.json');candidate=read(F/'P05_A/MECHANISM_REVIEW.json')
assert read(P/'PJ01_A/CLIENT_FIRST_RAW_REVIEW.json')['status']=='PASS'
events=candidate['events'];owners=sorted({e['owner']for e in events})
# Frozen evaluator selects first non-null submission in map's id-ordered drone
# list. Source audit confirms render is used only by the submission call. With
# no native error, infer selected owner; this is not a submitted-image SHA proof.
selected_owner=min(owners)if owners else None
selected_events=[e for e in events if e['owner']==selected_owner]
selected_added=max((e['added_pixels']for e in selected_events),default=0)
rows=[]
for d in [baseline,candidate]:
    p=d['phase'];b=p['map_breakdown']
    rows.append(dict(version=d['version'],total=d['score'],map_score=p['score_map'],wall=p['score_wall'],time=p['score_time'],
      trajectory=p['score_exploration_trajectory'],placed=d['placed'],expected=d['expected'],red_steps=d['red_steps'],red_wall_seconds=d['red_walltime'],
      red_wall_hit=d['red_wall_hit'],blue_wall_hit=d['blue_wall_hit'],map_credit_pp=100*b['credit'],false_drawing_pp=100*b['penalty']))
delta={k:rows[1][k]-rows[0][k]for k in ['total','map_score','wall','time','trajectory','placed','red_steps','red_wall_seconds','map_credit_pp','false_drawing_pp']}
gate=dict(actual_nonzero_selected_output_addition=selected_added>=1,map_gain_at_least_half=delta['map_score']>=.5,
 full_not_below_reference=delta['total']>=0,all10_placed=rows[1]['placed']==rows[1]['expected']==10,
 no_red_blue_clock_hits=not(rows[1]['red_wall_hit']or rows[1]['blue_wall_hit']))
out=dict(status='REVIEWED_SINGLE_MAP_MECHANISM_AND_SCORE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 rows=rows,delta_P05_minus_PJ01=delta,events=events,submitted_owner_inferred=selected_owner,selected_added_pixels_inferred=selected_added,
 binding_scope='Owner inference from frozen evaluator order and own submit-only render logs; no submitted-image SHA was logged, cannot claim exact byte binding.',
 gate=gate,eligible_for_five_analysis=all(gate.values()),automatic_five_started=False,
 reused_previous_control_first_archive_not_reverified=True,stable_causal_effect_established=False)
(F/'REVIEWED_COMPARISON.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in out.items()if k!='events'},ensure_ascii=False))
