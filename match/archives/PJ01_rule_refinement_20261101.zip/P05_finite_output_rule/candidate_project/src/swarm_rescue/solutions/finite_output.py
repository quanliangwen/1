"""Output-only finite wall support; original navigation memory remains intact."""
import json
import math
import time
import numpy as np
from swarm_rescue.solutions.bearing_memory import BearingMemory
from swarm_rescue.solutions.finite_wall_support import FiniteWallSupport,from_actual_scan
from swarm_rescue.solutions.thin_output_union import thin_output_union

class FiniteOutputMemory(BearingMemory):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self._output_support=FiniteWallSupport(self.width,self.height,fine=self.FINE)
        self._output_support_frames=0
        self._output_support_segments=0
        self._output_support_seconds=0.
        self._output_render_prints=0

    def observe(self,position,heading,distances,ray_angles,semantic=()):
        super().observe(position,heading,distances,ray_angles,semantic)
        stamp=float(self.step)
        if not math.isfinite(stamp) or stamp<0 or stamp!=int(stamp) or stamp<=self._output_support.last:return
        started=time.perf_counter()
        excluded=self.semantic_mask(distances,ray_angles,semantic)
        segments=from_actual_scan(position,heading,distances,ray_angles,excluded)
        self._output_support.update(step=int(stamp),pose=position,heading=float(heading),segments=segments)
        self._output_support_frames+=1
        self._output_support_segments+=len(segments)
        self._output_support_seconds+=time.perf_counter()-started

    def render(self):
        started=time.perf_counter()
        parent=super().render()
        image,audit=thin_output_union(parent,self._output_support.counts,fine=self.FINE,cell=self.CELL,
                                     nonwall=getattr(self,'nonwall_mask',None))
        if self._output_render_prints<4:
            print('[FINITE_OUTPUT] '+json.dumps(dict(owner=int(self.identifier),step=int(self.step),
                frames=self._output_support_frames,segments=self._output_support_segments,
                finite_support_seconds=self._output_support_seconds,render_seconds=time.perf_counter()-started,**audit)),flush=True)
            self._output_render_prints+=1
        return image

class FiniteOutputMixin:
    def __init__(self,identifier=None,misc_data=None,**kwargs):
        super().__init__(identifier=identifier,misc_data=misc_data,**kwargs)
        self.memory=FiniteOutputMemory(*self.size_area,identifier=int(identifier or 0),team_size=self.team_size)
        self.memory.frame_records=self.frame_records
        self.memory.frame_negative=self.frame_negative
