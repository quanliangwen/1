"""Exact packaged controller source path and public memory entry contracts."""
import ast
import inspect
import unittest
from types import SimpleNamespace

import numpy as np

from swarm_rescue.solutions.my_drone_eval import MyDroneEval
from swarm_rescue.solutions.bearing_memory import BearingMappingMixin, BearingMemory
from swarm_rescue.solutions import route_columns


class BearingEntryContracts(unittest.TestCase):
    def make_drone(self):
        return MyDroneEval(identifier=0, misc_data=SimpleNamespace(
            size_area=(320, 320), number_drones=5,
            max_timestep_limit=2000, max_walltime_limit=90))

    def test_mro_and_actual_memory_replacement(self):
        drone = self.make_drone()
        self.assertIs(MyDroneEval.mro()[1], BearingMappingMixin)
        self.assertIsInstance(drone.memory, BearingMemory)
        self.assertIs(drone.memory.frame_records, drone.frame_records)
        self.assertIs(drone.memory.frame_negative, drone.frame_negative)

    def test_packaged_public_observe_message_and_render(self):
        drone = self.make_drone()
        m = drone.memory
        m.step = 4
        m.observe(np.array([-20., 0.]), 0., [20.], [0.])
        m.step = 8
        m.observe(np.array([0., -20.]), 0., [20.], [np.pi / 2])
        packet = m.packet()
        self.assertEqual(len(packet), 2)
        self.assertEqual(len(packet[0]), 4)
        self.assertTrue(m.bearing_bits.any())
        image = m.render()
        self.assertEqual(image.shape, (320, 320))
        self.assertTrue(np.isfinite(image).all())
        other = BearingMemory(320, 320, identifier=1, team_size=5)
        other.merge(packet)
        np.testing.assert_array_equal(other.bearing_bits, m.bearing_bits)

    def test_layout_reads_new_value_from_source_memory(self):
        tree = ast.parse(inspect.getsource(route_columns.solve_route_columns))
        calls = [ast.unparse(node.func) for node in ast.walk(tree) if isinstance(node, ast.Call)]
        self.assertIn('memory.bearing_wall_values', calls)


if __name__ == '__main__':
    unittest.main()
