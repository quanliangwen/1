"""Finite public-array contracts for the farthest residual layout."""
import importlib.util
from pathlib import Path
import unittest

import numpy as np


spec = importlib.util.spec_from_file_location(
    "farthest_wall_cover",
    Path(__file__).parent / "source" / "farthest_wall_cover.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class FarthestWallContracts(unittest.TestCase):
    @staticmethod
    def fixtures():
        values = np.zeros((5, 11), float)
        values[2, 1] = values[2, 3] = values[2, 9] = 1
        allowed = np.zeros_like(values, bool)
        allowed[2, [1, 3, 9]] = True
        yy, xx = np.indices(values.shape, dtype=float)
        return values, allowed, xx, yy

    def test_far_residual_site_precedes_near_site(self):
        values, allowed, xx, yy = self.fixtures()
        field = np.zeros_like(values)
        result, work = module.farthest_layout(
            values, allowed, xx, yy, 1.1, 1., [0], [2], [field],
            lambda cell: field, 100., 1.)
        self.assertEqual(result[0], [(2, 1), (2, 9)])
        self.assertEqual(work["selected"], 2)

    def test_inventory_and_geodesic_budget(self):
        values, allowed, xx, yy = self.fixtures()
        field = np.full_like(values, np.inf)
        field[2, 3] = 2
        result, _ = module.farthest_layout(
            values, allowed, xx, yy, 1.1, 1., [4], [1], [field],
            lambda cell: field, 2., 1.)
        self.assertEqual(result[4], [(2, 3)])

    def test_no_legal_site_never_invents_target(self):
        values, allowed, xx, yy = self.fixtures()
        result, work = module.farthest_layout(
            values, np.zeros_like(allowed), xx, yy, 1.1, 1., [0], [2],
            [np.zeros_like(values)], lambda cell: np.zeros_like(values),
            100., 1.)
        self.assertEqual(result, {0: []})
        self.assertEqual(work["selected"], 0)

    def test_nonfinite_public_mass_rejected(self):
        values, allowed, xx, yy = self.fixtures()
        values[2, 3] = np.nan
        with self.assertRaises(ValueError):
            module.farthest_layout(
                values, allowed, xx, yy, 1.1, 1., [0], [1],
                [np.zeros_like(values)], lambda cell: np.zeros_like(values),
                100., 1.)


if __name__ == "__main__":
    unittest.main()
