"""Independent finite public-ray and packaged memory contracts."""
import math
import unittest

import numpy as np

from swarm_rescue.solutions.bearing_core import (
    corroborated_map, hit_direction_bits, independent_incidence,
)
from swarm_rescue.solutions.bearing_memory import BearingMemory


class BearingContracts(unittest.TestCase):
    def test_world_angle_wrap_and_semantic_exclusion(self):
        ids, bits = hit_direction_bits((-20., 0.), 2 * math.pi,
                                        [20., 20.], [0., math.pi / 2],
                                        [False, True], 64, 64)
        self.assertEqual(len(ids), 1)
        self.assertEqual(int(bits[0]), 1)
        ids2, bits2 = hit_direction_bits((0., -20.), 0., [20.],
                                          [math.pi / 2], [False], 64, 64)
        self.assertEqual(int(ids[0]), int(ids2[0]))
        self.assertEqual(int(bits2[0]), 4)

    def test_separation_rejects_same_and_adjacent_only(self):
        self.assertFalse(bool(independent_incidence(np.array([1, 3, 129], np.uint8)).any()))
        self.assertTrue(bool(independent_incidence(np.array([5], np.uint8))[0]))
        self.assertTrue(bool(independent_incidence(np.array([65], np.uint8))[0]))

    def test_same_source_frame_and_received_or_are_idempotent(self):
        m = BearingMemory(64, 64, identifier=0, team_size=5)
        m.step = 0
        m.observe(np.array([-20., 0.]), 0., np.array([20.]), np.array([0.]))
        once = m.bearing_bits.copy()
        m.observe(np.array([-20., 0.]), 0., np.array([20.]), np.array([0.]))
        np.testing.assert_array_equal(m.bearing_bits, once)
        m.step = 4
        m.observe(np.array([0., -20.]), 0., np.array([20.]), np.array([math.pi / 2]))
        self.assertTrue(bool(independent_incidence(m.bearing_bits).any()))
        packet = m.packet()
        peer = BearingMemory(64, 64, identifier=1, team_size=5)
        peer.merge(packet)
        first = peer.bearing_bits.copy()
        peer.merge(packet)
        np.testing.assert_array_equal(peer.bearing_bits, first)
        self.assertTrue(bool(independent_incidence(first).any()))

    def test_nonwall_retraction_and_legacy_parent_packet(self):
        source = BearingMemory(64, 64, identifier=0, team_size=5)
        source.step = 0
        source.observe(np.array([-20., 0.]), 0., [20.], [0.])
        receiver = BearingMemory(64, 64, identifier=1, team_size=5)
        receiver.merge(source.packet())
        self.assertTrue(receiver.bearing_bits.any())
        receiver.nonwall_mask = np.zeros(receiver.hits.shape, bool)
        receiver.nonwall_mask[16, 16] = True
        receiver.merge(source.packet())
        self.assertFalse(receiver.bearing_bits.any())
        receiver.merge(source.packet()[0])
        self.assertFalse(receiver.bearing_bits.any())

    def test_output_adds_only_measured_two_angle_cells(self):
        parent = np.zeros((128, 128), np.uint8)
        hits = np.zeros((64, 64), np.uint8)
        bits = np.zeros((32, 32), np.uint8)
        hits[32, 32] = 2
        bits[16, 16] = 5
        out, audit = corroborated_map(parent, hits, bits, 128, 128)
        self.assertEqual(audit['qualified_cells'], 1)
        self.assertGreater(audit['added_pixels'], 0)
        self.assertEqual(int(out[0, 0]), 0)
        bits[16, 16] = 3
        out2, audit2 = corroborated_map(parent, hits, bits, 128, 128)
        self.assertEqual(audit2['qualified_cells'], 0)
        self.assertFalse(out2.any())


if __name__ == '__main__':
    unittest.main()
