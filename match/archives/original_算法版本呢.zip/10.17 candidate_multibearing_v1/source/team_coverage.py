"""Team coverage allocation using only sensor memory and received messages.

Public entry: plan_team_coverage(memory, agents, drops, radius, travel_budget).
agents maps drone IDs to (sensor-estimated position, remaining inventory).
travel_budget is a path-length budget in pixels; omit for unlimited planning.
The result is {drone_id: [world-position, ...]}. No simulator imports or truth.

The caller should broadcast plans from one elected coordinator, include a
monotonic epoch and lease, and acknowledge placements by inventory decreases.
Recompute after each acknowledged placement or changed map/position evidence.
"""
from __future__ import annotations

import heapq
import math
import cv2
import numpy as np
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory


from swarm_rescue.solutions.coverage_geometry import geometry_wall_values

def observed_wall_values(memory,radius,return_solids=False):
    if isinstance(memory,GeometryPlanningMemory):
        cached=getattr(memory,'_coverage_values_cache',None)
        if cached is None or cached[0]!=float(radius):
            values,solids=geometry_wall_values(memory,radius,return_solids=True,line_width=12)
            cached=(float(radius),values,solids);memory._coverage_values_cache=cached
        return (cached[1].copy(),cached[2].copy()) if return_solids else cached[1].copy()
    return geometry_wall_values(memory,radius,return_solids=return_solids,line_width=12)

def path_costs(memory, walkable, start):
    """Same exact eight-neighbour metric; local adjacency avoids array overhead."""
    allowed=np.asarray(walkable,bool).copy()
    start=tuple(start);allowed[start]=True
    shape=allowed.shape;h,w=shape
    cached=getattr(memory,'_coverage_graph_cache',None)
    if cached is None or cached[0].shape!=shape or not np.array_equal(cached[0],allowed):
        adjacency=[[] for _ in range(h*w)]
        for dr,dc in ((0,1),(0,-1),(1,0),(-1,0),(1,1),(1,-1),(-1,1),(-1,-1)):
            r0,r1=max(0,-dr),min(h,h-dr);c0,c1=max(0,-dc),min(w,w-dc)
            valid=allowed[r0:r1,c0:c1]&allowed[r0+dr:r1+dr,c0+dc:c1+dc]
            if dr and dc:valid &= allowed[r0+dr:r1+dr,c0:c1]&allowed[r0:r1,c0+dc:c1+dc]
            rr,cc=np.nonzero(valid);origin=(rr+r0)*w+cc+c0
            dest=origin+dr*w+dc;weight=math.sqrt(2) if dr and dc else 1.
            for a,b in zip(origin.tolist(),dest.tolist()):adjacency[a].append((b,weight))
        memory._coverage_graph_cache=(allowed,adjacency)
    else:adjacency=cached[1]
    source=int(start[0])*w+int(start[1]);costs=[math.inf]*(h*w);costs[source]=0.
    queue=[(0.,source)]
    while queue:
        distance,node=heapq.heappop(queue)
        if distance>costs[node]:continue
        for neighbor,weight in adjacency[node]:
            proposal=distance+weight
            if proposal<costs[neighbor]:
                costs[neighbor]=proposal;heapq.heappush(queue,(proposal,neighbor))
    return np.asarray(costs).reshape(shape)*memory.CELL


def _market_incumbent(memory, agents, drops, radius, travel_budget=None,
                       quality_tolerance=0.92, forbidden_points=(), forbidden_mask=None,
                       deadline_pressure=0.0, _prepared=None):
    """Greedy marginal coverage followed by capacity-constrained assignment.

    Selects near-global-best gain first; path cost decides among candidates
    within quality_tolerance of that best gain. Thus distant dense surfaces
    are not suppressed merely because they are distant. Every pick removes its
    disk from future gains, including picks scheduled to other drones.

    A drone gets at most its reported remaining inventory. Each planned target
    is in that drone's sensor-known connected free space. A path-length budget
    prevents committing an agent to a route that cannot fit remaining time.
    """
    memory = GeometryPlanningMemory(memory) if _prepared is None else _prepared
    agents = {int(key):(np.asarray(pos,dtype=float),int(count))
              for key,(pos,count) in agents.items()
              if pos is not None and int(count)>0 and np.isfinite(pos).all()}
    plans = {key:[] for key in agents}
    if not agents:
        return plans
    values, solids = observed_wall_values(memory, radius, return_solids=True)
    walkable = memory.free & ~memory.blocked() & ~solids
    rr, cc = np.indices(memory.shape)
    xx = (cc + 0.5) * memory.CELL - memory.width / 2
    yy = memory.height / 2 - (rr + 0.5) * memory.CELL
    allowed = walkable.copy()
    if forbidden_mask is not None: allowed &= ~np.asarray(forbidden_mask,bool)
    for point, exclusion_radius in forbidden_points:
        allowed[(xx-point[0])**2+(yy-point[1])**2 < exclusion_radius**2] = False
    for point in drops:
        squared = (xx-point[0])**2 + (yy-point[1])**2
        values[squared <= radius**2] = 0
        # 24 px is the public placement separation; half a coarse-cell diagonal
        # gives slack because the goal is only approximately reached.
        allowed[squared < (40+0.71*memory.CELL)**2] = False
    rc = int(math.ceil(radius / memory.CELL))
    ky, kx = np.mgrid[-rc:rc+1,-rc:rc+1]
    disk = ((kx*memory.CELL)**2 + (ky*memory.CELL)**2 <= radius**2).astype(np.float32)
    costs = {key:path_costs(memory, walkable, memory.world_to_cell(pos))
             for key,(pos,_) in agents.items()}
    spent = {key:0.0 for key in agents}
    origin = getattr(memory, "origin", None)
    origin = np.zeros(2, dtype=float) if origin is None else np.asarray(origin, dtype=float)
    team_size = max(1, int(getattr(memory, "team_size", max(agents) + 1)))
    angle_map = np.arctan2(yy - origin[1], xx - origin[0])
    sector_factor = {key: 1.0 + 0.25 * np.cos(angle_map - 2.0 * math.pi * (key % team_size) / team_size)
                     for key in agents}
    urgency = min(1.0, max(0.0, (float(deadline_pressure) - 0.30) / 0.25))
    route_price_rate = 0.05 + 0.20 * urgency
    for _ in range(sum(count for _,count in agents.values())):
        gain = cv2.filter2D(values, -1, disk, borderType=cv2.BORDER_CONSTANT)
        feasible = {}
        best_bid = -1.0
        winner = None
        for key in sorted(agents):
            if len(plans[key]) >= agents[key][1]:
                continue
            mask = allowed & np.isfinite(costs[key])
            if travel_budget is not None:
                mask &= costs[key] + spent[key] <= float(travel_budget)
            if not mask.any():
                continue
            feasible[key] = mask
            # Auction bid: marginal wall utility priced by route effort and a
            # stable, soft angular territory preference for disconnected teams.
            route_price = 1.0 + route_price_rate * (costs[key] + spent[key]) / max(1.0, float(radius))
            bid = gain * sector_factor[key] / route_price
            bid[~mask] = -np.inf
            flat = int(np.argmax(bid))
            cell = tuple(int(v) for v in np.unravel_index(flat, memory.shape))
            score = float(bid[cell])
            tie = (score, -float(costs[key][cell]), float(gain[cell]), -key, -flat)
            if score > best_bid or (winner is not None and tie > winner[0]):
                if winner is None or tie > winner[0]:
                    winner = (tie, key, cell)
                    best_bid = score
        if winner is None:
            break
        _, key, cell = winner
        point = memory.cell_to_world(cell)
        plans[key].append(point.copy())
        spent[key] += float(costs[key][cell])
        squared = (xx-point[0])**2 + (yy-point[1])**2
        values[squared <= radius**2] = 0
        allowed[squared < (40+0.71*memory.CELL)**2] = False
        if len(plans[key]) < agents[key][1]:
            costs[key] = path_costs(memory,walkable,cell)
    return plans


def plan_team_coverage(memory,agents,drops,radius,travel_budget=None,
        quality_tolerance=.92,forbidden_points=(),forbidden_mask=None,deadline_pressure=0.):
    # Complete market-v2 policy remains the incumbent and lower-level supplier.
    # The only new layer selects a joint combination of feasible whole routes.
    if not any(pos is not None and int(count)>0 for pos,count in agents.values()):
        return {}
    prepared=GeometryPlanningMemory(memory)
    incumbent=_market_incumbent(memory,agents,drops,radius,travel_budget,
        quality_tolerance,forbidden_points,forbidden_mask,deadline_pressure,_prepared=prepared)
    from swarm_rescue.solutions.route_columns import solve_route_columns
    return solve_route_columns(memory,agents,drops,radius,incumbent,travel_budget,
        quality_tolerance,forbidden_points,forbidden_mask,lambda _:prepared,
        observed_wall_values,path_costs)
