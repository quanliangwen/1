"""Message-causal completion, with inventory-empty coordinators still serving peers.

All completion certificates travel alongside the corresponding merged sensor
packet. A cached packet is invalidated whenever a new certificate is learned.
No peer objects, global runtime state or absolute explored-area cutoff is used.
"""
import math
import numpy as np
from swarm_rescue.solutions.greedy_mapping import GreedyMappingDrone


class CompletionConsensusMixin:
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.completion_certificates = {}

    def _record_own_completion(self, step):
        own = int(self.identifier or 0)
        if int(self.carried_bombs_count()) == 0 and own not in self.completion_certificates:
            self.completion_certificates[own] = int(step)
            self.cached_packet = None

    def define_message_for_all(self):
        self._record_own_completion(int(self.elapsed_timestep))
        # The parent's normal packet builder now includes every sensor map
        # whose certificate this instance has acknowledged.
        message = super().define_message_for_all()
        message['completion_certificates'] = dict(self.completion_certificates)
        return message

    def _messages(self):
        super()._messages()
        step = int(self.elapsed_timestep)
        for _, message in self.communicator.received_messages:
            if not isinstance(message, dict) or message.get('kind') != 'greedy-map-v1':
                continue
            sender, sent = message.get('id'), message.get('step')
            if (not isinstance(sender, int) or not 0 <= sender < self.team_size
                    or not isinstance(sent, int) or not 0 <= sent <= step
                    or self.last_peer_step.get(sender) != sent or 'map' not in message):
                continue
            certificates = message.get('completion_certificates', {})
            if not isinstance(certificates, dict):
                continue
            for origin, stamp in certificates.items():
                if (not isinstance(origin, int) or not 0 <= origin < self.team_size
                        or not isinstance(stamp, int) or not 0 <= stamp <= sent):
                    continue
                if origin == int(self.identifier or 0):
                    continue
                if origin not in self.completion_certificates:
                    self.completion_certificates[origin] = stamp
                    # A relayed certificate must never outrun its map payload.
                    self.cached_packet = None
        self._record_own_completion(step)

    def _plan_route(self, step, returning, peer_goals):
        if int(self.carried_bombs_count()) == 0:
            # Leadership depends on received fresh state, not inventory. An
            # elected empty coordinator must still allocate its peers' slots.
            self._build_fleet_plan(step)
            self.placement_goal = None
            return GreedyMappingDrone._plan_route(self, step, True, peer_goals)
        return super()._plan_route(step, returning, peer_goals)

    def _submission_due(self, step):
        if self._remaining_steps() <= 0:
            return True
        self._record_own_completion(step)
        if int(self.carried_bombs_count()) != 0:
            return False
        if not all(i in self.completion_certificates for i in range(self.team_size)):
            return False
        own = int(self.identifier or 0)
        quality = self._map_quality()
        better = any(0 <= step - ts < self.STATE_FRESH_STEPS
            and (known, occupied, -peer) > (*quality, -own)
            for peer, (ts, known, occupied) in self.map_quality_records.items() if peer != own)
        return not better

    def control(self):
        command = super().control()
        if (self.submitted or self.pose is None or self.rally is None
                or int(self.carried_bombs_count()) != 0
                or np.linalg.norm(self.pose - self.rally) >= 40):
            return command
        # Remain within radio range without orbiting the rendezvous while
        # waiting for the remaining completion maps. Only public odometry.
        velocity = self.measured_velocity()
        if velocity is None or not np.isfinite(velocity).all():
            velocity = np.zeros(2)
        cosine, sine = math.cos(self.heading), math.sin(self.heading)
        command.update(forward=float(np.clip(-(velocity[0]*cosine + velocity[1]*sine)/5.5, -1, 1)),
            lateral=float(np.clip(-(-velocity[0]*sine + velocity[1]*cosine)/5.5, -1, 1)),
            rotation=0., grasper=0, place_bomb=0)
        return command
