"""Compatibility entry for the active route-column coverage planner."""
from swarm_rescue.solutions.team_coverage import plan_team_coverage as _greedy_plan

from swarm_rescue.solutions.trust_region_cover import refine_trust_region

def plan_team_coverage_lns(memory, agents, drops, radius, travel_budget=None, quality_tolerance=0.92, forbidden_points=(), forbidden_mask=None, search_seed=None, deadline_pressure=0.0):
    base=_greedy_plan(memory, agents, drops, radius, travel_budget=travel_budget, quality_tolerance=quality_tolerance, forbidden_points=forbidden_points, forbidden_mask=forbidden_mask, deadline_pressure=deadline_pressure)
    return refine_trust_region(memory,agents,drops,radius,base,travel_budget=travel_budget,forbidden_points=forbidden_points,forbidden_mask=forbidden_mask)
