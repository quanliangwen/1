"""Whole-layout farthest-residual wall cover with inherited market fallback."""
import math
import time

import numpy as np
from swarm_rescue.solutions.farthest_wall_cover import farthest_layout


def solve_route_columns(memory, agents, drops, radius, incumbent, travel_budget,
                        quality_tolerance, forbidden_points, forbidden_mask,
                        planning_view, wall_values, distance_field):
    started = time.perf_counter()
    audit = {'framework': 'observed-wall farthest-residual cover',
             'selected_changed': False, 'route_fields': 0}

    def finish(plan, reason):
        audit['reason'] = reason
        audit['enclosing_elapsed_seconds'] = time.perf_counter() - started
        memory.farthest_wall_audit = audit
        print('[farthest-wall]', audit, flush=True)
        return plan

    if not math.isfinite(radius) or radius <= 0:
        return finish(incumbent, 'invalid_radius')
    budget = math.inf if travel_budget is None else float(travel_budget)
    if math.isnan(budget) or budget < 0:
        return finish(incumbent, 'invalid_budget')
    original = {int(k): [np.asarray(p, float).copy() for p in ps]
                for k, ps in incumbent.items()}
    owners = sorted(k for k, ps in original.items() if ps)
    counts = [len(original[k]) for k in owners]
    slots = sum(counts)
    if not 0 < slots <= 10 or any(c > 2 for c in counts):
        return finish(incumbent, 'unsupported_cardinality')
    clean = {}
    for k in owners:
        if k not in agents:
            return finish(incumbent, 'missing_owner')
        p, inventory = agents[k]
        p = np.asarray(p, float)
        if (p.shape != (2,) or not np.isfinite(p).all()
                or not math.isfinite(float(inventory))
                or int(inventory) < len(original[k])):
            return finish(incumbent, 'invalid_owner')
        clean[k] = p
    pm = planning_view(memory)
    values, solids = wall_values(pm, radius, return_solids=True)
    values = np.asarray(values, float).copy()
    # Only measured multi-bearing additions alter this full-layout value field.
    if hasattr(memory, 'bearing_wall_values'):
        values = memory.bearing_wall_values(values)
    if values.shape != pm.shape or not np.isfinite(values).all() or np.any(values < 0):
        return finish(incumbent, 'invalid_values')
    walkable = np.asarray(pm.free, bool) & ~np.asarray(pm.blocked(), bool) & ~np.asarray(solids, bool)
    rr, cc = np.indices(pm.shape)
    xx = (cc + .5) * pm.CELL - pm.width / 2
    yy = pm.height / 2 - (rr + .5) * pm.CELL
    allowed = walkable.copy()
    if forbidden_mask is not None:
        mask = np.asarray(forbidden_mask, bool)
        if mask.shape != pm.shape:
            return finish(incumbent, 'invalid_mask')
        allowed &= ~mask
    for point, exclusion in forbidden_points:
        point = np.asarray(point, float)
        if (point.shape != (2,) or not np.isfinite(point).all()
                or not math.isfinite(float(exclusion)) or exclusion < 0):
            return finish(incumbent, 'invalid_exclusion')
        allowed[(xx - point[0]) ** 2 + (yy - point[1]) ** 2 < exclusion ** 2] = False
    separation = 40 + .71 * pm.CELL
    for point in drops:
        point = np.asarray(point, float)
        if point.shape != (2,) or not np.isfinite(point).all():
            return finish(incumbent, 'invalid_drop')
        sq = (xx - point[0]) ** 2 + (yy - point[1]) ** 2
        values[sq <= radius ** 2 + 1e-8] = 0
        allowed[sq < separation ** 2] = False
    fields = {}

    def field(cell):
        cell = tuple(int(v) for v in cell)
        if not walkable[cell]:
            raise ValueError('field origin outside known-free graph')
        if cell not in fields:
            fields[cell] = distance_field(pm, walkable, cell)
            audit['route_fields'] += 1
        return fields[cell]

    starts = {k: pm.world_to_cell(clean[k]) for k in owners}
    if any(not walkable[cell] for cell in starts.values()):
        return finish(incumbent, 'start_not_known_free')
    original_centres = [p for k in owners for p in original[k]]
    if any(p.shape != (2,) or not np.isfinite(p).all() for p in original_centres):
        return finish(incumbent, 'invalid_incumbent')

    def union(centres):
        covered = np.zeros(pm.shape, bool)
        for p in centres:
            covered |= ((xx - p[0]) ** 2 + (yy - p[1]) ** 2
                        <= radius ** 2 + 1e-8)
        return float(values[covered].sum())

    baseline = union(original_centres)
    audit['incumbent_union'] = baseline
    start_fields = [field(starts[k]) for k in owners]
    try:
        paths, work = farthest_layout(values, allowed, xx, yy, radius, pm.CELL,
                                      owners, counts, start_fields, field,
                                      budget, separation)
    except (ValueError, TypeError, OverflowError) as exc:
        return finish(incumbent, 'finite_layout_rejected_' + type(exc).__name__)
    audit['model_work'] = work
    if any(len(paths[k]) != len(original[k]) for k in owners):
        return finish(incumbent, 'incomplete_inventory_layout')
    output = {k: [] for k in original}
    for k in owners:
        prior = starts[k]
        consumed = 0.0
        for cell in paths[k]:
            if not allowed[cell]:
                return finish(incumbent, 'illegal_target')
            leg = float(field(prior)[cell])
            consumed += leg
            if not math.isfinite(consumed) or consumed > budget + 1e-8:
                return finish(incumbent, 'route_budget')
            output[k].append(pm.cell_to_world(cell).copy())
            prior = cell
    centres = [p for k in owners for p in output[k]]
    if any(np.linalg.norm(p - q) < separation - 1e-8
           for i, p in enumerate(centres) for q in centres[:i]):
        return finish(incumbent, 'site_separation')
    proposed = union(centres)
    audit['proposed_union'] = proposed
    if proposed <= baseline + 1e-7:
        return finish(incumbent, 'no_strict_full_union_gain')
    audit['selected_changed'] = True
    return finish(output, 'farthest_layout_selected')
