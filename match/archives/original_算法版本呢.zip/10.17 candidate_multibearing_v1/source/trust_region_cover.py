"""One-site epsilon-constrained coverage improvement of a feasible incumbent.
Only per-call public sensor geometry and received fleet state are used.
Target count, owners and visit order stay fixed; shortest-route lengths cannot
increase beyond explicit epsilon. No global running state or truth access.
"""
from __future__ import annotations
import math
import cv2
import numpy as np
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
from swarm_rescue.solutions.team_coverage import observed_wall_values,path_costs

TRUST_RADIUS_RATIO = 1.25
ROUTE_EPSILON = 32.0
MIN_GAIN_RATIO = 0.003
MAX_OPTIONS = 128


def _repeat_hit_support(memory):
    repeated=(np.asarray(memory.hits)>=2).astype(np.float32)
    smooth=cv2.GaussianBlur(repeated,(0,0),sigmaX=1.2)
    density=cv2.resize(smooth,(int(memory.shape[1]),int(memory.shape[0])),interpolation=cv2.INTER_AREA)
    confidence=0.35*np.clip(density/0.08,0.0,1.0)
    rr,cc=np.indices(memory.shape)
    xx=(cc+0.5)*memory.CELL-memory.width/2
    yy=memory.height/2-(rr+0.5)*memory.CELL
    frame=(np.abs(xx)>memory.width/2-memory.CELL)|(np.abs(yy)>memory.height/2-memory.CELL)
    confidence[frame]*=0.5
    return confidence.astype(np.float32)


def _coverage_mask(pm, points, radius):
    rr,cc=np.indices(pm.shape)
    xx=(cc+0.5)*pm.CELL-pm.width/2
    yy=pm.height/2-(rr+0.5)*pm.CELL
    covered=np.zeros(pm.shape,bool)
    for point in points:
        covered |= (xx-point[0])**2+(yy-point[1])**2 <= radius**2+1e-8
    return covered


def refine_trust_region(memory, agents, drops, radius, base, travel_budget=None,
                        forbidden_points=(), forbidden_mask=None,
                        route_epsilon=ROUTE_EPSILON,
                        trust_radius_ratio=TRUST_RADIUS_RATIO):
    previous=getattr(memory,'trust_region_diagnostics',{})
    diag={'calls':previous.get('calls',0)+1,'utility_candidates':0,'evaluated_candidates':0,
          'fields_computed':0,'accepted':0,'accepted_total':previous.get('accepted_total',0)}
    memory.trust_region_diagnostics=diag
    original={int(k):[np.asarray(p,float).copy() for p in ps] for k,ps in base.items()}
    if not any(original.values()): return original
    pm=GeometryPlanningMemory(memory)
    values,solids=observed_wall_values(pm,radius,return_solids=True)
    confirmed_values=np.asarray(values,np.float32).copy()
    values=np.maximum(confirmed_values,_repeat_hit_support(pm))
    walkable=pm.free & ~pm.blocked() & ~solids
    allowed=walkable.copy()
    rr,cc=np.indices(pm.shape)
    xx=(cc+0.5)*pm.CELL-pm.width/2
    yy=pm.height/2-(rr+0.5)*pm.CELL
    if forbidden_mask is not None:
        mask=np.asarray(forbidden_mask,bool)
        if mask.shape!=pm.shape: return original
        allowed &= ~mask
    for p,r in forbidden_points:
        allowed[(xx-p[0])**2+(yy-p[1])**2 < float(r)**2] = False
    separation=40.0+0.71*pm.CELL
    for point in drops:
        squared=(xx-point[0])**2+(yy-point[1])**2
        values[squared<=radius**2+1e-8]=0
        confirmed_values[squared<=radius**2+1e-8]=0
        allowed[squared<separation**2]=False
    clean={int(k):(np.asarray(p,float),int(n)) for k,(p,n) in agents.items()
           if p is not None and np.asarray(p).shape==(2,) and np.isfinite(p).all() and int(n)>0}
    fields={}
    def field(cell):
        cell=tuple(int(v) for v in cell)
        if cell not in fields:
            fields[cell]=path_costs(pm,walkable,cell)
            diag['fields_computed']+=1
        return fields[cell]
    def distance(a,b): return float(field(pm.world_to_cell(a))[pm.world_to_cell(b)])
    def route_length(k,items):
        previous=clean[k][0];length=0.0
        for point in items:
            length+=distance(previous,point);previous=point
        return length
    route_before={}
    for k,items in original.items():
        if not items: continue
        if k not in clean or len(items)>clean[k][1]: return original
        # Path validation is deferred until useful geometry exists.
    all_points=[p for ps in original.values() for p in ps]
    incumbent_score=float(values[_coverage_mask(pm,all_points,radius)].sum())
    incumbent_confirmed=float(confirmed_values[_coverage_mask(pm,all_points,radius)].sum())
    threshold=max(0.1,MIN_GAIN_RATIO*incumbent_score)
    rc=int(math.ceil(radius/pm.CELL));ky,kx=np.mgrid[-rc:rc+1,-rc:rc+1]
    disk=((kx*pm.CELL)**2+(ky*pm.CELL)**2<=radius**2+1e-8).astype(np.float32)
    winner=None;winner_rank=(threshold,0.0,0,0,0)
    trust=float(radius)*float(trust_radius_ratio)
    for k in sorted(original):
        for slot,old in enumerate(original[k]):
            others=[p for owner,items in original.items() for j,p in enumerate(items) if not(owner==k and j==slot)]
            residual=values.copy();residual[_coverage_mask(pm,others,radius)]=0
            gains=cv2.filter2D(residual,-1,disk,borderType=cv2.BORDER_CONSTANT)
            old_gain=float(residual[_coverage_mask(pm,[old],radius)].sum())
            confirmed_residual=confirmed_values.copy()
            confirmed_residual[_coverage_mask(pm,others,radius)]=0
            confirmed_gains=cv2.filter2D(confirmed_residual,-1,disk,borderType=cv2.BORDER_CONSTANT)
            old_confirmed=float(confirmed_residual[_coverage_mask(pm,[old],radius)].sum())
            mask=allowed & ((xx-old[0])**2+(yy-old[1])**2<=trust**2+1e-8)
            mask &= confirmed_gains>=old_confirmed-1e-5
            for other in others: mask &= (xx-other[0])**2+(yy-other[1])**2>=separation**2-1e-8
            improving=mask & (gains>old_gain+threshold)
            diag['utility_candidates']+=int(np.count_nonzero(improving))
            if not improving.any():continue
            mask=improving
            if k not in route_before:
                length=route_length(k,original[k])
                if not math.isfinite(length) or (travel_budget is not None and length>float(travel_budget)+1e-6):return original
                route_before[k]=length
            prev=clean[k][0] if slot==0 else original[k][slot-1]
            nxt=original[k][slot+1] if slot+1<len(original[k]) else None
            old_edge=distance(prev,old)+(distance(old,nxt) if nxt is not None else 0.0)
            candidate_lengths=route_before[k]-old_edge+field(pm.world_to_cell(prev))
            if nxt is not None: candidate_lengths=candidate_lengths+field(pm.world_to_cell(nxt))
            cap=route_before[k]+float(route_epsilon)
            if travel_budget is not None: cap=min(cap,float(travel_budget))
            mask &= np.isfinite(candidate_lengths) & (candidate_lengths<=cap+1e-6)
            eligible=np.flatnonzero(mask.ravel() & (gains.ravel()>old_gain+threshold))
            if not eligible.size: continue
            order=eligible[np.argsort(-gains.ravel()[eligible],kind='stable')[:MAX_OPTIONS]]
            for flat in order:
                diag['evaluated_candidates']+=1
                cell=tuple(int(v) for v in np.unravel_index(int(flat),pm.shape))
                point=pm.cell_to_world(cell)
                delta=float(gains[cell])-old_gain
                rank=(delta,route_before[k]-float(candidate_lengths[cell]),-k,-slot,-int(flat))
                if rank>winner_rank: winner=(k,slot,point.copy());winner_rank=rank
    if winner is None: return original
    # Validate unchanged owners only if an exchange will actually be applied.
    # This preserves the original infeasible-incumbent fallback.
    for key,items in original.items():
        if not items or key in route_before:continue
        length=route_length(key,items)
        if not math.isfinite(length) or (travel_budget is not None and length>float(travel_budget)+1e-6):return original
        route_before[key]=length
    k,slot,point=winner
    result={key:[p.copy() for p in items] for key,items in original.items()}
    result[k][slot]=point
    # Defensive final constraints: preserve slots/owners and validate exact
    # geodesics and utility after cell-to-world conversion.
    if any(len(result[key])!=len(original[key]) for key in original): return original
    if route_length(k,result[k])>route_before[k]+float(route_epsilon)+1e-6: return original
    final_points=[p for ps in result.values() for p in ps]
    final_score=float(values[_coverage_mask(pm,final_points,radius)].sum())
    if final_score<incumbent_score+threshold-1e-5: return original
    final_confirmed=float(confirmed_values[_coverage_mask(pm,final_points,radius)].sum())
    if final_confirmed<incumbent_confirmed-1e-5: return original
    diag['accepted']=1;diag['accepted_total']+=1
    diag['confirmed_gain']=final_confirmed-incumbent_confirmed
    return result
