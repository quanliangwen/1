"""Exact packaged-entry contracts; run with candidate workspace/src on PYTHONPATH."""
from types import SimpleNamespace
import unittest

import numpy as np

from swarm_rescue.solutions.my_drone_eval import MyDroneEval
from swarm_rescue.solutions.route_columns import solve_route_columns


class PublicGrid:
    CELL = 50.
    shape = (5, 11)
    width = 550.
    height = 250.

    def __init__(self):
        self.free = np.ones(self.shape, bool)

    def blocked(self):
        return np.zeros(self.shape, bool)

    def cell_to_world(self, cell):
        r, c = cell
        return np.array([(c + .5) * self.CELL - self.width / 2,
                         self.height / 2 - (r + .5) * self.CELL])

    def world_to_cell(self, point):
        x, y = point
        return (int(self.height / 2 / self.CELL - y / self.CELL),
                int((x + self.width / 2) / self.CELL))


class FarthestWallEntryContracts(unittest.TestCase):
    def test_full_controller_constructor_retains_fleet_state(self):
        drone = MyDroneEval(identifier=0, misc_data=SimpleNamespace(
            size_area=(320, 320), number_drones=5,
            max_timestep_limit=2000, max_walltime_limit=90))
        self.assertIn('FleetCoverageMixin', [c.__name__ for c in MyDroneEval.mro()])
        self.assertIsInstance(drone.fleet_states, dict)
        self.assertIsNotNone(drone.memory)

    def test_packaged_route_entry_changes_a_valid_two_site_layout(self):
        grid = PublicGrid()
        values = np.zeros(grid.shape, float)
        values[2, [1, 3, 8, 9]] = 1
        incumbent = {0: [grid.cell_to_world((2, 1)),
                         grid.cell_to_world((2, 3))]}
        agents = {0: (grid.cell_to_world((2, 0)), 2)}

        def wall_values(memory, radius, return_solids=False):
            return values.copy(), np.zeros(grid.shape, bool)

        def field(memory, walkable, cell):
            rr, cc = np.indices(grid.shape)
            return 50. * (np.abs(rr - cell[0]) + np.abs(cc - cell[1]))

        plan = solve_route_columns(
            grid, agents, [], 60., incumbent, 2000., .92,
            (), None, lambda m: m, wall_values, field)
        self.assertEqual(len(plan[0]), 2)
        self.assertEqual(grid.farthest_wall_audit['reason'],
                         'farthest_layout_selected')
        self.assertTrue(grid.farthest_wall_audit['selected_changed'])
        self.assertGreater(grid.farthest_wall_audit['proposed_union'],
                           grid.farthest_wall_audit['incumbent_union'])

    def test_missing_reachable_inventory_keeps_incumbent(self):
        grid = PublicGrid()
        values = np.zeros(grid.shape, float)
        values[2, [1, 9]] = 1
        incumbent = {0: [grid.cell_to_world((2, 1))]}
        agents = {0: (grid.cell_to_world((2, 0)), 1)}

        def wall_values(memory, radius, return_solids=False):
            return values.copy(), np.zeros(grid.shape, bool)

        def field(memory, walkable, cell):
            rr, cc = np.indices(grid.shape)
            return 50. * (np.abs(rr - cell[0]) + np.abs(cc - cell[1]))

        plan = solve_route_columns(
            grid, agents, [], 60., incumbent, 0., .92,
            (), None, lambda m: m, wall_values, field)
        self.assertEqual(len(plan[0]), 1)
        self.assertEqual(grid.farthest_wall_audit['reason'],
                         'no_strict_full_union_gain')


if __name__ == '__main__':
    unittest.main()
