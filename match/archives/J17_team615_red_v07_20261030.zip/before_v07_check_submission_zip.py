"""Fail-closed contest ZIP identity/dependency/ABI-receipt release check."""
import argparse,ast,datetime,hashlib,json,re,sys,zipfile
from pathlib import Path

PINNED={'numpy':'1.26.4','opencv-contrib-python':'4.11.0.86','pandas':'2.2.3'}
SDK_INHERIT={'numpy':'>=1.24.4','opencv-contrib-python':'>=4.10.0.84'}
REFERENCE_V05=Path('E:/codex/PJ01_team615_red_v05_20261026/team615_red_v05.zip')
REFERENCE_V05_SHA256='1413661721353548f9dcb9badf6aed4c8763dbde56de0c6d170b7429dc0c9406'
SDK_INHERIT_RUNS={
    'numpy1':{'numpy':'1.26.4','opencv-contrib-python':'4.11.0.86','pandas':'2.2.3'},
    'numpy2':{'numpy':'2.2.6','opencv-contrib-python':'4.11.0.86','pandas':'2.2.3'},
}

def inspect_package(path,receipt=None,static_only=False,dependency_profile='pinned'):
    checks=[]
    def require(condition,name):
        if not condition:raise ValueError(name)
        checks.append(name)
    raw=path.read_bytes();digest=hashlib.sha256(raw).hexdigest()
    require(dependency_profile in ['pinned','sdk-inherit-v06'],'known_explicit_dependency_profile')
    if dependency_profile=='sdk-inherit-v06':
        require(path.name=='team615_red_v06.zip','sdk_inherit_profile_scoped_to_v06')
    require(re.fullmatch(r'team615_(red|blue)_v[0-9]{2,}\.zip',path.name) is not None,'numeric_team615_and_version_filename')
    with zipfile.ZipFile(path) as z:
        names=z.namelist()
        require(z.testzip() is None,'zip_crc')
        require(len(names)==len(set(names)),'no_duplicate_entries')
        require(all('/' not in n and '\\' not in n and n not in ['.','..'] for n in names),'flat_zip_no_traversal')
        require({'team_info.yml','my_drone_eval.py','req.txt'}<=set(names),'required_root_files')
        require(all(n.endswith(('.py','.txt','.yml','.yaml')) for n in names),'no_engine_state_or_binary_payload')
        team=z.read('team_info.yml').decode('utf-8-sig')
        require(len(re.findall(r'(?m)^\s*team_number\s*:',team))==1,'one_team_number_key')
        require(re.search(r'(?m)^team_number:\s*615\s*(?:#.*)?$',team) is not None,'team_number_yaml_integer_615')
        require('wLoPV5EE' not in team,'historical_string_identifier_absent')
        for field in ['team_name','team_members']:
            require(re.search(r'(?m)^'+field+r':\s*[^\s#].*$',team) is not None,field+'_present')
        deps={}
        for line in z.read('req.txt').decode('utf-8-sig').splitlines():
            line=line.split('#',1)[0].strip()
            if not line:continue
            pattern=r'([A-Za-z0-9_.-]+)==([A-Za-z0-9_.+-]+)' if dependency_profile=='pinned' else r'([A-Za-z0-9_.-]+)(>=[A-Za-z0-9_.+-]+)'
            match=re.fullmatch(pattern,line)
            require(match is not None,'all_dependencies_exact_pins' if dependency_profile=='pinned' else 'sdk_dependency_lower_bounds_only')
            name,version=match.groups();name=name.lower().replace('_','-')
            require(name not in deps,'no_duplicate_dependency_'+name);deps[name]=version
        if dependency_profile=='pinned':
            require(all(deps.get(n)==v for n,v in PINNED.items()),'validated_numpy_opencv_pandas_pins')
        else:
            require(deps==SDK_INHERIT,'exact_sdk_inherit_v06_dependency_declarations')
        require(not any(n in deps for n in ['opencv-python','opencv-python-headless','opencv-contrib-python-headless']),'no_conflicting_opencv_distributions')
        files={n:hashlib.sha256(z.read(n)).hexdigest() for n in names}
        for n in names:
            if n.endswith('.py'):ast.parse(z.read(n).decode('utf-8-sig'),filename=n)
        require(True,'all_python_syntax')
        require('image_ref.txt' not in names or not z.read('image_ref.txt').strip(),'code_submission_empty_image_ref')
        if dependency_profile=='sdk-inherit-v06':
            require(REFERENCE_V05.exists(),'preserved_v05_reference_available')
            require(hashlib.sha256(REFERENCE_V05.read_bytes()).hexdigest()==REFERENCE_V05_SHA256,'preserved_v05_reference_hash')
            with zipfile.ZipFile(REFERENCE_V05) as reference:
                require(set(reference.namelist())==set(names),'v06_payload_names_unchanged_from_v05')
                require(all(z.read(n)==reference.read(n) for n in names if n!='req.txt'),'v06_changes_req_only_all_other_payload_bytes_unchanged')
    if not static_only:
        require(receipt is not None,'abi_receipt_required')
        proof=json.loads(receipt.read_text(encoding='utf-8'))
        require(proof.get('status')=='PASS','abi_checks_pass')
        require(proof.get('submission_zip_sha256')==digest,'abi_receipt_bound_to_actual_zip')
        require(proof.get('payload_files_sha256')==files,'abi_receipt_exact_payload')
        require(proof.get('team_number')==615,'sdk_reads_team615')
        if dependency_profile=='pinned':
            require(proof.get('distribution_versions')==PINNED,'runtime_critical_distributions_match_pins')
            require(proof.get('numeric_random_pandas_cv_operations')=='PASS','mtrand_random_pandas_cv_operations_pass')
            require(proof.get('sdk_launcher_and_stats_import')=='PASS','sdk_import_chain_pass')
            require(all(proof.get('critical_module_paths',{}).get(n) for n in ['numpy','numpy.random.mtrand','pandas','cv2']),'recorded_critical_binary_paths')
        else:
            require(proof.get('dependency_profile')==dependency_profile,'abi_receipt_dependency_profile_matches')
            runs=proof.get('abi_runs',{})
            require(set(runs)==set(SDK_INHERIT_RUNS),'two_numpy_branches_required')
            for key,versions in SDK_INHERIT_RUNS.items():
                run=runs[key]
                require(run.get('status')=='PASS',key+'_abi_pass')
                require(run.get('submission_zip_sha256')==digest and run.get('payload_files_sha256')==files,key+'_receipt_exact_zip_and_payload')
                require(run.get('distribution_versions')==versions,key+'_runtime_full_numeric_combination')
                require(run.get('team_number')==615,key+'_sdk_reads_team615')
                require(run.get('numeric_random_pandas_cv_operations')=='PASS',key+'_real_numeric_operations')
                require(run.get('sdk_launcher_and_stats_import')=='PASS',key+'_sdk_import_chain')
                require(run.get('controller_factory_import')=='PASS' and run.get('all_payload_hashes_match') is True,key+'_actual_extracted_controller_import_and_hashes')
                require(all(run.get('critical_module_paths',{}).get(n) for n in ['numpy','numpy.random.mtrand','pandas','cv2']),key+'_critical_module_paths_recorded')
                plan=run.get('installation_dry_run',{})
                require(plan.get('status')=='PASS' and plan.get('planned_installations')==[],key+'_sdk_inheritance_requests_no_dependency_replacement')
    return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'STATIC_ONLY_PASS_NOT_RELEASED' if static_only else 'PASS','zip':str(path),'sha256':digest,'dependency_profile':dependency_profile,'checks':checks,'official_container_verified':False}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('zip',type=Path);p.add_argument('--abi-receipt',type=Path);p.add_argument('--static-only',action='store_true');p.add_argument('--dependency-profile',choices=['pinned','sdk-inherit-v06'],default='pinned');p.add_argument('--output',type=Path);a=p.parse_args()
    try:r=inspect_package(a.zip,a.abi_receipt,a.static_only,a.dependency_profile);code=0
    except Exception as e:r={'status':'FAIL','zip':str(a.zip),'error':str(e)};code=1
    if a.output:a.output.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(r,ensure_ascii=False));sys.exit(code)
