"""Retain conservative centre protection until the surface hull is credible."""
import cv2
import numpy as np
from swarm_rescue.solutions.centre_geometry import CentreGeometryMixin
from swarm_rescue.solutions.centre_safety import CentreSafetyMixin


class ReviewedCentreGeometryMixin(CentreGeometryMixin):
    def _messages(self):
        super()._messages()
        clouds=[np.asarray(cloud,float) for _,cloud in self.centre_surface_records.values() if len(cloud)]
        self._centre_geometry_trusted=False
        if not clouds:
            return
        points=np.concatenate(clouds).astype(np.float32)
        if len(points)<4:
            return
        hull=cv2.convexHull(points)
        _,sides,_=cv2.minAreaRect(hull)
        rectangle_area=float(sides[0]*sides[1])
        # A line/single facet or three-corner triangle should not disable the
        # previous conservative disks merely because a convex hull can be drawn.
        self._centre_geometry_trusted=(min(sides)>=48 and rectangle_area>0 and
                                      cv2.contourArea(hull)/rectangle_area>=.80)

    def _placement_forbidden(self):
        if not getattr(self,'_centre_geometry_trusted',False):
            return CentreSafetyMixin._placement_forbidden(self)
        return []

    def _placement_allowed(self,step,semantic):
        if not super()._placement_allowed(step,semantic):
            return False
        return all(np.linalg.norm(self.pose-point)>=radius
                   for point,radius in self._placement_forbidden())
