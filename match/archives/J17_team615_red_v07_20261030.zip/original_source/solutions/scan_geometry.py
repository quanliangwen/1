"""Optional sensor-only line extraction, scan registration and wall mapping.

The controller reads only measured GPS, compass, odometry, lidar, semantic
objects and received messages. There is no access to simulator/map truth.
Inspired by Olson (ICRA 2009) and point-to-line laser registration; TLS lines
make the registration target less sensitive to independent range noise.
"""
from __future__ import annotations

import math
import numpy as np



def extract_scan_lines(distances, angles, excluded=None, max_range=285.0):
    """TLS split-and-merge over contiguous lidar beams; return local segments.

    Output items are (start, end, member beam indices). Gaps and corner residuals
    split segments. No Manhattan assumption or known arena walls are required.
    """
    distances, angles = np.asarray(distances, float), np.asarray(angles, float)
    valid = np.isfinite(distances) & (distances > 12) & (distances < max_range)
    if excluded is not None:
        valid &= ~np.asarray(excluded, bool)
    points = np.column_stack((distances * np.cos(angles), distances * np.sin(angles)))
    ids = np.flatnonzero(valid)
    if not len(ids):
        return []
    gaps = np.flatnonzero((np.diff(ids) > 1) |
                         (np.linalg.norm(np.diff(points[ids], axis=0), axis=1) > 20)) + 1
    runs = np.split(ids, gaps)
    lines = []

    def fit(indices, depth=0):
        if len(indices) < 5:
            return
        p = points[indices]
        center = p.mean(axis=0)
        _, _, vectors = np.linalg.svd(p - center, full_matrices=False)
        tangent = vectors[0]
        normal = np.array([-tangent[1], tangent[0]])
        residual = np.abs((p - center) @ normal)
        worst = int(np.argmax(residual))
        if residual[worst] > 5.0 and depth < 8 and 3 <= worst <= len(p) - 4:
            fit(indices[:worst + 1], depth + 1)
            fit(indices[worst:], depth + 1)
            return
        if np.percentile(residual, 80) > 3.8:
            return
        projected = (p - center) @ tangent
        low, high = np.percentile(projected, [0, 100])
        if high - low < 22:
            return
        lines.append((center + tangent * low, center + tangent * high, indices.copy()))

    for run in runs:
        fit(run)
    return lines


def transform_points(points, position, heading):
    c, s = math.cos(heading), math.sin(heading)
    return np.asarray(points) @ np.array([[c, s], [-s, c]]) + np.asarray(position)


