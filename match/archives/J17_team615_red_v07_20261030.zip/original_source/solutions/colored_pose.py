"""Augmented-noise EKF reference using only GPS/compass/odometry inputs.

This is a local Gaussian linearization, not an exact nonlinear posterior or
game-optimal controller. No arena, peer, wall truth or history is consumed.
"""
import math
import numpy as np

def wrap(a):return (a+math.pi)%(2*math.pi)-math.pi

class ColoredPoseFilter:
    RHO=.98
    GPS_SD=5.
    COMPASS_SD=math.radians(4.)
    DIST_SD=.2
    ALPHA_SD=math.radians(8.)
    ROTATION_SD=math.radians(1.)
    def __init__(self):
        self.x=None;self.P=None;self.last_gain=None
    def initialize(self,gps,compass):
        self.x=np.array([gps[0],gps[1],compass,0.,0.,0.],float)
        self.P=np.zeros((6,6))
        for p,b,v in [(0,3,self.GPS_SD**2),(1,4,self.GPS_SD**2),(2,5,self.COMPASS_SD**2)]:
            self.P[p,p]=self.P[b,b]=v;self.P[p,b]=self.P[b,p]=-v
    def reanchor(self,position,heading):
        """Honor existing external boundary correction without fake information.

        Shift pose mean and the opposite bias mean so the contemporaneous
        absolute observation is unchanged; do not shrink covariance or claim
        an independent probabilistic anchor measurement.
        """
        if self.x is None:return
        p=np.asarray(position,float);h=float(heading)
        if p.shape!=(2,) or not np.isfinite(p).all() or not math.isfinite(h):
            raise ValueError('Invalid anchor')
        self.x[3:5]+=self.x[:2]-p
        self.x[5]=wrap(self.x[5]+wrap(self.x[2]-h))
        self.x[:2]=p;self.x[2]=wrap(h)
    def update(self,gps,compass,odom):
        goodgps=gps is not None and np.asarray(gps).shape==(2,) and np.isfinite(gps).all()
        goodcompass=compass is not None and math.isfinite(float(compass))
        goododom=odom is not None and np.asarray(odom).shape==(3,) and np.isfinite(odom).all()
        if self.x is None:
            if not(goodgps and goodcompass):return None,None
            self.initialize(gps,float(compass));return self.x[:2].copy(),float(self.x[2])
        # SDK Sensor.update does not advance its AR noise when disabled.
        # A missing public value therefore freezes that sensor bias process.
        F=np.eye(6)
        if goodgps:F[3,3]=F[4,4]=self.RHO
        if goodcompass:F[5,5]=self.RHO
        Q=np.zeros((6,6))
        if goododom:
            distance,alpha,rotation=map(float,odom)
            angle=self.x[2]+alpha;c,s=math.cos(angle),math.sin(angle)
            self.x[:2]+=distance*np.array([c,s]);self.x[2]=wrap(self.x[2]+rotation)
            F[0,2]=-distance*s;F[1,2]=distance*c
            J=np.array([[c,-distance*s],[s,distance*c]])
            Q[:2,:2]=J@np.diag([self.DIST_SD**2,self.ALPHA_SD**2])@J.T
            Q[2,2]=self.ROTATION_SD**2
        else:
            # With missing displacement the pose is not physically predictable.
            # This declared uncertainty prevents pretending an unmoving exact pose.
            Q[0,0]=Q[1,1]=9.;Q[2,2]=math.radians(5.)**2
        if goodgps:
            self.x[3:5]*=self.RHO
            Q[3,3]=Q[4,4]=self.GPS_SD**2*(1-self.RHO**2)
        if goodcompass:
            self.x[5]*=self.RHO
            Q[5,5]=self.COMPASS_SD**2*(1-self.RHO**2)
        self.P=F@self.P@F.T+Q
        H=[];innov=[]
        if goodgps:
            for axis in (0,1):
                row=np.zeros(6);row[axis]=row[axis+3]=1.
                H.append(row);innov.append(float(gps[axis])-self.x[axis]-self.x[axis+3])
        if goodcompass:
            H.append(np.array([0.,0.,1.,0.,0.,1.]))
            innov.append(wrap(float(compass)-self.x[2]-self.x[5]))
        if H:
            H=np.asarray(H);innovation=np.asarray(innov)
            # SDK readouts contain AR bias and no additional white component.
            # Tiny R is numerical regularization only, explicitly recorded.
            R=np.eye(len(H))*1e-10
            K=np.linalg.solve(H@self.P@H.T+R,H@self.P).T
            self.x+=K@innovation;self.x[2]=wrap(self.x[2]);self.x[5]=wrap(self.x[5])
            A=np.eye(6)-K@H
            self.P=A@self.P@A.T+K@R@K.T
            self.P=(self.P+self.P.T)/2
            self.last_gain=K
        return self.x[:2].copy(),float(self.x[2])


class ColoredPoseMixin:
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self._colored_pose_filter=ColoredPoseFilter()
        self._colored_pose_updates=0
        self._colored_anchor_updates=0
        self._colored_odom_recoveries=0
        self._colored_last_odom_valid=False

    def _update_pose(self):
        gps=self.measured_gps_position()
        compass=self.measured_compass_angle()
        odom=self.odometer_values()
        goodgps=gps is not None and np.asarray(gps).shape==(2,) and np.isfinite(gps).all()
        goodcompass=compass is not None and math.isfinite(float(compass))
        goododom=odom is not None and np.asarray(odom).shape==(3,) and np.isfinite(odom).all()
        f=self._colored_pose_filter
        if f.x is None:
            # Retain original partial-sensor initialization and rally semantics.
            # SDK sensor getters are read-only cached observations.
            super()._update_pose()
            if goodgps and goodcompass and self.pose is not None:
                f.initialize(gps,float(compass));f.reanchor(self.pose,self.heading)
                self._colored_last_odom_valid=bool(goododom)
                self._colored_log('INITIALIZED')
            return
        if goododom and not self._colored_last_odom_valid:
            # SDK odometry after disabling spans the whole outage. Current
            # absolute fixes may already have moved the estimate: do not
            # apply that cumulative displacement as a single-step increment.
            odom=None;self._colored_odom_recoveries+=1
        self._colored_last_odom_valid=bool(goododom)
        self.pose,self.heading=f.update(gps,compass,odom)
        self.heading_initialized=True
        if self.rally is None:self.rally=self.pose.copy()
        self._colored_pose_updates+=1
        if self._colored_pose_updates%240==0:self._colored_log('PERIODIC')

    def _colored_accept_anchor(self):
        if self._colored_pose_filter.x is None:return
        self._colored_pose_filter.reanchor(self.pose,self.heading)
        self._colored_anchor_updates+=1

    def _colored_log(self,event):
        import json
        f=self._colored_pose_filter
        print('[COLORED_POSE] '+json.dumps(dict(event=event,owner=int(self.identifier),
            step=int(self.elapsed_timestep),updates=self._colored_pose_updates,
            anchor_updates=self._colored_anchor_updates,odom_recoveries=self._colored_odom_recoveries,
            estimated_bias=None if f.x is None else f.x[3:].tolist(),
            posterior_pose_variances=None if f.P is None else np.diag(f.P)[:3].tolist()),sort_keys=True),flush=True)
