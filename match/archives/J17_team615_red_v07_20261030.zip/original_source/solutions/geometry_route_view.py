"""Sensor-derived planning mask and target routing with per-drone caching.

Cache defaults: clearance=22 px, line_width=8 px, max_age=120 steps. Width 12
can be explicitly selected; the objective's line width is independently 12.
The old view, live map, and lidar motor controller remain unchanged.
"""
import heapq
import math
import cv2
import numpy as np
from swarm_rescue.solutions.line_regularization import regularized_walls


class GeometryPlanningMemory:
    def __init__(self,memory,clearance=22.0,line_width=8,measured_layer=None):
        self._memory=memory
        self.free=(cv2.morphologyEx(memory.free.astype(np.uint8),cv2.MORPH_CLOSE,
                                    np.ones((3,3),np.uint8)).astype(bool)|memory.free)
        if measured_layer is None:
            measured=regularized_walls(memory.hits,fine=memory.FINE,line_width=line_width,
                                       keep_raw=False,fit_band=10,duplicate_distance=8,covariance_limit=30)
        else:
            measured=np.asarray(measured_layer,np.uint8)
            if measured.shape!=memory.hits.shape: raise ValueError('Measured layer shape differs')
        if measured.any():
            distance=cv2.distanceTransform(1-measured,cv2.DIST_L2,5)*memory.FINE
            rows=np.minimum(((np.arange(memory.shape[0])+.5)*memory.CELL/memory.FINE).astype(int),memory.hit_shape[0]-1)
            cols=np.minimum(((np.arange(memory.shape[1])+.5)*memory.CELL/memory.FINE).astype(int),memory.hit_shape[1]-1)
            self._blocked=distance[np.ix_(rows,cols)]<float(clearance)
        else:
            self._blocked=memory.blocked().copy()
        semantic=getattr(memory,"semantic_navigation_blocked",None)
        if semantic is not None:
            if np.asarray(semantic).shape!=memory.shape: raise ValueError("Semantic navigation shape differs")
            self._blocked |= np.asarray(semantic,bool)

    def __getattr__(self,name):
        return getattr(self._memory,name)

    def blocked(self):
        return self._blocked.copy()

    @staticmethod
    def _visible(start,end,walkable):
        count=max(abs(end[0]-start[0]),abs(end[1]-start[1]))*2+1
        cells=np.rint(np.linspace(start,end,max(2,count))).astype(int)
        # At diagonal corners require both neighboring orthogonal cells, too.
        for first,last in zip(cells[:-1],cells[1:]):
            dr,dc=last-first
            if dr and dc and (not walkable[first[0]+dr,first[1]] or
                              not walkable[first[0],first[1]+dc]): return False
        return bool(np.all(walkable[cells[:,0],cells[:,1]]))

    def route_to(self,position,destination,inferred_solids=None):
        start=self.world_to_cell(position);wanted=self.world_to_cell(destination)
        walkable=self.free & ~self._blocked
        if inferred_solids is not None:
            solids=np.asarray(inferred_solids,bool)
            if solids.shape!=self.shape: raise ValueError('inferred_solids shape differs from map')
            walkable &= ~solids
        walkable=walkable.copy();walkable[start]=True
        costs=np.full(self.shape,np.inf);costs[start]=0
        parents={};queue=[(0.,start)]
        while queue:
            distance,cell=heapq.heappop(queue)
            if distance>costs[cell]: continue
            row,col=cell
            for dr,dc in ((-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)):
                nr,nc=row+dr,col+dc
                if not(0<=nr<costs.shape[0] and 0<=nc<costs.shape[1]) or not walkable[nr,nc]: continue
                if dr and dc and (not walkable[row+dr,col] or not walkable[row,col+dc]): continue
                proposal=distance+(math.sqrt(2) if dr and dc else 1.)
                if proposal<costs[nr,nc]:
                    costs[nr,nc]=proposal;parents[(nr,nc)]=cell
                    heapq.heappush(queue,(proposal,(nr,nc)))
        if np.isfinite(costs[wanted]):
            goal=wanted
        else:
            rr,cc=np.indices(costs.shape)
            score=np.full(self.shape,np.inf)
            reachable=np.isfinite(costs)
            score[reachable]=((rr[reachable]-wanted[0])**2+(cc[reachable]-wanted[1])**2+.025*costs[reachable])
            if not reachable.any(): return [],None
            goal=tuple(int(value) for value in np.unravel_index(np.argmin(score),costs.shape))
        cells=[goal]
        while cells[-1]!=start: cells.append(parents[cells[-1]])
        cells.reverse()
        smooth=[start];index=0
        while index<len(cells)-1:
            far=index+1
            for candidate in range(index+2,len(cells)):
                if not self._visible(cells[index],cells[candidate],walkable): break
                far=candidate
            smooth.append(cells[far]);index=far
        actual=self.cell_to_world(goal)
        return ([self.cell_to_world(cell) for cell in smooth[1:]] or [actual.copy()]),actual


class GeometryPlanningCache:
    """Own one cache per drone; never store it in module/shared global state."""
    def __init__(self,max_age=120,clearance=22.0,line_width=8):
        self.max_age=int(max_age);self.clearance=float(clearance);self.line_width=int(line_width)
        self.memory=None;self.view=None;self.created_step=-1000

    def invalidate(self):
        self.view=None

    def get(self,memory,step):
        if (self.view is None or self.memory is not memory or
                int(step)-self.created_step>=self.max_age or int(step)<self.created_step):
            self.memory=memory
            self.view=GeometryPlanningMemory(memory,clearance=self.clearance,line_width=self.line_width)
            self.created_step=int(step)
        return self.view
