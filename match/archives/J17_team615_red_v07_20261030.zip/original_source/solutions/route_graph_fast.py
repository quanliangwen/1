"""Exact multi-target distances on a sensed eight-neighbour grid.

A local adjacency list is reused within one planner call only. Obstacles and
no-corner-cutting diagonals have the same meaning as the incumbent planner.
There is no persistent/global map cache and no framework dependency.
"""
import heapq
import math
import numpy as np


def pair_distances(walkable,cells,cell_size):
    walkable=np.asarray(walkable,dtype=bool)
    h,w=walkable.shape
    adjacency=[[] for _ in range(h*w)]
    for dr,dc in ((0,1),(0,-1),(1,0),(-1,0),(1,1),(1,-1),(-1,1),(-1,-1)):
        r0,r1=max(0,-dr),min(h,h-dr)
        c0,c1=max(0,-dc),min(w,w-dc)
        allowed=walkable[r0:r1,c0:c1] & walkable[r0+dr:r1+dr,c0+dc:c1+dc]
        if dr and dc:
            allowed &= walkable[r0+dr:r1+dr,c0:c1] & walkable[r0:r1,c0+dc:c1+dc]
        rr,cc=np.nonzero(allowed)
        origin=(rr+r0)*w+cc+c0
        destination=origin+dr*w+dc
        weight=math.sqrt(2) if dr and dc else 1.0
        for u,v in zip(origin.tolist(),destination.tolist()):adjacency[u].append((v,weight))
    targets=[int(r)*w+int(c) for r,c in cells]
    if any(not(0<=int(r)<h and 0<=int(c)<w and walkable[int(r),int(c)]) for r,c in cells):
        raise ValueError('pair-distance endpoints must be traversable grid cells')
    n=len(cells);result=np.full((n,n),np.inf);np.fill_diagonal(result,0.)
    index={node:i for i,node in enumerate(targets)}
    for i,source in enumerate(targets[:-1]):
        pending=set(targets[i+1:]);dist=[math.inf]*(h*w);dist[source]=0.;queue=[(0.,source)]
        while queue and pending:
            distance,node=heapq.heappop(queue)
            if distance>dist[node]:continue
            if node in pending:
                j=index[node];result[i,j]=result[j,i]=distance*cell_size;pending.remove(node)
                if not pending:break
            for neighbor,weight in adjacency[node]:
                trial=distance+weight
                if trial<dist[neighbor]:
                    dist[neighbor]=trial;heapq.heappush(queue,(trial,neighbor))
    return result
