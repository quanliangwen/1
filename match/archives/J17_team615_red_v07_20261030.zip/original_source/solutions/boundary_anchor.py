"""Optional pose correction from repeatedly observed physical arena edges.

Inputs are lidar-derived local line segments and measured pose. Public arena
dimensions define the coordinate limits, but no boundary is created from those
limits alone: registration requires a long, repeatedly observed boundary span.
The estimates never read a map file, simulator state or evaluation truth.
"""
from collections import deque
import math
import numpy as np


def wrap(angle):
    return (angle+math.pi) % (2*math.pi)-math.pi


def transform(points, position, heading):
    c, s = math.cos(heading), math.sin(heading)
    return np.asarray(points) @ np.array([[c, s], [-s, c]]) + np.asarray(position)


class ObservedBoundaryAnchor:
    def __init__(self, width, height, wall_thickness=6.0):
        self.width, self.height = float(width), float(height)
        self.wall_half = float(wall_thickness)/2
        self.records = [deque(maxlen=24) for _ in range(4)]
        self.confirmed = [False]*4

    def _proposals(self, lines, position, heading):
        proposals = []
        for first, last, *_ in lines:
            endpoints = transform(np.array([first, last]), position, heading)
            vector = endpoints[1]-endpoints[0]
            length = float(np.linalg.norm(vector))
            if length < 60:
                continue
            angle = math.atan2(vector[1], vector[0])
            axis = int(round(angle/(math.pi/2)))
            angular_error = wrap(angle-axis*math.pi/2)
            if abs(angular_error) > math.radians(6):
                continue
            coordinate = endpoints.mean(axis=0)
            if axis % 2:
                # x-low/x-high; along coordinate is y.
                side = 0 if coordinate[0] < 0 else 1
                target = (-1 if side == 0 else 1)*(self.width/2-self.wall_half)
                offset = target-coordinate[0]
                along = endpoints[:, 1]
                span = self.height
                bound = self.height/2
            else:
                # y-low/y-high; along coordinate is x.
                side = 2 if coordinate[1] < 0 else 3
                target = (-1 if side == 2 else 1)*(self.height/2-self.wall_half)
                offset = target-coordinate[1]
                along = endpoints[:, 0]
                span = self.width
                bound = self.width/2
            if abs(offset) > 12 or np.any(np.abs(along) > bound+15):
                continue
            proposals.append((side, length, float(along.min()), float(along.max()),
                              float(offset), float(angular_error), span))
        return proposals

    def correct(self, lines, position, heading, step):
        position = np.asarray(position, float).copy()
        heading = float(heading)
        candidates = self._proposals(lines, position, heading)
        for side, length, lo, hi, offset, angle, span in candidates:
            self.records[side].append((int(step), lo, hi, offset, angle))
            recent = [r for r in self.records[side] if step-r[0] <= 96]
            if len(recent) < 3 or len({r[0] for r in recent}) < 3:
                continue
            offsets = np.array([r[3] for r in recent])
            # Require a long physical span and repeated mutually consistent
            # detections. A short wall merely near the frame cannot anchor pose.
            extent = max(r[2] for r in recent)-min(r[1] for r in recent)
            if (extent >= .28*span and np.std(offsets) <= 5 and
                    abs(np.median(offsets)) <= 9):
                self.confirmed[side] = True
        trusted = [r for r in candidates if self.confirmed[r[0]]]
        if not trusted:
            return position, heading, False
        angles = np.array([r[5] for r in trusted])
        lengths = np.array([r[1] for r in trusted])
        angular_error = float(np.average(angles, weights=lengths))
        # Mild updates protect motion/navigation against spurious registration.
        corrected_heading = wrap(heading-float(np.clip(.6*angular_error,
                                                     -math.radians(2), math.radians(2))))
        trusted = [r for r in self._proposals(lines, position, corrected_heading)
                   if self.confirmed[r[0]]]
        for axis, sides in enumerate(((0, 1), (2, 3))):
            offsets = [r[4] for r in trusted if r[0] in sides]
            if offsets:
                position[axis] += float(np.clip(.6*np.median(offsets), -5, 5))
        return position, corrected_heading, True
