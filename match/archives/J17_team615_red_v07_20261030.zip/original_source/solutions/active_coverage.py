"""Active maximum-coverage planning with an optimistic sensor-belief model.

Two complete greedy coverage problems quantify unresolved layout opportunity:
one uses measured geometry, the other adds hypothetical unseen wall mass.
The latter is an optimistic MODEL, not a certified bound on the true map.
No hypothetical site is sent to a drone; actual targets use the sensed-space
route-column planner. All inventory is eligible when acquisition stops.
"""
import math
import cv2
import numpy as np
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
from swarm_rescue.solutions.team_coverage import observed_wall_values
from swarm_rescue.solutions.greedy_mapping import GreedyMappingDrone


def greedy_value(values,allowed,radius,cell_size,count):
    remaining=np.asarray(values,np.float32).copy();legal=np.asarray(allowed,bool).copy()
    rc=int(math.ceil(radius/cell_size));dy,dx=np.mgrid[-rc:rc+1,-rc:rc+1]
    kernel=((dx*cell_size)**2+(dy*cell_size)**2<=radius**2).astype(np.float32)
    rows,cols=np.indices(remaining.shape);utility=0.
    for _ in range(max(0,int(count))):
        gain=cv2.filter2D(remaining,-1,kernel,borderType=cv2.BORDER_CONSTANT)
        gain[~legal]=-np.inf
        cell=np.unravel_index(np.argmax(gain),gain.shape)
        if not np.isfinite(gain[cell]) or gain[cell]<=0:break
        utility+=float(gain[cell])
        squared=(rows-cell[0])**2+(cols-cell[1])**2
        remaining[squared<=(radius/cell_size)**2]=0
        legal[squared<((40+.71*cell_size)/cell_size)**2]=False
    return utility


def acquisition_needed(layout_gap,map_gap,remaining_steps,execution_steps,tolerance=2.):
    """Stop sensing when model regret is small, or execution consumes slack."""
    return (layout_gap+map_gap>tolerance and remaining_steps>execution_steps)


class ActiveCoverageMixin:
    # The time-based start/reserve paths in FleetCoverageMixin are disabled;
    # _build_fleet_plan below is the sole acquisition/placement readiness gate.
    PLAN_START_RATIO=0.
    RESERVE_RELEASE_RATIO=0.

    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.coverage_ready=False
        self.coverage_model={}
        self._coverage_model_step=-1000
        self._clock_anchor=None
        self._step_seconds=None
        self._contact_steps={}
        self._fusion_started=None
        self._stable_inventory_step=None
        self._seeking_fusion=False
        self._acq_fusion_since=None
        self._acq_fusion_until=None
        self._acq_fusion_done=False
        self._acq_commit_pending=False
        self._acq_fusion_execution=None
        self._acq_fusion_prints=0

    def _update_pose(self):
        super()._update_pose()
        step=int(self.elapsed_timestep);wall=float(self.elapsed_walltime)
        if self._clock_anchor is None:self._clock_anchor=(step,wall)
        elif step-self._clock_anchor[0]>=48:
            ts,tw=self._clock_anchor;rate=max(0.,wall-tw)/max(1,step-ts)
            self._step_seconds=rate if self._step_seconds is None else .75*self._step_seconds+.25*rate
            self._clock_anchor=(step,wall)

    def _remaining_steps(self):
        step=float(self.elapsed_timestep);wall=float(self.elapsed_walltime)
        rate=max(.001,self._step_seconds or wall/max(1.,step))
        reserve=max(5.,24.*rate)
        return max(0.,min(float(self.limit)-step-24.,(self.walltime_limit-wall-reserve)/rate))

    def define_message_for_all(self):
        message=super().define_message_for_all()
        if self._seeking_fusion:
            message['coverage_sync']=(int(self.elapsed_timestep),int(self.identifier or 0))
        return message

    def _messages(self):
        super()._messages()
        step=int(self.elapsed_timestep)
        for _,msg in self.communicator.received_messages:
            if isinstance(msg,dict) and msg.get('kind')=='greedy-map-v1' and msg.get('id') is not None:
                self._contact_steps[int(msg['id'])]=step
                request=msg.get('coverage_sync')
                if (isinstance(request,(tuple,list)) and len(request)==2
                    and int(request[1])==int(msg['id']) and 0<=step-int(request[0])<120
                    and not self.coverage_ready and self.fleet_plan is None):
                    self._seeking_fusion=True

    def _estimate_coverage_opportunity(self,step):
        if step-self._coverage_model_step<120:return self.coverage_model
        self._coverage_model_step=step
        view=GeometryPlanningMemory(self.memory)
        values,solids=observed_wall_values(view,self.blast_radius,return_solids=True)
        measured=cv2.resize((self.memory.hits>=2).astype(np.float32),
            (self.memory.shape[1],self.memory.shape[0]),interpolation=cv2.INTER_AREA)>.02
        supported=cv2.dilate(measured.astype(np.uint8),np.ones((3,3),np.uint8)).astype(bool)
        unknown=~view.free & ~supported & ~solids
        known=view.free|supported|solids
        density=float(np.clip(values.sum()/max(1,int(known.sum())),.005,.35))
        unseen=unknown.astype(np.float32)*density
        rr,cc=np.indices(view.shape);xx=(cc+.5)*view.CELL-view.width/2;yy=view.height/2-(rr+.5)*view.CELL
        actual=view.free & ~view.blocked() & ~solids
        hypothetical=~view.blocked() & ~solids
        forbidden=self._placement_forbidden_mask()
        if forbidden is not None:actual &= ~forbidden;hypothetical &= ~forbidden
        for point,radius in self._placement_forbidden():
            excluded=(xx-point[0])**2+(yy-point[1])**2<radius**2
            actual[excluded]=False;hypothetical[excluded]=False
        for point in self.drop_records.values():
            squared=(xx-point[0])**2+(yy-point[1])**2
            values[squared<=self.blast_radius**2]=0;unseen[squared<=self.blast_radius**2]=0
            excluded=squared<(40+.71*view.CELL)**2
            actual[excluded]=False;hypothetical[excluded]=False
        active={k:n for k,(ts,p,n) in self.fleet_states.items() if p is not None and 0<=step-ts<120}
        slots=sum(active.values())
        measured_value=greedy_value(values,actual,self.blast_radius,view.CELL,slots)
        possible_value=greedy_value(values+unseen,hypothetical,self.blast_radius,view.CELL,slots)
        layout_gap=20.*max(0.,possible_value-measured_value)/max(1.,possible_value)
        map_gap=50.*float(unseen.sum())/max(1.,float(values.sum()+unseen.sum()))
        # A sensor-scale multi-stop route and an information-delivery trip.
        # This is an execution estimate; exact route feasibility is checked by
        # the unchanged route-column supplier before a target is assigned.
        max_inventory=max(active.values(),default=int(self.carried_bombs_count()))
        return_distance=0. if self.rally is None else float(np.linalg.norm(self.pose-self.rally))
        execution=(max_inventory*4*self.blast_radius+return_distance)/3.+24*(max_inventory+1)
        self.coverage_model={'known_value':measured_value,'optimistic_value':possible_value,
            'layout_gap':layout_gap,'map_gap':map_gap,'execution_steps':execution,'slots':slots,
            'unseen_wall_mass':float(unseen.sum()),'sensor_density':density}
        return self.coverage_model

    def _acquisition_needed(self,model,step):
        return acquisition_needed(model['layout_gap'],model['map_gap'],
            self._remaining_steps(),model['execution_steps'])

    def _acq_fusion_log(self, step, reason):
        if self._acq_fusion_prints >= 16:
            return
        self._acq_fusion_prints += 1
        import json
        print('[ACQUISITION_FUSION] '+json.dumps(dict(owner=int(self.identifier or 0),
            step=int(step),reason=reason,since=self._acq_fusion_since,until=self._acq_fusion_until,
            commit_pending=self._acq_commit_pending,remaining=float(self._remaining_steps()),
            execution=self._acq_fusion_execution)),flush=True)

    def _ensure_acq_fusion(self, step, execution=None, commit=False):
        remaining=float(self._remaining_steps())
        if commit:
            self._acq_commit_pending=True
            self._acq_fusion_execution=max(float(execution or 0.),self._acq_fusion_execution or 0.)
        room=(remaining/2. if self._acq_fusion_execution is None else
              remaining-self._acq_fusion_execution-48.)
        cap=min(int(self.STATE_FRESH_STEPS),max(0,int(room)))
        if self._acq_fusion_since is None:
            self._acq_fusion_since=int(step)
            self._acq_fusion_until=int(step)+cap
            self._acq_fusion_log(step,'START_BOUNDED_FUSION')
        else:
            # A later policy/model update may shorten this attempt, never renew it.
            self._acq_fusion_until=min(self._acq_fusion_until,int(step)+cap)

    def _advance_acq_fusion(self, step):
        if not self._seeking_fusion:
            return self._acq_fusion_done
        if self._acq_fusion_done:
            self._seeking_fusion=False
            return True
        if self._acq_fusion_since is None:
            self._ensure_acq_fusion(step)
        own=int(self.identifier or 0)
        at_rally=(self.rally is not None and self.pose is not None and
                  np.linalg.norm(self.pose-self.rally)<48)
        fresh_map=at_rally and any(peer!=own and self._acq_fusion_since<stamp<=step
            and step-stamp<self.STATE_FRESH_STEPS for peer,stamp in self.last_peer_step.items())
        plan_ready=(self.fleet_plan is not None and 0<=step-self.fleet_plan[0]<self.PLAN_FRESH_STEPS)
        remaining=float(self._remaining_steps())
        reserve_reached=(self._acq_commit_pending and self._acq_fusion_execution is not None
                         and remaining<=self._acq_fusion_execution+48.)
        reason=('EXISTING_PLAN_AVAILABLE' if plan_ready else 'ACTUAL_MAP_AT_RALLY' if fresh_map else
                'EXECUTION_RESERVE_REACHED' if reserve_reached else 'FUSION_WINDOW_EXPIRED'
                if step>=self._acq_fusion_until else None)
        if reason is None:
            return False
        self._seeking_fusion=False
        self._acq_fusion_done=True
        if self._acq_commit_pending:
            self.coverage_ready=True
        self._acq_fusion_log(step,reason)
        return True

    def _build_fleet_plan(self,step):
        # Keep the rendezvous attempt finite even if leadership changes or the
        # inherited acquisition policy changes its mind while travelling home.
        if self._seeking_fusion:
            self._advance_acq_fusion(step)
        active=[k for k,(ts,p,n) in self.fleet_states.items() if p is not None and 0<=step-ts<120]
        if not active or int(self.identifier or 0)!=min(active):return
        if not self.coverage_ready:
            model=self._estimate_coverage_opportunity(step)
            if self._acquisition_needed(model,step):return
            rendezvous=0. if self.rally is None else float(np.linalg.norm(self.pose-self.rally))/3.
            if (len(active)<self.team_size and not self._acq_fusion_done and
                    self._remaining_steps()>model['execution_steps']+rendezvous+48):
                self._seeking_fusion=True
                self._ensure_acq_fusion(step,model['execution_steps'],commit=True)
                if not self._advance_acq_fusion(step):return
            self.coverage_ready=True;self._seeking_fusion=False
            print('[active-coverage] release_all_inventory',int(self.identifier or 0),step,model,flush=True)
        super()._build_fleet_plan(step)

    def _plan_route(self,step,returning,peer_goals):
        # Allow a fusion request to acquire an actual plan at the meeting. Do
        # not keep travelling home after a valid coordinated plan arrives.
        if self._seeking_fusion:
            self._build_fleet_plan(step)
            if self.fleet_plan is not None and 0<=step-self.fleet_plan[0]<self.PLAN_FRESH_STEPS:
                self._seeking_fusion=False
            elif self._seeking_fusion and self.rally is not None and self.assignment_goal is None:
                self.placement_goal=None
                return GreedyMappingDrone._plan_route(self,step,True,peer_goals)
        if int(self.carried_bombs_count())==0:
            self.placement_goal=None
            if self._fusion_started is None:self._fusion_started=step
            # Returning is triggered by completed inventory, not a time phase.
            # After a message exchange at the rendezvous, resume useful mapping
            # if the common sensor map is still incomplete.
            at_rally=self.rally is not None and np.linalg.norm(self.pose-self.rally)<48
            contacts=sum(0<=step-ts<120 for peer,ts in self._contact_steps.items() if peer!=int(self.identifier or 0))
            if at_rally and contacts and self._map_quality()[0]<.985 and self._all_inventory_empty():
                return GreedyMappingDrone._plan_route(self,step,False,peer_goals)
            return GreedyMappingDrone._plan_route(self,step,True,peer_goals)
        return super()._plan_route(step,False,peer_goals)

    def _is_returning(self,step):return int(self.carried_bombs_count())==0

    def _placement_spacing(self,step):return 30.

    def _maybe_place(self,command,step,semantic):
        inventory=int(self.carried_bombs_count())
        if self.submitted or self.pose is None or inventory<=0 or self.pending_drop is not None:return
        if step-self.last_attempt_step<8:return
        if self.placement_goal is None or np.linalg.norm(self.pose-self.placement_goal)>self.placement_arrival_radius:return
        if not self._placement_allowed(step,semantic):return
        command.update(forward=0.,lateral=0.,rotation=0.,grasper=0,place_bomb=1)
        self.pending_drop=(inventory,self.pose.copy(),step);self.last_attempt_step=step

    def _submission_due(self,step):
        if self._remaining_steps()<=0:return True
        if not self._all_inventory_empty():return False
        if self._stable_inventory_step is None:self._stable_inventory_step=step
        own=int(self.identifier or 0);quality=self._map_quality()
        better=any(0<=step-ts<90 and (known,occupied,-peer)>(*quality,-own)
                   for peer,(ts,known,occupied) in self.map_quality_records.items() if peer!=own)
        contacts=sum(0<=step-ts<120 for peer,ts in self._contact_steps.items() if peer!=own)
        # Require an actual message exchange after completion, then submit a
        # sufficiently complete sensor map. No minimum elapsed fraction.
        return (not better and contacts>=max(1,self.team_size-2) and quality[0]>=.985
                and step-self._stable_inventory_step>=24)
