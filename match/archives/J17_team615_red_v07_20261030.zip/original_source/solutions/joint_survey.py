"""Budgeted joint task allocation using only per-drone sensor memory.

Flow: retain committed placement routes -> estimate unresolved sensor evidence
-> enumerate reachable survey views -> select one positive-value idle-agent
assignment -> broadcast a short task lease -> execute or release at deadline.
The information gain is a heuristic; it is not an expected official score.
"""
import math
import cv2
import numpy as np
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
from swarm_rescue.solutions.team_coverage import path_costs
from swarm_rescue.solutions.line_regularization import regularized_walls


def evidence_uncertainty(memory):
    measured=regularized_walls(memory.hits,fine=memory.FINE,line_width=12,
        keep_raw=False,fit_band=10,duplicate_distance=8,covariance_limit=30)
    distance=(cv2.distanceTransform(1-measured.astype(np.uint8),cv2.DIST_L2,5)*memory.FINE if measured.any() else np.full(measured.shape,np.inf))
    unexplained=(memory.hits>=2) & (distance>6.0)
    # Fine hit support is capped per coarse cell so dense repeated rays cannot
    # dominate the task value. Observed free-space coverage is not a stop gate.
    residual=cv2.resize(unexplained.astype(np.float32),
        (memory.shape[1],memory.shape[0]),interpolation=cv2.INTER_AREA)
    residual=np.minimum(1.0,residual*(float(memory.CELL)/memory.FINE)**2/4.0)
    optical=cv2.resize((memory.hits>=2).astype(np.float32),
        (memory.shape[1],memory.shape[0]),interpolation=cv2.INTER_AREA)>.04
    unknown=(~memory.free & ~optical).astype(np.float32)
    value=.85*residual+.15*unknown
    value[[0,-1],:]*=.5; value[:,[0,-1]]*=.5
    return value,optical


def visible_gain(cell,weights,opaque,cell_size,horizon=240.0):
    radius=int(math.ceil(horizon/cell_size)); row,col=cell
    r0,r1=max(0,row-radius),min(weights.shape[0],row+radius+1)
    c0,c1=max(0,col-radius),min(weights.shape[1],col+radius+1)
    rr,cc=np.nonzero(weights[r0:r1,c0:c1]>.01); rr+=r0; cc+=c0
    keep=(rr-row)**2+(cc-col)**2 <= (horizon/cell_size)**2
    ends=np.column_stack((rr[keep],cc[keep]))
    if not len(ends): return 0.0
    delta=ends-np.asarray(cell); counts=np.maximum(2,2*np.abs(delta).max(axis=1)+1)
    ids=np.arange(int(counts.max()))[None,:]
    sample=ids<(counts-1)[:,None]
    rs=np.rint(row+ids*delta[:,0,None]/(counts-1)[:,None]).astype(int)
    cs=np.rint(col+ids*delta[:,1,None]/(counts-1)[:,None]).astype(int)
    rs=np.clip(rs,0,weights.shape[0]-1); cs=np.clip(cs,0,weights.shape[1]-1)
    clear=~np.any(opaque[rs,cs] & sample,axis=1)
    return float(weights[ends[clear,0],ends[clear,1]].sum())


def survey_horizon(step,limit,inventory):
    return limit


def choose_survey_task(memory,active,blocked_ids,step,limit,failed=(),incumbent_goals=None,current_task=None):
    """Solve the one-optional-scout assignment by bounded enumeration.

    x[i,v] is binary; at most one selected task, no occupied placement agent,
    sensed graph reachability, <=240px detour and time left before next phase.
    Greedy one-exchange: maximize improvement over the ordinary task, with
    a 25 percent plus0.5 switch hurdle relative to an active feasible task.
    All values are information proxies, not official score predictions. No task is valid
    unless uncertainty>=2 cells and the new viewpoint is at least48px away.
    """
    eligible={int(k):(np.asarray(p,float),int(n)) for k,(p,n) in active.items()
        if k not in blocked_ids and np.asarray(p).shape==(2,) and np.isfinite(p).all()
        and step < survey_horizon(step,limit,n)-24}
    if not eligible: return None,{'reason':'no_idle_agent'}
    weights,opaque=evidence_uncertainty(memory)
    if float(weights.sum())<2: return None,{'reason':'no_unresolved_evidence'}
    pm=GeometryPlanningMemory(memory)
    walkable=pm.free & ~pm.blocked()
    rr,cc=np.indices(pm.shape)
    destination_allowed=walkable.copy()
    for until,point in failed:
        if step<until:
            r,c=pm.world_to_cell(point); destination_allowed[(rr-r)**2+(cc-c)**2<=4]=False
    window=max(3,int(round(2*240/pm.CELL))|1)
    proxy=cv2.boxFilter(weights,-1,(window,window),normalize=False,borderType=cv2.BORDER_CONSTANT)
    best=None; incumbent=None; tested=0
    for key,(position,inventory) in sorted(eligible.items()):
        costs=path_costs(pm,walkable,pm.world_to_cell(position))
        remaining=survey_horizon(step,limit,inventory)-step-24
        budget=min(240.0,max(0.0,remaining*2.0))
        mask=destination_allowed & np.isfinite(costs) & (costs>=48) & (costs<=budget)
        rank=np.where(mask,proxy/(1+costs/120),-np.inf)
        baseline_bid=0.0
        old=(incumbent_goals or {}).get(key)
        if old is not None:
            old_cell=pm.world_to_cell(old)
            if np.isfinite(costs[old_cell]):
                baseline_bid=visible_gain(old_cell,weights,opaque,pm.CELL)/(1+float(costs[old_cell])/120)
        if current_task is not None and key==current_task[0]:
            current_cell=pm.world_to_cell(current_task[1])
            if destination_allowed[current_cell] and np.isfinite(costs[current_cell]) and 24<=costs[current_cell]<=budget:
                gain=visible_gain(current_cell,weights,opaque,pm.CELL)
                distance=float(costs[current_cell]); score=gain/(1+distance/120)
                surplus=score-1.25*baseline_bid-.5
                if gain>=2 and surplus>0:
                    incumbent=((surplus,-distance,-key,-current_cell[0],-current_cell[1]),key,
                        pm.cell_to_world(current_cell).copy(),gain,distance,budget,baseline_bid,score)
        candidates=[]
        for flat in np.argsort(rank.ravel())[::-1]:
            cell=tuple(map(int,np.unravel_index(flat,rank.shape)))
            if not np.isfinite(rank[cell]) or rank[cell]<=0: break
            if any((cell[0]-r)**2+(cell[1]-c)**2<9 for r,c in candidates): continue
            candidates.append(cell)
            if len(candidates)>=12: break
        for cell in candidates:
            gain=visible_gain(cell,weights,opaque,pm.CELL); tested+=1
            if gain<2: continue
            distance=float(costs[cell]); score=gain/(1+distance/120)
            if score <= 1.25*baseline_bid+.5: continue
            choice=(score-1.25*baseline_bid-.5,-distance,-key,-cell[0],-cell[1])
            if best is None or choice>best[0]:
                best=(choice,key,pm.cell_to_world(cell).copy(),gain,distance,budget,baseline_bid,score)
    retained=False
    if incumbent is not None and (best is None or best[0][0]<=1.25*incumbent[0][0]+.5):
        best=incumbent; retained=True
    if best is None: return None,{'reason':'no_positive_feasible_view','tested':tested}
    _,key,point,gain,distance,budget,baseline_bid,score=best
    return (key,point),{'reason':'retained_current_task' if retained else 'selected','gain':gain,'distance':distance,
        'budget':budget,'incumbent_bid':baseline_bid,'bid':score,'net_improvement':best[0][0],'retained':retained,'tested':tested,'uncertainty':float(weights.sum())}


class JointSurveyCoverMixin:
    """Message-only coordinator with optional survey tasks and fixed drop leases."""
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.survey_plan=None
        self.survey_last_build=-1000
        self.survey_failed=[]
        self.survey_diagnostics={}

    def _survey_remaining_steps(self,step):
        # Estimate a delivery trip from the known graph, not Euclidean distance
        # through walls. The route is recomputed only on a planning tick.
        if getattr(self,'_survey_budget_step',None)==step:
            return self._survey_budget_cache
        remaining=self._remaining_steps()
        delivery=0.
        if self.rally is not None and self.pose is not None:
            route,actual=self.memory.route(self.pose,destination=self.rally)
            if actual is None:
                delivery=remaining
            else:
                points=[self.pose]+list(route)
                delivery=sum(float(np.linalg.norm(b-a)) for a,b in zip(points,points[1:]))/3.+24.
        # A scout holding inventory needs time to finish its own stops.
        inventory=int(self.carried_bombs_count())
        execution=inventory*(4.*self.blast_radius/3.+24.)
        self._survey_budget_step=step
        self._survey_budget_cache=max(0.,remaining-delivery-execution)
        return self._survey_budget_cache

    def define_message_for_all(self):
        message=super().define_message_for_all()
        message['joint_survey_plan']=self.survey_plan
        return message

    def _messages(self):
        super()._messages()
        step=int(self.elapsed_timestep)
        active=[k for k,(ts,pos,_) in self.fleet_states.items()
            if pos is not None and 0<=step-ts<self.STATE_FRESH_STEPS]
        leader=min(active) if active else int(self.identifier or 0)
        for _,message in self.communicator.received_messages:
            if not isinstance(message,dict) or message.get('kind')!='greedy-map-v1': continue
            proposal=message.get('joint_survey_plan')
            if not isinstance(proposal,(tuple,list)) or len(proposal)!=5: continue
            epoch,sender,owner,point,until=proposal
            if sender!=leader or not 0<=step-int(epoch)<120 or not step<int(until): continue
            if point is not None and (np.asarray(point).shape!=(2,) or not np.isfinite(point).all()): continue
            if self.survey_plan is None or int(epoch)>self.survey_plan[0]:
                self.survey_plan=(int(epoch),int(sender),owner,point,int(until))

    def _build_fleet_plan(self,step):
        super()._build_fleet_plan(step)
        self._build_survey_plan(step)

    def _build_survey_plan(self,step):
        active={k:(pos,n) for k,(ts,pos,n) in self.fleet_states.items()
            if pos is not None and 0<=step-ts<self.STATE_FRESH_STEPS}
        own=int(self.identifier or 0)
        if not active or own!=min(active) or step-self.survey_last_build<96: return
        self.survey_last_build=step
        # Reserve the sensor-graph return trip and acknowledged placement
        # execution, measured against the current remaining public budget.
        # There are no elapsed-time phases or inventory holdbacks.
        remaining=self._survey_remaining_steps(step)
        if remaining<=24:
            self.survey_plan=(step,own,None,None,step)
            self.survey_diagnostics={'reason':'insufficient_execution_slack'}
            return
        # Nonempty fleet routes and acknowledged/unacknowledged leases retain
        # priority. A survey task cannot revoke another controller's commitment.
        blocked=set(self._reserved_first_goals(step,active))
        if self.fleet_plan is not None:
            for peer,(initial,goals) in self.fleet_plan[2].items():
                if peer in active and len(goals)>max(0,int(initial)-active[peer][1]): blocked.add(peer)
        self.survey_failed=[(until,p) for until,p in self.survey_failed if step<until]
        incumbent_goals={peer:goal for peer,(ts,pos,goal) in self.exploration_records.items()
            if goal is not None and 0<=step-ts<120}
        if getattr(self,'_ordinary_survey_goal',None) is not None:
            incumbent_goals[own]=self._ordinary_survey_goal
        previous=self.survey_plan
        current_task=None
        if (previous is not None and previous[1]==own and previous[2] in active
            and previous[2] not in blocked and previous[3] is not None
            and 0<=step-previous[0]<120 and step<previous[4]):
            current_task=(previous[2],previous[3])
        task,info=choose_survey_task(self.memory,active,blocked,step,step+remaining,
            self.survey_failed,incumbent_goals,current_task)
        if info.get('retained'):
            # Retention must not renew the lease or bypass phase deadlines.
            self.survey_diagnostics=info
            return
        self.survey_diagnostics=info
        peer,point=(None,None) if task is None else task
        self.survey_plan=(step,own,peer,point,min(step+120,int(step+remaining)))

    def _plan_route(self,step,returning,peer_goals):
        ordinary=super()._plan_route(step,returning,peer_goals)
        self._ordinary_survey_goal=ordinary[1]
        if self.placement_goal is not None or self.assignment_goal is not None: return ordinary
        self._build_survey_plan(step)
        plan=self.survey_plan
        if plan is None: return ordinary
        epoch,leader,owner,point,until=plan
        own=int(self.identifier or 0); inventory=int(self.carried_bombs_count())
        if (owner!=own or point is None or not 0<=step-epoch<120 or step>=until
            or self._survey_remaining_steps(step)<=24): return ordinary
        point=np.asarray(point,float)
        if np.linalg.norm(self.pose-point)<24:
            self.survey_failed.append((step+180,point.copy()))
            self.survey_plan=None
            return ordinary
        route,actual=self.memory.route(self.pose,destination=point)
        if actual is None or np.linalg.norm(actual-point)>1:
            self.survey_failed.append((step+180,point.copy()))
            self.survey_plan=None
            return ordinary
        self.placement_goal=None
        return route or [point.copy()],point.copy()

