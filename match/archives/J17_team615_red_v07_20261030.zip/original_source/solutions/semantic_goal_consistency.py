"""Use existing current public BOMB safety exclusion in plan acceptance too.

No inferred inventory/certificates, no global history of anonymous objects,
no new utility/greedy rule. This is a consistency constraint for the unchanged
finite coverage/route problem. Sensor getters return the current cached data.
"""
import math
import numpy as np

class SemanticGoalConsistencyMixin:
    def _semantic_bomb_forbidden(self):
        pose=getattr(self,'pose',None)
        if pose is None:return []
        pose=np.asarray(pose,float)
        heading=float(self.heading)
        if pose.shape!=(2,) or not np.isfinite(pose).all() or not math.isfinite(heading):return []
        spacing=float(self._placement_spacing(int(self.elapsed_timestep)))
        if not math.isfinite(spacing) or spacing<=0:return []
        result=[]
        for obj in self.semantic_values() or ():
            if getattr(getattr(obj,'entity_type',None),'name','')!='BOMB':continue
            distance=float(obj.distance);angle=float(obj.angle)
            if not math.isfinite(distance) or distance<0 or not math.isfinite(angle):continue
            angle+=heading
            point=pose+distance*np.array([math.cos(angle),math.sin(angle)])
            result.append((point,spacing))
        return result

    def _placement_forbidden(self):
        # Preserve centre constraints and masks; never mutate parent containers.
        return list(super()._placement_forbidden())+self._semantic_bomb_forbidden()


    def _point_conflicts_with_drop(self,point):
        result=super()._point_conflicts_with_drop(point)
        if result:
            point=np.asarray(point,float)
            support=[(p,r) for p,r in self._semantic_bomb_forbidden() if np.linalg.norm(point-p)<r]
            if support:
                self._semantic_goal_hits=getattr(self,'_semantic_goal_hits',0)+1
                if getattr(self,'_semantic_goal_logs',0)<12:
                    import json
                    self._semantic_goal_logs=getattr(self,'_semantic_goal_logs',0)+1
                    print('[SEMANTIC_GOAL] '+json.dumps(dict(event='CURRENT_OBSERVED_BOMB_EXCLUSION',
                        owner=int(self.identifier or 0),step=int(self.elapsed_timestep),wall=float(self.elapsed_walltime),
                        target=point.tolist(),pose=np.asarray(self.pose,float).tolist(),
                        observed=[dict(position=p.tolist(),radius=r) for p,r in support],
                        confirmed_drop_count=len(self.drop_records),inventory=int(self.carried_bombs_count()),
                        pending=self.pending_drop is not None),allow_nan=False),flush=True)
        return result
