"""Sensor-driven revisit viewpoints for incompletely observed wall surfaces.

This changes navigation utility only. Arena dimensions locate potential survey
viewpoints; no border pixel is drawn or reported without actual lidar evidence.
An edge receives survey priority only after measured hits identify that side.
"""
from __future__ import annotations

import math

import cv2
import numpy as np

from swarm_rescue.solutions.fast_exploration import CoordinatedMapMemory


class EdgeSurveyMapMemory(CoordinatedMapMemory):
    """Explore empty space and inspect missing spans of measured arena edges."""

    EDGE_RANGE = 190.0
    EDGE_WEIGHT = 5.0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Sensor-confirmed clear rays beyond a hypothetical arena edge can
        # disprove that wall hypothesis. These local negative observations are
        # never used to draw a wall or to alter the communicated wall evidence.
        self.edge_no_wall = [np.zeros(self.shape[1], bool), np.zeros(self.shape[1], bool),
                             np.zeros(self.shape[0], bool), np.zeros(self.shape[0], bool)]
        self.edge_stats = {}

    def observe(self, position, heading, distances, ray_angles, semantic=()):
        super().observe(position, heading, distances, ray_angles, semantic)
        d, a = np.asarray(distances, float), np.asarray(ray_angles, float)
        theta = heading + a
        if len(d) != len(theta):
            return
        position = np.asarray(position, float)
        for side, absent in enumerate(self.edge_no_wall):
            for index in range(len(absent)):
                target = self._edge_point(side, index)
                vector = target - position
                distance = float(np.linalg.norm(vector))
                if not 35 < distance < 195:
                    continue
                bearing = math.atan2(vector[1], vector[0])
                error = np.abs((theta-bearing+math.pi) % (2*math.pi)-math.pi)
                ray = int(np.argmin(error))
                if error[ray] < math.radians(1.5) and np.isfinite(d[ray]) and d[ray] > distance + 24:
                    absent[index] = True

    def _edge_point(self, side, index):
        if side < 2:
            return np.array([(index+.5)*self.CELL-self.width/2,
                             (1 if side == 0 else -1)*(self.height/2-3.)])
        return np.array([(-1 if side == 2 else 1)*(self.width/2-3.),
                         self.height/2-(index+.5)*self.CELL])

    def edge_spans(self):
        """Missing coarse spans only on physically evidenced boundary sides."""
        measured = self.hits >= 2
        band = max(2, int(math.ceil(16/self.FINE)))
        sides = [measured[:band].sum(axis=0), measured[-band:].sum(axis=0),
                 measured[:, :band].sum(axis=1), measured[:, -band:].sum(axis=1)]
        result = []
        for side, evidence in enumerate(sides):
            flag = (evidence >= 1).astype(np.uint8)
            # Match the renderer's evidence rule and limited 40px closing.
            flag = cv2.morphologyEx(flag[None, :], cv2.MORPH_CLOSE,
                                   np.ones((1, max(1, int(40/self.FINE))), np.uint8))[0]
            length = self.shape[1] if side < 2 else self.shape[0]
            stride = self.CELL / self.FINE
            observed = np.zeros(length, bool)
            for index in range(length):
                lo, hi = int(index*stride), min(len(flag), int((index+1)*stride))
                observed[index] = hi > lo and np.mean(flag[lo:hi]) >= .5
            # Navigation may seek the missing continuation of an observed line,
            # but an unobserved side cannot be assumed to contain a wall.
            identified = bool(np.count_nonzero(flag)*self.FINE >= 96 and observed.sum() >= 4)
            missing = ~observed & ~self.edge_no_wall[side] if identified else np.zeros(length, bool)
            # Short gaps are already bridged by rendering and have low value.
            run_start = None
            for index in range(length+1):
                active = index < length and missing[index]
                if active and run_start is None:
                    run_start = index
                elif not active and run_start is not None:
                    if index-run_start < 3:
                        missing[run_start:index] = False
                    run_start = None
            result.append(missing)
            self.edge_stats[side] = dict(identified=identified, observed=int(observed.sum()),
                                         missing=int(missing.sum()), bins=length)
        return result

    def survey_gain(self, blocked=None):
        """Unseen physical edge length visible from free interior viewpoints."""
        if blocked is None:
            blocked = self.blocked()
        free = self.free & ~blocked
        rr, cc = np.indices(self.shape)
        gain = np.zeros(self.shape, np.float32)
        sides = self.edge_spans()
        # Visibility concerns optical wall occlusion, rather than robot-footprint
        # inflation. A ray can observe a wall even though its last cells are not
        # suitable positions for the robot itself.
        coarse_wall = cv2.resize((self.hits >= 2).astype(np.float32),
            (self.shape[1], self.shape[0]), interpolation=cv2.INTER_AREA) >= .035
        for side, missing in enumerate(sides):
            indices = np.flatnonzero(missing)
            if not len(indices):
                continue
            if side == 0:
                perpendicular = (rr+.5)*self.CELL - 3
                along = cc
            elif side == 1:
                perpendicular = self.height - (rr+.5)*self.CELL - 3
                along = cc
            elif side == 2:
                perpendicular = (cc+.5)*self.CELL - 3
                along = rr
            else:
                perpendicular = self.width - (cc+.5)*self.CELL - 3
                along = rr
            candidates = free & (perpendicular >= 45) & (perpendicular <= self.EDGE_RANGE)
            for row, col in zip(*np.nonzero(candidates)):
                longitudinal = (indices-int(along[row, col]))*self.CELL
                distance = np.hypot(longitudinal, perpendicular[row, col])
                visible = indices[distance <= self.EDGE_RANGE]
                if not len(visible):
                    continue
                # Evaluate three sample lines through the unseen span, so an
                # intervening internal wall does not masquerade as map gain.
                ordered = visible[np.argsort(np.abs(visible-int(along[row, col])))]
                clear_samples = 0
                for index in ordered[:3]:
                    end = self.world_to_cell(self._edge_point(side, int(index)))
                    lr, lc = self._line_cells((int(row), int(col)), end)
                    # Last cell is the edge being measured, not an obstruction.
                    if len(lr) > 1 and not coarse_wall[lr[:-1], lc[:-1]].any():
                        clear_samples += 1
                if clear_samples:
                    gain[row, col] += len(visible) * clear_samples / min(3, len(ordered))
        return gain

    def exploration_utility(self, position, peers=(), survey=None):
        blocked = self.blocked()
        unknown = (~self.free & ~blocked).astype(np.float32)
        information = cv2.boxFilter(unknown, -1, (13, 13), normalize=False,
                                    borderType=cv2.BORDER_CONSTANT)
        adjacent = cv2.dilate(unknown.astype(np.uint8), np.ones((3,3), np.uint8)) > 0
        if survey is None:
            survey = self.survey_gain(blocked)
        rr, cc = np.indices(self.shape)
        start = self.world_to_cell(position)
        far = (rr-start[0])**2 + (cc-start[1])**2 >= 5
        eligible = (adjacent | (survey > .5)) & far
        utility = (information + self.EDGE_WEIGHT*survey) - .25*self.visits
        utility[~eligible] = -np.inf
        origin = self.world_to_cell(self.origin if self.origin is not None else position)
        angle = np.arctan2(origin[0]-rr, cc-origin[1])
        utility *= 1.0 + .20*np.cos(angle-2*math.pi*self.identifier/self.team_size)
        reservations = self.reservations or [(0, p, None, -1) for p in peers if p is not None]
        for age, goal, peer_pos, peer_id in reservations:
            if goal is None or age > 400:
                continue
            gr, gc = self.world_to_cell(goal)
            squared = (rr-gr)**2 + (cc-gc)**2
            strength = (.86 if peer_id < self.identifier else .58)*max(.25, 1-age/550)
            utility *= 1-strength*np.exp(-squared/65.)
            if peer_id < self.identifier and age < 80:
                utility[squared < 9] = -np.inf
        self.failed_goals = [(until, point) for until, point in self.failed_goals if until > self.step]
        for _, point in self.failed_goals:
            fr, fc = self.world_to_cell(point)
            utility[(rr-fr)**2 + (cc-fc)**2 <= 9] = -np.inf
        return utility

    def route(self, position, identifier=0, peers=(), destination=None, utility=None):
        if destination is not None:
            if self.world_to_cell(position) == self.world_to_cell(destination):
                return [], np.asarray(destination, float).copy()
            return super().route(position, identifier, peers, destination, utility)
        if utility is not None:
            return super().route(position, identifier, peers, destination, utility)
        survey = self.survey_gain()
        if not np.any(survey > .5):
            return super().route(position, identifier, peers)
        values = self.exploration_utility(position, peers, survey=survey)
        route, goal = super().route(position, identifier, peers, utility=values)
        if goal is None:
            return super().route(position, identifier, peers)
        previous = self.exploration_goal
        if previous is not None and np.linalg.norm(previous-np.asarray(position)) > 30:
            old_cell, new_cell = self.world_to_cell(previous), self.world_to_cell(goal)
            if (np.isfinite(values[old_cell]) and values[old_cell] >= .85*values[new_cell]
                    and self.step-self.last_exploration_goal_step < 120):
                old_route, old_actual = super().route(position, destination=previous)
                if old_actual is not None and np.linalg.norm(old_actual-previous) < 20:
                    route, goal = old_route, previous.copy()
        if previous is None or self.world_to_cell(previous) != self.world_to_cell(goal):
            self.last_exploration_goal_step = self.step
        self.exploration_goal = np.asarray(goal, float).copy()
        return route, goal
