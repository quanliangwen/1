"""Public-input local tracker prototype. Not integrated into a game payload."""
import math
import numpy as np
from swarm_rescue.solutions.local_motion_qp import instantaneous_velocity,scan_and_raw_halfplanes,odometry_velocity_upper
from swarm_rescue.solutions.joint_backup_qp import local_command,safe_legacy_command,COMMAND_NORMALS
from swarm_rescue.solutions.scan_geometry import extract_scan_lines
from swarm_rescue.solutions.greedy_mapping import MapMemory

def rotate(v,theta):
    c,s=math.cos(theta),math.sin(theta)
    return np.array([c*v[0]-s*v[1],s*v[0]+c*v[1]])

def actuator_command_vector(vector):
    """SDK bounds are exact; remove only QP arithmetic residuals at output."""
    u=np.asarray(vector,float)
    if u.shape!=(2,) or not np.isfinite(u).all():raise ValueError('Invalid QP actuator vector')
    if np.max(np.abs(u))>1.+1e-7 or np.linalg.norm(u)>1.+1e-7:
        raise ValueError('QP actuator vector exceeds numerical residual allowance')
    u=np.clip(u,-1.,1.)
    size=float(np.linalg.norm(u))
    if size>1.:u/=size
    return np.clip(u,-1.,1.)

def record_final_command(drone,command):
    step=int(drone.elapsed_timestep)
    u=np.array([command.get('forward',0.),command.get('lateral',0.)],float)
    if not np.isfinite(u).all():raise ValueError('Non-finite applied command')
    u=np.clip(u,-1.,1.)
    u/=max(1.,float(np.linalg.norm(u)))
    drone._qp_previous_command=u
    drone._qp_previous_rotation=float(command.get('rotation',0.))
    drone._qp_previous_step=step
    odom=drone.odometer_values()
    drone._qp_previous_odom_valid=bool(odom is not None and np.asarray(odom).shape==(3,) and np.isfinite(odom).all())

def track_command(drone,distances,angles,semantic,legacy):
    """legacy(cell_ack: bool) is invoked exactly once on every path."""
    step=int(drone.elapsed_timestep)
    def fallback(reason):return legacy(False),dict(mode=reason,guarded_handoff=False)
    if (getattr(drone,'placement_goal',None) is None or int(drone.carried_bombs_count())<=0
            or not drone.waypoints or step<int(drone.escape_until)):
        return fallback('ORIGINAL_NONCOMMIT_OR_ESCAPE')
    if getattr(drone,'_qp_previous_step',-100)!=step-1 or not getattr(drone,'_qp_previous_odom_valid',False):
        return fallback('ORIGINAL_NO_CONSECUTIVE_PUBLIC_COMMAND')
    if abs(getattr(drone,'_qp_previous_rotation',0.))>1e-10:
        return fallback('ORIGINAL_PREVIOUS_YAW_COMMAND')
    odom=drone.odometer_values()
    if odom is None or np.asarray(odom).shape!=(3,) or not np.isfinite(odom).all():return fallback('ORIGINAL_MISSING_ODOMETRY')
    d,alpha,turn=map(float,odom)
    if d<-.6:return fallback('ORIGINAL_ODOMETRY_OUTSIDE_ERROR_BOX')
    if abs(turn)>math.radians(10):return fallback('ORIGINAL_ROTATION_OUTSIDE_LOCAL_MODEL')
    for obj in semantic or ():
        if getattr(getattr(obj,'entity_type',None),'name','')=='DRONE' and float(obj.distance)<84.:
            return fallback('ORIGINAL_NEAR_MOVING_DRONE')
    ranges=np.asarray(distances,float).copy();rays=np.asarray(angles,float)
    if ranges.ndim!=1 or ranges.shape!=rays.shape or len(ranges)>512 or not np.isfinite(rays).all():return fallback('ORIGINAL_UNSUPPORTED_SCAN')
    finite=np.isfinite(ranges)&(ranges>0)
    if not finite.any():return fallback('ORIGINAL_MISSING_SCAN')
    passable=MapMemory.semantic_mask(ranges,rays,semantic,('BOMB',))
    ranges[passable]=300.
    average=d*np.array([math.cos(alpha-turn),math.sin(alpha-turn)])
    velocity=instantaneous_velocity(average,rotate(drone._qp_previous_command,-turn))
    if np.linalg.norm(velocity)>12.+1e-8:return fallback('ORIGINAL_SPEED_OUTSIDE_LOCAL_MODEL')
    lines=extract_scan_lines(ranges,rays)
    try:normals,limits=scan_and_raw_halfplanes(lines,ranges,rays)
    except ValueError as error:
        if str(error)!='Unusable segment through sensor origin':raise
        return fallback('ORIGINAL_UNUSABLE_LOCAL_SEGMENT')
    position=np.asarray(drone.pose,float);heading=float(drone.heading)
    if position.shape!=(2,) or not np.isfinite(position).all() or not math.isfinite(heading):return fallback('ORIGINAL_INVALID_POSE')
    preview=list(drone.waypoints)
    while (len(preview)>1 and np.linalg.norm(preview[0]-position)<22 and
            drone.memory.world_to_cell(position)==drone.memory.world_to_cell(preview[0])):
        preview.pop(0)
    target=np.asarray(preview[0],float);error=rotate(target-position,-heading)
    deferred=(len(preview)>1 and np.linalg.norm(target-position)<22 and
              drone.memory.world_to_cell(position)!=drone.memory.world_to_cell(target))
    upper=odometry_velocity_upper(odom,drone._qp_previous_command,normals)
    face_upper=odometry_velocity_upper(odom,drone._qp_previous_command,COMMAND_NORMALS)
    probe=local_command(error,velocity,normals,limits,toward_upper=upper,velocity_face_upper=face_upper)
    if probe is None:return fallback('ORIGINAL_INFEASIBLE_STATIC_MODEL')
    command=legacy(True)
    if not np.array_equal(np.asarray(drone.waypoints[0]),target):raise RuntimeError('Preview and actual waypoint handoff differ')
    near=float(np.linalg.norm(error))<=2.*float(drone.memory.CELL)
    if near:result=probe;mode='TRACKING_QP'
    else:
        result=safe_legacy_command([command.get('forward',0.),command.get('lateral',0.)],velocity,normals,limits,toward_upper=upper,velocity_face_upper=face_upper)
        if result is None:raise RuntimeError('Previously feasible local corridor became infeasible')
        mode=result['mode']
    command['forward'],command['lateral']=map(float,actuator_command_vector(result['command']))
    return command,dict(mode=mode,guarded_handoff=bool(deferred),
        stationarity=float(result['stationarity']),primal_violation=float(result['primal_violation']),
        wall_constraints=len(normals),fit_segments=len(lines),target_distance=float(np.linalg.norm(error)),
        backup_speed_mode=float(result['speed_mode']),union_modes_solved=int(result.get('union_modes_solved',0)),
        union_lower_bound_attained=bool(result.get('union_lower_bound_attained',False)))
