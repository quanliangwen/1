"""Per-instance, idempotent public hit-bearing evidence grafted onto parent memory."""
import math
import time

import numpy as np

from swarm_rescue.solutions.bearing_core import (
    add_corrobated_wall_value, corroborated_map, fine_any_to_four, hit_direction_bits,
)
from swarm_rescue.solutions.geometry_navigation import GeometryRouteMemory


class BearingMemory(GeometryRouteMemory):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.bearing_bits = np.zeros(((self.height + 3) // 4, (self.width + 3) // 4), np.uint8)
        self._bearing_frame_step = None
        self._bearing_audit_prints = 0
        self.bearing_source_frames = 0
        self.bearing_merged_packets = 0

    def _retract_nonwall(self):
        mask = getattr(self, 'nonwall_mask', None)
        if mask is not None:
            mask = np.asarray(mask, bool)
            if mask.shape == self.hits.shape:
                self.bearing_bits[fine_any_to_four(mask, self.bearing_bits.shape)] = 0

    def observe(self, position, heading, distances, ray_angles, semantic=()):
        super().observe(position, heading, distances, ray_angles, semantic)
        step = float(self.step)
        if not math.isfinite(step) or step < 0 or step != int(step) or step == self._bearing_frame_step:
            self._retract_nonwall()
            return
        self._bearing_frame_step = int(step)
        d = np.asarray(distances, float)
        a = np.asarray(ray_angles, float)
        if d.ndim != 1 or d.shape != a.shape:
            self._retract_nonwall()
            return
        excluded = self.semantic_mask(d, a, semantic)
        ids, bits = hit_direction_bits(position, heading, d, a, excluded, self.width, self.height)
        if len(ids):
            np.bitwise_or.at(self.bearing_bits.ravel(), ids, bits)
            self.bearing_source_frames += 1
        self._retract_nonwall()

    def packet(self):
        ids = np.flatnonzero(self.bearing_bits.ravel()).astype(np.int32)
        return (super().packet(), (ids, self.bearing_bits.ravel()[ids].copy()))

    def merge(self, packet):
        if (isinstance(packet, (tuple, list)) and len(packet) == 2
                and isinstance(packet[0], (tuple, list)) and len(packet[0]) == 4):
            super().merge(packet[0])
            evidence = packet[1]
            if isinstance(evidence, (tuple, list)) and len(evidence) == 2:
                ids = np.asarray(evidence[0])
                bits = np.asarray(evidence[1])
                if (ids.ndim == 1 and bits.shape == ids.shape and ids.dtype.kind in 'iu'
                        and bits.dtype.kind in 'uib' and
                        (not len(ids) or (int(ids.min()) >= 0 and int(ids.max()) < self.bearing_bits.size))):
                    np.bitwise_or.at(self.bearing_bits.ravel(), ids.astype(np.intp), bits.astype(np.uint8))
                    self.bearing_merged_packets += 1
        else:
            super().merge(packet)
        self._retract_nonwall()

    def bearing_fields(self):
        started = time.perf_counter()
        parent = super().render()
        image, audit = corroborated_map(parent, self.hits, self.bearing_bits,
                                        self.width, self.height, getattr(self, 'nonwall_mask', None))
        self.last_bearing_audit = dict(audit)
        if self._bearing_audit_prints < 8:
            print('[multi-bearing]', int(getattr(self, 'identifier', 0)), int(self.step),
                  dict(audit, source_frames=self.bearing_source_frames,
                       received_packets=self.bearing_merged_packets,
                       enclosing_elapsed=time.perf_counter() - started), flush=True)
            self._bearing_audit_prints += 1
        return image, parent

    def bearing_wall_values(self, values):
        image, parent = self.bearing_fields()
        return add_corrobated_wall_value(values, image, parent, self.CELL,
                                         self.width, self.height)

    def render(self):
        image, _ = self.bearing_fields()
        return image


class BearingMappingMixin:
    def __init__(self, identifier=None, misc_data=None, **kwargs):
        super().__init__(identifier=identifier, misc_data=misc_data, **kwargs)
        self.memory = BearingMemory(*self.size_area, identifier=int(identifier or 0),
                                    team_size=self.team_size)
        self.memory.frame_records = self.frame_records
        self.memory.frame_negative = self.frame_negative
