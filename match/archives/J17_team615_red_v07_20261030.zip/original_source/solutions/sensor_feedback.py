"""Velocity feedback from public per-step odometry, independent of pose resets."""
import math
import numpy as np


def feedback_velocity(drone, fallback):
    counts = getattr(drone, 'feedback_audit', None)
    if counts is None:
        counts = {'calls': 0, 'odometry': 0, 'fallback': 0}
        drone.feedback_audit = counts
    counts['calls'] += 1
    odometry = drone.odometer_values()
    if odometry is not None:
        odometry = np.asarray(odometry, dtype=float)
        if odometry.shape == (3,) and np.isfinite(odometry).all():
            # Alpha is measured in the preceding body frame; undo this step's yaw.
            angle = float(drone.heading) + float(odometry[1]) - float(odometry[2])
            counts['odometry'] += 1
            return float(odometry[0]) * np.array([math.cos(angle), math.sin(angle)])
    counts['fallback'] += 1
    return np.asarray(fallback, dtype=float).copy()
