"""Submission-only prior from the competition's public closed-arena rule.

All advertised arenas have four enclosing walls, min thickness6px, flush with
the publicly supplied rectangle. This cannot be applied to an open arena.
No map class/name, interior wall coordinates or playground instance is read.
"""
import numpy as np

PUBLIC_MIN_BORDER_THICKNESS=6
PUBLIC_SCORER_SURFACE_DEPTH=4

def complete_public_closed_boundary(image,size_area,*,closed_arena_rule=False):
    audit=dict(applied=False,reason='CLOSED_ARENA_PREMISE_NOT_ENABLED',added_pixels=0)
    if not closed_arena_rule:return image,audit
    size=np.asarray(size_area)
    grid=np.asarray(image)
    if (size.shape!=(2,) or not np.issubdtype(size.dtype,np.number) or
        not np.isfinite(size).all() or not np.equal(size,np.rint(size)).all()):
        return image,dict(audit,reason='UNSUPPORTED_PUBLIC_SIZE')
    width,height=map(int,size)
    if grid.ndim!=2 or grid.shape!=(height,width):
        return image,dict(audit,reason='NONCANONICAL_SUBMISSION_SHAPE')
    if not (np.issubdtype(grid.dtype,np.number) or grid.dtype==np.bool_) or not np.isfinite(grid).all():
        return image,dict(audit,reason='UNSUPPORTED_PIXEL_VALUES')
    t=PUBLIC_MIN_BORDER_THICKNESS
    if min(width,height)<=2*t:return image,dict(audit,reason='PUBLIC_SIZE_TOO_SMALL')
    frame=np.zeros(grid.shape,bool)
    frame[:t,:]=True;frame[-t:,:]=True;frame[:,:t]=True;frame[:,-t:]=True
    added=frame & (grid==0);result=grid.copy();result[added]=1
    # Diagnostic lower bound only: official obstacle_depth includes free
    # exterior, hence every known true pixel in the outer4 ring is surface.
    surface=np.zeros(grid.shape,bool);s=PUBLIC_SCORER_SURFACE_DEPTH
    surface[:s,:]=True;surface[-s:,:]=True;surface[:,:s]=True;surface[:,-s:]=True
    return result,dict(applied=True,reason='PUBLIC_CLOSED_FRAME_MINIMUM_SUBSET',added_pixels=int(added.sum()),
        guaranteed_new_surface_hits=int(np.count_nonzero(added&surface)),surface_depth_assumption=s,
        prior_pixels=int(frame.sum()),public_size=[width,height],canonical_shape=list(grid.shape),
        minimum_thickness=t,input_nonzero=int(np.count_nonzero(grid)),output_nonzero=int(np.count_nonzero(result)),
        scope='Known public frame only, no inferred interior or observed-memory modification. Not applicable to open arenas.')


"""Only the final submission hook changes; no perception or motion override."""
import json

class PublicClosedBoundaryMixin:
    PUBLIC_CLOSED_ARENA_PREMISE=True
    def submit_exploration_map(self,image,*args,**kwargs):
        corrected,audit=complete_public_closed_boundary(image,self.size_area,
            closed_arena_rule=bool(self.PUBLIC_CLOSED_ARENA_PREMISE))
        if audit['applied']:
            import hashlib
            audit['input_sha256']=hashlib.sha256(np.asarray(image).tobytes()).hexdigest()
            audit['output_sha256']=hashlib.sha256(np.asarray(corrected).tobytes()).hexdigest()
        self.public_boundary_diagnostics=audit
        frame=getattr(getattr(self,'memory',None),'frame_diagnostics',{})
        original_frame=dict(available=bool(frame),accepted=bool(frame.get('accepted',False)),
            closed=bool(frame.get('closed',False)),reason=str(frame.get('reason','unavailable')),
            confirmed_openings_count=len(frame.get('confirmed_openings',[])))
        print('[PUBLIC_FRAME_PRIOR] '+json.dumps(dict(owner=int(self.identifier or 0),step=int(self.elapsed_timestep),
            wall=float(self.elapsed_walltime),prior=audit,original_frame=original_frame),allow_nan=False),flush=True)
        return super().submit_exploration_map(corrected,*args,**kwargs)
