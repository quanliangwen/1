"""Message-fused measured line families support a revocable rectangle prior."""
import math
import numpy as np

from swarm_rescue.solutions.anchor_mapping import AnchoredMapMemory
from swarm_rescue.solutions.rectangular_boundary import RectangularBoundaryInference
from swarm_rescue.solutions.scan_geometry import extract_scan_lines,transform_points
from swarm_rescue.solutions.short_wall_support import add_short_wall_support


class InferredFrameMemory(AnchoredMapMemory):
    def render(self):
        base=super().render()
        base=add_short_wall_support(self,base,mode='box_dense',density=2)
        model=RectangularBoundaryInference(self.width,self.height,world_axis_prior=True,
                                            plane_coordinate_guard=10,plane_mad_limit=3.5,
                                            maximum_line_angle_deg=2,maximum_line_normal_spread=8)
        grouped={}
        for source,step,lines,origin,endpoints,*_ in getattr(self,'frame_records',{}).values():
            grouped[(source,step)]=[source,step,lines,origin,list(endpoints)]
        for entries in getattr(self,'frame_negative',{}).values():
            for _,source,step,origin,endpoint in entries:
                record=grouped.setdefault((source,step),[source,step,[],origin,[]])
                record[4].append(endpoint)
        model.ingest_batch(grouped.values())
        self.frame_diagnostics=model.diagnostics()
        return model.render(base)


class FrameMappingMixin:
    def __init__(self,identifier=None,misc_data=None,**kwargs):
        super().__init__(identifier=identifier,misc_data=misc_data,**kwargs)
        self.memory=InferredFrameMemory(*self.size_area,identifier=int(identifier or 0),team_size=self.team_size)
        self.frame_records={}
        self.memory.frame_records=self.frame_records
        self.frame_negative={}
        self.memory.frame_negative=self.frame_negative

    def define_message_for_all(self):
        message=super().define_message_for_all()
        message['frame_records']=dict(self.frame_records)
        message['frame_negative']=dict(self.frame_negative)
        return message

    def _messages(self):
        super()._messages()
        for _,message in self.communicator.received_messages:
            if not isinstance(message,dict): continue
            for key,record in message.get('frame_records',{}).items():
                if key not in self.frame_records: self.frame_records[key]=record
            for key,entries in message.get('frame_negative',{}).items():
                for entry in entries: self._retain_negative(key,entry)
        self._limit_frame_records()

    def _limit_frame_records(self):
        if len(self.frame_records)<=384: return
        retained=set()
        ordered=sorted(self.frame_records,key=lambda key:key[1],reverse=True)
        for side in range(4):
            chosen=[key for key in ordered if side in self.frame_records[key][5]][:80]
            retained.update(chosen)
        self.frame_records={key:self.frame_records[key] for key in retained}
        self.memory.frame_records=self.frame_records

    def _update_pose(self):
        super()._update_pose()
        step=int(self.elapsed_timestep)
        if self.pose is None or step%4: return
        lidar=self.lidar_values()
        if lidar is None: return
        distances=np.asarray(lidar,float)
        angles=np.asarray(self.lidar_rays_angles(),float)
        excluded=self.memory.semantic_mask(distances,angles,self.semantic_values())
        # Every raw ray can refute a frame hypothesis even when no long wall
        # line is visible in that scan. Never discard these opening witnesses.
        valid=np.isfinite(distances)&(distances>12)&(distances<=302)
        ids=np.flatnonzero(valid)
        theta=self.heading+angles[ids]
        ranges=np.maximum(0,distances[ids]-12)
        ends=self.pose+np.column_stack((np.cos(theta),np.sin(theta)))*ranges[:,None]
        self._collect_negative(step,ends)
        lines=extract_scan_lines(distances,angles,excluded)
        accepted=[]
        sides=set()
        for first,last,_ in lines:
            world=transform_points(np.array([first,last]),self.pose,self.heading)
            vector=world[1]-world[0]
            angle=math.atan2(vector[1],vector[0])
            if abs((angle+math.pi/4)%(math.pi/2)-math.pi/4)>math.radians(8): continue
            vertical=abs(vector[1])>abs(vector[0])
            axis=0 if vertical else 1
            midpoint=world[:,axis].mean()
            extent=self.memory.width if axis==0 else self.memory.height
            if abs(abs(midpoint)-extent/2)>max(12,.025*extent): continue
            if np.linalg.norm(vector)<60: continue
            accepted.append(world.copy())
            sides.add(axis*2+int(midpoint>=0))
        if not accepted: return
        valid=np.isfinite(distances)&(distances>12)&(distances<=302)
        ids=np.flatnonzero(valid)[::8]
        theta=self.heading+angles[ids]
        ranges=np.maximum(0,distances[ids]-12)
        ends=self.pose+np.column_stack((np.cos(theta),np.sin(theta)))*ranges[:,None]
        own=int(self.identifier or 0)
        self.frame_records[(own,step)]=(own,step,np.asarray(accepted),self.pose.copy(),ends.copy(),tuple(sides))
        self._limit_frame_records()

    def _retain_negative(self,key,entry):
        merged=list(self.frame_negative.get(key,[]))+[entry]
        unique={}
        for record in merged:
            # Different rays in one scan may refute different learned-plane
            # intervals. Public-plane confidence cannot safely rank them after
            # the fitted plane moves; only exact gossip duplicates are removed.
            endpoint=np.asarray(record[4],float)
            provenance=(int(record[1]),int(record[2]),int(key[1]),
                        float(endpoint[0]),float(endpoint[1]))
            if provenance not in unique or record[0]>unique[provenance][0]: unique[provenance]=record
        self.frame_negative[key]=list(unique.values())

    def _collect_negative(self,step,endpoints):
        own=int(self.identifier or 0)
        for axis,extent in ((0,self.memory.width),(1,self.memory.height)):
            for sign in (-1,1):
                plane=sign*extent/2
                candidates=endpoints[sign*(endpoints[:,axis]-plane)>5]
                for endpoint in candidates:
                    delta=endpoint-self.pose
                    # The final public-axis model permits its learned plane to
                    # differ from the public limit by at most 10 px. An origin
                    # up to 2 px beyond that limit can still be 8 px inside a
                    # valid learned plane. Do not pre-reject that witness.
                    plane_guard=10.0
                    rounding_margin=1e-3+8*np.finfo(np.float32).eps*(
                        max(abs(self.pose))+max(abs(endpoint))+extent)
                    if sign*(self.pose[axis]-plane)>plane_guard-8+rounding_margin or abs(delta[axis])<1e-6: continue
                    fraction=(plane-self.pose[axis])/delta[axis]
                    # This public intersection is only a storage bucket; the
                    # final audit checks intersection with the learned plane.
                    along=float(self.pose[1-axis]+fraction*delta[1-axis])
                    side=axis*2+int(sign>0)
                    normal_sigma=math.sqrt(5**2+(2.5*delta[axis]/max(1,np.linalg.norm(delta)))**2+
                                           (math.radians(4)*delta[1-axis])**2)
                    required=20+3*normal_sigma
                    penetration=sign*(endpoint[axis]-plane)
                    # Keep every ray that could satisfy the final confidence
                    # test anywhere in the allowed plane interval. Equality is
                    # retained because the final audit uses >=; the margin also
                    # covers its float32 coordinate conversion.
                    if penetration+plane_guard+rounding_margin<required: continue
                    confidence=float(penetration/required)
                    key=(own,side,int(math.floor(along/8)))
                    self._retain_negative(key,(confidence,own,step,self.pose.copy(),endpoint.copy()))
