"""Certified enumeration/branch-and-bound for at most two remaining slots.

All declared sites remain eligible. Individual coverage sums are admissible
upper bounds for pair union, so sorting/pruning never discards a possible
strict improvement. This is an exact finite-domain subproblem, not greedy.
"""
import math
import time
import numpy as np


def solve_small_inventory(owner_ids, inventories, start_costs, between, points,
                          cover, weights, budgets, separation, time_limit=2.):
    from swarm_rescue.solutions.exact_layout_decomposition import allocate_exact
    started = time.perf_counter()
    slots = sum(inventories.values())
    if slots > 2 or any(inventories[i] < 0 for i in owner_ids):
        raise ValueError('Only zero, one or two total slots')
    points = np.asarray(points, float)
    cover = np.asarray(cover, bool)
    weights = np.asarray(weights, float)
    if cover.shape != (len(points), len(weights)) or not np.isfinite(weights).all() or np.any(weights < 0):
        raise ValueError('Invalid coverage data')
    if any(math.isnan(budgets[i]) or budgets[i] < 0 for i in owner_ids):
        raise ValueError('Invalid route budget')
    # Feasible routes must have finite graph length even for unlimited budget.
    # The shared first-feasible DP compares costs with <=, so use the largest
    # finite float instead of infinity to prevent inf <= inf admitting a gap.
    budgets = {i: float(budgets[i]) if math.isfinite(budgets[i])
               else math.nextafter(math.inf, 0.) for i in owner_ids}
    metric = between if callable(between) else lambda j, k: float(between[j, k])
    graph_pairs = {}
    def distance(j, k):
        if (j, k) not in graph_pairs:
            value = float(metric(j, k))
            if math.isnan(value) or value < 0:
                raise ValueError('Invalid graph distance')
            graph_pairs[j, k] = value
        return graph_pairs[j, k]
    gains = np.einsum('ij,j->i', cover, weights, optimize=False)
    eligible = [j for j in range(len(points)) if any(inventories[i] > 0
        and math.isfinite(float(start_costs[i][j]))
        and 0 <= float(start_costs[i][j]) <= budgets[i]+1e-8 for i in owner_ids)]
    order = sorted(eligible, key=lambda j: (-float(gains[j]), j))
    plan = {i: [] for i in owner_ids}
    costs = {str(i): 0. for i in owner_ids}
    best_count, best_cover, checked, cut_by_bound = 0, 0., 0, 0
    if slots and order:
        # Best feasible singleton is exact because all gains were evaluated.
        chosen = order[0]
        plan, costs = allocate_exact([chosen], owner_ids, inventories, start_costs, distance, budgets)
        if plan is None:
            raise RuntimeError('Eligible singleton unexpectedly infeasible')
        best_count, best_cover = 1, float(gains[chosen])
    optimal = True
    if slots == 2:
        for pos, j in enumerate(order):
            if best_count == 2 and pos+1 < len(order) and float(gains[j]+gains[order[pos+1]]) <= best_cover+1e-9:
                cut_by_bound += len(order)-pos-1
                break
            for k in order[pos+1:]:
                if checked % 16 == 0 and time.perf_counter()-started >= time_limit:
                    optimal = False
                    break
                upper = float(gains[j]+gains[k])
                if best_count == 2 and upper <= best_cover+1e-9:
                    cut_by_bound += 1
                    break
                checked += 1
                if np.linalg.norm(points[j]-points[k]) < separation-1e-8:
                    continue
                covered = float(weights[cover[j] | cover[k]].sum())
                if best_count == 2 and covered <= best_cover+1e-9:
                    continue
                candidate, candidate_costs = allocate_exact([j, k], owner_ids, inventories,
                                                            start_costs, distance, budgets)
                if candidate is None:
                    continue
                plan, costs = candidate, candidate_costs
                best_count, best_cover = 2, covered
            if not optimal:
                break
    dominance = float(weights.sum())+1.
    objective = dominance*best_count+best_cover
    # Conservative upper bound remains valid after a time-limited stop.
    possible_count = min(slots, len(order))
    upper_coverage = min(float(weights.sum()), sum(float(gains[j]) for j in order[:possible_count]))
    bound = objective if optimal else dominance*possible_count+upper_coverage
    audit = dict(status=2 if optimal else 9, solution_count=1, objective=objective,
        bound=bound, gap=abs(bound-objective)/abs(objective) if objective else 0. if bound == 0 else None,
        selected_slots=best_count, covered_weight=best_cover, route_costs=costs,
        requested_slots=slots, variables=0, constraints=0, node_count=checked,
        pairs_checked=checked, branches_pruned_by_valid_bound=cut_by_bound,
        graph_pair_queries=len(graph_pairs), allocation_subproblems=checked+int(best_count > 0),
        heuristic_effort=0, threads=1, formulation='exact_small_inventory_coverage_branch_and_bound',
        solver='complete_enumeration_with_admissible_union_upper_bounds',
        elapsed=time.perf_counter()-started)
    return plan, audit
