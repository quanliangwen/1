"""Exact Hall-type necessary inequalities for the route-allocation master."""
import numpy as np

def reachability_capacity_rows(owner_ids,inventories,start_costs,budgets,n_sites):
    owners=list(owner_ids);patterns=np.zeros(n_sites,dtype=np.int64)
    for k,owner in enumerate(owners):
        costs=np.asarray(start_costs[owner],float)
        if costs.shape!=(n_sites,):raise ValueError('Invalid start-cost shape')
        if inventories[owner]>0:
            eligible=np.isfinite(costs)&(costs>=0)&(costs<=budgets[owner]+1e-8)
            patterns[eligible]|=1<<k
    full=(1<<len(owners))-1;rows=[]
    for subset in range(1,full):
        capacity=sum(inventories[owner] for k,owner in enumerate(owners) if subset&(1<<k))
        sites=np.flatnonzero((patterns!=0)&((patterns&subset)==patterns))
        # When each binary site already has upper bound1, this row would be
        # tautological. Omitting it is exact algebraic redundancy removal.
        if len(sites)>capacity:rows.append((subset,sites.tolist(),int(capacity)))
    return rows,patterns
