"""Exact QP over a finite union of realizable shared-backup terminal sets.

Known velocity/fixed convex corridor gives model recursive feasibility.
Gaussian measurement boxes/changing scans do not inherit that guarantee.
"""
import math
import numpy as np
from swarm_rescue.solutions.local_motion_qp import coefficients,project_polygon

FACES=16
GAMMA=math.cos(math.pi/FACES)
theta=(np.arange(FACES)+.5)*2*math.pi/FACES
COMMAND_NORMALS=np.c_[np.cos(theta),np.sin(theta)]
COMMAND_VERTICES=np.c_[np.cos(np.arange(FACES)*2*math.pi/FACES),np.sin(np.arange(FACES)*2*math.pi/FACES)]
SUB_A=np.array([coefficients(s)[0] for s in range(1,11)])
SUB_B=np.array([coefficients(s)[1] for s in range(1,11)])
_,_,_c,_d=coefficients(10)
# Dyadic speeds from original12px/step limit; include every gain whose
# exact closed-loop velocity multiplier remains nonnegative.
SPEED_MODES=tuple(12./2**k for k in range(16) if GAMMA/(12./2**k)<=_c/_d)

def constraints_for_mode(velocity,normals,limits,speed,toward_upper=None,velocity_face_upper=None):
    v=np.asarray(velocity,float);n=np.asarray(normals,float).reshape(-1,2);limits=np.asarray(limits,float)
    if v.shape!=(2,) or not np.isfinite(v).all() or np.linalg.norm(v)>12.+1e-8:return None,None
    if limits.shape!=(len(n),) or not np.isfinite(n).all() or not np.isfinite(limits).all():raise ValueError('Invalid shared-backup corridor')
    lengths=np.linalg.norm(n,axis=1)
    if np.any(abs(lengths-1)>1e-8):raise ValueError('Shared-backup normals must be unit length')
    toward=n@v if toward_upper is None else np.asarray(toward_upper,float)
    face_v=COMMAND_NORMALS@v if velocity_face_upper is None else np.asarray(velocity_face_upper,float)
    if toward.shape!=(len(n),) or face_v.shape!=(FACES,) or not np.isfinite(toward).all() or not np.isfinite(face_v).all():raise ValueError('Invalid shared-backup velocity support')
    a,b,c,d=coefficients(10);gain=GAMMA/float(speed)
    if gain>c/d+1e-12 or gain<=0:raise ValueError('Backup feedback not monotone')
    L=(a-b*gain)/(1-c+d*gain)
    A=list(COMMAND_NORMALS);rhs=[GAMMA]*FACES
    if len(n):
        cv,cu=SUB_A,SUB_B
        zero=cu==0
        if np.any(limits[:,None]-toward[:,None]*cv[zero]<-1e-8):return None,None
        sub=(limits[:,None]-toward[:,None]*cv[~zero])/cu[~zero]
        terminal=(limits-(a+L*c)*toward)/(b+L*d)
        bound=np.minimum(sub.min(axis=1),terminal)
        keep=bound<1.
        A.extend(n[keep]);rhs.extend(bound[keep].tolist())
    # This is the actual common backup input condition, not independent
    # maximum braking authority for each wall normal.
    velocity_bounds=(GAMMA/gain-c*face_v)/d
    keep=velocity_bounds<1.
    A.extend(COMMAND_NORMALS[keep]);rhs.extend(velocity_bounds[keep].tolist())
    return np.asarray(A),np.asarray(rhs)

def union_projection(preferred,velocity,normals,limits,toward_upper=None,velocity_face_upper=None):
    preferred=np.asarray(preferred,float)
    common=project_polygon(preferred,COMMAND_NORMALS,np.full(FACES,GAMMA),initial_polygon=COMMAND_VERTICES)
    assert common is not None
    constraints=[constraints_for_mode(velocity,normals,limits,s,toward_upper,velocity_face_upper) for s in SPEED_MODES]
    # Public lower bound: every terminal-mode polytope is a subset of the same
    # command16gon. If its common optimum is feasible in any mode it is global.
    for speed,(A,b) in zip(SPEED_MODES,constraints):
        if A is not None and np.max(A@common['command']-b)<=1e-8:
            return dict(common,speed_mode=speed,union_modes_solved=0,union_lower_bound_attained=True)
    best=None;solved=0
    for speed,(A,b) in zip(SPEED_MODES,constraints):
        if A is None:continue
        q=project_polygon(preferred,A,b,initial_polygon=COMMAND_VERTICES);solved+=1
        if q is not None and (best is None or q['objective']<best['objective']-1e-12):
            best=dict(q,speed_mode=speed)
    if best is not None:best.update(union_modes_solved=solved,union_lower_bound_attained=False)
    return best

def local_command(delta,velocity,normals,limits,faces=16,velocity_weight=1.,effort_weight=.01,toward_upper=None,velocity_face_upper=None):
    if faces!=FACES:raise ValueError('This finite reference fixes16 command faces')
    delta=np.asarray(delta,float);velocity=np.asarray(velocity,float)
    if delta.shape!=(2,) or velocity.shape!=(2,) or not np.isfinite(delta).all() or not np.isfinite(velocity).all():raise ValueError('Invalid union-QP state')
    a,b,c,d=coefficients(10)
    preferred=(b*delta-(b*a+velocity_weight*d*c)*velocity)/(b*b+velocity_weight*d*d+effort_weight)
    return union_projection(preferred,velocity,normals,limits,toward_upper,velocity_face_upper)

def safe_legacy_command(desired,velocity,normals,limits,faces=16,toward_upper=None,velocity_face_upper=None):
    desired=np.asarray(desired,float)
    if np.linalg.norm(desired)<=1.+1e-10:
        for speed in SPEED_MODES:
            A,b=constraints_for_mode(velocity,normals,limits,speed,toward_upper,velocity_face_upper)
            if A is not None and (len(A)==FACES or np.max(A[FACES:]@desired-b[FACES:])<=1e-8):
                return dict(command=desired.copy(),stationarity=0.,primal_violation=0.,mode='SAFE_ORIGINAL_COMMAND',speed_mode=speed)
    q=union_projection(desired,velocity,normals,limits,toward_upper,velocity_face_upper)
    if q is not None:q['mode']='SAFETY_QP'
    return q
