"""Extend the previously checked F42 DP to callable metrics and fixed prefixes.

The selected sites stay fixed. This solves equal-speed known-graph *placement*
makespan, not physical execution or return-to-rally time.
"""
from itertools import combinations
import math

def minimum_makespan(selected,owners,inventories,start_costs,between,budgets,prefix_costs=None):
    selected=tuple(sorted(selected));owners=list(owners);prefix_costs=prefix_costs or {}
    if len(selected)>10 or len(selected)!=len(set(selected)):raise ValueError('At most10 distinct selected sites')
    if any(inventories[i] not in (0,1,2) or math.isnan(budgets[i]) or budgets[i]<0 for i in owners):raise ValueError('Invalid capacity/budget')
    if any(not math.isfinite(float(prefix_costs.get(i,0.))) or prefix_costs.get(i,0.)<0 for i in owners):raise ValueError('Uncertified prefix cost')
    raw=between if callable(between) else lambda j,k:float(between[j][k]);cache={}
    def metric(j,k):
        if (j,k) not in cache:
            value=float(raw(j,k))
            if math.isnan(value) or value<0:raise ValueError('Invalid graph metric')
            cache[j,k]=value
        return cache[j,k]
    full=(1<<len(selected))-1;states={0:(0.,{},{})};transitions=0
    for owner in owners:
        options=[(0,[],0.)]
        eligible=[p for p,j in enumerate(selected) if math.isfinite(float(start_costs[owner][j])) and 0<=float(start_costs[owner][j])<=budgets[owner]+1e-8]
        if inventories[owner]>0:options.extend((1<<p,[selected[p]],float(start_costs[owner][selected[p]])) for p in eligible)
        if inventories[owner]>1:
            for p,q in combinations(eligible,2):
                j,k=selected[p],selected[q];forward=float(start_costs[owner][j])+metric(j,k);reverse=float(start_costs[owner][k])+metric(k,j)
                cost=min(forward,reverse)
                if cost<=budgets[owner]+1e-8:options.append(((1<<p)|(1<<q),[j,k] if forward<=reverse else [k,j],cost))
        new={}
        for mask,(value,assignment,costs) in states.items():
            for used,route,cost in options:
                if mask&used:continue
                transitions+=1;combined=mask|used;proposal=max(value,float(prefix_costs.get(owner,0.))+cost)
                if combined not in new or proposal<new[combined][0]:
                    new[combined]=(proposal,dict(assignment,**{str(owner):route}),dict(costs,**{str(owner):cost}))
        states=new
    found=states.get(full)
    audit=dict(states=len(states),transitions=transitions,pair_queries=len(cache),
        queried_pair_costs=[dict(first=j,second=k,cost=v if math.isfinite(v) else None,finite=math.isfinite(v)) for (j,k),v in sorted(cache.items())])
    if found is None:return None,None,None,audit
    value,plan,costs=found
    return {i:plan[str(i)] for i in owners},costs,value,audit
