"""Keep executing good coverage targets despite small inter-drone map offsets."""
import numpy as np
from swarm_rescue.solutions.team_coverage_lns import plan_team_coverage_lns as plan_team_coverage


class FleetEndpointRepairMixin:
    def _other_live_placement_goals(self,step):
        """Read only this drone's received reports; never inspect peer objects."""
        own=int(self.identifier or 0)
        goals=[]
        for peer,(ts,inventory,goal,since) in self.assignment_reports.items():
            if (peer==own or inventory<=0 or goal is None or
                    not 0<=step-ts<self.STATE_FRESH_STEPS or
                    not 0<=step-since<self.GOAL_LEASE_STEPS): continue
            state=self.fleet_states.get(peer)
            if (state is not None and 0<=step-state[0]<self.STATE_FRESH_STEPS
                    and state[0]>=ts and state[2]!=inventory): continue
            goals.append(np.asarray(goal,float))
        plan=self.fleet_plan
        if plan is not None and 0<=step-plan[0]<self.PLAN_FRESH_STEPS:
            for peer,(initial,points) in plan[2].items():
                if peer==own: continue
                current=initial
                state=self.fleet_states.get(peer)
                if state is not None and 0<=step-state[0]<self.STATE_FRESH_STEPS:
                    current=state[2]
                report=self.assignment_reports.get(peer)
                if report is not None:
                    ts,inventory,goal,since=report
                    if 0<=step-ts<self.STATE_FRESH_STEPS:
                        if state is None or ts>=state[0]:current=inventory
                        if goal is None and since>=0 and ts>plan[0]:continue
                if current>0:
                    goals.extend(np.asarray(p,float) for p in points[max(0,initial-current):])
        return goals

    def _reject_assignment(self,step,point):
        peer_goals=self._other_live_placement_goals(step)
        separation=40.0+.71*float(self.memory.CELL)
        route,actual=self.memory.route(self.pose,destination=point)
        actual=None if actual is None else np.asarray(actual,float)
        if (actual is not None and 1<=np.linalg.norm(actual-point)<=40 and
                not self._point_conflicts_with_drop(actual) and
                all(np.linalg.norm(actual-goal)+1e-8>=separation for goal in peer_goals)):
            target=actual
        else:
            super()._reject_assignment(step,point)
            reserved=list(self.drop_records.values())+peer_goals
            own=int(self.identifier or 0)
            forbidden=list(getattr(self,'_placement_forbidden',lambda:[])())+[(np.asarray(point,float),48)]
            plans=plan_team_coverage(self.memory,{own:(self.pose,int(self.carried_bombs_count()))},
                                     reserved,self.blast_radius,travel_budget=max(0.,self._remaining_steps()*3.0),
                                     quality_tolerance=.98,forbidden_points=forbidden,
                                     forbidden_mask=getattr(self,'_placement_forbidden_mask',lambda:None)())
            if not plans.get(own): return
            target=np.asarray(plans[own][0],float)
            route,actual=self.memory.route(self.pose,destination=target)
            if actual is None or np.linalg.norm(actual-target)>1: return
        self.assignment_goal=target.copy()
        self.assignment_inventory=int(self.carried_bombs_count())
        self.assignment_since=step
        self.assignment_reports[int(self.identifier or 0)]=self._own_assignment_report(step)
        self._endpoint_repair_route=(route or [target.copy()],target.copy())

    def _plan_route(self,step,returning,peer_goals):
        self._endpoint_repair_route=None
        result=super()._plan_route(step,returning,peer_goals)
        if self._endpoint_repair_route is not None:
            route,target=self._endpoint_repair_route
            self.placement_goal=target.copy()
            return route,target
        return result
