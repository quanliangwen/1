"""One-site epsilon-constrained coverage improvement of a feasible incumbent.
Only per-call public sensor geometry and received fleet state are used.
Target count, owners and visit order stay fixed; shortest-route lengths cannot
increase beyond explicit epsilon. No global running state or truth access.
"""
from __future__ import annotations
import math
import cv2
import numpy as np
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
from swarm_rescue.solutions.team_coverage import observed_wall_values,path_costs
from swarm_rescue.solutions.farthest_wall_cover import owner_travel_budget

TRUST_RADIUS_RATIO = 1.25
ROUTE_EPSILON = 32.0
MIN_GAIN_RATIO = 0.003
MAX_OPTIONS = 128


def _repeat_hit_support(memory):
    repeated=(np.asarray(memory.hits)>=2).astype(np.float32)
    smooth=cv2.GaussianBlur(repeated,(0,0),sigmaX=1.2)
    density=cv2.resize(smooth,(int(memory.shape[1]),int(memory.shape[0])),interpolation=cv2.INTER_AREA)
    confidence=0.35*np.clip(density/0.08,0.0,1.0)
    rr,cc=np.indices(memory.shape)
    xx=(cc+0.5)*memory.CELL-memory.width/2
    yy=memory.height/2-(rr+0.5)*memory.CELL
    frame=(np.abs(xx)>memory.width/2-memory.CELL)|(np.abs(yy)>memory.height/2-memory.CELL)
    confidence[frame]*=0.5
    return confidence.astype(np.float32)


def _coverage_mask(pm, points, radius):
    rr,cc=np.indices(pm.shape)
    xx=(cc+0.5)*pm.CELL-pm.width/2
    yy=pm.height/2-(rr+0.5)*pm.CELL
    covered=np.zeros(pm.shape,bool)
    for point in points:
        covered |= (xx-point[0])**2+(yy-point[1])**2 <= radius**2+1e-8
    return covered


def refine_trust_region(memory, agents, drops, radius, base, travel_budget=None,
                        forbidden_points=(), forbidden_mask=None,
                        route_epsilon=ROUTE_EPSILON,
                        trust_radius_ratio=TRUST_RADIUS_RATIO,_prepared=None):
    previous=getattr(memory,'trust_region_diagnostics',{})
    diag={'calls':previous.get('calls',0)+1,'utility_candidates':0,'evaluated_candidates':0,
          'fields_computed':0,'accepted':0,'accepted_total':previous.get('accepted_total',0)}
    memory.trust_region_diagnostics=diag
    original={int(k):[np.asarray(p,float).copy() for p in ps] for k,ps in base.items()}
    if not any(original.values()): return original
    pm=GeometryPlanningMemory(memory) if _prepared is None else _prepared
    values,solids=observed_wall_values(pm,radius,return_solids=True)
    confirmed_values=np.asarray(values,np.float32).copy()
    values=np.maximum(confirmed_values,_repeat_hit_support(pm))
    walkable=pm.free & ~pm.blocked() & ~solids
    allowed=walkable.copy()
    rr,cc=np.indices(pm.shape)
    xx=(cc+0.5)*pm.CELL-pm.width/2
    yy=pm.height/2-(rr+0.5)*pm.CELL
    if forbidden_mask is not None:
        mask=np.asarray(forbidden_mask,bool)
        if mask.shape!=pm.shape: return original
        allowed &= ~mask
    for p,r in forbidden_points:
        allowed[(xx-p[0])**2+(yy-p[1])**2 < float(r)**2] = False
    separation=40.0+0.71*pm.CELL
    for point in drops:
        squared=(xx-point[0])**2+(yy-point[1])**2
        values[squared<=radius**2+1e-8]=0
        confirmed_values[squared<=radius**2+1e-8]=0
        allowed[squared<separation**2]=False
    clean={int(k):(np.asarray(p,float),int(n)) for k,(p,n) in agents.items()
           if p is not None and np.asarray(p).shape==(2,) and np.isfinite(p).all() and int(n)>0}
    fields={}
    def field(cell):
        cell=tuple(int(v) for v in cell)
        if cell not in fields:
            fields[cell]=path_costs(pm,walkable,cell)
            diag['fields_computed']+=1
        return fields[cell]
    def distance(a,b): return float(field(pm.world_to_cell(a))[pm.world_to_cell(b)])
    def route_length(k,items):
        previous=clean[k][0];length=0.0
        for point in items:
            length+=distance(previous,point);previous=point
        return length
    route_before={}
    for k,items in original.items():
        if not items: continue
        if k not in clean or len(items)>clean[k][1]: return original
        # Path validation is deferred until useful geometry exists.
    all_points=[p for ps in original.values() for p in ps]
    incumbent_score=float(values[_coverage_mask(pm,all_points,radius)].sum())
    incumbent_confirmed=float(confirmed_values[_coverage_mask(pm,all_points,radius)].sum())
    threshold=max(0.1,MIN_GAIN_RATIO*incumbent_score)
    rc=int(math.ceil(radius/pm.CELL));ky,kx=np.mgrid[-rc:rc+1,-rc:rc+1]
    disk=((kx*pm.CELL)**2+(ky*pm.CELL)**2<=radius**2+1e-8).astype(np.float32)
    def _try_joint_pair():
        slots=[(k,j,p) for k in sorted(original) for j,p in enumerate(original[k])]
        diag['joint_pairs_evaluated']=0
        diag['joint_owner_pairs']=0
        diag['joint_accepted_total']=previous.get('joint_accepted_total',0)
        if (len(slots)<2 or len(slots)>10 or len(clean)>5 or
                len({k for k,j,p in slots})<2):
            return original
        if not (np.isfinite(values).all() and np.isfinite(confirmed_values).all()):
            return original
        for k,items in original.items():
            if not items:
                continue
            if k not in clean or len(items)>clean[k][1]:
                return original
            length=route_length(k,items)
            if (not math.isfinite(length) or
                    (travel_budget is not None and length>owner_travel_budget(travel_budget,k)+1e-6)):
                return original
            route_before[k]=length

        def point_valid(point,old,fixed):
            if np.asarray(point).shape!=(2,) or not np.isfinite(point).all():
                return False
            cell=tuple(int(v) for v in pm.world_to_cell(point))
            r,c=cell
            if not (0<=r<pm.shape[0] and 0<=c<pm.shape[1] and allowed[cell]):
                return False
            if float(np.sum((point-old)**2))>trust**2+1e-8:
                return False
            if any(float(np.sum((point-p)**2))<separation**2-1e-8 for p in fixed):
                return False
            if any(float(np.sum((point-p)**2))<float(rad)**2 for p,rad in forbidden_points):
                return False
            return True

        best=None
        best_rank=None
        for left in range(len(slots)):
            k,i,old_a=slots[left]
            for right in range(left+1,len(slots)):
                h,j,old_b=slots[right]
                if k==h:
                    continue
                diag['joint_owner_pairs']+=1
                fixed=[p for n,(owner,slot,p) in enumerate(slots) if n not in (left,right)]
                fixed_mask=_coverage_mask(pm,fixed,radius)
                residual=values.copy();residual[fixed_mask]=0
                gains=cv2.filter2D(residual,-1,disk,borderType=cv2.BORDER_CONSTANT)

                def pool(owner,slot,old):
                    prev=clean[owner][0] if slot==0 else original[owner][slot-1]
                    nxt=original[owner][slot+1] if slot+1<len(original[owner]) else None
                    edge=distance(prev,old)+(distance(old,nxt) if nxt is not None else 0.0)
                    lengths=route_before[owner]-edge+field(pm.world_to_cell(prev))
                    if nxt is not None:
                        lengths=lengths+field(pm.world_to_cell(nxt))
                    cap=route_before[owner]+float(route_epsilon)
                    if travel_budget is not None:
                        cap=min(cap,owner_travel_budget(travel_budget,owner))
                    mask=allowed & ((xx-old[0])**2+(yy-old[1])**2<=trust**2+1e-8)
                    for p in fixed:
                        mask &= (xx-p[0])**2+(yy-p[1])**2>=separation**2-1e-8
                    mask &= np.isfinite(lengths) & (lengths<=cap+1e-6)
                    # The incumbent occupies one of the eight slots, even
                    # if it later fails current geometry validation.
                    result=[(old.copy(),route_before[owner],-1,
                             _coverage_mask(pm,[old],radius),point_valid(old,old,fixed))]
                    ids=np.flatnonzero(mask.ravel())
                    ids=ids[np.argsort(-gains.ravel()[ids],kind='stable')]
                    for flat in ids:
                        cell=tuple(int(v) for v in np.unravel_index(int(flat),pm.shape))
                        point=pm.cell_to_world(cell)
                        if np.array_equal(point,old) or not point_valid(point,old,fixed):
                            continue
                        result.append((point.copy(),float(lengths[cell]),int(flat),
                                       _coverage_mask(pm,[point],radius),True))
                        if len(result)==8:
                            break
                    return result

                a_pool=pool(k,i,old_a);b_pool=pool(h,j,old_b)
                for a,a_length,a_flat,a_mask,a_valid in a_pool:
                    for b,b_length,b_flat,b_mask,b_valid in b_pool:
                        diag['joint_pairs_evaluated']+=1
                        if not (a_valid and b_valid) or a_flat<0 or b_flat<0:
                            continue
                        if float(np.sum((a-b)**2))<separation**2-1e-8:
                            continue
                        covered=fixed_mask | a_mask | b_mask
                        score=float(values[covered].sum())
                        if score<incumbent_score+threshold-1e-5:
                            continue
                        confirmed=float(confirmed_values[covered].sum())
                        if confirmed<incumbent_confirmed-1e-5:
                            continue
                        saving=route_before[k]+route_before[h]-a_length-b_length
                        rank=(score-incumbent_score,saving,-k,-i,-h,-j,-a_flat,-b_flat)
                        if best_rank is None or rank>best_rank:
                            best=(k,i,a.copy(),h,j,b.copy());best_rank=rank
        if best is None:
            return original
        k,i,a,h,j,b=best
        result={owner:[p.copy() for p in items] for owner,items in original.items()}
        result[k][i]=a;result[h][j]=b
        points=[p for items in result.values() for p in items]
        for owner,items in result.items():
            if len(items)!=len(original[owner]):
                return original
            if not items:
                continue
            length=route_length(owner,items)
            if not math.isfinite(length) or length>route_before[owner]+float(route_epsilon)+1e-6:
                return original
            if travel_budget is not None and length>owner_travel_budget(travel_budget,owner)+1e-6:
                return original
            for slot,point in enumerate(items):
                fixed=[p for other,ps in result.items() for n,p in enumerate(ps)
                       if not (other==owner and n==slot)]
                if not point_valid(point,original[owner][slot],fixed):
                    return original
        for n,p in enumerate(points):
            if any(float(np.sum((p-q)**2))<separation**2-1e-8 for q in points[n+1:]):
                return original
            if any(float(np.sum((p-q)**2))<separation**2-1e-8 for q in drops):
                return original
        final_score=float(values[_coverage_mask(pm,points,radius)].sum())
        final_confirmed=float(confirmed_values[_coverage_mask(pm,points,radius)].sum())
        if final_score<incumbent_score+threshold-1e-5 or final_confirmed<incumbent_confirmed-1e-5:
            return original
        diag['accepted']=1;diag['accepted_total']+=1
        diag['joint_accepted_total']+=1
        diag['confirmed_gain']=final_confirmed-incumbent_confirmed
        count=getattr(memory,'_joint_pair_log_count',0)
        if count<8:
            print('[joint-pair-exchange]',{'owners':(k,h),'slots':(i,j),
                  'nominal_gain':final_score-incumbent_score,
                  'confirmed_gain':final_confirmed-incumbent_confirmed,
                  'pairs':diag['joint_pairs_evaluated']},flush=True)
            memory._joint_pair_log_count=count+1
        return result


    winner=None;winner_rank=(threshold,0.0,0,0,0)
    trust=float(radius)*float(trust_radius_ratio)
    for k in sorted(original):
        for slot,old in enumerate(original[k]):
            others=[p for owner,items in original.items() for j,p in enumerate(items) if not(owner==k and j==slot)]
            residual=values.copy();residual[_coverage_mask(pm,others,radius)]=0
            gains=cv2.filter2D(residual,-1,disk,borderType=cv2.BORDER_CONSTANT)
            old_gain=float(residual[_coverage_mask(pm,[old],radius)].sum())
            confirmed_residual=confirmed_values.copy()
            confirmed_residual[_coverage_mask(pm,others,radius)]=0
            confirmed_gains=cv2.filter2D(confirmed_residual,-1,disk,borderType=cv2.BORDER_CONSTANT)
            old_confirmed=float(confirmed_residual[_coverage_mask(pm,[old],radius)].sum())
            mask=allowed & ((xx-old[0])**2+(yy-old[1])**2<=trust**2+1e-8)
            mask &= confirmed_gains>=old_confirmed-1e-5
            for other in others: mask &= (xx-other[0])**2+(yy-other[1])**2>=separation**2-1e-8
            improving=mask & (gains>old_gain+threshold)
            diag['utility_candidates']+=int(np.count_nonzero(improving))
            if not improving.any():continue
            mask=improving
            if k not in route_before:
                length=route_length(k,original[k])
                if not math.isfinite(length) or (travel_budget is not None and length>owner_travel_budget(travel_budget,k)+1e-6):return original
                route_before[k]=length
            prev=clean[k][0] if slot==0 else original[k][slot-1]
            nxt=original[k][slot+1] if slot+1<len(original[k]) else None
            old_edge=distance(prev,old)+(distance(old,nxt) if nxt is not None else 0.0)
            candidate_lengths=route_before[k]-old_edge+field(pm.world_to_cell(prev))
            if nxt is not None: candidate_lengths=candidate_lengths+field(pm.world_to_cell(nxt))
            cap=route_before[k]+float(route_epsilon)
            if travel_budget is not None: cap=min(cap,owner_travel_budget(travel_budget,k))
            mask &= np.isfinite(candidate_lengths) & (candidate_lengths<=cap+1e-6)
            eligible=np.flatnonzero(mask.ravel() & (gains.ravel()>old_gain+threshold))
            if not eligible.size: continue
            order=eligible[np.argsort(-gains.ravel()[eligible],kind='stable')[:MAX_OPTIONS]]
            for flat in order:
                diag['evaluated_candidates']+=1
                cell=tuple(int(v) for v in np.unravel_index(int(flat),pm.shape))
                point=pm.cell_to_world(cell)
                delta=float(gains[cell])-old_gain
                rank=(delta,route_before[k]-float(candidate_lengths[cell]),-k,-slot,-int(flat))
                if rank>winner_rank: winner=(k,slot,point.copy());winner_rank=rank
    if winner is None: return _try_joint_pair()
    # Validate unchanged owners only if an exchange will actually be applied.
    # This preserves the original infeasible-incumbent fallback.
    for key,items in original.items():
        if not items or key in route_before:continue
        length=route_length(key,items)
        if not math.isfinite(length) or (travel_budget is not None and length>owner_travel_budget(travel_budget,key)+1e-6):return original
        route_before[key]=length
    k,slot,point=winner
    result={key:[p.copy() for p in items] for key,items in original.items()}
    result[k][slot]=point
    # Defensive final constraints: preserve slots/owners and validate exact
    # geodesics and utility after cell-to-world conversion.
    if any(len(result[key])!=len(original[key]) for key in original): return original
    if route_length(k,result[k])>route_before[k]+float(route_epsilon)+1e-6: return original
    if route_length(k,result[k])>owner_travel_budget(travel_budget,k)+1e-6: return original
    final_points=[p for ps in result.values() for p in ps]
    final_score=float(values[_coverage_mask(pm,final_points,radius)].sum())
    if final_score<incumbent_score+threshold-1e-5: return original
    final_confirmed=float(confirmed_values[_coverage_mask(pm,final_points,radius)].sum())
    if final_confirmed<incumbent_confirmed-1e-5: return original
    diag['accepted']=1;diag['accepted_total']+=1
    diag['confirmed_gain']=final_confirmed-incumbent_confirmed
    return result
