"""Bounded own-state observability only; all parent decisions run once unchanged."""
import hashlib
import json
import time
import numpy as np


class DiagnosticAuditMixin:
    def __init__(self, **kwargs):
        self._diag = dict(prints=0, last_snapshot=-10000, last_due_reason=None,
                          contexts=[], remaining={}, seconds={}, calls={}, sent=0)
        super().__init__(**kwargs)

    def _diag_emit(self, event, **fields):
        critical = event in ('PRE_SUBMIT', 'SUBMITTED_IMAGE') or (
            event == 'SUBMISSION_GATE' and fields.get('actual_due'))
        if self._diag['prints'] >= 400 and not critical:
            return
        self._diag['prints'] += 1
        out = dict(event=event, owner=int(self.identifier or 0),
                   step=int(self.elapsed_timestep), wall=float(self.elapsed_walltime), **fields)
        print('[STATE_AUDIT] '+json.dumps(out, allow_nan=False), flush=True)

    def _diag_time(self, name, elapsed):
        self._diag['seconds'][name] = self._diag['seconds'].get(name, 0.)+elapsed
        self._diag['calls'][name] = self._diag['calls'].get(name, 0)+1

    def _remaining_steps(self):
        result = super()._remaining_steps()
        if self._diag['contexts']:
            self._diag['remaining'][self._diag['contexts'][-1]] = float(result)
        return result

    def _submission_due(self, step):
        self._diag['contexts'].append('due')
        try:
            result = super()._submission_due(step)
        finally:
            self._diag['contexts'].pop()
        remaining = self._diag['remaining'].get('due')
        inventory = int(self.carried_bombs_count())
        certificates = sorted(self.completion_certificates)
        if remaining is not None and remaining <= 0:
            reason = 'FORECAST_BUDGET_EXHAUSTED'
        elif inventory:
            reason = 'WAIT_OWN_INVENTORY'
        elif len(certificates) < self.team_size:
            reason = 'WAIT_COMPLETION_CERTIFICATES'
        elif getattr(self, '_final_sync_waiting', False):
            reason = 'WAIT_FINAL_MAP_EXCHANGE'
        elif result:
            reason = 'ALL_CERTIFICATES_NO_FRESH_BETTER_PEER'
        else:
            reason = 'FRESH_BETTER_PEER'
        self._diag['last_due'] = dict(reason=reason, actual_due=bool(result),
            remaining_steps=remaining, inventory=inventory, certificates=certificates,
            final_sync_reason=getattr(self, '_final_sync_reason', None),
            quality_cache=list(getattr(self, '_quality_cache', ())),
            quality_cache_step=int(getattr(self, '_quality_step', -1)),
            step_seconds=getattr(self, '_step_seconds', None),
            wall_limit=float(self.walltime_limit), step_limit=int(self.limit))
        if result or reason != self._diag['last_due_reason']:
            self._diag_emit('SUBMISSION_GATE', **self._diag['last_due'])
        self._diag['last_due_reason'] = reason
        return result

    def _acquisition_needed(self, model, step):
        self._diag['contexts'].append('acquisition')
        try:
            result = super()._acquisition_needed(model, step)
        finally:
            self._diag['contexts'].pop()
        stamp = (int(getattr(self, '_coverage_model_step', step)), bool(result))
        if self._diag.get('last_acquisition') != stamp:
            self._diag_emit('ACQUISITION', actual_continue=bool(result),
                remaining_steps=self._diag['remaining'].get('acquisition'),
                model={k:float(v) for k,v in model.items() if isinstance(v,(int,float,np.number))},
                terminal={k:(float(v) if np.isfinite(v) else None)
                          for k,v in self.terminal_value_diagnostics.items()
                          if isinstance(v,(int,float,np.number))})
            self._diag['last_acquisition'] = stamp
        return result

    def _messages(self):
        old=getattr(self,'fleet_plan',None)
        started = time.perf_counter()
        result = super()._messages()
        self._diag_time('messages', time.perf_counter()-started)
        plan=getattr(self,'fleet_plan',None)
        if plan is not None and (old is None or plan[:2]!=old[:2]):
            self._diag_emit('PLAN_RECEIVED',plan_epoch=int(plan[0]),leader=int(plan[1]),
                assignments={str(peer):dict(inventory=int(inv),goals=[np.asarray(p,float).tolist() for p in goals])
                    for peer,(inv,goals) in plan[2].items()})
        return result

    def _plan_route(self, step, returning, peer_goals):
        before=self._diag_assignment_state()
        started = time.perf_counter()
        result = super()._plan_route(step, returning, peer_goals)
        self._diag_time('plan_route', time.perf_counter()-started)
        after=self._diag_assignment_state()
        if before!=after:
            self._diag_emit('ASSIGNMENT_TRANSITION',before=before,after=after)
        return result

    def _diag_assignment_state(self):
        point=lambda p:None if p is None else np.asarray(p,float).tolist()
        plan=getattr(self,'fleet_plan',None)
        return dict(goal=point(getattr(self,'assignment_goal',None)),
            placement_goal=point(getattr(self,'placement_goal',None)),
            inventory=getattr(self,'assignment_inventory',None),
            since=int(getattr(self,'assignment_since',-1)),
            plan_epoch=None if plan is None else int(plan[0]),
            plan_leader=None if plan is None else int(plan[1]))

    def _build_fleet_plan(self,step):
        old=getattr(self,'fleet_plan',None)
        result=super()._build_fleet_plan(step)
        plan=getattr(self,'fleet_plan',None)
        if plan is not None and (old is None or plan[0]!=old[0] or plan[1]!=old[1]):
            self._diag_emit('PLAN_ISSUED',plan_epoch=int(plan[0]),leader=int(plan[1]),
                assignments={str(peer):dict(inventory=int(inv),goals=[np.asarray(p,float).tolist() for p in goals])
                    for peer,(inv,goals) in plan[2].items()},
                state_ages={str(p):int(step-ts) for p,(ts,pos,n) in self.fleet_states.items() if pos is not None},
                reports={str(peer):dict(stamp=int(r[0]),inventory=int(r[1]),
                    goal=None if r[2] is None else np.asarray(r[2],float).tolist(),since=int(r[3]))
                    for peer,r in self.assignment_reports.items()})
        return result

    def _reject_assignment(self,step,point):
        self._diag_emit('ASSIGNMENT_REJECTED',target=np.asarray(point,float).tolist())
        return super()._reject_assignment(step,point)

    def _watch_assignment_progress(self,step,inventory,target):
        result=super()._watch_assignment_progress(step,inventory,target)
        if result:
            self._diag_emit('ASSIGNMENT_STALLED',inventory=int(inventory),
                target=None if target is None else np.asarray(target,float).tolist())
        return result

    def define_message_for_all(self):
        message = super().define_message_for_all()
        self._diag['sent'] += 1
        self._diag['last_sent'] = dict(step=int(message.get('step', -1)),
            has_map='map' in message, certificates=sorted(message.get('completion_certificates', {})),
            cached_packet_step=int(getattr(self, 'last_packet_step', -1)))
        return message

    def _diag_snapshot(self, event):
        step = int(self.elapsed_timestep)
        memory = self.memory
        self._diag_emit(event, inventory=int(self.carried_bombs_count()),
            free_cells=int(np.count_nonzero(memory.free)), total_cells=int(memory.free.size),
            hit_bins_ge3=int(np.count_nonzero(memory.hits >= 3)),
            sensor_frames=int(getattr(memory, 'bearing_source_frames', 0)),
            merged_packets=int(getattr(memory, 'bearing_merged_packets', 0)),
            peer_map_ages={str(p):step-int(s) for p,s in self.last_peer_step.items()},
            peer_qualities={str(p):[int(r[0]),float(r[1]),int(r[2])]
                            for p,r in self.map_quality_records.items()},
            certificates={str(p):int(s) for p,s in self.completion_certificates.items()},
            sent=self._diag['sent'], last_sent=self._diag.get('last_sent'),
            semantic_navigation=dict(mask_cells=int(np.count_nonzero(getattr(memory,"semantic_navigation_blocked",[]))),
                route_counts=dict(getattr(memory,"semantic_navigation_counts",{})),
                motor_calls=int(getattr(self,"_semantic_navigation_motor_calls",0))),
            coverage_ready=bool(getattr(self, 'coverage_ready', False)),
            seeking_fusion=bool(getattr(self, '_seeking_fusion', False)),
            sortie_state=getattr(self, '_sortie_state', None),
            frame_sources=sorted({int(k[0]) for k in getattr(self, 'frame_records', {})}),
            frame_records=len(getattr(self, 'frame_records', {})),
            seconds=self._diag['seconds'].copy(), calls=self._diag['calls'].copy(),
            last_due=self._diag.get('last_due'))

    def submit_exploration_map(self, image, *args, **kwargs):
        # Observe the exact image supplied to the SDK; no extra render or map change.
        a = np.asarray(image)
        self._diag_snapshot('PRE_SUBMIT')
        self._diag_emit('SUBMITTED_IMAGE', shape=list(a.shape), dtype=str(a.dtype),
            sha256=hashlib.sha256(a.tobytes()).hexdigest(), nonzero=int(np.count_nonzero(a)),
            render_frame_diagnostic_keys=sorted(getattr(self.memory, 'frame_diagnostics', {})),
            last_due=self._diag.get('last_due'))
        return super().submit_exploration_map(image, *args, **kwargs)

    def control(self):
        result = super().control()
        step = int(self.elapsed_timestep)
        if step-self._diag['last_snapshot'] >= 120:
            self._diag['last_snapshot'] = step
            self._diag_snapshot('PERIODIC')
        return result
