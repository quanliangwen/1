"""Own received semantic surface geometry, separate from scored wall layers."""
import cv2
import numpy as np

def semantic_navigation_mask(memory, points, clearance=22.):
    points=np.asarray(points,float).reshape((-1,2))
    if not np.isfinite(points).all():raise ValueError('Nonfinite semantic surface')
    raw=np.zeros(memory.hit_shape,np.uint8)
    if not len(points):return np.zeros(memory.shape,bool)
    fine=np.column_stack(((points[:,0]+memory.width/2)/memory.FINE,
                          (memory.height/2-points[:,1])/memory.FINE))
    hull=cv2.convexHull(np.rint(fine).astype(np.int32))
    cv2.fillConvexPoly(raw,hull,1)
    if not raw.any():return np.zeros(memory.shape,bool)
    distances=cv2.distanceTransform(1-raw,cv2.DIST_L2,5)*memory.FINE
    rows=np.minimum(((np.arange(memory.shape[0])+.5)*memory.CELL/memory.FINE).astype(int),memory.hit_shape[0]-1)
    cols=np.minimum(((np.arange(memory.shape[1])+.5)*memory.CELL/memory.FINE).astype(int),memory.hit_shape[1]-1)
    return distances[np.ix_(rows,cols)]<float(clearance)

def _emit(memory,event,**fields):
    import json
    counts=getattr(memory,'semantic_navigation_counts',{})
    count=counts.get(event,0);counts[event]=count+1;memory.semantic_navigation_counts=counts
    if count<12:
        print('[SEMANTIC_NAV] '+json.dumps(dict(event=event,owner=int(memory.identifier),step=int(memory.step),**fields)),flush=True)

def refresh_semantic_navigation(drone,points,step):
    memory=drone.memory
    mask=semantic_navigation_mask(memory,points)
    old=getattr(memory,'semantic_navigation_blocked',None)
    changed=old is None or not np.array_equal(old,mask)
    memory.semantic_navigation_blocked=mask
    if not changed:return
    if hasattr(memory,'geometry_cache'):memory.geometry_cache.invalidate()
    walkable=~mask.copy();start=memory.world_to_cell(drone.pose);walkable[start]=True
    cells=[start]+[memory.world_to_cell(p) for p in getattr(drone,'waypoints',[])]
    invalid=any(not memory._visible(a,b,walkable) for a,b in zip(cells[:-1],cells[1:]))
    if invalid:
        drone.waypoints=[];drone.last_plan_step=-1000
    _emit(memory,'SURFACE_LAYER_UPDATED',surface_points=len(points),mask_cells=int(mask.sum()),
          prior_route_invalidated=bool(invalid),wall_hits_unchanged=True)

def audit_semantic_route(memory,position,destination,route,actual):
    mask=getattr(memory,'semantic_navigation_blocked',None)
    if mask is None or not mask.any():return
    start=memory.world_to_cell(position);wanted=memory.world_to_cell(destination)
    walkable=~mask.copy();walkable[start]=True
    if memory._visible(start,wanted,walkable):return
    cells=[start]+[memory.world_to_cell(p) for p in route]
    valid=all(memory._visible(a,b,walkable) for a,b in zip(cells[:-1],cells[1:]))
    exact=actual is not None and np.linalg.norm(np.asarray(actual)-destination)<1.
    _emit(memory,'DETOUR_EXACT' if exact and valid else 'TARGET_BLOCKED_OR_PARTIAL',
          target=np.asarray(destination,float).tolist(),waypoints=[np.asarray(p,float).tolist() for p in route],
          exact_endpoint=bool(exact),semantic_segments_clear=bool(valid),
          scope='Own received semantic layer, finite grid; not actual physical collision proof')

def audit_semantic_motor(drone,distances,angles,semantic,bomb_mask):
    from swarm_rescue.solutions.greedy_mapping import MapMemory
    if not any(getattr(getattr(o,'entity_type',None),'name','')=='DISPOSAL_CENTER' for o in semantic or ()):return
    mask=MapMemory.semantic_mask(distances,angles,semantic,('DISPOSAL_CENTER',)) & ~bomb_mask
    if not mask.any():return
    count=getattr(drone,'_semantic_navigation_motor_calls',0)
    drone._semantic_navigation_motor_calls=count+1
    if count<8:
        import json
        print('[SEMANTIC_NAV] '+json.dumps(dict(event='DC_RAYS_RETAINED',owner=int(drone.identifier),
            step=int(drone.elapsed_timestep),rays=int(mask.sum()),min_range=float(np.min(np.asarray(distances)[mask])))),flush=True)
