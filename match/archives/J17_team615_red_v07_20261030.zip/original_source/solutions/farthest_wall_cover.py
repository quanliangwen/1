"""Deterministic farthest-residual observed-wall disk layout.

All arrays are public sensor-derived planning rasters supplied by the caller.
This module never reads a map class, game result, or peer-private state.
"""
import math

import cv2
import numpy as np


def owner_travel_budget(budget, owner):
    """Owner-specific nominal length; missing mapping entries get no suffix."""
    if budget is None:
        return math.inf
    if isinstance(budget,dict):
        return float(budget.get(int(owner),0.0))
    return float(budget)


def farthest_layout(values, allowed, xx, yy, radius, cell_size, owners,
                    counts, start_fields, field_at, budget, separation):
    """Return owner-indexed cell paths under the declared finite rule."""
    budgets=[owner_travel_budget(budget,k) for k in owners]
    values = np.asarray(values, dtype=np.float64)
    allowed = np.asarray(allowed, dtype=bool).copy()
    xx, yy = np.asarray(xx, float), np.asarray(yy, float)
    if (values.ndim != 2 or allowed.shape != values.shape
            or xx.shape != values.shape or yy.shape != values.shape
            or not np.isfinite(values).all() or np.any(values < 0)
            or not np.isfinite(xx).all() or not np.isfinite(yy).all()
            or not math.isfinite(radius) or radius <= 0
            or not math.isfinite(cell_size) or cell_size <= 0
            or not math.isfinite(separation) or separation < 0
            or any(math.isnan(b) or b<0 for b in budgets)
            or len(owners) != len(counts) or len(owners) != len(start_fields)
            or any(int(n) != n or n < 0 for n in counts)):
        raise ValueError("invalid public layout context")
    fields = [np.asarray(f, float).copy() for f in start_fields]
    if any(f.shape != values.shape or np.isnan(f).any() for f in fields):
        raise ValueError("invalid geodesic fields")
    rc = int(math.ceil(radius / cell_size))
    gy, gx = np.mgrid[-rc:rc + 1, -rc:rc + 1]
    disk = ((gx * cell_size) ** 2 + (gy * cell_size) ** 2
            <= radius ** 2 + 1e-8).astype(np.float64)
    residual = values.copy()
    claimed = np.zeros(values.shape, dtype=bool)
    paths = {int(owner): [] for owner in owners}
    spent = [0.0] * len(owners)
    work = dict(anchors_examined=0, candidates_evaluated=0,
                inaccessible_anchors=0, selected=0)
    slots = sum(int(n) for n in counts)
    for _ in range(slots):
        owner_masks = [allowed & np.isfinite(f)
                       & (spent[i] + f <= budgets[i] + 1e-8)
                       if len(paths[int(owners[i])]) < counts[i]
                       else np.zeros(values.shape, bool)
                       for i, f in enumerate(fields)]
        eligible = np.logical_or.reduce(owner_masks) if owner_masks else np.zeros(values.shape, bool)
        if not np.any(eligible):
            break
        coverable = cv2.filter2D(eligible.astype(np.float64), -1, disk,
                                 borderType=cv2.BORDER_CONSTANT) > 0
        possible = (residual > 0) & coverable
        if not np.any(possible):
            break
        if np.any(claimed):
            distance = cv2.distanceTransform((~claimed).astype(np.uint8),
                                             cv2.DIST_L2, 5)
            primary = distance
        else:
            primary = residual
        ranked = np.flatnonzero(possible.ravel())
        anchor_flat = max(ranked, key=lambda j:
                          (float(primary.ravel()[j]),
                           float(residual.ravel()[j]), -int(j)))
        ar, ac = np.unravel_index(anchor_flat, values.shape)
        work["anchors_examined"] += 1
        candidate_anchor = ((xx - xx[ar, ac]) ** 2
                            + (yy - yy[ar, ac]) ** 2 <= radius ** 2 + 1e-8)
        gain = cv2.filter2D(residual, -1, disk,
                            borderType=cv2.BORDER_CONSTANT)
        best = None
        for i, owner in enumerate(owners):
            candidate = owner_masks[i] & candidate_anchor
            indexes = np.flatnonzero(candidate.ravel())
            work["candidates_evaluated"] += int(indexes.size)
            if not indexes.size:
                continue
            flat = max(indexes, key=lambda j:
                       (float(gain.ravel()[j]),
                        -float(fields[i].ravel()[j]), -int(j)))
            key = (float(gain.ravel()[flat]),
                   -float(fields[i].ravel()[flat]), -int(owner), -int(flat))
            if best is None or key > best[0]:
                best = (key, i, int(flat))
        if best is None or best[0][0] <= 0:
            work["inaccessible_anchors"] += 1
            break
        _, i, flat = best
        cell = tuple(int(v) for v in np.unravel_index(flat, values.shape))
        point = np.array([xx[cell], yy[cell]], float)
        spent[i] += float(fields[i][cell])
        paths[int(owners[i])].append(cell)
        disk_mask = ((xx - point[0]) ** 2 + (yy - point[1]) ** 2
                     <= radius ** 2 + 1e-8)
        residual[disk_mask] = 0
        claimed |= disk_mask
        allowed[(xx - point[0]) ** 2 + (yy - point[1]) ** 2
                < separation ** 2] = False
        next_field = np.asarray(field_at(cell), float)
        if next_field.shape != values.shape or np.isnan(next_field).any():
            raise ValueError("invalid updated geodesic field")
        fields[i] = next_field
        work["selected"] += 1
    return paths, work
