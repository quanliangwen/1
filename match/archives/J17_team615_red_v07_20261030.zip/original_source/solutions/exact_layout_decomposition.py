"""Finite maximum coverage MILP + exact <=10-site route-allocation DP.

The master chooses sites; the subproblem certifies owner/route feasibility.
An infeasible selected set yields a valid monotone no-good cut. Optimality is
for the declared known-graph model, never the unknown complete game.
"""
import math
import time
from itertools import combinations
from swarm_rescue.solutions.reachability_capacity import reachability_capacity_rows
import numpy as np


def allocate_exact(selected, owner_ids, inventories, start_costs, between, budgets):
    selected = tuple(sorted(selected))
    target = (1 << len(selected))-1
    metric = between if callable(between) else lambda j, k: float(between[j, k])
    states = {0: ({}, {})}
    for owner in owner_ids:
        routes = [(0, [], 0.)]
        eligible = [p for p, j in enumerate(selected)
                    if 0 <= float(start_costs[owner][j]) <= budgets[owner]+1e-8
                    and math.isfinite(float(start_costs[owner][j]))]
        if inventories[owner] > 0:
            routes.extend((1 << p, [selected[p]], float(start_costs[owner][selected[p]])) for p in eligible)
        if inventories[owner] > 1:
            for p, q in combinations(eligible, 2):
                j, k = selected[p], selected[q]
                forward = float(start_costs[owner][j])+metric(j, k)
                reverse = float(start_costs[owner][k])+metric(k, j)
                cost = min(forward, reverse)
                if math.isnan(cost) or cost < 0:
                    raise ValueError('Invalid graph metric')
                if cost <= budgets[owner]+1e-8:
                    routes.append(((1 << p) | (1 << q),
                                   [j, k] if forward <= reverse else [k, j], cost))
        next_states = {}
        for mask, (assignments, costs) in states.items():
            for used, route, cost in routes:
                if used & mask:
                    continue
                combined = mask | used
                if combined not in next_states:
                    next_states[combined] = (dict(assignments, **{str(owner): route}),
                                             dict(costs, **{str(owner): cost}))
        states = next_states
    if target not in states:
        return None, None
    assignment, costs = states[target]
    return {i: assignment[str(i)] for i in owner_ids}, costs


def solve_layout(owner_ids, inventories, start_costs, between, points, cover,
                  weights, budgets, separation, time_limit=2.):
    import gurobipy as gp
    started = time.perf_counter()
    points, cover, weights = np.asarray(points, float), np.asarray(cover, bool), np.asarray(weights, float)
    if any(inventories[i] not in (0, 1, 2) or math.isnan(budgets[i]) or budgets[i] < 0 for i in owner_ids):
        raise ValueError('Invalid two-stop inventory/budget')
    if cover.shape != (len(points), len(weights)) or np.any(weights < 0) or not np.isfinite(weights).all():
        raise ValueError('Invalid coverage matrix')
    # Pair metrics shared only inside this solve, including all DP callbacks.
    original_metric = between if callable(between) else lambda j, k: float(between[j, k])
    graph_pairs = {}
    def metric(j, k):
        if (j, k) not in graph_pairs:
            value = float(original_metric(j, k))
            if math.isnan(value) or value < 0:
                raise ValueError('Invalid graph distance')
            graph_pairs[j, k] = value
        return graph_pairs[j, k]
    feasible_sets, cut_keys, errors = {}, set(), []
    def allocation(js):
        key = tuple(sorted(js))
        if key not in feasible_sets:
            feasible_sets[key] = allocate_exact(key, owner_ids, inventories,
                                                start_costs, metric, budgets)
        return feasible_sets[key]
    with gp.Env(empty=True) as env:
        env.setParam('OutputFlag', 0)
        env.start()
        with gp.Model(env=env) as model:
            for key, value in dict(Threads=1, Heuristics=0, MIPGap=0, MIPGapAbs=0,
                                   TimeLimit=float(time_limit), Seed=0, LazyConstraints=1).items():
                model.setParam(key, value)
            u = model.addVars(len(points), vtype=gp.GRB.BINARY)
            y = model.addVars(len(weights), lb=0, ub=1)
            model.addConstr(gp.quicksum(u.values()) <= sum(inventories.values()))
            for j in range(len(points)):
                if not any(inventories[i] and math.isfinite(float(start_costs[i][j]))
                           and 0 <= float(start_costs[i][j]) <= budgets[i]+1e-8 for i in owner_ids):
                    u[j].UB = 0
            capacity_rows,reachability_patterns=reachability_capacity_rows(owner_ids,inventories,start_costs,budgets,len(points))
            for subset,sites,capacity in capacity_rows:
                model.addConstr(gp.quicksum(u[j] for j in sites)<=capacity)
            # Exact spatial hash enumerates every separation conflict.
            buckets, conflicts = {}, 0
            size = max(float(separation), 1e-9)
            for j, point in enumerate(points):
                bucket = tuple(math.floor(float(v)/size) for v in point)
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        for k in buckets.get((bucket[0]+dx, bucket[1]+dy), ()):
                            if np.linalg.norm(point-points[k]) < separation-1e-8:
                                model.addConstr(u[j]+u[k] <= 1)
                                conflicts += 1
                buckets.setdefault(bucket, []).append(j)
            for e in range(len(weights)):
                model.addConstr(y[e] <= gp.quicksum(u[int(j)] for j in np.flatnonzero(cover[:, e])))
            dominance = float(weights.sum())+1.
            model.setObjective(dominance*gp.quicksum(u.values()) +
                gp.quicksum(float(weights[e])*y[e] for e in range(len(weights))), gp.GRB.MAXIMIZE)
            # Empty layout is a certified feasible starting point; no greedy seed.
            for variable in list(u.values())+list(y.values()):
                variable.Start = 0.
            def separate(m, where):
                if where != gp.GRB.Callback.MIPSOL:
                    return
                try:
                    js = tuple(j for j, v in u.items() if m.cbGetSolution(v) > .5)
                    assignment, _ = allocation(js)
                    if assignment is None:
                        if not js:
                            raise RuntimeError('Empty layout incorrectly infeasible')
                        # Under nonnegative shortest-path metric, removing sites
                        # cannot destroy route feasibility. Exclude all supersets.
                        m.cbLazy(gp.quicksum(u[j] for j in js) <= len(js)-1)
                        cut_keys.add(js)
                except Exception as exc:
                    errors.append(repr(exc))
                    m.terminate()
            model.optimize(separate)
            if errors:
                raise RuntimeError('Exact allocation callback failed: '+str(errors))
            audit = dict(status=int(model.Status), solution_count=int(model.SolCount),
                         variables=int(model.NumVars), constraints=int(model.NumConstrs),
                         node_count=float(model.NodeCount), conflicts=conflicts,
                         requested_slots=sum(inventories.values()), heuristic_effort=0,
                         threads=1, lazy_route_cuts=len(cut_keys), allocation_subproblems=len(feasible_sets),
                         graph_pair_queries=len(graph_pairs), solver_version=list(gp.gurobi.version()),
                         bound=float(model.ObjBound) if math.isfinite(model.ObjBound) else None,
                         reachability_capacity_cuts=len(capacity_rows),
                         reachability_pattern_counts={str(int(mask)):int(np.sum(reachability_patterns==mask)) for mask in np.unique(reachability_patterns)},
                         formulation='same_coverage_master_with_Hall_capacity_inequalities_and_exact_route_DP')
            if not model.SolCount:
                return {}, dict(audit, elapsed=time.perf_counter()-started)
            chosen = [j for j in u if u[j].X > .5]
            plan, costs = allocation(chosen)
            if plan is None:
                raise RuntimeError('Uncertified final layout')
            if len(chosen) != sum(map(len, plan.values())):
                raise RuntimeError('Allocation drops selected sites')
            for i, js in plan.items():
                if len(js) > inventories[i] or costs[str(i)] > budgets[i]+1e-8:
                    raise RuntimeError('Final allocation fails capacity/budget')
            coverage = float(weights[np.any(cover[chosen], axis=0)].sum()) if chosen else 0.
            objective = float(model.ObjVal)
            bound = float(model.ObjBound)
            gap = abs(bound-objective)/abs(objective) if objective else 0. if abs(bound) < 1e-9 else None
            audit.update(objective=objective, gap=gap, selected_slots=len(chosen),
                         covered_weight=coverage, route_costs=costs,
                         elapsed=time.perf_counter()-started)
            return plan, audit
