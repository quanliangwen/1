"""Schedule-aware score-unit continuation decisions from public state only.

The official red time contribution is flat only when the *forecast completion*
stays before half of the step limit.  A probe performed before half can still
lose time score by pushing placement and submission beyond that breakpoint.
"""
from __future__ import annotations

import numpy as np


def red_time_contribution(step, limit):
    """Return the exact top-level time contribution in [0, 10] points."""
    limit = max(1.0, float(limit))
    fraction = np.clip((limit - float(step)) / (0.5 * limit), 0.0, 1.0)
    return 10.0 * float(fraction)


def scheduled_delay_time_loss(step, delay, execution, limit):
    """Time-score loss from delaying a forecast completion by ``delay`` steps."""
    finish = float(step) + max(0.0, float(execution))
    delayed_finish = finish + max(0.0, float(delay))
    return max(0.0, red_time_contribution(finish, limit)
               - red_time_contribution(delayed_finish, limit))


def bounded_completion_risk(completion_value, probe, slack):
    """Bound inventory value exposed while a probe consumes execution slack."""
    if slack <= 0:
        return float("inf")
    return max(0.0, float(completion_value)) * min(
        1.0, max(0.0, float(probe)) / float(slack))


def continue_with_schedule(expected_gain, completion_value, step, probe,
                           remaining, execution, limit):
    """Compare public expected gain with schedule-aware score and finish risk."""
    slack = float(remaining) - max(0.0, float(execution))
    if slack <= probe:
        return False
    cost = scheduled_delay_time_loss(step, probe, execution, limit)
    cost += bounded_completion_risk(completion_value, probe, slack)
    return float(expected_gain) > cost


class TerminalValueMixin:
    """Use the forecast finish, instead of current time, for every probe gate."""

    TERMINAL_PROBE_STEPS = 120.0

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._terminal_previous = None
        self._terminal_gain_rate = None
        self.terminal_value_diagnostics = {
            "acquisition_calls": 0,
            "acquisition_continue": 0,
            "commitment_calls": 0,
            "commitment_defer": 0,
            "model_updates": 0,
        }

    def _record_terminal_model(self, model, step):
        stamp = int(getattr(self, "_coverage_model_step", step))
        if self._terminal_previous is not None and self._terminal_previous[0] == stamp:
            return
        total_gap = max(0.0, float(model.get("layout_gap", 0.0))
                        + float(model.get("map_gap", 0.0)))
        previous = self._terminal_previous
        if previous is not None and stamp > previous[0]:
            observed = max(0.0, previous[1] - total_gap) / float(stamp - previous[0])
            if self._terminal_gain_rate is None:
                self._terminal_gain_rate = observed
            else:
                self._terminal_gain_rate = 0.65 * self._terminal_gain_rate + 0.35 * observed
        self._terminal_previous = (stamp, total_gap)
        self.terminal_value_diagnostics["model_updates"] += 1

    def _expected_probe_gain(self, model, probe):
        total_gap = max(0.0, float(model.get("layout_gap", 0.0))
                        + float(model.get("map_gap", 0.0)))
        if self._terminal_gain_rate is None:
            return min(total_gap, 0.10 * total_gap)
        return min(total_gap, max(float(probe) * self._terminal_gain_rate,
                                  0.05 * total_gap))

    def _acquisition_needed(self, model, step):
        self.terminal_value_diagnostics["acquisition_calls"] += 1
        self._record_terminal_model(model, step)
        remaining = float(self._remaining_steps())
        execution = max(0.0, float(model.get("execution_steps", 0.0)))
        probe = min(self.TERMINAL_PROBE_STEPS, max(24.0, remaining - execution))
        initial = max(1, int(getattr(self, "initial_inventory", 1) or 1))
        slots = max(0, int(model.get("slots", 0)))
        completion_value = 40.0 * slots / max(1, int(self.team_size) * initial)
        expected = self._expected_probe_gain(model, probe)
        decision = continue_with_schedule(
            expected, completion_value, step, probe, remaining, execution, self.limit)
        self.terminal_value_diagnostics.update({
            "last_acquisition_expected_gain": expected,
            "last_acquisition_time_loss": scheduled_delay_time_loss(
                step, probe, execution, self.limit),
            "last_acquisition_completion_risk": bounded_completion_risk(
                completion_value, probe, remaining - execution),
            "last_total_gap": max(0.0, float(model.get("layout_gap", 0.0))
                                  + float(model.get("map_gap", 0.0))),
            "last_forecast_finish": float(step) + execution,
        })
        self.terminal_value_diagnostics["acquisition_continue"] += int(decision)
        return bool(decision)

    def _should_defer_commitment(self, loss, remaining, execution, probe,
                                 completion_value, step):
        self.terminal_value_diagnostics["commitment_calls"] += 1
        model = getattr(self, "coverage_model", {}) or {}
        expected = min(float(loss), self._expected_probe_gain(model, probe))
        decision = continue_with_schedule(
            expected, completion_value, step, probe, remaining, execution, self.limit)
        self.terminal_value_diagnostics.update({
            "last_commitment_expected_gain": expected,
            "last_commitment_time_loss": scheduled_delay_time_loss(
                step, probe, execution, self.limit),
            "last_commitment_completion_risk": bounded_completion_risk(
                completion_value, probe, float(remaining) - float(execution)),
            "last_commitment_loss_bound": float(loss),
            "last_forecast_finish": float(step) + float(execution),
        })
        self.terminal_value_diagnostics["commitment_defer"] += int(decision)
        return bool(decision)
