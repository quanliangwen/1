"""One original line fit, multiple independently rendered widths; no cache across calls."""
import math
import numpy as np
import cv2

def regularized_wall_layers(hits, fine=2, line_widths=(8,12), keep_raw=False,
                      fit_band=6, duplicate_distance=2, covariance_limit=12,
                      snap_boundary_lines=False):
    hits = np.asarray(hits)
    support = cv2.GaussianBlur(hits.astype(np.float32), (0, 0), 1.2)
    proposals = cv2.HoughLinesP((support >= .55).astype(np.uint8), 1, math.pi/720,
                               threshold=25, minLineLength=25, maxLineGap=12)
    if keep_raw:
        output = cv2.dilate((support >= .7).astype(np.uint8), np.ones((3, 3), np.uint8))
    else:
        output = np.zeros(hits.shape, np.uint8)
    outputs={int(width):output.copy() for width in line_widths}
    if not outputs: raise ValueError("At least one layer width required")
    if proposals is None:
        return outputs
    rows, cols = np.nonzero(hits >= 2)
    points = np.column_stack((cols, rows)).astype(float)
    weights = np.sqrt(np.minimum(hits[rows, cols].astype(float), 12))
    accepted = []
    for x1, y1, x2, y2 in np.asarray(proposals).reshape(-1, 4):
        start, end = np.array([x1, y1], float), np.array([x2, y2], float)
        tangent = end-start
        length = np.linalg.norm(tangent)
        tangent /= length
        normal = np.array([-tangent[1], tangent[0]])
        # A superset of the oriented fitting rectangle. Preserve the original
        # point order and exact dot products for every possible support point.
        # The extra pixel absorbs floating arithmetic at the coarse bound.
        margin=float(fit_band)+9.
        subset=np.flatnonzero((points[:,0]>=min(x1,x2)-margin) &
            (points[:,0]<=max(x1,x2)+margin) &
            (points[:,1]>=min(y1,y2)-margin) &
            (points[:,1]<=max(y1,y2)+margin))
        delta = points[subset]-start
        along, across = delta @ tangent, delta @ normal
        ids = subset[np.flatnonzero((np.abs(across) < fit_band) & (along > -8) & (along < length+8))]
        if len(ids) < 25:
            continue
        p, w = points[ids], weights[ids]
        center = np.average(p, axis=0, weights=w)
        cov = ((p-center)*w[:, None]).T @ (p-center)/w.sum()
        eigenvalues, eigenvectors = np.linalg.eigh(cov)
        tangent = eigenvectors[:, 1]
        normal = eigenvectors[:, 0]
        if eigenvalues[0] > covariance_limit or eigenvalues[1] < 15*eigenvalues[0]:
            continue
        distance = (p-center) @ tangent
        low, high = np.percentile(distance, [1, 99])
        length = high-low
        if length < 25:
            continue
        first, last = center+tangent*low, center+tangent*high
        # A wall must have evidence in >= 70% of 8 px longitudinal bins.
        bins = np.clip(((distance-low)/4).astype(int), 0, max(1, int(length/4)))
        histogram = np.bincount(bins, minlength=max(2, int(length/4)+1))
        present = histogram > 0
        if present.mean() < .70:
            continue
        if any(abs(normal @ (center-oldcenter)) < duplicate_distance and
               abs(tangent @ oldtangent) > .999 and
               np.linalg.norm(center-oldcenter) < .4*(length+oldlength)
               for oldcenter, oldtangent, oldlength in accepted):
            continue
        accepted.append((center, tangent, length))
        if snap_boundary_lines:
            # A long fitted physical surface parallel and very close to a
            # public arena limit is a boundary hypothesis. Recentering only
            # that observed segment avoids retaining its noisy parallel cloud.
            # No extrapolation beyond first/last measured support is performed.
            margin = 16/fine
            near_horizontal = abs(tangent[1]) < math.sin(math.radians(2))
            near_vertical = abs(tangent[0]) < math.sin(math.radians(2))
            if near_horizontal and max(first[1],last[1]) < margin:
                first[1]=last[1]=3/fine
            elif near_horizontal and min(first[1],last[1]) > hits.shape[0]-margin:
                first[1]=last[1]=hits.shape[0]-3/fine
            elif near_vertical and max(first[0],last[0]) < margin:
                first[0]=last[0]=3/fine
            elif near_vertical and min(first[0],last[0]) > hits.shape[1]-margin:
                first[0]=last[0]=hits.shape[1]-3/fine
        # Bridge at most the Hough 24 px gap, never extrapolate beyond evidence.
        for line_width,output in outputs.items():
            cv2.line(output, tuple(np.round(first).astype(int)), tuple(np.round(last).astype(int)),
                     1, max(1, int(math.ceil(line_width/fine))))
    return outputs

