"""Exact 2D convex-QP projection for a declared local, static corridor.

Optimality is only for this one-step quadratic model and supplied halfplanes.
No claims about noisy sensing, unmodeled collisions or whole-game optimality.
"""
import itertools
import math
import numpy as np

def coefficients(substep):
    damping=.95**.1
    a=.1*sum(damping**k for k in range(substep))
    b=.06*sum(damping**k for k in range(max(0,substep-1)))
    return a,b,damping**substep,.6*damping**(substep-1) if substep else 0.

def braking_envelope(faces=16,max_speed=14.):
    """Exact affine envelope of fixed normal braking in the free-body model."""
    gamma=math.cos(math.pi/faces);a,b,c,d=coefficients(10)
    pA=pB=0.;vA=1.;vB=0.;lines=[(0.,0.)]
    for tick in range(64):
        for s in range(1,11):
            cv,cu,_,_=coefficients(s)
            lines.append((pA+cv*vA,pB+cv*vB+gamma*cu))
        pA+=a*vA;pB+=a*vB+gamma*b
        vA,vB=c*vA,c*vB+gamma*d
        if vA*max_speed-vB<=0:break
    else:raise RuntimeError('Braking envelope horizon insufficient')
    return np.asarray(lines,float).T

_BRAKING_A,_BRAKING_B=braking_envelope()

def corridor_constraints(velocity,normals,limits,faces=16,toward_upper=None):
    velocity=np.asarray(velocity,float);normals=np.asarray(normals,float).reshape(-1,2);limits=np.asarray(limits,float)
    if velocity.shape!=(2,) or not np.isfinite(velocity).all() or np.linalg.norm(velocity)>12.+1e-8:return None,None
    lengths=np.linalg.norm(normals,axis=1)
    if limits.shape!=(len(normals),) or np.any(lengths<1e-12) or not np.isfinite(normals).all() or not np.isfinite(limits).all():
        raise ValueError('Invalid local corridor')
    normals=normals/lengths[:,None];limits=limits/lengths
    theta=(np.arange(faces)+.5)*2*math.pi/faces
    A=[p for p in np.column_stack((np.cos(theta),np.sin(theta)))];rhs=[math.cos(math.pi/faces)]*faces
    fulla,fullb,fullc,fulld=coefficients(10)
    # One realizable shared feedback u=-k*v; ||v||<=12 gives ||u||<=gamma,
    # so this command is inside the16gon for every velocity direction.
    # Position along this backup converges monotonically to p+L*v.
    gain=math.cos(math.pi/faces)/12.
    terminal_length=(fulla-fullb*gain)/(1.-fullc+fulld*gain)
    if len(normals):
        toward=normals@velocity
        if toward_upper is not None:
            upper=np.asarray(toward_upper,float)
            if upper.shape!=toward.shape or not np.isfinite(upper).all():
                raise ValueError('Invalid directional velocity upper bound')
            toward=upper
        cv=np.array([coefficients(s)[0] for s in range(1,11)])
        cu=np.array([coefficients(s)[1] for s in range(1,11)])
        zero=cu==0
        if np.any(limits[:,None]-toward[:,None]*cv[zero]<-1e-8):return None,None
        sub=(limits[:,None]-toward[:,None]*cv[~zero])/cu[~zero]
        terminal=(limits-(fulla+terminal_length*fullc)*toward)/(fullb+terminal_length*fulld)
        bound=np.minimum(np.min(sub,axis=1),terminal)
        # ||u||<=1 implies n.u<=1 for every unit normal: these discarded
        # inequalities are mathematically redundant, not a ranked subset.
        keep=bound<1.
        A.extend(normals[keep]);rhs.extend(bound[keep].tolist())
    return np.asarray(A),np.asarray(rhs)

def project_polygon(desired,A,b,tolerance=1e-8,initial_polygon=None):
    """Project onto polygon by exact edge minimization, then check KKT."""
    desired=np.asarray(desired,float);A=np.asarray(A,float).reshape(-1,2);b=np.asarray(b,float)
    if desired.shape!=(2,) or b.shape!=(len(A),) or not np.isfinite(desired).all() or not np.isfinite(A).all() or not np.isfinite(b).all():
        raise ValueError('Invalid QP data')
    norms=np.linalg.norm(A,axis=1)
    if np.any((norms<1e-14)&(b<-tolerance)):return None
    good=norms>=1e-14;A=A[good]/norms[good,None];b=b[good]/norms[good]
    # Inscribed command polygon is always supplied; [-2,2]^2 contains it.
    poly=[np.array(p,float) for p in (initial_polygon if initial_polygon is not None else [(-2,-2),(2,-2),(2,2),(-2,2)])]
    ids=np.arange(len(A))
    if initial_polygon is not None:
        # Caller supplies the common command polygon, already enforced by the
        # first16 rows. Remove only rows redundant on that exact polygon;
        # retain all original rows for final KKT certification.
        products=A@np.asarray(poly).T
        if np.any(b<products.min(axis=1)-tolerance):return None
        ids=np.flatnonzero(b<products.max(axis=1))
        ids=ids[np.argsort(b[ids],kind='stable')]
    for row,rhs in zip(A[ids],b[ids]):
        clipped=[]
        for x,y in zip(poly,poly[1:]+poly[:1]):
            sx=float(row@x-rhs);sy=float(row@y-rhs)
            if sx<=tolerance:clipped.append(x)
            if (sx<=tolerance)!=(sy<=tolerance):
                den=sx-sy
                if abs(den)>1e-14:clipped.append(x+(sx/den)*(y-x))
        poly=clipped
        if not poly:return None
    candidates=[]
    if np.all(A@desired<=b+tolerance):candidates.append(desired.copy())
    for x,y in zip(poly,poly[1:]+poly[:1]):
        delta=y-x;norm2=float(delta@delta)
        alpha=float(np.clip((desired-x)@delta/norm2,0.,1.)) if norm2>1e-20 else 0.
        candidates.append(x+alpha*delta)
    u=min(candidates,key=lambda z:float(np.sum((z-desired)**2)))
    gradient=u-desired;active=np.flatnonzero(np.abs(A@u-b)<=5*tolerance);dual=np.zeros(len(A));witness=np.linalg.norm(gradient)<=5*tolerance
    if not witness:
        for i in active:
            lam=-float(A[i]@gradient)
            if lam>=-tolerance and np.linalg.norm(gradient+max(0.,lam)*A[i])<=10*tolerance:
                dual[i]=max(0.,lam);witness=True;break
    if not witness:
        for i,j in itertools.combinations(active,2):
            matrix=A[[i,j]].T
            if abs(np.linalg.det(matrix))<1e-12:continue
            lam=np.linalg.solve(matrix,-gradient)
            if np.min(lam)>=-tolerance:
                dual[[i,j]]=np.maximum(0.,lam);witness=True;break
    if not witness:raise RuntimeError('Polygon projection lacks KKT certificate')
    return dict(command=u,objective=.5*float(gradient@gradient),
        stationarity=float(np.linalg.norm(gradient+A.T@dual)),
        primal_violation=max(0.,float(np.max(A@u-b))) if len(A) else 0.,
        complementarity=float(np.max(np.abs(dual*(A@u-b)))) if len(A) else 0.)

def local_command(delta,velocity,normals,limits,faces=16,velocity_weight=1.,effort_weight=.01,toward_upper=None):
    """Min ||a*v+b*u-delta||² + beta||c*v+d*u||² + rho||u||².

    limits are measured signed line distances minus declared center clearance.
    All10 substep halfplanes retained algebraically via parallel compression.
    """
    delta=np.asarray(delta,float);velocity=np.asarray(velocity,float)
    normals=np.asarray(normals,float).reshape(-1,2);limits=np.asarray(limits,float)
    if (delta.shape!=(2,) or velocity.shape!=(2,) or limits.shape!=(len(normals),) or
            not np.isfinite(delta).all() or not np.isfinite(velocity).all() or
            not np.isfinite(normals).all() or not np.isfinite(limits).all() or
            np.any(np.linalg.norm(normals,axis=1)<1e-12) or faces<4 or velocity_weight<0 or effort_weight<=0):
        raise ValueError('Invalid tracking model')
    a,b,c,d=coefficients(10);den=b*b+velocity_weight*d*d+effort_weight
    preferred=(b*delta-(b*a+velocity_weight*d*c)*velocity)/den
    A,rhs=corridor_constraints(velocity,normals,limits,faces,toward_upper)
    if A is None:return None
    result=project_polygon(preferred,A,rhs)
    if result is not None:result.update(preferred=preferred,constraints=len(A))
    return result

def instantaneous_velocity(displacement,previous_command):
    a,b,c,d=coefficients(10)
    return (c/a)*np.asarray(displacement,float)+(d-c*b/a)*np.asarray(previous_command,float)

def scan_halfplanes(lines,clearance=26.):
    normals=[];limits=[]
    for first,last,*_ in lines:
        first,last=np.asarray(first,float),np.asarray(last,float)
        tangent=last-first;length=float(np.linalg.norm(tangent))
        if length<1e-8:continue
        fraction=float(np.clip(-first@tangent/(length*length),0.,1.))
        closest=first+fraction*tangent;distance=float(np.linalg.norm(closest))
        if distance<1e-8:raise ValueError('Unusable segment through sensor origin')
        normal=closest/distance
        normals.append(normal);limits.append(distance-float(clearance))
    return np.asarray(normals,float).reshape(-1,2),np.asarray(limits,float)

def safe_legacy_command(desired,velocity,normals,limits,faces=16,toward_upper=None):
    desired=np.asarray(desired,float);A,b=corridor_constraints(velocity,normals,limits,faces,toward_upper)
    if A is None:return None
    if np.linalg.norm(desired)<=1+1e-10 and np.all(A[faces:]@desired<=b[faces:]+1e-8):
        return dict(command=desired.copy(),stationarity=0.,primal_violation=0.,mode='SAFE_ORIGINAL_COMMAND')
    result=project_polygon(desired,A,b)
    if result is not None:result['mode']='SAFETY_QP'
    return result

def scan_and_raw_halfplanes(lines,distances,angles,clearance=26.):
    """Retain every usable observed endpoint, including TLS-discarded gaps."""
    n,b=scan_halfplanes(lines,clearance)
    ranges=np.asarray(distances,float);rays=np.asarray(angles,float)
    if ranges.ndim!=1 or ranges.shape!=rays.shape:raise ValueError('Invalid raw scan')
    good=np.isfinite(ranges)&np.isfinite(rays)&(ranges>12.)&(ranges<285.)
    raw=np.column_stack((np.cos(rays[good]),np.sin(rays[good])))
    return np.vstack((n,raw)),np.r_[b,ranges[good]-clearance]

def arc_support(normals,center,halfwidth):
    """Exact max n.(cos(theta),sin(theta)) on a closed angular interval."""
    normals=np.asarray(normals,float).reshape(-1,2)
    delta=(np.arctan2(normals[:,1],normals[:,0])-center+math.pi)%(2*math.pi)-math.pi
    return np.cos(np.maximum(0.,np.abs(delta)-halfwidth))

def odometry_velocity_upper(odom,previous_command,normals,sigma=3.):
    """Conservative support of the polar public-odometry error box.

    SDK distance/alpha/theta standard deviations .2px/8deg/1deg.
    Independent component intervals are sigma standard deviations, not an
    absolute Gaussian bound. Separate displacement/previous-command supports
    discard shared-angle coupling conservatively, never underbound the box.
    """
    distance,alpha,turn=map(float,odom)
    normals=np.asarray(normals,float).reshape(-1,2)
    if sigma<0 or not np.isfinite([distance,alpha,turn,sigma]).all():raise ValueError('Invalid odometry uncertainty')
    a,b,c,d=coefficients(10);k=d-c*b/a
    dlow,dhigh=distance-sigma*.2,distance+sigma*.2
    # SDK distance is a nonnegative true distance plus Gaussian readout noise.
    if dhigh<0:raise ValueError('Odometry uncertainty excludes nonnegative distance')
    dlow=max(0.,dlow)
    support=arc_support(normals,alpha-turn,math.radians(sigma*9.))
    displacement=np.maximum(dlow*support,dhigh*support)
    previous=np.asarray(previous_command,float);size=float(np.linalg.norm(previous))
    heading=math.atan2(previous[1],previous[0])-turn
    control=size*arc_support(normals,heading,math.radians(sigma))
    return (c/a)*displacement+k*control
