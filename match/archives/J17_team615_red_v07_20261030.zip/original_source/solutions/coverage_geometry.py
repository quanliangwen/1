"""Coverage-only solid hypotheses from fitted sensor lines; no map truth.

Replace team_coverage.observed_wall_values with geometry_wall_values for an
isolated experiment. The submitted exploration rendering remains unchanged.
The module consumes only memory hits/visits and the existing sensor-line fitter.
"""
import cv2
import numpy as np
from swarm_rescue.solutions.line_regularization import regularized_walls


def geometry_wall_values(memory,radius,return_solids=False,line_width=12,
                         gap_close=24,solid_confidence=.90,visited_limit=.01,
                         allow_open_rectangles=True,measured_layer=None):
    fine=float(memory.FINE)
    if measured_layer is None:
        measured=regularized_walls(memory.hits,fine=memory.FINE,line_width=line_width,
                                   keep_raw=False,fit_band=10,duplicate_distance=8,covariance_limit=30)
    else:
        measured=np.asarray(measured_layer,np.uint8)
        if measured.shape!=memory.hits.shape: raise ValueError('Measured layer shape differs')
    # The line fitter already constrains longitudinal evidence. Closing here is
    # only for coverage geometry, never for submitted-map credit.
    kernel=max(3,int(round(gap_close/fine))|1)
    closed=cv2.morphologyEx(measured,cv2.MORPH_CLOSE,np.ones((kernel,kernel),np.uint8))
    values=measured.astype(np.float32)
    solids=np.zeros_like(measured)
    visited=cv2.resize((memory.visits>0).astype(np.uint8),
                       (measured.shape[1],measured.shape[0]),interpolation=cv2.INTER_NEAREST)
    ray_free=cv2.resize(memory.free.astype(np.uint8),
                       (measured.shape[1],measured.shape[0]),interpolation=cv2.INTER_NEAREST)
    contours,hierarchy=cv2.findContours(closed,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
    if hierarchy is not None:
        for contour,link in zip(contours,hierarchy[0]):
            if link[3]<0: continue
            area=cv2.contourArea(contour)*fine*fine
            if area<24*24: continue
            (_, _),(width,height),_=cv2.minAreaRect(contour)
            short,long=sorted((width*fine,height*fine))
            if short<24 or long>3*radius: continue
            hull_area=cv2.contourArea(cv2.convexHull(contour))*fine*fine
            if hull_area<=0 or area/hull_area<.85: continue
            interior=np.zeros_like(measured)
            cv2.drawContours(interior,[contour],-1,1,-1)
            # A ray-free Boolean can be false inside real solids. Actual visits
            # to an eroded core are stronger contradiction evidence.
            erosion=max(3,int(round(2*memory.CELL/fine))|1)
            core=cv2.erode(interior,np.ones((erosion,erosion),np.uint8))>0
            if core.any() and np.mean(visited[core])>visited_limit: continue
            values[interior>0]=np.maximum(values[interior>0],solid_confidence)
            solids|=interior
    if allow_open_rectangles:
        # Three observed sides can support a convex rectangular obstacle before
        # its fourth side is surveyed. Use only compact, almost rectangular
        # component hulls and reject any physically visited eroded interior.
        # Lower confidence explicitly preserves this as an uncertain hypothesis.
        outer,_=cv2.findContours(measured,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        for contour in outer:
            hull=cv2.convexHull(contour)
            hull_area=cv2.contourArea(hull)*fine*fine
            (_, _),(width,height),_=cv2.minAreaRect(hull)
            short,long=sorted((width*fine,height*fine))
            rectangle_area=short*long
            if (short<48 or long>3*radius or rectangle_area<=0 or
                    hull_area/rectangle_area<.80): continue
            interior=np.zeros_like(measured)
            cv2.drawContours(interior,[hull],-1,1,-1)
            erosion=max(3,int(round(2*memory.CELL/fine))|1)
            core=cv2.erode(interior,np.ones((erosion,erosion),np.uint8))>0
            if (not core.any() or np.mean(visited[core])>visited_limit or
                    np.mean(ray_free[core])>.85): continue
            # Suppress the uncertain bounding strip; direct measured surfaces
            # remain in values independently. This limits outward hull errors.
            shrink=max(3,int(round(20/fine))|1)
            interior=cv2.erode(interior,np.ones((shrink,shrink),np.uint8))
            if not interior.any(): continue
            values[interior>0]=np.maximum(values[interior>0],.65)
            solids|=interior
    values=cv2.resize(values,(memory.shape[1],memory.shape[0]),interpolation=cv2.INTER_AREA)
    rr,cc=np.indices(memory.shape)
    xx=(cc+.5)*memory.CELL-memory.width/2
    yy=memory.height/2-(rr+.5)*memory.CELL
    frame=(np.abs(xx)>memory.width/2-memory.CELL)|(np.abs(yy)>memory.height/2-memory.CELL)
    values[frame]*=.5
    if return_solids:
        solids=cv2.resize(solids,(memory.shape[1],memory.shape[0]),interpolation=cv2.INTER_NEAREST)>0
        return values,solids
    return values
