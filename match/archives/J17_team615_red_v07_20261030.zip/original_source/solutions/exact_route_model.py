"""Finite-domain route/union-coverage MILP diagnostic (server research only).

No greedy incumbent, sampled candidate ranking, or local-search neighbourhood.
The declared site domain is input; optimality applies only to this finite model.
Gurobi is not added to any official submission's dependencies.
"""
from itertools import permutations
import math
import time
import numpy as np


def enumerate_routes(owner_ids, inventories, start_costs, between, points,
                     budgets, separation):
    n = len(points)
    routes = {}
    for i in owner_ids:
        if inventories[i] not in (0, 1, 2):
            raise ValueError('Model supports zero, one or two remaining slots')
        columns = [((), 0.)]
        for count in range(1, inventories[i]+1):
            for route in permutations(range(n), count):
                if count == 2 and np.linalg.norm(points[route[0]]-points[route[1]]) < separation-1e-8:
                    continue
                cost = float(start_costs[i][route[0]])
                if count == 2:
                    cost += float(between[route[0], route[1]])
                if math.isfinite(cost) and cost <= budgets[i]+1e-8:
                    columns.append((route, cost))
        routes[i] = columns
    return routes


def solve(owner_ids, inventories, start_costs, between, points, cover, weights,
          budgets, separation, time_limit=2.):
    import gurobipy as gp
    started = time.perf_counter()
    points = np.asarray(points, float).reshape((-1, 2))
    cover = np.asarray(cover, bool)
    weights = np.asarray(weights, float)
    if cover.shape != (len(points), len(weights)) or np.any(weights < 0) or not np.isfinite(weights).all():
        raise ValueError('Invalid coverage matrix/weights')
    columns = enumerate_routes(owner_ids, inventories, start_costs, between,
                               points, budgets, separation)
    # Silence only this independent model; don't modify the global environment.
    with gp.Env(empty=True) as env:
        env.setParam('OutputFlag', 0)
        env.start()
        with gp.Model(env=env) as model:
            model.Params.Threads = 1
            model.Params.Heuristics = 0
            model.Params.MIPGap = 0
            model.Params.MIPGapAbs = 0
            model.Params.TimeLimit = float(time_limit)
            model.Params.Seed = 0
            z = {(i, r): model.addVar(vtype=gp.GRB.BINARY)
                 for i in owner_ids for r in range(len(columns[i]))}
            u = model.addVars(len(points), vtype=gp.GRB.BINARY)
            y = model.addVars(len(weights), lb=0, ub=1)
            for i in owner_ids:
                model.addConstr(gp.quicksum(z[i, r] for r in range(len(columns[i]))) == 1)
            for j in range(len(points)):
                model.addConstr(u[j] == gp.quicksum(z[i, r] for i in owner_ids
                    for r, (route, _) in enumerate(columns[i]) if j in route))
            conflicts = 0
            for j in range(len(points)):
                for k in range(j):
                    if np.linalg.norm(points[j]-points[k]) < separation-1e-8:
                        model.addConstr(u[j]+u[k] <= 1)
                        conflicts += 1
            for e in range(len(weights)):
                model.addConstr(y[e] <= gp.quicksum(u[j] for j in np.flatnonzero(cover[:, e])))
            # A mathematically bounded coefficient makes placement cardinality
            # primary, coverage secondary. No guessed game difficulty reward.
            dominance = float(weights.sum()) + 1.
            model.setObjective(dominance*gp.quicksum(u.values()) +
                               gp.quicksum(float(weights[e])*y[e] for e in range(len(weights))),
                               gp.GRB.MAXIMIZE)
            model.optimize()
            audit = dict(status=int(model.Status), solution_count=int(model.SolCount),
                         columns={str(i): len(columns[i]) for i in owner_ids},
                         variables=int(model.NumVars), constraints=int(model.NumConstrs),
                         node_count=float(model.NodeCount), conflicts=conflicts,
                         requested_slots=sum(inventories.values()),
                         heuristic_effort=0, threads=1,
                         solver_version=list(gp.gurobi.version()),
                         bound=float(model.ObjBound) if math.isfinite(model.ObjBound) else None)
            if not model.SolCount:
                return {}, dict(audit, elapsed=time.perf_counter()-started)
            result = {}
            used = []
            costs = {}
            for i in owner_ids:
                chosen = [r for r in range(len(columns[i])) if z[i, r].X > .5]
                if len(chosen) != 1:
                    raise RuntimeError('Invalid discrete owner decision')
                route, cost = columns[i][chosen[0]]
                result[i] = list(route)
                used.extend(route)
                costs[str(i)] = cost
            if len(used) != len(set(used)):
                raise RuntimeError('Repeated site')
            coverage = float(weights[np.any(cover[used], axis=0)].sum()) if used else 0.
            audit.update(objective=float(model.ObjVal), gap=float(model.MIPGap),
                         selected_slots=len(used), covered_weight=coverage,
                         route_costs=costs, elapsed=time.perf_counter()-started)
            return result, audit


def prepare_observed_domain(memory, agents, drops, radius, travel_budget,
                            forbidden_points=(), forbidden_mask=None,
                            reserved_prefixes=None, max_sites=36, explicit_cells=None,
                            eager_between=True):
    """Read only own belief. explicit_cells is diagnostic-only and declared.

    Default domain: all allowed points on a fixed map-aligned coarse lattice;
    increase integer lattice stride until <=max_sites. No utility sorting.
    Actual original free observations are required, not just morphological fill.
    """
    from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
    from swarm_rescue.solutions.team_coverage import observed_wall_values, path_costs
    started = time.perf_counter()
    from swarm_rescue.solutions.shared_wall_layers import regularized_wall_layers
    from swarm_rescue.solutions.coverage_geometry import geometry_wall_values
    fit_started=time.perf_counter()
    layers=regularized_wall_layers(memory.hits,fine=memory.FINE,line_widths=(8,12),
        keep_raw=False,fit_band=10,duplicate_distance=8,covariance_limit=30)
    fit_seconds=time.perf_counter()-fit_started
    pm = GeometryPlanningMemory(memory,measured_layer=layers[8])
    prepared_values,prepared_solids=geometry_wall_values(pm,radius,return_solids=True,
        line_width=12,measured_layer=layers[12])
    pm._coverage_values_cache=(float(radius),prepared_values,prepared_solids)
    values, solids = observed_wall_values(pm, radius, return_solids=True)
    values = np.asarray(values, float).copy()
    if hasattr(memory, 'bearing_wall_values'):
        values = memory.bearing_wall_values(values)
    walkable = np.asarray(memory.free, bool) & pm.free & ~pm.blocked() & ~solids
    rr, cc = np.indices(pm.shape)
    xx = (cc+.5)*pm.CELL-pm.width/2
    yy = pm.height/2-(rr+.5)*pm.CELL
    allowed = walkable.copy()
    if forbidden_mask is not None:
        allowed &= ~np.asarray(forbidden_mask, bool)
    for p, exclusion in forbidden_points:
        allowed[(xx-p[0])**2+(yy-p[1])**2 < exclusion**2] = False
    separation = 40.+.71*pm.CELL
    for p in drops:
        squared = (xx-p[0])**2+(yy-p[1])**2
        values[squared <= radius**2] = 0
        allowed[squared < separation**2] = False
    cells = []
    stride = None
    if explicit_cells is not None:
        cells = sorted(set(tuple(int(x) for x in cell) for cell in explicit_cells))
        if (max_sites is not None and len(cells) > max_sites) or any(not allowed[cell] for cell in cells):
            raise ValueError('Invalid declared diagnostic domain')
    else:
        stride = 1
        while True:
            domain = allowed & (rr % stride == 0) & (cc % stride == 0)
            cells = [tuple(int(v) for v in cell) for cell in zip(*np.nonzero(domain))]
            if max_sites is None or len(cells) <= max_sites:
                break
            stride += 1
    points = np.asarray([pm.cell_to_world(cell) for cell in cells], float).reshape((-1, 2))
    positive = np.flatnonzero(values.ravel() > 0)
    weights = values.ravel()[positive]
    coordinates = np.column_stack((xx.ravel()[positive], yy.ravel()[positive]))
    cover = np.array([np.sum((coordinates-p)**2, axis=1) <= radius**2+1e-8
                      for p in points], bool).reshape((len(points), len(weights)))
    fields = {}
    field_stats = {'calls': 0, 'hits': 0, 'misses': 0}
    def field(cell):
        cell = tuple(cell)
        field_stats['calls'] += 1
        if cell not in fields:
            field_stats['misses'] += 1
            if len(fields) >= 64:
                fields.pop(next(iter(fields)))
            fields[cell] = path_costs(pm, walkable, cell)
        else:
            field_stats['hits'] += 1
        return fields[cell]
    owners = sorted(int(i) for i, (_, count) in agents.items() if int(count) > 0)
    inventories = {i: int(agents[i][1]) for i in owners}
    budgets = {i: float(travel_budget.get(i, 0) if isinstance(travel_budget, dict)
                        else math.inf if travel_budget is None else travel_budget) for i in owners}
    prefix_audit = []
    for i, (position, target) in (reserved_prefixes or {}).items():
        if i not in budgets:
            continue
        if not np.array_equal(np.asarray(agents[i][0]), np.asarray(target)):
            raise ValueError('Reserved target differs from suffix origin')
        source, goal = pm.world_to_cell(position), pm.world_to_cell(target)
        distance = float(field(source)[goal]) if walkable[source] and walkable[goal] else math.inf
        before = budgets[i]
        budgets[i] = max(0., before-distance) if math.isfinite(distance) else 0.
        prefix_audit.append(dict(owner=i, distance=distance if math.isfinite(distance) else None,
                                 budget_before=before, suffix_budget=budgets[i]))
    start_costs = {}
    for i in owners:
        source = pm.world_to_cell(agents[i][0])
        start_costs[i] = np.array([field(source)[cell] for cell in cells]) if walkable[source] else np.full(len(cells), math.inf)
    if eager_between:
        between = np.array([[field(a)[b] for b in cells] for a in cells], float).reshape((len(cells), len(cells)))
    else:
        between = lambda j, k: float(field(cells[j])[cells[k]])
    return dict(owner_ids=owners, inventories=inventories, start_costs=start_costs,
                between=between, points=points, cover=cover, weights=weights,
                budgets=budgets, separation=separation), dict(
                    stride=stride, site_count=len(cells), cells=[list(c) for c in cells],
                    domain='declared_explicit' if explicit_cells is not None else 'complete_fixed_lattice',
                    prefix_accounting=prefix_audit, distance_fields=len(fields),
                    distance_field_stats=field_stats,
                    preparation_elapsed=time.perf_counter()-started,
                    geometry_fit_passes=1,geometry_fit_seconds=fit_seconds,
                    known_free_only=True, exact_scope='finite sites and observed graph only')


def solve_assignment(owner_ids, inventories, start_costs, between, points, cover,
                     weights, budgets, separation, time_limit=2.):
    """Exact projected two-stop route model with lazy budget cuts.

    Each owner's set has <=2 sites. For a pair {j,k}, some order is feasible iff
    min(d(start,j)+d(j,k), d(start,k)+d(k,j)) <= budget. Thus a violated pair
    can be excluded by x_ij+x_ik<=1 without introducing all route columns.
    """
    import gurobipy as gp
    started = time.perf_counter()
    points, cover, weights = np.asarray(points, float), np.asarray(cover, bool), np.asarray(weights, float)
    if any(inventories[i] not in (0, 1, 2) for i in owner_ids):
        raise ValueError('Two-stop model only')
    if cover.shape != (len(points), len(weights)) or np.any(weights < 0) or not np.isfinite(weights).all():
        raise ValueError('Invalid coverage model')
    if any(math.isnan(budgets[i]) or budgets[i] < 0 for i in owner_ids):
        raise ValueError('Invalid route budget')
    metric = between if callable(between) else lambda j, k: float(between[j, k])
    route_costs, cut_keys, errors = {}, set(), []
    def pair_cost(i, j, k):
        key = (i, min(j, k), max(j, k))
        if key not in route_costs:
            jk, kj = metric(j, k), metric(k, j)
            if math.isnan(jk) or math.isnan(kj) or jk < 0 or kj < 0:
                raise ValueError('Invalid graph metric')
            route_costs[key] = min(float(start_costs[i][j])+jk, float(start_costs[i][k])+kj)
        return route_costs[key]
    with gp.Env(empty=True) as env:
        env.setParam('OutputFlag', 0)
        env.start()
        with gp.Model(env=env) as model:
            for key, value in dict(Threads=1, Heuristics=0, MIPGap=0, MIPGapAbs=0,
                                   TimeLimit=float(time_limit), Seed=0, LazyConstraints=1).items():
                model.setParam(key, value)
            feasible = [(i, j) for i in owner_ids for j in range(len(points))
                        if inventories[i] and math.isfinite(float(start_costs[i][j]))
                        and 0 <= float(start_costs[i][j]) <= budgets[i]+1e-8]
            x = {key: model.addVar(vtype=gp.GRB.BINARY) for key in feasible}
            u = model.addVars(len(points), vtype=gp.GRB.BINARY)
            y = model.addVars(len(weights), lb=0, ub=1)
            by_owner = {i: [j for k, j in feasible if k == i] for i in owner_ids}
            by_site = {j: [i for i in owner_ids if (i, j) in x] for j in range(len(points))}
            for i in owner_ids:
                model.addConstr(gp.quicksum(x[i, j] for j in by_owner[i]) <= inventories[i])
            for j in range(len(points)):
                model.addConstr(u[j] == gp.quicksum(x[i, j] for i in by_site[j]))
            conflicts = 0
            # Exact spatial indexing of all conflicts, not a candidate filter.
            bins = {}
            size = max(float(separation), 1e-9)
            for j, point in enumerate(points):
                bucket = tuple(math.floor(float(v)/size) for v in point)
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        for k in bins.get((bucket[0]+dx, bucket[1]+dy), ()):
                            if np.linalg.norm(point-points[k]) < separation-1e-8:
                                model.addConstr(u[j]+u[k] <= 1)
                                conflicts += 1
                bins.setdefault(bucket, []).append(j)
            for e in range(len(weights)):
                model.addConstr(y[e] <= gp.quicksum(u[int(j)] for j in np.flatnonzero(cover[:, e])))
            dominance = float(weights.sum())+1.
            model.setObjective(dominance*gp.quicksum(u.values()) +
                               gp.quicksum(float(weights[e])*y[e] for e in range(len(weights))), gp.GRB.MAXIMIZE)
            def separate(m, where):
                if where != gp.GRB.Callback.MIPSOL:
                    return
                try:
                    for i in owner_ids:
                        js = [j for j in by_owner[i] if m.cbGetSolution(x[i, j]) > .5]
                        if len(js) > 2:
                            raise RuntimeError('Integer solution violates inventory')
                        if len(js) == 2:
                            j, k = js
                            if pair_cost(i, j, k) > budgets[i]+1e-8:
                                m.cbLazy(x[i, j]+x[i, k] <= 1)
                                cut_keys.add((i, min(j, k), max(j, k)))
                except Exception as exc:
                    errors.append(repr(exc))
                    m.terminate()
            model.optimize(separate)
            if errors:
                raise RuntimeError('Route separation callback failed: '+str(errors))
            audit = dict(status=int(model.Status), solution_count=int(model.SolCount),
                         variables=int(model.NumVars), constraints=int(model.NumConstrs),
                         node_count=float(model.NodeCount), conflicts=conflicts,
                         requested_slots=sum(inventories.values()), heuristic_effort=0,
                         threads=1, lazy_route_cuts=len(cut_keys), evaluated_pairs=len(route_costs),
                         solver_version=list(gp.gurobi.version()),
                         bound=float(model.ObjBound) if math.isfinite(model.ObjBound) else None,
                         formulation='two_stop_projection_with_lazy_exact_graph_cuts')
            if not model.SolCount:
                return {}, dict(audit, elapsed=time.perf_counter()-started)
            plan, spent = {}, {}
            for i in owner_ids:
                js = [j for j in by_owner[i] if x[i, j].X > .5]
                if len(js) == 2:
                    j, k = js
                    # Return the shorter of the two exactly evaluated orders.
                    if float(start_costs[i][k])+metric(k, j) < float(start_costs[i][j])+metric(j, k):
                        js.reverse()
                    cost = pair_cost(i, j, k)
                else:
                    cost = float(start_costs[i][js[0]]) if js else 0.
                if len(js) > inventories[i] or cost > budgets[i]+1e-8:
                    raise RuntimeError('Returned route fails independent budget check')
                plan[i], spent[str(i)] = js, cost
            chosen = [j for js in plan.values() for j in js]
            if len(chosen) != len(set(chosen)):
                raise RuntimeError('Returned layout duplicates a site')
            for j, k in permutations(chosen, 2):
                if np.linalg.norm(points[j]-points[k]) < separation-1e-8:
                    raise RuntimeError('Returned layout violates separation')
            coverage = float(weights[np.any(cover[chosen], axis=0)].sum()) if chosen else 0.
            audit.update(objective=float(model.ObjVal), gap=float(model.MIPGap),
                         selected_slots=len(chosen), covered_weight=coverage,
                         route_costs=spent, elapsed=time.perf_counter()-started)
            return plan, audit
