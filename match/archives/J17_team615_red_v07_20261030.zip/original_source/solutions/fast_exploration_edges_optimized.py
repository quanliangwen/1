"""Vectorized equivalent of the measured-edge exploration utility.

Keep the original edge module installed. Derive AnchoredMapMemory from
OptimizedEdgeSurveyMapMemory in this module to use the faster implementation.
Only measured lidar, received packets and public dimensions enter navigation.
"""
from __future__ import annotations

import math

import cv2
import numpy as np

from swarm_rescue.solutions.fast_exploration import CoordinatedMapMemory
from swarm_rescue.solutions.fast_exploration_edges import EdgeSurveyMapMemory


class OptimizedEdgeSurveyMapMemory(EdgeSurveyMapMemory):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._edge_points_cache = [np.asarray([self._edge_point(side, i) for i in range(len(absent))])
                                  for side, absent in enumerate(self.edge_no_wall)]
        self._edge_cells_cache = [np.asarray([self.world_to_cell(point) for point in points])
                                 for points in self._edge_points_cache]
        self._ray_angles_cache = None
        self._sorted_ray_angles = None
        self._sorted_ray_indices = None
        self._duplicate_ray_groups = []
        self._surface_revision = 0
        self._survey_cache_key = None
        self._survey_cache = None

    def _nearest_rays(self, bearings, heading, angles):
        """Circular nearest neighbor without a bins-by-rays difference matrix."""
        if self._ray_angles_cache is None or not np.array_equal(self._ray_angles_cache, angles):
            self._ray_angles_cache = np.asarray(angles, float).copy()
            # Duplicate -pi/+pi rays use the first original index, like argmin.
            normalized = np.mod(angles, 2*math.pi)
            self._sorted_ray_angles, indices, counts = np.unique(normalized, return_index=True, return_counts=True)
            self._sorted_ray_indices = indices
            self._duplicate_ray_groups = [np.flatnonzero(normalized == angle)
                for angle, count in zip(self._sorted_ray_angles, counts) if count > 1]
        queries = np.mod(bearings-heading, 2*math.pi)
        insertion = np.searchsorted(self._sorted_ray_angles, queries)
        count = len(self._sorted_ray_angles)
        lower = self._sorted_ray_indices[(insertion-1) % count]
        upper = self._sorted_ray_indices[insertion % count]
        # Compute the final error in the same operation order as the original.
        low_error = np.abs((heading+angles[lower]-bearings+math.pi) % (2*math.pi)-math.pi)
        high_error = np.abs((heading+angles[upper]-bearings+math.pi) % (2*math.pi)-math.pi)
        choose_lower = (low_error < high_error) | ((low_error == high_error) & (lower < upper))
        rays = np.where(choose_lower, lower, upper)
        error = np.where(choose_lower, low_error, high_error)
        # Although -pi and +pi represent the same bearing, floating arithmetic
        # can make one wrapped error 1 ulp smaller. Check original duplicates
        # explicitly to preserve the old argmin's selected lidar reading.
        for group in self._duplicate_ray_groups:
            selected = np.flatnonzero(np.isin(rays, group))
            if not len(selected):
                continue
            duplicate_error = np.abs((heading+angles[group][None, :]-bearings[selected, None]+math.pi)
                                     % (2*math.pi)-math.pi)
            choices = np.argmin(duplicate_error, axis=1)
            rays[selected] = group[choices]
            error[selected] = duplicate_error[np.arange(len(selected)), choices]
        return rays, error

    def observe(self, position, heading, distances, ray_angles, semantic=()):
        # Bypass only the old scalar edge loop; preserve ordinary map updates.
        CoordinatedMapMemory.observe(self, position, heading, distances, ray_angles, semantic)
        self._surface_revision += 1
        d, a = np.asarray(distances, float), np.asarray(ray_angles, float)
        if len(d) != len(a) or not len(d):
            return
        position = np.asarray(position, float)
        for side, points in enumerate(self._edge_points_cache):
            vectors = points-position
            distances_to_edge = np.linalg.norm(vectors, axis=1)
            valid = np.flatnonzero((distances_to_edge > 35) & (distances_to_edge < 195))
            if not len(valid):
                continue
            bearings = np.arctan2(vectors[valid, 1], vectors[valid, 0])
            rays, error = self._nearest_rays(bearings, heading, a)
            clear = (error < math.radians(1.5)) & np.isfinite(d[rays]) & (d[rays] > distances_to_edge[valid]+24)
            self.edge_no_wall[side][valid[clear]] = True

    def merge(self, packet):
        super().merge(packet)
        self._surface_revision += 1

    def _batch_line_visibility(self, starts, ends, occupied):
        """Exactly the old doubled-grid line sampling, evaluated in one array."""
        starts, ends = np.asarray(starts, int), np.asarray(ends, int)
        delta = ends-starts
        count = np.maximum(2, 2*np.max(np.abs(delta), axis=1)+1)
        indices = np.arange(int(count.max()))[None, :]
        # np.linspace computes start + index * step. Retaining that order
        # preserves rounding of cell boundaries rather than changing the ray.
        step = delta/(count-1)[:, None]
        rows = np.rint(starts[:, 0, None]+indices*step[:, 0, None]).astype(int)
        cols = np.rint(starts[:, 1, None]+indices*step[:, 1, None]).astype(int)
        sample = indices < (count-1)[:, None]  # original lr[:-1], lc[:-1]
        rows = np.clip(rows, 0, self.shape[0]-1)
        cols = np.clip(cols, 0, self.shape[1]-1)
        return ~np.any(occupied[rows, cols] & sample, axis=1)

    def survey_gain(self, blocked=None):
        use_cache = blocked is None
        key = self._surface_revision
        if use_cache and self._survey_cache_key == key:
            return self._survey_cache.copy()
        if blocked is None:
            blocked = self.blocked()
        free = self.free & ~blocked
        rr, cc = np.indices(self.shape)
        gain = np.zeros(self.shape, np.float32)
        sides = self.edge_spans()
        coarse_wall = cv2.resize((self.hits >= 2).astype(np.float32),
            (self.shape[1], self.shape[0]), interpolation=cv2.INTER_AREA) >= .035
        for side, missing in enumerate(sides):
            indices = np.flatnonzero(missing)
            if not len(indices):
                continue
            if side == 0:
                perpendicular, along = (rr+.5)*self.CELL-3, cc
            elif side == 1:
                perpendicular, along = self.height-(rr+.5)*self.CELL-3, cc
            elif side == 2:
                perpendicular, along = (cc+.5)*self.CELL-3, rr
            else:
                perpendicular, along = self.width-(cc+.5)*self.CELL-3, rr
            candidates = free & (perpendicular >= 45) & (perpendicular <= self.EDGE_RANGE)
            rows, cols = np.nonzero(candidates)
            if not len(rows):
                continue
            longitudinal = (indices[None, :]-along[rows, cols, None])*self.CELL
            distance = np.hypot(longitudinal, perpendicular[rows, cols, None])
            visible_mask = distance <= self.EDGE_RANGE
            visible_count = visible_mask.sum(axis=1)
            starts, ends, owners = [], [], []
            # Keep the old visible-subset argsort, including its tie ordering.
            # Only this cheap selection is scalar; all ray grids are batched.
            for candidate in np.flatnonzero(visible_count):
                visible = indices[visible_mask[candidate]]
                ordered = visible[np.argsort(np.abs(visible-int(along[rows[candidate], cols[candidate]])))]
                for index in ordered[:3]:
                    start = (int(rows[candidate]), int(cols[candidate]))
                    starts.append(start)
                    ends.append(self._edge_cells_cache[side][index])
                    owners.append(candidate)
            if not starts:
                continue
            clear = self._batch_line_visibility(starts, ends, coarse_wall)
            clear_count = np.bincount(np.asarray(owners)[clear], minlength=len(rows))
            values = visible_count*clear_count/np.maximum(1, np.minimum(3, visible_count))
            gain[rows, cols] += values.astype(np.float32)
        if use_cache:
            self._survey_cache_key, self._survey_cache = key, gain.copy()
        return gain


# This alias makes the parent-class import change a one-line substitution.
EdgeSurveyMapMemory = OptimizedEdgeSurveyMapMemory
