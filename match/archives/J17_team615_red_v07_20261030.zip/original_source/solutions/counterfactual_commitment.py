"""One irreversible placement at a time, with sensor-belief opportunity cost.

Compare an optimistic K-disk layout against committing this observed site and
optimizing the remaining K-1 slots. These are heuristic values, not certified
bounds or official scores. Hypothetical unknown sites never become targets.
"""
import math
import cv2
import numpy as np
from swarm_rescue.solutions.active_coverage import greedy_value
from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
from swarm_rescue.solutions.team_coverage import observed_wall_values
from swarm_rescue.solutions.fleet_mission import FleetCoverageMixin
from swarm_rescue.solutions.greedy_mapping import GreedyMappingDrone


def uncertain_wall_density(wall_mass,known_cells,radius,cell_size):
    # A scan footprint is correlated evidence. Counting every cell as an
    # independent sample would make a mostly-empty first scan overconfident.
    # Beta(2,8) encodes a broad prior; use an optimistic mean+2sd moment bound.
    footprint=max(1.,math.pi*(radius/cell_size)**2)
    effective=max(0.,float(known_cells))/footprint
    frequency=float(np.clip(wall_mass/max(1.,known_cells),0.,1.))
    alpha=2.+effective*frequency;beta=8.+effective*(1.-frequency)
    mean=alpha/(alpha+beta)
    variance=alpha*beta/((alpha+beta)**2*(alpha+beta+1.))
    return float(np.clip(mean+2.*math.sqrt(variance),.005,.35))


def commitment_loss(measured,unseen,allowed,cell,radius,cell_size,slots):
    """Lost opportunity if one slot is irreversibly spent on this known site."""
    slots=max(1,int(slots));rr,cc=np.indices(measured.shape)
    disk=(rr-cell[0])**2+(cc-cell[1])**2<=(radius/cell_size)**2
    potential=measured+unseen
    free_value=greedy_value(potential,allowed,radius,cell_size,slots)
    remaining=potential.copy();remaining[disk]=0
    legal=allowed.copy()
    legal[(rr-cell[0])**2+(cc-cell[1])**2<((40+.71*cell_size)/cell_size)**2]=False
    forced=float(measured[disk].sum())+greedy_value(remaining,legal,radius,cell_size,slots-1)
    return 20.*max(0.,free_value-forced)/max(1.,free_value)


def should_defer(loss,remaining,execution,probe,completion_value):
    slack=remaining-execution
    if slack<=probe:return False
    delay=completion_value*probe/max(1.,slack)
    return loss>max(.2,delay)


class CounterfactualCommitmentMixin:
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self._commitment_fields=None;self._commitment_step=-1000
        self._commitment_losses={}
        self.commitment_diagnostics={};self._defer_logged=None

    def _build_fleet_plan(self,step):
        # Plans may be revised while exploration is valuable. Every current
        # inventory slot is available to the supplier at every planning tick.
        return super()._build_fleet_plan(step)

    def _commitment_model(self,step):
        if self._commitment_fields is not None and step-self._commitment_step<120:
            return self._commitment_fields
        view=GeometryPlanningMemory(self.memory)
        values,solids=observed_wall_values(view,self.blast_radius,return_solids=True)
        supported=cv2.resize((self.memory.hits>=2).astype(np.float32),
            (self.memory.shape[1],self.memory.shape[0]),interpolation=cv2.INTER_AREA)>.02
        supported=cv2.dilate(supported.astype(np.uint8),np.ones((3,3),np.uint8)).astype(bool)
        unknown=~view.free & ~supported & ~solids
        known=view.free|supported|solids
        density=uncertain_wall_density(float(values.sum()),int(known.sum()),self.blast_radius,view.CELL)
        unseen=unknown.astype(np.float32)*density
        allowed=~view.blocked() & ~solids
        rr,cc=np.indices(view.shape);xx=(cc+.5)*view.CELL-view.width/2;yy=view.height/2-(rr+.5)*view.CELL
        forbidden=self._placement_forbidden_mask()
        if forbidden is not None:allowed &= ~forbidden
        for point,rad in self._placement_forbidden():
            allowed[(xx-point[0])**2+(yy-point[1])**2<rad**2]=False
        self._commitment_fields=(view,values,unseen,allowed,xx,yy)
        self._commitment_step=step
        self._commitment_losses={}
        return self._commitment_fields

    def _should_defer_commitment(self,loss,remaining,execution,probe,completion_value,step):
        return should_defer(loss,remaining,execution,probe,completion_value)

    def _plan_route(self,step,returning,peer_goals):
        ordinary=super()._plan_route(step,returning,peer_goals)
        target=self.placement_goal
        inventory=int(self.carried_bombs_count())
        if target is None or inventory<=0:return ordinary
        view,base,latent,legal,xx,yy=self._commitment_model(step)
        values=base.copy();unseen=latent.copy();allowed=legal.copy()
        for point in self.drop_records.values():
            squared=(xx-point[0])**2+(yy-point[1])**2
            values[squared<=self.blast_radius**2]=0;unseen[squared<=self.blast_radius**2]=0
            allowed[squared<(40+.71*view.CELL)**2]=False
        # Stale inventory is a conservative remaining-option estimate. It is
        # never used to command a disconnected peer or read another instance.
        initial=max(1,int(self.initial_inventory or inventory))
        slots=sum(inventory if peer==int(self.identifier or 0) else
            int(self.inventory_records.get(peer,(0,initial))[1]) for peer in range(self.team_size))
        key=(view.world_to_cell(target),slots,tuple(sorted(self.drop_records)))
        if key not in self._commitment_losses:
            self._commitment_losses[key]=commitment_loss(values,unseen,allowed,key[0],self.blast_radius,view.CELL,slots)
        loss=self._commitment_losses[key]
        path=[self.pose]+list(ordinary[0])
        travel=sum(float(np.linalg.norm(b-a)) for a,b in zip(path,path[1:]))/3.
        execution=travel+max(0,inventory-1)*(4*self.blast_radius/3.+24.)+24.
        probe=2*self.blast_radius/3.+24.
        defer=self._should_defer_commitment(loss,self._remaining_steps(),execution,probe,
            40.*inventory/max(1,self.team_size*initial),step)
        self.commitment_diagnostics={'loss':loss,'defer':defer,'slots':slots,'execution':execution}
        if defer:
            # Explicit release is sent through the existing acknowledgment
            # protocol. It neither marks a legal site unreachable nor spends it.
            self.assignment_goal=None;self.assignment_inventory=None
            self.assignment_reports[int(self.identifier or 0)]=self._own_assignment_report(step)
            self.placement_goal=None
            return GreedyMappingDrone._plan_route(self,step,False,peer_goals)
        return ordinary
