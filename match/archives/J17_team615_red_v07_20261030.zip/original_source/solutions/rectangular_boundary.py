"""Sensor-driven rectangular frame hypothesis, with persistent gap evidence.

No simulator/map/evaluation state is read. Four repeatedly measured physical
line families fit the rectangle's orientation and planes. Public arena size
only rejects small interior rectangles; it never supplies a rendered plane.
The extrapolated corners are a structural inference, not observed geometry.
"""
from __future__ import annotations
from dataclasses import dataclass
from collections import deque
import math
import numpy as np
import cv2


def _merge_intervals(intervals):
    merged = []
    for first, last in sorted(intervals):
        if not merged or first > merged[-1][1]:
            merged.append([first,last])
        else:
            merged[-1][1] = max(merged[-1][1],last)
    return merged


def _weighted_median(values, weights):
    order = np.argsort(values)
    values, weights = np.asarray(values)[order], np.asarray(weights)[order]
    return float(values[np.searchsorted(np.cumsum(weights),.5*weights.sum())])


@dataclass
class FrameHypothesis:
    angle: float
    planes: tuple
    spans: tuple
    independent_scans: tuple
    support_fractions: tuple
    corners: np.ndarray
    closed: bool = True
    plane_mads: tuple = ()
    observed_axis_bias: float = 0.0


class RectangularBoundaryInference:
    """Conservative four-side frame model around public arena coordinates.

    `observe` takes WORLD-space measured line endpoints and optional measured
    free-ray endpoints. A free-ray endpoint is a lidar return or max-range point:
    the straight segment before it is observed clear, regardless of hit class.
    Repeated penetration beyond a fitted plane invalidates that wall interval.
    """
    def __init__(self, width, height, *, min_scans=3, minimum_span=.30,
                 maximum_corner_extension=.25, minimum_extent=.96,
                 wall_width=12, free_penetration=20, opening_scans=2,
                 plane_coordinate_guard=12, maximum_axis_tilt_deg=.5,
                 contradiction_sigma=3, gps_sigma=5, compass_sigma_deg=4,
                 lidar_sigma=2.5, world_axis_prior=False, plane_mad_limit=4,
                 maximum_line_angle_deg=4, maximum_line_normal_spread=12,
                 maximum_observed_axis_bias_deg=1.5):
        self.width,self.height = int(width),int(height)
        self.min_scans,self.minimum_span = int(min_scans),float(minimum_span)
        self.maximum_corner_extension = float(maximum_corner_extension)
        self.minimum_extent = float(minimum_extent)
        self.wall_width,self.free_penetration = int(wall_width),float(free_penetration)
        self.opening_scans = int(opening_scans)
        self.plane_coordinate_guard=float(plane_coordinate_guard)
        self.maximum_axis_tilt=math.radians(maximum_axis_tilt_deg)
        self.contradiction_sigma=float(contradiction_sigma)
        self.gps_sigma,self.compass_sigma,self.lidar_sigma=float(gps_sigma),math.radians(compass_sigma_deg),float(lidar_sigma)
        self.world_axis_prior=bool(world_axis_prior)
        self.plane_mad_limit=float(plane_mad_limit)
        self.maximum_line_angle=math.radians(maximum_line_angle_deg)
        self.maximum_line_normal_spread=float(maximum_line_normal_spread)
        self.maximum_observed_axis_bias=math.radians(maximum_observed_axis_bias_deg)
        self.lines = deque(maxlen=768)
        # Compact scan blocks preserve all free-ray counterevidence, including
        # evidence seen before the positive four-side model was confirmed.
        self.ray_blocks = []
        self._audit_cursor = 0
        self._audit_model = None
        self.seen = set()
        self.gap_votes = {}
        self.confirmed_gaps = []
        self.hypothesis = None
        self.reason = 'no line evidence'

    def observe(self, lines, *, step, source=0, origin=None, free_endpoints=None):
        key = (int(source),int(step))
        if key in self.seen:
            return
        self.seen.add(key)
        for line in lines:
            endpoints = np.asarray(line[:2],float)
            if endpoints.shape != (2,2) or not np.isfinite(endpoints).all():
                continue
            if np.linalg.norm(endpoints[1]-endpoints[0]) >= 60:
                self.lines.append((key,endpoints.copy()))
        if origin is not None and free_endpoints is not None:
            origin,ends = np.asarray(origin,float),np.asarray(free_endpoints,float)
            if origin.shape == (2,) and ends.ndim == 2 and ends.shape[1] == 2:
                ends=ends[np.isfinite(ends).all(axis=1)]
                if len(ends):
                    self.ray_blocks.append((key,origin.astype(np.float32),ends.astype(np.float32)))
        new_hypothesis = self._fit()
        if new_hypothesis is not None:
            self.hypothesis = new_hypothesis
        elif self.hypothesis is not None:
            self.reason = 'retained confirmed frame while the current line window is incomplete'
        if self.hypothesis is not None:
            self._audit_free_rays(self.hypothesis)
            self.hypothesis.closed = not bool(self.confirmed_gaps)

    @staticmethod
    def _basis(angle):
        return np.array([[math.cos(angle),math.sin(angle)],
                         [-math.sin(angle),math.cos(angle)]])

    def ingest_batch(self,records):
        """Fit once after provenance-preserving fusion, then audit all rays.

        Records are (source, step, world_lines, measured_origin, free_endpoints).
        Negative-only records are valid and do not need a positive long line.
        """
        for source,step,lines,origin,endpoints in records:
            key=(int(source),int(step))
            if key in self.seen:
                continue
            self.seen.add(key)
            for line in lines:
                points=np.asarray(line[:2],float)
                if points.shape==(2,2) and np.isfinite(points).all() and np.linalg.norm(points[1]-points[0])>=60:
                    self.lines.append((key,points.copy()))
            if origin is not None and endpoints is not None:
                origin,ends=np.asarray(origin,float),np.asarray(endpoints,float)
                if origin.shape==(2,) and ends.ndim==2 and ends.shape[1]==2:
                    ends=ends[np.isfinite(ends).all(axis=1)]
                    if len(ends):
                        self.ray_blocks.append((key,origin.astype(np.float32),ends.astype(np.float32)))
        self.hypothesis=self._fit()
        if self.hypothesis is not None:
            self._audit_free_rays(self.hypothesis,full=True)
            self.hypothesis.closed=not bool(self.confirmed_gaps)

    def _fit(self):
        if len(self.lines) < 4*self.min_scans:
            self.reason = 'insufficient repeated line evidence'
            return None
        endpoints = np.array([r[1] for r in self.lines])
        vectors = endpoints[:,1]-endpoints[:,0]
        lengths = np.linalg.norm(vectors,axis=1)
        angles = np.arctan2(vectors[:,1],vectors[:,0])
        # Fold all perpendicular direction families into one common axis.
        angle = math.atan2(float(np.sum(lengths*np.sin(4*angles))),
                           float(np.sum(lengths*np.cos(4*angles))))/4
        observed_angle=angle
        if self.world_axis_prior:
            if abs(observed_angle)>self.maximum_observed_axis_bias:
                self.reason='physical line directions do not support the public-axis hypothesis'
                return None
            angle=0.0
        elif abs(angle)>self.maximum_axis_tilt:
            self.reason='observed frame orientation is inconsistent with public arena axes'
            return None
        basis = self._basis(angle)
        coordinates = endpoints @ basis.T
        families = [[],[],[],[]]
        for index, points in enumerate(coordinates):
            vector = points[1]-points[0]
            direction = math.atan2(vector[1],vector[0])
            folded = (direction+math.pi/4)%(math.pi/2)-math.pi/4
            if abs(folded) > self.maximum_line_angle:
                continue
            vertical = abs(vector[1]) > abs(vector[0])
            normal_axis,along_axis = (0,1) if vertical else (1,0)
            if abs(points[1,normal_axis]-points[0,normal_axis])>self.maximum_line_normal_spread:
                continue
            midpoint = float(points[:,normal_axis].mean())
            side = normal_axis*2 + int(midpoint>=0)
            expected_half = (self.width if normal_axis==0 else self.height)/2
            # A physical frame side lies near the public coordinate limit.
            # This is a classification guard, not the plane used for rendering.
            if abs(abs(midpoint)-expected_half) > self.plane_coordinate_guard:
                continue
            families[side].append((self.lines[index][0],midpoint,
                float(points[:,along_axis].min()),float(points[:,along_axis].max()),float(lengths[index])))
        planes,spans,counts,fractions,mads = [],[],[],[],[]
        for family in families:
            keys = {r[0] for r in family}
            if len(keys) < self.min_scans:
                self.reason = 'a physical side is not independently confirmed'
                return None
            plane = _weighted_median([r[1] for r in family],[r[4] for r in family])
            mad=_weighted_median([abs(r[1]-plane) for r in family],[r[4] for r in family])
            if mad>self.plane_mad_limit:
                self.reason='physical side has excessive normal-plane dispersion'
                return None
            mads.append(mad)
            agreeing = [r for r in family if abs(r[1]-plane)<=8]
            keys = {r[0] for r in agreeing}
            if len(keys) < self.min_scans:
                self.reason = 'side plane estimates are inconsistent'
                return None
            intervals = _merge_intervals([(r[2],r[3]) for r in agreeing])
            planes.append(plane);spans.append(intervals);counts.append(len(keys))
        left,right,bottom,top = planes
        if any(abs(abs(p)-size/2)>self.plane_coordinate_guard
               for p,size in zip(planes,[self.width,self.width,self.height,self.height])):
            self.reason='fitted physical planes are inconsistent with public coordinate limits'
            return None
        extent = np.array([right-left,top-bottom])
        public = np.array([self.width,self.height])
        if np.any(extent < self.minimum_extent*public) or np.any(extent>1.03*public):
            self.reason = 'four lines fit an interior rectangle, not the arena frame'
            return None
        if abs((left+right)/2)>.04*self.width or abs((bottom+top)/2)>.04*self.height:
            self.reason = 'rectangle is inconsistent with public arena coordinates'
            return None
        for side, intervals in enumerate(spans):
            low,high = (bottom,top) if side<2 else (left,right)
            covered = sum(max(0,min(b,high)-max(a,low)) for a,b in intervals)
            fraction = covered/(high-low)
            fractions.append(fraction)
            if fraction<self.minimum_span:
                self.reason = 'a side has too little actually observed span'
                return None
            if ((intervals[0][0]-low)/(high-low)>self.maximum_corner_extension or
                    (high-intervals[-1][1])/(high-low)>self.maximum_corner_extension):
                self.reason = 'unobserved corner extension is too long'
                return None
        corners = np.array([[left,bottom],[right,bottom],[right,top],[left,top]]) @ basis
        self.reason = 'four observed sides support a rectangular frame hypothesis'
        return FrameHypothesis(angle,tuple(planes),tuple(spans),tuple(counts),tuple(fractions),corners,
                               plane_mads=tuple(mads),observed_axis_bias=observed_angle)

    def _audit_free_rays(self,hypothesis,full=False):
        if not self.ray_blocks:
            return
        basis = self._basis(hypothesis.angle)
        left,right,bottom,top = hypothesis.planes
        model=np.r_[hypothesis.angle,hypothesis.planes]
        changed=(self._audit_model is None or
                 abs(model[0]-self._audit_model[0])>math.radians(.5) or
                 np.max(np.abs(model[1:]-self._audit_model[1:]))>3)
        start=0 if full or changed else self._audit_cursor
        records=self.ray_blocks[start:]
        self._audit_cursor=len(self.ray_blocks);self._audit_model=model
        if not records:
            return
        counts=[len(r[2]) for r in records]
        q0=np.repeat(np.asarray([r[1] for r in records]),counts,axis=0) @ basis.T
        q1=np.concatenate([r[2] for r in records],axis=0) @ basis.T
        record_index=np.repeat(np.arange(len(records)),counts)
        for side,plane in enumerate(hypothesis.planes):
            axis,sign = (0,-1) if side==0 else (0,1) if side==1 else (1,-1) if side==2 else (1,1)
            delta=q1[:,axis]-q0[:,axis]
            displacement=q1-q0
            ranges=np.linalg.norm(displacement,axis=1)
            radial_normal=np.divide(delta,ranges,out=np.zeros_like(delta),where=ranges>0)
            # A penetration has to exceed sensor uncertainty in the plane's
            # normal direction; long oblique rays amplify compass noise.
            normal_sigma=np.sqrt(self.gps_sigma**2+
                (self.lidar_sigma*radial_normal)**2+
                (self.compass_sigma*displacement[:,1-axis])**2)
            required=self.free_penetration+self.contradiction_sigma*normal_sigma
            amount=np.divide(plane-q0[:,axis],delta,out=np.full(len(delta),-1.),where=np.abs(delta)>1e-6)
            along=q0[:,1-axis]+amount*(q1[:,1-axis]-q0[:,1-axis])
            low,high=(bottom,top) if axis==0 else (left,right)
            good=((sign*(q0[:,axis]-plane)<=-8)&
                  (sign*(q1[:,axis]-plane)>=required)&
                  (amount>0)&(amount<1)&(along>=low)&(along<=high))
            # Only genuine penetration candidates reach the small Python vote
            # loop; ordinary closed-wall scans are handled by vectorized masks.
            for index in np.flatnonzero(good):
                key=records[record_index[index]][0]
                bucket=int(math.floor(along[index]/8))
                votes = self.gap_votes.setdefault((side,bucket),set())
                votes.add(key)
                if len(votes)>=self.opening_scans and (side,bucket) not in self.confirmed_gaps:
                    self.confirmed_gaps.append((side,bucket))

    def render(self, base=None):
        grid = np.zeros((self.height,self.width),np.uint8) if base is None else np.asarray(base,np.uint8).copy()
        hypothesis = self.hypothesis
        if hypothesis is None:
            return grid
        # Re-evaluate the entire preserved ray history before any inferred
        # geometry is submitted. The observer usually audits only new blocks.
        self._audit_free_rays(hypothesis,full=True)
        hypothesis.closed=not bool(self.confirmed_gaps)
        pixels = np.column_stack((hypothesis.corners[:,0]+self.width/2,
                                  self.height/2-hypothesis.corners[:,1])).round().astype(int)
        cv2.polylines(grid,[pixels],True,1,self.wall_width)
        basis = self._basis(hypothesis.angle)
        for side,bucket in self.confirmed_gaps:
            plane = hypothesis.planes[side]
            along_low,along_high = bucket*8-12,(bucket+1)*8+12
            pad = self.wall_width+10
            points = (np.array([[plane-pad,along_low],[plane+pad,along_low],
                                [plane+pad,along_high],[plane-pad,along_high]]) if side<2 else
                      np.array([[along_low,plane-pad],[along_high,plane-pad],
                                [along_high,plane+pad],[along_low,plane+pad]])) @ basis
            gap_pixels = np.column_stack((points[:,0]+self.width/2,
                                           self.height/2-points[:,1])).round().astype(int)
            cv2.fillPoly(grid,[gap_pixels],0)
        return grid

    def diagnostics(self):
        h=self.hypothesis
        return {'accepted':h is not None,'reason':self.reason,
                'closed':False if h is None else h.closed,
                'confirmed_openings':list(self.confirmed_gaps),
                'observed_side_fractions':None if h is None else h.support_fractions,
                'independent_side_scans':None if h is None else h.independent_scans,
                'plane_mads':None if h is None else h.plane_mads,
                'axis_source':'public arena structural hypothesis' if self.world_axis_prior else 'observed line directions',
                'observed_axis_bias':None if h is None else h.observed_axis_bias,
                'inferred_planes':None if h is None else h.planes,
                'inferred_angle':None if h is None else h.angle}
