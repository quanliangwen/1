"""Share measured disposal surfaces and avoid losing placements in that zone."""
import math
import cv2
import numpy as np


class CentreSafetyMixin:
    CLEAR_NONWALL_HITS = False
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.centre_records={}
        self.centre_surface_records={}

    def define_message_for_all(self):
        message=super().define_message_for_all()
        message['centres']=dict(self.centre_records)
        message['centre_surfaces']=dict(self.centre_surface_records)
        return message

    def _messages(self):
        super()._messages()
        step,own=int(self.elapsed_timestep),int(self.identifier or 0)
        points=[]
        for obj in self.semantic_values() or ():
            if getattr(getattr(obj,'entity_type',None),'name','')=='DISPOSAL_CENTER':
                angle=self.heading+float(obj.angle)
                point=self.pose+float(obj.distance)*np.array([math.cos(angle),math.sin(angle)])
                if np.isfinite(point).all(): points.append(point)
        if points:
            estimate=np.median(points,axis=0)
            self.centre_records[own]=(step,estimate.copy())
            previous=self.centre_surface_records.get(own,(-1,[]))[1]
            cloud=np.asarray(list(previous)+points,float)[-160:]
            self.centre_surface_records[own]=(step,cloud.copy())
        for _,message in self.communicator.received_messages:
            if not isinstance(message,dict): continue
            for field,target in (('centres',self.centre_records),('centre_surfaces',self.centre_surface_records)):
                for peer,record in message.get(field,{}).items():
                    if record[0]>target.get(peer,(-1,))[0]: target[peer]=record
        if self.CLEAR_NONWALL_HITS and step%20==0:
            layer=np.zeros(self.memory.hit_shape,np.uint8)
            for _,cloud in self.centre_surface_records.values():
                for x,y in cloud:
                    col=int(round((x+self.memory.width/2)/self.memory.FINE))
                    row=int(round((self.memory.height/2-y)/self.memory.FINE))
                    cv2.circle(layer,(col,row),max(1,int(10/self.memory.FINE)),1,-1)
            # Public limits protect any observed frame evidence from deletion.
            band=max(1,int(12/self.memory.FINE))
            layer[:band]=0; layer[-band:]=0; layer[:,:band]=0; layer[:,-band:]=0
            self.memory.hits[layer>0]=0

    def _placement_forbidden(self):
        return [(np.asarray(point,float),120.0) for _,point in self.centre_records.values()]

    def _placement_allowed(self,step,semantic):
        if not super()._placement_allowed(step,semantic): return False
        if any(getattr(getattr(obj,'entity_type',None),'name','')=='DISPOSAL_CENTER'
               and float(obj.distance)<95 for obj in semantic or ()): return False
        return all(np.linalg.norm(self.pose-point)>=radius for point,radius in self._placement_forbidden())
