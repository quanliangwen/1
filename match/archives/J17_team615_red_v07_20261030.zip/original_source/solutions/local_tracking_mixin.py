"""Public-input convex local tracking. Server research only; no SDK mutation."""
import json
import time
from swarm_rescue.solutions.local_tracking_wrapper import track_command,record_final_command

class LocalQPTrackingMixin:
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self._qp_counts={}
        self._qp_cpu_seconds=0.
        self._qp_changed_logs=0
        self._qp_handoff_count=0
        self._qp_last_summary=-120
        self._qp_final_summary=False
        self._qp_cell_ack=False

    def _qp_emit(self,kind,**values):
        print('[LOCAL_TRACK_QP] '+json.dumps(dict(kind=kind,owner=int(self.identifier),
            step=int(self.elapsed_timestep),**values),sort_keys=True),flush=True)

    def _drive(self,distances,angles,semantic=()):
        parent_drive=super()._drive
        def legacy(cell_ack):
            previous=self._qp_cell_ack
            self._qp_cell_ack=bool(cell_ack)
            try:return parent_drive(distances,angles,semantic)
            finally:self._qp_cell_ack=previous
        begin=time.perf_counter()
        command,audit=track_command(self,distances,angles,semantic,legacy)
        self._qp_cpu_seconds+=time.perf_counter()-begin
        mode=audit['mode'];self._qp_counts[mode]=self._qp_counts.get(mode,0)+1
        self._qp_handoff_count+=int(audit.get('guarded_handoff',False))
        if (mode in ('TRACKING_QP','SAFETY_QP') or audit.get('guarded_handoff',False)) and self._qp_changed_logs<24:
            self._qp_changed_logs+=1
            self._qp_emit('ACTION',**audit)
        return command

    def control(self):
        command=super().control()
        # Parent control includes placement and rendezvous command overrides.
        # Store only this final public return value for the next-step inverse.
        record_final_command(self,command)
        step=int(self.elapsed_timestep)
        final=bool(self.submitted) and not self._qp_final_summary
        if step-self._qp_last_summary>=120 or final:
            self._qp_last_summary=step;self._qp_final_summary|=final
            self._qp_emit('SUMMARY',counts=dict(self._qp_counts),
                calls=sum(self._qp_counts.values()),guarded_handoffs=self._qp_handoff_count,
                wrapper_seconds=self._qp_cpu_seconds,inventory=int(self.carried_bombs_count()),final=final)
        return command
