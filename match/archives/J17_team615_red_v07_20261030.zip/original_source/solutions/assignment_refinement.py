"""Post-master exact assignment only; no selected-site or coverage changes."""
import math,time
import numpy as np
from swarm_rescue.solutions.minmax_assignment import minimum_makespan

def refine_assignment(data,selected,audit,domain):
    chosen=sorted(j for route in selected.values() for j in route)
    out=dict(audit)
    if not chosen:return selected,dict(out,minmax_status='NO_SELECTED_SITES',post_assignment_pair_queries=0)
    if len(chosen)!=len(set(chosen)):raise ValueError('Original plan duplicates selected sites')
    if len(data['owner_ids'])<=1:return selected,dict(out,minmax_status='ONE_OWNER_ALREADY_ROUTE_OPTIMAL',post_assignment_pair_queries=0)
    prefixes={}
    for row in domain['prefix_accounting']:
        distance=row['distance']
        if distance is None or not math.isfinite(distance) or distance<0:
            return selected,dict(out,minmax_status='PREFIX_UNCERTIFIED',post_assignment_pair_queries=0)
        prefixes[int(row['owner'])]=float(distance)
    oldcosts=dict(audit['route_costs'])
    before=max(prefixes.get(i,0.)+float(oldcosts[str(i)]) for i in data['owner_ids'])
    begin=time.perf_counter()
    refined,costs,value,certificate=minimum_makespan(chosen,data['owner_ids'],data['inventories'],data['start_costs'],
        data['between'],data['budgets'],prefixes)
    elapsed=time.perf_counter()-begin
    if refined is None:raise RuntimeError('Original selected sites failed equivalent minmax feasibility')
    if value>before+1e-8:raise RuntimeError('Minimum makespan is worse than certified original assignment')
    if sorted(j for route in refined.values() for j in route)!=chosen:raise RuntimeError('Assignment changed selected sites')
    for i,route in refined.items():
        if len(route)>data['inventories'][i] or costs[str(i)]>data['budgets'][i]+1e-8:raise RuntimeError('Refined assignment exceeds original budget/capacity')
    out.update(minmax_status='EXACT_FIXED_SITE_MINMAX',minmax_before=before,minmax_after=value,
        minmax_strict_improvement=bool(value<before-1e-8),minmax_seconds=elapsed,
        original_route_costs=oldcosts,route_costs=costs,post_assignment_pair_queries=certificate['pair_queries'],
        minmax_transitions=certificate['transitions'],
        minmax_inputs=dict(selected_indices=chosen,selected_points=data['points'][chosen].tolist(),
            owner_order=data['owner_ids'],inventories=data['inventories'],budgets={str(i):float(v) if math.isfinite(v) else None for i,v in data['budgets'].items()},
            prefixes=prefixes,start_costs={str(i):[float(data['start_costs'][i][j]) if math.isfinite(float(data['start_costs'][i][j])) else None for j in chosen] for i in data['owner_ids']},
            queried_pairs=certificate['queried_pair_costs'],original_assignment={str(i):list(route) for i,route in selected.items()},refined_assignment={str(i):list(route) for i,route in refined.items()}),
        minmax_scope='Exact selected-site known-graph placement makespan including certified fixed prefixes; excludes return-to-rally, dynamic interactions and uncertain physical speeds. Original coverage/cardinality objective and solver gap unchanged.')
    return refined,out
