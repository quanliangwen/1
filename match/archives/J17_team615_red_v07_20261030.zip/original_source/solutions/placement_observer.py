"""Own public-state placement request/ack observer; no policy changes."""
import json
import math
import numpy as np


class PlacementObserverMixin:
    def __init__(self, **kwargs):
        self._pg_counts={};self._pg_prints=0;self._pg_last=-1000;self._pg_pose_last=-1000
        self._pg_inside=False;self._pg_allowed=None
        super().__init__(**kwargs)

    def _pg_emit(self,event,**fields):
        self._pg_counts[event]=self._pg_counts.get(event,0)+1
        if self._pg_prints>=400 and event!='FINAL_GATE_SUMMARY':return
        self._pg_prints+=1
        print('[PLACEMENT_GATE] '+json.dumps(dict(event=event,owner=int(self.identifier or 0),
            step=int(self.elapsed_timestep),wall=float(self.elapsed_walltime),**fields),allow_nan=False),flush=True)

    def _pg_position(self):
        point=lambda p:None if p is None else np.asarray(p,float).tolist()
        pose=getattr(self,'pose',None);goal=getattr(self,'placement_goal',None)
        return dict(pose=point(pose),placement_goal=point(goal),
            assignment_goal=point(getattr(self,'assignment_goal',None)),
            distance=None if pose is None or goal is None else float(np.linalg.norm(pose-goal)),
            waypoint=point(self.waypoints[0]) if getattr(self,'waypoints',None) else None,
            assignment_since=int(getattr(self,'assignment_since',-1)))

    def _placement_allowed(self,step,semantic):
        result=super()._placement_allowed(step,semantic)
        if self._pg_inside:
            self._pg_allowed=bool(result)
        return result

    def _maybe_place(self,command,step,semantic):
        inventory=int(self.carried_bombs_count())
        pending_before=getattr(self,'pending_drop',None)
        position=self._pg_position()
        self._pg_inside=True;self._pg_allowed=None
        try:result=super()._maybe_place(command,step,semantic)
        finally:self._pg_inside=False
        if pending_before is None and getattr(self,'pending_drop',None) is not None:
            reason='REQUESTED'
        elif getattr(self,'submitted',False):reason='ALREADY_SUBMITTED'
        elif position['pose'] is None:reason='NO_POSE'
        elif inventory<=0:reason='NO_INVENTORY'
        elif pending_before is not None:reason='AWAIT_PREVIOUS_REQUEST'
        elif step-self.last_attempt_step<8:reason='RETRY_INTERVAL'
        elif position['placement_goal'] is None:reason='NO_PLACEMENT_GOAL'
        elif position['distance']>self.placement_arrival_radius:reason='ESTIMATED_NOT_ARRIVED'
        elif self._pg_allowed is False:reason='PUBLIC_SAFETY_GATE'
        else:reason='OTHER_PARENT_BRANCH'
        self._pg_counts['branch_'+reason]=self._pg_counts.get('branch_'+reason,0)+1
        if reason=='REQUESTED' or (inventory>0 and step-self._pg_last>=24):
            self._pg_last=int(step)
            centers=[float(o.distance) for o in semantic or ()
                     if getattr(getattr(o,'entity_type',None),'name','')=='DISPOSAL_CENTER'
                     and math.isfinite(float(o.distance))]
            self._pg_emit('PLACE_DECISION',reason=reason,inventory=inventory,
                public_allowed=self._pg_allowed,semantic_center_min=min(centers,default=None),
                command={k:float(command.get(k,0)) for k in ['forward','lateral','rotation','grasper','place_bomb']},
                **position)
        return result

    def _sync_placement(self,step):
        pending=getattr(self,'pending_drop',None)
        inventory=int(self.carried_bombs_count())
        result=super()._sync_placement(step)
        if pending is not None and (inventory<pending[0] or step>pending[2]):
            self._pg_emit('REQUEST_ACK',outcome='INVENTORY_DECREASED' if inventory<pending[0] else 'NO_INVENTORY_DECREASE',
                inventory_before=int(pending[0]),inventory_now=inventory,request_step=int(pending[2]),
                request_pose=np.asarray(pending[1],float).tolist())
        return result

    def control(self):
        result=super().control()
        step=int(self.elapsed_timestep)
        if step-self._pg_pose_last>=120:
            self._pg_pose_last=step
            self._pg_emit('OWN_POSE',inventory=int(self.carried_bombs_count()),**self._pg_position())
        return result

    def submit_exploration_map(self,image,*args,**kwargs):
        self._pg_emit('FINAL_GATE_SUMMARY',inventory=int(self.carried_bombs_count()),
            counts=self._pg_counts.copy(),**self._pg_position())
        return super().submit_exploration_map(image,*args,**kwargs)
