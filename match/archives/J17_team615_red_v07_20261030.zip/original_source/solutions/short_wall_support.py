"""Optional additive short-wall renderer using repeated sensor evidence only."""
import numpy as np
import cv2
from swarm_rescue.solutions.line_regularization import regularized_walls,render_with_observed_boundary


def add_short_wall_support(memory,base=None,*,mode='dense',density=3.0,
                           width=10,min_length=24,max_length=100,
                           min_base_distance=0):
    if base is None:
        base=render_with_observed_boundary(memory,line_width=18,keep_raw=False,
                 fit_band=10,duplicate_distance=8,covariance_limit=30,
                 boundary_hit_threshold=1,boundary_bin_evidence=1)
    base=np.asarray(base,np.uint8).copy()
    if mode in ('dense','box_dense'):
        support=cv2.GaussianBlur(memory.hits.astype(np.float32),(0,0),1.0)
        layer=(support>=density).astype(np.uint8)
        # Strong repeated local endpoint support is useful for box corners and
        # short faces that fail long-line extraction. This preserves the base.
        layer=cv2.dilate(layer,np.ones((3,3),np.uint8))
        if mode=='box_dense':
            # Admit compact 2D corner/box-shaped support, reject long thin
            # wall clouds. Closing is only for component classification; the
            # returned addition still consists of actually measured support.
            connected=cv2.morphologyEx(layer,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8))
            count,labels,stats,_=cv2.connectedComponentsWithStats(connected)
            accepted=np.zeros(count,bool)
            for index in range(1,count):
                w=stats[index,cv2.CC_STAT_WIDTH]*memory.FINE
                h=stats[index,cv2.CC_STAT_HEIGHT]*memory.FINE
                if min(w,h)>=24 and max(w,h)<=240 and max(w,h)/min(w,h)<=4:
                    accepted[index]=True
            layer &= accepted[labels].astype(np.uint8)
    elif mode=='short_lines':
        layer=regularized_walls(memory.hits,memory.FINE,width,False,
                 fit_band=6,duplicate_distance=4,covariance_limit=12,
                 min_length_pixels=min_length,max_length_pixels=max_length,
                 min_support_cells=12,hough_votes=12,anisotropy_ratio=10)
    else:
        raise ValueError(mode)
    pixels=np.repeat(np.repeat(layer,memory.FINE,axis=0),memory.FINE,axis=1)
    pixels=pixels[:memory.height,:memory.width]
    if min_base_distance>0:
        distance=cv2.distanceTransform(1-(base>0).astype(np.uint8),cv2.DIST_L2,cv2.DIST_MASK_PRECISE)
        pixels[distance<min_base_distance]=0
    return np.maximum(base,pixels)
