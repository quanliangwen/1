"""Convex passable zone geometry inferred solely from semantic surface returns."""
import cv2
import numpy as np

from swarm_rescue.solutions.centre_safety import CentreSafetyMixin
from swarm_rescue.solutions.semantic_navigation import refresh_semantic_navigation


class CentreGeometryMixin(CentreSafetyMixin):
    def _messages(self):
        super()._messages()
        step=int(self.elapsed_timestep)
        if step-getattr(self,'_centre_geometry_step',-100)<20: return
        self._centre_geometry_step=step
        clouds=[np.asarray(cloud,float) for _,cloud in self.centre_surface_records.values() if len(cloud)]
        if not clouds:
            self._centre_zone_mask=None
            return
        points=np.concatenate(clouds)
        cells=np.column_stack(((self.memory.height/2-points[:,1])/self.memory.CELL,
                               (points[:,0]+self.memory.width/2)/self.memory.CELL))
        hull=cv2.convexHull(cells[:,::-1].astype(np.float32)).round().astype(np.int32)
        raw=np.zeros(self.memory.shape,np.uint8)
        if len(hull)>=3: cv2.fillConvexPoly(raw,hull,1)
        # Semantic disposal entities are traversable; observed convex interior
        # can connect to its measured boundary. Real wall clearance still wins.
        self.memory.free[raw>0]=True
        self._centre_zone_mask=cv2.dilate(raw,np.ones((5,5),np.uint8)).astype(bool)
        refresh_semantic_navigation(self,points,step)
        if self.CLEAR_NONWALL_HITS:
            negative=np.zeros(self.memory.hit_shape,np.uint8)
            for x,y in points:
                col=int(round((x+self.memory.width/2)/self.memory.FINE))
                row=int(round((self.memory.height/2-y)/self.memory.FINE))
                cv2.circle(negative,(col,row),max(1,int(10/self.memory.FINE)),1,-1)
            band=max(1,int(12/self.memory.FINE))
            negative[:band]=0; negative[-band:]=0; negative[:,:band]=0; negative[:,-band:]=0
            self.memory.nonwall_mask=negative.astype(bool)
            self.memory.hits[self.memory.nonwall_mask]=0

    def _placement_forbidden(self):
        return []

    def _placement_forbidden_mask(self):
        return getattr(self,'_centre_zone_mask',None)

    def _placement_allowed(self,step,semantic):
        # Keep bomb spacing but replace the broad surface-centered 120px disks
        # with the measured convex zone and a physical-clearance margin.
        if not super(CentreSafetyMixin,self)._placement_allowed(step,semantic): return False
        if any(getattr(getattr(obj,'entity_type',None),'name','')=='DISPOSAL_CENTER'
               and float(obj.distance)<32 for obj in semantic or ()): return False
        mask=self._placement_forbidden_mask()
        return mask is None or not mask[self.memory.world_to_cell(self.pose)]
