"""Finite file-only completion helper; starts no games and uploads nothing."""
from pathlib import Path
import datetime,json,os,subprocess,sys,time,traceback
P=Path(__file__).resolve().parent
F=P.parent/'swarm-eod-literature-analysis/F107_J17_portable_release_20261030'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
save=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert not (P/'FILE_FINALIZER_RUN_ONCE.json').exists()
save(P/'FILE_FINALIZER_RUN_ONCE.json',dict(pid=os.getpid(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),starts_native_games=False,uploads_to_official_website=False))
launch=read(F/'WINDOWS_COLLECTOR_LAUNCH.json')
end=datetime.datetime.fromisoformat(launch['utc'].replace('Z','+00:00'))+datetime.timedelta(hours=14)
try:
    while datetime.datetime.now(datetime.timezone.utc)<end:
        q=F/'LOCAL_COLLECTOR_RESULT.json'
        if q.exists():
            state=read(q)
            if state['status']!='COMPLETE':raise RuntimeError('Collector failed: '+str(state))
            audit=read(F/'CAMPAIGN_CLIENT_REVIEW.json')
            if audit['status']!='PASS' or audit['native_failure']:
                raise RuntimeError('Native campaign failed; no release')
            if not any(g['group']=='J17P_FIVE' and g['maps']==5 for g in audit['groups']):
                raise RuntimeError('Complete five-map validation missing; no release')
            with (P/'audit/FILE_FINALIZER.log').open('x',encoding='utf-8') as log:
                result=subprocess.run([sys.executable,str(P/'finalize_release.py')],cwd=P,stdout=log,stderr=subprocess.STDOUT)
            if result.returncode:raise RuntimeError('Final release checks failed; see audit/FILE_FINALIZER.log; no retry')
            manifest=read(P/'DELIVERY_MANIFEST.json')
            assert manifest['status']=='PASS_RELEASED_LOCAL_NOT_UPLOADED'
            save(P/'FILE_FINALIZER_RESULT.json',dict(status='PASS_ARTIFACTS_COMPLETE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),zip=manifest['zip'],zip_sha256=manifest['zip_sha256'],starts_native_games=False,uploads_to_official_website=False))
            break
        time.sleep(15)
    else:raise TimeoutError('Original finite 14h collection window expired; no release')
except Exception:
    save(P/'FILE_FINALIZER_RESULT.json',dict(status='BLOCKED_NOT_RELEASED',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),error=traceback.format_exc(),starts_native_games=False,uploads_to_official_website=False))
    raise
