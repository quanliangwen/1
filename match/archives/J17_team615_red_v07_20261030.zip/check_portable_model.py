from pathlib import Path
import hashlib,importlib.util,itertools,json,math,sys,time
import numpy as np
R=Path('/home/junhao/quan/parallel_test_solver/match')
H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
F=H/'J17_v07_release_validation_20261030'
sys.path.insert(0,str(F/'workspace/src'))
from swarm_rescue.solutions.exact_layout_decomposition import solve_layout
spec=importlib.util.spec_from_file_location('original_J17_model',H/'F85_public_boundary_submission_pilot_20261030/J17/source/exact_layout_decomposition.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)

def brute(d):
    n=len(d['points']);best=-1.;best_sites=None
    def alloc(selected):
        if not selected:return True
        owners=d['owner_ids']
        for choices in itertools.product(owners,repeat=len(selected)):
            valid=True
            for owner in owners:
                js=[j for j,i in zip(selected,choices) if i==owner]
                if len(js)>d['inventories'][owner]:valid=False;break
                if not js:continue
                cost=min(d['start_costs'][owner][p[0]]+sum(d['between'][p[k],p[k+1]] for k in range(len(p)-1)) for p in itertools.permutations(js))
                if cost>d['budgets'][owner]+1e-8:valid=False;break
            if valid:return True
        return False
    for bits in range(1<<n):
        js=[j for j in range(n) if bits&(1<<j)]
        if len(js)>sum(d['inventories'].values()):continue
        if any(np.linalg.norm(d['points'][j]-d['points'][k])<d['separation']-1e-8 for j,k in itertools.combinations(js,2)):continue
        if not alloc(js):continue
        value=(float(d['weights'].sum())+1)*len(js)+(float(d['weights'][np.any(d['cover'][js],axis=0)].sum()) if js else 0)
        if value>best:best,best_sites=value,js
    return best,best_sites

begin=time.perf_counter();rng=np.random.default_rng(615);rows=[]
for k in range(40):
    n=3+k%5;e=2+k%4;owners=list(range(1+k%3))
    points=rng.integers(-4,5,size=(n,2)).astype(float)*10
    between=np.linalg.norm(points[:,None]-points[None,:],axis=2)
    origins=rng.integers(-4,5,size=(len(owners),2))*10
    d=dict(owner_ids=owners,inventories={i:1+(i+k)%2 for i in owners},
        start_costs={i:np.linalg.norm(points-origins[i],axis=1) for i in owners},between=between,
        points=points,cover=rng.random((n,e))<.45,weights=rng.integers(0,8,size=e).astype(float),
        budgets={i:float(rng.integers(0,110)) for i in owners},separation=float([0,12,24][k%3]))
    if k%9==0:d['start_costs'][0][0]=np.inf
    want,sites=brute(d)
    plan,audit=solve_layout(**d,time_limit=3.)
    original,oa=old.solve_layout(**d,time_limit=3.)
    assert audit['optimality_proven'] and audit['gap']==0,(k,audit)
    assert abs(audit['objective']-want)<1e-7,(k,audit,want)
    assert abs(oa['objective']-want)<1e-7,(k,oa,want)
    assert sum(map(len,plan.values()))==audit['selected_slots']
    rows.append(dict(case=k,objective=want,selected_slots=audit['selected_slots'],external_cuts=audit['lazy_route_cuts'],seconds=audit['elapsed']))
# An optimal relaxed selection which violates two-stop route budget must
# generate a route cut, rather than dropping a selected task after solving.
d=dict(owner_ids=[0],inventories={0:2},start_costs={0:np.array([10.,10.])},
    between=np.array([[0.,20.],[20.,0.]]),points=np.array([[-10.,0.],[10.,0.]]),
    cover=np.eye(2,dtype=bool),weights=np.ones(2),budgets={0:15.},separation=0.)
plan,a=solve_layout(**d,time_limit=3.)
assert a['lazy_route_cuts']>=1 and a['selected_slots']==1 and a['gap']==0
route_cut=dict(check='PASS',**a)
# Time zero may return only the certified empty plan and a nonzero bound.
plan,a=solve_layout(**d,time_limit=0.)
assert sum(map(len,plan.values()))==0 and not a['optimality_proven'] and a['bound']>0
# No gurobipy import occurs in the actual candidate path (original comparison
# above did import it separately). A license-size-free model exceeds 2000.
n=2101
large=dict(owner_ids=[0,1],inventories={0:2,1:2},start_costs={i:np.ones(n) for i in [0,1]},
    between=lambda j,k:0. if j==k else 1.,points=np.c_[np.arange(n)*30.,np.zeros(n)],
    cover=np.ones((n,1),bool),weights=np.array([1.]),budgets={0:10.,1:10.},separation=24.)
plan,a=solve_layout(**large,time_limit=3.)
assert a['variables']>2000 and a['selected_slots']==4 and a['gap']==0,a
out=dict(status='PASS',independent_brute_cases=40,gurobi_comparison_cases=40,
    route_exclusion_case=route_cut,time_zero_certified_empty='PASS',
    size_limited_license_boundary_case=dict(variables=a['variables'],constraints=a['constraints'],slots=a['selected_slots'],seconds=a['elapsed']),
    cases=rows,total_seconds=time.perf_counter()-begin,native_games=0)
build=json.loads((F/'BUILD.json').read_text())
out.update(submission_zip_sha256=build['zip_sha256'],payload_files_sha256=build['source_files'])
(F/'MODEL_EQUIVALENCE_CHECK.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['cases','route_exclusion_case']}))
