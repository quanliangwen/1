"""Fail-closed release assembly after actual J17 portable native validation."""
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,sys,zipfile
P=Path(__file__).resolve().parent;A=P/'audit'
F=P.parent/'swarm-eod-literature-analysis/F107_J17_portable_release_20261030'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
candidate=P/'candidate_v2/team615_red_v07.zip';digest=sha(candidate)
assert digest=='1716cecbd00b920ed4f5a4e16c9f00c95e6db82c32b57629c2689ea769b0448a'
with zipfile.ZipFile(candidate) as z:files={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
audit=read(F/'CAMPAIGN_CLIENT_REVIEW.json')
assert audit['status']=='PASS' and audit['native_failure'] is False
assert read(F/'LOCAL_COLLECTOR_RESULT.json')['status']=='COMPLETE'
gate=read(F/'PILOT_GATE.json');assert gate['status']=='PASS'
groups={g['group']:g for g in audit['groups']}
assert set(groups)=={'J17P_DIAG','J17P_FIVE'}
five=groups['J17P_FIVE'];assert five['maps']==5 and len(five['rows'])==5
archive_proofs={}
for name in ['J17P_DIAG','J17P_FIVE']:
    q=read(F/name/'CLIENT_FIRST_RAW_REVIEW.json');assert q['status']=='PASS'
    matrix=read(F/name/'RESULT.json');assert matrix['complete'] and matrix['source_hashes']['red']==files
    assert matrix['payload_unchanged'] is True
    archive_proofs[name]=dict(archive_sha256=q['archive_sha256'],files=q['files_first_verified'])
runs={name:read(A/('ABI_'+name+'.json')) for name in ['numpy1','numpy2','clean_sdk']}
assert all(r['status']=='PASS' and r['submission_zip_sha256']==digest and r['payload_files_sha256']==files for r in runs.values())
model=read(A/'MODEL_EQUIVALENCE_CHECK.json')
assert model['status']=='PASS' and model['submission_zip_sha256']==digest and model['payload_files_sha256']==files
official=read(A/'OFFICIAL_STATIC_CHECK.json')
assert official['status']=='PASS' and official['submission_zip_sha256']==digest==official['alias_sha256']
native=dict(status='PASS',submission_zip_sha256=digest,payload_files_sha256=files,
    pilot_gate='PASS',pilot_score=gate['score'],five_maps_complete=True,
    first_windows_raw_review='PASS',archives=archive_proofs,native_failure=False,
    five_map_mean=five['five_map_mean'],placed=five['placed'],expected=five['expected'],
    blue_disposed=five['blue_disposed'],blue_expected=sum(r['blue_expected'] for r in five['rows']),
    red_clock_hits=five['red_clock_hits'],blue_clock_hits=five['blue_clock_hits'],rows=five['rows'],
    original_J17_score_not_inherited=True)
direct=F/'DIRECT_START_AUTHORIZATION.json'
if direct.exists():
    auth=read(direct);resources=read(F/'DIRECT_START_RESOURCE_RECEIPT.json')
    assert auth['human_request']=='直接启动测试'
    native.update(evaluation_resource_scope='EXPLICIT_USER_CPU_AND_LOAD_GATE_OVERRIDE',
        resource_matched_to_original_J17=False,direct_start_authorization=auth,
        direct_start_resource_receipt=resources)
else:
    native.update(evaluation_resource_scope='ORIGINAL_RESOURCE_GATE',resource_matched_to_original_J17=True)
receipt=dict(status='PASS',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    dependency_profile='j17-portable-v07',submission_zip_sha256=digest,payload_files_sha256=files,
    source_parent_zip_sha256='652b59edbfba68aa5b163b2cbdc904ebecdbe75927073e3a59168013e725a839',
    team_number=615,sdk_source_revision='e2f022bb3832bae16bfb4e67fe8510f2b5baf586',
    abi_runs=runs,model_equivalence=model,native_validation=native,official_static_check=official,
    official_container_verified=False,official_online_submission_performed=False,
    environment_scope='Reused isolated numerical environments and a previously clean-installed SDK stack, as disclosed in each run. No official base image; no guarantee for a pre-corrupted website environment.')
proof=A/'RELEASE_ABI_RECEIPT.json';save(proof,receipt)
target=P/'team615_red_v07.zip';assert not target.exists(),'Do not overwrite a released file'
shutil.copyfile(candidate,target);assert sha(target)==digest
guard=P.parent/'swarm-submission-guard/check_submission_zip.py'
check=subprocess.run([sys.executable,str(guard),str(target),'--abi-receipt',str(proof),
    '--dependency-profile','j17-portable-v07','--output',str(A/'RELEASE_CHECK.json')],capture_output=True,text=True)
(A/'FINAL_GUARD.stdout.log').write_text(check.stdout,encoding='utf-8')
(A/'FINAL_GUARD.stderr.log').write_text(check.stderr,encoding='utf-8')
assert check.returncode==0,check.stdout+check.stderr
assert read(A/'RELEASE_CHECK.json')['status']=='PASS'
source=P/'J17_portable_v07_source.zip';assert not source.exists()
with zipfile.ZipFile(target) as src,zipfile.ZipFile(source,'x',compression=zipfile.ZIP_DEFLATED) as out:
    for n in src.namelist():
        dest=n if n in ['req.txt','team_info.yml','image_ref.txt'] else 'solutions/'+n
        out.writestr(dest,src.read(n))
framework='J17免许可提交版采用“分布式感知与执行、临时协调机统一优化”的滚动规划框架：各无人机独立建图、估计位置，并通过实际通信共享地图、库存和投放记录；协调机用混合整数规划选择墙面覆盖较好的布点，再用精确动态规划核验任务分配和访问路线，同时满足库存、间距和执行预算；每架无人机通过Dijkstra路径与局部QP控制完成移动，以真实库存下降确认投放，最后通过完成证书和有界地图交换提交地图。本提交版以无需许可证的SciPy/HiGHS替代原Gurobi，保留布点模型及其余感知、通信和控制模块；限时求解返回的是经验证的可行方案，不保证每次达到有限模型最优，更不代表全游戏全局最优。'
(P/'算法框架说明.txt').write_text(framework+'\n',encoding='utf-8')
lines=['J17免许可证比赛提交版V07','',
    '推荐上传：team615_red_v07.zip。源码包J17_portable_v07_source.zip供阅读，不上传源码包。',
    '队号：team_number为YAML整数615，保留原队名和队员。提交ZIP根目录平铺算法、辅助源码、req.txt和team_info.yml，无SDK/地图/历史结果/虚拟环境/NumPy等二进制库或许可证凭据。',
    '依赖：numpy>=1.24.4；opencv-contrib-python>=4.10.0.84；scipy==1.17.1。不单独覆盖Pandas，不依赖Gurobi或商业许可。',
    '实际ZIP已通过NumPy1.26.4和2.2.6的完整数值/SDK/入口检查，以及既有干净SDK的NumPy2.4.6组合检查，安装预演无替换项；环境复用/共享边界详audit/RELEASE_ABI_RECEIPT.json，不能称为官网容器验证。',
    '模型检查：40个独立穷举和原Gurobi模型对照、路线加割、零预算可行空方案、大于2000变量的禁止Gurobi导入实解均通过。',
    f'适配版单图Map01检查：{gate["score"]:.8f}；独立五图均分：{five["five_map_mean"]:.8f}；投放{five["placed"]}/{five["expected"]}；蓝队清除{native["blue_disposed"]}/{native["blue_expected"]}。原J17的77.85136510不是此适配版成绩。',
    '逐图 | 完整红分 | 实际投放 | BLUE清除 | RED墙钟hit | BLUE墙钟hit']
for r in five['rows']:lines.append(f'{r["map"]} | {r["score"]:.8f} | {r["placed"]}/{r["expected"]} | {r["blue_disposed"]}/{r["blue_expected"]} | {r["red_wall_hit"]} | {r["blue_wall_hit"]}')
lines+=['',framework,'',
    '官方SDK静态检查使用字节完全相同的team615_preliminary.zip审计副本，适配其旧文件名规则；真正交付文件名按用户赛事规范使用team615_red_v07.zip，并由独立发布检查器核验。静态检查对继承的19处print调用给出警告，不影响通过；为保持已测源码未删除这些诊断。',
    '尚未在官网容器或官网上传验证，不能保证平台复用损坏依赖环境时也绝不报错；如官网仍报ABI错误，应取得安装日志及实际模块路径，不再反复更换算法掩盖环境问题。',
    '提交ZIP SHA256：'+digest,'源码ZIP SHA256：'+sha(source)]
if direct.exists():
    lines+=['','本轮五图依用户“直接启动测试”的明确授权绕过CPU/负载等待门槛，仍保留内存/磁盘下限及单一调度。SDK、蓝队、算法、比赛时限、线程不变。原J17的77.8514来自原资源门槛，两组不是资源匹配或同随机条件对照，分差只能作为观察，不能归为纯求解器效应。']
(P/'提交说明与验证结果.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
manifest=dict(status='PASS_RELEASED_LOCAL_NOT_UPLOADED',zip=str(target),zip_sha256=digest,
    source_zip=str(source),source_zip_sha256=sha(source),native_validation=native,
    official_container_verified=False,final_guard=str(A/'RELEASE_CHECK.json'))
save(P/'DELIVERY_MANIFEST.json',manifest)
print(json.dumps(dict(status=manifest['status'],zip=str(target),sha256=digest,
    portable_five_map_mean=five['five_map_mean'],placed=five['placed'],expected=five['expected']),ensure_ascii=False))
