from pathlib import Path
import importlib.abc,importlib.metadata as md,json,sys,hashlib,subprocess,os
R=Path('/home/junhao/quan/parallel_test_solver/match');H=R/'solver_study/framework_screen_20261016/best87_independent_20261025'
F=H/'J17_v07_release_validation_20261030';label=sys.argv[1]
shared=R/'.venv/lib/python3.11/site-packages'
if label!='clean_sdk':sys.path.append(str(shared))
build=json.loads((F/'BUILD.json').read_text());W=Path(build['workspace'])
sys.path.insert(0,str(W/'src'))
class NoCommercialSolver(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname=='gurobipy' or fullname.startswith('gurobipy.'):
            raise ImportError('Release verification explicitly prohibits gurobipy')
sys.meta_path.insert(0,NoCommercialSolver())
import numpy as np,numpy.random.mtrand as mt,pandas as pd,cv2,scipy
from scipy.optimize import milp,Bounds
assert np.isfinite(np.random.RandomState(615).normal(size=128)).all()
assert pd.DataFrame({'a':[1.,2.,3.]}).a.sum()==6.
assert cv2.filter2D(np.ones((8,8),np.float32),-1,np.ones((3,3),np.float32)).shape==(8,8)
assert scipy.__version__=='1.17.1'
for n,h in build['source_files'].items():
    p=W/'req.txt' if n=='req.txt' else W/'src/swarm_rescue/solutions'/n
    assert hashlib.sha256(p.read_bytes()).hexdigest()==h,n
from swarm_rescue.launcher import Launcher
from swarm_rescue.simulation.reporting.stats_computation import StatsComputation
from swarm_rescue.simulation.reporting.team_info import TeamInfo
from swarm_rescue.solutions.my_drone_eval import MyDroneEval,drone_class_for_mode
from swarm_rescue.solutions.exact_layout_decomposition import solve_layout
assert type(TeamInfo().team_number) is int and TeamInfo().team_number==615
assert drone_class_for_mode('place') is MyDroneEval
n=2101
plan,proof=solve_layout([0,1],{0:2,1:2},{i:np.ones(n) for i in [0,1]},
    lambda j,k:0. if j==k else 1.,np.c_[np.arange(n)*30.,np.zeros(n)],
    np.ones((n,1),bool),np.ones(1),{0:10.,1:10.},24.,time_limit=3.)
assert proof['variables']==2102 and proof['selected_slots']==4 and proof['gap']==0
import pyglet
window=pyglet.window.Window(width=1,height=1,visible=False)
try:
    from swarm_rescue.maps.map_01 import Map01
    arena=Map01(drone_type=MyDroneEval,number_drones=5)
    assert len(arena.drones)==5 and len({id(d.memory.hits) for d in arena.drones})==5
finally:window.close()
assert not any(n=='gurobipy' or n.startswith('gurobipy.') for n in sys.modules)
foreign=[]
for name,m in list(sys.modules.items()):
    if name.startswith('swarm_rescue.solutions') and getattr(m,'__file__',None):
        p=Path(m.__file__);assert p.resolve().is_relative_to((W/'src/swarm_rescue/solutions').resolve())
        assert hashlib.sha256(p.read_bytes()).hexdigest()==build['source_files'][p.name]
        foreign.append(name)
report=F/('INSTALL_DRY_RUN_'+label+'.json')
code="import sys,runpy;"+('sys.path.append('+repr(str(shared))+');' if label!='clean_sdk' else '')+"sys.argv=['pip','install','--dry-run','--no-index','--report',"+repr(str(report))+",'-r',"+repr(str(W/'req.txt'))+"];runpy.run_module('pip',run_name='__main__')"
if label=='native_main':
    # The match interpreter has no pip module. Borrow only the read-only
    # installer implementation after its own packages for a no-install preview.
    helper=H/'submission_alns_v9_20261025T1532Z/dependency_venv/lib/python3.11/site-packages'
    code=code.replace('import sys,runpy;','import sys,runpy;sys.path.append('+repr(str(helper))+');')
dry=subprocess.run([sys.executable,'-I','-c',code],capture_output=True,text=True)
(F/('INSTALL_DRY_RUN_'+label+'.log')).write_text(dry.stdout+'\n'+dry.stderr)
assert dry.returncode==0,dry.stderr
install=json.loads(report.read_text()).get('install',[]);assert install==[],install
out=dict(status='PASS',dependency_profile='j17-portable-v07',label=label,
    submission_zip_sha256=build['zip_sha256'],payload_files_sha256=build['source_files'],
    python=sys.version,executable=sys.executable,sys_path=sys.path,
    distribution_versions={n:md.version(n) for n in ['numpy','pandas','opencv-contrib-python','scipy']},
    critical_module_paths={n:m.__file__ for n,m in [('numpy',np),('numpy.random.mtrand',mt),('pandas',pd),('cv2',cv2),('scipy',scipy)]},
    numeric_random_pandas_cv_operations='PASS',sdk_launcher_and_stats_import='PASS',
    controller_factory_import='PASS',all_payload_hashes_match=True,team_number=615,
    solver_real_solve='PASS',solver_no_license_and_import_block_test='PASS',
    solver_test_variables=proof['variables'],solver_test_constraints=proof['constraints'],
    five_independent_native_constructors='PASS',native_game_rounds=0,
    installation_dry_run=dict(status='PASS',planned_installations=[]),
    scope='Reused isolated numerical environment; NumPy/Pandas/OpenCV from its existing stack, with shared read-only SDK dependencies and SciPy for numpy1/numpy2. clean_sdk uses the entire previously clean-installed SDK environment without overlays. This is not the official container.',
    official_container_verified=False)
(F/('ABI_'+label+'.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['status','label','submission_zip_sha256','distribution_versions','solver_test_variables']}))
