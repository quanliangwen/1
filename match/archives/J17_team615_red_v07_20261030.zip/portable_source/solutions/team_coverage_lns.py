"""Exact finite-domain placement core; legacy public function name retained.

Portable J17 uses SciPy/HiGHS MILP and exact route certificates.
It is a coordinator-based solver, not a fully decentralized optimizer.
"""
import json
import time
import numpy as np
from swarm_rescue.solutions.exact_route_model import prepare_observed_domain
from swarm_rescue.solutions.exact_layout_decomposition import solve_layout
from swarm_rescue.solutions.small_inventory_exact import solve_small_inventory
from swarm_rescue.solutions.assignment_refinement import refine_assignment


def plan_team_coverage_lns(memory, agents, drops, radius, travel_budget=None,
        quality_tolerance=.92, forbidden_points=(), forbidden_mask=None,
        search_seed=None, deadline_pressure=0., reserved_prefixes=None):
    started = time.perf_counter()
    clean = {int(i): (np.asarray(p, float), int(count)) for i, (p, count) in agents.items()
             if p is not None and int(count) > 0 and np.asarray(p).shape == (2,)
             and np.isfinite(p).all()}
    if not clean:
        return {}
    data, domain = prepare_observed_domain(memory, clean, drops, radius,
        travel_budget, forbidden_points=forbidden_points, forbidden_mask=forbidden_mask,
        reserved_prefixes=reserved_prefixes, max_sites=None, eager_between=False)
    optimizer = solve_small_inventory if sum(data["inventories"].values()) <= 2 else solve_layout
    selected, audit = optimizer(**data, time_limit=2.)
    selected, audit = refine_assignment(data,selected,audit,domain)
    result = {i: [data['points'][j].copy() for j in js] for i, js in selected.items()}
    audit.update(domain_sites=domain['site_count'], domain_stride=domain['stride'],
                 prefix_accounting=domain['prefix_accounting'],
                 prepare_seconds=domain['preparation_elapsed'],
                 geometry_fit_passes=domain['geometry_fit_passes'],
                 geometry_fit_seconds=domain['geometry_fit_seconds'],
                 field_stats=domain['distance_field_stats'],
                 total_seconds=time.perf_counter()-started,
                 native_step=int(getattr(memory, 'step', 0)),
                 solver_scope='finite observed graph and proxy coverage; not global game optimum')
    memory.exact_layout_audit = audit
    print('[EXACT_LAYOUT] '+json.dumps(audit, sort_keys=True), flush=True)
    return result
