"""J17 observed-domain construction; no solver or commercial dependency.

Production prepare_observed_domain is unchanged from the tested J17.
Unused research-only Gurobi entry points are omitted from the release.
"""
import math
import time
import numpy as np


def prepare_observed_domain(memory, agents, drops, radius, travel_budget,
                            forbidden_points=(), forbidden_mask=None,
                            reserved_prefixes=None, max_sites=36, explicit_cells=None,
                            eager_between=True):
    """Read only own belief. explicit_cells is diagnostic-only and declared.

    Default domain: all allowed points on a fixed map-aligned coarse lattice;
    increase integer lattice stride until <=max_sites. No utility sorting.
    Actual original free observations are required, not just morphological fill.
    """
    from swarm_rescue.solutions.geometry_route_view import GeometryPlanningMemory
    from swarm_rescue.solutions.team_coverage import observed_wall_values, path_costs
    started = time.perf_counter()
    from swarm_rescue.solutions.shared_wall_layers import regularized_wall_layers
    from swarm_rescue.solutions.coverage_geometry import geometry_wall_values
    fit_started=time.perf_counter()
    layers=regularized_wall_layers(memory.hits,fine=memory.FINE,line_widths=(8,12),
        keep_raw=False,fit_band=10,duplicate_distance=8,covariance_limit=30)
    fit_seconds=time.perf_counter()-fit_started
    pm = GeometryPlanningMemory(memory,measured_layer=layers[8])
    prepared_values,prepared_solids=geometry_wall_values(pm,radius,return_solids=True,
        line_width=12,measured_layer=layers[12])
    pm._coverage_values_cache=(float(radius),prepared_values,prepared_solids)
    values, solids = observed_wall_values(pm, radius, return_solids=True)
    values = np.asarray(values, float).copy()
    if hasattr(memory, 'bearing_wall_values'):
        values = memory.bearing_wall_values(values)
    walkable = np.asarray(memory.free, bool) & pm.free & ~pm.blocked() & ~solids
    rr, cc = np.indices(pm.shape)
    xx = (cc+.5)*pm.CELL-pm.width/2
    yy = pm.height/2-(rr+.5)*pm.CELL
    allowed = walkable.copy()
    if forbidden_mask is not None:
        allowed &= ~np.asarray(forbidden_mask, bool)
    for p, exclusion in forbidden_points:
        allowed[(xx-p[0])**2+(yy-p[1])**2 < exclusion**2] = False
    separation = 40.+.71*pm.CELL
    for p in drops:
        squared = (xx-p[0])**2+(yy-p[1])**2
        values[squared <= radius**2] = 0
        allowed[squared < separation**2] = False
    cells = []
    stride = None
    if explicit_cells is not None:
        cells = sorted(set(tuple(int(x) for x in cell) for cell in explicit_cells))
        if (max_sites is not None and len(cells) > max_sites) or any(not allowed[cell] for cell in cells):
            raise ValueError('Invalid declared diagnostic domain')
    else:
        stride = 1
        while True:
            domain = allowed & (rr % stride == 0) & (cc % stride == 0)
            cells = [tuple(int(v) for v in cell) for cell in zip(*np.nonzero(domain))]
            if max_sites is None or len(cells) <= max_sites:
                break
            stride += 1
    points = np.asarray([pm.cell_to_world(cell) for cell in cells], float).reshape((-1, 2))
    positive = np.flatnonzero(values.ravel() > 0)
    weights = values.ravel()[positive]
    coordinates = np.column_stack((xx.ravel()[positive], yy.ravel()[positive]))
    cover = np.array([np.sum((coordinates-p)**2, axis=1) <= radius**2+1e-8
                      for p in points], bool).reshape((len(points), len(weights)))
    fields = {}
    field_stats = {'calls': 0, 'hits': 0, 'misses': 0}
    def field(cell):
        cell = tuple(cell)
        field_stats['calls'] += 1
        if cell not in fields:
            field_stats['misses'] += 1
            if len(fields) >= 64:
                fields.pop(next(iter(fields)))
            fields[cell] = path_costs(pm, walkable, cell)
        else:
            field_stats['hits'] += 1
        return fields[cell]
    owners = sorted(int(i) for i, (_, count) in agents.items() if int(count) > 0)
    inventories = {i: int(agents[i][1]) for i in owners}
    budgets = {i: float(travel_budget.get(i, 0) if isinstance(travel_budget, dict)
                        else math.inf if travel_budget is None else travel_budget) for i in owners}
    prefix_audit = []
    for i, (position, target) in (reserved_prefixes or {}).items():
        if i not in budgets:
            continue
        if not np.array_equal(np.asarray(agents[i][0]), np.asarray(target)):
            raise ValueError('Reserved target differs from suffix origin')
        source, goal = pm.world_to_cell(position), pm.world_to_cell(target)
        distance = float(field(source)[goal]) if walkable[source] and walkable[goal] else math.inf
        before = budgets[i]
        budgets[i] = max(0., before-distance) if math.isfinite(distance) else 0.
        prefix_audit.append(dict(owner=i, distance=distance if math.isfinite(distance) else None,
                                 budget_before=before, suffix_budget=budgets[i]))
    start_costs = {}
    for i in owners:
        source = pm.world_to_cell(agents[i][0])
        start_costs[i] = np.array([field(source)[cell] for cell in cells]) if walkable[source] else np.full(len(cells), math.inf)
    if eager_between:
        between = np.array([[field(a)[b] for b in cells] for a in cells], float).reshape((len(cells), len(cells)))
    else:
        between = lambda j, k: float(field(cells[j])[cells[k]])
    return dict(owner_ids=owners, inventories=inventories, start_costs=start_costs,
                between=between, points=points, cover=cover, weights=weights,
                budgets=budgets, separation=separation), dict(
                    stride=stride, site_count=len(cells), cells=[list(c) for c in cells],
                    domain='declared_explicit' if explicit_cells is not None else 'complete_fixed_lattice',
                    prefix_accounting=prefix_audit, distance_fields=len(fields),
                    distance_field_stats=field_stats,
                    preparation_elapsed=time.perf_counter()-started,
                    geometry_fit_passes=1,geometry_fit_seconds=fit_seconds,
                    known_free_only=True, exact_scope='finite sites and observed graph only')
