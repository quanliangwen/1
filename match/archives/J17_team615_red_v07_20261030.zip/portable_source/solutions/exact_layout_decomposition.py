"""Portable maximum coverage MILP + exact <=10-site route-allocation DP.

The master chooses sites; the subproblem certifies owner/route feasibility.
An infeasible selected set yields a valid monotone no-good cut. Optimality is
for the declared known-graph model, never the unknown complete game.
"""
import math
import time
from itertools import combinations
from swarm_rescue.solutions.reachability_capacity import reachability_capacity_rows
import numpy as np


def allocate_exact(selected, owner_ids, inventories, start_costs, between, budgets):
    selected = tuple(sorted(selected))
    target = (1 << len(selected))-1
    metric = between if callable(between) else lambda j, k: float(between[j, k])
    states = {0: ({}, {})}
    for owner in owner_ids:
        routes = [(0, [], 0.)]
        eligible = [p for p, j in enumerate(selected)
                    if 0 <= float(start_costs[owner][j]) <= budgets[owner]+1e-8
                    and math.isfinite(float(start_costs[owner][j]))]
        if inventories[owner] > 0:
            routes.extend((1 << p, [selected[p]], float(start_costs[owner][selected[p]])) for p in eligible)
        if inventories[owner] > 1:
            for p, q in combinations(eligible, 2):
                j, k = selected[p], selected[q]
                forward = float(start_costs[owner][j])+metric(j, k)
                reverse = float(start_costs[owner][k])+metric(k, j)
                cost = min(forward, reverse)
                if math.isnan(cost) or cost < 0:
                    raise ValueError('Invalid graph metric')
                if cost <= budgets[owner]+1e-8:
                    routes.append(((1 << p) | (1 << q),
                                   [j, k] if forward <= reverse else [k, j], cost))
        next_states = {}
        for mask, (assignments, costs) in states.items():
            for used, route, cost in routes:
                if used & mask:
                    continue
                combined = mask | used
                if combined not in next_states:
                    next_states[combined] = (dict(assignments, **{str(owner): route}),
                                             dict(costs, **{str(owner): cost}))
        states = next_states
    if target not in states:
        return None, None
    assignment, costs = states[target]
    return {i: assignment[str(i)] for i in owner_ids}, costs


def solve_layout(owner_ids, inventories, start_costs, between, points, cover,
                  weights, budgets, separation, time_limit=2.):
    """Same finite model, solved by license-free HiGHS with explicit route cuts.

    A valid route certificate is required before returning any nonempty plan.
    Time-limited results carry the retained feasible value and a valid upper
    bound; no rounding-only or uncertified master solution is executable.
    """
    import warnings
    import scipy
    from scipy.optimize import Bounds, LinearConstraint, milp
    from scipy.sparse import coo_matrix, vstack
    started = time.perf_counter()
    points = np.asarray(points, float)
    cover = np.asarray(cover, bool)
    weights = np.asarray(weights, float)
    n, e = len(points), len(weights)
    if points.shape != (n, 2) or not np.isfinite(points).all():
        raise ValueError('Invalid candidate geometry')
    if any(inventories[i] not in (0, 1, 2) or math.isnan(budgets[i])
           or budgets[i] < 0 for i in owner_ids):
        raise ValueError('Invalid two-stop inventory/budget')
    if cover.shape != (n, e) or np.any(weights < 0) or not np.isfinite(weights).all():
        raise ValueError('Invalid coverage matrix')
    if not math.isfinite(separation) or separation < 0 or not math.isfinite(time_limit) or time_limit < 0:
        raise ValueError('Invalid separation/solve budget')
    original_metric = between if callable(between) else lambda j, k: float(between[j, k])
    pairs, allocations, cut_keys = {}, {}, set()
    def metric(j, k):
        if (j, k) not in pairs:
            value = float(original_metric(j, k))
            if math.isnan(value) or value < 0:
                raise ValueError('Invalid graph distance')
            pairs[j, k] = value
        return pairs[j, k]
    def allocate(js):
        key = tuple(sorted(js))
        if key not in allocations:
            allocations[key] = allocate_exact(key, owner_ids, inventories,
                                              start_costs, metric, budgets)
        return allocations[key]
    capacity_rows, patterns = reachability_capacity_rows(
        owner_ids, inventories, start_costs, budgets, n)
    ub = np.ones(n+e)
    eligible = np.zeros(n, bool)
    for j in range(n):
        eligible[j] = any(inventories[i] and math.isfinite(float(start_costs[i][j]))
            and 0 <= float(start_costs[i][j]) <= budgets[i]+1e-8 for i in owner_ids)
    ub[:n] = eligible
    ri, ci, values, lower, upper = [], [], [], [], []
    def row(indices, coefficients, hi):
        index = len(upper)
        columns = list(indices)
        ri.extend([index]*len(columns));ci.extend(columns)
        values.extend(coefficients);lower.append(-np.inf);upper.append(float(hi))
    slots = sum(inventories.values())
    row(range(n), [1.]*n, slots)
    for subset, sites, capacity in capacity_rows:
        row(sites, [1.]*len(sites), capacity)
    buckets, conflicts = {}, []
    size = max(float(separation), 1e-9)
    for j, point in enumerate(points):
        bucket = tuple(math.floor(float(v)/size) for v in point)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for k in buckets.get((bucket[0]+dx, bucket[1]+dy), ()):
                    if np.linalg.norm(point-points[k]) < separation-1e-8:
                        row([j, k], [1., 1.], 1.)
                        conflicts.append((j, k))
        buckets.setdefault(bucket, []).append(j)
    for k in range(e):
        sites = np.flatnonzero(cover[:, k]).tolist()
        row(sites+[n+k], [-1.]*len(sites)+[1.], 0.)
    matrix = coo_matrix((np.asarray(values, float),
        (np.asarray(ri, np.int32), np.asarray(ci, np.int32))),
        shape=(len(upper), n+e)).tocsc()
    lower, upper = np.asarray(lower), np.asarray(upper)
    dominance = float(weights.sum())+1.
    objective = -np.r_[np.full(n, dominance), weights]
    integrality = np.r_[np.ones(n, np.int32), np.zeros(e, np.int32)]
    best, best_costs = allocate(())
    best_value = 0.
    bound = dominance*min(slots, int(eligible.sum()))+float(weights.sum())
    iterations = nodes = 0
    proven = False
    status, message = 1, 'Time budget exhausted before certified positive solution'
    optimization_started = time.perf_counter()
    deadline = optimization_started+float(time_limit)
    while n+e and time.perf_counter() < deadline:
        remaining = deadline-time.perf_counter()
        if remaining <= 0:
            break
        options = dict(disp=False, time_limit=remaining, mip_rel_gap=0.,
            mip_abs_gap=0., threads=1, random_seed=0, mip_heuristic_effort=0.)
        # SciPy forwards these documented HiGHS options. Suppress only its
        # forwarding notice, leaving numerical/option errors visible.
        with warnings.catch_warnings():
            warnings.filterwarnings('ignore', message='Unrecognized options detected:.*',
                                    category=RuntimeWarning)
            result = milp(objective, integrality=integrality,
                bounds=Bounds(np.zeros(n+e), ub),
                constraints=LinearConstraint(matrix, lower, upper), options=options)
        iterations += 1
        status, message = int(result.status), str(result.message)
        nodes += int(getattr(result, 'mip_node_count', 0) or 0)
        dual = getattr(result, 'mip_dual_bound', None)
        if dual is not None and math.isfinite(float(dual)):
            bound = min(bound, -float(dual))
        if status in (2, 3, 4):
            raise RuntimeError('Portable master failed despite feasible empty layout: '+message)
        if result.x is None:
            break
        x = np.asarray(result.x)
        if x.shape != (n+e,) or not np.isfinite(x).all() or np.any(np.abs(x[:n]-np.rint(x[:n])) > 1e-5):
            raise RuntimeError('Master returned nonintegral or invalid solution')
        chosen = tuple(np.flatnonzero(x[:n] > .5).tolist())
        chosen_set = set(chosen)
        if (len(chosen) > slots or any(not eligible[j] for j in chosen)
            or any(j in chosen_set and k in chosen_set for j, k in conflicts)):
            raise RuntimeError('Master selection violates inventory/reach/separation')
        plan, costs = allocate(chosen)
        if plan is not None:
            covered = float(weights[np.any(cover[list(chosen)], axis=0)].sum()) if chosen else 0.
            value = dominance*len(chosen)+covered
            if value >= best_value:
                best, best_costs, best_value = plan, costs, value
            # Master optimum + exact feasible allocation proves optimum of
            # the original finite model. A time-limited feasible master is
            # also certified executable, but is never labelled optimal.
            if status == 0:
                bound = best_value
                proven = True
            break
        if not chosen or chosen in cut_keys:
            raise RuntimeError('Invalid or repeated route exclusion')
        cut_keys.add(chosen)
        cut = coo_matrix((np.ones(len(chosen)),
            (np.zeros(len(chosen), np.int32), np.asarray(chosen, np.int32))),
            shape=(1, n+e)).tocsc()
        matrix = vstack([matrix, cut], format='csc')
        lower = np.r_[lower, -np.inf];upper = np.r_[upper, len(chosen)-1.]
    bound = max(best_value, bound)
    selected = sorted(j for js in best.values() for j in js)
    covered = float(weights[np.any(cover[selected], axis=0)].sum()) if selected else 0.
    for i, js in best.items():
        if len(js) > inventories[i] or best_costs[str(i)] > budgets[i]+1e-8:
            raise RuntimeError('Final allocation violates original budget/capacity')
    gap = (bound-best_value)/abs(best_value) if best_value else (0. if bound < 1e-9 else None)
    return best, dict(status=0 if proven else 1, master_status=status,
        optimality_proven=proven, solution_count=1, variables=n+e,
        constraints=len(upper), node_count=nodes, conflicts=len(conflicts),
        requested_slots=slots, heuristic_effort=0, threads=1,
        lazy_route_cuts=len(cut_keys), allocation_subproblems=len(allocations),
        graph_pair_queries=len(pairs), solver_version=['SciPy',scipy.__version__,'HiGHS'],
        solver_backend='license_free_highs_explicit_route_separation',
        solver_iterations=iterations, solver_message=message,
        bound=bound, objective=best_value, gap=gap, selected_slots=len(selected),
        covered_weight=covered, route_costs=best_costs,
        reachability_capacity_cuts=len(capacity_rows),
        reachability_pattern_counts={str(int(m)):int(np.sum(patterns==m)) for m in np.unique(patterns)},
        preparation_seconds=optimization_started-started,
        optimization_elapsed=time.perf_counter()-optimization_started,
        elapsed=time.perf_counter()-started,
        formulation='same_coverage_master_and_Hall_rows_with_exact_route_DP_and_valid_external_no_good_cuts')


