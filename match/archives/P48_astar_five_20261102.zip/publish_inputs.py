"""Publish only this requested task's reviewable artifacts to user repository."""
from pathlib import Path
import json,hashlib,subprocess,os,shutil,difflib,urllib.request,datetime
F=Path(__file__).resolve().parent;W=F/'github_worktree';relative=Path('swarm-eod/P48_Astar_five_20261102');T=W/relative;T.mkdir(parents=True,exist_ok=True)
env=dict(os.environ,GIT_TERMINAL_PROMPT='0');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):
 p=subprocess.run(['git','-c','http.proxy=','-c','credential.interactive=never','-C',str(W),*args],env=env,capture_output=True)
 if p.returncode:raise RuntimeError(p.stderr.decode(errors='replace'))
 return p.stdout
manifest=json.loads((F/'CANDIDATE_MANIFEST.json').read_text());shutil.copyfile(Path(manifest['zip']),T/'P48_Astar_research.zip')
review=dict(manifest);review.pop('zip',None);review.pop('source',None)
(T/'source_manifest.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
for name in ['TEST_PROTOCOL.json','ASTAR_CONTRACT_FIRST.json']:shutil.copyfile(F/name,T/name)
patch=''
for name in manifest['changed_files']:
 a=F/'parent_source'/name;b=F/'versions/P48_ASTAR/source'/name
 patch+=''.join(difflib.unified_diff(a.read_text().splitlines(keepends=True)if a.exists()else[],b.read_text().splitlines(keepends=True),fromfile='P48/'+name,tofile='P48_ASTAR/'+name))
(T/'algorithm_changes.diff').write_text(patch,encoding='utf8')
old=json.loads(Path('E:/codex/PJ01_rule_refinement_20261101/P55_P48_five_score_validation_20261101/CAMPAIGN_CLIENT_REVIEW.json').read_text())['result']
baseline=dict(mean=old['mean'],placed=old['placed'],maps=[dict(map=r['map'],full=r['full'],map_score=r['phase']['score_map'],wall_score=r['phase']['score_wall'],time_score=r['phase']['score_time'],placed=r['placed'])for r in old['rows']],scope='Already completed P48 original five-map observation. Not rerun or paired to new natural-random A* rounds.')
(T/'baseline_P48_five.json').write_text(json.dumps(baseline,indent=2)+'\n')
readme='''# P48 A* 五图测试（2026-11-02）

用户要求：仅替换算法，直接测试完整五图。这里将已确定目标后的执行路径搜索替换为A*，沿用P48的探索、布点、分配和预算规则。候选选点需要的全图距离场及布局全对距离仍保留原方法，避免同时改变选点目标；本次并非把整个布点问题改成A*。

## 改动范围

- 新增精确八邻接A*，使用octile启发函数，保留原代价、非负净空惩罚和斜角禁穿。
- 普通探索/utility选出目标后，A*重建实际执行路径；目标评分原样。
- 几何目标寻路改A*；目标不可达时保留原完整距离场和相同回退选点规则。
- 原路径平滑、绘图、感知、通信、任务分配、投放、依赖、SDK和蓝队均不改。
- 原提交日志附加各机自己的A*调用计数，计数不进入决策。无需Gurobi。

## 验证与评测

160个独立Bellman–Ford最短路对照（含56个不可达完整场案例）、108个原方法接口与36个几何接口检查通过。目标选择和原地图数组保持，等长路线允许不同；这些是数值接口验证，不是游戏提分证据。

本次仅一个Map01–05组，每图RED和同team006 BLUE各一场，共10native，无外部seed，无单图成绩筛选，不重跑旧P48/PJ01对照，不追加B组、不重启之前暂停的持续迭代。实际SDK启动资格与原资源门槛满足后开跑。成绩及进度将在本任务目录更新，当前尚不能给出A*五图均分。

已完成P48原五图参考均分72.6026760546，投放50/50；新一组自然随机结果差异只作观察，不能单组归因为搜索算法。

`P48_Astar_research.zip`是研究输入，不是新比赛提交版本。`source_manifest.json`和`algorithm_changes.diff`明确所有修改；`SHA256SUMS.json`校验本目录发布文件。原正式V09保持不变。
'''
(T/'README.md').write_text(readme,encoding='utf8')
# Publish canonical LF text bytes: Git's normal newline conversion otherwise
# changes uploaded text relative to hashes of Windows CRLF work files.
for p in T.iterdir():
 if p.is_file()and p.suffix!='.zip':p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
hashes={p.name:sha(p)for p in T.iterdir()if p.is_file()and p.name!='SHA256SUMS.json'};(T/'SHA256SUMS.json').write_bytes((json.dumps(hashes,indent=2)+'\n').encode())
git('config','user.name','Codex');git('config','user.email','codex@users.noreply.github.com')
git('add','--',relative.as_posix())
staged=git('diff','--cached','--name-only').decode().splitlines();assert staged and all(n.startswith(relative.as_posix()+'/')for n in staged)
git('commit','-m','Add P48 A-star navigation experiment inputs and validation')
commit=git('rev-parse','HEAD').decode().strip()
try:
 git('push','origin','HEAD:main')
except Exception as e:
 (F/'GITHUB_INPUTS_UPLOAD_ERROR.json').write_text(json.dumps(dict(status='NOT_VERIFIED_UPLOADED',commit=commit,error=str(e)),indent=2)+'\n');raise
head=git('ls-remote','origin','refs/heads/main').decode().split()[0];assert head==commit
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));verified={}
for p in T.iterdir():
 if not p.is_file():continue
 url='https://raw.githubusercontent.com/quanliangwen/1/'+commit+'/'+relative.as_posix()+'/'+p.name
 with opener.open(url,timeout=45)as response:body=response.read()
 digest=hashlib.sha256(body).hexdigest();assert digest==sha(p);verified[p.name]=digest
receipt=dict(status='PASS_REMOTE_COMMIT_AND_ALL_FILE_SHA256_VERIFIED',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),commit=commit,path=relative.as_posix(),url='https://github.com/quanliangwen/1/tree/'+commit+'/'+relative.as_posix(),files_sha256=verified,local_folder_is_temporary_worktree=True)
(F/'GITHUB_INPUTS_PUBLICATION.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(status=receipt['status'],commit=commit,url=receipt['url'])))
