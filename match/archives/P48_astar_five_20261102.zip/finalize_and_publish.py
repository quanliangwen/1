"""Report this one completed study; never launch or repeat a game."""
from pathlib import Path
import json,hashlib,subprocess,os,urllib.request,datetime
F=Path(__file__).resolve().parent;W=F/'github_worktree';rel='swarm-eod/P48_Astar_five_20261102';T=W/rel;read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not(F/'RESULT_PUBLICATION.json').exists()
state=read(F/'STATUS.json');assert state['status']=='COMPLETE_FINITE_STAGED_CAMPAIGN'
review=read(F/'CAMPAIGN_CLIENT_REVIEW.json');assert review['status']=='PASS'and not review['native_failure']
result=review['result'];assert len(result['rows'])==5
matrix=read(F/'P48_ASTAR_A/RESULT.json');raw=read(F/'P48_ASTAR_A/CLIENT_FIRST_RAW_REVIEW.json');binding=read(F/'INTERNAL_ZIP_BINDING.json')
assert matrix['complete']and matrix['payload_unchanged']and matrix['source_hashes']['red']==binding['payload_files']and raw['status']=='PASS'
base=read(T/'baseline_P48_five.json');old={r['map']:r for r in base['maps']};rows=[]
for r in result['rows']:
 b=old[r['map']];p=r['phase'];new_independent=.5*p['score_map']+.2*p['score_wall']+.1*p['score_time'];old_independent=.5*b['map_score']+.2*b['wall_score']+.1*b['time_score']
 rows.append(dict(map=r['map'],baseline_full=b['full'],astar_full=r['full'],full_delta=r['full']-b['full'],baseline_map=b['map_score'],astar_map=p['score_map'],baseline_wall=b['wall_score'],astar_wall=p['score_wall'],baseline_time=b['time_score'],astar_time=p['score_time'],baseline_placed=b['placed'],astar_placed=r['placed'],expected=r['expected'],astar_red_steps=r['red_steps'],astar_red_walltime=r['red_walltime'],red_wall_hit=r['red_wallhit'],blue_wall_hit=r['blue_wallhit'],reported_astar_calls=r['astar_calls'],reported_astar_expanded=r['astar_expanded'],submitted_map_bound=r['submitted_image_bound'],baseline_blue_difficulty_points=b['full']-old_independent,astar_blue_difficulty_points=r['full']-new_independent))
means=lambda key:sum(r[key]for r in rows)/5
summary=dict(status='COMPLETE_REVIEWED_FIVE_MAP_OBSERVATION',baseline_mean=base['mean'],astar_mean=result['mean'],mean_delta=result['mean']-base['mean'],baseline_placed=base['placed'],astar_placed=result['placed'],expected=50,evaluation_valid=result['evaluation_valid'],audit_integrity=result['audit_integrity'],red_wall_hits=sum(r['red_wall_hit']for r in rows),blue_wall_hits=sum(r['blue_wall_hit']for r in rows),total_reported_astar_calls=sum(r['reported_astar_calls']for r in rows),weighted_mean_changes=dict(map_points=.5*(means('astar_map')-means('baseline_map')),wall_points=.2*(means('astar_wall')-means('baseline_wall')),time_points=.1*(means('astar_time')-means('baseline_time')),blue_difficulty_points=means('astar_blue_difficulty_points')-means('baseline_blue_difficulty_points')),rows=rows,comparison_scope='One new original Map01-05 RED/BLUE group vs already completed P48. Natural-random episodes differ; descriptive observation, not a paired causal or stable-improvement claim. No control rerun, repeat, B group or official release.',game_rounds_added=10,ongoing_iteration_resumed=False)
(F/'FIVE_COMPARISON.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(T/'results.json').write_bytes((json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode())
entry=read(F/'ENTRY_ACTUAL_ZIP_FIRST.json')
receipts=dict(submission_research_zip_sha256=binding['sha256'],sdk_commit=read(F/'PREDECLARATION.json')['sdk_commit'],team_number=entry['team_number'],numeric_versions=entry['numeric_versions'],actual_SDK_entry_status=entry['status'],five_independent_constructors=entry['five_native_constructors_independent'],source_payload_unchanged_during_games=matrix['payload_unchanged'],first_raw_review=raw['status'],raw_archive_sha256=raw['archive_sha256'],files_first_verified=raw['files_first_verified'],NPZ_or_pickle_loaded=False,private_BLUE_console_read=False,source_contract=read(F/'ASTAR_CONTRACT_FIRST.json'))
(T/'test_receipts.json').write_bytes((json.dumps(receipts,ensure_ascii=False,indent=2)+'\n').encode())
now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).strftime('%Y-%m-%d %H:%M:%S 北京时间')
text=f'''# P48 A* 五图测试结果

更新时间：{now}

已完整完成原Map01–05，每图RED与原team006 BLUE各一场，共10native；原始文件首次Windows字节SHA审核及campaign审查通过。没有重跑P48/PJ01对照，没有追加B组或恢复持续迭代。

**原P48均分 {summary['baseline_mean']:.6f}；A*版本均分 {summary['astar_mean']:.6f}；观察差 {summary['mean_delta']:+.6f}。** 原P48投放{summary['baseline_placed']}/50，A*投放{summary['astar_placed']}/50。A*组RED墙钟超时{summary['red_wall_hits']}图、BLUE墙钟超时{summary['blue_wall_hits']}图。

|地图|原P48总分|A*总分|分差|A*地图分|A*覆盖分|A*时间分|投放|RED/BLUE超时|
|---|---:|---:|---:|---:|---:|---:|---:|---|
'''
for r in rows:text+=f"|{r['map']}|{r['baseline_full']:.4f}|{r['astar_full']:.4f}|{r['full_delta']:+.4f}|{r['astar_map']:.4f}|{r['astar_wall']:.4f}|{r['astar_time']:.4f}|{r['astar_placed']}/10|{'是'if r['red_wall_hit']else'否'}/{'是'if r['blue_wall_hit']else'否'}|\n"
text+='\n## 实际替换范围\n\n执行路线搜索改为精确八邻接A*，使用octile启发函数；保留原图、净空惩罚、斜角禁穿、平滑和不可达回退规则。探索/utility的候选评分仍用原完整距离场，布点与任务分配算法不变，因此这里没有把整个布点问题改成A*。无需Gurobi。各机提交日志实际记录A*调用合计'+str(summary['total_reported_astar_calls'])+'次；这是已记录调用，不是新增任务数。\n'
text+='\n## 分数变化的构成与限度\n\n'
for k,v in summary['weighted_mean_changes'].items():text+=f'- {k}: {v:+.6f} 总分点。\n'
text+='\n两组采用相同SDK/蓝队/原时限/线程和资源门槛，但自然随机场次不同。这些差异不能单组解释成A*的纯因果效果或稳定优势。'+('本组没有双方墙钟超时，数据可作该次性能观察。'if summary['evaluation_valid']else'本组存在墙钟超时，成绩保留报告，不据此宣布性能改善。')+'\n'
text+='\n160个独立Bellman–Ford对照、108个原探索接口和36个几何接口检查通过。新旧目标选择一致，等长路线可不同。`algorithm_changes.diff`列出四个修改文件；`P48_Astar_research.zip`仅为研究输入，不是比赛发布包，原正式V09不变。`results.json`含逐图新旧分项、投放、步数和超时；`test_receipts.json`含实际启动与首次审核绑定；`SHA256SUMS.json`校验本目录发布字节。\n'
(T/'README.md').write_bytes(text.encode())
hashes={p.name:sha(p)for p in T.iterdir()if p.is_file()and p.name!='SHA256SUMS.json'};(T/'SHA256SUMS.json').write_bytes((json.dumps(hashes,indent=2)+'\n').encode())
env=dict(os.environ,GIT_TERMINAL_PROMPT='0')
def git(*args):
 p=subprocess.run(['git','-c','http.proxy=','-c','credential.interactive=never','-C',str(W),*args],env=env,capture_output=True)
 if p.returncode:raise RuntimeError(p.stderr.decode(errors='replace'))
 return p.stdout
git('add','--',rel);staged=git('diff','--cached','--name-only').decode().splitlines();assert staged and all(n.startswith(rel+'/')for n in staged)
git('commit','-m','Report complete P48 A-star five-map evaluation')
# Preserve concurrent work in other task folders; never force-push.
git('fetch','origin','main');git('rebase','origin/main');git('push','origin','HEAD:main');commit=git('rev-parse','HEAD').decode().strip();assert git('ls-remote','origin','refs/heads/main').decode().split()[0]==commit
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));verified={}
for p in T.iterdir():
 if p.is_file():
  url='https://raw.githubusercontent.com/quanliangwen/1/'+commit+'/'+rel+'/'+p.name
  with opener.open(url,timeout=45)as response:b=response.read()
  assert hashlib.sha256(b).hexdigest()==sha(p),p.name;verified[p.name]=sha(p)
publication=dict(status='PASS_REMOTE_RESULTS_AND_ALL_SHA256_VERIFIED',commit=commit,url='https://github.com/quanliangwen/1/tree/'+commit+'/'+rel,files_sha256=verified,summary=summary)
(F/'RESULT_PUBLICATION.json').write_text(json.dumps(publication,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(status=publication['status'],commit=commit,url=publication['url'],astar_mean=summary['astar_mean'],delta=summary['mean_delta'])))
