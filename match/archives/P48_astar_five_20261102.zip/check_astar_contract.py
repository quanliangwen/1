"""Search oracle and original-method interface checks, zero SDK frames."""
from pathlib import Path
import ast,hashlib,json,sys,math,heapq,importlib.util
import numpy as np
import cv2
F=Path(__file__).resolve().parent;S=F/'versions/P48_ASTAR/source';P=F/'parent_source';out=F/'ASTAR_CONTRACT_FIRST.json';assert not out.exists()
spec=importlib.util.spec_from_file_location('actual_astar',S/'astar_grid.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
rng=np.random.default_rng(615);count=0;unreachable=0
for case in range(160):
 h,w=int(rng.integers(3,10)),int(rng.integers(3,10));walk=rng.random((h,w))>.25;start=(int(rng.integers(h)),int(rng.integers(w)));goal=(int(rng.integers(h)),int(rng.integers(w)));walk[start]=True
 penalty=rng.random((h,w))*.3 if case%2 else np.zeros((h,w));diag=math.sqrt(2)if case%3 else 1.414
 # Independently list graph edges by neighbouring coordinate pairs, then
 # synchronous Bellman-Ford relaxations; no A*/heap code reused.
 edges=[]
 for u in range(h*w):
  r,c=divmod(u,w)
  if not walk[r,c]:continue
  for v in range(h*w):
   rr,cc=divmod(v,w);dr,dc=rr-r,cc-c
   if not walk[rr,cc]or max(abs(dr),abs(dc))!=1:continue
   if dr and dc and not(walk[r,cc]and walk[rr,c]):continue
   edges.append((u,v,(diag if dr and dc else 1.)*(1.+penalty[rr,cc])))
 dist=np.full(h*w,np.inf);dist[start[0]*w+start[1]]=0.
 for _ in range(h*w-1):
  next_dist=dist.copy()
  for u,v,weight in edges:next_dist[v]=min(next_dist[v],dist[u]+weight)
  if np.array_equal(next_dist,dist):break
  dist=next_dist
 costs,parents,stats=a.astar_grid(walk,start,goal,penalty,diagonal=diag);target=dist[goal[0]*w+goal[1]]
 assert bool(np.isfinite(target))==stats['reached']
 if np.isfinite(target):
  assert abs(costs[goal]-target)<1e-9
  nodes=[goal]
  while nodes[-1]!=start:assert len(nodes)<=h*w;nodes.append(parents[nodes[-1]])
  total=0.
  for b,c in zip(nodes[:0:-1],nodes[-2::-1]):
   dr,dc=c[0]-b[0],c[1]-b[1];assert max(abs(dr),abs(dc))==1
   assert not(dr and dc)or(walk[b[0],c[1]]and walk[c[0],b[1]])
   total+=(diag if dr and dc else 1.)*(1.+penalty[c])
  assert abs(total-target)<1e-9
 else:
  unreachable+=1;assert np.array_equal(np.isfinite(costs.ravel()),np.isfinite(dist));assert np.allclose(costs.ravel()[np.isfinite(dist)],dist[np.isfinite(dist)],atol=1e-9)
 count+=1
def load_classes(root):
 env=dict(np=np,cv2=cv2,math=math,heapq=heapq,astar_grid=a.astar_grid,record_astar=a.record_astar)
 t=ast.parse((root/'greedy_mapping.py').read_text());node=next(n for n in t.body if isinstance(n,ast.ClassDef)and n.name=='MapMemory');exec(compile(ast.Module(body=[node],type_ignores=[]),'actual_base_memory','exec'),env)
 t=ast.parse((root/'fast_exploration.py').read_text());node=next(n for n in t.body if isinstance(n,ast.ClassDef)and n.name=='CoordinatedMapMemory');exec(compile(ast.Module(body=[node],type_ignores=[]),'actual_coordinated_memory','exec'),env)
 t=ast.parse((root/'geometry_route_view.py').read_text());node=next(n for n in t.body if isinstance(n,ast.ClassDef)and n.name=='GeometryPlanningMemory');exec(compile(ast.Module(body=[node],type_ignores=[]),'actual_geometry_memory','exec'),env)
 return env
old,new=load_classes(P),load_classes(S);interfaces=[]
for case in range(36):
 h,w=8,11;free=rng.random((h,w))>.2;clearance=rng.uniform(20.,75.,(h,w));clearance[rng.random((h,w))<.2]=8.;position=np.array([-48.,16.]);destination=np.array([48.,-32.]);utility=rng.random((h,w));visits=rng.integers(0,10,(h,w),dtype=np.uint8)
 for mode in ['explore','utility','destination']:
  results=[];mems=[]
  for env in [old,new]:
   m=env['CoordinatedMapMemory'](w*16,h*16,identifier=case%5,team_size=5);m.free=free.copy();m.visits=visits.copy();m.step=100;m.clearance=lambda:clearance.copy();mems.append(m)
   kw=dict(utility=utility.copy())if mode=='utility'else dict(destination=destination.copy())if mode=='destination'else{}
   results.append(m.route(position,**kw))
  left,right=results
  assert(left[1]is None)==(right[1]is None)
  if left[1]is not None:assert np.array_equal(left[1],right[1]),(case,mode,left[1],right[1])
  assert np.array_equal(mems[0].free,mems[1].free)and np.array_equal(mems[0].hits,mems[1].hits)
  interfaces.append(dict(case=case,mode=mode,endpoint_unchanged=True,path_changed=not(len(left[0])==len(right[0])and all(np.array_equal(p,q)for p,q in zip(left[0],right[0])))))
 geometry=[]
 for env in [old,new]:
  mem=env['MapMemory'](w*16,h*16);view=object.__new__(env['GeometryPlanningMemory']);view._memory=mem;view.free=free.copy();view._blocked=clearance<22
  geometry.append(view.route_to(position,destination))
 assert np.array_equal(geometry[0][1],geometry[1][1]),('geometry fallback',case)
report=dict(status='PASS_ASTAR_SEARCH_AND_UNCHANGED_ENDPOINT_INTERFACES',bellman_ford_cases=count,unreachable_full_field_cases=unreachable,actual_coordinated_interface_cases=len(interfaces),geometry_interface_cases=36,changed_tie_paths=sum(x['path_changed']for x in interfaces),checks=dict(shortest_weighted_cost=True,no_corner_cutting=True,unreachable_full_field_preserved=True,goal_selection_unchanged=True,original_free_hits_unchanged=True),helper_sha256=hashlib.sha256((S/'astar_grid.py').read_bytes()).hexdigest(),SDK_frames=0,native_rounds=0,limits='Actual original classes with authored numeric free/clearance/utility fixtures, not SDK flight or score evidence. Equal-cost path tie choices may change actual motion.')
out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
