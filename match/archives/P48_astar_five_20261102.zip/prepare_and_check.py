from pathlib import Path
import zipfile,json,subprocess,hashlib,ast
F=Path(__file__).resolve().parent;R='/home/junhao/quan/parallel_test_solver/match';H=R+'/solver_study/framework_screen_20261016/best87_independent_20261025';D=H+'/P48_astar_five_20261102';ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','junhao@10.112.162.60']
assert not(F/'ASTAR_CONTRACT_FIRST.json').exists()
parent=F/'parent_source';parent.mkdir()
with zipfile.ZipFile('E:/codex/P48_team615_red_v09_20261102/team615_red_v09.zip')as z:
 for n in z.namelist():assert '/'not in n and'\\'not in n;(parent/n).write_bytes(z.read(n))
for p in [F/'check_astar_contract.py',F/'build_candidate.py',F/'astar_grid.py']:ast.parse(p.read_text())
code='from pathlib import Path\np=Path('+repr(D)+')\nassert not p.exists()\np.mkdir()\n'
p=subprocess.run(ssh+[R+'/.venv/bin/python','-'],input=code.encode(),capture_output=True);(F/'MKDIR_FIRST.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
for p in [F/'versions',parent,F/'check_astar_contract.py',F/'CANDIDATE_MANIFEST.json']:
 subprocess.run(['scp','-q','-r',str(p),'junhao@10.112.162.60:'+D+'/'],check=True)
p=subprocess.run(ssh+[R+'/.venv/bin/python',D+'/check_astar_contract.py'],capture_output=True);(F/'CONTRACT_FIRST.log').write_bytes(p.stdout+p.stderr);print(p.stdout.decode(errors='replace'));assert p.returncode==0,p.stderr.decode(errors='replace')
subprocess.run(['scp','-q','junhao@10.112.162.60:'+D+'/ASTAR_CONTRACT_FIRST.json',str(F/'ASTAR_CONTRACT_FIRST.json')],check=True)
