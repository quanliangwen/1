from pathlib import Path
import ast,zipfile,hashlib,json,datetime
F=Path(__file__).resolve().parent;parent=Path('E:/codex/P48_team615_red_v09_20261102/team615_red_v09.zip');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(parent)=='fcef716d6855e7c5048299048e8ebd8216c777663ed75faf2583155d1648abc9'
source=F/'versions/P48_ASTAR/source';source.mkdir(parents=True);assert not(F/'CANDIDATE_MANIFEST.json').exists()
with zipfile.ZipFile(parent)as z:
 before={n:hashlib.sha256(z.read(n)).hexdigest()for n in z.namelist()}
 for n in z.namelist():assert '/'not in n and'\\'not in n;(source/n).write_bytes(z.read(n))
(source/'astar_grid.py').write_bytes((F/'astar_grid.py').read_bytes())
p=source/'fast_exploration.py';s=p.read_text();s=s.replace('import heapq\n','import heapq\nfrom swarm_rescue.solutions.astar_grid import astar_grid, record_astar\n',1)
old='''        cells = [goal]
        while cells[-1] != start:
            cells.append(parent[cells[-1]])
''';assert s.count(old)==1
new='''        # Endpoint selection above is unchanged. Whole-map distances still
        # compare every exploration/utility candidate; A* builds the actual
        # execution route to that already chosen endpoint on the same graph.
        astar_cost, parent, astar_stats = astar_grid(walkable, start, goal,
            penalties=np.asarray(penalties).reshape(self.shape))
        record_astar(self, astar_stats, 'coordinated')
        if not np.isfinite(astar_cost[goal]):
            raise RuntimeError('Selected reachable endpoint missing from identical A* graph')
        cells = [goal]
        while cells[-1] != start:
            cells.append(parent[cells[-1]])
''';s=s.replace(old,new);p.write_text(s)
p=source/'geometry_route_view.py';s=p.read_text().replace('import heapq\n','import heapq\nfrom swarm_rescue.solutions.astar_grid import astar_grid, record_astar\n',1)
start=s.index('        costs=np.full(self.shape,np.inf);costs[start]=0\n');end=s.index('        if np.isfinite(costs[wanted]):',start)
s=s[:start]+'''        costs,parents,astar_stats=astar_grid(walkable,start,wanted)
        record_astar(self,astar_stats,'geometry')
'''+s[end:];p.write_text(s)
p=source/'fresh_opportunity_audit.py';s=p.read_text();needle="inventory=int(self.carried_bombs_count()),stats=dict(self._fresh_opportunity_stats))\n        return super().submit_exploration_map(image)";assert s.count(needle)==1
s=s.replace(needle,"inventory=int(self.carried_bombs_count()),stats=dict(self._fresh_opportunity_stats),astar_stats=dict(getattr(self.memory,'astar_statistics',{})))\n        return super().submit_exploration_map(image)")
p.write_text(s)
files={p.name:sha(p)for p in source.iterdir()};changed=[n for n in files if before.get(n)!=files[n]]
assert set(changed)=={'astar_grid.py','fast_exploration.py','geometry_route_view.py','fresh_opportunity_audit.py'}
for p in source.glob('*.py'):ast.parse(p.read_text())
archive=F/'versions/P48_ASTAR/P48_Astar_research.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(source.iterdir()):z.writestr(p.name,p.read_bytes())
out=dict(status='FROZEN_ASTAR_PATH_REPLACEMENT_PENDING_INTERFACE_CHECK',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent_zip_sha256=sha(parent),zip=str(archive),sha256=sha(archive),source=str(source),payload_files=files,parent_files=before,changed_files=changed,behavior_changes=['A* constructs execution routes to unchanged selected exploration/utility goals.','Geometry fixed-destination route search switches Dijkstra to octile A*, preserving full-field fallback only when the destination is unreachable.'],unchanged=['candidate scoring/full-grid cost fields and all-pairs layout distances','coverage objectives/assignment/spacing/budgets','sensors/maps/messages/motor/path smoothing','SDK/opponent/requirements/team615'],diagnostics_only=['fresh_opportunity_audit includes own per-memory A* counters at existing submission log'],scope='Finite user-requested one original five-map group, no pilot screening, no baseline rerun, no ongoing iteration resumption, no Gurobi.',official_submission_ready=False)
(F/'CANDIDATE_MANIFEST.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status=out['status'],changed=changed,sha256=out['sha256'])))
