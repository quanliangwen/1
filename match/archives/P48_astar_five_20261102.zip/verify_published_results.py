"""Recover publication verification after Git rebase rewrote local newlines.

No file upload, score change, game restart, or duplicate archive review.
"""
from pathlib import Path
import subprocess,urllib.request,hashlib,json,datetime
F=Path(__file__).resolve().parent;W=F/'github_worktree';rel='swarm-eod/P48_Astar_five_20261102';T=W/rel
assert not(F/'RESULT_PUBLICATION.json').exists()
commit=subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'],text=True).strip();base='https://raw.githubusercontent.com/quanliangwen/1/'+commit+'/'+rel+'/'
op=urllib.request.build_opener(urllib.request.ProxyHandler({}))
def fetch(name):
 with op.open(base+name,timeout=45)as response:return response.read()
hashes=json.loads(fetch('SHA256SUMS.json'));contents={};verified={}
for name,expected in hashes.items():
 body=fetch(name);actual=hashlib.sha256(body).hexdigest();assert actual==expected,name;verified[name]=actual;contents[name]=body
summary=json.loads((F/'FIVE_COMPARISON.json').read_text());assert json.loads(contents['results.json'])==summary
assert json.loads(contents['TEST_PROTOCOL.json'])==json.loads((F/'TEST_PROTOCOL.json').read_text())
binding=json.loads((F/'INTERNAL_ZIP_BINDING.json').read_text());assert verified['P48_Astar_research.zip']==binding['sha256']
receipt=json.loads(contents['test_receipts.json']);raw=json.loads((F/'P48_ASTAR_A/CLIENT_FIRST_RAW_REVIEW.json').read_text())
assert receipt['raw_archive_sha256']==raw['archive_sha256']and receipt['first_raw_review']=='PASS'
assert contents['README.md'].replace(b'\r\n',b'\n')==(T/'README.md').read_bytes().replace(b'\r\n',b'\n')
local_mismatches=[name for name,digest in verified.items()if hashlib.sha256((T/name).read_bytes()).hexdigest()!=digest]
note=dict(status='VERIFIED_REMOTE_CANONICAL_BYTES_NO_UPLOAD_CORRECTION_REQUIRED',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),initial_error='Final publisher compared canonical remote LF against post-rebase Windows CRLF working files. Published checksums were already correct.',local_post_rebase_newline_differences=local_mismatches,all_remote_files_match_published_SHA256SUMS=True,algorithm_or_scores_changed=False,new_game_rounds=0,raw_archives_reaudited=False)
(F/'PUBLICATION_VERIFICATION_RECOVERY.json').write_text(json.dumps(note,indent=2)+'\n')
publication=dict(status='PASS_REMOTE_RESULTS_AND_ALL_SHA256_VERIFIED',commit=commit,url='https://github.com/quanliangwen/1/tree/'+commit+'/'+rel,files_sha256=verified,summary=summary,verification_note=note)
(F/'RESULT_PUBLICATION.json').write_text(json.dumps(publication,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(F/'COMPLETION_PUBLICATION_RECOVERED.json').write_text(json.dumps(dict(status='COMPLETE_VERIFIED_GITHUB_RESULTS',commit=commit,url=publication['url'],original_first_error_retained=True,game_restarts=0),indent=2)+'\n')
print(json.dumps(dict(status=publication['status'],commit=commit,url=publication['url'],mean=summary['astar_mean'],delta=summary['mean_delta'],published_files=len(verified)+1)))
