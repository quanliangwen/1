"""作业1：Edmonds-Karp最大流，并穷举全部割独立校验。仅需Python标准库。"""
from collections import deque
from itertools import combinations
import json
from pathlib import Path

ARCS = [('ST','RO',50), ('ST','BO',70), ('ST','LI',40),
        ('RO','NY',60), ('BO','NY',40), ('BO','NO',50),
        ('LI','NO',30), ('NY','LA',80), ('NO','LA',70)]

def solve():
    adj, residual = {}, {}
    for u, v, c in ARCS:
        adj.setdefault(u, []).append(v)
        adj.setdefault(v, []).append(u)
        residual[u, v], residual[v, u] = c, 0
    value, trace = 0, []
    while True:
        parent, queue = {'ST': None}, deque(['ST'])
        while queue and 'LA' not in parent:
            u = queue.popleft()
            for v in adj[u]:
                if v not in parent and residual[u, v] > 0:
                    parent[v] = u
                    queue.append(v)
        if 'LA' not in parent:
            break
        path, v = [], 'LA'
        while parent[v] is not None:
            u = parent[v]
            path.append((u, v))
            v = u
        delta = min(residual[e] for e in path)
        for u, v in path:
            residual[u, v] -= delta
            residual[v, u] += delta
        value += delta
        trace.append({'path': ['ST'] +
                      [v for u, v in reversed(path)],
                      'delta': delta, 'total': value})
    flows = [(u, v, c, c-residual[u,v]) for u,v,c in ARCS]
    for u,v,c,f in flows:
        assert 0 <= f <= c
    for n in adj:
        net = sum(f for u,v,c,f in flows if u == n)
        net -= sum(f for u,v,c,f in flows if v == n)
        assert net == (value if n == 'ST' else
                       -value if n == 'LA' else 0)
    middle = sorted(set(adj) - {'ST', 'LA'})
    cuts = []
    for k in range(len(middle)+1):
        for subset in combinations(middle, k):
            side = {'ST', *subset}
            capacity = sum(c for u,v,c in ARCS
                           if u in side and v not in side)
            cuts.append((capacity, sorted(side)))
    minimum = min(c for c,s in cuts)
    assert value == minimum
    # 独立枚举源点流量及波尔多分流，统计最大流方案数。
    optima = []
    for a in range(51):
        for b in range(71):
            l = value-a-b
            if not 0 <= l <= 30:
                continue
            for q in range(41):
                no = b-q+l
                ny = a+q
                if 0 <= b-q <= 50 and ny <= 80 and no <= 70:
                    optima.append((a,b,l,a,q,b-q,l,ny,no))
    assert len(optima) == 1
    assert list(optima[0]) == [f for u,v,c,f in flows]
    return {'maximum_flow': value, 'arcs': flows,
            'augmentations': trace, 'cuts_checked': len(cuts),
            'optimal_solution_count': len(optima),
            'minimum_cuts': [s for c,s in cuts if c == minimum]}

if __name__ == '__main__':
    result = solve()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    Path(__file__).with_name('问题一运行结果.json').write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print('问题一求解结果：最大运输量为150单位，各路线最优流量唯一。')
    for u,v,c,f in result['arcs']:
        print(f'{u} -> {v}: 容量={c}, 流量={f}, 剩余={c-f}')
