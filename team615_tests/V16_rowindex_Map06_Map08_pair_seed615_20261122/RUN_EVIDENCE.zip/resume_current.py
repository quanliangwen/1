"""User-authorized fixed idle physical-core comparison, exactly one match per arm."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl
import hashlib
import json
import os
import platform
import subprocess
import time

ROOT=Path(__file__).resolve().parent
LOCK='/home/junhao/quan/parallel_test_solver/match/solver_study/serial_evaluation.lock'
CORE_COUNT=16
previous=None
def now():return datetime.now(timezone.utc).isoformat()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def status(value):save(ROOT/'STATUS.json',dict(utc=now(),**value))
def counters():
    out={}
    for line in Path('/proc/stat').read_text().splitlines():
        fields=line.split()
        if fields[0]=='cpu' or fields[0].startswith('cpu') and fields[0][3:].isdigit():
            values=list(map(int,fields[1:9]));out[fields[0]]=(sum(values),values[3]+values[4])
    return out
def sample(cpus=()):
    global previous
    values=counters();busy=None;per_core={};stamp=time.monotonic()
    if previous is not None:
        for key in ['cpu']+['cpu'+str(c) for c in cpus]:
            total=values[key][0]-previous[key][0];idle=values[key][1]-previous[key][1]
            percent=100.*(total-idle)/total if total else 0.
            if key=='cpu':busy=percent
            else:per_core[key]=percent
    previous=values
    load=Path('/proc/loadavg').read_text().split()
    pressure={n:(Path('/proc/pressure')/n).read_text().strip() for n in ['cpu','memory','io']}
    return dict(utc=now(),monotonic=stamp,cpu_busy_percent=busy,load1=float(load[0]),load5=float(load[1]),
                load15=float(load[2]),runnable=load[3],pressure=pressure,selected_cpu_busy_percent=per_core)
def process_sample(pid,detailed):
    try:
        p=Path('/proc')/str(pid);raw=(p/'stat').read_text();f=raw[raw.rfind(')')+2:].split()
        result=dict(pid=pid,state=f[0],user_seconds=int(f[11])/os.sysconf('SC_CLK_TCK'),
                    system_seconds=int(f[12])/os.sysconf('SC_CLK_TCK'),threads=int(f[17]),cpu=int(f[36]),
                    rss_bytes=int(f[21])*os.sysconf('SC_PAGE_SIZE'))
        if detailed:
            total=[0,0,0];count=0
            for task in (p/'task').iterdir():
                try:
                    v=list(map(int,(task/'schedstat').read_text().split()));total=[x+y for x,y in zip(total,v)];count+=1
                except (FileNotFoundError,ProcessLookupError):pass
            result['thread_schedstat_sum']=dict(runtime_ns=total[0],runqueue_wait_ns=total[1],timeslices=total[2],read_threads=count)
            result['allowed_cpu_list']=[s for s in (p/'status').read_text().splitlines() if s.startswith('Cpus_allowed_list')]
        return result
    except (FileNotFoundError,ProcessLookupError):return None

ROOT=ROOT/'Map08'
stage=ROOT/'current'
with (ROOT/'CURRENT_USER_OVERRIDE_DISPATCH_ONCE_CLAIM').open('x'):pass
assert not any((stage/n).exists() for n in ['START.json','RUN_ONCE_CLAIM','SDK_PID'])
assert (ROOT/'V16/POST_RUN_SOURCE_CHECK.json').exists()
cpus=json.loads((ROOT/'AFFINITY_SELECTION.json').read_text())['logical_cpus']
override=json.loads((ROOT/'USER_LOAD_OVERRIDE.json').read_text())
lock=open(LOCK,'r');fcntl.flock(lock,fcntl.LOCK_EX)
try:
    sample(cpus);time.sleep(2);row=sample(cpus)
    cfg=json.loads((ROOT/'MONITOR_CONFIG.json').read_text());cfg.update(candidate_idle_gate_waived_by_user=True,candidate_dispatcher_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),candidate_mode='same_fixed_group_with_disclosed_background_interference');save(ROOT/'MONITOR_CONFIG.json',cfg)
    auth=json.loads((ROOT/'AUTHORIZED_RUN.json').read_text());auth.update(candidate_idle_gate_waived_by_user=True,candidate_fixed_same_group=True,candidate_interference_must_be_disclosed=True);save(ROOT/'AUTHORIZED_RUN.json',auth)
    save(stage/'LOWLOAD_ADMISSION.json',dict(version='current',mode='same_fixed_group_with_disclosed_background_interference',stable_seconds=0,admission=row,logical_cpus=cpus,lock_acquired=True,whole_server_lowload_claim=False,user_explicitly_waived_idle_gate=True))
    status(dict(state='RUNNING',task='current',completed_tasks=['V16'],logical_cpus=cpus,mode='USER_AUTHORIZED_DISCLOSED_BACKGROUND_INTERFERENCE'))
    with (stage/'dispatch.log').open('x') as output,(stage/'resources.jsonl').open('x',buffering=1) as stream:
        proc=subprocess.Popen(['bash',str(stage/'run_monitored.sh'),str(stage)],cwd=stage,stdout=output,stderr=subprocess.STDOUT,preexec_fn=lambda:os.sched_setaffinity(0,set(cpus)))
        index=0;pid=None
        while proc.poll() is None:
            row=sample(cpus)
            if (stage/'SDK_PID').exists():pid=int((stage/'SDK_PID').read_text())
            row['test_process']=process_sample(pid,index%5==0) if pid else None
            stream.write(json.dumps(row)+'\n');index+=1;time.sleep(1)
        returncode=proc.wait()
    save(stage/'MONITOR_FINISH.json',dict(utc=now(),returncode=returncode,pid=pid,samples=index,logical_cpus=cpus))
    if returncode!=0 or not (stage/'POST_RUN_SOURCE_CHECK.json').exists():raise RuntimeError('current failed; no rerun')
    status(dict(state='COMPLETE',completed_tasks=['V16','current'],red_rounds=2,maps=['Map08'],logical_cpus=cpus,candidate_idle_gate_waived_by_user=True,whole_server_lowload_claim=False))
except BaseException as exc:
    status(dict(state='FAILED',error=repr(exc),no_automatic_rerun=True));raise
finally:fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
