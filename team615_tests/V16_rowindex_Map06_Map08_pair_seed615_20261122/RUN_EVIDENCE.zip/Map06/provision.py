from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import ast,json,shutil,subprocess
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'team615_v16_rowindex_map09_pair_20261122'
SRC=ROOT.parent/'team615_v16_row_index_20261122'
HOST='quanliangwen@10.112.162.60';REMOTE='/home/quanliangwen/isolated_test/'+ROOT.name
H=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf8'))
save=lambda p,d:p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
b=read(SRC/'BUILD.json')
assert H(SRC/'baseline_snapshot.zip')==b['baseline_zip_sha256']=='e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791'
assert H(SRC/'candidate_snapshot.zip')==b['candidate_zip_sha256']=='1dfbbfd4186063edb908bd7cb1f812a0e8956a69901f28988f632acee2c70784'
assert b['changed_files']==['line_regularization.py'] and b['wall_margin_seconds']==1.5
shutil.copyfile(OLD/'environment.py',ROOT/'environment.py')
helpers=(OLD/'affinity_runner.py').read_text().split("save(ROOT/'HOST.json'")[0]
body=(ROOT/'runner_body.txt').read_text(encoding='utf8')
(ROOT/'affinity_runner.py').write_text(helpers+body,encoding='utf8',newline='\n')
tasks=[]
for mapname in ['Map06','Map08']:
 for label in ['V16','current']:
  rel=mapname+'/'+label;tasks.append(rel);folder=ROOT/rel;folder.mkdir(parents=True)
  source=SRC/('baseline_snapshot.zip' if label=='V16' else 'candidate_snapshot.zip')
  shutil.copyfile(source,folder/'candidate_snapshot.zip');shutil.copyfile(SRC/'baseline_snapshot.zip',folder/'baseline_snapshot.zip')
  with ZipFile(source) as z:
   files={n:sha256(z.read(n)).hexdigest() for n in z.namelist()}
   assert files==b['baseline_files' if label=='V16' else 'candidate_files']
   assert b'MIN_WALL_MARGIN = 1.5' in z.read('deadline_submission.py')
  binding=dict(baseline_commit='63ef52c4e56b37c3104ce060853b79ceab5ff133',baseline_zip_sha256=b['baseline_zip_sha256'],candidate_zip_sha256=H(source),baseline=b['baseline_files'],candidate=files,changed=[] if label=='V16' else ['line_regularization.py'])
  for name,data in [('BUILD.json',b),('DECLARED_SOURCE.json',files),('PATCH_BINDING.json',binding),('OFFLINE_CHECK.json',dict(simulation_steps=0,unit_cases=106 if label=='current' else 0))]:save(folder/name,data)
  origin=ROOT.parent/'team615_v17_map06_map08_seed615_20261121'/mapname
  for name in ['stage_run.py','place_map09.yml','matched_spawns.json','EXPECTED_ZONES.json']:shutil.copyfile(origin/name,folder/name)
  assert H(folder/'stage_run.py')=='33f7480f3eebd207ffa28ae81b36c0fd37cabaee057ac935697934f242929592'
  shell=(OLD/'V16/run_monitored.sh').read_text().replace('Map09',mapname).replace(' V16 ',' '+label+' ')
  (folder/'run_monitored.sh').write_text(shell,encoding='utf8',newline='\n')
 for n in ['place_map09.yml','matched_spawns.json','EXPECTED_ZONES.json']:assert H(ROOT/mapname/'V16'/n)==H(ROOT/mapname/'current'/n)
save(ROOT/'AUTHORIZED_RUN.json',dict(maps=['Map06','Map08'],seed=615,tasks=tasks,total_red_rounds=4,new_red_rounds_per_map_per_version=1,algorithm_changes=False,versions={'V16':b['baseline_zip_sha256'],'current':b['candidate_zip_sha256']},wall_margin_seconds_both=1.5,observer_identical=True,whole_server_lowload_required=False,physical_cores=16,selected_core_idle_gate_percent=5,stable_seconds=10,remote=REMOTE,other_queues_not_resumed=True))
for p in ROOT.glob('*.py'):ast.parse(p.read_text(encoding='utf8'))
subprocess.run(['ssh',HOST,'mkdir '+REMOTE],check=True)
subprocess.run(['scp','-q',*[str(ROOT/n) for n in ['affinity_runner.py','environment.py','AUTHORIZED_RUN.json']],HOST+':'+REMOTE+'/'],check=True)
for task in tasks:
 subprocess.run(['ssh',HOST,'mkdir -p '+REMOTE+'/'+task],check=True)
 subprocess.run(['scp','-q',*[str(p) for p in (ROOT/task).iterdir()],HOST+':'+REMOTE+'/'+task+'/'],check=True)
subprocess.run(['ssh',HOST,'/home/junhao/quan/parallel_test_solver/match/.venv/bin/python '+REMOTE+'/environment.py'],check=True)
print(subprocess.run(['ssh',HOST,'nohup python3 '+REMOTE+'/affinity_runner.py > '+REMOTE+'/queue.log 2>&1 < /dev/null & echo FOUR_MATCHES_QUEUED_ONCE_EACH'],capture_output=True,text=True,check=True).stdout)
