from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from hashlib import sha256
import json,struct,ast
ROOT=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf8'))
save=lambda p,v:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
H=lambda p:sha256(p.read_bytes()).hexdigest()
old=ROOT.parent/'team615_v16_rowindex_map09_pair_20261122/finalize_report.py'
prefix=old.read_text(encoding='utf8').split('metrics=[')[0]
prefix=prefix.replace("ROOT=Path(__file__).resolve().parent", "ROOT=TASKROOT/MAP")
prefix=prefix.replace("result['map']=='Map09'", "result['map']==MAP")
lines=prefix.splitlines()
lines=[l for l in lines if not l.startswith("assert len(c['accepted_placements']") and not l.startswith("assert c['accepted_placements']") and not l.startswith("assert c['selected_cache_versions']") and not l.startswith("assert all(originals[")]
prefix='\n'.join(lines)
allresults={};report=['# V16与按行索引候选：Map06、Map08，种子615\n',
'本轮每版每图仅运行一次，共四场红队，无其他地图、蓝队、重跑或算法修改。两版均为冻结归档，保留1.5秒墙钟预留。每张图内两版固定同一组16物理核（含双线程共32逻辑CPU），串行共享测试锁。Map06完成后原核心组持续被占用，用户明确同意Map08另选新的一组，两图之间不混作同核比较。Map08候选开跑前，新组也被后台任务占用；用户随后明确允许固定原组带干扰运行并披露。Map08不是严格同负载测试，其秒数差只代表本次实测，不能全部归因于代码优化。停止的仅是未开局的等待队列，没有中断或重跑任何比赛。\n']
for MAP in ['Map06','Map08']:
 scope={'TASKROOT':ROOT,'MAP':MAP,'__file__':str(ROOT/'finalize.py')}
 exec(compile(prefix,str(old),'exec'),scope)
 r=read(ROOT/MAP/'delivery/RESULTS.json');allresults[MAP]=r;a=r['versions']['V16'];b=r['versions']['current'];c=r['comparison']
 report.extend(['## '+MAP+'\n','| 指标 | V16 | 按行索引 | 候选−V16 |','|---|---:|---:|---:|'])
 for name,key in [('交图者','submission_drone'),('交图步数','submission_step'),('得分（可核验红队小计/80）','score_out_of_80'),('地图分','map_score'),('墙覆盖分','wall_score'),('实投数','placed'),('交图指令墙钟/秒','submission_walltime_seconds'),('最终墙钟/秒','final_walltime_seconds'),('探索率/%','exploration_percent'),('掉血','total_health_lost'),('漏墙像素','missed_wall_pixels'),('误画像素','charged_misdraw_pixels')]:
  fmt=lambda v:str(v) if type(v)is int else f'{v:.6f}'
  report.append(f'| {name} | {fmt(a[key])} | {fmt(b[key])} | {fmt(b[key]-a[key])} |')
 report.extend(['','得分小计按SDK原权重为0.5×地图分＋0.2×墙覆盖分＋0.1×时间分；未把未输出的炸弹项冒称为完整总分。墙覆盖分使用SDK官方coverage字段。','',
  f"共同无人机及炸弹物理记录截至第{c['last_same_drone_and_bomb_frame_step']}步；进一步限制制图调用安排及收尾审计一致，可比截至第{c['matched_physics_render_closeout_last_step']}步：V16 {c['same_work_V16_seconds']:.6f}秒，候选 {c['same_work_candidate_seconds']:.6f}秒，候选累计节省{c['matched_physics_render_closeout_saved_seconds']:.6f}秒。跨越此区间的同一步数数据仅作实际运行记录，不能解释为完全相同工作量的加速。\n",
 '| 步数 | V16累计秒 | 候选累计秒 | 候选节省秒 | 在共同工作区间内 |','|---:|---:|---:|---:|---|'])
 for step,x in sorted(c['same_step_times'].items(),key=lambda x:int(x[0])):
  report.append(f"| {step} | {x['V16_seconds']:.6f} | {x['candidate_seconds']:.6f} | {x['candidate_saved_seconds']:+.6f} | {'是' if int(step)<=c['matched_physics_render_closeout_last_step'] else '否'} |")
 report.extend(['','| 运行条件 | V16 | 候选 |','|---|---:|---:|'])
 for name,key in [('整机CPU占用均值/%','cpu_busy_percent'),('整机load1均值','load1'),('所选CPU池占用均值/%','selected_pool_busy_percent'),('所选CPU池其他任务估计等效核均值','estimated_other_work_cpu_equivalents_in_pool')]:
  report.append(f"| {name} | {a['resources'][key]['mean']:.6f} | {b['resources'][key]['mean']:.6f} |")
 report.extend(['',f"相同CPU亲和性：{c['same_observed_cpu_masks']}；全部实投事件相同：{c['same_all_accepted_placements']}；最终图片相同：{c['same_selected_map']}；第一处分歧：物理记录={c['first_different_recorded_frame']}（记录帧，比赛步数需加1），制图安排={c['first_different_render_schedule_step']}步，收尾审计={c['first_closeout_audit_difference_step']}步。",'',
 '提交记录：`'+json.dumps({'V16':a['all_submissions'],'current':b['all_submissions']},ensure_ascii=False)+'`。',
 '兜底记录：`'+json.dumps({'V16':a['walltime_submission'],'current':b['walltime_submission']},ensure_ascii=False)+'`。',''])
 report.extend([f"小计变化分解：地图项{.5*(b['map_score']-a['map_score']):+.6f}，墙覆盖项{.2*(b['wall_score']-a['wall_score']):+.6f}，时间项{.1*(b['time_score']-a['time_score']):+.6f}。两版最终缓存版本：`{json.dumps(c['selected_cache_versions'],ensure_ascii=False)}`。",''])
 if MAP=='Map06':
  report.extend(['本图候选算到更多步，但依旧由原墙钟出口结束。实际地图分略升，时间分下降幅度更大，因此得分小计下降；这不支持将本图结果表述为得分提升。两版全部投放及共同区间物理记录一致，最终图片差异发生在后续缓存更新和选择中。',''])
selections={m:read(ROOT/m/'received/AFFINITY_SELECTION.json') for m in ['Map06','Map08']}
report.extend(['## 证据与边界\n',f"Map06逻辑CPU：`{selections['Map06']['logical_cpus']}`；Map08逻辑CPU：`{selections['Map08']['logical_cpus']}`。两组均重新选择，未与上一轮Map09混作同核对照。本轮比较仅在每张图内进行。前三场入场要求全部所选逻辑CPU连续10秒不超过5%占用；Map08候选依用户明确选择取消空闲门槛并保持同组运行。亲和性并不保证独占，运行期采样详见RESULTS和原始证据。整机存在后台负载，不声称整机低负载。",
'每版每图一场只能说明本次条件下的结果，不能给出统计显著性保证。最终墙钟接近时，应比较共同工作区间同一步数耗时，或额外执行步数；不能将墙钟兜底结束时的秒数差直接当作算法节省。\n',
'V16归档SHA256：`e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791`；候选归档：`1dfbbfd4186063edb908bd7cb1f812a0e8956a69901f28988f632acee2c70784`。只存在line_regularization.py变化，算法源文件逐场运行前后校验通过，SDK开跑前按封存清单校验通过。V16继续保留为比赛基线。'])
out=ROOT/'delivery';out.mkdir(exist_ok=True)
save(out/'RESULTS.json',dict(status='COMPLETE',maps=['Map06','Map08'],seed=615,new_red_rounds=4,Map08_separate_group_authorized_by_user=True,Map08_candidate_idle_admission_waived_by_user=True,strict_equal_background_load_claim=False,results=allresults))
(out/'REPORT.md').write_text('\n'.join(report)+'\n',encoding='utf8')
with ZipFile(out/'RUN_EVIDENCE.zip','w',ZIP_DEFLATED) as z:
 for m in ['Map06','Map08']:
  with ZipFile(ROOT/m/'delivery/RUN_EVIDENCE.zip') as orig:
   for n in orig.namelist():z.writestr(m+'/'+n,orig.read(n))
 for n in ['finalize.py','runner_body.txt','provision.py','affinity_runner_map08.py','RESELECTION_BY_USER.json','resume_current.py','resume_body.txt','USER_LOAD_OVERRIDE.json']:z.write(ROOT/n,n)
save(out/'CHECKSUMS_SHA256.json',{p.name:H(p) for p in sorted(out.iterdir()) if p.name!='CHECKSUMS_SHA256.json'})
print(json.dumps({m:{'versions':{k:{f:v[f] for f in ['submission_drone','submission_step','score_out_of_80','map_score','wall_score','placed','final_walltime_seconds']} for k,v in r['versions'].items()},'same_work_step':r['comparison']['matched_physics_render_closeout_last_step'],'same_work_gain':r['comparison']['matched_physics_render_closeout_saved_seconds']} for m,r in allresults.items()},indent=2))
