from pathlib import Path, PurePosixPath
from hashlib import sha256
from zipfile import ZipFile, ZIP_DEFLATED
import ast
import json
import math
import struct
import subprocess

r=Path(__file__).resolve().parent
folder=r/'Map08';received=folder/'received'
host='quanliangwen@10.112.162.60';remote=(r/'SERVER_STAGE.txt').read_text().strip()+'/Map08'
histories={'V16':r.parent/'team615_first_round_yield_maps_20261121/Map08/received',
           'V17':r.parent/'team615_v17_map06_map08_seed615_20261121/Map08/received'}
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def download(paths,destination):
    destination.mkdir(parents=True,exist_ok=True)
    subprocess.run(['scp','-q','-o','BatchMode=yes',*[host+':'+p for p in paths],str(destination)],check=True)

files=['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','placement_events.jsonl','run.log','dispatch.log',
       'wall_geometry.npz','group_dataset.npz','GROUP_DATASET.json','POST_RUN_SOURCE_CHECK.json','EXTRA_ARTIFACTS.json']
download([remote+'/'+name for name in files],received)
end=read(received/'FINISH.json')
assert (end['status'],end['completed_red_rounds'],end['blue_rounds'],end['layout_evaluations'])==('COMPLETE',1,0,0)
official=PurePosixPath(end['result_dir'])
assert official.is_relative_to(PurePosixPath(remote)/'official_sdk/results_swarm_rescue')
for name,digest in end['files'].items():
    path=PurePosixPath(name);assert not path.is_absolute() and '..' not in path.parts
    download([str(official/path)],received/'official'/path.parent)
    assert h(received/'official'/name)==digest
for name,digest in read(received/'EXTRA_ARTIFACTS.json').items():assert h(received/name)==digest
build=read(r/'BUILD.json');start=read(received/'START.json')
assert h(r/'candidate_snapshot.zip')==build['candidate_zip_sha256']=='3b7053616c45ee965bfca5f4d9ba08fbbcc1f167f9a8a9e4faa5ec1e6d8a30ed'
assert h(r/'baseline_snapshot.zip')==build['baseline_zip_sha256']=='0aaed704f050073b664d4c0bece9f9ff6500e59edf55c78a7284036f01c167e7'
assert start['solutions_sha256']==read(received/'SOURCE_MATCH.json')['candidate']==build['candidate_files']
assert read(received/'POST_RUN_SOURCE_CHECK.json')['status']=='PASS'
assert (start['seed'],start['map_name'],start['drones'],start['bombs_per_drone'],start['timestep_limit'],start['walltime_limit'])==(615,'Map08',5,2,5400,180)
assert start['sdk']=='6557940dc18549ffc7a945db887da5b05b7ed2f1'
v16_files=read(r.parent/'team615_red_v16_first30_release_20261121/BUILD.json')['payload_files_sha256']
scores={};grids={};starts={}
for label,path in {**histories,'candidate':received}.items():
    s=read(path/'OFFICIAL_SCORE.json');other=read(path/'START.json');scores[label]=s;starts[label]=other
    assert other['solutions_sha256']==(build['candidate_files'] if label=='candidate' else build['original_files'] if label=='V17' else v16_files)
    for key in ['seed','sdk','sdk_archive_sha256','map_name','drones','bombs_per_drone','timestep_limit','walltime_limit','competition_mode','spawn','zones']:
        assert start[key]==other[key],(label,key)
    assert h(path/'placement_events.jsonl')==s['placement_events_sha256'] and h(path/'wall_geometry.npz')==s['wall_geometry_sha256']
    for name,digest in read(path/'FINISH.json')['files'].items():assert h(path/'official'/name)==digest
    assert s['submitted_map'] and s['selected_submission']['image_sha256']==s['selected_image_sha256']
    assert math.isclose(s['partial'],.5*s['map_score']+.2*s['coverage']+.1*s['time_score'],abs_tol=1e-9)
    assert len(read(next((path/'official').glob('*_bombs.json')))['bombs'])==s['placed']
    grid=read(next((path/'official').glob('*_exploration.json')))['grid'];grids[label]=grid
    assert sha256(bytes(x for row in grid for x in row)).hexdigest()==s['selected_image_sha256']
log=(received/'dispatch.log').read_text(encoding='utf8')
assert log.count('START Map08 soft_emergency_yield seed615')==1 and log.count('COMPLETE Map08 soft_emergency_yield seed615')==1
assert 'START Map06' not in log and 'START Map09' not in log

def summary(s):
    selected=s['selected_submission'];details={d['drone']:d for d in s['drone_details']}
    chosen=details[selected['drone']];event=chosen['walltime_submission']
    submits=[e for e in chosen['group_audit'] if e[1] in ('soft_cutoff_submit','submitted')]
    mode=event.get('fallback','deadline_election') if event is not None else 'soft_cutoff' if any(e[1]=='soft_cutoff_submit' for e in submits) else 'ordinary'
    return dict(partial_score_out_of_80=s['partial'],map_score=s['map_score'],wall_score=s['coverage'],time_score=s['time_score'],
        submission_drone=selected['drone'],submission_step=selected['step'],submission_walltime_seconds=selected['walltime_seconds'],
        final_walltime_seconds=s['elapsed_walltime'],remaining_walltime_at_finish=180.-s['elapsed_walltime'],placed=s['placed'],
        expected=s['expected'],exploration_percent=s['trajectory'],selected_map_sha256=s['selected_image_sha256'],all_submissions=s['submissions'],
        submission_mode=mode,deadline_event=event,selected_cache=chosen['group_best_metadata'],
        missed_wall_pixels=s['map_breakdown']['wall_pixels']-s['map_breakdown']['wall_hits'],charged_misdraw_pixels=s['map_breakdown']['charged_pixels'],
        total_health_lost=sum(25-d['health'] for d in s['drone_details']),
        drone_0=dict(final_snapshots=details[0]['group_final_snapshot_count'],yielding_at_end=details[0]['group_yielding_at_end'],
            ready_at_end=details[0]['group_submission_ready'],ordinary_selection=details[0]['group_ordinary_selection'],
            slot=details[0]['group_end_slot'],audit=details[0]['group_audit'],deadline_event=details[0]['walltime_submission'],
            submitted=any(v['drone']==0 for v in s['submissions'])),
        drone_1=dict(final_snapshots=details[1]['group_final_snapshot_count'],ready_at_end=details[1]['group_submission_ready'],
            cached_image_sha256=details[1]['group_cached_image_sha256'],cache=details[1]['group_best_metadata'],
            audit=details[1]['group_audit'],submitted=any(v['drone']==1 for v in s['submissions'])))
arms={label:summary(s) for label,s in scores.items()}
fields=['partial_score_out_of_80','map_score','wall_score','time_score','submission_step','submission_walltime_seconds',
        'final_walltime_seconds','placed','exploration_percent','missed_wall_pixels','charged_misdraw_pixels','total_health_lost']
deltas={label:{key:arms['candidate'][key]-arms[label][key] for key in fields} for label in histories}
components={label:dict(map=.5*d['map_score'],wall=.2*d['wall_score'],time=.1*d['time_score']) for label,d in deltas.items()}
for label in components:assert math.isclose(sum(components[label].values()),deltas[label]['partial_score_out_of_80'],abs_tol=1e-9)
same={label:grids['candidate']==grid for label,grid in grids.items() if label!='candidate'}
candidate=arms['candidate']
outcome=dict(zero_ordinary_ready=candidate['drone_0']['ready_at_end'],zero_guard_yielding_at_end=candidate['drone_0']['yielding_at_end'],
    zero_submitted=candidate['drone_0']['submitted'],one_submitted=candidate['drone_1']['submitted'],
    one_holds_bitmap_identical_to_V16=candidate['drone_1']['cached_image_sha256']==arms['V16']['selected_map_sha256'],
    actual_selected_bitmap_identical_to_V16=same['V16'],actual_selected_bitmap_identical_to_V17=same['V17'],
    low_walltime_yield_condition_exercised=(candidate['submission_walltime_seconds']>168. and candidate['drone_0']['yielding_at_end']
        and candidate['drone_0']['ready_at_end'] and 3444<=candidate['submission_step']<3474),
    soft_cutoff_exit_used=candidate['submission_mode']=='soft_cutoff',hard_fallback_used=candidate['deadline_event'] is not None)

def npy(path,key):
    with ZipFile(path) as archive:raw=archive.read(key+'.npy')
    offset=10 if raw[6]==1 else 12
    length=struct.unpack('<H' if offset==10 else '<I',raw[8:offset])[0]
    return ast.literal_eval(raw[offset:offset+length].decode('latin1').strip()),raw[offset+length:]
timings={}
for label,path in {**histories,'candidate':received}.items():
    recording=next((path/'official/recordings').glob('*.npz'))
    header,data=npy(recording,'timestamps');assert header['descr']=='<f8' and not header['fortran_order']
    times=struct.unpack('<'+str(len(data)//8)+'d',data)
    points={str(index):times[index] for index in [999,1999,2999,3238,3240,3441,3442,3443,3448] if index<len(times)}
    gaps=sorted([(times[i]-times[i-1],i,times[i-1],times[i]) for i in range(1,len(times))],reverse=True)[:5]
    timings[label]=dict(recorded_frames=len(times),sampled_record_indices_walltime=points,largest_recorded_intervals=gaps)
binding=dict(status='PASS',candidate_zip_sha256=build['candidate_zip_sha256'],V17_zip_sha256=build['baseline_zip_sha256'],
    V16_zip_sha256='e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791',
    candidate_runtime_source=start['solutions_sha256'],historical_runtime_sources={label:s['solutions_sha256'] for label,s in starts.items() if label!='candidate'},
    post_run_source_check=read(received/'POST_RUN_SOURCE_CHECK.json'),observer_byte_identical_to_V16_V17=True,
    config_byte_identical_to_V16_V17=True,matched_sdk_seed_spawns_zones_limits=True,new_red_rounds=1,new_historical_rounds=0,
    blue_rounds=0,other_maps_run=0,official_scores_sha256={label:h(path/'OFFICIAL_SCORE.json') for label,path in {**histories,'candidate':received}.items()})
result=dict(status='COMPLETE',map='Map08',seed=615,new_red_rounds=1,other_maps_run=0,algorithm_changes=False,arms=arms,
    candidate_minus=deltas,score_delta_components=components,outcome=outcome,offline_recorded_timing=timings,source_binding=binding,
    score_scope='Red subtotal out of 80; no blue bomb-difficulty calibration or official website score.',
    timing_scope='One current candidate run versus historical V17/V16, not a newly matched timing cohort. Submission uses SDK sampled walltime; final walltime includes closing work. Replay record indices are not asserted controller steps.')
save(r/'RESULTS.json',result)
delivery=r/'delivery';delivery.mkdir(exist_ok=True)
save(delivery/'RESULTS.json',result);save(delivery/'SOURCE_BINDING.json',binding)
text='# 软应急让行候选：Map08，种子615，单次对照\n\n'
text+='本次只新跑1场当前候选Map08，不重跑V17/V16、不跑其他地图、不修改算法或SDK。\n\n'
text+='| 指标 | 已有V16 | 已有V17 | 当前候选 |\n|---|---:|---:|---:|\n'
for label,key,fmt in [('交图者','submission_drone','id'),('交图步数','submission_step','int'),('调用交图墙钟','submission_walltime_seconds','seconds'),
    ('最终墙钟','final_walltime_seconds','seconds'),('红队小计/80','partial_score_out_of_80','float'),('地图分','map_score','float'),('实投数','placed','int')]:
    def display(v):return str(v)+'号' if fmt=='id' else str(v) if fmt=='int' else f'{v:.6f}'+('秒' if fmt=='seconds' else '')
    text+='| '+label+' | '+' | '.join(display(arms[k][key]) for k in ['V16','V17','candidate'])+' |\n'
text+='\n## 交图协调核对\n\n'
text+='`'+json.dumps(outcome,ensure_ascii=False)+'`\n\n'
text+=f"0号末帧最终快照{candidate['drone_0']['final_snapshots']}份，普通交图就绪={candidate['drone_0']['ready_at_end']}，首轮让行={candidate['drone_0']['yielding_at_end']}，实际提交={candidate['drone_0']['submitted']}。1号最终快照{candidate['drone_1']['final_snapshots']}份，实际提交={candidate['drone_1']['submitted']}，其缓存是否与V16成功提交图相同={outcome['one_holds_bitmap_identical_to_V16']}。\n\n"
text+=f"最终采用{candidate['submission_drone']}号，方式为`{candidate['submission_mode']}`，结算后距离180秒上限仍有{candidate['remaining_walltime_at_finish']:.6f}秒。提交记录：`{json.dumps(candidate['all_submissions'],ensure_ascii=False)}`。\n\n"
text+=f"相比V17小计变化{deltas['V17']['partial_score_out_of_80']:+.6f}，地图变化{deltas['V17']['map_score']:+.6f}；相比V16小计变化{deltas['V16']['partial_score_out_of_80']:+.6f}，地图变化{deltas['V16']['map_score']:+.6f}。实际提交图是否逐字节相同：`{json.dumps(same)}`。\n\n"
text+='候选改动仅删除不足12秒取消首轮让行的条件，其他55个成员不变，5秒硬兜底保留。运行前后56成员及实际ZIP均校验；SDK/种子/出生点/区域/时限/线程与历史一致，观测脚本逐字节相同。历史和本次的每步耗时可能不同，不能把墙钟差异全部算作算法加速。数据中的低墙钟触发标记区分是否真正覆盖该应急条件，避免仅凭1号交好图就声称已经覆盖软应急。\n\n'
text+='得分为红队小计/80，不含蓝队炸弹难度校准，不是官网校准总分。调用交图墙钟为SDK采样，最终墙钟包含收尾；离线时间核对只读取已有回放，没有追加控制/物理仿真。\n\n'
text+='候选原件：[软应急让行研究候选](https://github.com/quanliangwen/1/tree/4dcedba1cfa3db5b303377c3af47ddde857d7b1b/team615_research/V17_soft_emergency_yield_20261121)。历史：[V17 Map08](https://github.com/quanliangwen/1/tree/8a34bd46c5a846b0da22621c41b16ca5248b0e88/team615_tests/V17_Map06_Map08_seed615_20261121)、[V16 Map08](https://github.com/quanliangwen/1/tree/cb079a122091ddee1f14e5bba4327260e91e82b3/team615_red_v15/first_round_yield_maps_20261121)。\n'
(delivery/'README.md').write_text(text,encoding='utf8')
with ZipFile(delivery/'RUN_EVIDENCE.zip','w',compression=ZIP_DEFLATED) as archive:
    for p in sorted(received.rglob('*')):
        if p.is_file():archive.write(p,'candidate/'+p.relative_to(received).as_posix())
    for label,path in histories.items():
        for name in ['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','POST_RUN_SOURCE_CHECK.json']:
            archive.write(path/name,label+'/'+name)
        for p in (path/'official').glob('*_exploration.json'):archive.write(p,label+'/official/'+p.name)
    for name in ['stage_run.py','run_once.sh','place_map09.yml','OBSERVATION_BINDING.json','PATCH_BINDING.json','BUILD.json',
                 'OFFLINE_CHECK.json','DECLARED_SOURCE.json','matched_spawns.json','EXPECTED_ZONES.json']:
        archive.write(folder/name,'harness/'+name)
    for name in ['AUTHORIZED_RUN.json','provision.py','collect_report.py','SDK_SELECTION_EVIDENCE.json']:
        archive.write(r/name,'harness/'+name)
save(delivery/'CHECKSUMS_SHA256.json',{p.name:h(p) for p in sorted(delivery.iterdir()) if p.is_file() and p.name!='CHECKSUMS_SHA256.json'})
brief={label:{key:arm[key] for key in ['submission_drone','submission_step','submission_walltime_seconds','final_walltime_seconds',
    'partial_score_out_of_80','map_score','placed','submission_mode']} for label,arm in arms.items()}
print(json.dumps(dict(arms=brief,deltas=deltas,outcome=outcome,offline_recorded_timing=timings),indent=2,ensure_ascii=False))
