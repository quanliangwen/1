from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile, ZIP_DEFLATED
import json

r=Path(__file__).resolve().parent
result=json.loads((r/'RESULTS.json').read_bytes())
c=result['arms']['candidate'];outcome=result['outcome']
assert not outcome['zero_submitted'] and outcome['zero_guard_yielding_at_end']
assert outcome['one_submitted'] and outcome['actual_selected_bitmap_identical_to_V16']
assert c['submission_drone']==1 and c['submission_step']==3452
assert not outcome['low_walltime_yield_condition_exercised'] and not outcome['hard_fallback_used']
findings=dict(status='CONFIRMED',candidate_zip_sha256=result['source_binding']['candidate_zip_sha256'],
    zero_yielded=True,one_submitted_good_bitmap=True,selected_bitmap_identical_to_V16=True,
    soft_emergency_actual_match_coverage=False,
    reason='This run finished at 154.379s with 25.621s left and did not enter the <12-second soft emergency condition.',
    interpretation='The run confirms the normal submission path and good-map result, but cannot causally attribute recovery versus the slower V17 run to the newly changed low-walltime guard. Soft-emergency-specific evidence remains the synthetic counterexamples.',
    new_red_rounds=1,other_maps_run=0,additional_simulation_for_analysis=0)
(r/'REPORT_INTERPRETATION.json').write_text(json.dumps(findings,indent=2)+'\n',encoding='utf8')
p=r/'delivery/README.md';text=p.read_text(encoding='utf8')
marker='\n## 交图协调核对\n'
assert text.count(marker)==1
paragraph=(f"\n本次结果：0号让行且未提交，1号在3452步交图，实际图片与V16逐字节相同；红队小计恢复至52.641344。但本次结束于{c['final_walltime_seconds']:.6f}秒，仍余{c['remaining_walltime_at_finish']:.6f}秒，未进入不足12秒的软应急阶段。因此这次实测确认正常交图路径没有回退，不能单凭本次对照声称新软应急条件已经实战验证或导致提分；该特定条件目前仍由139组反例中的相关用例提供证据。\n")
p.write_text(text.replace(marker,paragraph+marker),encoding='utf8')
with ZipFile(r/'delivery/RUN_EVIDENCE.zip','a',compression=ZIP_DEFLATED) as archive:
    assert 'offline/REPORT_INTERPRETATION.json' not in archive.namelist()
    archive.write(r/'REPORT_INTERPRETATION.json','offline/REPORT_INTERPRETATION.json')
    archive.write(r/'finalize_findings.py','offline/finalize_findings.py')
manifest={p.name:sha256(p.read_bytes()).hexdigest() for p in sorted((r/'delivery').iterdir()) if p.is_file() and p.name!='CHECKSUMS_SHA256.json'}
(r/'delivery/CHECKSUMS_SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
print(json.dumps(findings,indent=2))
