from pathlib import Path, PurePosixPath
from hashlib import sha256
from zipfile import ZipFile, ZIP_DEFLATED
import argparse
import ast
import json
import math
import struct
import subprocess

r=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('map',choices=['Map06','Map09']);name=parser.parse_args().map
folder=r/name;received=folder/'received'
host='quanliangwen@10.112.162.60';remote=(r/'SERVER_STAGE.txt').read_text().strip()+'/'+name
if name=='Map06':
    histories={'V16':r.parent/'team615_first_round_yield_map06_20261121/Map06/received',
               'V17':r.parent/'team615_v17_map06_map08_seed615_20261121/Map06/received'}
else:
    histories={'V16':r.parent/'team615_first_round_yield_maps_20261121/Map09/received',
               'V17':r.parent/'team615_v17_map09_seed615_20261121/Map09/received'}
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def download(paths,destination):
    destination.mkdir(parents=True,exist_ok=True)
    subprocess.run(['scp','-q','-o','BatchMode=yes',*[host+':'+p for p in paths],str(destination)],check=True)

files=['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','placement_events.jsonl','run.log','dispatch.log',
       'wall_geometry.npz','group_dataset.npz','GROUP_DATASET.json','POST_RUN_SOURCE_CHECK.json','EXTRA_ARTIFACTS.json']
download([remote+'/'+n for n in files],received)
end=read(received/'FINISH.json')
assert (end['status'],end['completed_red_rounds'],end['blue_rounds'],end['layout_evaluations'])==('COMPLETE',1,0,0)
official=PurePosixPath(end['result_dir']);assert official.is_relative_to(PurePosixPath(remote)/'official_sdk/results_swarm_rescue')
for file,digest in end['files'].items():
    path=PurePosixPath(file);assert not path.is_absolute() and '..' not in path.parts
    download([str(official/path)],received/'official'/path.parent)
    assert h(received/'official'/file)==digest
for file,digest in read(received/'EXTRA_ARTIFACTS.json').items():assert h(received/file)==digest
build=read(r/'BUILD.json');start=read(received/'START.json')
assert h(r/'candidate_snapshot.zip')==build['candidate_zip_sha256']=='3b7053616c45ee965bfca5f4d9ba08fbbcc1f167f9a8a9e4faa5ec1e6d8a30ed'
assert h(r/'baseline_snapshot.zip')==build['baseline_zip_sha256']=='0aaed704f050073b664d4c0bece9f9ff6500e59edf55c78a7284036f01c167e7'
assert start['solutions_sha256']==read(received/'SOURCE_MATCH.json')['candidate']==build['candidate_files']
assert read(received/'POST_RUN_SOURCE_CHECK.json')['status']=='PASS'
assert (start['seed'],start['map_name'],start['drones'],start['bombs_per_drone'],start['timestep_limit'],start['walltime_limit'])==(615,name,5,2,5400,180)
assert start['sdk']=='6557940dc18549ffc7a945db887da5b05b7ed2f1'
v16_files=read(r.parent/'team615_red_v16_first30_release_20261121/BUILD.json')['payload_files_sha256']
scores={};grids={};starts={}
for label,path in {**histories,'candidate':received}.items():
    s=read(path/'OFFICIAL_SCORE.json');other=read(path/'START.json');scores[label]=s;starts[label]=other
    assert other['solutions_sha256']==(build['candidate_files'] if label=='candidate' else build['original_files'] if label=='V17' else v16_files)
    for key in ['seed','sdk','sdk_archive_sha256','map_name','drones','bombs_per_drone','timestep_limit','walltime_limit','competition_mode','spawn','zones']:
        assert start[key]==other[key],(label,key)
    assert h(folder/'place_map09.yml')==h(path.parent/'place_map09.yml'),(label,'config_bytes')
    assert h(r/'stage_run.py')==h(path.parent/'stage_run.py'),(label,'observer_bytes')
    assert h(path/'placement_events.jsonl')==s['placement_events_sha256'] and h(path/'wall_geometry.npz')==s['wall_geometry_sha256']
    for file,digest in read(path/'FINISH.json')['files'].items():assert h(path/'official'/file)==digest
    assert s['submitted_map'] and s['selected_submission']['image_sha256']==s['selected_image_sha256']
    assert math.isclose(s['partial'],.5*s['map_score']+.2*s['coverage']+.1*s['time_score'],abs_tol=1e-9)
    assert len(read(next((path/'official').glob('*_bombs.json')))['bombs'])==s['placed']
    grid=read(next((path/'official').glob('*_exploration.json')))['grid'];grids[label]=grid
    assert sha256(bytes(x for row in grid for x in row)).hexdigest()==s['selected_image_sha256']
log=(received/'dispatch.log').read_text(encoding='utf8')
assert log.count('START '+name+' soft_emergency_yield seed615')==1 and log.count('COMPLETE '+name+' soft_emergency_yield seed615')==1
assert not any('START '+other in log for other in ['Map06','Map08','Map09'] if other!=name)

def summary(s):
    selected=s['selected_submission'];details={d['drone']:d for d in s['drone_details']}
    chosen=details[selected['drone']];event=chosen['walltime_submission']
    submits=[e for e in chosen['group_audit'] if e[1] in ('soft_cutoff_submit','submitted')]
    mode=event.get('fallback','deadline_election') if event is not None else 'soft_cutoff' if any(e[1]=='soft_cutoff_submit' for e in submits) else 'ordinary'
    per={}
    for owner,d in details.items():
        records=d['final_inventory_records']
        zero_all=len(records)==5 and all(value[1]==0 for value in records.values())
        per[str(owner)]=dict(ordinary_selection_ever_opened=d['group_ordinary_selection'],ordinary_ready_at_end=d['group_submission_ready'],
            guard_yielding_at_end=d['group_yielding_at_end'],final_snapshots=d['group_final_snapshot_count'],
            all_inventory_zero_known_at_end=zero_all,final_inventory_records=records,deadline_event=d['walltime_submission'],
            candidate_cache=d['group_best_metadata'],cached_image_sha256=d['group_cached_image_sha256'],
            yield_window=d['group_first_round_window'],submission_slot=d['group_end_slot'],group_audit=d['group_audit'])
    return dict(partial_score_out_of_80=s['partial'],map_score=s['map_score'],wall_score=s['coverage'],time_score=s['time_score'],
        submission_drone=selected['drone'],submission_step=selected['step'],submission_walltime_seconds=selected['walltime_seconds'],
        final_walltime_seconds=s['elapsed_walltime'],remaining_walltime_at_finish=180.-s['elapsed_walltime'],placed=s['placed'],expected=s['expected'],
        exploration_percent=s['trajectory'],selected_map_sha256=s['selected_image_sha256'],all_submissions=s['submissions'],
        submission_mode=mode,deadline_event=event,selected_cache=chosen['group_best_metadata'],
        missed_wall_pixels=s['map_breakdown']['wall_pixels']-s['map_breakdown']['wall_hits'],charged_misdraw_pixels=s['map_breakdown']['charged_pixels'],
        total_health_lost=sum(25-d['health'] for d in s['drone_details']),per_drone=per,
        per_drone_last_confirmation={str(owner):d['last_confirmation'] for owner,d in details.items()})
arms={label:summary(s) for label,s in scores.items()}
fields=['partial_score_out_of_80','map_score','wall_score','time_score','submission_step','submission_walltime_seconds',
        'final_walltime_seconds','placed','exploration_percent','missed_wall_pixels','charged_misdraw_pixels','total_health_lost']
deltas={label:{key:arms['candidate'][key]-arms[label][key] for key in fields} for label in histories}
components={label:dict(map=.5*d['map_score'],wall=.2*d['wall_score'],time=.1*d['time_score']) for label,d in deltas.items()}
for label in components:assert math.isclose(sum(components[label].values()),deltas[label]['partial_score_out_of_80'],abs_tol=1e-9)
same={label:grids['candidate']==grid for label,grid in grids.items() if label!='candidate'}
new=arms['candidate'];per=new['per_drone']
assessment=dict(any_ordinary_selection_ever_opened=any(d['ordinary_selection_ever_opened'] for d in per.values()),
    any_ordinary_ready_at_end=any(d['ordinary_ready_at_end'] for d in per.values()),
    any_all_stock_zero_known_at_end=any(d['all_inventory_zero_known_at_end'] for d in per.values()),
    static_guard_values_at_end={owner:d['guard_yielding_at_end'] for owner,d in per.items()},
    actual_exit=new['submission_mode'],hard_fallback_used=(new['deadline_event'] is not None and new['deadline_event'].get('fallback') in ('walltime','timestep')),
    deadline_exit_used=new['deadline_event'] is not None,
    actual_selected_bitmap_identical_to=same,
    interpretation='Static guard=True alone does not prove waiting. Check ordinary eligibility and actual exit; missing team stock confirmation returns before first-round yield.')

def npy(path,key):
    with ZipFile(path) as archive:raw=archive.read(key+'.npy')
    offset=10 if raw[6]==1 else 12
    length=struct.unpack('<H' if offset==10 else '<I',raw[8:offset])[0]
    return ast.literal_eval(raw[offset:offset+length].decode('latin1').strip()),raw[offset+length:]
timings={}
for label,path in {**histories,'candidate':received}.items():
    recording=next((path/'official/recordings').glob('*.npz'))
    header,data=npy(recording,'timestamps');assert header['descr']=='<f8' and not header['fortran_order']
    times=struct.unpack('<'+str(len(data)//8)+'d',data)
    indices=[999,1999,2999,3295,3499,3999,4342,4499,4588,4993]
    timings[label]=dict(recorded_frames=len(times),sampled_record_indices_walltime={str(i):times[i] for i in indices if i<len(times)},
        largest_recorded_intervals=sorted([(times[i]-times[i-1],i,times[i-1],times[i]) for i in range(1,len(times))],reverse=True)[:5])
binding=dict(status='PASS',candidate_zip_sha256=build['candidate_zip_sha256'],V17_zip_sha256=build['baseline_zip_sha256'],
    V16_zip_sha256='e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791',
    candidate_runtime_source=start['solutions_sha256'],historical_runtime_sources={label:s['solutions_sha256'] for label,s in starts.items() if label!='candidate'},
    post_run_source_check=read(received/'POST_RUN_SOURCE_CHECK.json'),observer_byte_identical_to_V16_V17=True,
    config_byte_identical_to_V16_V17=True,matched_sdk_seed_spawns_zones_limits=True,new_red_rounds=1,new_historical_rounds=0,
    blue_rounds=0,outside_authorized_maps_run=0,official_scores_sha256={label:h(path/'OFFICIAL_SCORE.json') for label,path in {**histories,'candidate':received}.items()})
result=dict(status='COMPLETE',map=name,seed=615,new_red_rounds=1,algorithm_changes=False,arms=arms,candidate_minus=deltas,
    score_delta_components=components,yield_assessment=assessment,offline_recorded_timing=timings,source_binding=binding,
    score_scope='Red subtotal out of 80; no blue bomb-difficulty calibration or official website score.',
    timing_scope='One current candidate run versus existing V17/V16, no fresh matched timing cohort. SDK sampled submission time differs from final walltime including closing.')
save(folder/'RESULTS.json',result)
with ZipFile(folder/'RUN_EVIDENCE.zip','w',compression=ZIP_DEFLATED) as archive:
    for p in sorted(received.rglob('*')):
        if p.is_file():archive.write(p,'candidate/'+p.relative_to(received).as_posix())
    for label,path in histories.items():
        for file in ['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','POST_RUN_SOURCE_CHECK.json']:
            archive.write(path/file,label+'/'+file)
        for p in (path/'official').glob('*_exploration.json'):archive.write(p,label+'/official/'+p.name)
    for file in ['stage_run.py','run_once.sh','place_map09.yml','OBSERVATION_BINDING.json','PATCH_BINDING.json','BUILD.json',
                 'OFFLINE_CHECK.json','DECLARED_SOURCE.json','matched_spawns.json','EXPECTED_ZONES.json']:
        archive.write(folder/file,'harness/'+file)
    for file in ['AUTHORIZED_RUN.json','provision.py','collect_one.py','SDK_SELECTION_EVIDENCE.json']:
        archive.write(r/file,'harness/'+file)
brief={label:{key:arm[key] for key in ['submission_drone','submission_step','submission_walltime_seconds','final_walltime_seconds',
    'partial_score_out_of_80','map_score','placed','submission_mode','selected_cache']} for label,arm in arms.items()}
print(json.dumps(dict(map=name,arms=brief,deltas=deltas,yield_assessment=assessment),indent=2,ensure_ascii=False))
