from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json
import shutil
import subprocess

r=Path(__file__).resolve().parent
candidate=r.parent/'team615_v17_soft_emergency_yield_20261121'
prior=r.parent/'team615_v17_map06_map08_seed615_20261121'
prior9=r.parent/'team615_v17_map09_seed615_20261121'
host='quanliangwen@10.112.162.60'
remote='/home/quanliangwen/isolated_test/team615_soft_yield_map06_map09_seed615_20261121'
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
save=lambda p,v:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
build=read(candidate/'BUILD.json');validation=read(candidate/'VALIDATION.json');counter=read(candidate/'counterexamples.json')
assert build['status']==validation['status']==counter['status']=='PASS' and counter['scenario_groups']==139
assert h(candidate/'candidate_snapshot.zip')==h(candidate/'delivery/CANDIDATE_SOURCE.zip')==build['candidate_zip_sha256']==validation['candidate_zip_sha256']==counter['archive_sha256']=='3b7053616c45ee965bfca5f4d9ba08fbbcc1f167f9a8a9e4faa5ec1e6d8a30ed'
assert h(candidate/'baseline_snapshot.zip')==build['baseline_zip_sha256']=='0aaed704f050073b664d4c0bece9f9ff6500e59edf55c78a7284036f01c167e7'
assert build['changed_existing_files']==['group_exchange.py'] and build['unchanged_files']==55
(r/'SERVER_STAGE.txt').write_text(remote+'\n',encoding='utf8')
save(r/'AUTHORIZED_RUN.json',dict(maps=['Map06','Map09'],seed=615,new_red_rounds_per_map=1,new_red_rounds=2,
    blue_rounds=0,rerun_V16=False,rerun_V17=False,rerun_Map08=False,algorithm_changes=False,candidate_zip_sha256=build['candidate_zip_sha256']))
for name in ['candidate_snapshot.zip','baseline_snapshot.zip','BUILD.json','VALIDATION.json','counterexamples.json']:
    shutil.copyfile(candidate/name,r/name)
save(r/'PATCH_BINDING.json',dict(baseline_commit=build['baseline_commit'],baseline_zip_sha256=build['baseline_zip_sha256'],
    candidate_zip_sha256=build['candidate_zip_sha256'],baseline=build['original_files'],candidate=build['candidate_files'],changed=build['changed_existing_files']))
save(r/'DECLARED_SOURCE.json',build['candidate_files'])
save(r/'OFFLINE_CHECK.json',dict(simulation_steps=0,unit_groups=139,validation_sha256=h(candidate/'VALIDATION.json')))
for name in ['stage_run.py','matched_spawns.json','EXPECTED_ZONES.json','SDK_SELECTION_EVIDENCE.json']:
    shutil.copyfile(prior/name,r/name)
assert h(r/'stage_run.py')==h(prior/'Map06/stage_run.py')==h(prior9/'Map09/stage_run.py')
with ZipFile(r/'candidate_snapshot.zip') as a,ZipFile(r/'baseline_snapshot.zip') as b:
    assert a.testzip() is None and a.namelist()==b.namelist() and len(a.namelist())==56
    assert {n:sha256(a.read(n)).hexdigest() for n in a.namelist()}==build['candidate_files']
    assert [n for n in a.namelist() if a.read(n)!=b.read(n)]==['group_exchange.py']
    assert a.read('deadline_submission.py')==b.read('deadline_submission.py')
subprocess.run(['ssh','-o','BatchMode=yes',host,'mkdir '+remote],check=True)
for map_name,old_root in [('Map06',prior),('Map09',prior9)]:
    f=r/map_name;f.mkdir(exist_ok=False)
    for name in ['stage_run.py','candidate_snapshot.zip','baseline_snapshot.zip','DECLARED_SOURCE.json','PATCH_BINDING.json',
                 'BUILD.json','VALIDATION.json','counterexamples.json','matched_spawns.json','EXPECTED_ZONES.json','OFFLINE_CHECK.json']:
        shutil.copyfile(r/name,f/name)
    shutil.copyfile(old_root/map_name/'place_map09.yml',f/'place_map09.yml')
    run=(old_root/map_name/'run_once.sh').read_text(encoding='utf8').replace('v17_wallmargin5','soft_emergency_yield')
    (f/'run_once.sh').write_text(run,encoding='utf8',newline='\n')
    save(f/'OBSERVATION_BINDING.json',dict(observer_sha256=h(f/'stage_run.py'),observer_byte_identical_to_V17_and_V16=True,
        config_byte_identical_to_V17_and_V16=h(f/'place_map09.yml')==h(old_root/map_name/'place_map09.yml'),
        map=map_name,seed=615,controller_frozen_sha256=build['candidate_zip_sha256'],new_red_rounds_authorized=1))
    subprocess.run(['ssh','-o','BatchMode=yes',host,'mkdir '+remote+'/'+map_name],check=True)
    subprocess.run(['scp','-q','-o','BatchMode=yes',*[str(p) for p in sorted(f.iterdir())],host+':'+remote+'/'+map_name+'/'],check=True)
dispatch='''set -euo pipefail
root="$1"
bash "$root/Map06/run_once.sh" "$root/Map06" > "$root/Map06/dispatch.log" 2>&1
bash "$root/Map09/run_once.sh" "$root/Map09" > "$root/Map09/dispatch.log" 2>&1
printf 'COMPLETE ONLY MAP06 MAP09 SOFT_YIELD SEED615\\n'
'''
(r/'dispatch.sh').write_text(dispatch,encoding='utf8',newline='\n')
subprocess.run(['scp','-q','-o','BatchMode=yes',str(r/'dispatch.sh'),host+':'+remote+'/'],check=True)
command='nohup bash '+remote+'/dispatch.sh '+remote+' > '+remote+'/queue.log 2>&1 < /dev/null & echo QUEUED_MAP06_MAP09_SOFT_YIELD_ONCE_EACH'
p=subprocess.run(['ssh','-o','BatchMode=yes',host,command],capture_output=True,check=True,timeout=25)
print(p.stdout.decode(),flush=True);print(build['candidate_zip_sha256'],flush=True)
