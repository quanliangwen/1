from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import ast
import json
import math

r=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
maps={name:read(r/name/'RESULTS.json') for name in ['Map06','Map09']}
assert all(not v['yield_assessment']['any_ordinary_selection_ever_opened'] for v in maps.values())
assert all(not v['yield_assessment']['any_all_stock_zero_known_at_end'] for v in maps.values())
with ZipFile(r/'candidate_snapshot.zip') as candidate,ZipFile(r/'baseline_snapshot.zip') as baseline:
    assert candidate.read('closeout_departure.py')==baseline.read('closeout_departure.py')
    assert candidate.read('deadline_submission.py')==baseline.read('deadline_submission.py')
    closeout=candidate.read('closeout_departure.py').decode()
    assert 'ENTER_WALL = 25.0' in closeout
    tree=ast.parse(closeout)
    enter=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='_should_enter')
    gate_source=ast.get_source_segment(closeout,enter)

old9=r.parent/'team615_v17_map09_seed615_20261121/Map09/received'
new9=r/'Map09/received'
def accepted(path):
    rows=[json.loads(line) for line in (path/'placement_events.jsonl').read_text().splitlines()]
    counts={};points={}
    for row in rows:
        if row.get('event')=='sdk_placement' and row.get('accepted'):
            owner=row['drone'];counts[owner]=counts.get(owner,0)+1
            points[(owner,counts[owner])]=row
    return points
old_points=accepted(old9);new_points=accepted(new9)
assert len(old_points)==len(new_points)==10 and set(old_points)==set(new_points)
different=[key for key in new_points if new_points[key]['physical_xy']!=old_points[key]['physical_xy']]
old_score=read(old9/'OFFICIAL_SCORE.json');new_score=read(new9/'OFFICIAL_SCORE.json')
details={d['drone']:d for d in new_score['drone_details']}
old_details={d['drone']:d for d in old_score['drone_details']}
old_geom=old9/'wall_geometry.npz';new_geom=new9/'wall_geometry.npz'
with ZipFile(old_geom) as a,ZipFile(new_geom) as b:
    same_geometry=a.namelist()==b.namelist() and all(a.read(n)==b.read(n) for n in a.namelist())
assert same_geometry
last_old=old_points[(1,2)];last_new=new_points[(1,2)]
findings=dict(status='CONFIRMED_FROM_EXISTING_RESULTS_LOGS_AND_SOURCE',new_simulation_for_analysis=0,
    no_misyield_observed=True,
    evidence='All five ordinary-selection flags remained false and no aircraft knew all five zero-inventory records at finish; ordinary stock confirmation gates precede first-round yield. Both maps ended through the unchanged wall-clock hard fallback.',
    Map06=dict(bitmap_identical_to_V17=maps['Map06']['yield_assessment']['actual_selected_bitmap_identical_to']['V17'],
        candidate_minus_V17=maps['Map06']['candidate_minus']['V17'],score_components=maps['Map06']['score_delta_components']['V17'],
        interpretation='Same submitted map and 10 placements as V17; 206 more steps under essentially the same 175s final wall clock reduced the timestep bonus by 0.544974. No added first-round waiting was observed.'),
    Map09=dict(same_wall_geometry_arrays=same_geometry,changed_accepted_placements=[list(key) for key in different],
        other_accepted_placements_identical=len(new_points)-len(different),last_bomb_V17=last_old,last_bomb_candidate=last_new,
        candidate_last_bomb_distance_from_first=math.dist(last_new['physical_xy'],new_points[(1,1)]['physical_xy']),
        unchanged_closeout_enter_wall_seconds=25.,unchanged_closeout_entry_source=gate_source,
        candidate_closeout_audit=details[1]['closeout_departure_audit'],
        candidate_last_confirmation=details[1]['last_confirmation'],V17_last_confirmation=old_details[1]['last_confirmation'],
        candidate_cache=maps['Map09']['arms']['candidate']['selected_cache'],V17_cache=maps['Map09']['arms']['V17']['selected_cache'],
        candidate_zero_map_revisions=details[0]['final_source_versions'],V17_zero_map_revisions=old_details[0]['final_source_versions'],
        candidate_wall_score=new_score['coverage'],V17_wall_score=old_score['coverage'],
        timing_at_record999={label:values['sampled_record_indices_walltime']['999'] for label,values in maps['Map09']['offline_recorded_timing'].items()},
        interpretation='This run progressed more slowly before the changed first-round guard could execute. The unchanged 25s closeout fired at step3701, moved drone1 last placement to step3725 near its first bomb, and confirmed at3726. Hard cutoff4053 preceded the historical late map delivery/cache4590, so the actual Map09 map/wall gains were not preserved in this run. Exact system-load cause is unmeasured; do not attribute these changes to the unexecuted yield rule.'),
    comparison_boundary='Each current map ran once against existing V17/V16 cohorts. Timing load was not controlled; no causal performance upgrade is established.')
(r/'FINDINGS.json').write_text(json.dumps(findings,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(dict(no_misyield_observed=True,changed_placements=different,
    other_placements_identical=10-len(different),Map09_cache_new=details[0]['group_best_metadata'],Map09_last_confirmation=details[1]['last_confirmation']),indent=2))
