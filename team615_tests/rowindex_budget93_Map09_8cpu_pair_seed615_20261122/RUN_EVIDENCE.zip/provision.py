from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import ast,json,shutil,subprocess
ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'team615_rowindex_budget93_20261122'
TEMPLATE=ROOT.parent/'team615_budget93_maps08_09_seed615_20261122/Map09'
HOST='quanliangwen@10.112.162.60';REMOTE='/home/quanliangwen/isolated_test/'+ROOT.name
H=lambda p:sha256(p.read_bytes()).hexdigest()
save=lambda p,d:p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
build=json.loads((SRC/'BUILD.json').read_text());assert build['status']=='PASS'
assert H(SRC/'rowindex_baseline_snapshot.zip')=='1dfbbfd4186063edb908bd7cb1f812a0e8956a69901f28988f632acee2c70784'
assert H(SRC/'candidate_snapshot.zip')=='0ed2e45090a6a8104c0a3bf92d8ac79382a7891eccb978ffaba8a72a2b06a449'
observer=(TEMPLATE/'stage_run.py').read_text(encoding='utf8')
observer=observer.replace('import gc\n','import gc\nimport time\n')
needle='audit_stream = (stage/"placement_events.jsonl").open("x",encoding="utf8",buffering=1)'
assert observer.count(needle)==1
observer=observer.replace(needle,needle+'\ntiming_stream = (stage/"TIMING_ANCHORS.jsonl").open("x",encoding="utf8",buffering=1)\nTIMING_STEPS = {1,501,1001,1501,2001,2501,3001,3240,3501,4001,4340,4501,4590,4751,4950,4991,5021,5022,5030,5051,5251}')
needle='        step = int(drone.elapsed_timestep)\n        prior_wall = drone.team_wall.reservation'
assert observer.count(needle)==1
observer=observer.replace(needle,'''        step = int(drone.elapsed_timestep)
        if drone.identifier == 0 and step in TIMING_STEPS:
            timing_stream.write(json.dumps(dict(step=step, walltime=float(drone.elapsed_walltime),
                host_monotonic=time.monotonic(), host_unix=time.time()))+"\\n")
        prior_wall = drone.team_wall.reservation''')
observer=observer.replace('audit_stream.close()','audit_stream.close()\ntiming_stream.close()')
observer=observer.replace('budget_submission=d.budget_submission_event,budget_submission_audit=d.budget_submission_audit,',"budget_submission=getattr(d,'budget_submission_event',None),budget_submission_audit=getattr(d,'budget_submission_audit',[]),")
assert observer.count('timing_stream.write')==1
for label in ['rowindex','budget93']:
    stage=ROOT/label;stage.mkdir()
    source=SRC/('rowindex_baseline_snapshot.zip' if label=='rowindex' else 'candidate_snapshot.zip')
    shutil.copyfile(source,stage/'candidate_snapshot.zip');shutil.copyfile(SRC/'rowindex_baseline_snapshot.zip',stage/'baseline_snapshot.zip')
    with ZipFile(source) as z:files={n:sha256(z.read(n)).hexdigest() for n in z.namelist()}
    assert files==build['baseline_files' if label=='rowindex' else 'candidate_files']
    save(stage/'DECLARED_SOURCE.json',files)
    save(stage/'PATCH_BINDING.json',dict(baseline_commit='310cc3af98d6f1ca93e81b3cebe54b8f249421f5',baseline_zip_sha256=build['baseline_zip_sha256'],candidate_zip_sha256=H(source),baseline=build['baseline_files'],candidate=files,changed=[] if label=='rowindex' else build['changed_files']))
    save(stage/'OFFLINE_CHECK.json',dict(simulation_steps=0,verification='frozen existing archives; no source edits'))
    for n in ['place_map09.yml','matched_spawns.json','EXPECTED_ZONES.json']:shutil.copyfile(TEMPLATE/n,stage/n)
    (stage/'stage_run.py').write_text(observer,encoding='utf8',newline='\n')
    (stage/'run_monitored.sh').write_text((TEMPLATE/'run_monitored.sh').read_text().replace(' budget93 ',' '+label+' '),encoding='utf8',newline='\n')
assert H(ROOT/'rowindex/stage_run.py')==H(ROOT/'budget93/stage_run.py')
helper=(ROOT.parent/'team615_v16_rowindex_map09_pair_20261122/affinity_runner.py').read_text().split("save(ROOT/'HOST.json'")[0]
(ROOT/'monitor.py').write_text(helper+(ROOT/'monitor_body.txt').read_text(),encoding='utf8',newline='\n')
shutil.copyfile(ROOT.parent/'team615_v16_rowindex_map09_pair_20261122/environment.py',ROOT/'environment.py')
save(ROOT/'AUTHORIZED_RUN.json',dict(maps=['Map09'],seed=615,total_red_rounds=2,versions=['rowindex','budget93'],rounds_per_version=1,retries=False,algorithm_changes=False,other_maps=False,V16_remains_competition_baseline=True,whole_server_lowload_required=True,cpu_busy_percent_max=15,load1_max=32,global_stable_seconds=30,physical_cores=16,selected_each_logical_cpu_busy_percent_max=5,selected_stable_seconds_min=10,allow_core_change_after_first_start=False,allow_relaxation=False))
save(ROOT/'OBSERVER_BINDING.json',dict(observer_sha256=H(ROOT/'rowindex/stage_run.py'),same_observer_both_versions=True,original_observer_sha256=H(TEMPLATE/'stage_run.py'),changes='same sparse host/SDK timing anchors for both arms; optional budget attributes in post-score export only',timing_steps=[1,501,1001,1501,2001,2501,3001,3240,3501,4001,4340,4501,4590,4751,4950,4991,5021,5022,5030,5051,5251]))
for p in [*ROOT.glob('*.py'),*ROOT.glob('*/stage_run.py')]:ast.parse(p.read_text())
subprocess.run(['ssh',HOST,'mkdir '+REMOTE],check=True)
subprocess.run(['scp','-q',*[str(ROOT/n) for n in ['monitor.py','environment.py','AUTHORIZED_RUN.json','OBSERVER_BINDING.json']],HOST+':'+REMOTE+'/'],check=True)
for label in ['rowindex','budget93']:
    subprocess.run(['ssh',HOST,'mkdir '+REMOTE+'/'+label],check=True)
    subprocess.run(['scp','-q',*[str(p) for p in (ROOT/label).iterdir()],HOST+':'+REMOTE+'/'+label+'/'],check=True)
subprocess.run(['ssh',HOST,'/home/junhao/quan/parallel_test_solver/match/.venv/bin/python '+REMOTE+'/environment.py'],check=True)
print(subprocess.run(['ssh',HOST,'nohup python3 '+REMOTE+'/monitor.py > '+REMOTE+'/queue.log 2>&1 < /dev/null & echo STRICT_LOWLOAD_MAP09_PAIR_QUEUED_NO_MATCHES_YET'],capture_output=True,text=True,check=True).stdout)
