"""Download and inspect completed recordings; never run a controller."""
from pathlib import Path, PurePosixPath
from hashlib import sha256
from zipfile import ZipFile, ZIP_DEFLATED
import ast
from datetime import datetime
import json
import math
import statistics
import struct
import subprocess

ROOT=Path(__file__).resolve().parent
HOST='quanliangwen@10.112.162.60'
REMOTE='/home/quanliangwen/isolated_test/'+ROOT.name
H=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf8'))
def save(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def download(paths,dest):
    dest.mkdir(parents=True,exist_ok=True)
    subprocess.run(['scp','-q',*[HOST+':'+p for p in paths],str(dest)],check=True)
def npy(data):
    width=2 if data[6]==1 else 4
    size=int.from_bytes(data[8:8+width],'little')
    return ast.literal_eval(data[8+width:8+width+size].decode('latin1')),data[8+width+size:]
def timestamps(p):
    with ZipFile(p) as archive:
        _,b=npy(archive.read('timestamps.npy'))
    return struct.unpack('<'+'d'*(len(b)//8),b)
def distribution(values):
    values=sorted(v for v in values if v is not None)
    return dict(count=len(values),minimum=values[0],mean=statistics.mean(values),median=statistics.median(values),
                p95=values[math.ceil(.95*len(values))-1],maximum=values[-1]) if values else None

download([REMOTE+'/'+name for name in ['STATUS.json','MONITOR_CONFIG.json','HOST.json','ENVIRONMENT.json','queue_resources.jsonl','queue.log','AFFINITY_SELECTION.json','AUTHORIZED_RUN.json','OBSERVER_BINDING.json']],ROOT/'received')
assert read(ROOT/'received/STATUS.json')['state']=='COMPLETE'
(ROOT/'AUTHORIZED_RUN.json').write_bytes((ROOT/'received/AUTHORIZED_RUN.json').read_bytes())
result={};starts={};arrays={};recorded_times={};bomb_arrays={}
evidence=[]
for label in ('rowindex','budget93'):
    target=ROOT/label/'received';remote=REMOTE+'/'+label
    files=['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','placement_events.jsonl',
           'POST_RUN_SOURCE_CHECK.json','EXTRA_ARTIFACTS.json','resources.jsonl','LOWLOAD_ADMISSION.json',
           'MONITOR_FINISH.json','SDK_PID','TIMING_ANCHORS.jsonl','dispatch.log','run.log','GROUP_DATASET.json','group_dataset.npz','wall_geometry.npz']
    download([remote+'/'+name for name in files],target)
    finish=read(target/'FINISH.json')
    assert (finish['status'],finish['completed_red_rounds'],finish['blue_rounds'],finish['layout_evaluations'])==('COMPLETE',1,0,0)
    assert read(target/'POST_RUN_SOURCE_CHECK.json')['status']=='PASS'
    base=PurePosixPath(finish['result_dir']);assert base.is_relative_to(PurePosixPath(remote)/'official_sdk/results_swarm_rescue')
    for name,digest in finish['files'].items():
        rel=PurePosixPath(name);assert not rel.is_absolute() and '..' not in rel.parts
        download([str(base/rel)],target/'official'/rel.parent)
        assert H(target/'official'/name)==digest
    for name,digest in read(target/'EXTRA_ARTIFACTS.json').items():assert H(target/name)==digest
    start=read(target/'START.json');starts[label]=start
    declared=read(ROOT/label/'DECLARED_SOURCE.json')
    assert start['solutions_sha256']==declared==read(target/'SOURCE_MATCH.json')['candidate']
    assert (start['map_name'],start['seed'],start['timestep_limit'],start['walltime_limit'])==('Map09',615,5400,180)
    s=read(target/'OFFICIAL_SCORE.json');assert s['submitted_map']
    assert math.isclose(s['partial'],.5*s['map_score']+.2*s['coverage']+.1*s['time_score'],abs_tol=1e-9)
    assert H(target/'placement_events.jsonl')==s['placement_events_sha256']
    assert H(target/'wall_geometry.npz')==s['wall_geometry_sha256']
    rec=next((target/'official/recordings').glob('*.npz'))
    ts=timestamps(rec);recorded_times[label]=ts;assert len(ts)==s['steps']-1
    with ZipFile(rec) as z:
        arrays[label]=npy(z.read('drone_states.npy'))
        bomb_arrays[label]=npy(z.read('bomb_states.npy'))
    cuts=[2,1001,2001,3001,3240,3444,3474,3501,4001,4501,4590,s['steps']]
    cuts=sorted(set(v for v in cuts if v<=s['steps']))
    segments=[]
    for lo,hi in zip(cuts,cuts[1:]):
        dt=[ts[i]-ts[i-1] for i in range(lo-1,hi-1)]
        segments.append(dict(start_step=lo,end_step=hi,frames=hi-lo,seconds=ts[hi-2]-ts[lo-2],
                             frame_ms=distribution([v*1000 for v in dt]),frames_over_100ms=sum(v>.1 for v in dt),
                             frames_over_1s=sum(v>1 for v in dt)))
    resources=[json.loads(l) for l in (target/'resources.jsonl').read_text().splitlines()]
    admission=read(target/'LOWLOAD_ADMISSION.json')
    previous=admission['admission']['monotonic'];cpus=[]
    for row in resources:
        if row['monotonic']-previous>=.5:cpus.append(row['cpu_busy_percent'])
        previous=row['monotonic']
    processes=[r for r in resources if r['test_process']]
    sched=[r['test_process']['thread_schedstat_sum'] for r in processes if 'thread_schedstat_sum' in r['test_process']]
    group=dict(cpu_busy_percent=distribution(cpus),load1=distribution([r['load1'] for r in resources]),
               samples=len(resources),over_15_percent=sum(v is not None and v>15 for v in cpus),
               over_load1_32=sum(r['load1']>32 for r in resources),
               observed_cpu_seconds=max((r['test_process']['user_seconds']+r['test_process']['system_seconds'] for r in processes),default=0),
               observed_peak_rss_bytes=max((r['test_process']['rss_bytes'] for r in processes),default=0),
               maximum_observed_thread_runqueue_wait_seconds=max((r['runqueue_wait_ns']/1e9 for r in sched),default=0),
               note='Process lifetime samples include SDK initialization and result export; last sample precedes process exit.')
    group['selected_logical_cpus']=read(ROOT/'received/AFFINITY_SELECTION.json')['logical_cpus']
    group['selected_pool_busy_percent']=distribution([
        statistics.mean(row['selected_cpu_busy_percent'].values()) for row in resources if row['selected_cpu_busy_percent']])
    masks=[r['test_process']['allowed_cpu_list'] for r in processes if 'allowed_cpu_list' in r['test_process']]
    group['observed_process_cpu_masks']=list({tuple(value) for value in masks})
    other=[]
    for a,b in zip(resources,resources[1:]):
        if a['test_process'] and b['test_process']:
            dt=b['monotonic']-a['monotonic']
            cpu_a=a['test_process']['user_seconds']+a['test_process']['system_seconds']
            cpu_b=b['test_process']['user_seconds']+b['test_process']['system_seconds']
            busy=sum(b['selected_cpu_busy_percent'].values())/100
            other.append(max(0.,busy-(cpu_b-cpu_a)/dt))
    group['estimated_other_work_cpu_equivalents_in_pool']=distribution(other)
    details=s['drone_details'];chosen=s['selected_submission']
    result[label]=dict(score_out_of_80=s['partial'],map_score=s['map_score'],wall_score=s['coverage'],
        time_score=s['time_score'],exploration_percent=s['trajectory'],submission_drone=chosen['drone'],submission_step=chosen['step'],
        submission_walltime_seconds=chosen['walltime_seconds'],final_walltime_seconds=s['elapsed_walltime'],
        placed=s['placed'],all_submissions=s['submissions'],map_sha256=s['selected_image_sha256'],
        total_health_lost=sum(25-d['health'] for d in details),
        missed_wall_pixels=s['map_breakdown']['wall_pixels']-s['map_breakdown']['wall_hits'],
        charged_misdraw_pixels=s['map_breakdown']['charged_pixels'],
        last_confirmations={str(d['drone']):d['last_confirmation'] for d in details},
        ordinary_selection={str(d['drone']):d['group_ordinary_selection'] for d in details},
        first_ready={str(d['drone']):d['original_first_ready'] for d in details},
        walltime_submission={str(d['drone']):d['walltime_submission'] for d in details},
        admission=admission,resources=group,segments=segments,
        cumulative_time_at_steps={str(v):ts[v-2] for v in cuts})
    evidence.extend(p for p in target.rglob('*') if p.is_file())
assert all(starts['rowindex'][k]==starts['budget93'][k] for k in starts['rowindex'] if k!='solutions_sha256')
assert [k for k in starts['rowindex']['solutions_sha256'] if starts['rowindex']['solutions_sha256'][k]!=starts['budget93']['solutions_sha256'][k]]==['deadline_submission.py','red_hooks.py']
head0,b0=arrays['rowindex'];head1,b1=arrays['budget93'];stride=85
assert len(b0)//head0['shape'][0]==len(b1)//head1['shape'][0]==stride
first=next((i for i in range(min(head0['shape'][0],head1['shape'][0])) if b0[i*stride:(i+1)*stride]!=b1[i*stride:(i+1)*stride]),None)
rowindex=result['rowindex'];current=result['budget93']
fields=['score_out_of_80','map_score','wall_score','time_score','submission_step','final_walltime_seconds','placed','exploration_percent','total_health_lost','missed_wall_pixels','charged_misdraw_pixels']
comparison=dict(current_minus_rowindex={k:current[k]-rowindex[k] for k in fields},
    common_trajectory_prefix_frames=min(head0['shape'][0],head1['shape'][0]) if first is None else first,
    first_different_recorded_frame=None if first is None else first+1,
    same_selected_map=rowindex['map_sha256']==current['map_sha256'],
    cpu_mean_difference_percent_points=current['resources']['cpu_busy_percent']['mean']-rowindex['resources']['cpu_busy_percent']['mean'],
    load1_mean_difference=current['resources']['load1']['mean']-rowindex['resources']['load1']['mean'])
common_end=min(rowindex['submission_step'],current['submission_step'])
last_same_step=min(common_end,first+1) if first is not None else common_end
comparison['last_same_physical_frame_step']=last_same_step
comparison['last_same_frame_rowindex_seconds']=recorded_times['rowindex'][last_same_step-2]
comparison['last_same_frame_candidate_seconds']=recorded_times['budget93'][last_same_step-2]
comparison['last_same_frame_time_saved_seconds']=recorded_times['rowindex'][last_same_step-2]-recorded_times['budget93'][last_same_step-2]
comparison['same_step_times']={str(step):dict(rowindex_seconds=recorded_times['rowindex'][step-2],
    candidate_seconds=recorded_times['budget93'][step-2],
    candidate_saved_seconds=recorded_times['rowindex'][step-2]-recorded_times['budget93'][step-2],
    within_same_physical_prefix=step<=last_same_step) for step in sorted(set(
        s for s in [1001,2001,3001,3240,3444,3501,4001,4501,4590,5001,last_same_step,common_end] if s<=common_end))}
comparison['same_observed_cpu_masks']=rowindex['resources']['observed_process_cpu_masks']==current['resources']['observed_process_cpu_masks']
comparison['whole_run_cpu_samples_within_15_percent']=all(r['resources']['over_15_percent']==0 for r in result.values())
comparison['whole_run_load1_samples_within_32']=all(r['resources']['over_load1_32']==0 for r in result.values())
bh0,bb0=bomb_arrays['rowindex'];bh1,bb1=bomb_arrays['budget93']
bs0=len(bb0)//bh0['shape'][0];bs1=len(bb1)//bh1['shape'][0];padded=max(bs0,bs1)
first_bomb=next((i for i in range(min(bh0['shape'][0],bh1['shape'][0]))
    if bb0[i*bs0:(i+1)*bs0].ljust(padded,b'\0')!=bb1[i*bs1:(i+1)*bs1].ljust(padded,b'\0')),None)
comparison['first_different_bomb_recorded_frame']=None if first_bomb is None else first_bomb+1
joint_step=min(last_same_step,first_bomb+1) if first_bomb is not None else last_same_step
comparison['last_same_drone_and_bomb_frame_step']=joint_step
comparison['joint_prefix_time_saved_seconds']=recorded_times['rowindex'][joint_step-2]-recorded_times['budget93'][joint_step-2]
comparison['joint_prefix_rowindex_seconds']=recorded_times['rowindex'][joint_step-2]
comparison['joint_prefix_candidate_seconds']=recorded_times['budget93'][joint_step-2]
placements={}
for label in ['rowindex','budget93']:
    rows=[json.loads(s) for s in (ROOT/label/'received/placement_events.jsonl').read_text().splitlines()]
    placements[label]=[e for e in rows if e['event']=='sdk_placement' and e['accepted']]
comparison['same_all_accepted_placements']=placements['rowindex']==placements['budget93']
comparison['accepted_placements']=placements
comparison['same_step_times'][str(joint_step)]=dict(rowindex_seconds=recorded_times['rowindex'][joint_step-2],
    candidate_seconds=recorded_times['budget93'][joint_step-2],candidate_saved_seconds=comparison['joint_prefix_time_saved_seconds'],
    within_same_physical_prefix=True,within_same_drone_and_bomb_prefix=True)

details={label:read(ROOT/label/'received/OFFICIAL_SCORE.json')['drone_details'] for label in ['rowindex','budget93']}
anchors={};phases={};closeouts={};renders={}
for label in ['rowindex','budget93']:
    target=ROOT/label/'received'
    remote_hash=subprocess.run(['ssh',HOST,'sha256sum '+REMOTE+'/'+label+'/TIMING_ANCHORS.jsonl'],capture_output=True,text=True,check=True).stdout.split()[0]
    assert H(target/'TIMING_ANCHORS.jsonl')==remote_hash
    anchors[label]=[json.loads(l) for l in (target/'TIMING_ANCHORS.jsonl').read_text().splitlines()]
    resource=[json.loads(l) for l in (target/'resources.jsonl').read_text().splitlines()]
    wanted=[a for a in anchors[label] if a['step'] in [1,1001,2001,3001,4001,4340,4501,4590,4950,5022,5051,5251]]
    phase=[]
    assigned=read(ROOT/'received/AFFINITY_SELECTION.json')['logical_cpus']
    for lo,hi in zip(wanted,wanted[1:]):
        rows=[r for r in resource if lo['host_monotonic']<=r['monotonic']<hi['host_monotonic']]
        assigned_other=[];sibling_busy=[]
        for a,b in zip(rows,rows[1:]):
            if a['test_process'] and b['test_process']:
                dt=b['monotonic']-a['monotonic']
                own=sum(b['test_process'][k]-a['test_process'][k] for k in ['user_seconds','system_seconds'])/dt
                assigned_other.append(max(0.,sum(b['selected_cpu_busy_percent']['cpu'+str(c)] for c in assigned)/100-own))
                sibling_busy.append(sum(v for k,v in b['selected_cpu_busy_percent'].items() if int(k[3:]) not in assigned)/100)
        phase.append(dict(start_step=lo['step'],end_step=hi['step'],sdk_start_control_wall_seconds=hi['walltime']-lo['walltime'],host_seconds=hi['host_monotonic']-lo['host_monotonic'],global_cpu_percent=distribution([r['cpu_busy_percent'] for r in rows]),load1=distribution([r['load1'] for r in rows]),external_work_equivalents_on_assigned_cpus=distribution(assigned_other),work_equivalents_on_unassigned_siblings=distribution(sibling_busy),load_violations=sum(not r['global_lowload_thresholds_met'] for r in rows),samples=len(rows)))
    phases[label]=phase
    closeouts[label]={str(d['drone']):d['closeout_departure_audit'] for d in details[label]}
    event=next(d for d in details[label] if d['drone']==result[label]['submission_drone'])
    result[label].update(budget_events={str(d['drone']):d['budget_submission'] for d in details[label]},budget_audits={str(d['drone']):d['budget_submission_audit'] for d in details[label]},ordinary_first_ready={str(d['drone']):d['original_first_ready'] for d in details[label]},selected_cache=event['group_best_metadata'],submission_calls=len(result[label]['all_submissions']),phases=phase,timing_anchor_sha256=remote_hash)
    live=-1;last=-1;events=[];ts=recorded_times[label]
    for d in details[label]:
        live=-1;last=-1
        for e in d['group_candidate_audit']:
            step,kind=e[:2]
            if kind=='snapshot_frozen' or kind=='payload_stored' and e[3]=='snapshot':last=step
            elif kind=='live_candidate_cached':live=step;events.append((step,d['drone'],'live_or_finish'))
            elif kind=='image_built':
                if e[2]==d['drone']:events.append((step,d['drone'],'frozen'))
                elif e[2]==5:
                    wall=ts[step-3] if step>=3 else 0
                    if step<4590 and 180-wall>8 and live<last:events.append((step,d['drone'],'new_fusion'))
    renders[label]=sorted(events)
closeout_diff=next((s for s in sorted({e[0] for g in closeouts.values() for rows in g.values() for e in rows}) if {o:[e for e in rows if e[0]==s] for o,rows in closeouts['rowindex'].items()}!={o:[e for e in rows if e[0]==s] for o,rows in closeouts['budget93'].items()}),None)
render_diff=next((s for s in sorted({e[0] for rows in renders.values() for e in rows}) if [e for e in renders['rowindex'] if e[0]==s]!=[e for e in renders['budget93'] if e[0]==s]),None)
matched=comparison['last_same_drone_and_bomb_frame_step']
if closeout_diff is not None:matched=min(matched,closeout_diff-1)
if render_diff is not None:matched=min(matched,render_diff-1)
comparison.update(closeout_audits=closeouts,first_closeout_audit_difference_step=closeout_diff,identified_render_events=renders,first_render_schedule_difference_step=render_diff,matched_work_last_step=matched,matched_work_rowindex_seconds=recorded_times['rowindex'][matched-2],matched_work_budget_seconds=recorded_times['budget93'][matched-2],matched_work_budget_saved_seconds=recorded_times['rowindex'][matched-2]-recorded_times['budget93'][matched-2])
comparison['same_step_times'][str(matched)]=dict(rowindex_seconds=recorded_times['rowindex'][matched-2],budget_seconds=recorded_times['budget93'][matched-2],budget_saved_seconds=comparison['matched_work_budget_saved_seconds'],within_matching_physics_render_closeout=True)
heavy=read(ROOT.parent/'team615_budget93_maps08_09_seed615_20261122/delivery/RESULTS.json')['results']['Map09']
heavy_version=heavy['versions']['budget93']
heavy_folder=ROOT.parent/'team615_budget93_maps08_09_seed615_20261122/Map09/received'
heavy_rec=next((heavy_folder/'official/recordings').glob('*.npz'));heavy_ts=timestamps(heavy_rec)
with ZipFile(heavy_rec) as z:
    hdh,hdb=npy(z.read('drone_states.npy'));hbh,hbb=npy(z.read('bomb_states.npy'))
heavy_timing={}
for label in ['rowindex','budget93']:
    dh,db=arrays[label];bh,bb=bomb_arrays[label]
    size=min(dh['shape'][0],hdh['shape'][0]);fd=next((i for i in range(size) if db[i*85:(i+1)*85]!=hdb[i*85:(i+1)*85]),None)
    bs=len(bb)//bh['shape'][0];hbs=len(hbb)//hbh['shape'][0];padding=max(bs,hbs)
    fb=next((i for i in range(min(bh['shape'][0],hbh['shape'][0])) if bb[i*bs:(i+1)*bs].ljust(padding,b'\0')!=hbb[i*hbs:(i+1)*hbs].ljust(padding,b'\0')),None)
    prefix=min((x+1 for x in [fd,fb] if x is not None),default=min(dh['shape'][0],hdh['shape'][0])+1)
    points=[s for s in [1001,2001,3001,3501,prefix] if s<=prefix]
    heavy_timing[label]=dict(last_same_drone_and_bomb_step=prefix,same_step_times={str(s):dict(heavy_seconds=heavy_ts[s-2],this_run_seconds=recorded_times[label][s-2],observed_saved_seconds=heavy_ts[s-2]-recorded_times[label][s-2]) for s in sorted(set(points))})
recovery={label:{k:result[label][k]-heavy_version[k] for k in ['score_out_of_80','map_score','wall_score','submission_step','placed','final_walltime_seconds']} for label in ['rowindex','budget93']}
quality={label:dict(admission=read(ROOT/label/'received/LOWLOAD_ADMISSION.json'),monitor_finish=read(ROOT/label/'received/MONITOR_FINISH.json')) for label in ['rowindex','budget93']}
assert quality['rowindex']['admission']['logical_cpus']==quality['budget93']['admission']['logical_cpus']
delivery=ROOT/'delivery';delivery.mkdir(exist_ok=True)
output=dict(status='COMPLETE',map='Map09',seed=615,new_red_rounds=2,other_maps=0,algorithm_changes=False,V16_remains_competition_baseline=True,versions=result,comparison=comparison,admission_and_resource_evidence=quality,whole_server_lowload_required=False,user_authorized_8cpu_override=True,timing_anchors=anchors,heavy_reference=heavy_version,recovery_against_heavy_reference=recovery,matched_physics_timing_against_heavy_reference=heavy_timing)
save(delivery/'RESULTS.json',output)
report=['# Map09种子615：按行索引与93%预算候选同组8CPU各一次\n','本轮只新增两场Map09，按行索引候选与93%预算候选各一场。未改算法、依赖或比赛参数，未跑其他地图，V16继续作为比赛提交基线。两版使用相同的稀疏时间锚点观察器和配置，原始源码归档保持冻结。\n','## 本轮结果及此前高负载参考\n','| 指标 | 本轮按行索引 | 本轮93%预算 | 此前高负载93%预算 |','|---|---:|---:|---:|']
fmt=lambda v:str(v) if type(v)is int else f'{v:.6f}'
for name,key in [('交图者','submission_drone'),('交图步数','submission_step'),('得分小计/80','score_out_of_80'),('地图分','map_score'),('墙覆盖分','wall_score'),('时间分','time_score'),('实投数','placed'),('最终墙钟/秒','final_walltime_seconds'),('探索率/%','exploration_percent'),('掉血','total_health_lost')]:report.append('| '+name+' | '+' | '.join(fmt(v[key]) for v in [result['rowindex'],result['budget93'],heavy_version])+' |')
report.extend(['','得分小计=0.5×地图分＋0.2×墙覆盖分＋0.1×时间分。未将未输出的炸弹项冒称为完整总分。','',
    '## 8CPU配置及负载记录\n','用户后续明确要求直接启动，以8个CPU是否空闲为主，取消整机低负载门槛。首场从同一socket的8个不同空闲物理核各选择1个逻辑CPU，合计恰好8CPU；两场固定同组，线程设置相同。初次选核时检查SMT兄弟，之后同组8个指定CPU按每2秒采样、3次均≤5%占用后启动。整机及兄弟线程负载仍记录，CPU亲和性不构成独占预约。共享评测锁继续遵守，不影响别的评测，不自动重跑。此前严格等待队列未启动任何比赛，停止的只有等待进程；变更凭据见USER_8CPU_OVERRIDE.json。','',
    '同组逻辑CPU：`'+json.dumps(quality['rowindex']['admission']['logical_cpus'])+'`。','',
    '| 监控项 | 按行索引 | 93%预算 | 高负载参考 |','|---|---:|---:|---:|'])
for title,key in [('整机CPU占用均值/%','cpu_busy_percent'),('load1均值','load1'),('CPU池其他任务估计等效核均值（含兄弟线程）','estimated_other_work_cpu_equivalents_in_pool')]:report.append('| '+title+' | '+' | '.join(f"{v['resources'][key]['mean']:.6f}" for v in [result['rowindex'],result['budget93'],heavy_version])+' |')
report.extend(['','全阶段运行监控（含初始化和导出）超出旧整机参考线的样本：`'+json.dumps({label:q['monitor_finish']['global_load_violation_samples'] for label,q in quality.items()})+'`。旧参考线为CPU≤15%、load1≤32，现仅用于描述，已不作为通过/失败门槛。分段统计按SDK/主机时钟锚点把一秒资源采样归类，边界附近为近似。本轮监控8物理核及其兄弟线程，历史高负载参考监控16物理核；池内等效核均值不能当作同大小池直接比较。','',
    '## 分段耗时与负载\n','| 版本 | 起步 | 止步 | SDK控制入口累计秒差 | 主机秒差 | CPU均值/% | load1均值 | 超出旧参考线样本 |','|---|---:|---:|---:|---:|---:|---:|---:|'])
for label,rows in phases.items():
    for x in rows:report.append(f"| {label} | {x['start_step']} | {x['end_step']} | {x['sdk_start_control_wall_seconds']:.6f} | {x['host_seconds']:.6f} | {x['global_cpu_percent']['mean'] if x['global_cpu_percent'] else None} | {x['load1']['mean'] if x['load1'] else None} | {x['load_violations']} |")
report.extend(['','## 同工作量对照与结束路径\n',f'物理记录、已识别制图安排及末弹审计同时匹配至{matched}步：按行索引用时{comparison["matched_work_rowindex_seconds"]:.6f}秒，预算候选{comparison["matched_work_budget_seconds"]:.6f}秒，实测差{comparison["matched_work_budget_saved_seconds"]:.6f}秒。更晚区间可能已涉及不同决策，不能继续当作相同工作量的纯计算比较。',
    '同一步数记录末尾耗时：`'+json.dumps(comparison['same_step_times'],ensure_ascii=False)+'`。','',
    '末弹收尾审计：`'+json.dumps(closeouts,ensure_ascii=False)+'`。','',
    '实际投放事件：`'+json.dumps(comparison['accepted_placements'],ensure_ascii=False)+'`。',''])
for label,v in result.items():
    report.extend([label+'预算出口：`'+json.dumps(v['budget_events'],ensure_ascii=False)+'`；预算门槛审计：`'+json.dumps(v['budget_audits'],ensure_ascii=False)+'`。',
        '硬兜底：`'+json.dumps(v['walltime_submission'],ensure_ascii=False)+'`；最终缓存：`'+json.dumps(v['selected_cache'],ensure_ascii=False)+'`；提交调用：`'+json.dumps(v['all_submissions'],ensure_ascii=False)+'`。',''])
report.extend(['## 相对高负载场次的恢复\n','差值：`'+json.dumps(recovery,ensure_ascii=False)+'`。','',
    '在共同无人机和炸弹物理记录区间内的同一步数耗时：`'+json.dumps(heavy_timing,ensure_ascii=False)+'`。','',
    '本轮只有一组配对，仍需结合全程负载、末弹落点、最终缓存及得分解释环境影响，不能凭单个分数保证其他种子或负载下完全无差异。本轮已按用户要求改为同组8CPU、带全局负载记录的对照，不能称全程整机低负载或复刻官网具体硬件。正式比赛基线仍为V16。'])
(delivery/'REPORT.md').write_text('\n'.join(report)+'\n',encoding='utf8')
with ZipFile(delivery/'RUN_EVIDENCE.zip','w',ZIP_DEFLATED) as z:
    for label in ['rowindex','budget93']:
        for p in (ROOT/label/'received').rglob('*'):
            if p.is_file():z.write(p,p.relative_to(ROOT).as_posix())
        for n in ['stage_run.py','DECLARED_SOURCE.json','PATCH_BINDING.json','OFFLINE_CHECK.json','place_map09.yml','run_monitored.sh','matched_spawns.json','EXPECTED_ZONES.json']:z.write(ROOT/label/n,label+'/'+n)
    for p in (ROOT/'received').iterdir():
        if p.is_file():z.write(p,p.relative_to(ROOT).as_posix())
    for n in ['provision.py','monitor.py','collect.py','collect_prefix.txt','collect_tail.txt','environment.py','AUTHORIZED_RUN.json','OBSERVER_BINDING.json','monitor8cpu.py','monitor8cpu_body.txt','USER_8CPU_OVERRIDE.json','STRICT_WAIT_MONITOR_CONFIG.json','STRICT_WAIT_AUTHORIZED_RUN.json']:z.write(ROOT/n,n)
    hp=ROOT.parent/'team615_budget93_maps08_09_seed615_20261122'
    for n in ['OFFICIAL_SCORE.json','resources.jsonl','ADMISSION.json','MONITOR_FINISH.json']:z.write(hp/'Map09/received'/n,'heavy_reference/'+n)
    z.write(heavy_rec,'heavy_reference/'+heavy_rec.name)
    z.write(hp/'delivery/RESULTS.json','heavy_reference/RESULTS.json')
save(delivery/'CHECKSUMS_SHA256.json',{p.name:H(p) for p in sorted(delivery.iterdir()) if p.name!='CHECKSUMS_SHA256.json'})
print(json.dumps({k:v for k,v in output.items() if k not in ['timing_anchors','comparison']},indent=2,ensure_ascii=False))
