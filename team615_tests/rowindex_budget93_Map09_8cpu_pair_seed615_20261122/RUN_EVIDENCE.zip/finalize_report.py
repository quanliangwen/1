from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'delivery'
read=lambda p:json.loads(p.read_text(encoding='utf8'))
save=lambda p,d:p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
r=read(OUT/'RESULTS.json');a=r['versions']['rowindex'];b=r['versions']['budget93'];h=r['heavy_reference']
assert r['new_red_rounds']==2 and r['other_maps']==0 and r['algorithm_changes'] is False
assert r['comparison']['same_observed_cpu_masks']
for v in [a,b]:
    assert v['placed']==10 and v['submission_drone']==0 and v['submission_calls']==5
    assert all(e is None for e in v['budget_events'].values()) and all(not e for e in v['budget_audits'].values())
assert len(r['admission_and_resource_evidence']['rowindex']['admission']['logical_cpus'])==8
src=read(ROOT/'budget93/received/SOURCE_MATCH.json')
old=read(ROOT.parent/'team615_budget93_maps08_09_seed615_20261122/Map09/received/SOURCE_MATCH.json')
assert src['candidate_zip_sha256']==old['candidate_zip_sha256']=='0ed2e45090a6a8104c0a3bf92d8ac79382a7891eccb978ffaba8a72a2b06a449'
r['interpretation']=dict(supports_environment_as_major_factor=True,strict_causal_isolation_claim=False,
    reasons=['same budget archive recovered from 37.974583 to 42.926742','same 8 assigned CPUs pair scores differ only 0.024323','at matched physical step3501 identical budget source used 116.855343s versus 154.999697s under old heavy conditions','budget exit never activated in either new run; original wall-clock closeout still changes bomb location'],
    limitations=['one pair only','8CPU allocation and scheduling contention changed together relative to heavy reference','whole-server load still present; user explicitly removed global gate','Map09 budget exit itself was not exercised'])
save(OUT/'RESULTS.json',r)
timing=r['matched_physics_timing_against_heavy_reference']
intro=f'''## 结论

本次结果支持：此前Map09大幅退分主要与运行环境、CPU分配/争用及原墙钟收尾的耦合有关，未见93%预算候选本身产生同等级持续退化的证据。按行索引和预算候选在同一组8CPU下小计分别42.902419、42.926742，只差{b['score_out_of_80']-a['score_out_of_80']:+.6f}；同一份预算源码相对此前高干扰场次恢复{b['score_out_of_80']-h['score_out_of_80']:+.6f}分。

这不是严格整机低负载实验：用户在等待后明确改为8CPU空闲即可启动。两场CPU亲和性实际一致，各自开跑前的目标8CPU空闲检查通过；全局背景负载仍存在且不同，未单独隔离CPU数量、频率、缓存和争用各自的贡献，不能给出纯负载因果比例。

两场均由0号机在约178.5秒触发原墙钟兜底，预算事件和审计全部为空，均实投10枚。最终墙钟接近并不表示运行性能相同：高干扰场次仅完成3990步，本轮预算候选完成4944步。两场均有5架同帧提交调用，SDK采用0号图；唯一提交协调未因此解决。V16继续作为比赛基线。

## 在共同物理记录区间内的累计耗时

| 比赛步数 | 此前高干扰预算候选/秒 | 本轮按行索引8CPU/秒 | 本轮预算8CPU/秒 |
|---:|---:|---:|---:|
'''
for step in ['1001','2001','3001','3501']:
    x=timing['rowindex']['same_step_times'][step];y=timing['budget93']['same_step_times'][step]
    intro+=f"| {step} | {y['heavy_seconds']:.6f} | {x['this_run_seconds']:.6f} | {y['this_run_seconds']:.6f} |\n"
intro+='''
三场的五机和炸弹物理记录均可匹配到3503步。预算候选同为3501步时，累计少用38.144353秒，且算法归档与高干扰场次相同。此前在3503步便已用155.034秒，触发原剩余25秒收尾；本轮两版分别到4341、4444步才进入对应收尾，末弹位置随之改变。新预算规则没有参与这些差异。

本轮最后一枚实投分别在4343、4446步，前9次实际投放完全相同；两版0号均采用4590版缓存，但最终图像不同。该差异与原墙钟流程和后续地图证据/制图过程的变化同时出现，不应将小计0.024323分差包装为预算策略的稳定收益。Map09在超过5022步时的新预算出口表现，本轮仍未实际覆盖。

'''
text=(OUT/'REPORT.md').read_text(encoding='utf8')
text=text.replace('## 本轮结果及此前高负载参考\n',intro+'## 本轮结果及此前高负载参考\n',1)
(OUT/'REPORT.md').write_text(text,encoding='utf8')
with ZipFile(OUT/'RUN_EVIDENCE.zip','a',ZIP_DEFLATED) as z:z.write(Path(__file__),Path(__file__).name)
save(OUT/'CHECKSUMS_SHA256.json',{p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.iterdir()) if p.name!='CHECKSUMS_SHA256.json'})
print(json.dumps(dict(pair_scores=[a['score_out_of_80'],b['score_out_of_80']],budget_score_recovery=b['score_out_of_80']-h['score_out_of_80'],budget_same_step3501_time_saved=timing['budget93']['same_step_times']['3501']['observed_saved_seconds'],same_8_cpu_masks=True,algorithm_changes=False,new_rounds=2),indent=2))
