"""User-authorized fixed idle physical-core comparison, exactly one match per arm."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl
import hashlib
import json
import os
import platform
import subprocess
import time

ROOT=Path(__file__).resolve().parent
LOCK='/home/junhao/quan/parallel_test_solver/match/solver_study/serial_evaluation.lock'
CORE_COUNT=16
previous=None
def now():return datetime.now(timezone.utc).isoformat()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def status(value):save(ROOT/'STATUS.json',dict(utc=now(),**value))
def counters():
    out={}
    for line in Path('/proc/stat').read_text().splitlines():
        fields=line.split()
        if fields[0]=='cpu' or fields[0].startswith('cpu') and fields[0][3:].isdigit():
            values=list(map(int,fields[1:9]));out[fields[0]]=(sum(values),values[3]+values[4])
    return out
def sample(cpus=()):
    global previous
    values=counters();busy=None;per_core={};stamp=time.monotonic()
    if previous is not None:
        for key in ['cpu']+['cpu'+str(c) for c in cpus]:
            total=values[key][0]-previous[key][0];idle=values[key][1]-previous[key][1]
            percent=100.*(total-idle)/total if total else 0.
            if key=='cpu':busy=percent
            else:per_core[key]=percent
    previous=values
    load=Path('/proc/loadavg').read_text().split()
    pressure={n:(Path('/proc/pressure')/n).read_text().strip() for n in ['cpu','memory','io']}
    return dict(utc=now(),monotonic=stamp,cpu_busy_percent=busy,load1=float(load[0]),load5=float(load[1]),
                load15=float(load[2]),runnable=load[3],pressure=pressure,selected_cpu_busy_percent=per_core)
def process_sample(pid,detailed):
    try:
        p=Path('/proc')/str(pid);raw=(p/'stat').read_text();f=raw[raw.rfind(')')+2:].split()
        result=dict(pid=pid,state=f[0],user_seconds=int(f[11])/os.sysconf('SC_CLK_TCK'),
                    system_seconds=int(f[12])/os.sysconf('SC_CLK_TCK'),threads=int(f[17]),cpu=int(f[36]),
                    rss_bytes=int(f[21])*os.sysconf('SC_PAGE_SIZE'))
        if detailed:
            total=[0,0,0];count=0
            for task in (p/'task').iterdir():
                try:
                    v=list(map(int,(task/'schedstat').read_text().split()));total=[x+y for x,y in zip(total,v)];count+=1
                except (FileNotFoundError,ProcessLookupError):pass
            result['thread_schedstat_sum']=dict(runtime_ns=total[0],runqueue_wait_ns=total[1],timeslices=total[2],read_threads=count)
            result['allowed_cpu_list']=[s for s in (p/'status').read_text().splitlines() if s.startswith('Cpus_allowed_list')]
        return result
    except (FileNotFoundError,ProcessLookupError):return None

labels=['rowindex','budget93']
with (ROOT/'DISPATCH_ONCE_CLAIM').open('x'):pass
for label in labels:assert not any((ROOT/label/n).exists() for n in ['START.json','RUN_ONCE_CLAIM','SDK_PID'])
save(ROOT/'HOST.json',dict(utc=now(),hostname=platform.node(),platform=platform.platform(),logical_cpus=os.cpu_count(),cpuinfo=Path('/proc/cpuinfo').read_text().split('\n\n')[0]))
save(ROOT/'MONITOR_CONFIG.json',dict(cpu_busy_percent_max=15,load1_max=32,global_stable_seconds=30,selected_logical_cpu_busy_percent_max=5,selected_stable_seconds_min=10,physical_cores=16,logical_threads_per_core='all allowed siblings',lock=LOCK,lock_held_during_match=True,lock_held_while_waiting=False,run_sample_seconds=1,scheduling_sample_seconds=5,retries=False,no_admission_relaxation=True,monitor_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
queue=(ROOT/'queue_resources.jsonl').open('x',buffering=1);completed=[];cpus=None
def low(row):return row['cpu_busy_percent'] is not None and row['cpu_busy_percent']<=15 and row['load1']<=32
def idle(row):return low(row) and all(v<=5 for v in row['selected_cpu_busy_percent'].values())
def release(lock):
    fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
try:
    allowed=sorted(os.sched_getaffinity(0));groups={}
    for cpu in allowed:
        p=Path('/sys/devices/system/cpu')/f'cpu{cpu}'/'topology'
        key=int((p/'physical_package_id').read_text()),int((p/'core_id').read_text())
        groups.setdefault(key,[]).append(cpu)
    sample()
    for label in labels:
        stage=ROOT/label;stable=None;lock=None
        while True:
            time.sleep(2);row=sample(cpus or ());queue.write(json.dumps(dict(version=label,phase='lowload_admission',**row))+'\n')
            good=idle(row) if cpus is not None else low(row)
            stable=(stable if stable is not None else row['monotonic']) if good else None
            status(dict(state='WAITING_STRICT_LOWLOAD',version=label,completed_versions=completed,stable_seconds=0 if stable is None else row['monotonic']-stable,latest_sample=row,logical_cpus=cpus,thresholds_relaxed=False))
            if stable is None or row['monotonic']-stable<30:continue
            lock=open(LOCK,'r')
            try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:
                lock.close();lock=None;status(dict(state='WAITING_SHARED_SLOT',version=label,completed_versions=completed,latest_sample=row));continue
            if cpus is None:
                maximum={c:0. for c in allowed};sample(allowed);selected_rows=[]
                for _ in range(3):
                    time.sleep(2);check=sample(allowed);selected_rows.append(check);queue.write(json.dumps(dict(version=label,phase='locked_core_selection',**check))+'\n')
                    for c in allowed:maximum[c]=max(maximum[c],check['selected_cpu_busy_percent']['cpu'+str(c)])
                by_socket={}
                for key,items in groups.items():
                    if all(maximum[c]<=5 for c in items):by_socket.setdefault(key[0],[]).append((key,items))
                viable=[(s,sorted(v,key=lambda x:x[0],reverse=True)) for s,v in by_socket.items() if len(v)>=CORE_COUNT]
                if not viable or not all(low(r) for r in selected_rows):
                    release(lock);lock=None;stable=None;continue
                socket,selected=min(viable,key=lambda x:(-len(x[1]),x[0]));selected=selected[:CORE_COUNT]
                proposed=sorted(c for _,items in selected for c in items);start=time.monotonic();passed=True
                while time.monotonic()-start<10:
                    time.sleep(2);check=sample(proposed);queue.write(json.dumps(dict(version=label,phase='locked_selected_core_gate',**check))+'\n')
                    if not idle(check):passed=False;break
                if not passed:
                    release(lock);lock=None;stable=None;continue
                cpus=proposed
                save(ROOT/'AFFINITY_SELECTION.json',dict(utc=now(),physical_cores=CORE_COUNT,logical_cpus=cpus,socket=socket,core_topology=[dict(socket=k[0],core=k[1],siblings=v) for k,v in selected],maximum_preselection_busy_percent={str(c):maximum[c] for c in cpus},same_group_frozen_for_both_versions=True,note='Affinity restricts our process; it does not reserve against external jobs.'))
            else:
                time.sleep(2);check=sample(cpus);queue.write(json.dumps(dict(version=label,phase='locked_fixed_core_recheck',**check))+'\n')
                if not idle(check):release(lock);lock=None;stable=None;continue
            break
        save(stage/'LOWLOAD_ADMISSION.json',dict(utc=now(),version=label,mode='strict_lowload_same_physical_cores',admission=check,logical_cpus=cpus,whole_server_lowload_at_admission=True,global_stable_seconds_min=30,selected_stable_seconds_min=10,lock_acquired=True))
        status(dict(state='RUNNING',version=label,completed_versions=completed,logical_cpus=cpus,thresholds_relaxed=False))
        with (stage/'dispatch.log').open('x') as output,(stage/'resources.jsonl').open('x',buffering=1) as stream:
            proc=subprocess.Popen(['bash',str(stage/'run_monitored.sh'),str(stage)],cwd=stage,stdout=output,stderr=subprocess.STDOUT,preexec_fn=lambda:os.sched_setaffinity(0,set(cpus)))
            index=0;pid=None;violations=0
            while proc.poll() is None:
                row=sample(cpus)
                if (stage/'SDK_PID').exists():pid=int((stage/'SDK_PID').read_text())
                row['test_process']=process_sample(pid,index%5==0) if pid else None
                row['global_lowload_thresholds_met']=low(row)
                if not low(row):violations+=1
                stream.write(json.dumps(row)+'\n');index+=1;time.sleep(1)
            code=proc.wait()
        release(lock);lock=None
        save(stage/'MONITOR_FINISH.json',dict(utc=now(),returncode=code,pid=pid,samples=index,global_load_violation_samples=violations,logical_cpus=cpus,automatic_retries=False))
        if code or not (stage/'POST_RUN_SOURCE_CHECK.json').exists():raise RuntimeError(label+' failed; no automatic rerun')
        completed.append(label)
    status(dict(state='COMPLETE',map='Map09',seed=615,new_red_rounds=2,completed_versions=completed,logical_cpus=cpus,thresholds_relaxed=False))
except BaseException as exc:
    status(dict(state='FAILED',error=repr(exc),completed_versions=completed,no_automatic_rerun=True));raise
finally:
    if lock is not None:release(lock)
    queue.close()
