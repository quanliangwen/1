from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json
import shutil
import subprocess

r=Path(__file__).resolve().parent
release=r.parent/'team615_red_v17_wallmargin5_release_20261121'
prior=r.parent/'team615_first_round_yield_maps_20261121'
prior6=r.parent/'team615_first_round_yield_map06_20261121'
host='quanliangwen@10.112.162.60'
remote='/home/quanliangwen/isolated_test/team615_v17_map06_map08_seed615_20261121'
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
save=lambda p,v:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
build=read(release/'BUILD.json');checks=read(release/'RELEASE_CHECK.json');counter=read(release/'counterexamples.json')
assert checks['status']==counter['status']=='PASS' and counter['scenario_groups']==121
assert h(release/'delivery/team615_red_v17.zip')==build['submission_zip_sha256']==counter['archive_sha256']==checks['sha256']=='0aaed704f050073b664d4c0bece9f9ff6500e59edf55c78a7284036f01c167e7'
assert h(release/'baseline_v16.zip')==build['source_parent_zip_sha256']=='e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791'
assert build['changed_existing_files']==['deadline_submission.py']
(r/'SERVER_STAGE.txt').write_text(remote+'\n',encoding='utf8')
save(r/'AUTHORIZED_RUN.json',dict(maps=['Map06','Map08'],seed=615,new_red_rounds_per_map=1,
    new_red_rounds=2,blue_rounds=0,rerun_V16=False,rerun_Map09=False,algorithm_changes=False,
    version='V17',zip_sha256=build['submission_zip_sha256']))
normalized=dict(candidate_zip_sha256=build['submission_zip_sha256'],baseline_zip_sha256=build['source_parent_zip_sha256'],
    candidate_files=build['payload_files_sha256'],original_files=build['parent_payload_files_sha256'],
    changed_existing_files=build['changed_existing_files'],release_check_sha256=h(release/'RELEASE_CHECK.json'))
save(r/'BUILD.json',normalized)
save(r/'PATCH_BINDING.json',dict(baseline_commit='63ef52c4e56b37c3104ce060853b79ceab5ff133',
    baseline_zip_sha256=build['source_parent_zip_sha256'],candidate_zip_sha256=build['submission_zip_sha256'],
    baseline=build['parent_payload_files_sha256'],candidate=build['payload_files_sha256'],changed=build['changed_existing_files']))
save(r/'DECLARED_SOURCE.json',build['payload_files_sha256'])
save(r/'OFFLINE_CHECK.json',dict(simulation_steps=0,unit_groups=121,counterexamples_sha256=h(release/'counterexamples.json')))
for src,name in [(release/'delivery/team615_red_v17.zip','candidate_snapshot.zip'),(release/'baseline_v16.zip','baseline_snapshot.zip'),
                 (release/'RELEASE_ABI_RECEIPT.json','VALIDATION.json'),(release/'counterexamples.json','counterexamples.json')]:
    shutil.copyfile(src,r/name)
for name in ['stage_run.py','matched_spawns.json','EXPECTED_ZONES.json','SDK_SELECTION_EVIDENCE.json']:
    shutil.copyfile(prior/name,r/name)
assert h(r/'stage_run.py')==h(prior/'stage_run.py')==h(prior6/'stage_run.py')
with ZipFile(r/'candidate_snapshot.zip') as a,ZipFile(r/'baseline_snapshot.zip') as b:
    assert a.namelist()==b.namelist() and a.testzip() is None
    assert {n:sha256(a.read(n)).hexdigest() for n in a.namelist()}==build['payload_files_sha256']
    assert [n for n in a.namelist() if a.read(n)!=b.read(n)]==['deadline_submission.py']
    assert a.read('deadline_submission.py').replace(b'    MIN_WALL_MARGIN = 5.0',b'    MIN_WALL_MARGIN = 1.5')==b.read('deadline_submission.py')
subprocess.run(['ssh','-o','BatchMode=yes',host,'mkdir '+remote],check=True)
for map_name in ['Map06','Map08']:
    f=r/map_name;f.mkdir(exist_ok=False)
    baseline=prior6 if map_name=='Map06' else prior
    for name in ['stage_run.py','candidate_snapshot.zip','baseline_snapshot.zip','DECLARED_SOURCE.json','PATCH_BINDING.json',
                 'BUILD.json','VALIDATION.json','counterexamples.json','matched_spawns.json','EXPECTED_ZONES.json','OFFLINE_CHECK.json']:
        shutil.copyfile(r/name,f/name)
    shutil.copyfile(baseline/map_name/'place_map09.yml',f/'place_map09.yml')
    run=(baseline/map_name/'run_once.sh').read_text(encoding='utf8').replace('first_round_yield','v17_wallmargin5')
    (f/'run_once.sh').write_text(run,encoding='utf8',newline='\n')
    save(f/'OBSERVATION_BINDING.json',dict(observer_sha256=h(f/'stage_run.py'),observer_byte_identical_to_V16=True,
        config_byte_identical_to_V16=h(f/'place_map09.yml')==h(baseline/map_name/'place_map09.yml'),
        map=map_name,seed=615,controller_frozen_sha256=build['submission_zip_sha256'],new_red_rounds_authorized=1))
    subprocess.run(['ssh','-o','BatchMode=yes',host,'mkdir '+remote+'/'+map_name],check=True)
    subprocess.run(['scp','-q','-o','BatchMode=yes',*[str(p) for p in sorted(f.iterdir())],host+':'+remote+'/'+map_name+'/'],check=True)
dispatch='''set -euo pipefail
root="$1"
bash "$root/Map06/run_once.sh" "$root/Map06" > "$root/Map06/dispatch.log" 2>&1
bash "$root/Map08/run_once.sh" "$root/Map08" > "$root/Map08/dispatch.log" 2>&1
printf 'COMPLETE ONLY MAP06 MAP08 V17 SEED615\\n'
'''
(r/'dispatch.sh').write_text(dispatch,encoding='utf8',newline='\n')
subprocess.run(['scp','-q','-o','BatchMode=yes',str(r/'dispatch.sh'),host+':'+remote+'/'],check=True)
command='nohup bash '+remote+'/dispatch.sh '+remote+' > '+remote+'/queue.log 2>&1 < /dev/null & echo QUEUED_MAP06_MAP08_V17_ONCE_EACH'
p=subprocess.run(['ssh','-o','BatchMode=yes',host,command],capture_output=True,check=True,timeout=25)
print(p.stdout.decode(),flush=True)
print(build['submission_zip_sha256'],flush=True)
