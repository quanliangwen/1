from pathlib import Path, PurePosixPath
from hashlib import sha256
from zipfile import ZipFile, ZIP_DEFLATED
import argparse
import json
import math
import subprocess

r=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('map',choices=['Map06','Map08']);name=parser.parse_args().map
folder=r/name;received=folder/'received'
host='quanliangwen@10.112.162.60'
remote=(r/'SERVER_STAGE.txt').read_text().strip()+'/'+name
old_root=r.parent/('team615_first_round_yield_map06_20261121' if name=='Map06' else 'team615_first_round_yield_maps_20261121')
old=old_root/name/'received'
load=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def download(paths,dest):
    dest.mkdir(parents=True,exist_ok=True)
    subprocess.run(['scp','-q','-o','BatchMode=yes',*[host+':'+p for p in paths],str(dest)],check=True)

files=['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','placement_events.jsonl',
       'run.log','dispatch.log','wall_geometry.npz','group_dataset.npz','GROUP_DATASET.json',
       'POST_RUN_SOURCE_CHECK.json','EXTRA_ARTIFACTS.json']
download([remote+'/'+n for n in files],received)
end=load(received/'FINISH.json')
assert (end['status'],end['completed_red_rounds'],end['blue_rounds'],end['layout_evaluations'])==('COMPLETE',1,0,0)
official=PurePosixPath(end['result_dir'])
assert official.is_relative_to(PurePosixPath(remote)/'official_sdk/results_swarm_rescue')
for file,digest in end['files'].items():
    path=PurePosixPath(file)
    assert not path.is_absolute() and '..' not in path.parts
    download([str(official/path)],received/'official'/path.parent)
    assert h(received/'official'/file)==digest
for file,digest in load(received/'EXTRA_ARTIFACTS.json').items():assert h(received/file)==digest
assert load(received/'POST_RUN_SOURCE_CHECK.json')['status']=='PASS'
build=load(r/'BUILD.json')
start=load(received/'START.json');prior_start=load(old/'START.json')
score=load(received/'OFFICIAL_SCORE.json');prior=load(old/'OFFICIAL_SCORE.json')
assert h(r/'candidate_snapshot.zip')==build['candidate_zip_sha256']=='0aaed704f050073b664d4c0bece9f9ff6500e59edf55c78a7284036f01c167e7'
assert h(r/'baseline_snapshot.zip')==build['baseline_zip_sha256']=='e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791'
assert start['solutions_sha256']==load(received/'SOURCE_MATCH.json')['candidate']==build['candidate_files']
assert prior_start['solutions_sha256']==build['original_files']
for field in ['seed','sdk','sdk_archive_sha256','map_name','drones','bombs_per_drone','timestep_limit','walltime_limit','competition_mode','spawn','zones']:
    assert start[field]==prior_start[field],field
assert (start['seed'],start['map_name'],start['drones'],start['bombs_per_drone'],start['timestep_limit'],start['walltime_limit'])==(615,name,5,2,5400,180)
assert start['sdk']=='6557940dc18549ffc7a945db887da5b05b7ed2f1'
for path,s in [(received,score),(old,prior)]:
    assert h(path/'placement_events.jsonl')==s['placement_events_sha256']
    assert h(path/'wall_geometry.npz')==s['wall_geometry_sha256']
    for file,digest in load(path/'FINISH.json')['files'].items():assert h(path/'official'/file)==digest
    assert s['submitted_map'] and s['selected_submission']['image_sha256']==s['selected_image_sha256']
    assert math.isclose(s['partial'],.5*s['map_score']+.2*s['coverage']+.1*s['time_score'],abs_tol=1e-9)
    assert len(load(next((path/'official').glob('*_bombs.json')))['bombs'])==s['placed']
log=(received/'dispatch.log').read_text(encoding='utf8')
assert log.count('START '+name+' v17_wallmargin5 seed615')==1
assert log.count('COMPLETE '+name+' v17_wallmargin5 seed615')==1

def summary(s):
    selected=s['selected_submission']
    drone=next(d for d in s['drone_details'] if d['drone']==selected['drone'])
    event=drone['walltime_submission']
    confirmation={str(d['drone']):d['last_confirmation'] for d in s['drone_details']}
    return dict(partial_score_out_of_80=s['partial'],map_score=s['map_score'],wall_score=s['coverage'],time_score=s['time_score'],
        submission_drone=selected['drone'],submission_step=selected['step'],submission_walltime_seconds=selected['walltime_seconds'],
        final_walltime_seconds=s['elapsed_walltime'],remaining_walltime_at_submission=None if event is None else event.get('remaining_walltime'),
        remaining_walltime_at_finish=s['walltime_limit']-s['elapsed_walltime'],placed=s['placed'],expected=s['expected'],
        exploration_percent=s['trajectory'],all_submissions=s['submissions'],selected_map_sha256=s['selected_image_sha256'],
        submission_mode='ordinary' if event is None else event.get('fallback','deadline_election'),fallback=event,
        selected_cache=drone['group_best_metadata'],selected_group_cache_sha256=drone['group_cached_image_sha256'],
        missed_wall_pixels=s['map_breakdown']['wall_pixels']-s['map_breakdown']['wall_hits'],
        charged_misdraw_pixels=s['map_breakdown']['charged_pixels'],total_health_lost=sum(25-d['health'] for d in s['drone_details']),
        per_drone_last_confirmation=confirmation,last_bomb_confirmation_step=max(v for v in confirmation.values() if v is not None),
        inventories_at_end={str(d['drone']):d['inventory'] for d in s['drone_details']})

arms=dict(V16=summary(prior),V17=summary(score))
fields=['partial_score_out_of_80','map_score','wall_score','time_score','submission_step','submission_walltime_seconds',
        'final_walltime_seconds','remaining_walltime_at_finish','placed','exploration_percent','missed_wall_pixels',
        'charged_misdraw_pixels','total_health_lost','last_bomb_confirmation_step']
delta={field:arms['V17'][field]-arms['V16'][field] for field in fields}
old_grid=load(next((old/'official').glob('*_exploration.json')))['grid']
new_grid=load(next((received/'official').glob('*_exploration.json')))['grid']
assert sha256(bytes(x for row in old_grid for x in row)).hexdigest()==prior['selected_image_sha256']
assert sha256(bytes(x for row in new_grid for x in row)).hexdigest()==score['selected_image_sha256']
same_image=old_grid==new_grid
assert same_image==(prior['selected_image_sha256']==score['selected_image_sha256'])
decomposition=dict(map=.5*delta['map_score'],wall=.2*delta['wall_score'],time=.1*delta['time_score'])
assert math.isclose(sum(decomposition.values()),delta['partial_score_out_of_80'],abs_tol=1e-9)
binding=dict(status='PASS',V17_zip_sha256=build['candidate_zip_sha256'],V16_zip_sha256=build['baseline_zip_sha256'],
    V17_runtime_source_sha256=start['solutions_sha256'],V16_runtime_source_sha256=prior_start['solutions_sha256'],
    post_run_source_check=load(received/'POST_RUN_SOURCE_CHECK.json'),
    observer_byte_identical_to_V16=h(r/'stage_run.py')==h(old_root/'stage_run.py'),
    config_byte_identical_to_V16=h(folder/'place_map09.yml')==h(old_root/name/'place_map09.yml'),
    sdk_seed_spawns_zones_limits_matched=True,new_red_rounds=1,new_V16_rounds=0,blue_rounds=0,
    authorized_maps=['Map06','Map08'],outside_authorized_maps_run=0,
    V17_official_score_sha256=h(received/'OFFICIAL_SCORE.json'),V16_official_score_sha256=h(old/'OFFICIAL_SCORE.json'))
early_assessment=dict(actual_submitted_bitmap_identical=same_image,all_ten_bombs_placed=score['placed']==10,
    map_score_change=delta['map_score'],missed_wall_change=delta['missed_wall_pixels'],misdraw_change=delta['charged_misdraw_pixels'],
    last_bomb_confirmation_to_submission_steps=arms['V17']['submission_step']-arms['V17']['last_bomb_confirmation_step'],
    scope='Observed losses or preservation against this existing V16 run only; no counterfactual guarantee of all future mapping information.')
result=dict(status='COMPLETE',map=name,seed=615,new_red_rounds=1,algorithm_changes=False,arms=arms,V17_minus_V16=delta,
    score_delta_components=decomposition,early_submission_assessment=early_assessment,source_binding=binding,
    score_scope='Red subtotal out of 80; no blue bomb-difficulty calibration or official website run.',
    measurement_scope='SDK sampled submission walltime versus final walltime including round closing. Each current V17 run compared with existing V16, not a fresh paired timing trial.')
save(folder/'RESULTS.json',result)
with ZipFile(folder/'RUN_EVIDENCE.zip','w',compression=ZIP_DEFLATED) as archive:
    for path in sorted(received.rglob('*')):
        if path.is_file():archive.write(path,'V17/'+path.relative_to(received).as_posix())
    for file in ['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','POST_RUN_SOURCE_CHECK.json']:
        archive.write(old/file,'existing_V16/'+file)
    for path in (old/'official').glob('*_exploration.json'):archive.write(path,'existing_V16/official/'+path.name)
    for file in ['stage_run.py','run_once.sh','place_map09.yml','OBSERVATION_BINDING.json','PATCH_BINDING.json','BUILD.json',
                 'OFFLINE_CHECK.json','DECLARED_SOURCE.json','matched_spawns.json','EXPECTED_ZONES.json']:
        archive.write(folder/file,'harness/'+file)
    for file in ['AUTHORIZED_RUN.json','provision.py','collect_one.py','SDK_SELECTION_EVIDENCE.json']:
        archive.write(r/file,'harness/'+file)
print(json.dumps(dict(map=name,arms=arms,delta=delta,score_delta_components=decomposition,
    early_submission_assessment=early_assessment),indent=2,ensure_ascii=False))
