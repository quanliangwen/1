from pathlib import Path
from zipfile import ZipFile
import ast
import json
import struct
import sys

r=Path(__file__).resolve().parent
name=sys.argv[1]
assert name in ('Map06','Map08')
old_root=r.parent/('team615_first_round_yield_map06_20261121' if name=='Map06' else 'team615_first_round_yield_maps_20261121')
paths={'V16':old_root/name/'received','V17':r/name/'received'}
def array(path,key):
    with ZipFile(path) as archive:raw=archive.read(key+'.npy')
    offset=10 if raw[6]==1 else 12
    count=struct.unpack('<H' if offset==10 else '<I',raw[8:offset])[0]
    header=ast.literal_eval(raw[offset:offset+count].decode('latin1').strip())
    assert header['fortran_order'] is False
    return header,raw[offset+count:]
timestamps={};states={};summary={}
for label,p in paths.items():
    recording=next((p/'official/recordings').glob('*.npz'))
    header,body=array(recording,'timestamps')
    assert header['descr']=='<f8'
    times=struct.unpack('<'+str(len(body)//8)+'d',body);timestamps[label]=times
    header,body=array(recording,'drone_states');states[label]=(header,body)
    frames=header['shape'][0];assert frames==len(times)
    intervals=sorted([(times[i]-times[i-1],i,times[i-1],times[i]) for i in range(1,len(times))],reverse=True)
    summary[label]=dict(recorded_frames=frames,last_recorded_walltime=times[-1],largest_five_recorded_intervals=intervals[:5])
a,ab=states['V16'];b,bb=states['V17']
assert a['descr']==b['descr'] and a['shape'][1:]==b['shape'][1:]
size_a=len(ab)//a['shape'][0];size_b=len(bb)//b['shape'][0];assert size_a==size_b
length=min(a['shape'][0],b['shape'][0])
first=next((i for i in range(length) if ab[i*size_a:(i+1)*size_a]!=bb[i*size_a:(i+1)*size_a]),None)
samples=[]
for index in [999,1999,2999,3295,3499,3749,length-2,length-1]:
    if 0<=index<length:
        samples.append(dict(record_index=index,V16_walltime=timestamps['V16'][index],V17_walltime=timestamps['V17'][index],
            difference=timestamps['V17'][index]-timestamps['V16'][index]))
out=dict(map=name,scope='Offline read-only inspection of two already recorded NPZ files. No control, physics, or match replay.',
    timestamps=summary,first_different_recorded_drone_state=first,common_recorded_frames=length,
    all_common_drone_state_bytes_identical=first is None,sampled_same_record_indices=samples,
    caution='Record indices are replay frame indices, not asserted controller steps. Timing differences before the changed cutoff can affect existing wall-clock-dependent branches.')
(r/name/'OFFLINE_TIMING.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
print(json.dumps(out,indent=2))
