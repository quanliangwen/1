from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import ast
import json

r=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
for name in ['Map06','Map08']:
    result=read(r/name/'RESULTS.json')
    old_root=r.parent/('team615_first_round_yield_map06_20261121' if name=='Map06' else 'team615_first_round_yield_maps_20261121')
    for label,path in [('V16',old_root/name/'received'),('V17',r/name/'received')]:
        score=read(path/'OFFICIAL_SCORE.json');arm=result['arms'][label]
        drone=next(d for d in score['drone_details'] if d['drone']==arm['submission_drone'])
        events=[e for e in drone['group_audit'] if e[1] in ('soft_cutoff_submit','submitted')]
        if arm['fallback'] is None and any(e[1]=='soft_cutoff_submit' for e in events):arm['submission_mode']='soft_cutoff'
        arm['group_submit_events']=events
        if arm['remaining_walltime_at_submission'] is None:
            arm['remaining_walltime_at_submission']=180.-arm['submission_walltime_seconds']
    save(r/name/'RESULTS.json',result)
with ZipFile(r/'candidate_snapshot.zip') as z:
    group=z.read('group_exchange.py').decode('utf8')
    baseline=ZipFile(r/'baseline_snapshot.zip')
    assert z.read('group_exchange.py')==baseline.read('group_exchange.py')
tree=ast.parse(group)
methods={n.name:ast.get_source_segment(group,n) for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name in ('expired','yield_first_round','in_submission_slot')}
assert '<=8' in methods['expired'] and 'PreSubmitScan.MIN_WALLTIME_LEFT' in methods['yield_first_round']
new8=read(r/'Map08/received/OFFICIAL_SCORE.json')
old8=read(r.parent/'team615_first_round_yield_maps_20261121/Map08/received/OFFICIAL_SCORE.json')
detail0=next(d for d in new8['drone_details'] if d['drone']==0)
detail1=next(d for d in new8['drone_details'] if d['drone']==1)
assert detail0['walltime_submission'] is None
assert any(e[0]==3445 and e[1]=='soft_cutoff_submit' for e in detail0['group_audit'])
assert detail1['group_cached_image_sha256']==old8['selected_image_sha256']
timing6=read(r/'Map06/OFFLINE_TIMING.json');timing8=read(r/'Map08/OFFLINE_TIMING.json')
findings=dict(status='CONFIRMED_FROM_EXISTING_LOGS_AND_SOURCE',new_matches_for_analysis=0,
    Map06=dict(actual_5_second_hard_fallback=True,all_ten_bombs_confirmed_at=3297,submission_step=3868,
        observed_map_loss=4.23406520382423,
        same_record_index_3499_times=next(v for v in timing6['sampled_same_record_indices'] if v['record_index']==3499),
        interpretation='Slower per-frame progression existed long before the changed reserve could trigger. The 1214-step reduction and map loss cannot be attributed solely to adding 3.5 seconds reserve.'),
    Map08=dict(actual_5_second_hard_fallback=False,actual_exit='group soft_cutoff_submit',submission_step=3445,
        submission_walltime=172.37391233444214,walltime_left=180.-172.37391233444214,
        group_soft_cutoff_seconds=8,first_round_yield_released_below_seconds=12,
        zero_final_snapshots=detail0['group_final_snapshot_count'],one_final_snapshots=detail1['group_final_snapshot_count'],
        one_holds_bitmap_identical_to_V16_submission=True,one_cache_sha256=detail1['group_cached_image_sha256'],
        one_historical_identical_bitmap_map_score=old8['map_score'],
        last_large_frame=dict(record_index=3442,start=166.7546191215515,end=172.37391233444214,duration=5.619293212890625),
        interpretation='An unchanged low-walltime soft exit released the first-round yield and let drone0 submit inside its slot before drone1 slot. No hard deadline event occurred; do not label this a direct 5-second-hard-fallback regression.'),
    unchanged_source_sha256=sha256(group.encode('utf8')).hexdigest(),source_evidence=methods,
    boundary='One new run per authorized map versus historical V16 timing; machine load and per-frame costs were not matched.')
save(r/'FINDINGS.json',findings)
print(json.dumps(findings,indent=2,ensure_ascii=False))
