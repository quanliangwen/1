from pathlib import Path, PurePosixPath
from hashlib import sha256
from zipfile import ZipFile, ZIP_DEFLATED
import json
import math
import subprocess

r=Path(__file__).resolve().parent
folder=r/'Map09'
received=folder/'received'
host='quanliangwen@10.112.162.60'
remote=(r/'SERVER_STAGE.txt').read_text().strip()+'/Map09'
old=r.parent/'team615_first_round_yield_maps_20261121/Map09/received'
load=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def download(paths,dest):
    dest.mkdir(parents=True,exist_ok=True)
    subprocess.run(['scp','-q','-o','BatchMode=yes',*[host+':'+p for p in paths],str(dest)],check=True)

files=['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','placement_events.jsonl',
       'run.log','dispatch.log','wall_geometry.npz','group_dataset.npz','GROUP_DATASET.json',
       'POST_RUN_SOURCE_CHECK.json','EXTRA_ARTIFACTS.json']
download([remote+'/'+n for n in files],received)
end=load(received/'FINISH.json')
assert end['status']=='COMPLETE' and end['completed_red_rounds']==1 and end['blue_rounds']==end['layout_evaluations']==0
official=PurePosixPath(end['result_dir'])
assert official.is_relative_to(PurePosixPath(remote)/'official_sdk/results_swarm_rescue')
for name,digest in end['files'].items():
    path=PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts
    download([str(official/path)],received/'official'/path.parent)
    assert h(received/'official'/name)==digest
for name,digest in load(received/'EXTRA_ARTIFACTS.json').items():assert h(received/name)==digest
assert load(received/'POST_RUN_SOURCE_CHECK.json')['status']=='PASS'
build=load(r/'BUILD.json')
start=load(received/'START.json');prior_start=load(old/'START.json')
score=load(received/'OFFICIAL_SCORE.json');prior=load(old/'OFFICIAL_SCORE.json')
assert h(r/'candidate_snapshot.zip')==build['candidate_zip_sha256']=='0aaed704f050073b664d4c0bece9f9ff6500e59edf55c78a7284036f01c167e7'
assert h(r/'baseline_snapshot.zip')==build['baseline_zip_sha256']=='e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791'
assert start['solutions_sha256']==load(received/'SOURCE_MATCH.json')['candidate']==build['candidate_files']
assert prior_start['solutions_sha256']==build['original_files']
for field in ['seed','sdk','sdk_archive_sha256','map_name','drones','bombs_per_drone',
              'timestep_limit','walltime_limit','competition_mode','spawn','zones']:
    assert start[field]==prior_start[field],field
assert (start['seed'],start['map_name'],start['drones'],start['bombs_per_drone'],start['timestep_limit'],start['walltime_limit'])==(615,'Map09',5,2,5400,180)
assert start['sdk']=='6557940dc18549ffc7a945db887da5b05b7ed2f1'
for path,s in [(received,score),(old,prior)]:
    assert h(path/'placement_events.jsonl')==s['placement_events_sha256']
    assert h(path/'wall_geometry.npz')==s['wall_geometry_sha256']
    for name,digest in load(path/'FINISH.json')['files'].items():assert h(path/'official'/name)==digest
    assert s['submitted_map'] and s['selected_submission']['image_sha256']==s['selected_image_sha256']
    assert math.isclose(s['partial'],.5*s['map_score']+.2*s['coverage']+.1*s['time_score'],abs_tol=1e-9)
    bombs=load(next((path/'official').glob('*_bombs.json')))['bombs']
    assert len(bombs)==s['placed']
log=(received/'dispatch.log').read_text(encoding='utf8')
assert log.count('START Map09 v17_wallmargin5 seed615')==1
assert log.count('COMPLETE Map09 v17_wallmargin5 seed615')==1
assert 'START Map08' not in log and 'START Map06' not in log

def summary(s):
    selected=s['selected_submission']
    drone=next(d for d in s['drone_details'] if d['drone']==selected['drone'])
    event=drone['walltime_submission']
    return dict(partial_score_out_of_80=s['partial'],map_score=s['map_score'],wall_score=s['coverage'],
        time_score=s['time_score'],submission_drone=selected['drone'],submission_step=selected['step'],
        submission_walltime_seconds=selected['walltime_seconds'],final_walltime_seconds=s['elapsed_walltime'],
        remaining_walltime_at_submission=None if event is None else event['remaining_walltime'],
        remaining_walltime_at_finish=s['walltime_limit']-s['elapsed_walltime'],placed=s['placed'],
        expected=s['expected'],exploration_percent=s['trajectory'],
        all_submissions=[dict(drone=d['drone'],step=d['step'],walltime_seconds=d['walltime_seconds']) for d in s['submissions']],
        selected_map_sha256=s['selected_image_sha256'],fallback=event,
        selected_cache=drone['group_best_metadata'],
        missed_wall_pixels=s['map_breakdown']['wall_pixels']-s['map_breakdown']['wall_hits'],
        charged_misdraw_pixels=s['map_breakdown']['charged_pixels'],
        total_health_lost=sum(25-d['health'] for d in s['drone_details']))

arms=dict(V16=summary(prior),V17=summary(score))
fields=['partial_score_out_of_80','map_score','wall_score','time_score','submission_step',
        'submission_walltime_seconds','final_walltime_seconds','remaining_walltime_at_finish','placed',
        'exploration_percent','missed_wall_pixels','charged_misdraw_pixels','total_health_lost']
delta={key:arms['V17'][key]-arms['V16'][key] for key in fields}
old_grid=load(next((old/'official').glob('*_exploration.json')))['grid']
new_grid=load(next((received/'official').glob('*_exploration.json')))['grid']
assert sha256(bytes(x for row in old_grid for x in row)).hexdigest()==prior['selected_image_sha256']
assert sha256(bytes(x for row in new_grid for x in row)).hexdigest()==score['selected_image_sha256']
same_image=old_grid==new_grid
assert same_image==(prior['selected_image_sha256']==score['selected_image_sha256'])
decomposition=dict(map=.5*delta['map_score'],wall=.2*delta['wall_score'],time=.1*delta['time_score'])
assert math.isclose(sum(decomposition.values()),delta['partial_score_out_of_80'],abs_tol=1e-9)
binding=dict(status='PASS',V17_zip_sha256=build['candidate_zip_sha256'],V16_zip_sha256=build['baseline_zip_sha256'],
    V17_runtime_source_sha256=start['solutions_sha256'],V16_runtime_source_sha256=prior_start['solutions_sha256'],
    post_run_source_check=load(received/'POST_RUN_SOURCE_CHECK.json'),
    observed_harness_byte_identical_to_V16=h(r/'stage_run.py')==h(r.parent/'team615_first_round_yield_maps_20261121/stage_run.py'),
    config_byte_identical_to_V16=h(folder/'place_map09.yml')==h(r.parent/'team615_first_round_yield_maps_20261121/Map09/place_map09.yml'),
    sdk_seed_spawns_zones_limits_matched=True,new_red_rounds=1,new_V16_rounds=0,blue_rounds=0,other_maps_run=0,
    V17_official_score_sha256=h(received/'OFFICIAL_SCORE.json'),V16_official_score_sha256=h(old/'OFFICIAL_SCORE.json'))
result=dict(status='COMPLETE',map='Map09',seed=615,new_red_rounds=1,other_maps_run=0,algorithm_changes=False,
    arms=arms,V17_minus_V16=delta,score_delta_components=decomposition,actual_submitted_bitmap_identical=same_image,
    source_binding=binding,score_scope='Red subtotal out of 80; no new blue/bomb-difficulty calibration; not an official website result.',
    measurement_scope='Submission walltime is the SDK walltime supplied to the controller. Final walltime includes round closing work. One current V17 run versus one existing V16 run, not a fresh paired timing experiment.')
save(r/'RESULTS.json',result)
delivery=r/'delivery';delivery.mkdir(exist_ok=True)
save(delivery/'RESULTS.json',result)
save(delivery/'SOURCE_BINDING.json',binding)
rows=[('交图者',str(arms['V16']['submission_drone'])+'号',str(arms['V17']['submission_drone'])+'号'),
      ('交图步数',str(arms['V16']['submission_step']),str(arms['V17']['submission_step'])),
      ('交图调用墙钟',f"{arms['V16']['submission_walltime_seconds']:.6f}秒",f"{arms['V17']['submission_walltime_seconds']:.6f}秒"),
      ('最终墙钟',f"{arms['V16']['final_walltime_seconds']:.6f}秒",f"{arms['V17']['final_walltime_seconds']:.6f}秒"),
      ('红队小计/80',f"{arms['V16']['partial_score_out_of_80']:.6f}",f"{arms['V17']['partial_score_out_of_80']:.6f}"),
      ('地图分',f"{arms['V16']['map_score']:.6f}",f"{arms['V17']['map_score']:.6f}"),
      ('实投数',str(arms['V16']['placed']),str(arms['V17']['placed']))]
table='| 指标 | 已有V16 | 本次V17 |\n|---|---:|---:|\n'+''.join('| '+label+' | '+a+' | '+b+' |\n' for label,a,b in rows)
new=arms['V17']
text='# V17与已有V16：Map09，种子615，单次对照\n\n'+table+'\n'
text+=f"V17实际调用交图时距180秒上限尚有{new['remaining_walltime_at_submission']:.6f}秒；结算结束后仍有{new['remaining_walltime_at_finish']:.6f}秒。触发原因：`{new['fallback']['fallback']}`。全部提交记录：`{json.dumps(new['all_submissions'],ensure_ascii=False)}`。SDK按无人机顺序采用第一份提交，不能把同帧提交误称为按真实地图分选优。\n\n"
text+=f"本次与V16实际提交图片{'逐字节相同' if same_image else '不同'}；地图项贡献变化{decomposition['map']:+.6f}、炸墙项{decomposition['wall']:+.6f}、步数时间项{decomposition['time']:+.6f}，红队小计合计{delta['partial_score_out_of_80']:+.6f}。详细地图缺漏、误画、探索率、掉血和缓存版本见RESULTS.json。\n\n"
text+='严格只新跑1场V17 Map09，未重跑V16、未跑其他地图或蓝队、未修改算法或SDK、未改变导航或拟合。最终ZIP及运行前后56个源码成员SHA均核验，SDK/种子/出生点/区域/时限/线程配置与已有V16保持一致，观测脚本逐字节相同。两次运行的机器负载和每步耗时可能不同，不能把全部步数差异只归因于预留从1.5秒变5秒。\n\n'
text+='这里的得分为红队小计（满分80），未运行蓝队炸弹难度校准，不是官网校准总分，也不构成多种子性能保证。交图调用墙钟为SDK提供给控制器的采样值；最终墙钟包括比赛收尾。\n\n'
text+='V17提交包SHA256：`'+build['candidate_zip_sha256']+'`；原发布：[V17](https://github.com/quanliangwen/1/tree/61cac2ba23b0d1ffb81115f738d3d6a0d35ad149/team615_submissions/V17_wallmargin5_20261121)。已有V16证据：[三图候选的首轮30步让行Map09](https://github.com/quanliangwen/1/tree/cb079a122091ddee1f14e5bba4327260e91e82b3/team615_red_v15/first_round_yield_maps_20261121)。\n'
(delivery/'README.md').write_text(text,encoding='utf8')
with ZipFile(delivery/'RUN_EVIDENCE.zip','w',compression=ZIP_DEFLATED) as archive:
    for path in sorted(received.rglob('*')):
        if path.is_file():archive.write(path,'V17/'+path.relative_to(received).as_posix())
    for name in ['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','POST_RUN_SOURCE_CHECK.json']:
        archive.write(old/name,'existing_V16/'+name)
    for path in (old/'official').glob('*_exploration.json'):archive.write(path,'existing_V16/official/'+path.name)
    for name in ['stage_run.py','run_once.sh','place_map09.yml','OBSERVATION_BINDING.json','PATCH_BINDING.json',
                 'BUILD.json','OFFLINE_CHECK.json','DECLARED_SOURCE.json','matched_spawns.json','EXPECTED_ZONES.json']:
        archive.write(folder/name,'harness/'+name)
    for name in ['AUTHORIZED_RUN.json','provision.py','collect_and_report.py','SDK_SELECTION_EVIDENCE.json']:
        archive.write(r/name,'harness/'+name)
save(delivery/'CHECKSUMS_SHA256.json',{p.name:h(p) for p in sorted(delivery.iterdir()) if p.is_file() and p.name!='CHECKSUMS_SHA256.json'})
print(json.dumps(dict(arms=arms,delta=delta,score_delta_components=decomposition,actual_submitted_bitmap_identical=same_image),indent=2,ensure_ascii=False))
