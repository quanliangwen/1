from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import ast,json,shutil,subprocess

ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'team615_return40_only_20261122'
OLD=ROOT.parent/'team615_finish_minimal_maps05_06_07_seed615_20261122'
HOST='quanliangwen@10.112.162.60';REMOTE='/home/quanliangwen/isolated_test/'+ROOT.name
H=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf8'))
save=lambda p,d:p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
b=read(SRC/'BUILD.json');checks=[read(SRC/n) for n in ['RETURN40_TESTS.json','COUNTEREXAMPLES.json','BUDGET_REGRESSION.json']]
assert all(r['status']=='PASS' for r in checks) and sum(r['total_checks'] for r in checks)==192
assert H(SRC/'candidate_snapshot.zip')==b['candidate_zip_sha256']=='849714c8438fc9ec35b2327807b907133dc7c93bcd4b17a56d1dd0e47dafd8c4'
assert H(SRC/'baseline_snapshot.zip')==b['baseline_zip_sha256']=='c4b8513084ce114e6aae04b42489c995e73955ec545a64c5f9d999190004a562'
assert b['changed_files']==['group_exchange.py'] and b['unchanged_files']==55
limits={'Map05':[7200,240],'Map06':[5400,180],'Map07':[5400,180]}
starts={m:read(OLD/m/'received/START.json') for m in limits}
zones={m:s['zones'] for m,s in starts.items()};spawns={m:s['spawn'] for m,s in starts.items()}
assert zones=={'Map05':{'NoGpsZone':0,'NoComZone':0},'Map06':{'NoGpsZone':0,'NoComZone':1},'Map07':{'NoGpsZone':0,'NoComZone':0}}
original=(OLD/'Map05/stage_run.py').read_text(encoding='utf8')
assert original.count('        if step >= drone.limit*3//5:')==1
observer=original.replace('        if step >= drone.limit*3//5:','        if step >= drone.limit*2//5:')
for m in limits:
    stage=ROOT/m;stage.mkdir()
    for n in ['candidate_snapshot.zip','baseline_snapshot.zip']:shutil.copyfile(SRC/n,stage/n)
    with ZipFile(stage/'candidate_snapshot.zip') as z:files={n:sha256(z.read(n)).hexdigest() for n in z.namelist()}
    assert files==b['candidate_files']
    save(stage/'DECLARED_SOURCE.json',files)
    save(stage/'PATCH_BINDING.json',dict(baseline_commit='1dd95fecebdd147ff48459a66fccd619d11ef6c6',
        baseline_zip_sha256=b['baseline_zip_sha256'],candidate_zip_sha256=b['candidate_zip_sha256'],
        baseline=b['baseline_files'],candidate=files,changed=b['changed_files']))
    save(stage/'OFFLINE_CHECK.json',dict(simulation_steps=0,unit_checks=192,
        return40_checks_sha256=H(SRC/'RETURN40_TESTS.json'),counterexamples_sha256=H(SRC/'COUNTEREXAMPLES.json'),
        regression_sha256=H(SRC/'BUDGET_REGRESSION.json')))
    save(stage/'matched_spawns.json',spawns);save(stage/'EXPECTED_ZONES.json',zones);save(stage/'EXPECTED_LIMITS.json',limits)
    assert [starts[m]['timestep_limit'],starts[m]['walltime_limit']]==limits[m]
    (stage/'stage_run.py').write_text(observer,encoding='utf8',newline='\n')
    shutil.copyfile(OLD/m/'place_map09.yml',stage/'place_map09.yml')
    shell=(OLD/m/'run_monitored.sh').read_text(encoding='utf8').replace('finish_minimal','return40')
    (stage/'run_monitored.sh').write_text(shell,encoding='utf8',newline='\n')
monitor=(OLD/'received/monitor_remaining.py').read_text(encoding='utf8')
monitor=monitor.replace("maps=['Map06','Map07'];COUNT=8","maps=['Map05','Map06','Map07'];COUNT=8")
monitor=monitor.replace("'DISPATCH_REMAINING_CLAIM'","'DISPATCH_ONCE_CLAIM'")
monitor=monitor.replace("'queue_resources_remaining.jsonl'","'queue_resources.jsonl'")
monitor=monitor.replace("completed=['Map05'];lock=None","completed=[];lock=None")
(ROOT/'monitor.py').write_text(monitor,encoding='utf8',newline='\n')
shutil.copyfile(OLD/'environment.py',ROOT/'environment.py');shutil.copyfile(OLD/'watch.py',ROOT/'watch.py')
save(ROOT/'AUTHORIZED_RUN.json',dict(maps=list(limits),seed=615,rounds_per_map=1,total_red_rounds=3,
    other_maps=False,baseline_reruns=0,algorithm_changes=False,V16_remains_competition_baseline=True,
    assigned_logical_cpus=8,distinct_physical_cores=8,sibling_idle_required=False,global_load_is_admission_gate=False,
    candidate_zip_sha256=b['candidate_zip_sha256'],baseline_zip_sha256=b['baseline_zip_sha256'],native_limits=limits,retries=False))
save(ROOT/'OBSERVER_BINDING.json',dict(source_observer_sha256=H(OLD/'Map05/stage_run.py'),
    observer_sha256=H(ROOT/'Map05/stage_run.py'),same_observer_all_maps=True,
    change='inventory state-change diagnostics start at40 rather than60; actual return times remain original group audit events exported after scoring',
    score_and_control_commands_unmodified=True,seed_spawn_zone_limits_verified=True,native_limits=limits,actual_zones=zones))
for p in [*ROOT.glob('*.py'),*ROOT.glob('*/stage_run.py')]:ast.parse(p.read_text(encoding='utf8'))
subprocess.run(['ssh','-o','BatchMode=yes',HOST,'mkdir '+REMOTE],check=True)
subprocess.run(['scp','-q',*[str(ROOT/n) for n in ['monitor.py','environment.py','watch.py','AUTHORIZED_RUN.json','OBSERVER_BINDING.json']],HOST+':'+REMOTE+'/'],check=True)
for m in limits:
    subprocess.run(['ssh',HOST,'mkdir '+REMOTE+'/'+m],check=True)
    subprocess.run(['scp','-q',*[str(p) for p in (ROOT/m).iterdir()],HOST+':'+REMOTE+'/'+m+'/'],check=True)
subprocess.run(['ssh',HOST,'/home/junhao/quan/parallel_test_solver/match/.venv/bin/python '+REMOTE+'/environment.py'],check=True)
print(subprocess.run(['ssh',HOST,'nohup python3 '+REMOTE+'/monitor.py > '+REMOTE+'/queue.log 2>&1 < /dev/null & echo RETURN40_MAP05_MAP06_MAP07_ONCE_EACH_QUEUED'],capture_output=True,text=True,check=True).stdout)
