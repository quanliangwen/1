from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json,subprocess

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'team615_finish_minimal_maps05_06_07_seed615_20261122'
read=lambda p:json.loads(p.read_text(encoding='utf8'))
save=lambda p,d:p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
maps=['Map05','Map06','Map07'];rows={m:read(ROOT/m/'RESULTS.json') for m in maps}
assert all(r['status']=='COMPLETE' and r['new_red_rounds']==1 and r['baseline_reruns']==0 for r in rows.values())
candidate=ROOT.parent/'team615_return40_only_20261122/candidate_snapshot.zip'
baseline=ROOT.parent/'team615_budget93_finish_minimal_20261122/candidate_snapshot.zip'
v16=ROOT.parent/'team615_red_v16_first30_release_20261121/delivery/team615_red_v16.zip'
assert sha256(candidate.read_bytes()).hexdigest()=='849714c8438fc9ec35b2327807b907133dc7c93bcd4b17a56d1dd0e47dafd8c4'
assert sha256(baseline.read_bytes()).hexdigest()=='c4b8513084ce114e6aae04b42489c995e73955ec545a64c5f9d999190004a562'
assert sha256(v16.read_bytes()).hexdigest()=='e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791'
host='quanliangwen@10.112.162.60';remote='/home/quanliangwen/isolated_test/'+ROOT.name
received=ROOT/'received';received.mkdir(exist_ok=True)
names=['STATUS.json','HOST.json','ENVIRONMENT.json','AUTHORIZED_RUN.json','OBSERVER_BINDING.json','monitor.py','queue_resources.jsonl','queue.log']
subprocess.run(['scp','-q',*[host+':'+remote+'/'+n for n in names],str(received)],check=True)
assert read(received/'STATUS.json')['state']=='COMPLETE' and read(received/'STATUS.json')['new_red_rounds']==3
out=ROOT/'delivery';out.mkdir(exist_ok=True)
data=dict(status='COMPLETE',seed=615,new_red_rounds=3,rounds_per_map=1,baseline_reruns=0,other_maps=False,
    algorithm_changes_during_tests=False,V16_remains_competition_baseline=True,
    candidate_commit='74f7ec2811590daa1faf1376e697095e5908fe41',candidate_zip_sha256=sha256(candidate.read_bytes()).hexdigest(),
    baseline_commit='1dd95fecebdd147ff48459a66fccd619d11ef6c6',baseline_zip_sha256=sha256(baseline.read_bytes()).hexdigest(),
    V16_archive_sha256=sha256(v16.read_bytes()).hexdigest(),maps=rows,
    environment_limitations='Both arms configured for8 logical CPUs on8 physical cores; historical pools and load differ; SMT siblings may be busy. Not an exclusive or simultaneous timing comparison.')
save(out/'RESULTS.json',data)
f=lambda v:'—' if v is None else f'{v:.4f}' if isinstance(v,float) else str(v)
report=['# 40%返航与60%返航候选：Map05、Map06、Map07，种子615\n',
 '本轮40%候选每图只完成一场，共3场红队；60%候选仅引用既有记录，未重跑。没有测试其他地图、没有在测试中修改算法、SDK、依赖、导航或拟合。V16继续作为比赛基线。\n',
 '新旧56项源码仅group_exchange.py的返航入口差异；新40%门槛为Map05=2880步、Map06/07=2160步，末弹普通完成和交图相关共享60%门槛保持。携弹、待确认、安全路径和剩余预算仍限制实际返航，不是到40%就强制飞回。\n',
 f"40%冻结归档SHA256 `{data['candidate_zip_sha256']}`；60%归档 `{data['baseline_zip_sha256']}`。三场输入及运行时56项源码前后核对通过，正式V16归档哈希未变。\n",
 'SDK6557940dc18549ffc7a945db887da5b05b7ed2f1；Map05原生7200步/240秒，Map06/07为5400步/180秒。每图5机、每机2枚；种子、出生点/朝向、地图几何、SDK归档、原生时限、区域和评分配置与各自60%旧记录核对一致。实际无GPS/禁通信区域：Map05与Map07为0/0，Map06为0/1。\n',
 '## 总体结果\n',
 '| 地图 | 版本 | SDK采用提交者/步数 | 得分小计/80 | 地图分 | 墙覆盖分 | 探索率/% | 实投 | 掉血 | 最终墙钟/秒 |',
 '|---|---|---|---:|---:|---:|---:|---:|---:|---:|']
for m,r in rows.items():
 for label,key in [('60%','baseline'),('40%','candidate')]:
    q=r[key];report.append(f"| {m} | {label} | {q['submission_drone']} / {q['submission_step']} | {f(q['score_out_of_80'])} | {f(q['map_score'])} | {f(q['wall_score'])} | {f(q['exploration_percent'])} | {q['placed']}/10 | {q['health_lost']} | {f(q['final_walltime_seconds'])} |")
report+=['','小计沿用历史口径，并核对官方0.5×地图分＋0.2×墙覆盖分＋0.1×时间分；不把未输出的炸弹项当成完整100分。提交者为SDK所采用图片的来源，不代表同帧只有该机调用提交。','']
if (ROOT/'INTERPRETATION.md').exists():report +=[(ROOT/'INTERPRETATION.md').read_text(encoding='utf8'),'']
report+=['## 实际返航接管步数\n',
 '以下取原group_audit中首次return_owned：表示通过预检并接管返航任务，不是达到比例门槛，也不是已经到达交互点。—表示截至比赛结束未实际接管。重试、到达和中止另列于RESULTS.json。\n',
 '| 地图 | 版本 | 0号 | 1号 | 2号 | 3号 | 4号 |','|---|---|---:|---:|---:|---:|---:|']
for m,r in rows.items():
 for label,key in [('60%','baseline'),('40%','candidate')]:
    report.append('| '+m+' | '+label+' | '+' | '.join(f(r[key]['first_actual_return_step'][str(i)]) for i in range(5))+' |')
report+=['','## 第二枚实投→库存确认\n',
 '| 地图 | 版本 | 0号 | 1号 | 2号 | 3号 | 4号 |','|---|---|---|---|---|---|---|']
for m,r in rows.items():
 for label,key in [('60%','baseline'),('40%','candidate')]:
    vals=[]
    for i in range(5):
        c=r[key]['confirmations'][str(i)];vals.append('未完成，剩'+str(c['remaining']) if c['second_accepted_step'] is None else f"{c['second_accepted_step']}→{c['final_bomb_confirmation_step']}")
    report.append('| '+m+' | '+label+' | '+' | '.join(vals)+' |')
report+=['','实投来自SDK _try_place_bomb成功；确认来自库存下降，发指令不算投成。分支、实际中心坐标与墙钟时间均见RESULTS.json。','',
 '## 确认与终局路径\n']
for m,r in rows.items():
 report +=[f'### {m}']
 for label,key in [('60%','baseline'),('40%','candidate')]:
    q=r[key]
    report +=[f"{label}：结束路径 `{q['ending_path']}`；全部提交 `{json.dumps(q['submission_calls'],ensure_ascii=False)}`；同帧多机提交={q['simultaneous_submission']}。",
       '首次全队零确认：`'+json.dumps(q['first_team_confirmed_step'])+'`；普通就绪：`'+json.dumps(q['ordinary_first_ready'])+'`；交互提前出口启动：`'+json.dumps(q['group_early_finish_started'])+'`。',
       '结束时仍为正库存的来源：`'+json.dumps(q['ordinary_stock_blocks_at_end'],ensure_ascii=False)+'`。stale_positive=True表示该机仍持有旧正数，而对应飞机实际已空。',
       f"选择提案后等待步数={q['selected_choice_wait_steps']}；观察到至少2步等待={q['choice_two_step_wait_observed']}（无choice为不适用）。",
       '返航任务：`'+json.dumps(q['return_tasks'],ensure_ascii=False)+'`；返航中止：`'+json.dumps(q['return_abort_events'],ensure_ascii=False)+'`。','']
report+=['## 同一步数耗时及环境\n',
 '两版均分配8个逻辑CPU，来自8个不同物理核；启动前对实际分配CPU按3次2秒采样、最大忙碌不超过5%选取，SMT兄弟线程可能忙。不是独占、整机低负载或同时同核对照。不同历史时段负载不能完全控制，墙钟差不作为纯算法加速因果结论。CPU采样和运行队列等待统计保留。',
 '40%观察器仅将库存状态变化日志起点提前到40%，其余原观察、计分和控制调用顺序不变；实际返航审计本身是原算法日志。该诊断差异仍需披露。','',
 '| 地图 | 步数 | 60%累计秒 | 40%累计秒 | 40%−60%秒 |','|---|---:|---:|---:|---:|']
for m,r in rows.items():
 for t,q in r['same_step_cumulative_timing'].items():report.append(f"| {m} | {t} | {q['baseline_seconds']:.4f} | {q['candidate_seconds']:.4f} | {q['difference']:+.4f} |")
report+=['','首个记录轨迹差异步数：`'+json.dumps({m:r['first_recorded_drone_state_difference_step'] for m,r in rows.items()})+'`。详细资源统计、漏墙、误画和原始审计见RESULTS.json与RUN_EVIDENCE.zip。','',
 '这是单种子每图单次观察。40%候选按“其他均不变”继承60%候选的既有问题，包括普通出口可能绕过choice两帧等待；本轮未修，也不因分数变化推定已经修复。未发布新的正式比赛提交包，V16保持不变。']
(out/'REPORT.md').write_text('\n'.join(report)+'\n',encoding='utf8')
with ZipFile(out/'RUN_EVIDENCE.zip','w',ZIP_DEFLATED) as z:
 for folder in [received,*[ROOT/m/'received' for m in maps]]:
    for p in folder.rglob('*'):
        if p.is_file():z.write(p,p.relative_to(ROOT).as_posix())
 for n in ['provision.py','collect_one.py','finalize.py','watch.py','AUTHORIZED_RUN.json','OBSERVER_BINDING.json','INTERPRETATION.md']:
    if (ROOT/n).exists():z.write(ROOT/n,n)
 for m in maps:
    for n in ['stage_run.py','DECLARED_SOURCE.json','PATCH_BINDING.json','OFFLINE_CHECK.json','place_map09.yml','run_monitored.sh','matched_spawns.json','EXPECTED_ZONES.json','EXPECTED_LIMITS.json']:
        z.write(ROOT/m/n,m+'/'+n)
    for n in ['OFFICIAL_SCORE.json','START.json','SOURCE_MATCH.json','placement_events.jsonl','POST_RUN_SOURCE_CHECK.json','ADMISSION.json','resources.jsonl']:
        z.write(OLD/m/'received'/n,'baseline60/'+m+'/'+n)
save(out/'CHECKSUMS_SHA256.json',{p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.is_file() and p.name!='CHECKSUMS_SHA256.json'})
print(json.dumps(dict(status='COMPLETE',new_red_rounds=3,files=4,evidence_bytes=(out/'RUN_EVIDENCE.zip').stat().st_size),indent=2))
