"""Run the unstarted candidate once on the original CPU set; retain completed V16."""
from pathlib import Path
import hashlib
import json
import statistics
import time

ROOT=Path(__file__).resolve().parent
original=(ROOT/'affinity_runner.py').read_text()
# Load only the identical external monitor helpers, never the original dispatch body.
prefix=original.split("with (ROOT/'AFFINITY_DISPATCH_ONCE_CLAIM').open('x'):pass",1)[0]
assert len(prefix)<len(original)
exec(compile(prefix,str(ROOT/'affinity_runner.py')+':helpers','exec'),globals())
with (ROOT/'CURRENT_DISPATCH_ONCE_CLAIM_POOL5PP').open('x'):pass
assert json.loads((ROOT/'V16/FINISH.json').read_text())['completed_red_rounds']==1
assert (ROOT/'V16/POST_RUN_SOURCE_CHECK.json').exists()
stage=ROOT/'current'
assert not (stage/'START.json').exists() and not (stage/'RUN_ONCE_CLAIM').exists()
selection=json.loads((ROOT/'AFFINITY_SELECTION.json').read_text());cpus=selection['logical_cpus']
control_siblings=selection['core_topology'][0]['siblings']
first_rows=[json.loads(x) for x in (ROOT/'V16/resources.jsonl').read_text().splitlines()]
background=[]
for a,b in zip(first_rows,first_rows[1:]):
    if a['test_process'] and b['test_process']:
        dt=b['monotonic']-a['monotonic'];a=a['test_process'];p=b['test_process']
        own=(p['user_seconds']+p['system_seconds']-a['user_seconds']-a['system_seconds'])/dt
        background.append(max(0.,sum(b['selected_cpu_busy_percent'].values())/100-own))
target=statistics.mean(background)
tolerance=len(cpus)*.05  # At most five percentage points of the identical 32-CPU pool.
config=json.loads((ROOT/'MONITOR_CONFIG.json').read_text());config.update(
    second_arm_gate='10-second average background CPU occupancy within five percentage points of the selected pool compared with observed V16, plus idle first physical core',
    V16_estimated_background_cpu_equivalents_mean=target,current_background_tolerance_cpu_equivalents=tolerance,
    current_gate_control_core_siblings=control_siblings,
    V16_monitor_sha256=hashlib.sha256((ROOT/'affinity_runner.py').read_bytes()).hexdigest(),
    current_monitor_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    rationale='The original idle admission did not reserve CPUs; external jobs migrated into the set during V16. Match observed background instead of claiming exclusivity.')
save(ROOT/'MONITOR_CONFIG.json',config)
queue=(ROOT/'queue_resources.jsonl').open('a',buffering=1)
sample(cpus);window=[];lock=None
try:
    while True:
        time.sleep(2);row=sample(cpus);queue.write(json.dumps(dict(version='current',mode='same_affinity_matched_background',**row))+'\n')
        busy=sum(row['selected_cpu_busy_percent'].values())/100
        window.append((row['monotonic'],busy));window=window[-6:]
        average=statistics.mean(value for _,value in window)
        control_idle=all(row['selected_cpu_busy_percent']['cpu'+str(c)]<=5 for c in control_siblings)
        good=len(window)==6 and abs(average-target)<=tolerance and control_idle
        status(dict(state='WAITING_MATCHED_BACKGROUND',version='current',completed_versions=['V16'],
             observed_pool_cpu_equivalents_mean=average,V16_target_cpu_equivalents=target,latest_sample=row,logical_cpus=cpus))
        if good:
            lock=open(LOCK,'r')
            try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:lock.close();lock=None
            if lock is not None:
                time.sleep(2);check=sample(cpus)
                if (abs(sum(check['selected_cpu_busy_percent'].values())/100-target)<=tolerance
                    and all(check['selected_cpu_busy_percent']['cpu'+str(c)]<=5 for c in control_siblings)):break
                fcntl.flock(lock,fcntl.LOCK_UN);lock.close();lock=None
    save(stage/'LOWLOAD_ADMISSION.json',dict(version='current',mode='same_fixed_cores_matched_background',
        stable_seconds=window[-1][0]-window[0][0],admission=check,logical_cpus=cpus,lock_acquired=True,
        observed_background_cpu_equivalents_mean=average,V16_background_cpu_equivalents_mean=target,
        whole_server_lowload_claim=False,cores_exclusive_claim=False))
    status(dict(state='RUNNING',version='current',completed_versions=['V16'],logical_cpus=cpus))
    print(now(),'current ADMITTED SAME CORES MATCHED BACKGROUND',average,'target',target,flush=True)
    with (stage/'dispatch.log').open('x') as output,(stage/'resources.jsonl').open('x',buffering=1) as stream:
        proc=subprocess.Popen(['bash',str(stage/'run_monitored.sh'),str(stage)],cwd=stage,stdout=output,
             stderr=subprocess.STDOUT,preexec_fn=lambda:os.sched_setaffinity(0,set(cpus)))
        index=0;pid=None
        while proc.poll() is None:
            row=sample(cpus)
            if (stage/'SDK_PID').exists():pid=int((stage/'SDK_PID').read_text())
            row['test_process']=process_sample(pid,index%5==0) if pid else None
            stream.write(json.dumps(row)+'\n');index+=1;time.sleep(1)
        code=proc.wait()
    fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
    save(stage/'MONITOR_FINISH.json',dict(utc=now(),returncode=code,pid=pid,samples=index,logical_cpus=cpus))
    if code!=0 or not (stage/'POST_RUN_SOURCE_CHECK.json').exists():raise RuntimeError('Candidate failed; no rerun')
    print(now(),'current COMPLETE',flush=True)
    status(dict(state='COMPLETE',completed_versions=['V16','current'],red_rounds=2,maps=['Map09'],
       mode='same_fixed_physical_cores_with_observed_background',logical_cpus=cpus,
       whole_server_lowload_claim=False,cores_exclusive_claim=False))
except BaseException as exc:
    status(dict(state='FAILED',error=repr(exc),no_automatic_rerun=True));raise
finally:queue.close()
