from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import ast
import json
import shutil
import subprocess

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'team615_v16_bearing_equivalent_20261122'
TEMPLATE=ROOT.parent/'team615_lowload_pair_map09_seed615_20261121'
HOST='quanliangwen@10.112.162.60'
REMOTE='/home/quanliangwen/isolated_test/'+ROOT.name
READ=lambda p:json.loads(p.read_text(encoding='utf8'))
H=lambda p:sha256(p.read_bytes()).hexdigest()
build=READ(SOURCE/'BUILD.json');eq=READ(SOURCE/'EQUIVALENCE.json')
assert build['status']==eq['status']=='PASS' and eq['checks']==2958
assert H(SOURCE/'baseline_snapshot.zip')==build['baseline_zip_sha256']=='e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791'
assert H(SOURCE/'candidate_snapshot.zip')==build['candidate_zip_sha256']=='8fe10a240d1c53c372aa5dd2b0f040b0e18c00083a5a1a1b72102c7367902149'
assert build['changed_files']==['bearing_core.py'] and build['unchanged_files']==55 and build['min_wall_margin_seconds']==1.5
for name in ['BUILD.json','EQUIVALENCE.json','baseline_snapshot.zip','candidate_snapshot.zip']:
    shutil.copyfile(SOURCE/name,ROOT/name)
runner=(TEMPLATE/'lowload_runner.py').read_text(encoding='utf8').replace('V17','V16')
(ROOT/'lowload_runner.py').write_text(runner,encoding='utf8',newline='\n')
collector=(TEMPLATE/'collect_pair.py').read_text(encoding='utf8').replace('V17','V16').replace('v17','v16')
collector=collector.replace("==['group_exchange.py']","==['bearing_core.py']")
(ROOT/'collect_pair.py').write_text(collector,encoding='utf8',newline='\n')
environment=(TEMPLATE/'environment.py').read_text(encoding='utf8').replace("'opencv-python','opencv-python-headless'","'opencv-contrib-python'")
(ROOT/'environment.py').write_text(environment,encoding='utf8',newline='\n')
origin=ROOT.parent/'team615_v17_map09_seed615_20261121/Map09'
for label in ('V16','current'):
    folder=ROOT/label;folder.mkdir(exist_ok=False)
    archive=SOURCE/('baseline_snapshot.zip' if label=='V16' else 'candidate_snapshot.zip')
    shutil.copyfile(archive,folder/'candidate_snapshot.zip')
    shutil.copyfile(SOURCE/'baseline_snapshot.zip',folder/'baseline_snapshot.zip')
    with ZipFile(archive) as z:
        members={name:sha256(z.read(name)).hexdigest() for name in z.namelist()}
        assert members==build['baseline_files' if label=='V16' else 'candidate_files']
        deadline=ast.parse(z.read('deadline_submission.py'))
        cls=next(x for x in deadline.body if isinstance(x,ast.ClassDef) and x.name=='DeadlineSubmission')
        margin=next(x.value.value for x in cls.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='MIN_WALL_MARGIN' for t in x.targets))
        assert margin==1.5
    binding=dict(baseline_commit='63ef52c4e56b37c3104ce060853b79ceab5ff133',
        baseline_zip_sha256=build['baseline_zip_sha256'],candidate_zip_sha256=H(archive),
        baseline=build['baseline_files'],candidate=members,changed=[] if label=='V16' else ['bearing_core.py'])
    for name,data in [('DECLARED_SOURCE.json',members),('PATCH_BINDING.json',binding),
                      ('OFFLINE_CHECK.json',dict(simulation_steps=0,unit_checks=2958 if label=='current' else 0)),('BUILD.json',build)]:
        (folder/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
    for name in ['stage_run.py','place_map09.yml','matched_spawns.json','EXPECTED_ZONES.json']:
        shutil.copyfile(origin/name,folder/name)
    assert H(folder/'stage_run.py')=='33f7480f3eebd207ffa28ae81b36c0fd37cabaee057ac935697934f242929592'
    run=(TEMPLATE/'V17/run_monitored.sh').read_text(encoding='utf8').replace('V17',label)
    (folder/'run_monitored.sh').write_text(run,encoding='utf8',newline='\n')
assert H(ROOT/'V16/place_map09.yml')==H(ROOT/'current/place_map09.yml')
for p in ROOT.glob('*.py'):ast.parse(p.read_text(encoding='utf8'))
authorized=dict(maps=['Map09'],seed=615,versions={'V16':build['baseline_zip_sha256'],'current':build['candidate_zip_sha256']},
    new_red_rounds_per_version=1,total_red_rounds=2,algorithm_changes=False,observer_byte_identical=True,
    config_bytes_identical=True,wall_margin_seconds_both=1.5,remote=REMOTE,
    unrelated_previously_paused_V17_queue_not_resumed=True)
(ROOT/'AUTHORIZED_RUN.json').write_text(json.dumps(authorized,indent=2)+'\n',encoding='utf8')
subprocess.run(['ssh',HOST,'mkdir '+REMOTE],check=True)
subprocess.run(['scp','-q',*[str(ROOT/n) for n in ['lowload_runner.py','environment.py','AUTHORIZED_RUN.json']],HOST+':'+REMOTE+'/'],check=True)
for label in ('V16','current'):
    subprocess.run(['ssh',HOST,'mkdir '+REMOTE+'/'+label],check=True)
    subprocess.run(['scp','-q',*[str(p) for p in (ROOT/label).iterdir()],HOST+':'+REMOTE+'/'+label+'/'],check=True)
cmd='cd '+REMOTE+' && /home/junhao/quan/parallel_test_solver/match/.venv/bin/python environment.py && nohup python3 lowload_runner.py > queue.log 2>&1 < /dev/null & echo MAP09_V16_BEARING_PAIR_QUEUED'
print(subprocess.run(['ssh',HOST,cmd],check=True,capture_output=True,text=True).stdout)
