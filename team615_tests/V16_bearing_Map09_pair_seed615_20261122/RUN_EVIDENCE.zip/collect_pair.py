"""Download and inspect completed recordings; never run a controller."""
from pathlib import Path, PurePosixPath
from hashlib import sha256
from zipfile import ZipFile, ZIP_DEFLATED
import ast
from datetime import datetime
import json
import math
import statistics
import struct
import subprocess

ROOT=Path(__file__).resolve().parent
HOST='quanliangwen@10.112.162.60'
REMOTE='/home/quanliangwen/isolated_test/'+ROOT.name
H=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf8'))
def save(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def download(paths,dest):
    dest.mkdir(parents=True,exist_ok=True)
    subprocess.run(['scp','-q',*[HOST+':'+p for p in paths],str(dest)],check=True)
def npy(data):
    width=2 if data[6]==1 else 4
    size=int.from_bytes(data[8:8+width],'little')
    return ast.literal_eval(data[8+width:8+width+size].decode('latin1')),data[8+width+size:]
def timestamps(p):
    with ZipFile(p) as archive:
        _,b=npy(archive.read('timestamps.npy'))
    return struct.unpack('<'+'d'*(len(b)//8),b)
def distribution(values):
    values=sorted(v for v in values if v is not None)
    return dict(count=len(values),minimum=values[0],mean=statistics.mean(values),median=statistics.median(values),
                p95=values[math.ceil(.95*len(values))-1],maximum=values[-1]) if values else None

download([REMOTE+'/'+name for name in ['STATUS.json','MONITOR_CONFIG.json','HOST.json','ENVIRONMENT.json',
    'queue_resources.jsonl','queue.log','affinity_queue.log','AFFINITY_SELECTION.json','AUTHORIZED_RUN.json',
    'LOWLOAD_CONFIG_BEFORE_AFFINITY.json','LOWLOAD_STATUS_BEFORE_AFFINITY.json','current_queue.log',
    'FIRST_ARM_MONITOR_CONFIG.json','STATUS_BEFORE_MATCHED_BACKGROUND_GATE.json',
    'affinity_current_only_first_gate.py']],ROOT/'received')
assert read(ROOT/'received/STATUS.json')['state']=='COMPLETE'
result={};starts={};arrays={};recorded_times={}
evidence=[]
for label in ('V16','current'):
    target=ROOT/label/'received';remote=REMOTE+'/'+label
    files=['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','placement_events.jsonl',
           'POST_RUN_SOURCE_CHECK.json','EXTRA_ARTIFACTS.json','resources.jsonl','LOWLOAD_ADMISSION.json',
           'MONITOR_FINISH.json','SDK_PID','dispatch.log','run.log','GROUP_DATASET.json','group_dataset.npz','wall_geometry.npz']
    download([remote+'/'+name for name in files],target)
    finish=read(target/'FINISH.json')
    assert (finish['status'],finish['completed_red_rounds'],finish['blue_rounds'],finish['layout_evaluations'])==('COMPLETE',1,0,0)
    assert read(target/'POST_RUN_SOURCE_CHECK.json')['status']=='PASS'
    base=PurePosixPath(finish['result_dir']);assert base.is_relative_to(PurePosixPath(remote)/'official_sdk/results_swarm_rescue')
    for name,digest in finish['files'].items():
        rel=PurePosixPath(name);assert not rel.is_absolute() and '..' not in rel.parts
        download([str(base/rel)],target/'official'/rel.parent)
        assert H(target/'official'/name)==digest
    for name,digest in read(target/'EXTRA_ARTIFACTS.json').items():assert H(target/name)==digest
    start=read(target/'START.json');starts[label]=start
    declared=read(ROOT/label/'DECLARED_SOURCE.json')
    assert start['solutions_sha256']==declared==read(target/'SOURCE_MATCH.json')['candidate']
    assert (start['map_name'],start['seed'],start['timestep_limit'],start['walltime_limit'])==('Map09',615,5400,180)
    s=read(target/'OFFICIAL_SCORE.json');assert s['submitted_map']
    assert math.isclose(s['partial'],.5*s['map_score']+.2*s['coverage']+.1*s['time_score'],abs_tol=1e-9)
    assert H(target/'placement_events.jsonl')==s['placement_events_sha256']
    assert H(target/'wall_geometry.npz')==s['wall_geometry_sha256']
    rec=next((target/'official/recordings').glob('*.npz'))
    ts=timestamps(rec);recorded_times[label]=ts;assert len(ts)==s['steps']-1
    with ZipFile(rec) as z:arrays[label]=npy(z.read('drone_states.npy'))
    cuts=[2,1001,2001,3001,3240,3444,3474,3501,4001,4501,4590,s['steps']]
    cuts=sorted(set(v for v in cuts if v<=s['steps']))
    segments=[]
    for lo,hi in zip(cuts,cuts[1:]):
        dt=[ts[i]-ts[i-1] for i in range(lo-1,hi-1)]
        segments.append(dict(start_step=lo,end_step=hi,frames=hi-lo,seconds=ts[hi-2]-ts[lo-2],
                             frame_ms=distribution([v*1000 for v in dt]),frames_over_100ms=sum(v>.1 for v in dt),
                             frames_over_1s=sum(v>1 for v in dt)))
    resources=[json.loads(l) for l in (target/'resources.jsonl').read_text().splitlines()]
    admission=read(target/'LOWLOAD_ADMISSION.json')
    # Discard only the sub-second initial launch interval from aggregate CPU stats.
    # Raw samples remain in resources.jsonl; CPU tick quantization is noisy here.
    previous=admission['admission']['monotonic'];cpus=[]
    for row in resources:
        if row['monotonic']-previous>=.5:cpus.append(row['cpu_busy_percent'])
        previous=row['monotonic']
    processes=[r for r in resources if r['test_process']]
    sched=[r['test_process']['thread_schedstat_sum'] for r in processes if 'thread_schedstat_sum' in r['test_process']]
    group=dict(cpu_busy_percent=distribution(cpus),load1=distribution([r['load1'] for r in resources]),
               samples=len(resources),cpu_sample_intervals_at_least_half_second=True,
               over_15_percent=sum(v is not None and v>15 for v in cpus),
               over_load1_32=sum(r['load1']>32 for r in resources),
               observed_cpu_seconds=max((r['test_process']['user_seconds']+r['test_process']['system_seconds'] for r in processes),default=0),
               observed_peak_rss_bytes=max((r['test_process']['rss_bytes'] for r in processes),default=0),
               maximum_observed_thread_runqueue_wait_seconds=max((r['runqueue_wait_ns']/1e9 for r in sched),default=0),
               note='Process lifetime samples include SDK initialization and result export; last sample precedes process exit.')
    group['resource_mode']='fixed_same_idle_physical_cores_not_whole_server_lowload'
    group['selected_logical_cpus']=read(ROOT/'received/AFFINITY_SELECTION.json')['logical_cpus']
    group['selected_pool_mean_busy_percent']=distribution([
        statistics.mean(row['selected_cpu_busy_percent'].values()) for row in resources if row['selected_cpu_busy_percent']])
    masks=[row['test_process']['allowed_cpu_list'] for row in processes if 'allowed_cpu_list' in row['test_process']]
    group['observed_process_cpu_masks']=list({tuple(value) for value in masks})
    unrelated=[]
    for a,b in zip(resources,resources[1:]):
        if a['test_process'] and b['test_process']:
            interval=b['monotonic']-a['monotonic']
            cpu_a=a['test_process']['user_seconds']+a['test_process']['system_seconds']
            cpu_b=b['test_process']['user_seconds']+b['test_process']['system_seconds']
            pool_busy=sum(b['selected_cpu_busy_percent'].values())/100
            unrelated.append(max(0.,pool_busy-(cpu_b-cpu_a)/interval))
    group['estimated_other_work_in_selected_pool_cpu_core_equivalents']=distribution(unrelated)
    details=s['drone_details'];chosen=s['selected_submission']
    result[label]=dict(score_out_of_80=s['partial'],map_score=s['map_score'],wall_score=s['coverage'],
        time_score=s['time_score'],exploration_percent=s['trajectory'],submission_drone=chosen['drone'],submission_step=chosen['step'],
        submission_walltime_seconds=chosen['walltime_seconds'],final_walltime_seconds=s['elapsed_walltime'],
        placed=s['placed'],all_submissions=s['submissions'],map_sha256=s['selected_image_sha256'],
        total_health_lost=sum(25-d['health'] for d in details),
        missed_wall_pixels=s['map_breakdown']['wall_pixels']-s['map_breakdown']['wall_hits'],
        charged_misdraw_pixels=s['map_breakdown']['charged_pixels'],
        last_confirmations={str(d['drone']):d['last_confirmation'] for d in details},
        ordinary_selection={str(d['drone']):d['group_ordinary_selection'] for d in details},
        first_ready={str(d['drone']):d['original_first_ready'] for d in details},
        walltime_submission={str(d['drone']):d['walltime_submission'] for d in details},
        admission=admission,resources=group,segments=segments,
        cumulative_time_at_steps={str(v):ts[v-2] for v in cuts})
    evidence.extend(p for p in target.rglob('*') if p.is_file())
assert all(starts['V16'][k]==starts['current'][k] for k in starts['V16'] if k!='solutions_sha256')
assert [k for k in starts['V16']['solutions_sha256'] if starts['V16']['solutions_sha256'][k]!=starts['current']['solutions_sha256'][k]]==['bearing_core.py']
head0,b0=arrays['V16'];head1,b1=arrays['current'];stride=85
assert len(b0)//head0['shape'][0]==len(b1)//head1['shape'][0]==stride
first=next((i for i in range(min(head0['shape'][0],head1['shape'][0])) if b0[i*stride:(i+1)*stride]!=b1[i*stride:(i+1)*stride]),None)
v16=result['V16'];current=result['current']
fields=['score_out_of_80','map_score','wall_score','time_score','submission_step','final_walltime_seconds','placed','exploration_percent','total_health_lost','missed_wall_pixels','charged_misdraw_pixels']
comparison=dict(current_minus_V16={k:current[k]-v16[k] for k in fields},
    common_trajectory_prefix_frames=min(head0['shape'][0],head1['shape'][0]) if first is None else first,
    first_different_recorded_frame=None if first is None else first+1,
    same_selected_map=v16['map_sha256']==current['map_sha256'],
    cpu_mean_difference_percent_points=current['resources']['cpu_busy_percent']['mean']-v16['resources']['cpu_busy_percent']['mean'],
    load1_mean_difference=current['resources']['load1']['mean']-v16['resources']['load1']['mean'])
shared_end=min(v16['submission_step'],current['submission_step'])
comparison['same_step_time_comparison']={str(step):dict(
    V16_seconds=recorded_times['V16'][step-2],current_seconds=recorded_times['current'][step-2],
    current_seconds_saved=recorded_times['V16'][step-2]-recorded_times['current'][step-2])
    for step in sorted(set(s for s in [1001,2001,3001,3240,3501,4001,4501,4590,5001,shared_end] if s<=shared_end))}
comparison['pre_divergence_time_comparison_step']=min(shared_end,first+1) if first is not None else shared_end
prefix_step=comparison['pre_divergence_time_comparison_step']
comparison['pre_divergence_time_saved_seconds']=recorded_times['V16'][prefix_step-2]-recorded_times['current'][prefix_step-2]
comparison['both_rounds_within_lowload_thresholds']=all(
    r['resources']['over_15_percent']==0 and r['resources']['over_load1_32']==0 for r in result.values())
comparison['run_cpu_mean_difference_within_5pp']=abs(comparison['cpu_mean_difference_percent_points'])<=5
comparison['same_observed_cpu_masks']=v16['resources']['observed_process_cpu_masks']==current['resources']['observed_process_cpu_masks']
comparison['resource_mode']='USER_AUTHORIZED_FIXED_IDLE_PHYSICAL_CORES_NOT_WHOLE_SERVER_LOWLOAD'
comparison['selected_pool_other_work_mean_difference_cpu_equivalents']=(
    current['resources']['estimated_other_work_in_selected_pool_cpu_core_equivalents']['mean']-
    v16['resources']['estimated_other_work_in_selected_pool_cpu_core_equivalents']['mean'])
delivery=ROOT/'delivery';delivery.mkdir(exist_ok=True)
save(delivery/'RESULTS.json',dict(status='COMPLETE',map='Map09',seed=615,new_red_rounds=2,versions=result,comparison=comparison))
with ZipFile(delivery/'RUN_EVIDENCE.zip','w',ZIP_DEFLATED) as z:
    for p in evidence:z.write(p,p.relative_to(ROOT).as_posix())
    for p in (ROOT/'received').iterdir():
        if p.is_file():z.write(p,p.relative_to(ROOT).as_posix())
    for p in [ROOT/'AUTHORIZED_RUN.json',ROOT/'lowload_runner.py',ROOT/'affinity_runner.py',ROOT/'affinity_current_only.py',ROOT/'provision_pair.py',ROOT/'collect_pair.py',ROOT/'environment.py']:
        z.write(p,p.name)
    for label in ('V16','current'):
        for name in ['DECLARED_SOURCE.json','PATCH_BINDING.json','place_map09.yml','stage_run.py','run_monitored.sh']:
            z.write(ROOT/label/name,label+'/'+name)
print(json.dumps(dict(versions=result,comparison=comparison),ensure_ascii=False,indent=2))
