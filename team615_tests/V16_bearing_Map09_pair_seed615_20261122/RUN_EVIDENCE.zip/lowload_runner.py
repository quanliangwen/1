"""External resource observer and one-shot dispatcher; no solution modifications."""
from pathlib import Path
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
import platform
import subprocess
import time

ROOT = Path(__file__).resolve().parent
LOCK = '/home/junhao/quan/parallel_test_solver/match/solver_study/serial_evaluation.lock'
CPU_MAX = 15.0
LOAD_MAX = 32.0
STABLE_SECONDS = 60.0

def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n')

def now():
    return datetime.now(timezone.utc).isoformat()

previous = None
def system_sample():
    global previous
    rows = Path('/proc/stat').read_text().splitlines()
    cpu = list(map(int, rows[0].split()[1:9]))
    stamp = time.monotonic()
    busy = None
    if previous is not None:
        elapsed = sum(cpu)-sum(previous[0])
        idle = cpu[3]+cpu[4]-previous[0][3]-previous[0][4]
        busy = 100.*(elapsed-idle)/elapsed if elapsed else 0.
    previous = cpu, stamp
    load = Path('/proc/loadavg').read_text().split()
    pressure = {}
    for name in ('cpu', 'memory', 'io'):
        p = Path('/proc/pressure')/name
        pressure[name] = p.read_text().strip() if p.exists() else None
    return dict(utc=now(), monotonic=stamp, cpu_busy_percent=busy,
                load1=float(load[0]),load5=float(load[1]),load15=float(load[2]),
                runnable=load[3], pressure=pressure)

def process_sample(pid, detailed):
    try:
        base = Path('/proc')/str(pid)
        raw = (base/'stat').read_text()
        fields = raw[raw.rfind(')')+2:].split()
        row = dict(pid=pid,state=fields[0],user_seconds=int(fields[11])/os.sysconf('SC_CLK_TCK'),
                   system_seconds=int(fields[12])/os.sysconf('SC_CLK_TCK'),
                   threads=int(fields[17]),cpu=int(fields[36]),
                   rss_bytes=int(fields[21])*os.sysconf('SC_PAGE_SIZE'))
        if detailed:
            counters=[0,0,0]; count=0
            for task in (base/'task').iterdir():
                try:
                    values=list(map(int,(task/'schedstat').read_text().split()))
                    counters=[a+b for a,b in zip(counters,values)];count+=1
                except (FileNotFoundError,ProcessLookupError):
                    pass
            row['thread_schedstat_sum']=dict(runtime_ns=counters[0],runqueue_wait_ns=counters[1],
                                             timeslices=counters[2],read_threads=count)
        return row
    except (FileNotFoundError, ProcessLookupError):
        return None

def status(value):
    save(ROOT/'STATUS.json',dict(utc=now(),**value))

save(ROOT/'MONITOR_CONFIG.json',dict(cpu_busy_max_percent=CPU_MAX,load1_max=LOAD_MAX,
     stable_seconds=STABLE_SECONDS,run_sample_seconds=1,queue_sample_seconds=2,
     scheduling_sample_seconds=5,lock=LOCK,versions=['V16','current'],maps=['Map09'],seed=615,
     red_rounds_per_version=1,retry_simulations=False,
     monitor_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
save(ROOT/'HOST.json',dict(utc=now(),hostname=platform.node(),platform=platform.platform(),
     logical_cpus=os.cpu_count(),cpuinfo=Path('/proc/cpuinfo').read_text().split('\n\n')[0],
     own_cgroup=Path('/proc/self/cgroup').read_text(),
     allowed_cpus=[s for s in Path('/proc/self/status').read_text().splitlines() if s.startswith('Cpus_allowed')]))

with (ROOT/'DISPATCH_ONCE_CLAIM').open('x'):
    pass
queue=(ROOT/'queue_resources.jsonl').open('x',buffering=1)
try:
    for label in ('V16','current'):
        stage=ROOT/label
        assert not (stage/'START.json').exists()
        stable=None
        lock=None
        status(dict(state='WAITING_LOW_LOAD',version=label,completed_versions=['V16'] if label=='current' else []))
        while True:
            row=system_sample();queue.write(json.dumps(dict(version=label,**row))+'\n')
            good=row['cpu_busy_percent'] is not None and row['cpu_busy_percent']<=CPU_MAX and row['load1']<=LOAD_MAX
            stable=(stable if stable is not None else row['monotonic']) if good else None
            status(dict(state='WAITING_LOW_LOAD',version=label,latest_sample=row,
                        stable_seconds=0 if stable is None else row['monotonic']-stable,
                        completed_versions=['V16'] if label=='current' else []))
            if stable is not None and row['monotonic']-stable>=STABLE_SECONDS:
                lock=open(LOCK,'r')
                try:
                    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
                except BlockingIOError:
                    lock.close();lock=None
                if lock is not None:
                    time.sleep(2)
                    check=system_sample();queue.write(json.dumps(dict(version=label,locked_recheck=True,**check))+'\n')
                    if check['cpu_busy_percent']<=CPU_MAX and check['load1']<=LOAD_MAX:
                        break
                    fcntl.flock(lock,fcntl.LOCK_UN);lock.close();lock=None;stable=None
            time.sleep(2)
        save(stage/'LOWLOAD_ADMISSION.json',dict(version=label,stable_seconds=row['monotonic']-stable,
                                                admission=check,lock_acquired=True))
        status(dict(state='RUNNING',version=label,completed_versions=['V16'] if label=='current' else []))
        print(now(),label,'ADMITTED',flush=True)
        with (stage/'dispatch.log').open('x') as output, (stage/'resources.jsonl').open('x',buffering=1) as resources:
            proc=subprocess.Popen(['bash',str(stage/'run_monitored.sh'),str(stage)],cwd=stage,stdout=output,stderr=subprocess.STDOUT)
            index=0;pid=None
            while proc.poll() is None:
                row=system_sample()
                if (stage/'SDK_PID').exists():
                    pid=int((stage/'SDK_PID').read_text())
                row['test_process']=process_sample(pid,index%5==0) if pid else None
                resources.write(json.dumps(row)+'\n');index+=1
                time.sleep(1)
            returncode=proc.wait()
        fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
        save(stage/'MONITOR_FINISH.json',dict(utc=now(),returncode=returncode,pid=pid,samples=index))
        if returncode!=0 or not (stage/'POST_RUN_SOURCE_CHECK.json').exists():
            raise RuntimeError(f'{label} failed; no automatic rerun')
        print(now(),label,'COMPLETE',flush=True)
    status(dict(state='COMPLETE',completed_versions=['V16','current'],red_rounds=2,maps=['Map09']))
except BaseException as exc:
    status(dict(state='FAILED',error=repr(exc),no_automatic_rerun=True))
    raise
finally:
    queue.close()
