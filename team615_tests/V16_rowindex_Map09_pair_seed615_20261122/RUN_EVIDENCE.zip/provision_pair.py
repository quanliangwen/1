from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import ast,json,shutil,subprocess

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'team615_v16_row_index_20261122'
PREVIOUS=ROOT.parent/'team615_v16_bearing_map09_pair_20261122'
TEMPLATE=ROOT.parent/'team615_lowload_pair_map09_seed615_20261121'
HOST='quanliangwen@10.112.162.60';REMOTE='/home/quanliangwen/isolated_test/'+ROOT.name
H=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf8'))
build=read(SOURCE/'BUILD.json');eq=read(SOURCE/'EQUIVALENCE.json');bench=read(SOURCE/'BENCHMARK.json')
assert build['status']==eq['status']=='PASS' and eq['cases']==106
assert bench['decision']=='OFFLINE_GATE_PASSED_NO_MATCH_AUTHORIZED'
assert H(SOURCE/'baseline_snapshot.zip')==build['baseline_zip_sha256']=='e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791'
assert H(SOURCE/'candidate_snapshot.zip')==build['candidate_zip_sha256']=='1dfbbfd4186063edb908bd7cb1f812a0e8956a69901f28988f632acee2c70784'
assert build['changed_files']==['line_regularization.py'] and build['unchanged_files']==55 and build['wall_margin_seconds']==1.5
for name in ['BUILD.json','EQUIVALENCE.json','baseline_snapshot.zip','candidate_snapshot.zip']:
    shutil.copyfile(SOURCE/name,ROOT/name)
runner=(PREVIOUS/'affinity_runner.py').read_text(encoding='utf8')
# All measurement helpers are unchanged. Prefer a quieter socket and high-numbered idle cores.
runner=runner.replace("with (ROOT/'AFFINITY_DISPATCH_ONCE_CLAIM').open('x'):pass",'''save(ROOT/'HOST.json',dict(utc=now(),hostname=platform.node(),platform=platform.platform(),
    logical_cpus=os.cpu_count(),cpuinfo=Path('/proc/cpuinfo').read_text().split('\\n\\n')[0],
    own_cgroup=Path('/proc/self/cgroup').read_text(),
    allowed_cpus=[s for s in Path('/proc/self/status').read_text().splitlines() if s.startswith('Cpus_allowed')]))
with (ROOT/'AFFINITY_DISPATCH_ONCE_CLAIM').open('x'):pass''')
runner=runner.replace("sorted(items,key=lambda x:x[0])","sorted(items,key=lambda x:x[0],reverse=True)")
runner=runner.replace("min(viable,key=lambda x:x[0])", "min(viable,key=lambda x:(-len(x[1]),x[0]))")
runner=runner.replace("good=all(v<=5 for v in row['selected_cpu_busy_percent'].values())",
    "good=(all(v<=5 for v in row['selected_cpu_busy_percent'].values()) and row['cpu_busy_percent']<=15 and row['load1']<=32)")
runner=runner.replace("if all(v<=5 for v in check['selected_cpu_busy_percent'].values()):break",
    "if (all(v<=5 for v in check['selected_cpu_busy_percent'].values()) and check['cpu_busy_percent']<=15 and check['load1']<=32):break")
runner=runner.replace("whole_server_lowload_required=False", "whole_server_lowload_required_at_admission=True,whole_server_cpu_max_percent=15,whole_server_load1_max=32")
runner=runner.replace("user_explicitly_authorized_mode_change=True", "user_explicitly_requested_fixed_idle_physical_cores=True")
(ROOT/'affinity_runner.py').write_text(runner,encoding='utf8',newline='\n')
shutil.copyfile(PREVIOUS/'environment.py',ROOT/'environment.py')
collector=(TEMPLATE/'collect_pair.py').read_text(encoding='utf8').replace('V17','V16').replace('v17','v16')
collector=collector.replace("==['group_exchange.py']","==['line_regularization.py']")
collector=collector.replace("'queue_resources.jsonl','queue.log'","'queue_resources.jsonl','queue.log','AFFINITY_SELECTION.json','AUTHORIZED_RUN.json'")
collector=collector.replace("ROOT/'lowload_runner.py'","ROOT/'affinity_runner.py'")
(ROOT/'collect_pair.py').write_text(collector,encoding='utf8',newline='\n')
origin=ROOT.parent/'team615_v17_map09_seed615_20261121/Map09'
for label in ['V16','current']:
    folder=ROOT/label;folder.mkdir(exist_ok=False)
    source=SOURCE/('baseline_snapshot.zip' if label=='V16' else 'candidate_snapshot.zip')
    shutil.copyfile(source,folder/'candidate_snapshot.zip');shutil.copyfile(SOURCE/'baseline_snapshot.zip',folder/'baseline_snapshot.zip')
    with ZipFile(source) as z:
        files={name:sha256(z.read(name)).hexdigest() for name in z.namelist()}
        assert files==build['baseline_files' if label=='V16' else 'candidate_files']
        assert b'MIN_WALL_MARGIN = 1.5' in z.read('deadline_submission.py')
    binding=dict(baseline_commit='63ef52c4e56b37c3104ce060853b79ceab5ff133',
        baseline_zip_sha256=build['baseline_zip_sha256'],candidate_zip_sha256=H(source),
        baseline=build['baseline_files'],candidate=files,changed=[] if label=='V16' else ['line_regularization.py'])
    for name,data in [('BUILD.json',build),('DECLARED_SOURCE.json',files),('PATCH_BINDING.json',binding),
                      ('OFFLINE_CHECK.json',dict(simulation_steps=0,unit_cases=106 if label=='current' else 0))]:
        (folder/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
    for name in ['stage_run.py','place_map09.yml','matched_spawns.json','EXPECTED_ZONES.json']:
        shutil.copyfile(origin/name,folder/name)
    assert H(folder/'stage_run.py')=='33f7480f3eebd207ffa28ae81b36c0fd37cabaee057ac935697934f242929592'
    run=(TEMPLATE/'V17/run_monitored.sh').read_text(encoding='utf8').replace('V17',label)
    (folder/'run_monitored.sh').write_text(run,encoding='utf8',newline='\n')
assert H(ROOT/'V16/place_map09.yml')==H(ROOT/'current/place_map09.yml')
auth=dict(maps=['Map09'],seed=615,versions={'V16':build['baseline_zip_sha256'],'current':build['candidate_zip_sha256']},
    new_red_rounds_per_version=1,total_red_rounds=2,algorithm_changes=False,observer_bytes_identical=True,
    config_bytes_identical=True,wall_margin_seconds_both=1.5,remote=REMOTE,other_queues_not_resumed=True)
(ROOT/'AUTHORIZED_RUN.json').write_text(json.dumps(auth,indent=2)+'\n',encoding='utf8')
for p in ROOT.glob('*.py'):ast.parse(p.read_text(encoding='utf8'))
subprocess.run(['ssh',HOST,'mkdir '+REMOTE],check=True)
subprocess.run(['scp','-q',*[str(ROOT/n) for n in ['affinity_runner.py','environment.py','AUTHORIZED_RUN.json']],HOST+':'+REMOTE+'/'],check=True)
for label in ['V16','current']:
    subprocess.run(['ssh',HOST,'mkdir '+REMOTE+'/'+label],check=True)
    subprocess.run(['scp','-q',*[str(p) for p in (ROOT/label).iterdir()],HOST+':'+REMOTE+'/'+label+'/'],check=True)
subprocess.run(['ssh',HOST,'/home/junhao/quan/parallel_test_solver/match/.venv/bin/python '+REMOTE+'/environment.py'],check=True)
command='nohup python3 '+REMOTE+'/affinity_runner.py > '+REMOTE+'/queue.log 2>&1 < /dev/null & echo ROW_INDEX_MAP09_PAIR_QUEUED_ONCE_EACH'
print(subprocess.run(['ssh',HOST,command],capture_output=True,text=True,check=True).stdout)
