from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from hashlib import sha256
import json,struct,math

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'delivery'
read=lambda p:json.loads(p.read_text(encoding='utf8'))
H=lambda p:sha256(p.read_bytes()).hexdigest()
result=read(OUT/'RESULTS.json');a=result['versions']['V16'];b=result['versions']['current'];c=result['comparison']
assert result['map']=='Map09' and result['seed']==615 and result['new_red_rounds']==2
assert c['same_observed_cpu_masks']
auth=read(ROOT/'received/AUTHORIZED_RUN.json')
with ZipFile(ROOT/'V16/candidate_snapshot.zip') as x,ZipFile(ROOT/'current/candidate_snapshot.zip') as y:
    assert x.namelist()==y.namelist() and len(x.namelist())==56
    assert [n for n in x.namelist() if x.read(n)!=y.read(n)]==['line_regularization.py']
    assert x.read('deadline_submission.py')==y.read('deadline_submission.py')
    assert b'MIN_WALL_MARGIN = 1.5' in x.read('deadline_submission.py')

def recording_times(label):
    path=next((ROOT/label/'received/official/recordings').glob('*.npz'))
    with ZipFile(path) as z:
        raw=z.read('timestamps.npy');width=2 if raw[6]==1 else 4;n=int.from_bytes(raw[8:8+width],'little')
        raw=raw[8+width+n:]
    return struct.unpack('<'+'d'*(len(raw)//8),raw)
def full_render_events(label):
    details=read(ROOT/label/'received/OFFICIAL_SCORE.json')['drone_details'];times=recording_times(label);events=[]
    for d in details:
        live=-1;last=-1
        for e in d['group_candidate_audit']:
            step,kind=e[:2]
            if kind=='snapshot_frozen' or kind=='payload_stored' and e[3]=='snapshot':last=step
            elif kind=='live_candidate_cached':live=step;events.append((step,d['drone'],'live_or_finish'))
            elif kind=='image_built':
                if e[2]==d['drone']:events.append((step,d['drone'],'frozen'))
                elif e[2]==5:
                    wall=times[step-3] if step>=3 else 0
                    if step<4590 and 180-wall>8 and live<last:events.append((step,d['drone'],'new_fusion'))
    return sorted(events)
renders={label:full_render_events(label) for label in ['V16','current']}
prefix=c['last_same_drone_and_bomb_frame_step']
render_diff_step=next((step for step in sorted({e[0] for e in renders['V16']+renders['current']})
    if [e for e in renders['V16'] if e[0]==step]!=[e for e in renders['current'] if e[0]==step]),None)
c['first_different_render_schedule_step']=render_diff_step
work_end=min(prefix,render_diff_step-1) if render_diff_step is not None else prefix
ta,tb=recording_times('V16'),recording_times('current')
c['same_physical_prefix_and_render_schedule_last_step']=work_end
c['same_physical_prefix_and_render_schedule_saved_seconds']=ta[work_end-2]-tb[work_end-2]
c['same_work_V16_seconds']=ta[work_end-2];c['same_work_candidate_seconds']=tb[work_end-2]
c['same_step_times'][str(work_end)]=dict(V16_seconds=ta[work_end-2],candidate_seconds=tb[work_end-2],
    candidate_saved_seconds=ta[work_end-2]-tb[work_end-2],within_same_physical_prefix=True,
    within_same_drone_and_bomb_prefix=True,within_same_render_schedule=True)
c['identified_full_render_calls']={label:len(v) for label,v in renders.items()}
c['render_events']=renders
closeouts={}
for label in ['V16','current']:
    score=read(ROOT/label/'received/OFFICIAL_SCORE.json')
    closeouts[label]={str(d['drone']):d['closeout_departure_audit'] for d in score['drone_details']}
    assert read(ROOT/label/'received/FINISH.json')['completed_red_rounds']==1
    assert read(ROOT/label/'received/FINISH.json')['blue_rounds']==0
    assert read(ROOT/label/'received/POST_RUN_SOURCE_CHECK.json')['status']=='PASS'
c['closeout_audits']=closeouts
closeout_difference=next((step for step in sorted({e[0] for group in closeouts.values() for rows in group.values() for e in rows})
    if {owner:[e for e in rows if e[0]==step] for owner,rows in closeouts['V16'].items()}!=
       {owner:[e for e in rows if e[0]==step] for owner,rows in closeouts['current'].items()}),None)
c['first_closeout_audit_difference_step']=closeout_difference
if closeout_difference is not None:work_end=min(work_end,closeout_difference-1)
c['matched_physics_render_closeout_last_step']=work_end
c['matched_physics_render_closeout_saved_seconds']=ta[work_end-2]-tb[work_end-2]
c['same_work_V16_seconds']=ta[work_end-2];c['same_work_candidate_seconds']=tb[work_end-2]
c['same_step_times'][str(work_end)]=dict(V16_seconds=ta[work_end-2],candidate_seconds=tb[work_end-2],
    candidate_saved_seconds=ta[work_end-2]-tb[work_end-2],within_same_physical_prefix=True,
    within_same_drone_and_bomb_prefix=True,within_same_render_schedule=True,within_same_closeout_audit=True)
for key in ['same_physical_prefix_and_render_schedule_last_step','same_physical_prefix_and_render_schedule_saved_seconds']:
    c.pop(key,None)
originals={}
for owner in range(5):
    m0=read(ROOT/'V16/received/GROUP_DATASET.json')[str(owner)]
    m1=read(ROOT/'current/received/GROUP_DATASET.json')[str(owner)]
    originals[str(owner)]=dict(same_snapshot_digest=m0['snapshots'][str(owner)]['digest']==m1['snapshots'][str(owner)]['digest'],
        same_original_image_digest=m0['images'][str(owner)]['digest']==m1['images'][str(owner)]['digest'])
c['frozen_original_cross_run_comparison']=originals
c['selected_cache_versions']={label:next(d for d in read(ROOT/label/'received/OFFICIAL_SCORE.json')['drone_details']
    if d['drone']==result['versions'][label]['submission_drone'])['group_best_metadata'] for label in ['V16','current']}
assert len(c['accepted_placements']['V16'])==len(c['accepted_placements']['current'])==10
assert c['accepted_placements']['V16'][:-1]==c['accepted_placements']['current'][:-1]
assert c['accepted_placements']['V16'][-1]['drone']==c['accepted_placements']['current'][-1]['drone']==1
assert c['selected_cache_versions']['V16']['version']==4590 and c['selected_cache_versions']['current']['version']==4950
with ZipFile(ROOT/'V16/received/wall_geometry.npz') as wa,ZipFile(ROOT/'current/received/wall_geometry.npz') as wb:
    assert wa.namelist()==wb.namelist() and all(wa.read(n)==wb.read(n) for n in wa.namelist())
c['same_wall_truth_geometry']=True
assert all(originals[str(owner)]['same_snapshot_digest'] and originals[str(owner)]['same_original_image_digest'] for owner in [0,2,3,4])
c['both_min_wall_margin_seconds']=1.5
save=lambda p,v:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
save(OUT/'RESULTS.json',result)

metrics=[('交图者','submission_drone','号'),('交图步数','submission_step',''),('得分 / 80','score_out_of_80',''),
 ('地图分','map_score',''),('墙覆盖分','wall_score',''),('时间分','time_score',''),('实投数','placed',''),
 ('指令交图时墙钟 / 秒','submission_walltime_seconds',''),('最终墙钟 / 秒','final_walltime_seconds',''),
 ('探索率 / %','exploration_percent',''),('总掉血','total_health_lost',''),('漏墙像素','missed_wall_pixels',''),
 ('计入扣分的误画像素','charged_misdraw_pixels','')]
rows=[]
for name,key,suffix in metrics:
    av,bv=a[key],b[key]
    fmt=lambda v:str(v) if type(v) is int else f'{v:.6f}'
    delta='相同' if key=='submission_drone' and av==bv else (fmt(bv-av) if bv-av==0 else f'{bv-av:+.6f}')
    rows.append(f'| {name} | {fmt(av)}{suffix} | {fmt(bv)}{suffix} | {delta} |')
timing=[]
for step,x in sorted(c['same_step_times'].items(),key=lambda x:int(x[0])):
    joint=int(step)<=prefix;matched=joint and int(step)<=work_end
    timing.append(f"| {step} | {x['V16_seconds']:.6f} | {x['candidate_seconds']:.6f} | {x['candidate_saved_seconds']:+.6f} | {'相同物理记录、制图安排及收尾审计' if matched else '已越过共同对照区间'} |")
sr,cr=a['resources'],b['resources'];selection=read(ROOT/'received/AFFINITY_SELECTION.json')
profile=read(ROOT.parent/'team615_v16_row_index_20261122/BENCHMARK.json')['results']['Map09']
report=f'''# V16 与按行索引候选：Map09种子615，固定同组物理核各一次

本轮新增两场红队Map09，每版一场。没有其他地图、蓝队或重复运行，没有修改任一算法归档。V16仍为比赛基线，本报告不自动提升候选或安排后续比赛。

## 实际结果

| 指标 | 本轮V16 | 本轮按行索引候选 | 候选－V16 |
|---|---:|---:|---:|
{chr(10).join(rows)}

最后共同无人机/炸弹物理记录对应比赛第{prefix}步。在此之前，回放记录的五机位置、朝向、存活/血量及炸弹状态字节相同，候选累计快{c['joint_prefix_time_saved_seconds']:.6f}秒。

进一步同时约束制图调用的步数、无人机、调用种类及末弹收尾审计一致，可比较到第{work_end}步：V16累计{c['same_work_V16_seconds']:.6f}秒，候选{c['same_work_candidate_seconds']:.6f}秒，节省{c['matched_physics_render_closeout_saved_seconds']:.6f}秒。

两版最终墙钟相差{a['final_walltime_seconds']-b['final_walltime_seconds']:.6f}秒。两版均保留原1.5秒墙钟预留；若都耗到墙钟兜底，最终墙钟接近，而加速体现为同一步更快、同墙钟能运行更多步。若交图方式或状态发生变化，应结合RESULTS.json中的各机deadline事件、收尾审计及提交记录解释，不能只用结束墙钟差判断计算加速。

## 同一步数累计耗时

回放第一个记录对应SDK暖启动后的比赛第2步。下表为该比赛步结束时记录的累计墙钟；指令日志用的是该步开始时缓存的上一帧墙钟，两者不混用。正的节省表示候选更快。共同区间后的行只作实际过程对照，不当作严格相同工作量。

| 实际步数 | V16秒 | 候选秒 | 候选节省秒 | 可比性 |
|---|---:|---:|---:|---|
{chr(10).join(timing)}

第一次无人机记录差异位于回放第{c['first_different_recorded_frame']}帧，第一次炸弹记录差异位于回放第{c['first_different_bomb_recorded_frame']}帧；若为null表示共同长度内没有差异。第一次制图安排差异在第{render_diff_step}步。物理记录相同是回放精度下的比较，不声称保存了全部控制器内部状态。

第一处末弹收尾审计差异在第{closeout_difference}步，因此更严格的耗时对照截止到它之前一帧。

## 制图、投放与地图

可从日志定位的完整制图调用：V16 {len(renders['V16'])}次，候选{len(renders['current'])}次。融合图直接复用现成图的事件未计成新拟合；详细事件列表在RESULTS.json。加速可能使后期真实输入、备份次数和原墙钟预算分支的触发步数变化，因此不能把各自全程的制图时间当成同数量工作比较。

两版提交地图是否逐字节相同：{c['same_selected_map']}。地图SHA256分别为：

- V16：`{a['map_sha256']}`。
- 候选：`{b['map_sha256']}`。

10次或各自实际投放事件（无人机、步数和真实落点）是否完全相同：{c['same_all_accepted_placements']}。完整投放记录和每机收尾审计均已导出；若不同，不能因为拟合公式未改就承诺整场物理过程相同。

本轮已确认的差异：1号机在V16第4341步进入末弹收尾、第4343步实投；候选第4559步进入收尾、第4561步实投。原_closeout_departure._should_enter仍要求剩余墙钟不超过25秒、尚有库存、存在首弹及停滞条件。第4341步开始时，V16缓存墙钟为155.790秒（剩24.210秒），候选为149.760秒（剩30.240秒）；候选此时不满足25秒条件，因而继续原导航，直到后续满足条件。实投真实落点从(-276.748,273.180)变为(-12.389,211.586)。投放规则源码未改，但时间条件对应的步数和后续落点改变，墙覆盖分下降与这枚末弹的变化对应；其他9次接受投放记录一致。

0号提交缓存由V16的4590版变为候选的4950版，官方地图分上升；两版最后收到的各源版本仍为2号1892、3号2613、4号4189、1号406，不能把这次地图改善归因为额外收到了1号新图。同快照输入与个人原图的跨场摘要对照见RESULTS.json：0、2、3、4号的冻结输入与原图一致；1号因末弹结束时间不同而不同。

SDK红队已计算得分为0.5×地图分＋0.2×墙覆盖分＋0.1×时间分。其候选－V16贡献分别为：地图{.5*(b['map_score']-a['map_score']):+.6f}、墙覆盖{.2*(b['wall_score']-a['wall_score']):+.6f}、时间{.1*(b['time_score']-a['time_score']):+.6f}。

## 条件和资源记录

两场共同条件：SDK提交6557940dc18549ffc7a945db887da5b05b7ed2f1、相同观察脚本SHA33f7480f3eebd207ffa28ae81b36c0fd37cabaee057ac935697934f242929592、相同配置字节、种子615、相同出生位置和朝向、NO_COM+NO_GPS、5机、每机2枚、5400步/180秒、原软件渲染及线程变量。运行前后源码摘要核验均通过。

选定CPU插槽{selection['socket']}上的16个物理核（32逻辑核），实际进程允许列表两版一致。逻辑核为`{','.join(map(str,selection['logical_cpus']))}`。CPU亲和性不独占机器，故同时逐秒记录整机及该核组占用、进程CPU与调度等待。

最初等待共享串行槽时选定的核心组因等待中后台迁入而作废；两场均尚未启动时，在串行槽可用后重新采样选核。正式两场使用的是这同一组重新确认的核心，没有在两场之间换核或放宽准入门槛。每场开跑前要求核组逐核占用≤5%，整机CPU≤15%、load1≤32，持续检查通过后才启动；共享串行锁覆盖比赛执行期间。没有终止或修改其他任务。

| 资源（进程存续期，含初始化/导出） | V16 | 候选 |
|---|---:|---:|
| 整机CPU平均忙碌率 / % | {sr['cpu_busy_percent']['mean']:.4f} | {cr['cpu_busy_percent']['mean']:.4f} |
| load1平均 | {sr['load1']['mean']:.4f} | {cr['load1']['mean']:.4f} |
| 所选核组平均忙碌率 / % | {sr['selected_pool_busy_percent']['mean']:.4f} | {cr['selected_pool_busy_percent']['mean']:.4f} |
| 组内其他计算的CPU等量估计 | {sr['estimated_other_work_cpu_equivalents_in_pool']['mean']:.4f} | {cr['estimated_other_work_cpu_equivalents_in_pool']['mean']:.4f} |
| 进程CPU时间最后观测值 / 秒 | {sr['observed_cpu_seconds']:.3f} | {cr['observed_cpu_seconds']:.3f} |
| 存活线程累计调度等待之和的最大观测值 / 秒 | {sr['maximum_observed_thread_runqueue_wait_seconds']:.6f} | {cr['maximum_observed_thread_runqueue_wait_seconds']:.6f} |

整机CPU有效样本全部≤15%：{c['whole_run_cpu_samples_within_15_percent']}；load1样本全部≤32：{c['whole_run_load1_samples_within_32']}。剔除的只是启动后不足0.5秒、容易受CPU tick量化影响的初始CPU区间，原始记录仍完整保留。

组内其他计算等量为所选核心总忙碌时间减本测试进程CPU时间的逐秒近似，含采样误差；累计线程等待不等于主线程墙钟等待，不用它校正或扣除比赛耗时。单次配对可报告本轮观察，不代表跨地图或多种子稳定结论。

## 与离线估计的关系

此前Map09按实际调用次数加权的快照外推为{profile['call_count_weighted_saved_seconds']:.3f}秒，更谨慎长帧情景为{profile['heavy_frames_one_call_minimum_snapshot_saving_scenario_seconds']:.3f}秒。本轮共同物理记录、制图安排及收尾审计区间观察到{c['matched_physics_render_closeout_saved_seconds']:.3f}秒；比较区间长度和原历史外推口径不同，不把这两个数字强行视为同一工作量。整场实测的最终分数、地图和实投结果以上表为准。

V16归档SHA256：`{auth['versions']['V16']}`。

按行索引候选归档SHA256：`{auth['versions']['current']}`。

只有line_regularization.py不同，且仅regularized_walls()取点方式改变；其他55个文件一致，1.5秒预留不变，未叠加方向函数或评分解包优化。RUN_EVIDENCE.zip保留两场官方回放/评分、逐秒CPU记录、源码与SDK校验、原观察脚本和外部监控脚本。本轮不创建新的正式比赛提交包。
'''
(OUT/'REPORT.md').write_text(report,encoding='utf8',newline='\n')
with ZipFile(OUT/'RUN_EVIDENCE.zip','a',ZIP_DEFLATED) as z:
    if 'analysis/finalize_report.py' not in z.namelist():z.write(Path(__file__),'analysis/finalize_report.py')
manifest={p.name:H(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='CHECKSUMS_SHA256.json'}
assert set(manifest)=={'RESULTS.json','REPORT.md','RUN_EVIDENCE.zip'}
save(OUT/'CHECKSUMS_SHA256.json',manifest)
print(json.dumps(dict(same_work_last_step=work_end,same_work_saved_seconds=c['matched_physics_render_closeout_saved_seconds'],
    joint_prefix_last_step=prefix,joint_prefix_saved_seconds=c['joint_prefix_time_saved_seconds'],
    final_wall_saved_seconds=a['final_walltime_seconds']-b['final_walltime_seconds'],score_delta=b['score_out_of_80']-a['score_out_of_80']),indent=2))
