"""User-authorized fixed idle physical-core comparison, exactly one match per arm."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl
import hashlib
import json
import os
import platform
import subprocess
import time

ROOT=Path(__file__).resolve().parent
LOCK='/home/junhao/quan/parallel_test_solver/match/solver_study/serial_evaluation.lock'
CORE_COUNT=16
previous=None
def now():return datetime.now(timezone.utc).isoformat()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def status(value):save(ROOT/'STATUS.json',dict(utc=now(),**value))
def counters():
    out={}
    for line in Path('/proc/stat').read_text().splitlines():
        fields=line.split()
        if fields[0]=='cpu' or fields[0].startswith('cpu') and fields[0][3:].isdigit():
            values=list(map(int,fields[1:9]));out[fields[0]]=(sum(values),values[3]+values[4])
    return out
def sample(cpus=()):
    global previous
    values=counters();busy=None;per_core={};stamp=time.monotonic()
    if previous is not None:
        for key in ['cpu']+['cpu'+str(c) for c in cpus]:
            total=values[key][0]-previous[key][0];idle=values[key][1]-previous[key][1]
            percent=100.*(total-idle)/total if total else 0.
            if key=='cpu':busy=percent
            else:per_core[key]=percent
    previous=values
    load=Path('/proc/loadavg').read_text().split()
    pressure={n:(Path('/proc/pressure')/n).read_text().strip() for n in ['cpu','memory','io']}
    return dict(utc=now(),monotonic=stamp,cpu_busy_percent=busy,load1=float(load[0]),load5=float(load[1]),
                load15=float(load[2]),runnable=load[3],pressure=pressure,selected_cpu_busy_percent=per_core)
def process_sample(pid,detailed):
    try:
        p=Path('/proc')/str(pid);raw=(p/'stat').read_text();f=raw[raw.rfind(')')+2:].split()
        result=dict(pid=pid,state=f[0],user_seconds=int(f[11])/os.sysconf('SC_CLK_TCK'),
                    system_seconds=int(f[12])/os.sysconf('SC_CLK_TCK'),threads=int(f[17]),cpu=int(f[36]),
                    rss_bytes=int(f[21])*os.sysconf('SC_PAGE_SIZE'))
        if detailed:
            total=[0,0,0];count=0
            for task in (p/'task').iterdir():
                try:
                    v=list(map(int,(task/'schedstat').read_text().split()));total=[x+y for x,y in zip(total,v)];count+=1
                except (FileNotFoundError,ProcessLookupError):pass
            result['thread_schedstat_sum']=dict(runtime_ns=total[0],runqueue_wait_ns=total[1],timeslices=total[2],read_threads=count)
            result['allowed_cpu_list']=[s for s in (p/'status').read_text().splitlines() if s.startswith('Cpus_allowed_list')]
        return result
    except (FileNotFoundError,ProcessLookupError):return None

save(ROOT/'HOST.json',dict(utc=now(),hostname=platform.node(),platform=platform.platform(),
    logical_cpus=os.cpu_count(),cpuinfo=Path('/proc/cpuinfo').read_text().split('\n\n')[0],
    own_cgroup=Path('/proc/self/cgroup').read_text(),
    allowed_cpus=[s for s in Path('/proc/self/status').read_text().splitlines() if s.startswith('Cpus_allowed')]))
with (ROOT/'AFFINITY_DISPATCH_ONCE_CLAIM').open('x'):pass
for label in ['V16','current']:
    assert not (ROOT/label/'START.json').exists() and not (ROOT/label/'RUN_ONCE_CLAIM').exists()
allowed=sorted(os.sched_getaffinity(0));groups={}
for cpu in allowed:
    p=Path('/sys/devices/system/cpu')/f'cpu{cpu}'/'topology'
    key=int((p/'physical_package_id').read_text()),int((p/'core_id').read_text())
    groups.setdefault(key,[]).append(cpu)
queue=(ROOT/'queue_resources.jsonl').open('a',buffering=1)
try:
    status(dict(state='SELECTING_IDLE_PHYSICAL_CORES',completed_versions=[]))
    while True:
        maximum={cpu:0. for cpu in allowed};sample(allowed)
        for _ in range(3):
            time.sleep(2);row=sample(allowed)
            queue.write(json.dumps(dict(mode='fixed_idle_physical_cores_selection',**row))+'\n')
            for cpu in allowed:maximum[cpu]=max(maximum[cpu],row['selected_cpu_busy_percent']['cpu'+str(cpu)])
        by_socket={}
        for key,cpus in groups.items():
            if all(maximum[cpu]<=5 for cpu in cpus):by_socket.setdefault(key[0],[]).append((key,cpus))
        viable=[(socket,sorted(items,key=lambda x:x[0],reverse=True)) for socket,items in by_socket.items() if len(items)>=CORE_COUNT]
        if viable:
            socket,selected=min(viable,key=lambda x:(-len(x[1]),x[0]));selected=selected[:CORE_COUNT]
            cpus=sorted(cpu for key,items in selected for cpu in items);break
        status(dict(state='WAITING_IDLE_PHYSICAL_CORES',idle_cores_by_socket={s:len(v) for s,v in by_socket.items()}))
    save(ROOT/'AFFINITY_SELECTION.json',dict(utc=now(),physical_cores=CORE_COUNT,logical_cpus=cpus,socket=socket,
          core_topology=[dict(socket=key[0],core=key[1],siblings=items) for key,items in selected],
          maximum_preselection_busy_percent={str(cpu):maximum[cpu] for cpu in cpus},samples=3,interval_seconds=2,
          note='CPU affinity restricts our test process; it does not reserve cores against other jobs.'))
    save(ROOT/'MONITOR_CONFIG.json',dict(mode='USER_AUTHORIZED_FIXED_IDLE_PHYSICAL_CORES',
          whole_server_lowload_required_at_admission=True,whole_server_cpu_max_percent=15,whole_server_load1_max=32,physical_cores=CORE_COUNT,logical_cpus=cpus,
          idle_gate_each_selected_logical_cpu_max_percent=5,stable_seconds=10,run_sample_seconds=1,
          scheduling_sample_seconds=5,lock=LOCK,versions=['V16','current'],maps=['Map09'],seed=615,
          red_rounds_per_version=1,retry_simulations=False,
          monitor_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
    auth=json.loads((ROOT/'AUTHORIZED_RUN.json').read_text());auth.update(
          resource_mode='fixed_same_idle_physical_cores',user_explicitly_requested_fixed_idle_physical_cores=True,
          whole_server_lowload_claim=False,physical_cores=CORE_COUNT,logical_cpus=cpus)
    save(ROOT/'AUTHORIZED_RUN.json',auth)
    for label in ['V16','current']:
        stage=ROOT/label;stable=None;lock=None;completed=['V16'] if label=='current' else []
        while True:
            time.sleep(2);row=sample(cpus);queue.write(json.dumps(dict(version=label,mode='fixed_idle_physical_cores',**row))+'\n')
            good=(all(v<=5 for v in row['selected_cpu_busy_percent'].values()) and row['cpu_busy_percent']<=15 and row['load1']<=32)
            stable=(stable if stable is not None else row['monotonic']) if good else None
            status(dict(state='WAITING_SELECTED_CORES_IDLE',version=label,completed_versions=completed,
                   stable_seconds=0 if stable is None else row['monotonic']-stable,latest_sample=row,logical_cpus=cpus))
            if stable is not None and row['monotonic']-stable>=10:
                lock=open(LOCK,'r')
                try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
                except BlockingIOError:lock.close();lock=None
                if lock is not None:
                    time.sleep(2);check=sample(cpus)
                    queue.write(json.dumps(dict(version=label,locked_recheck=True,**check))+'\n')
                    if (all(v<=5 for v in check['selected_cpu_busy_percent'].values()) and check['cpu_busy_percent']<=15 and check['load1']<=32):break
                    fcntl.flock(lock,fcntl.LOCK_UN);lock.close();lock=None;stable=None
        save(stage/'LOWLOAD_ADMISSION.json',dict(version=label,mode='fixed_idle_physical_cores',
             stable_seconds=row['monotonic']-stable,admission=check,logical_cpus=cpus,lock_acquired=True,
             whole_server_lowload_claim=False))
        status(dict(state='RUNNING',version=label,completed_versions=completed,logical_cpus=cpus))
        print(now(),label,'ADMITTED FIXED CORES',cpus,flush=True)
        with (stage/'dispatch.log').open('x') as output,(stage/'resources.jsonl').open('x',buffering=1) as stream:
            proc=subprocess.Popen(['bash',str(stage/'run_monitored.sh'),str(stage)],cwd=stage,stdout=output,
                  stderr=subprocess.STDOUT,preexec_fn=lambda:os.sched_setaffinity(0,set(cpus)))
            index=0;pid=None
            while proc.poll() is None:
                row=sample(cpus)
                if (stage/'SDK_PID').exists():pid=int((stage/'SDK_PID').read_text())
                row['test_process']=process_sample(pid,index%5==0) if pid else None
                stream.write(json.dumps(row)+'\n');index+=1;time.sleep(1)
            returncode=proc.wait()
        fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
        save(stage/'MONITOR_FINISH.json',dict(utc=now(),returncode=returncode,pid=pid,samples=index,logical_cpus=cpus))
        if returncode!=0 or not (stage/'POST_RUN_SOURCE_CHECK.json').exists():raise RuntimeError(f'{label} failed; no rerun')
        print(now(),label,'COMPLETE',flush=True)
    status(dict(state='COMPLETE',completed_versions=['V16','current'],red_rounds=2,maps=['Map09'],
                mode='fixed_idle_physical_cores',logical_cpus=cpus,whole_server_lowload_claim=False))
except BaseException as exc:
    status(dict(state='FAILED',error=repr(exc),no_automatic_rerun=True));raise
finally:queue.close()
