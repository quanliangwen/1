from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import ast,json,shutil,subprocess
ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'team615_rowindex_budget93_20261122'
OLD=ROOT.parent/'team615_v16_rowindex_maps06_08_pair_20261122'
TEMPLATE=OLD/'Map06/current'
HOST='quanliangwen@10.112.162.60';REMOTE='/home/quanliangwen/isolated_test/'+ROOT.name
H=lambda p:sha256(p.read_bytes()).hexdigest()
save=lambda p,d:p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
b=json.loads((SRC/'BUILD.json').read_text());tests=json.loads((SRC/'COUNTEREXAMPLES.json').read_text(encoding='utf8'))
assert b['status']==tests['status']=='PASS' and tests['total_checks']==56
assert H(SRC/'candidate_snapshot.zip')==b['candidate_zip_sha256']=='0ed2e45090a6a8104c0a3bf92d8ac79382a7891eccb978ffaba8a72a2b06a449'
assert H(SRC/'rowindex_baseline_snapshot.zip')==b['baseline_zip_sha256']=='1dfbbfd4186063edb908bd7cb1f812a0e8956a69901f28988f632acee2c70784'
stage=ROOT/'Map06';stage.mkdir()
for source,name in [(SRC/'candidate_snapshot.zip','candidate_snapshot.zip'),(SRC/'rowindex_baseline_snapshot.zip','baseline_snapshot.zip')]:shutil.copyfile(source,stage/name)
with ZipFile(stage/'candidate_snapshot.zip') as z:
    files={n:sha256(z.read(n)).hexdigest() for n in z.namelist()};assert files==b['candidate_files']
save(stage/'DECLARED_SOURCE.json',files)
save(stage/'PATCH_BINDING.json',dict(baseline_commit='310cc3af98d6f1ca93e81b3cebe54b8f249421f5',baseline_zip_sha256=b['baseline_zip_sha256'],candidate_zip_sha256=b['candidate_zip_sha256'],baseline=b['baseline_files'],candidate=files,changed=b['changed_files']))
save(stage/'OFFLINE_CHECK.json',dict(simulation_steps=0,unit_checks=56,counterexamples_sha256=H(SRC/'COUNTEREXAMPLES.json')))
shutil.copyfile(SRC/'BUILD.json',stage/'BUILD.json')
for n in ['place_map09.yml','matched_spawns.json','EXPECTED_ZONES.json']:shutil.copyfile(TEMPLATE/n,stage/n)
original=(TEMPLATE/'stage_run.py').read_text(encoding='utf8')
needle='last_confirmation=d.last_confirmed_drop_step,walltime_submission=d.deadline_submission_event,'
assert original.count(needle)==1
observer=original.replace(needle,needle+'\n             budget_submission=d.budget_submission_event,budget_submission_audit=d.budget_submission_audit,')
(stage/'stage_run.py').write_text(observer,encoding='utf8',newline='\n')
# Only the final, post-scoring dict export changes; no live observer callback changes.
a=ast.parse(original);c=ast.parse(observer)
def runtime_prefix(t):
    end=next(i for i,n in enumerate(t.body) if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='details' for x in n.targets))
    return ast.dump(ast.Module(body=t.body[:end],type_ignores=[]),include_attributes=False)
assert runtime_prefix(a)==runtime_prefix(c)
save(ROOT/'OBSERVER_CHANGE.json',dict(original_sha256=H(TEMPLATE/'stage_run.py'),current_sha256=H(stage/'stage_run.py'),runtime_ast_unchanged=True,change='post-scoring budget event and audit export only'))
(stage/'run_monitored.sh').write_text((TEMPLATE/'run_monitored.sh').read_text().replace(' current ',' budget93 '),encoding='utf8',newline='\n')
helper=(OLD/'affinity_runner.py').read_text().split("tasks=['Map06/V16'")[0]
(ROOT/'monitor.py').write_text(helper+(ROOT/'monitor_body.txt').read_text(),encoding='utf8',newline='\n')
shutil.copyfile(ROOT.parent/'team615_v16_rowindex_map09_pair_20261122/environment.py',ROOT/'environment.py')
save(ROOT/'AUTHORIZED_RUN.json',dict(maps=['Map06'],seed=615,total_red_rounds=1,retries=False,other_maps=False,algorithm_changes=False,candidate_zip_sha256=b['candidate_zip_sha256'],comparison='existing row-index and V16 Map06 results only; no baseline reruns',wall_margin_seconds=1.5))
for p in [*ROOT.glob('*.py'),stage/'stage_run.py']:ast.parse(p.read_text())
subprocess.run(['ssh',HOST,'mkdir '+REMOTE],check=True)
subprocess.run(['scp','-q',*[str(ROOT/n) for n in ['monitor.py','environment.py','AUTHORIZED_RUN.json','OBSERVER_CHANGE.json']],HOST+':'+REMOTE+'/'],check=True)
subprocess.run(['ssh',HOST,'mkdir '+REMOTE+'/Map06'],check=True)
subprocess.run(['scp','-q',*[str(p) for p in stage.iterdir()],HOST+':'+REMOTE+'/Map06/'],check=True)
subprocess.run(['ssh',HOST,'/home/junhao/quan/parallel_test_solver/match/.venv/bin/python '+REMOTE+'/environment.py'],check=True)
print(subprocess.run(['ssh',HOST,'nohup python3 '+REMOTE+'/monitor.py > '+REMOTE+'/queue.log 2>&1 < /dev/null & echo ONE_MAP06_MATCH_QUEUED'],capture_output=True,text=True,check=True).stdout)
