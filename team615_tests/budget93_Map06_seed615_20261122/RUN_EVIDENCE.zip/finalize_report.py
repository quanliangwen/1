from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'delivery'
read=lambda p:json.loads(p.read_text(encoding='utf8'))
save=lambda p,d:p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
r=read(OUT/'RESULTS.json');s=read(ROOT/'Map06/received/OFFICIAL_SCORE.json')
old=r['versions']['rowindex'];new=r['versions']['budget93'];v16=r['versions']['V16'];analysis=r['submission_analysis']
assert r['new_red_rounds']==1 and r['baseline_reruns']==r['other_maps']==0
assert analysis['stale_confirmation_bypassed'] and analysis['selected_budget_event']['reason']=='step_budget'
assert new['submission_step']==5039 and new['submission_drone']==0
assert r['comparison']['rowindex']['same_selected_map'] and all(c['same_all_accepted_placements'] for c in r['comparison'].values())
analysis.update(actual_final_inventory={str(d['drone']):d['inventory'] for d in s['drone_details']},
    simultaneous_submission_calls=len(new['all_submissions']),all_calls_same_step=len({v['step'] for v in new['all_submissions']})==1,
    unique_submission_coordination_succeeded=False,selected_cache_version=new['cached_metadata']['0']['version'])
assert len(new['all_submissions'])==5 and set(analysis['actual_final_inventory'].values())=={0}
save(OUT/'RESULTS.json',r)
text=(OUT/'REPORT.md').read_text(encoding='utf8')
intro=f'''本次预算出口达到提前结束目标：SDK采用0号机第5039步提交，最终墙钟165.660309秒。相比已有按行索引候选，提前318步、实测少用12.967554秒，得分小计增加0.841270；地图图片、地图分、墙覆盖、全部10次实际投放相同。相比已有V16，实测少用12.946779秒，但步数仍多47步，小计仍低0.043881分。V16仍为比赛基线。

旧确认没有被补齐或清零：0号仍记录3号2678步剩1枚、4号1791步剩1枚；team_confirmed=false。普通提交未就绪，独立预算出口从5022步获得资格，在5039步按计划提交。实际场内五机库存均为零，共10枚实际投出，本次未牺牲实投数。

需要保留的风险：五机均在5039步调用提交，预算事件中均没有同窗对手估计。SDK最终采用0号图。本次只证明预算出口解除旧确认阻塞，不能称唯一提交协调或断联情况下最优地图选举已经解决。没有修改代码补救，也没有安排重跑。

'''
text=text.replace('## 三版本结果\n',intro+'## 三版本结果\n',1)
delta=r['comparison']['V16']['score_contribution']
extra=f'''## 得分与墙钟差解释

相对V16：地图项贡献{delta['map']:+.6f}，墙覆盖项{delta['wall']:+.6f}，时间项{delta['time']:+.6f}，合计{new['score_out_of_80']-v16['score_out_of_80']:+.6f}。地图小幅改善尚不足补偿多47步的时间项损失。相对按行索引候选，地图/墙覆盖/图片不变，收益来自少318步，对小计贡献+0.841270。

预算开启前第5021步，本次已经比历史按行索引场次快1.310788秒；两次CPU负载和核心组不同。因此不能把最终实测12.967554秒差全部归因于预算逻辑。历史轨迹在5039步累计166.837953秒，其后到原结束仍有约11.789911秒运行，说明提前停止确实避免了一段尾部运行。

与历史按行索引回放的首次无人机及炸弹记录差异均在5039步（本次结束帧）；全部实际投放事件逐条相同。新候选采用与旧按行索引候选相同的0号4995版缓存，提交图片SHA256均为`{new['map_sha256']}`。

'''
text=text.replace('## 条件与验证边界\n',extra+'## 条件与验证边界\n',1)
(OUT/'REPORT.md').write_text(text,encoding='utf8')
with ZipFile(OUT/'RUN_EVIDENCE.zip','a',ZIP_DEFLATED) as z:z.write(Path(__file__),Path(__file__).name)
save(OUT/'CHECKSUMS_SHA256.json',{p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.iterdir()) if p.name!='CHECKSUMS_SHA256.json'})
print(json.dumps(dict(status='PASS',new_rounds=1,selected_submission=s['selected_submission'],budget_event=analysis['selected_budget_event'],submission_calls=len(new['all_submissions']),vs_rowindex=r['comparison']['rowindex']['budget_minus_reference'],vs_V16=r['comparison']['V16']['budget_minus_reference']),indent=2,ensure_ascii=False))
