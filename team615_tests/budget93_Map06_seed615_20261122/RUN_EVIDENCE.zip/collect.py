"""Download and inspect completed recordings; never run a controller."""
from pathlib import Path, PurePosixPath
from hashlib import sha256
from zipfile import ZipFile, ZIP_DEFLATED
import ast
from datetime import datetime
import json
import math
import statistics
import struct
import subprocess

ROOT=Path(__file__).resolve().parent
HOST='quanliangwen@10.112.162.60'
REMOTE='/home/quanliangwen/isolated_test/'+ROOT.name
H=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf8'))
def save(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def download(paths,dest):
    dest.mkdir(parents=True,exist_ok=True)
    subprocess.run(['scp','-q',*[HOST+':'+p for p in paths],str(dest)],check=True)
def npy(data):
    width=2 if data[6]==1 else 4
    size=int.from_bytes(data[8:8+width],'little')
    return ast.literal_eval(data[8+width:8+width+size].decode('latin1')),data[8+width+size:]
def timestamps(p):
    with ZipFile(p) as archive:
        _,b=npy(archive.read('timestamps.npy'))
    return struct.unpack('<'+'d'*(len(b)//8),b)
def distribution(values):
    values=sorted(v for v in values if v is not None)
    return dict(count=len(values),minimum=values[0],mean=statistics.mean(values),median=statistics.median(values),
                p95=values[math.ceil(.95*len(values))-1],maximum=values[-1]) if values else None

download([REMOTE+'/'+n for n in ['STATUS.json','MONITOR_CONFIG.json','HOST.json','ENVIRONMENT.json','queue_resources.jsonl','queue.log','AFFINITY_SELECTION.json','AUTHORIZED_RUN.json','OBSERVER_CHANGE.json']],ROOT/'received')
assert read(ROOT/'received/STATUS.json')['state']=='COMPLETE'
target=ROOT/'Map06/received';remote=REMOTE+'/Map06'
files=['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','placement_events.jsonl','POST_RUN_SOURCE_CHECK.json','EXTRA_ARTIFACTS.json','resources.jsonl','ADMISSION.json','MONITOR_FINISH.json','SDK_PID','dispatch.log','run.log','GROUP_DATASET.json','group_dataset.npz','wall_geometry.npz']
download([remote+'/'+n for n in files],target)
finish=read(target/'FINISH.json')
assert (finish['status'],finish['completed_red_rounds'],finish['blue_rounds'],finish['layout_evaluations'])==('COMPLETE',1,0,0)
assert read(target/'POST_RUN_SOURCE_CHECK.json')['status']=='PASS'
base=PurePosixPath(finish['result_dir']);assert base.is_relative_to(PurePosixPath(remote)/'official_sdk/results_swarm_rescue')
for name,digest in finish['files'].items():
    rel=PurePosixPath(name);assert not rel.is_absolute() and '..' not in rel.parts
    download([str(base/rel)],target/'official'/rel.parent);assert H(target/'official'/name)==digest
for name,digest in read(target/'EXTRA_ARTIFACTS.json').items():assert H(target/name)==digest
start=read(target/'START.json');assert start['solutions_sha256']==read(ROOT/'Map06/DECLARED_SOURCE.json')==read(target/'SOURCE_MATCH.json')['candidate']
assert (start['map_name'],start['seed'],start['timestep_limit'],start['walltime_limit'])==('Map06',615,5400,180)
s=read(target/'OFFICIAL_SCORE.json');assert s['submitted_map']
assert math.isclose(s['partial'],.5*s['map_score']+.2*s['coverage']+.1*s['time_score'],abs_tol=1e-9)
assert H(target/'placement_events.jsonl')==s['placement_events_sha256'] and H(target/'wall_geometry.npz')==s['wall_geometry_sha256']
rec=next((target/'official/recordings').glob('*.npz'));ts=timestamps(rec);assert len(ts)==s['steps']-1
rows=[json.loads(l) for l in (target/'resources.jsonl').read_text().splitlines()]
admission=read(target/'ADMISSION.json')['admission'];previous=admission['monotonic'];cpubusy=[]
for row in rows:
    if row['monotonic']-previous>=.5:cpubusy.append(row['cpu_busy_percent'])
    previous=row['monotonic']
other=[]
for a,b in zip(rows,rows[1:]):
    if a['test_process'] and b['test_process']:
        dt=b['monotonic']-a['monotonic'];delta=sum(b['test_process'][k]-a['test_process'][k] for k in ['user_seconds','system_seconds'])
        other.append(max(0.,sum(b['selected_cpu_busy_percent'].values())/100-delta/dt))
resources=dict(cpu_busy_percent=distribution(cpubusy),load1=distribution([r['load1'] for r in rows]),estimated_other_work_cpu_equivalents_in_pool=distribution(other),logical_cpus=read(ROOT/'received/AFFINITY_SELECTION.json')['logical_cpus'],samples=len(rows))
chosen=s['selected_submission'];details=s['drone_details']
new=dict(score_out_of_80=s['partial'],map_score=s['map_score'],wall_score=s['coverage'],time_score=s['time_score'],exploration_percent=s['trajectory'],submission_drone=chosen['drone'],submission_step=chosen['step'],submission_walltime_seconds=chosen['walltime_seconds'],final_walltime_seconds=s['elapsed_walltime'],placed=s['placed'],all_submissions=s['submissions'],map_sha256=s['selected_image_sha256'],total_health_lost=sum(25-d['health'] for d in details),missed_wall_pixels=s['map_breakdown']['wall_pixels']-s['map_breakdown']['wall_hits'],charged_misdraw_pixels=s['map_breakdown']['charged_pixels'],resources=resources,
    budget_events={str(d['drone']):d['budget_submission'] for d in details},budget_audits={str(d['drone']):d['budget_submission_audit'] for d in details},walltime_submission={str(d['drone']):d['walltime_submission'] for d in details},final_inventory_records={str(d['drone']):d['final_inventory_records'] for d in details},ordinary_first_ready={str(d['drone']):d['original_first_ready'] for d in details},cached_metadata={str(d['drone']):d['group_best_metadata'] for d in details})
HIST=ROOT.parent/'team615_v16_rowindex_maps06_08_pair_20261122'
history=read(HIST/'delivery/RESULTS.json')['results']['Map06']
versions={'V16':history['versions']['V16'],'rowindex':history['versions']['current'],'budget93':new}
comparisons={}
with ZipFile(rec) as z:dh,db=npy(z.read('drone_states.npy'));bh,bb=npy(z.read('bomb_states.npy'))
placements=[e for e in (json.loads(l) for l in (target/'placement_events.jsonl').read_text().splitlines()) if e['event']=='sdk_placement' and e['accepted']]
for label,folder in [('V16','V16'),('rowindex','current')]:
    old=HIST/'Map06'/folder/'received';oldstart=read(old/'START.json')
    assert all(start[k]==oldstart[k] for k in start if k!='solutions_sha256')
    assert H(ROOT/'Map06/place_map09.yml')==H(HIST/'Map06'/folder/'place_map09.yml')
    oldrec=next((old/'official/recordings').glob('*.npz'));ot=timestamps(oldrec)
    with ZipFile(oldrec) as z:oh,ob=npy(z.read('drone_states.npy'));obh,obb=npy(z.read('bomb_states.npy'))
    assert len(db)//dh['shape'][0]==len(ob)//oh['shape'][0]==85
    count=min(dh['shape'][0],oh['shape'][0]);first=next((i for i in range(count) if db[i*85:(i+1)*85]!=ob[i*85:(i+1)*85]),None)
    bs=len(bb)//bh['shape'][0];obs=len(obb)//obh['shape'][0];padding=max(bs,obs)
    firstbomb=next((i for i in range(min(bh['shape'][0],obh['shape'][0])) if bb[i*bs:(i+1)*bs].ljust(padding,b'\0')!=obb[i*obs:(i+1)*obs].ljust(padding,b'\0')),None)
    op=[e for e in (json.loads(l) for l in (old/'placement_events.jsonl').read_text().splitlines()) if e['event']=='sdk_placement' and e['accepted']]
    fields=['score_out_of_80','map_score','wall_score','time_score','placed','submission_step','final_walltime_seconds','total_health_lost','exploration_percent','missed_wall_pixels','charged_misdraw_pixels']
    common_end=min(new['submission_step'],versions[label]['submission_step'])
    cuts=sorted(set(v for v in [1001,2001,3001,4001,4991,5021,5022,5030,common_end] if v<=common_end))
    comparisons[label]=dict(budget_minus_reference={f:new[f]-versions[label][f] for f in fields},same_all_accepted_placements=placements==op,first_different_drone_step=None if first is None else first+2,first_different_bomb_step=None if firstbomb is None else firstbomb+2,same_selected_map=new['map_sha256']==versions[label]['map_sha256'],same_step_times={str(v):dict(reference_seconds=ot[v-2],budget_seconds=ts[v-2],observed_saved_seconds=ot[v-2]-ts[v-2]) for v in cuts},score_contribution=dict(map=.5*(new['map_score']-versions[label]['map_score']),wall=.2*(new['wall_score']-versions[label]['wall_score']),time=.1*(new['time_score']-versions[label]['time_score'])))
    with ZipFile(old/'wall_geometry.npz') as a,ZipFile(target/'wall_geometry.npz') as b:assert a.namelist()==b.namelist() and all(a.read(n)==b.read(n) for n in a.namelist())
event=new['budget_events'][str(new['submission_drone'])]
summary=dict(budget_exit_used=event is not None,selected_budget_event=event,stale_confirmation_bypassed=bool(event and event['reason']=='step_budget' and event['team_confirmed'] is False and event['unconfirmed_peers']),old_confirmation_still_blocks_ordinary={str(d['drone']):d['original_first_ready'] is None for d in details},drone_zero_budget_audit=new['budget_audits']['0'])
delivery=ROOT/'delivery';delivery.mkdir(exist_ok=True)
save(delivery/'RESULTS.json',dict(status='COMPLETE',map='Map06',seed=615,new_red_rounds=1,baseline_reruns=0,other_maps=0,versions=versions,comparison=comparisons,submission_analysis=summary,comparison_is_historical_not_same_load=True))
report=['# 93%预算交图候选：Map06种子615单次测试\n','本轮只新增当前候选的一场Map06红队比赛；未重跑V16或按行索引基线，未跑其他地图。算法归档与六类反例通过版本逐字节一致，仍保留V16为比赛提交基线。\n','## 三版本结果\n','| 指标 | 已有V16 | 已有按行索引 | 本轮93%预算出口 |','|---|---:|---:|---:|']
metrics=[('交图者','submission_drone'),('交图步数','submission_step'),('得分小计/80','score_out_of_80'),('地图分','map_score'),('墙覆盖分','wall_score'),('时间分','time_score'),('实投数','placed'),('最终墙钟/秒','final_walltime_seconds'),('交图指令墙钟/秒','submission_walltime_seconds'),('探索率/%','exploration_percent'),('掉血','total_health_lost'),('漏墙像素','missed_wall_pixels'),('计入扣分误画像素','charged_misdraw_pixels')]
fmt=lambda v:str(v) if type(v)is int else f'{v:.6f}'
for title,key in metrics:report.append('| '+title+' | '+' | '.join(fmt(v[key]) for v in versions.values())+' |')
report.extend(['','得分小计按原SDK权重0.5×地图分＋0.2×墙覆盖分＋0.1×时间分，未将未输出的炸弹项冒称为完整总分。墙覆盖使用官方coverage字段。','',
    '## 提交原因\n','实际提交事件：`'+json.dumps(summary,ensure_ascii=False)+'`。','',
    '各机预算出口事件：`'+json.dumps(new['budget_events'],ensure_ascii=False)+'`。','',
    '各机预算门槛审计：`'+json.dumps(new['budget_audits'],ensure_ascii=False)+'`。','',
    '各机最终库存认知：`'+json.dumps(new['final_inventory_records'],ensure_ascii=False)+'`。','',
    '全部提交调用：`'+json.dumps(new['all_submissions'],ensure_ascii=False)+'`。','',
    '硬兜底事件：`'+json.dumps(new['walltime_submission'],ensure_ascii=False)+'`。','',
    '## 与历史结果的差值和证据\n'])
for label,c in comparisons.items():
    report.extend([label+'：`'+json.dumps({k:v for k,v in c.items() if k!='same_step_times'},ensure_ascii=False)+'`。','',
        '同一步数累计耗时：`'+json.dumps(c['same_step_times'],ensure_ascii=False)+'`。',''])
report.extend(['## 条件与验证边界\n','三版相同种子、地图/特殊区、出生点、5400步/180秒、5机/10弹、评分配置、SDK封存版本均核对一致。新观察器仅在评分结束后导出预算事件和审计，运行阶段AST与历史观察器一致。候选源文件运行前后SHA通过；正式V16和原按行索引归档未改。',
    '每版的CPU占用均值、load1均值、CPU池其他任务估计等效核均值：`'+json.dumps({label:{k:v['resources'][k]['mean'] for k in ['cpu_busy_percent','load1','estimated_other_work_cpu_equivalents_in_pool']} for label,v in versions.items()},ensure_ascii=False)+'`。',
    '本轮为单次新增对照历史结果；CPU核心组与背景负载不同。墙钟差为实测，不能全部归因于算法或预算出口。预算提交会结束比赛，因此提交后的轨迹不能再与未结束的历史长轨迹当作相同工作量比较。',
    '候选SHA256：`'+read(ROOT/'Map06/PATCH_BINDING.json')['candidate_zip_sha256']+'`。完整预算出口来源及56项反例证据见先前提交53a6e679e8f4d4faacf67ef8ca915f9ebfa9e473。'])
(delivery/'REPORT.md').write_text('\n'.join(report)+'\n',encoding='utf8')
with ZipFile(delivery/'RUN_EVIDENCE.zip','w',ZIP_DEFLATED) as z:
    for folder in [ROOT/'received',target]:
        for p in folder.rglob('*'):
            if p.is_file():z.write(p,p.relative_to(ROOT).as_posix())
    for n in ['provision.py','monitor.py','collect.py','collect_body.txt','environment.py','AUTHORIZED_RUN.json','OBSERVER_CHANGE.json']:z.write(ROOT/n,n)
    for n in ['stage_run.py','DECLARED_SOURCE.json','PATCH_BINDING.json','OFFLINE_CHECK.json','BUILD.json','run_monitored.sh','place_map09.yml','matched_spawns.json','EXPECTED_ZONES.json']:z.write(ROOT/'Map06'/n,'Map06/'+n)
    for folder in ['V16','current']:
        for n in ['START.json','OFFICIAL_SCORE.json','placement_events.jsonl','POST_RUN_SOURCE_CHECK.json']:
            z.write(HIST/'Map06'/folder/'received'/n,'historical/'+folder+'/'+n)
    z.write(HIST/'delivery/RESULTS.json','historical/PAIRED_RESULTS.json')
save(delivery/'CHECKSUMS_SHA256.json',{p.name:H(p) for p in sorted(delivery.iterdir()) if p.name!='CHECKSUMS_SHA256.json'})
print(json.dumps(dict(versions={k:{m:v[m] for m in ['submission_drone','submission_step','score_out_of_80','map_score','wall_score','placed','final_walltime_seconds']} for k,v in versions.items()},submission_analysis=summary),indent=2,ensure_ascii=False))
