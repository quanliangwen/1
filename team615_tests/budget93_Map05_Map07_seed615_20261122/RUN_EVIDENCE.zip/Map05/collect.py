"""Download and inspect completed recordings; never run a controller."""
from pathlib import Path, PurePosixPath
from hashlib import sha256
from zipfile import ZipFile, ZIP_DEFLATED
import ast
from datetime import datetime
import json
import math
import statistics
import struct
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
MAP=sys.argv[1]
assert MAP in ['Map05','Map07']
HOST='quanliangwen@10.112.162.60'
REMOTE='/home/quanliangwen/isolated_test/'+ROOT.name
H=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf8'))
def save(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def download(paths,dest):
    dest.mkdir(parents=True,exist_ok=True)
    subprocess.run(['scp','-q',*[HOST+':'+p for p in paths],str(dest)],check=True)
def npy(data):
    width=2 if data[6]==1 else 4
    size=int.from_bytes(data[8:8+width],'little')
    return ast.literal_eval(data[8+width:8+width+size].decode('latin1')),data[8+width+size:]
def timestamps(p):
    with ZipFile(p) as archive:
        _,b=npy(archive.read('timestamps.npy'))
    return struct.unpack('<'+'d'*(len(b)//8),b)
def distribution(values):
    values=sorted(v for v in values if v is not None)
    return dict(count=len(values),minimum=values[0],mean=statistics.mean(values),median=statistics.median(values),
                p95=values[math.ceil(.95*len(values))-1],maximum=values[-1]) if values else None


download([REMOTE+'/'+n for n in ['STATUS.json','HOST.json','ENVIRONMENT.json','queue_resources.jsonl','queue.log','AUTHORIZED_RUN.json','OBSERVER_BINDING.json']],ROOT/'received')
remote=REMOTE+'/'+MAP;target=ROOT/MAP/'received'
files=['STATUS.json','START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','placement_events.jsonl','POST_RUN_SOURCE_CHECK.json','EXTRA_ARTIFACTS.json','resources.jsonl','ADMISSION.json','MONITOR_FINISH.json','MONITOR_CONFIG.json','AFFINITY_SELECTION.json','SDK_PID','TIMING_ANCHORS.jsonl','dispatch.log','run.log','GROUP_DATASET.json','group_dataset.npz','wall_geometry.npz']
download([remote+'/'+n for n in files],target)
assert read(target/'STATUS.json')['state']=='COMPLETE'
finish=read(target/'FINISH.json')
assert (finish['status'],finish['completed_red_rounds'],finish['blue_rounds'],finish['layout_evaluations'])==('COMPLETE',1,0,0)
assert read(target/'POST_RUN_SOURCE_CHECK.json')['status']=='PASS'
base=PurePosixPath(finish['result_dir']);assert base.is_relative_to(PurePosixPath(remote)/'official_sdk/results_swarm_rescue')
for name,digest in finish['files'].items():
    rel=PurePosixPath(name);assert not rel.is_absolute() and '..' not in rel.parts
    download([str(base/rel)],target/'official'/rel.parent);assert H(target/'official'/name)==digest
for n,digest in read(target/'EXTRA_ARTIFACTS.json').items():assert H(target/n)==digest
start=read(target/'START.json');limit,wall_limit=read(ROOT/MAP/'EXPECTED_LIMITS.json')[MAP]
assert (start['map_name'],start['seed'],start['timestep_limit'],start['walltime_limit'],start['drones'],start['bombs_per_drone'])==(MAP,615,limit,wall_limit,5,2)
assert start['solutions_sha256']==read(ROOT/MAP/'DECLARED_SOURCE.json')==read(target/'SOURCE_MATCH.json')['candidate']
assert read(target/'SOURCE_MATCH.json')['candidate_zip_sha256']=='0ed2e45090a6a8104c0a3bf92d8ac79382a7891eccb978ffaba8a72a2b06a449'
s=read(target/'OFFICIAL_SCORE.json')
assert s['walltime_limit']==wall_limit
assert math.isclose(s['partial'],.5*s['map_score']+.2*s['coverage']+.1*s['time_score'],abs_tol=1e-9)
assert H(target/'placement_events.jsonl')==s['placement_events_sha256'] and H(target/'wall_geometry.npz')==s['wall_geometry_sha256']
remote_hash=subprocess.run(['ssh',HOST,'sha256sum '+remote+'/TIMING_ANCHORS.jsonl'],capture_output=True,text=True,check=True).stdout.split()[0]
assert H(target/'TIMING_ANCHORS.jsonl')==remote_hash
rows=[json.loads(l) for l in (target/'resources.jsonl').read_text().splitlines()]
admission=read(target/'ADMISSION.json')['admission'];previous=admission['monotonic'];busy=[]
for row in rows:
    if row['monotonic']-previous>=.5:busy.append(row['cpu_busy_percent'])
    previous=row['monotonic']
other=[]
for a,b in zip(rows,rows[1:]):
    if a['test_process'] and b['test_process']:
        dt=b['monotonic']-a['monotonic'];own=sum(b['test_process'][k]-a['test_process'][k] for k in ['user_seconds','system_seconds'])/dt
        other.append(max(0.,sum(b['selected_cpu_busy_percent'].values())/100-own))
resources=dict(cpu_busy_percent=distribution(busy),load1=distribution([r['load1'] for r in rows]),estimated_other_work_cpu_equivalents_in_pool=distribution(other),logical_cpus=read(target/'AFFINITY_SELECTION.json')['logical_cpus'],samples=len(rows))
assert len(resources['logical_cpus'])==8
chosen=s.get('selected_submission');details=s['drone_details'];drone=None if not chosen else chosen['drone']
calls=s['submissions'];selected_detail=next((d for d in details if d['drone']==drone),None)
budget=None if selected_detail is None else selected_detail['budget_submission']
hard=None if selected_detail is None else selected_detail['walltime_submission']
path='no_submission' if not chosen else 'budget' if budget else 'hard_'+str(hard.get('fallback','election')) if hard else 'ordinary'
mb=s.get('map_breakdown') or {}
result=dict(score_out_of_80=s['partial'],map_score=s['map_score'],wall_score=s['coverage'],time_score=s['time_score'],exploration_percent=s['trajectory'],submission_drone=drone,submission_step=None if chosen is None else chosen['step'],submission_walltime_seconds=None if not chosen else chosen['walltime_seconds'],final_walltime_seconds=s['elapsed_walltime'],steps=s['steps'],submitted_map=s['submitted_map'],placed=s['placed'],expected=s['expected'],all_submissions=calls,submission_calls=len(calls),simultaneous_submission=len(calls)>1 and len({c['step'] for c in calls})==1,ending_path=path,
    map_sha256=s['selected_image_sha256'],total_health_lost=sum(25-d['health'] for d in details),missed_wall_pixels=None if not mb else mb['wall_pixels']-mb['wall_hits'],charged_misdraw_pixels=mb.get('charged_pixels'),resources=resources,
    budget_window=[(limit*93+99)//100,(limit*93+99)//100+29],budget_window_entered=any(d['budget_submission_audit'] for d in details),budget_event=budget,budget_events={str(d['drone']):d['budget_submission'] for d in details},budget_audits={str(d['drone']):d['budget_submission_audit'] for d in details},hard_events={str(d['drone']):d['walltime_submission'] for d in details},last_confirmations={str(d['drone']):d['last_confirmation'] for d in details},actual_final_inventory={str(d['drone']):d['inventory'] for d in details},ordinary_first_ready={str(d['drone']):d['original_first_ready'] for d in details},selected_cache=None if selected_detail is None else selected_detail['group_best_metadata'])
rec=next((target/'official/recordings').glob('*.npz'));ts=timestamps(rec);assert len(ts)==s['steps']-1
points=sorted(set(v for v in [1001,2001,3001,4001,5001,6001,6696,s['steps']] if 2<=v<=s['steps']))
result['cumulative_time_at_steps']={str(v):ts[v-2] for v in points}
out=ROOT/MAP/'delivery';out.mkdir(exist_ok=True)
save(out/'RESULTS.json',dict(status='COMPLETE',map=MAP,seed=615,new_red_rounds=1,algorithm_changes=False,V16_remains_competition_baseline=True,native_limits=dict(steps=limit,wall_seconds=wall_limit),result=result))
report=[f'# 93%预算候选：{MAP}种子615单次测试\n','本图只运行当前冻结候选一场红队比赛，未重跑其他版本。算法、导航、拟合、投放及依赖未修改，V16继续作为比赛提交基线。\n',f'SDK原生限制：{limit}步／{wall_limit}秒；5机，每机2枚。新预算窗口：{result["budget_window"]}。配置启用NO_COM/NO_GPS枚举，但实际地图包含的区域数按SDK源码和开局校验为0/0。\n','| 指标 | 本次结果 |','|---|---:|']
fmt=lambda v:'无' if v is None else str(v) if type(v) in (int,bool) else f'{v:.6f}' if type(v)is float else str(v)
for name,key in [('SDK采用交图者','submission_drone'),('交图步数','submission_step'),('得分小计/80','score_out_of_80'),('地图分','map_score'),('墙覆盖分','wall_score'),('时间分','time_score'),('探索率/%','exploration_percent'),('实投数','placed'),('掉血','total_health_lost'),('最终墙钟/秒','final_walltime_seconds'),('提交调用数','submission_calls'),('同帧多机提交','simultaneous_submission')]:report.append('| '+name+' | '+fmt(result[key])+' |')
report.extend(['','得分小计按官方SDK的0.5×地图分＋0.2×墙覆盖分＋0.1×时间分核对，不将未输出的炸弹项冒称为完整总分。','',
    '结束路径：`'+path+'`；预算是否进入：`'+str(result['budget_window_entered'])+'`。',
    '预算事件：`'+json.dumps(result['budget_events'],ensure_ascii=False)+'`。',
    '预算审计：`'+json.dumps(result['budget_audits'],ensure_ascii=False)+'`。',
    '硬兜底事件：`'+json.dumps(result['hard_events'],ensure_ascii=False)+'`。',
    '全部提交调用：`'+json.dumps(calls,ensure_ascii=False)+'`。',
    '各机末弹确认步数：`'+json.dumps(result['last_confirmations'],ensure_ascii=False)+'`；最终真实库存：`'+json.dumps(result['actual_final_inventory'])+'`。',
    '同一步数累计耗时：`'+json.dumps(result['cumulative_time_at_steps'])+'`。','',
    '每场初选8个不同空闲物理核，每核仅分配一个逻辑CPU；整机负载不作入场门槛，使用共享评测锁。CPU亲和性只限定本任务，不保证其他任务不进入或占用SMT兄弟线程。',
    '监控统计：`'+json.dumps(resources,ensure_ascii=False)+'`。',
    'SDK封存版本6557940dc18549ffc7a945db887da5b05b7ed2f1，出生点和原生时限校验通过，全部56项算法源码运行前后SHA验证通过。候选归档SHA256：`0ed2e45090a6a8104c0a3bf92d8ac79382a7891eccb978ffaba8a72a2b06a449`。本次没有官网提交或正式新版本发布。'])
(out/'REPORT.md').write_text('\n'.join(report)+'\n',encoding='utf8')
with ZipFile(out/'RUN_EVIDENCE.zip','w',ZIP_DEFLATED) as z:
    for folder in [ROOT/'received',target]:
        for p in folder.rglob('*'):
            if p.is_file():z.write(p,p.relative_to(ROOT).as_posix())
    for n in ['provision.py','monitor.py','monitor_body.txt','collect.py','collect_prefix.txt','collect_tail.txt','environment.py','AUTHORIZED_RUN.json','OBSERVER_BINDING.json']:z.write(ROOT/n,n)
    for n in ['stage_run.py','DECLARED_SOURCE.json','PATCH_BINDING.json','OFFLINE_CHECK.json','run_monitored.sh','place_map09.yml','matched_spawns.json','EXPECTED_ZONES.json','EXPECTED_LIMITS.json']:z.write(ROOT/MAP/n,MAP+'/'+n)
print(json.dumps(dict(map=MAP,result=result),indent=2,ensure_ascii=False))
