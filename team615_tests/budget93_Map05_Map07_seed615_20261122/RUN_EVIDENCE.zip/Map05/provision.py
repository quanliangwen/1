from pathlib import Path
from hashlib import sha256
import ast,json,math,random,shutil,subprocess
ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'team615_rowindex_budget93_20261122'
PREV=ROOT.parent/'team615_rowindex_budget93_map09_lowload_pair_20261122'
HOST='quanliangwen@10.112.162.60';REMOTE='/home/quanliangwen/isolated_test/'+ROOT.name
H=lambda p:sha256(p.read_bytes()).hexdigest()
save=lambda p,d:p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
assert H(SRC/'candidate_snapshot.zip')=='0ed2e45090a6a8104c0a3bf92d8ac79382a7891eccb978ffaba8a72a2b06a449'
limits={'Map05':[7200,240],'Map07':[5400,180]}
expected={};angles=random.Random(615);headings=[angles.uniform(-math.pi,math.pi) for _ in range(5)]
for name,center in [('Map05',(65,-15)),('Map07',(-520,-411))]:
    expected[name]=[[[center[0]-40+(i%3)*40.,center[1]-40+(i//3)*40.],headings[i]] for i in range(5)]
ref=json.loads((ROOT.parent/'team615_messenger_rolling_map07_20261121/matched_spawns.json').read_text())
assert expected['Map07']==ref['Map07']
observer=(PREV/'budget93/stage_run.py').read_text(encoding='utf8')
observer=observer.replace('(\"Map06\", \"Map08\", \"Map09\")','("Map05", "Map07")')
needle='assert (self.max_timestep_limit,self.max_walltime_limit,self.number_drones) == (5400,180,5)'
assert observer.count(needle)==1
observer=observer.replace(needle,"assert (self.max_timestep_limit,self.max_walltime_limit,self.number_drones) == (7200,240,5) if map_name=='Map05' else (self.max_timestep_limit,self.max_walltime_limit,self.number_drones) == (5400,180,5)")
observer=observer.replace('timestep_limit=5400,walltime_limit=180,','timestep_limit=self.max_timestep_limit,walltime_limit=self.max_walltime_limit,')
observer=observer.replace('5030,5051,5251}', '5030,5051,5251,5501,6001,6501,6695,6696,6710,6725,7001}')
assert 'TIMING_STEPS' in observer and '6696' in observer
for name in limits:
    stage=ROOT/name;stage.mkdir()
    for n in ['candidate_snapshot.zip','baseline_snapshot.zip','DECLARED_SOURCE.json','PATCH_BINDING.json','OFFLINE_CHECK.json']:shutil.copyfile(PREV/'budget93'/n,stage/n)
    assert H(stage/'candidate_snapshot.zip')==H(SRC/'candidate_snapshot.zip')
    save(stage/'matched_spawns.json',expected)
    save(stage/'EXPECTED_ZONES.json',{m:{'NoGpsZone':0,'NoComZone':0} for m in limits})
    save(stage/'EXPECTED_LIMITS.json',limits)
    (stage/'stage_run.py').write_text(observer,encoding='utf8',newline='\n')
    config=(PREV/'budget93/place_map09.yml').read_text().replace('map_name: Map09','map_name: '+name)
    (stage/'place_map09.yml').write_text(config,encoding='utf8',newline='\n')
    (stage/'run_monitored.sh').write_text((PREV/'budget93/run_monitored.sh').read_text().replace('Map09',name),encoding='utf8',newline='\n')
save(ROOT/'OBSERVER_BINDING.json',dict(observer_sha256=H(ROOT/'Map05/stage_run.py'),same_observer_both_maps=True,source_observer_sha256=H(PREV/'budget93/stage_run.py'),changes='map allowlist, native map-specific limit assertions/START fields, sparse Map05 timing anchors; algorithm archive unchanged',spawn_reference='official map constructor grid formula and random.Random(615) first5 angles; Map07 matched existing official seed615 START',expected_limits=limits,expected_zone_counts={m:{'NoGpsZone':0,'NoComZone':0} for m in limits}))
helper=(PREV/'monitor8cpu.py').read_text().split("labels=['rowindex','budget93']")[0]
(ROOT/'monitor.py').write_text(helper+(ROOT/'monitor_body.txt').read_text(),encoding='utf8',newline='\n')
shutil.copyfile(PREV/'environment.py',ROOT/'environment.py')
save(ROOT/'AUTHORIZED_RUN.json',dict(maps=['Map05','Map07'],seed=615,rounds_per_map=1,total_red_rounds=2,other_maps=False,baseline_reruns=0,algorithm_changes=False,V16_remains_competition_baseline=True,assigned_logical_cpus=8,distinct_physical_cores=8,global_load_is_admission_gate=False,candidate_zip_sha256=H(SRC/'candidate_snapshot.zip'),native_limits=limits,retries=False))
for p in [*ROOT.glob('*.py'),*ROOT.glob('*/stage_run.py')]:ast.parse(p.read_text())
subprocess.run(['ssh',HOST,'mkdir '+REMOTE],check=True)
subprocess.run(['scp','-q',*[str(ROOT/n) for n in ['monitor.py','environment.py','AUTHORIZED_RUN.json','OBSERVER_BINDING.json']],HOST+':'+REMOTE+'/'],check=True)
for name in limits:
    subprocess.run(['ssh',HOST,'mkdir '+REMOTE+'/'+name],check=True)
    subprocess.run(['scp','-q',*[str(p) for p in (ROOT/name).iterdir()],HOST+':'+REMOTE+'/'+name+'/'],check=True)
subprocess.run(['ssh',HOST,'/home/junhao/quan/parallel_test_solver/match/.venv/bin/python '+REMOTE+'/environment.py'],check=True)
print(subprocess.run(['ssh',HOST,'nohup python3 '+REMOTE+'/monitor.py > '+REMOTE+'/queue.log 2>&1 < /dev/null & echo MAP05_MAP07_ONCE_EACH_QUEUED'],capture_output=True,text=True,check=True).stdout)
