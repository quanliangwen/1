from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json
ROOT=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf8'))
save=lambda p,d:p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
results={m:read(ROOT/m/'delivery/RESULTS.json') for m in ['Map05','Map07']}
for m,r in results.items():
    assert r['map']==m and r['seed']==615 and r['new_red_rounds']==1
    assert read(ROOT/m/'received/POST_RUN_SOURCE_CHECK.json')['status']=='PASS'
    assert read(ROOT/m/'received/SOURCE_MATCH.json')['candidate_zip_sha256']=='0ed2e45090a6a8104c0a3bf92d8ac79382a7891eccb978ffaba8a72a2b06a449'
raw7=read(ROOT/'Map07/received/OFFICIAL_SCORE.json')
d4=next(d for d in raw7['drone_details'] if d['drone']==4)
selected=results['Map07']['result']['budget_event']
assert results['Map07']['result']['placed']==9 and d4['inventory']==1 and d4['health']==25
results['Map07']['observed_risk']=dict(budget_ended_with_unplaced_bomb=True,drone_still_carrying=4,actual_remaining_inventory=1,health=25,submitter=2,submitter_peer4_record=selected['inventory_records']['4'],drone_zero_peer4_record=raw7['drone_details'][0]['final_inventory_records']['4'],submitter_treated_peer4_as_unknown=4 in selected['unconfirmed_peers'],drone_zero_vetoed_by_recent_stock=True,drone_four_closeout_audit=d4['closeout_departure_audit'],submission_walltime=results['Map07']['result']['submission_walltime_seconds'],original_25_second_closeout_time_gate=155.0,counterfactual_later_success_not_tested=True)
out=ROOT/'delivery';out.mkdir(exist_ok=True)
save(out/'RESULTS.json',dict(status='COMPLETE',maps=['Map05','Map07'],seed=615,new_red_rounds=2,other_maps=0,baseline_reruns=0,algorithm_changes=False,V16_remains_competition_baseline=True,results=results))
report=['# 当前93%预算交图候选：Map05、Map07，种子615各一次\n',
'本轮仅运行当前冻结候选Map05、Map07各一场红队比赛，共两场。未改算法、依赖、导航、拟合或投放规则；没有额外地图、蓝队或其他版本重跑，V16继续作为比赛提交基线。每场分配8个逻辑CPU，来自8个不同的初选空闲物理核，保留1.5秒墙钟预留和双时限兜底。\n',
'原生地图时限：Map05为7200步/240秒，Map07为5400步/180秒，保持官方SDK设定；对应93%预算窗口为6696—6725、5022—5051。两图实际均无NoGps/NoCom区域，配置枚举及实际区域数开局核验通过。\n',
'本轮关键发现：Map05预算出口交图且实投10/10；Map07预算出口在4号仍存活、健康25并携带1枚时结束了整场，只投9/10。当前候选允许把过旧正库存作为确认缺失、在预算到期结束等待的风险已在Map07实测触发。本次不修改或重跑，V16继续为比赛提交基线。\n',
'| 指标 | Map05 | Map07 |','|---|---:|---:|']
fmt=lambda v:'无' if v is None else str(v) if type(v) in (int,bool) else f'{v:.6f}' if type(v)is float else str(v)
metrics=[('交图者','submission_drone'),('交图步数','submission_step'),('得分小计/80','score_out_of_80'),('地图分','map_score'),('墙覆盖分','wall_score'),('时间分','time_score'),('探索率/%','exploration_percent'),('实投数','placed'),('掉血','total_health_lost'),('最终墙钟/秒','final_walltime_seconds'),('提交调用数','submission_calls'),('同帧多机提交','simultaneous_submission'),('结束路径','ending_path')]
for title,key in metrics:report.append('| '+title+' | '+' | '.join(fmt(v['result'][key]) for v in results.values())+' |')
report.extend(['','得分小计为官方SDK红队可核验的0.5×地图分＋0.2×墙覆盖分＋0.1×时间分，满分80；不冒称完整总分。未进行其他版本对照，不能据这两场声称优于V16。\n'])
report.extend(['## Map07为何只投出9枚\n',
'2号机在5036步从预算出口提交，记录中的4号库存仍是1915步剩1枚，按规则列为未知，因此没有阻止2号交图。与此同时，0号持有4号5034步剩1枚的近期记录，其预算出口被fresh_peer_stock正确拦截；4号自身也因local_stock_or_pending被拦截。这两处局部保护没有传播成全队终局否决，2号仍能结束整场。',
'4号结束时健康25、真实库存1，并非阵亡造成统计缺失。提交调用发生在154.924481秒，距180秒上限尚有约25.0755秒，原剩余25秒收尾的时间门槛尚未到；4号收尾审计为空。最终墙钟155.025251秒是本帧结束记录，不代表交图调用前已经进入25秒收尾。',
'可以确认预算出口截断了仍携弹无人机的后续运行机会；本次未继续或另跑仿真，不能断言如果不提交，最后一枚就一定能投出。风险证据：`'+json.dumps(results['Map07']['observed_risk'],ensure_ascii=False)+'`。\n'])
for m,r in results.items():
    text=(ROOT/m/'delivery/REPORT.md').read_text(encoding='utf8')
    report.append(text.replace('# 93%预算候选：'+m+'种子615单次测试','## '+m+'详细记录',1))
report.extend(['## 交付与验证\n','完整原始比赛产物、提交调用、投放事件、库存确认、预算门槛、时间锚点、CPU及进程监控均保留，逐文件SHA256核验通过。算法源码归档未改，源文件运行前后校验通过。候选SHA256为0ed2e45090a6a8104c0a3bf92d8ac79382a7891eccb978ffaba8a72a2b06a449。',
'每图单次、种子615；测试结果仅代表本次资源和负载条件。服务器整体仍有背景任务，初始空闲CPU亲和性不保证独占，不把整机低负载或官网硬件复刻作为本轮结论。无官网上传或新正式比赛提交版本发布，V16基线保持。'])
(out/'REPORT.md').write_text('\n'.join(report)+'\n',encoding='utf8')
with ZipFile(out/'RUN_EVIDENCE.zip','w',ZIP_DEFLATED) as z:
    for m in results:
        with ZipFile(ROOT/m/'delivery/RUN_EVIDENCE.zip') as part:
            for n in part.namelist():z.writestr(m+'/'+n,part.read(n))
    z.write(Path(__file__),Path(__file__).name)
save(out/'CHECKSUMS_SHA256.json',{p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.name!='CHECKSUMS_SHA256.json'})
print(json.dumps({m:{key:r['result'][key] for key in ['submission_drone','submission_step','score_out_of_80','map_score','wall_score','exploration_percent','placed','total_health_lost','final_walltime_seconds','ending_path','submission_calls','simultaneous_submission']} for m,r in results.items()},indent=2,ensure_ascii=False))
