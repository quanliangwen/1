"""User-authorized fixed idle physical-core comparison, exactly one match per arm."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl
import hashlib
import json
import os
import platform
import subprocess
import time

ROOT=Path(__file__).resolve().parent
LOCK='/home/junhao/quan/parallel_test_solver/match/solver_study/serial_evaluation.lock'
CORE_COUNT=16
previous=None
def now():return datetime.now(timezone.utc).isoformat()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def status(value):save(ROOT/'STATUS.json',dict(utc=now(),**value))
def counters():
    out={}
    for line in Path('/proc/stat').read_text().splitlines():
        fields=line.split()
        if fields[0]=='cpu' or fields[0].startswith('cpu') and fields[0][3:].isdigit():
            values=list(map(int,fields[1:9]));out[fields[0]]=(sum(values),values[3]+values[4])
    return out
def sample(cpus=()):
    global previous
    values=counters();busy=None;per_core={};stamp=time.monotonic()
    if previous is not None:
        for key in ['cpu']+['cpu'+str(c) for c in cpus]:
            total=values[key][0]-previous[key][0];idle=values[key][1]-previous[key][1]
            percent=100.*(total-idle)/total if total else 0.
            if key=='cpu':busy=percent
            else:per_core[key]=percent
    previous=values
    load=Path('/proc/loadavg').read_text().split()
    pressure={n:(Path('/proc/pressure')/n).read_text().strip() for n in ['cpu','memory','io']}
    return dict(utc=now(),monotonic=stamp,cpu_busy_percent=busy,load1=float(load[0]),load5=float(load[1]),
                load15=float(load[2]),runnable=load[3],pressure=pressure,selected_cpu_busy_percent=per_core)
def process_sample(pid,detailed):
    try:
        p=Path('/proc')/str(pid);raw=(p/'stat').read_text();f=raw[raw.rfind(')')+2:].split()
        result=dict(pid=pid,state=f[0],user_seconds=int(f[11])/os.sysconf('SC_CLK_TCK'),
                    system_seconds=int(f[12])/os.sysconf('SC_CLK_TCK'),threads=int(f[17]),cpu=int(f[36]),
                    rss_bytes=int(f[21])*os.sysconf('SC_PAGE_SIZE'))
        if detailed:
            total=[0,0,0];count=0
            for task in (p/'task').iterdir():
                try:
                    v=list(map(int,(task/'schedstat').read_text().split()));total=[x+y for x,y in zip(total,v)];count+=1
                except (FileNotFoundError,ProcessLookupError):pass
            result['thread_schedstat_sum']=dict(runtime_ns=total[0],runqueue_wait_ns=total[1],timeslices=total[2],read_threads=count)
            result['allowed_cpu_list']=[s for s in (p/'status').read_text().splitlines() if s.startswith('Cpus_allowed_list')]
        return result
    except (FileNotFoundError,ProcessLookupError):return None

stage=ROOT/'Map09'
with (ROOT/'MAP09_DISPATCH_ONCE_CLAIM').open('x'):pass
assert not any((stage/n).exists() for n in ['START.json','RUN_ONCE_CLAIM','SDK_PID'])
assert json.loads((ROOT/'Map08/STATUS.json').read_text())['state']=='COMPLETE'
lock=open(LOCK,'r');fcntl.flock(lock,fcntl.LOCK_EX)
try:
    selection=json.loads((ROOT/'Map08/AFFINITY_SELECTION.json').read_text())
    cpus=selection['logical_cpus'];selection.update(utc=now(),mode='reuse_Map08_fixed_group_with_disclosed_contention',note='Idle physical core selection could not find 16 cores. Reuse prior group; no low-load claim. Historical comparisons have different background load.')
    save(stage/'AFFINITY_SELECTION.json',selection)
    sample(cpus);time.sleep(2);row=sample(cpus)
    save(stage/'MONITOR_CONFIG.json',dict(mode='fixed_group_with_disclosed_contention',whole_server_lowload_claim=False,logical_cpus=cpus,physical_cores=16,sample_seconds=1,retries=False,lock=LOCK,monitor_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),admission_change='MAP09_ADMISSION_CHANGE.json'))
    save(stage/'ADMISSION.json',dict(mode='fixed_group_with_disclosed_contention',admission=row,logical_cpus=cpus,lock_acquired=True,whole_server_lowload_claim=False))
    status(dict(state='RUNNING',map='Map09',seed=615,completed_maps=['Map08'],logical_cpus=cpus,mode='fixed_group_with_disclosed_contention'))
    with (stage/'dispatch.log').open('x') as output,(stage/'resources.jsonl').open('x',buffering=1) as stream:
        proc=subprocess.Popen(['bash',str(stage/'run_monitored.sh'),str(stage)],cwd=stage,stdout=output,stderr=subprocess.STDOUT,preexec_fn=lambda:os.sched_setaffinity(0,set(cpus)))
        index=0;pid=None
        while proc.poll() is None:
            row=sample(cpus)
            if (stage/'SDK_PID').exists():pid=int((stage/'SDK_PID').read_text())
            row['test_process']=process_sample(pid,index%5==0) if pid else None
            stream.write(json.dumps(row)+'\n');index+=1;time.sleep(1)
        code=proc.wait()
    save(stage/'MONITOR_FINISH.json',dict(utc=now(),returncode=code,pid=pid,samples=index,logical_cpus=cpus))
    if code or not (stage/'POST_RUN_SOURCE_CHECK.json').exists():raise RuntimeError('Map09 failed; no rerun')
    save(stage/'STATUS.json',dict(state='COMPLETE',map='Map09',seed=615,new_red_rounds=1))
    status(dict(state='COMPLETE',maps=['Map08','Map09'],completed_maps=['Map08','Map09'],seed=615,new_red_rounds=2))
except BaseException as exc:
    status(dict(state='FAILED',error=repr(exc),completed_maps=['Map08'],no_automatic_rerun=True));raise
finally:fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
