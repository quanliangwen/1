from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json,struct
ROOT=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf8'))
save=lambda p,d:p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
results={m:read(ROOT/m/'delivery/RESULTS.json') for m in ['Map08','Map09']}
def times(folder):
    p=next((folder/'official/recordings').glob('*.npz'))
    with ZipFile(p) as z:raw=z.read('timestamps.npy')
    width=2 if raw[6]==1 else 4;size=int.from_bytes(raw[8:8+width],'little');raw=raw[8+width+size:]
    return struct.unpack('<'+'d'*(len(raw)//8),raw)
trace={}
for label,folder in {'V16':ROOT.parent/'team615_v16_rowindex_map09_pair_20261122/V16/received','rowindex':ROOT.parent/'team615_v16_rowindex_map09_pair_20261122/current/received','budget93':ROOT/'Map09/received'}.items():
    score=read(folder/'OFFICIAL_SCORE.json');d=next(d for d in score['drone_details'] if d['drone']==1)
    entry=next(e for e in d['closeout_departure_audit'] if e[1]=='stall_enter')[0]
    t=times(folder)[entry-3]
    trace[label]=dict(drone_one_closeout_entry_step=entry,cached_walltime_from_previous_frame=t,remaining_walltime=180-t,last_confirmation_step=d['last_confirmation'],selected_drone_zero_cache=score['drone_details'][0]['group_best_metadata'])
results['Map09']['timed_closeout_trace']=trace
for m,r in results.items():
    assert r['map']==m and r['seed']==615 and r['new_red_rounds']==1 and r['baseline_reruns']==0
    assert read(ROOT/m/'received/POST_RUN_SOURCE_CHECK.json')['status']=='PASS'
    assert read(ROOT/m/'received/SOURCE_MATCH.json')['candidate_zip_sha256']=='0ed2e45090a6a8104c0a3bf92d8ac79382a7891eccb978ffaba8a72a2b06a449'
out=ROOT/'delivery';out.mkdir(exist_ok=True)
report=['# 93%预算交图候选：Map08、Map09种子615各一次\n',
'本轮只新增当前冻结候选Map08、Map09各一场，共两场红队。未重跑已有V16或按行索引结果，未新增其他地图或蓝队比赛，未改算法、导航、拟合、投放或依赖。V16继续作为比赛提交基线。\n']
for m,r in results.items():
    a=r['submission_analysis'];v=r['versions']['budget93'];calls=v['all_submissions']
    report.extend(['## '+m+'：结束路径与结果\n',
        f"本场SDK采用{v['submission_drone']}号机第{v['submission_step']}步提交，结束路径`{a['ending_path']}`。预算窗口是否进入：{a['budget_window_entered']}；是否使用预算出口：{a['budget_exit_used']}；是否在5022步之前结束：{a['selected_submission_before_budget_window']}。实投{v['placed']}枚，结束时各机真实库存：`{json.dumps(a['actual_final_inventory'])}`。",
        f"提交调用共{a['submission_calls']}次，同帧多机提交：{a['simultaneous_submission']}。调用清单：`{json.dumps(calls,ensure_ascii=False)}`。",''])
    for label,c in r['comparison'].items():
        delta=c['budget_minus_reference']
        report.append(f"相对{label}：步数{delta['submission_step']:+d}，得分小计{delta['score_out_of_80']:+.6f}，地图分{delta['map_score']:+.6f}，墙覆盖分{delta['wall_score']:+.6f}，最终墙钟{delta['final_walltime_seconds']:+.6f}秒；提交图片相同={c['same_selected_map']}，全部投放事件相同={c['same_all_accepted_placements']}。")
    if not a['budget_window_entered']:
        report.append('本场结束前尚未进入5022—5051预算窗口，因此没有通过新预算策略提前截断比赛。若与历史结果仍有差异，应检查已有墙钟收尾与缓存规则、负载和触发步数，不能把这些差异直接归为预算提前交图。')
    elif a['budget_exit_used']:
        report.append('本场确实由新预算出口结束。是否损失后期信息需结合图片、得分、墙覆盖和实投差异评价；只跑这一场，不能保证其他种子或负载下的收益。')
    else:
        report.append('本场进入过预算窗口但没有从预算出口结束；应以预算门槛审计及最终出口记录解释，不能将未触发的预算提交当作成功提前结束。')
    report.append('')
    if m=='Map09':
        c=r['comparison']['rowindex'];p=c['accepted_placements']
        assert p['reference'][:-1]==p['budget93'][:-1]
        report.extend(['本场明显退分：相对已有按行索引候选，小计下降5.698468，地图分下降14.623477，墙覆盖下降5.240526。原墙钟兜底在178.519秒左右、第3990步触发；该步数尚早于新窗口，全部预算事件和审计为空。',
        '进一步核对：1号机在3503步进入原末弹收尾，3520步实际放下末弹、3521步确认；历史V16为4343步实投，历史按行索引为4561步实投。前9次接受投放记录完全相同，最后一枚实际位置改变：`'+json.dumps({'rowindex':p['reference'][-1],'budget93':p['budget93'][-1]},ensure_ascii=False)+'`。',
        '本场进入收尾时已用约155.034秒，剩24.966秒，满足原有剩余25秒及停滞条件。0号最后采用3870版缓存，历史V16和按行索引分别采用4590、4950版。它们直接说明原墙钟流程在更小步数介入，末弹位置、可运行步数和缓存更新机会均改变；不能把地图变化直接解释为新预算出口截断。',
        '本轮整机CPU占用均值54.536%，历史两场约11.49%；所选CPU池其他任务估计等效核均值15.706，历史均低于0.04。负载差构成明显混杂，本次无法隔离代码自身开销与外部负载各自的影响，也不能证明候选在同负载下退化或无退化。',
        '收尾与缓存证据：`'+json.dumps(trace,ensure_ascii=False)+'`。',''])
    text=(ROOT/m/'delivery/REPORT.md').read_text(encoding='utf8')
    report.append(text.replace('# 93%预算交图候选：'+m+'种子615单次测试','### '+m+'详细证据',1))
report.extend(['## 汇总边界\n','Map08先选定当时空闲的16个物理核。Map09开始前无法找到16个空闲物理核，停止的仅是尚未开局的选核等待进程；没有中断或重跑比赛。随后复用本轮Map08同一组核心带干扰运行，实时入场负载见Map09/ADMISSION.json，变更记录见MAP09_ADMISSION_CHANGE.json。Map09的AFFINITY_SELECTION.json继承Map08的原选核拓扑和预筛选数据，不可当作Map09空闲证明。算法、比赛参数、线程配置均未改变。',
'历史参考场次的核心组和后台负载与本轮不同。已记录每场CPU占用、CPU亲和性、进程及运行队列等待；不声称整机低负载或严格相同负载。单次最终墙钟差不等于纯算法耗时差。',
'比赛参数、出生点、配置、SDK版本均已核对；原始比赛产物和额外导出均按SHA256核验，算法源文件运行前后校验通过。完整候选源码及56项反例见提交53a6e679e8f4d4faacf67ef8ca915f9ebfa9e473。'])
save(out/'RESULTS.json',dict(status='COMPLETE',maps=['Map08','Map09'],seed=615,new_red_rounds=2,baseline_reruns=0,other_new_maps=0,algorithm_changes=False,V16_remains_competition_baseline=True,results=results))
(out/'REPORT.md').write_text('\n'.join(report)+'\n',encoding='utf8')
with ZipFile(out/'RUN_EVIDENCE.zip','w',ZIP_DEFLATED) as z:
    for m in results:
        with ZipFile(ROOT/m/'delivery/RUN_EVIDENCE.zip') as part:
            for n in part.namelist():z.writestr(m+'/'+n,part.read(n))
    z.write(Path(__file__),Path(__file__).name)
    for n in ['monitor09.py','monitor09_body.txt','MAP09_ADMISSION_CHANGE.json']:z.write(ROOT/n,n)
save(out/'CHECKSUMS_SHA256.json',{p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.name!='CHECKSUMS_SHA256.json'})
print(json.dumps({m:{'versions':{k:{f:v[f] for f in ['submission_drone','submission_step','submission_calls','score_out_of_80','map_score','wall_score','placed','final_walltime_seconds']} for k,v in r['versions'].items()},'analysis':r['submission_analysis']} for m,r in results.items()},indent=2,ensure_ascii=False))
