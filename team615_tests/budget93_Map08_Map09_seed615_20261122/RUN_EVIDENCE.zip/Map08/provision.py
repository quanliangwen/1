from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import ast,json,shutil,subprocess
ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'team615_rowindex_budget93_20261122'
PREV=ROOT.parent/'team615_budget93_map06_seed615_20261122'
HOST='quanliangwen@10.112.162.60';REMOTE='/home/quanliangwen/isolated_test/'+ROOT.name
H=lambda p:sha256(p.read_bytes()).hexdigest()
save=lambda p,d:p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
b=json.loads((SRC/'BUILD.json').read_text());tests=json.loads((SRC/'COUNTEREXAMPLES.json').read_text(encoding='utf8'))
assert b['status']==tests['status']=='PASS' and tests['total_checks']==56
assert H(SRC/'candidate_snapshot.zip')==b['candidate_zip_sha256']=='0ed2e45090a6a8104c0a3bf92d8ac79382a7891eccb978ffaba8a72a2b06a449'
assert H(SRC/'rowindex_baseline_snapshot.zip')==b['baseline_zip_sha256']=='1dfbbfd4186063edb908bd7cb1f812a0e8956a69901f28988f632acee2c70784'
templates={'Map08':ROOT.parent/'team615_v16_rowindex_maps06_08_pair_20261122/Map08/current','Map09':ROOT.parent/'team615_v16_rowindex_map09_pair_20261122/current'}
for mapname,template in templates.items():
    stage=ROOT/mapname;stage.mkdir()
    for n in ['candidate_snapshot.zip','baseline_snapshot.zip','DECLARED_SOURCE.json','PATCH_BINDING.json','OFFLINE_CHECK.json','BUILD.json','stage_run.py']:shutil.copyfile(PREV/'Map06'/n,stage/n)
    assert H(stage/'candidate_snapshot.zip')==b['candidate_zip_sha256']
    for n in ['place_map09.yml','matched_spawns.json','EXPECTED_ZONES.json']:shutil.copyfile(template/n,stage/n)
    assert ('map_name: '+mapname) in (stage/'place_map09.yml').read_text()
    observer=(stage/'stage_run.py').read_text();original=(template/'stage_run.py').read_text()
    def prefix(t):
        tree=ast.parse(t);i=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.Assign) and any(isinstance(v,ast.Name) and v.id=='details' for v in n.targets))
        return ast.dump(ast.Module(body=tree.body[:i],type_ignores=[]),include_attributes=False)
    assert prefix(observer)==prefix(original)
    save(stage/'OBSERVER_CHANGE.json',dict(original_sha256=H(template/'stage_run.py'),current_sha256=H(stage/'stage_run.py'),runtime_ast_unchanged=True,change='same post-scoring budget event export as completed Map06 test'))
    (stage/'run_monitored.sh').write_text((PREV/'Map06/run_monitored.sh').read_text().replace('Map06',mapname),encoding='utf8',newline='\n')
    save(stage/'AUTHORIZED_RUN.json',dict(maps=[mapname],seed=615,total_red_rounds=1,retries=False,algorithm_changes=False,candidate_zip_sha256=b['candidate_zip_sha256'],comparison='historical row-index and V16 results; no baseline reruns',V16_remains_competition_baseline=True))
helper=(PREV/'monitor.py').read_text().split("stage=ROOT/'Map06'")[0]
(ROOT/'monitor.py').write_text(helper+(ROOT/'monitor_body.txt').read_text(),encoding='utf8',newline='\n')
shutil.copyfile(PREV/'environment.py',ROOT/'environment.py')
save(ROOT/'AUTHORIZED_RUN.json',dict(maps=['Map08','Map09'],seed=615,total_red_rounds=2,red_rounds_per_map=1,other_maps=False,baseline_reruns=0,retries=False,algorithm_changes=False,candidate_zip_sha256=b['candidate_zip_sha256'],V16_remains_competition_baseline=True))
for p in [*ROOT.glob('*.py'),*ROOT.glob('*/stage_run.py')]:ast.parse(p.read_text())
subprocess.run(['ssh',HOST,'mkdir '+REMOTE],check=True)
subprocess.run(['scp','-q',*[str(ROOT/n) for n in ['monitor.py','environment.py','AUTHORIZED_RUN.json']],HOST+':'+REMOTE+'/'],check=True)
for mapname in templates:
    subprocess.run(['ssh',HOST,'mkdir '+REMOTE+'/'+mapname],check=True)
    subprocess.run(['scp','-q',*[str(p) for p in (ROOT/mapname).iterdir()],HOST+':'+REMOTE+'/'+mapname+'/'],check=True)
subprocess.run(['ssh',HOST,'/home/junhao/quan/parallel_test_solver/match/.venv/bin/python '+REMOTE+'/environment.py'],check=True)
print(subprocess.run(['ssh',HOST,'nohup python3 '+REMOTE+'/monitor.py > '+REMOTE+'/queue.log 2>&1 < /dev/null & echo TWO_AUTHORIZED_MATCHES_QUEUED_ONCE_EACH'],capture_output=True,text=True,check=True).stdout)
