from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json,shutil,subprocess

ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'team615_return50_only_20261122'
OLD60=ROOT.parent/'team615_finish_minimal_maps05_06_07_seed615_20261122'
OLD40=ROOT.parent/'team615_return40_maps05_06_07_seed615_20261122'
read=lambda p:json.loads(p.read_text(encoding='utf8'))
save=lambda p,d:p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
maps=['Map05','Map06','Map07'];rows={m:read(ROOT/m/'RESULTS.json') for m in maps}
assert all(r['status']=='COMPLETE' and r['new_red_rounds']==1 and r['baseline_reruns']==0 for r in rows.values())
b=read(SRC/'BUILD.json');assert b['candidate_zip_sha256']=='e69ea77adb25b9ecbb8bd3a38f34f2241c35ad788c147aff67bc6d83e7c227e8'
assert sha256((SRC/'candidate_snapshot.zip').read_bytes()).hexdigest()==b['candidate_zip_sha256']
assert all(sha256((SRC/'candidate'/n).read_bytes()).hexdigest()==h for n,h in b['candidate_files'].items())
v16=ROOT.parent/'team615_red_v16_first30_release_20261121/delivery/team615_red_v16.zip'
v16sha=sha256(v16.read_bytes()).hexdigest();assert v16sha=='e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791'
host='quanliangwen@10.112.162.60';remote='/home/quanliangwen/isolated_test/'+ROOT.name
received=ROOT/'received';received.mkdir(exist_ok=True)
names=['STATUS.json','HOST.json','ENVIRONMENT.json','AUTHORIZED_RUN.json','OBSERVER_BINDING.json','monitor.py','queue_resources.jsonl','queue.log']
subprocess.run(['scp','-q',*[host+':'+remote+'/'+n for n in names],str(received)],check=True)
assert read(received/'STATUS.json')['state']=='COMPLETE' and read(received/'STATUS.json')['new_red_rounds']==3
out=ROOT/'delivery';out.mkdir(exist_ok=True)
save(out/'RESULTS.json',dict(status='COMPLETE',seed=615,new_red_rounds=3,rounds_per_map=1,baseline_reruns=0,
 other_maps=False,algorithm_changes_during_tests=False,V16_remains_competition_baseline=True,V16_archive_sha256=v16sha,
 candidate50_zip_sha256=b['candidate_zip_sha256'],parent40_zip_sha256=b['baseline_zip_sha256'],
 reference60_zip_sha256='c4b8513084ce114e6aae04b42489c995e73955ec545a64c5f9d999190004a562',maps=rows,
 validation='50% return only,43 threshold checks+95 existing functional checks+56 budget regressions; historical 40/60 results not rerun',
 environment_limitations='All use8 assigned logical CPUs from8 distinct physical cores; not simultaneous, exclusive or identical-load timing comparisons; SMT interference recorded.'))
arms=[('40%','reference40'),('50%','candidate'),('60%','baseline')]
f=lambda v:'—' if v is None else f'{v:.4f}' if isinstance(v,float) else str(v)
report=['# 50%返航最后一轮：Map05、Map06、Map07种子615，与40%/60%对照\n',
 '只新跑50%候选，每图一场、共三场红队。40%和60%均引用既有记录，未重跑；没有运行其他地图。测试期间未再修改算法、SDK、导航、拟合、投放、依赖。V16继续作为比赛基线。\n',
 '相对40%源码只把GroupExchange.return_start从limit*2//5改为limit//2，其他55项文件和其他方法保持不变。50%门槛：Map05=3600步，Map06/07=2700步；末弹完成和普通交图共享门槛仍60%，原安全、实投确认、协调、93%预算和1.5秒墙钟硬兜底均保持。携弹或路线不安全时不会强行返航。\n',
 f"50%冻结归档SHA256 `{b['candidate_zip_sha256']}`，源代码在candidate/，它是研究候选，不是新正式比赛提交包；43+95+56=194项反例通过不等于实战稳定提升。三场输入及运行时56项源码前后核对通过，V16原件哈希未变。\n",
 '官方封存SDK6557940dc18549ffc7a945db887da5b05b7ed2f1；Map05=7200步/240秒，Map06/07=5400步/180秒；5机、每机2枚。各图种子、出生点/朝向、实际区域、墙几何和评分配置均与40%/60%记录核对一致。实际无GPS/禁通信区域：Map05/07为0/0，Map06为0/1。\n',
 '## 主要结果\n','| 地图 | 返航门槛 | SDK采用者/步数 | 得分小计/80 | 地图分 | 墙覆盖分 | 探索率/% | 实投 | 掉血 | 最终墙钟/秒 |',
 '|---|---|---|---:|---:|---:|---:|---:|---:|---:|']
for m,r in rows.items():
 for label,key in arms:
    q=r[key];report.append(f"| {m} | {label} | {q['submission_drone']} / {q['submission_step']} | {f(q['score_out_of_80'])} | {f(q['map_score'])} | {f(q['wall_score'])} | {f(q['exploration_percent'])} | {q['placed']}/10 | {q['health_lost']} | {f(q['final_walltime_seconds'])} |")
report+=['','得分小计沿用历史口径，核对官方0.5×地图分＋0.2×墙覆盖分＋0.1×时间分；不冒称完整100分。时间配置按步数计算，步数较少不等于墙钟更短；SDK采用者也不等于唯一提交调用者。','']
if (ROOT/'INTERPRETATION.md').exists():report +=[(ROOT/'INTERPRETATION.md').read_text(encoding='utf8'),'']
report+=['## 首次实际返航任务接管\n','取原group_audit的return_owned事件；不是比例门槛本身，也不是到达交互点。—表示没有接管；完整任务/重试、预检、中止和到达见RESULTS.json。\n',
 '| 地图 | 门槛 | 0号 | 1号 | 2号 | 3号 | 4号 |','|---|---|---:|---:|---:|---:|---:|']
for m,r in rows.items():
 for label,key in arms:report.append('| '+m+' | '+label+' | '+' | '.join(f(r[key]['first_actual_return_step'][str(i)]) for i in range(5))+' |')
report+=['','## 第二枚实投/库存确认步数\n','| 地图 | 门槛 | 0号 | 1号 | 2号 | 3号 | 4号 |','|---|---|---|---|---|---|---|']
for m,r in rows.items():
 for label,key in arms:
    vals=[]
    for i in range(5):
        q=r[key]['confirmations'][str(i)];vals.append('未投完，剩'+str(q['remaining']) if q['second_accepted_step'] is None else f"{q['second_accepted_step']}/{q['final_bomb_confirmation_step']}")
    report.append('| '+m+' | '+label+' | '+' | '.join(vals)+' |')
report+=['','实投来自SDK返回成功，库存下降才确认；不能将发指令当实投。各次实投中心、请求分支及对应墙钟时间已保存。','',
 '## 确认缺口与实际终局\n']
for m,r in rows.items():
 report +=[f'### {m}']
 for label,key in arms:
    q=r[key];report +=[f"{label}：路径 `{q['ending_path']}`；全部提交 `{json.dumps(q['submission_calls'],ensure_ascii=False)}`。",
       '首次全队零确认：`'+json.dumps(q['first_team_confirmed_step'])+'`；普通就绪：`'+json.dumps(q['ordinary_first_ready'])+'`；交互提前出口启动：`'+json.dumps(q['group_early_finish_started'])+'`。',
       '结束时仍为正库存的记录：`'+json.dumps(q['ordinary_stock_blocks_at_end'],ensure_ascii=False)+'`；stale_positive=True表示实际已投空但此机仍持有旧正数。',
       f"同帧多机提交={q['simultaneous_submission']}；choice后等待步数={q['selected_choice_wait_steps']}；观察到2步等待={q['choice_two_step_wait_observed']}（无choice不适用）。",'']
report+=['## 同一步数耗时与环境\n','三版都按8个空闲逻辑CPU、来自8个物理核的口径启动；SMT兄弟线程可能忙。历史CPU池/负载不同，不是独占、同时同核或严格同负载实验。诊断观察器与40%版相同，库存日志从40%采样但不参与控制。资源和队列等待保留，不将墙钟差全归因于返航参数。','',
 '| 地图 | 步数 | 60%累计秒 | 50%累计秒 | 50%−60%秒 |','|---|---:|---:|---:|---:|']
for m,r in rows.items():
 for t,q in r['same_step_cumulative_timing'].items():report.append(f"| {m} | {t} | {q['baseline_seconds']:.4f} | {q['candidate_seconds']:.4f} | {q['difference']:+.4f} |")
report+=['','与40%的同一步数耗时、轨迹首次差异、落点变化、漏墙和误画详见RESULTS.json。50%沿用原候选已知的确认和普通提交回落问题，本轮没有连带修复；不因为分数变化声称已解决。没有官网验证、官网上传或新的正式比赛ZIP。']
(out/'REPORT.md').write_text('\n'.join(report)+'\n',encoding='utf8')
for n in b['candidate_files']:
    dest=out/'candidate'/n;dest.parent.mkdir(exist_ok=True);shutil.copyfile(SRC/'candidate'/n,dest)
for n in ['BUILD.json','CHANGES.patch','RETURN50_TESTS.json','COUNTEREXAMPLES.json','BUDGET_REGRESSION.json',
          'freeze.py','verify_return50.py','verify_finish.py','verify_budget_regression.py','return50.log','counterexamples.log','budget_regression.log']:
    dest=out/'source_validation'/n;dest.parent.mkdir(exist_ok=True);shutil.copyfile(SRC/n,dest)
with ZipFile(out/'RUN_EVIDENCE.zip','w',ZIP_DEFLATED) as z:
 for folder in [received,*[ROOT/m/'received' for m in maps]]:
    for p in folder.rglob('*'):
        if p.is_file():z.write(p,p.relative_to(ROOT).as_posix())
 for n in ['provision.py','collect_one.py','finalize.py','watch.py','AUTHORIZED_RUN.json','OBSERVER_BINDING.json','INTERPRETATION.md']:
    if (ROOT/n).exists():z.write(ROOT/n,n)
 for m in maps:
    for n in ['stage_run.py','DECLARED_SOURCE.json','PATCH_BINDING.json','OFFLINE_CHECK.json','place_map09.yml','run_monitored.sh','matched_spawns.json','EXPECTED_ZONES.json','EXPECTED_LIMITS.json']:
        z.write(ROOT/m/n,m+'/'+n)
    for tag,old in [('baseline60',OLD60),('reference40',OLD40)]:
        for n in ['OFFICIAL_SCORE.json','START.json','SOURCE_MATCH.json','placement_events.jsonl','POST_RUN_SOURCE_CHECK.json','ADMISSION.json','resources.jsonl']:
            z.write(old/m/'received'/n,tag+'/'+m+'/'+n)
manifest={p.relative_to(out).as_posix():sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*')) if p.is_file() and p.name!='CHECKSUMS_SHA256.json'}
save(out/'CHECKSUMS_SHA256.json',manifest)
print(json.dumps(dict(status='COMPLETE',new_red_rounds=3,files=len(manifest)+1,evidence_bytes=(out/'RUN_EVIDENCE.zip').stat().st_size),indent=2))
