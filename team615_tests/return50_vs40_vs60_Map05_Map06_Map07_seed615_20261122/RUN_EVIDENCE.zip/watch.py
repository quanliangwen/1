from pathlib import Path
import json
root=Path(__file__).resolve().parent
print((root/'STATUS.json').read_text())
for m in ['Map05','Map06','Map07']:
    p=root/m
    if (p/'OFFICIAL_SCORE.json').exists():
        s=json.loads((p/'OFFICIAL_SCORE.json').read_text())
        print(m,'SCORED',json.dumps({k:s[k] for k in ['partial','map_score','coverage','placed','steps','elapsed_walltime','selected_submission']},ensure_ascii=False))
    elif (p/'START.json').exists():
        print(m,'RUNNING')
        if (p/'TIMING_ANCHORS.jsonl').exists():print('latest_anchor',(p/'TIMING_ANCHORS.jsonl').read_text().splitlines()[-1:])
        if (p/'placement_events.jsonl').exists():
            lines=(p/'placement_events.jsonl').read_text().splitlines();rows=[]
            for line in lines:
                try:rows.append(json.loads(line))
                except json.JSONDecodeError:pass
            accepted=[r for r in rows if r['event']=='sdk_placement' and r.get('accepted')]
            print('accepted',[(r['drone'],r['step']) for r in accepted])
    else:print(m,'NOT_STARTED')
