from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json,subprocess

ROOT=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf8'))
save=lambda p,d:p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
maps=['Map05','Map06','Map07'];rows={m:read(ROOT/m/'RESULTS.json') for m in maps}
assert all(r['status']=='COMPLETE' and r['new_red_rounds']==1 and r['baseline_reruns']==0 for r in rows.values())
v16=ROOT.parent/'team615_red_v16_first30_release_20261121/delivery/team615_red_v16.zip'
candidate=ROOT.parent/'team615_budget93_finish_minimal_20261122/candidate_snapshot.zip'
assert sha256(v16.read_bytes()).hexdigest()=='e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791'
assert sha256(candidate.read_bytes()).hexdigest()=='c4b8513084ce114e6aae04b42489c995e73955ec545a64c5f9d999190004a562'
host='quanliangwen@10.112.162.60';remote='/home/quanliangwen/isolated_test/'+ROOT.name
received=ROOT/'received';received.mkdir(exist_ok=True)
subprocess.run(['scp','-q',*[host+':'+remote+'/'+n for n in ['STATUS.json','HOST.json','ENVIRONMENT.json','AUTHORIZED_RUN.json',
    'OBSERVER_BINDING.json','ADMISSION_CHANGE.json','monitor.py','monitor_physical_wait.py','queue_resources.jsonl',
    'queue_resources_8logical.jsonl','queue.log','queue_8logical.log','monitor_remaining.py','queue_resources_remaining.jsonl',
    'queue_remaining.log','PREFLIGHT_RECOVERY.json','STATUS_before_recovery.json']],str(received)],check=True)
failed=ROOT/'Map06_preflight_failed';failed.mkdir(exist_ok=True)
subprocess.run(['scp','-q',*[host+':'+remote+'/Map06_preflight_failed/'+n for n in ['run.log','dispatch.log',
    'SOURCE_MATCH.json','MONITOR_FINISH.json','placement_events.jsonl','TIMING_ANCHORS.jsonl','EXPECTED_ZONES.json','stage_run.py']],str(failed)],check=True)
assert (failed/'TIMING_ANCHORS.jsonl').stat().st_size==(failed/'placement_events.jsonl').stat().st_size==0
assert read(received/'STATUS.json')['state']=='COMPLETE'
assert read(received/'STATUS.json')['new_red_rounds']==3
out=ROOT/'delivery';out.mkdir(exist_ok=True)
data=dict(status='COMPLETE',seed=615,new_red_rounds=3,baseline_reruns=0,other_maps=False,algorithm_changes=False,
    V16_remains_competition_baseline=True,candidate_commit='1dd95fecebdd147ff48459a66fccd619d11ef6c6',
    candidate_zip_sha256='c4b8513084ce114e6aae04b42489c995e73955ec545a64c5f9d999190004a562',maps=rows,
    V16_archive_sha256='e98990cfd9269ab521621bc97d7c9e81e21fa83bb83dafbfefb3943480dd6791',
    environment_limitations='Historical runs are not simultaneous controlled CPU comparisons; Map06 old32 assigned logical CPUs, current8; current SMT siblings may be busy. No baseline reruns or altered limits.')
save(out/'RESULTS.json',data)
f=lambda v:'—' if v is None else f'{v:.4f}' if isinstance(v,float) else str(v)
report=['# 末弹完成与交互提前交图候选：Map05、Map06、Map07种子615对照\n',
 '当前冻结候选每图只跑一场，共3场红队；已有93%预算候选只读历史记录，没有重跑。算法未修改，没有运行其他地图。V16继续作为比赛基线。\n',
 '当前源码为提交1dd95fecebdd147ff48459a66fccd619d11ef6c6，冻结归档SHA256 c4b8513084ce114e6aae04b42489c995e73955ec545a64c5f9d999190004a562；基线为0ed2e45090a6a8104c0a3bf92d8ac79382a7891eccb978ffaba8a72a2b06a449。三场输入及运行时56项源码前后核验通过。\n',
 'SDK为6557940dc18549ffc7a945db887da5b05b7ed2f1；原生Map05=7200步/240秒，Map06/07=5400步/180秒。每图5机、每机2枚；种子、出生位置、朝向、SDK归档、实际区域数和评分配置与各自旧记录核对一致。Map05/07实际无GPS/无通信区域为0/0，Map06为0/1。\n',
 '## 主要结果\n',
 '| 地图 | 版本 | 提交者/步数 | 得分小计/80 | 地图分 | 墙覆盖分 | 实投 | 掉血 | 最终墙钟/秒 |',
 '|---|---|---|---:|---:|---:|---:|---:|---:|']
risks=[m for m,r in rows.items() if r['candidate']['choice_two_step_wait_observed'] is False]
if risks:
 report.insert(2,'**实测发现协调缺口：'+ '、'.join(risks)+'的普通出口在创建choice同帧提交，未等待原定2帧。前一轮反例漏测了try_submit返回等待后落入普通出口的组合路径。本轮未修代码，不能用151项反例已通过代替完整路径正确性，更不能据此升级比赛基线。**\n')
for m,r in rows.items():
 for label,key in [('原93%预算','baseline'),('当前候选','candidate')]:
    q=r[key];report.append(f"| {m} | {label} | {q['submission_drone']} / {q['submission_step']} | {f(q['score_out_of_80'])} | {f(q['map_score'])} | {f(q['wall_score'])} | {q['placed']}/10 | {q['health_lost']} | {f(q['final_walltime_seconds'])} |")
report+=['','小计与历史口径一致，核对官方输出的0.5×地图分＋0.2×墙覆盖分＋0.1×时间分；不把未输出的炸弹项冒称完整100分。墙覆盖分与探索率不同，详细分解、漏墙、误画及探索率见RESULTS.json。','',
 'Map05：4号5228→5229为新末弹分支的实投/确认；0号5660→5661仍来自原25秒墙钟收尾，不应归功于普通末弹分支。0号5844步交图，旧固定4524步留时门槛早已过去；本图不能证明在旧180+24门槛之前结束。步数虽少859，最终墙钟反而多3.052秒，不能宣称实测省时。',
 'Map06：全队3247步已投完，但没有任何飞机补齐全队零确认，原正库存仍挡住普通提交；最终0号4678步由1.5秒墙钟硬兜底提交，未到5022步93%窗口。其余9枚实投中心与旧记录一致，3号第二枚中心移动约102.255px，墙覆盖下降1.351分对应落点改变；不是单纯的墙钟环境解释。','',
 'Map07：4号3250步通过新末弹分支实际投出、3251步库存确认，早于5022步93%门槛；旧版末弹始终未投。实投9→10，得分小计+1.446、地图分+2.689、墙覆盖+0.549，但掉血0→4、最终墙钟+3.526秒。所有飞机仍缺全队零确认，交互提前出口均未启动；最终1/2/3号在5039步预算出口同帧提交，SDK采用1号。Map06则是5机在墙钟硬兜底同帧提交、SDK采用0号；不能把这两图称作普通交图协调成功。','',
 '## 各机第二枚实际投出与库存确认\n',
 '| 地图 | 版本 | 0号 实投→确认 | 1号 | 2号 | 3号 | 4号 |',
 '|---|---|---|---|---|---|---|']
for m,r in rows.items():
 for label,key in [('原93%预算','baseline'),('当前候选','candidate')]:
    q=r[key];vals=[]
    for i in range(5):
        c=q['confirmations'][str(i)];vals.append('未完成，剩'+str(c['remaining']) if c['second_accepted_step'] is None else f"{c['second_accepted_step']}→{c['final_bomb_confirmation_step']}")
    report.append('| '+m+' | '+label+' | '+' | '.join(vals)+' |')
report+=['','“实投”来自SDK _try_place_bomb返回True；“确认”来自原库存同步，不把发出脉冲当作投成。未投完时last_confirmation可能只是首枚确认，因此本表明确显示未完成。','',
 '## 库存确认、交互与终局路径\n']
for m,r in rows.items():
 q=r['candidate'];raw=read(ROOT/m/'received/OFFICIAL_SCORE.json')
 ev=[json.loads(l) for l in (ROOT/m/'received/placement_events.jsonl').read_text(encoding='utf8').splitlines()]
 failures={};requests=[]
 for row in ev:
    if row.get('event')=='completion_rejected':
        d=str(row['drone']);reason=str(row['values'][0]);failures.setdefault(d,{})[reason]=failures.setdefault(d,{}).get(reason,0)+1
    if row.get('event')=='request' and row.get('branch')=='last_bomb_completion':requests.append({k:row[k] for k in ['drone','step','gps_fixed','speed','walltime_seconds']})
 report +=[f'### {m}',
    f"结束路径：{q['ending_path']}；提交调用：`{json.dumps(q['submission_calls'],ensure_ascii=False)}`；同帧多机提交：{q['simultaneous_submission']}。",
    f"所选提交相对choice创建的等待步数：{q['selected_choice_wait_steps']}；是否观察到至少2步选择等待：{q['choice_two_step_wait_observed']}（无choice则不适用）。普通提交和分组提交的分流以实际审计为准，不能把提前出口已启动当成固定留时被绕过的因果证明。",
    '各机首次全队库存清零（仅从60%后新增状态日志观察）：`'+json.dumps(q['first_team_confirmed_step'],ensure_ascii=False)+'`。',
    '原普通就绪步数：`'+json.dumps(q['ordinary_first_ready'],ensure_ascii=False)+'`；交互提前出口启动：`'+json.dumps(q['group_early_finish_started'],ensure_ascii=False)+'`。',
    '确认返航重试是否消耗：`'+json.dumps(q['confirmation_retry_used'],ensure_ascii=False)+'`。',
    '结束时仍为正库存的来源记录（stale_positive=True表示实际已空，但该机仍持有旧正数；False表示确有剩弹）：`'+json.dumps(q['ordinary_stock_blocks_at_end'],ensure_ascii=False)+'`。',
    '末弹新分支请求：`'+json.dumps(requests,ensure_ascii=False)+'`。',
    '末弹新分支复核拒绝次数：`'+json.dumps(failures,ensure_ascii=False)+'`。',
    '组交互关键事件：`'+json.dumps({str(d['drone']):[row for row in d['group_audit'] if row[1] in ['confirmation_return_retry','return_owned','route_abort','exchange_finish_ready','choice_proposed','submitted','soft_cutoff_submit','coord_cutoff']] for d in raw['drone_details']},ensure_ascii=False)+'`。','']
report+=['## 时间与环境边界\n',
 '新场每图固定8个空闲逻辑CPU，来自8个不同物理核；SMT兄弟线程可能忙，不作整机低负载或独占承诺。最初等待物理核完全空闲时未启动任何比赛；按用户先前“8个CPU空闲即可”的要求，仅更改启动前CPU准入，没有中止或重跑任何比赛。等待记录和ADMISSION_CHANGE.json保留。',
 '历史Map05/07分配8个逻辑CPU且初选物理核整体空闲；历史Map06分配16个物理核的32个逻辑CPU，本轮8个逻辑CPU。墙钟差和同一步数耗时受共享负载、SMT和分配差异影响，不作严格代码加速归因。新增观察器只追加少量状态变化/末弹事件与评分后导出，但仍是需要披露的计时条件差异。',
 '', '| 地图 | 步数 | 旧累计秒 | 新累计秒 | 新−旧秒 |','|---|---:|---:|---:|---:|']
for m,r in rows.items():
 for t,q in r['same_step_cumulative_timing'].items():
    report.append(f"| {m} | {t} | {q['baseline_seconds']:.4f} | {q['candidate_seconds']:.4f} | {q['difference']:+.4f} |")
report+=['','资源采样（整机忙碌、load1及监控池额外CPU工作量统计）和首次轨迹分歧步数均见RESULTS.json。记录从第2步开始，累计时刻按step−2索引。','',
 'Map06首次构造前校验误用了0个禁通信区，官方实际为1，因而在START和任何control/physics之前终止；原始事件和计时文件均为空，错误日志保留。只修正测试EXPECTED_ZONES为历史官方记录0/1，再完成其唯一一场；Map05未重跑，算法/SDK/地图本身未修改。这是一次零步启动错误，不是丢弃低分后重跑。','',
 '本轮是每图单种子的单次观察，不能据此宣称稳定提升或替换V16。未修改任何算法、依赖、SDK、导航、拟合或投放规则；未新增比赛提交包、未官网上传。']
(out/'REPORT.md').write_text('\n'.join(report)+'\n',encoding='utf8')
with ZipFile(out/'RUN_EVIDENCE.zip','w',ZIP_DEFLATED) as z:
 for folder in [received,failed,*[ROOT/m/'received' for m in maps]]:
    for p in folder.rglob('*'):
        if p.is_file():z.write(p,p.relative_to(ROOT).as_posix())
 for n in ['provision.py','admit_8logical.py','recover_preflight.py','watch.py','collect_one.py','finalize.py','AUTHORIZED_RUN.json','OBSERVER_BINDING.json']:
    z.write(ROOT/n,n)
 for m in maps:
    for n in ['stage_run.py','DECLARED_SOURCE.json','PATCH_BINDING.json','OFFLINE_CHECK.json','place_map09.yml','run_monitored.sh','matched_spawns.json','EXPECTED_ZONES.json','EXPECTED_LIMITS.json']:
        z.write(ROOT/m/n,m+'/'+n)
    oldroot=ROOT.parent/('team615_budget93_map06_seed615_20261122' if m=='Map06' else 'team615_budget93_maps05_07_seed615_20261122')
    for n in ['OFFICIAL_SCORE.json','START.json','SOURCE_MATCH.json','placement_events.jsonl','POST_RUN_SOURCE_CHECK.json','ADMISSION.json','resources.jsonl']:
        z.write(oldroot/m/'received'/n,'baseline/'+m+'/'+n)
manifest={p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.is_file() and p.name!='CHECKSUMS_SHA256.json'}
save(out/'CHECKSUMS_SHA256.json',manifest)
print(json.dumps(dict(status='COMPLETE',new_red_rounds=3,files=len(manifest)+1,evidence_bytes=(out/'RUN_EVIDENCE.zip').stat().st_size),indent=2))
