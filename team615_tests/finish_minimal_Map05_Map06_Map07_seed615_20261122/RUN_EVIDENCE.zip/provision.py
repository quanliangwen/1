from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import ast,json,shutil,subprocess

ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'team615_budget93_finish_minimal_20261122'
OLD57=ROOT.parent/'team615_budget93_maps05_07_seed615_20261122'
OLD6=ROOT.parent/'team615_budget93_map06_seed615_20261122'
HOST='quanliangwen@10.112.162.60';REMOTE='/home/quanliangwen/isolated_test/'+ROOT.name
H=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf8'))
save=lambda p,d:p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
b=read(SRC/'BUILD.json');tests=read(SRC/'COUNTEREXAMPLES.json');reg=read(SRC/'BUDGET_REGRESSION.json')
assert tests['status']==reg['status']=='PASS' and tests['total_checks']+reg['total_checks']==151
assert H(SRC/'candidate_snapshot.zip')==b['candidate_zip_sha256']=='c4b8513084ce114e6aae04b42489c995e73955ec545a64c5f9d999190004a562'
assert H(SRC/'baseline_snapshot.zip')==b['baseline_zip_sha256']=='0ed2e45090a6a8104c0a3bf92d8ac79382a7891eccb978ffaba8a72a2b06a449'
limits={'Map05':[7200,240],'Map06':[5400,180],'Map07':[5400,180]}
spawns={m:read((OLD6 if m=='Map06' else OLD57)/m/'received/START.json')['spawn'] for m in limits}
zones={m:read((OLD6 if m=='Map06' else OLD57)/m/'received/START.json')['zones'] for m in limits}
original=(OLD57/'Map05/stage_run.py').read_text(encoding='utf8')
observer=original.replace('("Map05", "Map07")','("Map05", "Map06", "Map07")')
observer=observer.replace('def observed_control(drone, method):','stock_states = {}\n\ndef observed_control(drone, method):')
needle='        result = method()\n'
assert observer.count(needle)==1
observer=observer.replace(needle,needle+'''        if step >= drone.limit*3//5:
            counts = tuple(drone.inventory_records.get(owner,(-1,None))[1] for owner in range(drone.team_size))
            if counts != stock_states.get(drone.identifier):
                stock_states[drone.identifier] = counts
                emit(dict(drone=int(drone.identifier),step=step,event="ordinary_inventory_gate",
                          team_confirmed=drone._all_inventory_empty(),records=dict(drone.inventory_records),
                          local_inventory=int(drone.carried_bombs_count()),pending=drone.pending_drop is not None))
''')
needle='"wall_task_reserve","wall_task_end","wall_task_release","wall_task_no_route"):'
assert observer.count(needle)==1
observer=observer.replace(needle,'"completion_started","completion_review","completion_rejected","completion_expired",\n                     '+needle)
needle='             messenger_audit=d.messenger.audit,'
assert observer.count(needle)==1
observer=observer.replace(needle,'''             group_early_finish_started=d.group_exchange.early_finish_started,
             group_confirmation_retry_used=d.group_exchange.confirmation_retry_used,
             group_peer_zero_receipts=d.group_exchange.peer_zero_receipts,
             second_drop_audit=d.second_drop.audit,
'''+needle)
# JSON output supports the immutable acknowledgement sets, without touching
# the actual controller or wire types. The conversion runs only after scoring.
observer=observer.replace('json.dumps(data, indent=2, ensure_ascii=False)','json.dumps(data, indent=2, ensure_ascii=False, default=lambda v:sorted(v) if isinstance(v,(set,frozenset)) else json_native(v))')
for m in limits:
    stage=ROOT/m;stage.mkdir()
    shutil.copyfile(SRC/'candidate_snapshot.zip',stage/'candidate_snapshot.zip')
    shutil.copyfile(SRC/'baseline_snapshot.zip',stage/'baseline_snapshot.zip')
    with ZipFile(stage/'candidate_snapshot.zip') as z:files={n:sha256(z.read(n)).hexdigest() for n in z.namelist()}
    assert files==b['candidate_files']
    save(stage/'DECLARED_SOURCE.json',files)
    save(stage/'PATCH_BINDING.json',dict(baseline_commit='53a6e679e8f4d4faacf67ef8ca915f9ebfa9e473',
         baseline_zip_sha256=b['baseline_zip_sha256'],candidate_zip_sha256=b['candidate_zip_sha256'],
         baseline=b['baseline_files'],candidate=files,changed=b['changed_files']))
    save(stage/'OFFLINE_CHECK.json',dict(simulation_steps=0,unit_checks=151,
         counterexamples_sha256=H(SRC/'COUNTEREXAMPLES.json'),regression_sha256=H(SRC/'BUDGET_REGRESSION.json')))
    save(stage/'matched_spawns.json',spawns)
    save(stage/'EXPECTED_ZONES.json',zones)
    save(stage/'EXPECTED_LIMITS.json',limits)
    (stage/'stage_run.py').write_text(observer,encoding='utf8',newline='\n')
    config=(OLD57/'Map05/place_map09.yml').read_text().replace('map_name: Map05','map_name: '+m)
    (stage/'place_map09.yml').write_text(config,encoding='utf8',newline='\n')
    shell=(OLD57/'Map05/run_monitored.sh').read_text().replace('Map05',m).replace('budget93','finish_minimal')
    (stage/'run_monitored.sh').write_text(shell,encoding='utf8',newline='\n')
monitor=(OLD57/'monitor.py').read_text(encoding='utf8').replace("maps=['Map05','Map07'];COUNT=8","maps=['Map05','Map06','Map07'];COUNT=8")
monitor=monitor.replace('new_red_rounds=2','new_red_rounds=3')
(ROOT/'monitor.py').write_text(monitor,encoding='utf8',newline='\n')
shutil.copyfile(OLD57/'environment.py',ROOT/'environment.py')
save(ROOT/'AUTHORIZED_RUN.json',dict(maps=list(limits),seed=615,rounds_per_map=1,total_red_rounds=3,
     other_maps=False,baseline_reruns=0,algorithm_changes=False,V16_remains_competition_baseline=True,
     assigned_logical_cpus=8,distinct_physical_cores=8,global_load_is_admission_gate=False,
     candidate_zip_sha256=b['candidate_zip_sha256'],native_limits=limits,retries=False))
save(ROOT/'OBSERVER_BINDING.json',dict(original_observer_sha256=H(OLD57/'Map05/stage_run.py'),
     observer_sha256=H(ROOT/'Map05/stage_run.py'),same_observer_all_maps=True,
     changes='Map06 allowlist; sparse state-change inventory-gate and completion audit logging; post-scoring new state export and set serialization',
     algorithm_bytes_changed=False,original_score_and_submission_call_order_preserved=True,
     native_limits=limits,spawn_reference='same SDK seed615 starts as the existing budget93 matches'))
for p in [*ROOT.glob('*.py'),*ROOT.glob('*/stage_run.py')]:ast.parse(p.read_text(encoding='utf8'))
subprocess.run(['ssh','-o','BatchMode=yes',HOST,'mkdir '+REMOTE],check=True)
subprocess.run(['scp','-q',*[str(ROOT/n) for n in ['monitor.py','environment.py','AUTHORIZED_RUN.json','OBSERVER_BINDING.json']],HOST+':'+REMOTE+'/'],check=True)
for m in limits:
    subprocess.run(['ssh',HOST,'mkdir '+REMOTE+'/'+m],check=True)
    subprocess.run(['scp','-q',*[str(p) for p in (ROOT/m).iterdir()],HOST+':'+REMOTE+'/'+m+'/'],check=True)
subprocess.run(['ssh',HOST,'/home/junhao/quan/parallel_test_solver/match/.venv/bin/python '+REMOTE+'/environment.py'],check=True)
print(subprocess.run(['ssh',HOST,'nohup python3 '+REMOTE+'/monitor.py > '+REMOTE+'/queue.log 2>&1 < /dev/null & echo MAP05_MAP06_MAP07_ONCE_EACH_QUEUED'],capture_output=True,text=True,check=True).stdout)
