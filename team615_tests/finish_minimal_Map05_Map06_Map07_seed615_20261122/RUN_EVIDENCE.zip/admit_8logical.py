"""Change only pre-match CPU admission; no source or running match is touched."""
from pathlib import Path
import json,os,signal,time
ROOT=Path(__file__).resolve().parent
target=str(ROOT/'monitor.py')
pids=[]
for p in Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:args=(p/'cmdline').read_bytes().split(b'\0')
    except (FileNotFoundError,PermissionError,ProcessLookupError):continue
    if target.encode() in args:pids.append(int(p.name))
assert len(pids)==1,pids
pid=pids[0];os.kill(pid,signal.SIGSTOP)
try:
    children=(Path('/proc')/str(pid)/'task'/str(pid)/'children').read_text().split()
    assert not children,children
    for m in ['Map05','Map06','Map07']:
        assert not any((ROOT/m/n).exists() for n in ['START.json','RUN_ONCE_CLAIM','SDK_PID'])
except BaseException:
    os.kill(pid,signal.SIGCONT);raise
os.kill(pid,signal.SIGTERM);os.kill(pid,signal.SIGCONT)
for _ in range(100):
    if not (Path('/proc')/str(pid)).exists():break
    time.sleep(.05)
old=(ROOT/'monitor.py').read_text()
(ROOT/'monitor_physical_wait.py').write_text(old)
new=old.replace("'DISPATCH_ONCE_CLAIM'","'DISPATCH_8LOGICAL_CLAIM'")
new=new.replace("'queue_resources.jsonl'","'queue_resources_8logical.jsonl'")
new=new.replace('if all(maximum[c]<=5 for c in items):','if any(maximum[c]<=5 for c in items):')
new=new.replace('cpus=sorted(min(v) for _,v in selected);','cpus=sorted(min(v,key=lambda c:(maximum[c],c)) for _,v in selected);')
new=new.replace('assigned_cpu=min(v)','assigned_cpu=min(v,key=lambda c:(maximum[c],c))')
new=new.replace('Exactly 8 assigned logical CPUs from 8 idle physical cores; affinity is not exclusive reservation. Fresh selection for each different map.',
                'Exactly 8 idle assigned logical CPUs from 8 distinct physical cores; SMT sibling threads may be busy. Affinity is not exclusive. Historical reference load differs.')
new=new.replace("selection_samples=3,selection_interval_seconds=2,run_sample_seconds=1,", "selection_samples=3,selection_interval_seconds=2,run_sample_seconds=1,sibling_cpu_idle_required=False,")
(ROOT/'monitor.py').write_text(new)
(ROOT/'ADMISSION_CHANGE.json').write_text(json.dumps(dict(status='BEFORE_ANY_MATCH',old_wait_monitor_pid=pid,
 new_physics_runs=0,algorithm_changes=False,reason='prior explicit user instruction: 8 idle CPUs suffice; no whole-server or sibling-idle wait',
 assigned_logical_cpus=8,distinct_physical_cores=8,sibling_idle_required=False,all_maps_unstarted=True),indent=2)+'\n')
print('Pre-match admission updated; no match has started or been retried.')
