"""Preserve failed zero-control fixture and resume only unstarted maps."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
p=ROOT/'Map06';archive=ROOT/'Map06_preflight_failed'
assert p.resolve().parent==ROOT.resolve() and not archive.exists()
assert not (p/'START.json').exists()
assert (p/'TIMING_ANCHORS.jsonl').stat().st_size==0
assert (p/'placement_events.jsonl').stat().st_size==0
assert not (p/'FINISH.json').exists()
assert json.loads((ROOT/'STATUS.json').read_text())['completed_maps']==['Map05']
(ROOT/'STATUS_before_recovery.json').write_bytes((ROOT/'STATUS.json').read_bytes())
p.rename(archive)
old=(ROOT/'monitor.py').read_text()
new=old.replace("maps=['Map05','Map06','Map07'];COUNT=8","maps=['Map06','Map07'];COUNT=8")
new=new.replace("'DISPATCH_8LOGICAL_CLAIM'","'DISPATCH_REMAINING_CLAIM'")
new=new.replace("'queue_resources_8logical.jsonl'","'queue_resources_remaining.jsonl'")
new=new.replace('completed=[];lock=None',"completed=['Map05'];lock=None")
new=new.replace("state='COMPLETE',maps=maps,seed=615", "state='COMPLETE',maps=['Map05','Map06','Map07'],seed=615")
(ROOT/'monitor_remaining.py').write_text(new)
fix=dict(status='ZERO_CONTROL_PREFLIGHT_FIX',map='Map06',physics_steps=0,control_calls=0,
         failed_fixture='expected NoComZone0, actual official Map06 NoComZone1',
         expected_zones={'NoGpsZone':0,'NoComZone':1},algorithm_changes=False,SDK_changes=False,
         completed_map_not_repeated='Map05',only_remaining_maps=['Map06','Map07'])
(ROOT/'PREFLIGHT_RECOVERY.json').write_text(json.dumps(fix,indent=2)+'\n')
print(json.dumps(fix))
