"""中文启动入口，完整实现见class_report.py。"""
from class_report import main

if __name__ == "__main__":
    raise SystemExit(main())
