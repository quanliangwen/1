"""运行：python -m unittest discover -s tests -v"""
import copy
import csv
import io
import json
import math
import subprocess
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import class_report as cr


def row(sid="001", score=80, subject="数学", name="同学甲", exam="01_期中", cls="一班"):
    return {"student_id":sid, "name":name, "class":cls, "exam":exam,
            "subject":subject, "score":score}


class ValidationTests(unittest.TestCase):
    def test_original_compatibility_and_immutability(self):
        rows=[{"class":"A","score":80},{"class":"B","score":None},
              {"class":"A","score":100},{"class":"B","score":60}]
        original=copy.deepcopy(rows)
        self.assertEqual(cr.report(rows), {"A":90,"B":60})
        cr.analyze(rows)
        self.assertEqual(rows, original)

    def test_missing_and_zero(self):
        for value in [None,"","缺考"," None ","NA","n/a","--"]:
            self.assertIsNone(cr.parse_score(value))
        self.assertEqual(cr.parse_score(0),0)
        self.assertEqual(cr.parse_score("100"),100)

    def test_invalid_scores(self):
        for value in [True, False, -1, 101, "nan", "inf", "-inf", "abc", [], {}, math.nan]:
            with self.subTest(value=value), self.assertRaises(cr.DataError):
                cr.parse_score(value)

    def test_aliases(self):
        clean,issues=cr.normalize_records([{"学号":"001","姓名":"甲","班级":"A","成绩":"90"}])
        self.assertFalse(issues)
        self.assertEqual(clean[0]["student_id"],"001")
        self.assertEqual(clean[0]["score"],90)

    def test_invalid_rows_and_duplicate(self):
        rows=[row(), row(), row("002",101), {"score":1}, {"class":"A"}, 7]
        clean,issues=cr.normalize_records(rows)
        self.assertEqual(len(clean),1)
        self.assertEqual(len(issues),5)
        self.assertEqual([x["row"] for x in issues],[2,3,4,5,6])

    def test_name_conflict_and_same_name_different_id(self):
        clean,issues=cr.normalize_records([row(), row(subject="语文",name="别人"), row("002")])
        self.assertEqual(len(clean),2)
        self.assertEqual(len(issues),1)

    def test_duplicate_aliases_and_overflow_columns(self):
        clean,issues=cr.normalize_records([{"class":"A","score":80,"成绩":90},
                                         {"class":"A","score":80,None:["extra"]}])
        self.assertFalse(clean)
        self.assertEqual(len(issues),2)

    def test_invalid_thresholds_and_weights(self):
        for p,e in [(90,60),(None,90),(-1,90),(60,101)]:
            with self.assertRaises(cr.DataError): cr.analyze([],p,e)
        for w in [0,-1,"bad",math.nan,True]:
            with self.assertRaises(cr.DataError): cr.analyze([],weights={"数学":w})


class StatisticsTests(unittest.TestCase):
    def test_empty(self):
        data=cr.analyze([])
        self.assertIsNone(data["overview"]["mean"])
        self.assertFalse(data["classes"])
        self.assertEqual(cr.report([]),{})
        self.assertIn("没有符合条件",cr.html_report(data))

    def test_all_absent_class_retained(self):
        data=cr.analyze([row(score=None)])
        self.assertEqual(len(data["classes"]),1)
        self.assertIsNone(data["classes"][0]["mean"])
        self.assertIsNone(data["classes"][0]["pass_rate"])
        self.assertIsNone(data["students"][0]["rank"])
        self.assertEqual(cr.report([row(score=None)]),{})

    def test_boundaries_median_stddev(self):
        s=cr.summarize([0,59,60,70,80,90,100,None])
        self.assertEqual(s["mean"],459/7)
        self.assertEqual(s["median"],70)
        self.assertEqual(s["pass_count"],5)
        self.assertEqual(s["excellent_count"],2)
        self.assertEqual(s["distribution"],{"90–100":2,"80–89.99":1,"70–79.99":1,"60–69.99":1,"0–59.99":2})
        self.assertEqual(cr.summarize([60])["stddev"],0)

    def test_competition_ranking_and_partial_exclusion(self):
        rows=[row("001",100),row("002",90),row("003",90),row("004",80),row("005",None)]
        students=cr.analyze(rows)["students"]
        self.assertEqual([s["rank"] for s in students],[1,2,2,4,None])

    def test_weighting(self):
        rows=[row(score=100),row(subject="语文",score=50)]
        s=cr.analyze(rows,weights={"数学":2})["students"][0]
        self.assertAlmostEqual(s["weighted_mean"],250/3)
        self.assertEqual(s["total"],150)
        self.assertEqual(s["rank"],1)

    def test_unrecorded_subject_excludes_rank(self):
        data=cr.analyze([row(),row(subject="语文"),row("002")])
        self.assertEqual(data["students"][1]["unrecorded_subjects"],["语文"])
        self.assertIsNone(data["students"][1]["rank"])
        self.assertEqual(data["classes"][0]["unrecorded_count"],1)
        self.assertEqual(sum(r["unrecorded_count"] for r in data["subjects"]),1)

    def test_exams_are_separate_and_progress(self):
        data=cr.analyze([row(score=60),row(score=90,exam="02_期末")])
        self.assertEqual(len(data["classes"]),2)
        self.assertEqual(data["students"][1]["change"],30)
        self.assertEqual([s["rank"] for s in data["students"]],[1,1])

    def test_progress_not_comparable(self):
        rows=[row(),row(exam="02_期末"),row(subject="语文",exam="02_期末")]
        self.assertIsNone(cr.analyze(rows)["students"][1]["change"])

    def test_custom_thresholds(self):
        s=cr.summarize([65,75,85],70,80)
        self.assertEqual(s["pass_count"],2)
        self.assertEqual(s["excellent_count"],1)


class StorageTests(unittest.TestCase):
    def test_crud_and_query_copy(self):
        book=cr.GradeBook([row()])
        book.add(row("002",name="同学乙"))
        self.assertEqual(len(book.search("乙")),1)
        found=book.search("001");found[0]["score"]=0
        self.assertEqual(book.records[0]["score"],80)
        book.update(("一班","01_期中","001","数学"),"90")
        self.assertEqual(book.records[0]["score"],90)
        book.delete(("一班","01_期中","002","数学"))
        self.assertEqual(len(book.records),1)

    def test_invalid_mutation_is_atomic(self):
        book=cr.GradeBook([row()]); old=book.records
        for operation in [lambda:book.add(row()),lambda:book.update(cr.record_key(row()),120),
                          lambda:book.delete(("bad",)*4),lambda:book.replace([row(),row("2",-1)])]:
            with self.assertRaises(cr.DataError):operation()
            self.assertEqual(book.records,old)

    def test_json_save_load_and_failed_write(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/"scores.json";book=cr.GradeBook([row()]);book.save(path)
            old=path.read_bytes()
            self.assertEqual(cr.GradeBook.load(path).records,book.records)
            with patch("class_report.os.replace",side_effect=OSError("disk failure")):
                with self.assertRaises(OSError):book.save(path)
            self.assertEqual(path.read_bytes(),old)
            self.assertFalse(list(path.parent.glob("*.tmp")))

    def test_csv_round_trip_and_formula_protection(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/"scores.csv"
            cr.write_csv(path,cr.FIELDS,[row(),row("002",None)])
            clean,issues=cr.normalize_records(cr.read_records(path))
            self.assertFalse(issues);self.assertEqual(clean[0]["student_id"],"001")
            self.assertIsNone(clean[1]["score"])
            cr.write_csv(path,["name"],[{"name":"=1+1"}])
            with path.open(encoding="utf-8-sig",newline="") as f:
                self.assertEqual(next(csv.DictReader(f))["name"],"'=1+1")

    def test_csv_duplicate_header_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'bad.csv'
            path.write_text('class,score,score\nA,80,90\n',encoding='utf-8')
            with self.assertRaises(cr.DataError):cr.read_records(path)

    def test_weights_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'input.json';out=Path(tmp)/'out';weights=Path(tmp)/'weights.json'
            path.write_text(json.dumps([row(score=100),row(subject='语文',score=50)]),encoding='utf-8')
            weights.write_text(json.dumps({'数学':2}),encoding='utf-8')
            with redirect_stdout(io.StringIO()):
                result=cr.main(['report','--input',str(path),'--out',str(out),'--weights-file',str(weights)])
            self.assertEqual(result,0)
            data=json.loads((out/'report.json').read_text('utf-8'))
            self.assertAlmostEqual(data['students'][0]['weighted_mean'],250/3)

    def test_exports_and_html_escape(self):
        with tempfile.TemporaryDirectory() as tmp:
            data=cr.analyze([row(name='<script>alert("x")</script>')])
            path=cr.export_report(data,tmp)
            text=path.read_text('utf-8')
            self.assertNotIn('<script>alert',text)
            self.assertIn('&lt;script&gt;',text)
            self.assertEqual(len(list(Path(tmp).iterdir())),8)
            self.assertEqual(json.loads((Path(tmp)/'report.json').read_text('utf-8'))['students'][0]['rank'],1)

    def test_menu_save_failure_rolls_back(self):
        book=cr.GradeBook([row()])
        with patch.object(cr.GradeBook,'load',return_value=book),patch.object(book,'save',side_effect=OSError('disk')):
            with patch('builtins.input',side_effect=['3','一班','01_期中','001','数学','90','0']),redirect_stdout(io.StringIO()):
                cr.menu('unused.json')
        self.assertEqual(book.records[0]['score'],80)

    def test_cli_strict_rejects_without_outputs(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'input.json';out=Path(tmp)/'out'
            path.write_text(json.dumps([row(),row()]),encoding='utf-8')
            result=subprocess.run([sys.executable,str(cr.BASE/'class_report.py'),'report','--input',str(path),'--out',str(out),'--strict'],capture_output=True)
            self.assertEqual(result.returncode,2)
            self.assertFalse(out.exists())

    def test_cli_protects_input_from_export_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'report.json';path.write_text(json.dumps([row()]),encoding='utf-8')
            original=path.read_bytes()
            result=subprocess.run([sys.executable,str(cr.BASE/'class_report.py'),'report','--input',str(path),'--out',tmp],capture_output=True)
            self.assertEqual(result.returncode,2)
            self.assertEqual(path.read_bytes(),original)


if __name__ == '__main__':
    unittest.main()
