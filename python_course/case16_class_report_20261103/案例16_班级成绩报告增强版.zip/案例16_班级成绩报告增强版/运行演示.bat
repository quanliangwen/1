@echo off
chcp 65001 >nul
cd /d "%~dp0"
python class_report.py demo
if errorlevel 1 (
  echo 运行失败，请检查Python 3.10或以上是否安装并加入PATH。
  pause
  exit /b 1
)
start "" "%~dp0输出\班级成绩报告.html"
pause
