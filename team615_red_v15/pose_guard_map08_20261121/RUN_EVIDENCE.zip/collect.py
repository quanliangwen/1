"""Collect exactly one new Map08 run and compare with two sealed prior runs."""
from hashlib import sha256
from pathlib import Path, PurePosixPath
from zipfile import ZipFile, ZIP_DEFLATED
import json
import math
import subprocess
import numpy as np

root=Path(__file__).resolve().parent
old=root.parent/'team615_messenger_batch1_20261121'
guard=root.parent/'team615_messenger_pose_guard_20261121'
received=root/'received'
delivery=root/'delivery'
remote='/home/quanliangwen/isolated_test/team615_pose_guard_map08_EqeDum'
host='quanliangwen@10.112.162.60'
sdk='6557940dc18549ffc7a945db887da5b05b7ed2f1'

def read(p):
    return json.loads(p.read_bytes())

def digest(p):
    return sha256(p.read_bytes()).hexdigest()

def download(paths,folder):
    folder.mkdir(exist_ok=True,parents=True)
    subprocess.run(['scp','-q','-o','BatchMode=yes',*(f'{host}:{p}' for p in paths),str(folder)],check=True)

def verify(folder,expected_hash,expected_files):
    start,end,source,score=(read(folder/f'{name}.json') for name in ('START','FINISH','SOURCE_MATCH','OFFICIAL_SCORE'))
    assert [start[k] for k in ['seed','sdk','sdk_archive_sha256','map_name','drones','bombs_per_drone','timestep_limit','walltime_limit','competition_mode']]==[
        615,sdk,'9155bc4cdf5e0813cd328d3a56c3b73633ba351c3859e694762ed41376fc6860','Map08',5,2,5400,180,True]
    assert start['spawn']==read(root/'matched_spawns.json')['Map08']
    assert start['zones']==read(root/'EXPECTED_ZONES.json')['Map08']
    assert source['candidate_zip_sha256']==expected_hash
    assert start['solutions_sha256']==source['candidate']==expected_files
    assert [end[k] for k in ['status','completed_red_rounds','blue_rounds','layout_evaluations']]==['COMPLETE',1,0,0]
    assert digest(folder/'placement_events.jsonl')==score['placement_events_sha256']
    assert digest(folder/'wall_geometry.npz')==score['wall_geometry_sha256']
    for name,sha in end['files'].items():
        assert digest(folder/'official'/name)==sha
    assert math.isclose(score['partial'],.5*score['map_score']+.2*score['coverage']+.1*score['time_score'],abs_tol=1e-8)
    events=[json.loads(line) for line in (folder/'placement_events.jsonl').read_bytes().splitlines()]
    drops=[e for e in events if e['event']=='sdk_placement' and e['accepted']]
    assert len(drops)==score['placed']
    layout=read(next((folder/'official').glob('*bombs.json')))['bombs']
    assert len(layout)==score['placed']
    selected=score['selected_submission']
    if selected and selected.get('drone') is not None:
        assert selected['image_sha256']==score['selected_image_sha256']
    audit=next(d for d in score['drone_details'] if d['drone']==4)['messenger_audit']
    acks=[a for a in audit if a[1]=='payload_ack']
    to0=[a for a in acks if a[2]==0]
    full=[a for a in to0 if set(a[5])==set(range(5))]
    if expected_hash!='c3021a3eb48031e82bfac9306654b48ca09f168d6f65b13349cf12f783104c7c':
        for i,a in enumerate(audit):
            if a[1]=='exchange_complete':
                assert audit[i-1][:3]==[a[0],'payload_ack',a[2]]
    b=score['map_breakdown']
    return dict(source_zip_sha256=expected_hash,map_score=score['map_score'],
        partial_score_out_of_80=score['partial'],wall_score=score['coverage'],time_score=score['time_score'],
        wall_surface_pixels=b['wall_pixels'],wall_hits=b['wall_hits'],missed_wall_pixels=b['wall_pixels']-b['wall_hits'],
        charged_misdraw_pixels=b['charged_pixels'],misdraw_total_charge=b['total_charge'],misdraw_penalty=b['penalty'],
        predicted_wall_pixels=b['predicted_pixels'],map_breakdown=b,
        exploration_percent=score['trajectory'],first_payload_ack_step=acks[0][0] if acks else None,
        first_payload_ack_to0_step=to0[0][0] if to0 else None,
        first_all_empty_payload_ack_to0_step=full[0][0] if full else None,
        legacy_unverified_exchange_to0_steps=[a[0] for a in audit if a[1]=='exchange_complete' and a[2]==0] if not acks else [],
        selected_submission=score['selected_submission'],submission_step=score['steps'],
        placed=score['placed'],total_health_lost=sum(25-d['health'] for d in score['drone_details']),
        final_health={d['drone']:d['health'] for d in score['drone_details']},
        elapsed_walltime_seconds=score['elapsed_walltime'],observed_placement_events=drops,
        official_bomb_layout=layout,
        last_drop_step=max((e['step'] for e in drops),default=None),messenger_audit=audit,
        active_messenger_refresh_steps=[e['step'] for e in events if e['event']=='messenger_map_refresh' and e['state']=='ACTIVE'],
        deadline_events={d['drone']:d['walltime_submission'] for d in score['drone_details']})

if __name__=='__main__':
    build=read(root/'CANDIDATE_BUILD.json')
    assert digest(root/'candidate_snapshot.zip')==build['candidate_zip_sha256']=='2cbd4b56519659a13b38e75fa85eb689c2a5c2bdefc74d447ecc9b2fcb6a7e0e'
    assert digest(guard/'candidate.zip')==build['candidate_zip_sha256']
    assert all(digest(guard/'candidate'/n)==sha for n,sha in build['candidate_files'].items())
    assert digest(root/'stage_run.py')==digest(old/'stage_run.py')
    names=['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','placement_events.jsonl','run.log','dispatch.log','wall_geometry.npz']
    download([f'{remote}/{n}' for n in names],received)
    end=read(received/'FINISH.json')
    result=PurePosixPath(end['result_dir'])
    assert result.is_relative_to(PurePosixPath(remote)/'official_sdk/results_swarm_rescue')
    for name in end['files']:
        file=PurePosixPath(name)
        assert not file.is_absolute() and '..' not in file.parts
        download([str(result/file)],received/'official'/file.parent)
    lines=(received/'dispatch.log').read_text(encoding='utf-8').splitlines()
    assert sum(x=='START Map08 pose_guard seed615' for x in lines)==1
    assert sum(x=='COMPLETE Map08 pose_guard seed615' for x in lines)==1
    original_binding=read(old/'baseline_binding.json')
    first_binding=read(old/'candidate_binding.json')
    receipt=read(old/'REMOTE_VERIFIED.json')
    assert digest(old/'delivery/RESULTS.json')==receipt['results_sha256']
    history=read(old/'delivery/RESULTS.json')['scores']['Map08']
    rounds={
        'original':verify(old/'received/Map08_baseline',original_binding['candidate_zip_sha256'],original_binding['candidate']),
        'batch1':verify(old/'received/Map08_candidate',first_binding['candidate_zip_sha256'],first_binding['candidate']),
        'pose_guard':verify(received,build['candidate_zip_sha256'],build['candidate_files'])}
    for arm,oldkey in [('original','baseline'),('batch1','candidate')]:
        assert rounds[arm]['map_score']==history[oldkey]['map_score']
        assert rounds[arm]['partial_score_out_of_80']==history[oldkey]['partial_score_out_of_80']
    assert rounds['original']['wall_surface_pixels']==rounds['batch1']['wall_surface_pixels']==rounds['pose_guard']['wall_surface_pixels']==96652
    fields=['missed_wall_pixels','charged_misdraw_pixels','map_score','partial_score_out_of_80','exploration_percent','submission_step','placed','total_health_lost','elapsed_walltime_seconds','misdraw_penalty','wall_score','time_score']
    deltas={a:{k:rounds['pose_guard'][k]-rounds[a][k] for k in fields} for a in ['original','batch1']}
    prior_npz=np.load(next((old/'received/Map08_candidate/official/recordings').glob('*.npz')))
    new_npz=np.load(next((received/'official/recordings').glob('*.npz')))
    trajectory=dict(drone_state_arrays_identical=bool(np.array_equal(prior_npz['drone_states'],new_npz['drone_states'])),
                    bomb_state_arrays_identical=bool(np.array_equal(prior_npz['bomb_states'],new_npz['bomb_states'])),
                    recorded_frames=int(len(new_npz['timestamps'])),
                    walltime_delta_at_frame_2160=float(new_npz['timestamps'][2160]-prior_npz['timestamps'][2160]),
                    walltime_delta_at_frame_2488=float(new_npz['timestamps'][2488]-prior_npz['timestamps'][2488]))
    result=dict(seed=615,map_name='Map08',sdk=sdk,new_red_rounds=1,historical_red_rounds=2,blue_rounds=0,
                source_changed_in_this_task=False,new_candidate_build=build,
                runs=rounds,pose_guard_minus= deltas,
                placements_identical={a:rounds['pose_guard']['official_bomb_layout']==rounds[a]['official_bomb_layout'] for a in ['original','batch1']},
                raw_placement_event_logs_identical={a:rounds['pose_guard']['observed_placement_events']==rounds[a]['observed_placement_events'] for a in ['original','batch1']},
                recorded_trajectory_comparison_to_batch1=trajectory,
                definitions=dict(missed_wall_pixels='truth wall surface pixels not hit by submission',
                    charged_misdraw_pixels='predicted pixels farther than 10px from any truth wall',
                    payload_ack='fresh direct peer receipt acknowledging outbound map version and pinned empty inventory IDs',
                    elapsed_walltime_seconds='SDK round elapsed including post-submission cleanup'))
    delivery.mkdir(exist_ok=True)
    (delivery/'RESULTS.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    with ZipFile(delivery/'RUN_EVIDENCE.zip','w',compression=ZIP_DEFLATED) as z:
        for p in sorted(received.rglob('*')):
            if p.is_file():z.write(p,'new_pose_guard/'+p.relative_to(received).as_posix())
        for a,folder in [('original',old/'received/Map08_baseline'),('batch1',old/'received/Map08_candidate')]:
            for p in sorted(folder.rglob('*')):
                if p.is_file():z.write(p,'historical_'+a+'/'+p.relative_to(folder).as_posix())
        for name in ['stage_run.py','run_once.sh','collect.py','report.py','CANDIDATE_BUILD.json','UNIT_VALIDATION.json','DECLARED_SOURCE.json','PATCH_BINDING.json','OFFLINE_CHECK.json','place_map08.yml','matched_spawns.json','EXPECTED_ZONES.json']:
            z.write(root/name,name)
    with ZipFile(delivery/'RUN_EVIDENCE.zip') as z:assert z.testzip() is None
    (delivery/'CHECKSUMS_SHA256.json').write_text(json.dumps({p.name:digest(p) for p in delivery.iterdir() if p.name!='CHECKSUMS_SHA256.json'},indent=2)+'\n')
    print(json.dumps({a:{k:r[k] for k in fields+['first_payload_ack_to0_step','first_all_empty_payload_ack_to0_step','selected_submission']} for a,r in rounds.items()},indent=2))
    print(json.dumps(deltas,indent=2))
