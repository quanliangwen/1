from pathlib import Path
from hashlib import sha256
import json

root=Path(__file__).resolve().parent
delivery=root/'delivery'
r=json.loads((delivery/'RESULTS.json').read_bytes())
runs=r['runs']
labels={'original':'原版（已有结果）','batch1':'第一批候选（已有结果）','pose_guard':'定位可靠性候选（本次唯一新增一局）'}
rows=[
    ('漏墙像素','missed_wall_pixels',False),('被扣分的误画像素','charged_misdraw_pixels',False),
    ('地图得分，百分制','map_score',True),('红队已测得分，满分80','partial_score_out_of_80',True),
    ('探索率，百分比','exploration_percent',True),('交图步数','submission_step',False),
    ('实投数','placed',False),('五机总掉血','total_health_lost',False),
    ('整局墙钟，秒','elapsed_walltime_seconds',True),('误画惩罚项','misdraw_penalty',True),
    ('画墙像素总数','predicted_wall_pixels',False)]
text=['Map08 种子615 定位可靠性候选单局对照','',
      '本次仅新增运行定位可靠性候选一局。原版与第一批候选采用先前相同SDK、种子和出生点的已核验记录，没有重复运行两版。',
      '候选源码未改，仍是上一轮通过19组反例的版本；也未开展第二批修改。',
      'SDK 6557940dc18549ffc7a945db887da5b05b7ed2f1，5机各2枚，5400步、180秒。评测脚本与前两版字节相同，使用共享串行评测锁。',
      '', '指标\t原版\t第一批候选\t定位可靠性候选']
for label,key,decimal in rows:
    vals=[f'{runs[a][key]:.4f}' if decimal else str(runs[a][key]) for a in labels]
    text.append(label+'\t'+'\t'.join(vals))
text += ['交图机号\t'+'\t'.join(str(runs[a]['selected_submission']['drone']) for a in labels),
         '首次向0号机实际载荷确认步数\t'+'\t'.join(str(runs[a]['first_payload_ack_to0_step']) if runs[a]['first_payload_ack_to0_step'] is not None else '未记录真实双向回执' for a in labels),
         '首次向0号机确认全队清零步数\t'+'\t'.join(str(runs[a]['first_all_empty_payload_ack_to0_step']) if runs[a]['first_all_empty_payload_ack_to0_step'] is not None else '未记录全队清零双向回执' for a in labels),
         '', '口径',
         '漏墙为96652个可计分真实墙面像素中，提交图未命中的数量。误画为距任何真实墙超过10px容差、受到扣分的预测像素。误画惩罚还与距离有关，因此同时保留惩罚项与total_charge。',
         '探索率为真实航迹区域探索率，与提交地图质量分别计量。掉血为五机初始总血125减最终总血。墙钟是SDK整局elapsed_walltime，含提交后的收尾。',
         '原版没有真正的双向收包确认机制；旧日志exchange_complete记为'+str(runs['original']['legacy_unverified_exchange_to0_steps'])+'，不能与新版本payload_ack等同。',
         '仅测红队80分部分，另20分蓝队布局难度未测。交图机为最终计分选中的提交者。',
         '', '本次候选相对两版的变化（正数表示增加）']
for a in ['original','batch1']:
    d=r['pose_guard_minus'][a]
    text.append(labels[a]+f"：漏墙{d['missed_wall_pixels']:+d}像素，误画{d['charged_misdraw_pixels']:+d}像素，地图得分{d['map_score']:+.4f}，红队已测得分{d['partial_score_out_of_80']:+.4f}，探索率{d['exploration_percent']:+.4f}个百分点，总掉血{d['total_health_lost']:+d}，墙钟{d['elapsed_walltime_seconds']:+.2f}秒。")
text += ['', '实际投放一致性', '以官方炸弹文件核对最终落点：'+str(r['placements_identical']),
         '投放钩子日志存在一步及坐标差异；与官方炸弹布局、录制状态交叉核对后，不将这些钩子字段当作真实航迹差异。',
         '', '录制轨迹与墙钟拆分',json.dumps(r['recorded_trajectory_comparison_to_batch1'],ensure_ascii=False),
         '新候选与第一批保存的3443帧无人机及炸弹状态逐帧一致。本次在帧2160处（信使启动前）已慢约17.23秒，不能将整局多31.42秒全部归因于保护墙点的复制开销。',
         '', '本次结果解释',
         '相对第一批：误画减少2367像素，漏墙只减少78像素，地图得分提高0.4558分；回收约6.37%的原有地图退分。主要是减轻一部分误画，主要漏墙仍在。',
         '相对原版：仍多漏5628个墙面像素、多8453个扣分误画像素，地图得分低6.6986分。本局不足以支持替换原版或宣称整场综合改善。',
         '', '信使实际载荷确认日志']
for a in labels:
    ack=[e for e in runs[a]['messenger_audit'] if e[1]=='payload_ack']
    text.append(labels[a]+'：'+json.dumps(ack,ensure_ascii=False))
text += ['', '数据边界',
         '固定种子单次结果只能说明这次Map08的观测结果；墙钟受运行负载影响。未以历史分数冒充新跑分，也没有运行其他地图或第二轮复测。',
         '该改动限制4号机ACTIVE期间新增的低可信墙和方向证据，不清理旧错点，不改变其他机号的观测规则。是否能推广到其他种子和地图，本次没有验证。',
         '', '候选内部测试ZIP SHA256 '+r['new_candidate_build']['candidate_zip_sha256'],
         '源码变化与上次交付一致：仅red_hooks.py相对第一批候选改变，其余52文件逐字节一致。',
         'RUN_EVIDENCE.zip包含本局与两局历史对照的官方结果、图像、轨迹、来源绑定和逐次投放/信使日志；RESULTS.json保留未四舍五入的结果。']
(delivery/'RESULT.txt').write_text('\n\n'.join(text)+'\n',encoding='utf-8',newline='\n')
manifest={p.name:sha256(p.read_bytes()).hexdigest() for p in delivery.iterdir() if p.name!='CHECKSUMS_SHA256.json'}
(delivery/'CHECKSUMS_SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Report and checksums generated.')
