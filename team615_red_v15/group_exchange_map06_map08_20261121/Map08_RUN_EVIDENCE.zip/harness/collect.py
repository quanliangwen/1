from pathlib import Path,PurePosixPath
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import argparse,json,math,subprocess
import numpy as np

r=Path(__file__).resolve().parent
host='quanliangwen@10.112.162.60'
remote=(r/'SERVER_STAGE.txt').read_text(encoding='utf-8').strip()
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
parser=argparse.ArgumentParser();parser.add_argument('map',choices=['Map06','Map08']);args=parser.parse_args()
name=args.map;folder=r/name;received=folder/'received';received.mkdir(exist_ok=True)
old=r.parent/'team615_messenger_batch1_20261121/received'/f'{name}_baseline'

def download(paths,dest):
    dest.mkdir(parents=True,exist_ok=True)
    subprocess.run(['scp','-q','-o','BatchMode=yes',*[f'{host}:{p}' for p in paths],str(dest)],check=True)

files=['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','placement_events.jsonl',
       'run.log','dispatch.log','wall_geometry.npz']
download([f'{remote}/{name}/{f}' for f in files],received)
end=read(received/'FINISH.json');official=PurePosixPath(end['result_dir'])
assert official.is_relative_to(PurePosixPath(remote)/name/'official_sdk/results_swarm_rescue')
for n,d in end['files'].items():
    p=PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts
    download([str(official/p)],received/'official'/p.parent)
    assert h(received/'official'/n)==d
b=read(folder/'BUILD.json');start=read(received/'START.json');s=read(received/'OFFICIAL_SCORE.json')
assert h(folder/'candidate_snapshot.zip')==b['candidate_zip_sha256']=='641685d7bd460f6241abb4e2c0f02527d7324a37d78f6492401d66a4b6a63cda'
assert start['solutions_sha256']==read(received/'SOURCE_MATCH.json')['candidate']==b['candidate_files']
assert [start[k] for k in ['seed','sdk','map_name','drones','bombs_per_drone','timestep_limit','walltime_limit','competition_mode']]==[
    615,'6557940dc18549ffc7a945db887da5b05b7ed2f1',name,5,2,5400,180,True]
assert start['spawn']==read(folder/'matched_spawns.json')[name]
assert start['zones']==read(folder/'EXPECTED_ZONES.json')[name]
assert [end[k] for k in ['status','completed_red_rounds','blue_rounds','layout_evaluations']]==['COMPLETE',1,0,0]
assert h(received/'placement_events.jsonl')==s['placement_events_sha256']
assert h(received/'wall_geometry.npz')==s['wall_geometry_sha256']
log=(received/'dispatch.log').read_text(encoding='utf-8')
assert log.count(f'START {name} group_exchange seed615')==log.count(f'COMPLETE {name} group_exchange seed615')==1

def verify_old():
    a,e,score=read(old/'START.json'),read(old/'FINISH.json'),read(old/'OFFICIAL_SCORE.json')
    assert a['solutions_sha256']==b['original_files'] and a['seed']==615 and a['map_name']==name
    assert a['sdk']==start['sdk'] and a['sdk_archive_sha256']==start['sdk_archive_sha256']
    assert a['spawn']==start['spawn'] and a['zones']==start['zones']
    assert h(old/'placement_events.jsonl')==score['placement_events_sha256']
    for n,d in e['files'].items():assert h(old/'official'/n)==d
    return score

def summary(score,folder):
    m=score['map_breakdown']
    assert math.isclose(score['partial'],.5*score['map_score']+.2*score['coverage']+.1*score['time_score'],abs_tol=1e-8)
    layout=read(next((folder/'official').glob('*bombs.json')))['bombs']
    assert len(layout)==score['placed']
    chosen=score['selected_submission']
    if chosen and chosen.get('drone') is not None:assert chosen['image_sha256']==score['selected_image_sha256']
    return dict(map_score=score['map_score'],partial_score_out_of_80=score['partial'],wall_score=score['coverage'],
        time_score=score['time_score'],exploration_percent=score['trajectory'],
        missed_wall_pixels=m['wall_pixels']-m['wall_hits'],charged_misdraw_pixels=m['charged_pixels'],
        map_breakdown=m,submission_step=score['steps'],selected_submission=chosen,placed=score['placed'],
        total_health_lost=sum(25-d['health'] for d in score['drone_details']),
        elapsed_walltime_seconds=score['elapsed_walltime'],
        per_drone_last_confirmation={str(d['drone']):d['last_confirmation'] for d in score['drone_details']},
        per_drone_health={str(d['drone']):d['health'] for d in score['drone_details']},
        deadline_events={str(d['drone']):d['walltime_submission'] for d in score['drone_details']})

o,c=summary(verify_old(),old),summary(s,received)
fields=['partial_score_out_of_80','map_score','wall_score','time_score','exploration_percent',
        'missed_wall_pixels','charged_misdraw_pixels','submission_step','placed','total_health_lost','elapsed_walltime_seconds']
delta={k:c[k]-o[k] for k in fields};prefix={}
az=np.load(next((old/'official/recordings').glob('*.npz')))
cz=np.load(next((received/'official/recordings').glob('*.npz')))
for key in ['drone_states','bomb_states']:
    a,v=az[key],cz[key];n=min(len(a),len(v));equal=np.ones(n,bool)
    for field in a.dtype.names:equal&=(a[field][:n]==v[field][:n]).reshape(n,-1).all(1)
    w=np.flatnonzero(~equal)
    prefix[key]=dict(original_frames=len(a),candidate_frames=len(v),first_different_frame=None if not w.size else int(w[0]),
                     first_3237_frames_equal=bool(equal[:min(n,3237)].all()))

groups={}
for row in s['drone_details']:
    owner=str(row['drone']);g={k:v for k,v in row.items() if k.startswith('group_') and k!='group_final_trail'}
    g.update(final_inventory_records=row['final_inventory_records'],
        navigation_return_tasks=sum(v[1]=='return_owned' for v in row['group_audit']),
        abort_events=[v for v in row['group_audit'] if v[1]=='route_abort'],
        stored_payloads=[v for v in row['group_candidate_audit'] if v[1]=='payload_stored'],
        snapshot_owners=[v[1] for v in row['group_manifest'] if v[0]=='snapshot'],
        image_owners=[v[1] for v in row['group_manifest'] if v[0]=='image'])
    groups[owner]=g
result=dict(status='COMPLETE',map=name,seed=615,new_red_rounds=1,historical_original_rounds=1,blue_rounds=0,
    original=o,candidate=c,candidate_minus_original=delta,recorded_prefix=prefix,group_details=groups,
    candidate_zip_sha256=b['candidate_zip_sha256'],candidate_source_identical_to_map09=True,
    controller_changed=False,source_frozen_during_match=True,
    score_contribution_changes=dict(map=.5*delta['map_score'],wall=.2*delta['wall_score'],time=.1*delta['time_score']))
assert abs(sum(result['score_contribution_changes'].values())-delta['partial_score_out_of_80'])<1e-8
(folder/'RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with ZipFile(folder/'RUN_EVIDENCE.zip','w',ZIP_DEFLATED) as z:
    for p in sorted(received.rglob('*')):
        if p.is_file():z.write(p,'candidate/'+p.relative_to(received).as_posix())
    for n in ['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','placement_events.jsonl','wall_geometry.npz']:
        z.write(old/n,'historical_original/'+n)
    for p in sorted((old/'official/recordings').glob('*.npz')):z.write(p,'historical_original/official/recordings/'+p.name)
    for n in ['BUILD.json','VALIDATION.json','counterexamples.json','stage_run.py','run_once.sh','OFFLINE_CHECK.json',
              'DECLARED_SOURCE.json','PATCH_BINDING.json','OBSERVATION_BINDING.json','place_map09.yml','matched_spawns.json','EXPECTED_ZONES.json']:
        z.write(folder/n,'harness/'+n)
    z.write(r/'collect.py','harness/collect.py')
print(json.dumps(dict(map=name,original=o,candidate=c,delta=delta,prefix=prefix,
    groups={i:{k:g[k] for k in ['group_root','group_root_acks','group_branch','group_started','group_phase',
        'snapshot_owners','image_owners','abort_events','stored_payloads','group_choice']} for i,g in groups.items()}),indent=2))
