from pathlib import Path
r=Path(__file__).resolve().parent
s=(r.parent/'team615_neartie_slots_20261121/counterexamples.py').read_text(encoding='utf-8')
needle='    d=Flight(owner);g=d.group_exchange;p=g.plan\n'
assert s.count(needle)==1
# Existing 89 groups exercise the unchanged eligible/two-snapshot path. Supply
# real valid packets, rather than bypassing the new production guard.
insert="""    d.final_maps.freeze(3200,d.memory)
    peer=(owner+1)%5
    d.final_maps.snapshots[peer]=(peer,3200,True,d.memory.packet())
"""
s=s.replace(needle,needle+insert)
def change(fn,old,new):
    global s
    start=s.index('def '+fn+'(');end=s.index('\ncheck(',start);part=s[start:end]
    assert old in part,(fn,old)
    s=s[:start]+part.replace(old,new)+s[end:]
change('historical_bid_yield',"d0.map_bids[1]=(3300,1500,True)","d0.map_bids[1]=(3300,4700,True)")
change('historical_bid_yield',"(3300,1500,1200)","(3300,4700,4400)")
change('recheck_bid_before_submit',"(3448,1500,True)","(3448,4700,True)")
change('bounded_bid_wait',"(step,1500,False)","(step,4700,False)")
position=s.index("result=dict(status='PASS'")
s=s[:position]+(r/'extra_tests.py').read_text(encoding='utf-8')+'\n'+s[position:]
compile(s,'counterexamples.py','exec');(r/'counterexamples.py').write_text(s,encoding='utf-8')
print('89 inherited groups use valid two-final-snapshot fixtures; new groups cover zero/one/two-source boundaries without mocked guards.')
