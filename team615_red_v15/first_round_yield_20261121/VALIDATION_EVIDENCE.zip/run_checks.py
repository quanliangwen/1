from pathlib import Path
from hashlib import sha256
import json,subprocess
r=Path(__file__).resolve().parent
source=r.parent/'team615_neartie_maps_20261121/Map08/received/OFFICIAL_SCORE.json'
raw=source.read_bytes();score=json.loads(raw)
context=dict(scope='Existing frozen near-tie/slot Map08 seed615 logs only; final snapshot count inferred from unchanged rank formula.',
    official_score_json_sha256=sha256(raw).hexdigest(),drones={})
for d in score['drone_details']:
    if not d['original_own_sent_bids']:continue
    bid=d['original_own_sent_bids'][-1];q=d['original_map_quality'];residual=bid[1]-q*1500//10000
    assert residual%1600==0
    context['drones'][str(d['drone'])]=dict(bid=bid,map_quality=q,inferred_final_snapshot_count=residual//1600)
(r/'MAP08_BID_CONTEXT.json').write_text(json.dumps(context,indent=2)+'\n')
subprocess.run(['python',str(r/'prepare_tests.py')],check=True)
remote=(r/'SERVER_STAGE.txt').read_text().strip();host='quanliangwen@10.112.162.60'
for n in ['candidate_snapshot.zip','BUILD.json','counterexamples.py','validate.py','MAP08_SAVED_TABLES.json','MAP08_BID_CONTEXT.json']:
    subprocess.run(['scp','-q','-o','BatchMode=yes',str(r/n),f'{host}:{remote}/'],check=True)
sdk='/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/P407_P398_semifinal_three_maps_20261110/official_sdk'
py='/home/junhao/quan/parallel_test_solver/match/.venv/bin/python'
command=f'cd {remote} && PYTHONPATH={sdk}/src PYGLET_HEADLESS=true PYTHONDONTWRITEBYTECODE=1 {py} -B counterexamples.py candidate_snapshot.zip candidate --output counterexamples.json > counterexamples.log 2>&1'
run=subprocess.run(['ssh','-o','BatchMode=yes',host,command],capture_output=True)
subprocess.run(['scp','-q','-o','BatchMode=yes',f'{host}:{remote}/counterexamples.log',str(r/'counterexamples.log')],check=True)
print((r/'counterexamples.log').read_text(encoding='utf-8')[-11000:])
if run.returncode:raise SystemExit(run.returncode)
command=f'cd {remote} && PYTHONPATH={sdk}/src PYGLET_HEADLESS=true PYTHONDONTWRITEBYTECODE=1 {py} -B validate.py > validation.log 2>&1'
run=subprocess.run(['ssh','-o','BatchMode=yes',host,command],capture_output=True)
for name in ['counterexamples.json','VALIDATION.json','validation.log','static_candidate.log']:
    subprocess.run(['scp','-q','-o','BatchMode=yes',f'{host}:{remote}/{name}',str(r/name)],check=True)
print((r/'validation.log').read_text(encoding='utf-8')[-2500:])
if run.returncode:raise SystemExit(run.returncode)
