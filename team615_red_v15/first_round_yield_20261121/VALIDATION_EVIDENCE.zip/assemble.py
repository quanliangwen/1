from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json,shutil
r=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
b=read(r/'BUILD.json');v=read(r/'VALIDATION.json');c=read(r/'counterexamples.json')
assert b['status']==v['status']==c['status']=='PASS'
assert c['scenario_groups']==107 and v['candidate_scenario_groups']==107
assert h(r/'candidate_snapshot.zip')==b['candidate_zip_sha256']==c['archive_sha256']==v['candidate_zip_sha256']
assert c['physics_steps']==c['physics_step_attempts']==c['map_objects_created']==c['full_matches']==0
assert b['changed_existing_files']==['group_exchange.py'] and b['unchanged_files']==55
assert b['baseline_zip_sha256']=='f2c1059afc5218bd19cea9995679492b8c2211fd2eae42d0f77caa9abbbab318'
d=r/'delivery';d.mkdir(exist_ok=True)
config=dict(min_final_snapshots=2,threshold_store='drone.final_maps.snapshots',first_round_start='existing finish_floor(drone)',
    first_round_end='finish_floor(drone) + team_size * SUBMISSION_SLOT_STEPS',interval='[start,end)',
    example_limit=5400,example_start=3444,example_end=3474,example_window_steps=30,
    fixed_absolute_window=True,no_new_timer_or_retry_counter=True,no_bid_forwarding=True,
    release_as_soon_as_final_snapshots_reach_two=True,skip_when_wall_seconds_left_less_than=12,
    skip_at_existing_deadline_window=True,ordinary_and_legacy_fast_exits_share_guard=True,
    rendering_and_cache_update_before_new_guard=True,near_tie_and_six_step_slots_unchanged=True,
    placement_stock_and_pending_veto_unchanged=True,hard_wall_and_timestep_fallbacks_unchanged=True,
    navigation_and_fitting_unchanged=True)
results=dict(status='COUNTEREXAMPLES_AND_STATIC_PASS',configuration=config,build=b,validation=v,counterexamples=c,
    synthetic_examples=dict(scope='Unit control calls with synthetic sensors and saved historical bid grades; no arena or match run.',
        one_final_zero_yields_and_two_final_one_submits_at=3452,
        two_final_preferred_ID_earliest_submissions={'0':3448,'1':3452,'2':3458,'3':3464,'4':3470},
        all_under_two=dict(yield_ends=3474,synthetic_zero_submit=3476),
        second_final_arrives_at_3446=dict(released_immediately=True,synthetic_zero_submit=3448),
        late_ready_one_at_3478=dict(new_grace_started=False,synthetic_one_submit=3482)),
    simulation=dict(full_matches=0,physics_steps=0,physics_step_attempts=0,map_objects_created=0),
    actual_map08_score=None,actual_map09_score=None,actual_map08_submission_step=None,actual_map09_submission_step=None,
    limitations=['No new full simulation, trajectory replay or official online submission.',
        'Final snapshot count is an existing evidence proxy, not guaranteed official map quality.',
        '107 scenario groups comprise 89 inherited cases supplied with two valid final snapshots and 18 new low-count/boundary groups.',
        'Three inherited synthetic bid cases are shifted by 3200 to preserve their relative rank after adding two fixture snapshots.',
        'Some inherited protocol cases use the previous shortened 3300 floor; new first-round cases use genuine 5400/3444 timing.',
        'Synthetic 3452 submission does not prove that actual Map08 will end with drone1 or score 77.1892.',
        'Hard fallbacks retain priority and can still produce simultaneous emergency submissions.'])
(d/'RESULTS.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for n in ['BUILD.json','VALIDATION.json','counterexamples.json','counterexamples.py','first_round_yield.patch','MAP08_BID_CONTEXT.json','MAP08_SAVED_TABLES.json']:
    shutil.copyfile(r/n,d/n)
shutil.copyfile(r/'candidate/group_exchange.py',d/'group_exchange.py')
shutil.copyfile(r/'candidate_snapshot.zip',d/'CANDIDATE_SOURCE.zip')
with ZipFile(d/'VALIDATION_EVIDENCE.zip','w',ZIP_DEFLATED) as z:
    for n in ['BUILD.json','VALIDATION.json','counterexamples.json','counterexamples.log','validation.log','static_candidate.log',
        'counterexamples.py','extra_tests.py','prepare_tests.py','run_checks.py','validate.py','build.py','assemble.py',
        'MAP08_BID_CONTEXT.json','MAP08_SAVED_TABLES.json','baseline_snapshot.zip','first_round_yield.patch','SERVER_STAGE.txt']:
        z.write(r/n,n)
    assert z.testzip() is None
readme=f'''# 最终快照不足2份时让出首轮30步

已按授权在当前近分＋6步时间槽候选上完成最小修改：只加普通交图首轮让行，不做竞价转发。107组反例、官方静态内容检查与数值环境检查PASS；没有运行完整比赛、没有创建地图或执行物理步，也没有新的Map08/Map09成绩。

基线SHA256：`{b['baseline_zip_sha256']}`

候选SHA256：`{b['candidate_zip_sha256']}`

## 实现与边界

56个成员，只改`group_exchange.py`，其余55个文件字节一致。

新增`yield_first_round(drone, step)`，条件是：

1. 使用`drone.final_maps.snapshots`计数，少于2份才让行。分组候选池的快照数不替代它。
2. 时间区间为原`finish_floor`到`finish_floor + team_size × 6`，左闭右开。当前5机/5400步配置为3444～3473步，3474步解除新增让行。
3. 墙钟剩余不足12秒，或已进入原最后截止窗口时，不新增让行。恰好12秒仍按普通首轮规则执行。
4. 第二份最终快照到达后立即不再受此规则限制，仍须遵守实投确认、原有竞价和本机6步时隙。

只在两个现有函数各增加一次检查：

- `try_submit()`：放在原缓存比较、库存/pending检查、原有窗口、0.003最终选图和ready更新之后，发提案/普通提交之前。
- `ordinary_submit_allowed()`：让旧普通交图、ABORT后的出口和FastCloseout也服从相同规则。

没有新增本地计时器或重试状态。重复广播、新比较、晚到的普通交图资格都不会把30步重新启动。此规则只延后结束比赛，现有扫描、导航和缓存仍照常执行。

移除新增的两行调用后，两个旧函数的AST可完整还原基线；GroupExchange其余所有旧方法AST相同。`map_candidates.py`、`red_hooks.py`、FinalMaps、竞价、投放复核、双时限、导航与拟合代码均未修改。消息结构和收发实现未改，没有竞价转发。

## 反例验证

共107组PASS：89组继承回归与18组新增。继承组显式补入两份有效最终快照，以验证原有高档可提交路径；3个竞价合成组的分数相应平移3200，保持原相对大小。没有把生产让行判断替换成恒假。新增组覆盖0/1/2份快照、窗口边界、所有编号和退出条件。

| 反例 | 结果 |
|---|---|
| 采用已有Map08日志中的0号1份/2943、1号2份/4546档位 | 0号首轮无提案，1号合成控制调用在3452步提交当前图；不需要竞价转发 |
| 轮流让0、1、2、3、4号成为唯一有2份最终快照者 | 各编号都能优先；合成最早提交依次3448、3452、3458、3464、3470 |
| 全部不足2份 | 3474步解除新增让行；合成例0号3476步提交，不无限等待 |
| 重复地图包、反复比较、晚到资格 | 首轮截止仍固定，晚到资格不再新等30步 |
| 第二份最终快照在3446步到达 | 立即解除新增限制，合成例0号3448步提交 |
| 分组已有2份快照，但FinalMaps只有1份 | 首轮仍让行，计数对象正确 |
| 首轮结束后还有库存、pending或队友未确认 | 仍禁止普通提交 |
| 旧普通、FastCloseout与各返航/ABORT状态 | 无法绕过新增让行 |
| 墙钟不足12秒、最后截止窗口、硬步数/墙钟兜底 | 正常退出新增让行；硬兜底直接用现有缓存 |
| Map09缺末弹确认，4230/4590步缓存刷新 | 不进入新增让行判断，4590版缓存继续用于墙钟兜底 |
| 真实RedHooks.control配合合成传感器 | 让行期间扫描继续，最终重画仍只一次，导航状态不变 |
| 0.003近分选新图与个人原图保护 | 原有回归PASS，相关源码逐字节未改 |

以上步数为合成控制器调用结果，不是新Map08轨迹。对五个编号的优先验证在第一份合成交图后停止调用；没有SDK地图、物理或实际比赛结束流程。不能据此宣称实际Map08已经由1号提交或恢复77.1892分。

## 检查与交付

实际候选ZIP已绑定SHA256。SDK225个文件核验PASS，官方静态内容检查PASS。只读复用Python3.11.17环境，真实NumPy1.26.4 mtrand/RandomState、Pandas3.0.6、OpenCV4.11.0.86运算通过；没有安装或替换依赖，不声称官网镜像验证。

`CANDIDATE_SOURCE.zip`是研究源码快照，不是新正式参赛放行包，未上传官网。`first_round_yield.patch`只适用于SHA256为f2c1059a…的近分＋6步时间槽基线；修改文件单独提供。

`RESULTS.json`包含完整配置、检查和明确为null的新地图成绩。`VALIDATION_EVIDENCE.zip`保留测试/构建脚本、原始验证日志和基线快照。`MAP08_BID_CONTEXT.json`记录既有竞价分档依据，`MAP08_SAVED_TABLES.json`是继承的旧评分表夹具，均不是新仿真产物。

最终快照数量只是原有证据档位，不能保证地图真实得分更高。当前证明新增让行及其退出契约，真实Map08、Map09收益仍未复测。
'''
(d/'README.md').write_text(readme,encoding='utf-8')
manifest={p.name:h(p) for p in sorted(d.iterdir()) if p.name!='CHECKSUMS_SHA256.json'}
assert len(manifest)==12,len(manifest)
(d/'CHECKSUMS_SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(status='PASS',delivery_files=13,candidate_sha256=b['candidate_zip_sha256'],scenario_groups=107),indent=2))
