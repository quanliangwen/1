# New cases exercise the actual first-round guard with zero/one/two final maps.
def final_count(drone, count):
    drone.final_maps.snapshots.clear()
    for offset in range(count):
        owner=(drone.identifier+offset)%drone.team_size
        drone.final_maps.snapshots[owner]=(owner,3420,True,drone.memory.packet())


def count_and_time_boundaries():
    d,g=real_partial()
    for count in [0,1,2,3,5]:
        final_count(d,count)
        for step in [3444,3448,3473]:assert g.yield_first_round(d,step)==(count<2)
        for step in [3443,3474,3504]:assert not g.yield_first_round(d,step)
check('E01_zero_one_two_final_snapshot_and_half_open_30step_boundaries',count_and_time_boundaries)


def observed_map08_grade_example():
    context=json.loads((args.archive.parent/'MAP08_BID_CONTEXT.json').read_bytes())
    d0,g0=real_partial(0);d1,g1=real_partial(1)
    for d in [d0,d1]:
        saved=context['drones'][str(d.identifier)]
        d.map_quality=saved['map_quality'];final_count(d,saved['inferred_final_snapshot_count'])
        assert RedHooks._own_map_bid(d,3444)[1]==saved['bid'][1]
    d0._prefer_own_submission=lambda *a:(_ for _ in ()).throw(AssertionError('weak candidate must yield without needing a relayed bid'))
    for step in range(3444,3453):
        assert not poll(d0,g0,step)
        if not d1.submitted:poll(d1,g1,step)
    assert not d0.sent and g0.choice is None and d1.red_submission_step==3452
    assert g1.candidates.best['owner']==5 and g1.candidates.best['version']==3444
check('E02_logged_Map08_bid_grades_hold_zero_and_allow_one_at_3452_without_forwarding',observed_map08_grade_example)


def every_identifier_can_win():
    for preferred in range(5):
        flights=[real_partial(i,phase='RETURN_LOCAL' if i%2 else 'ABORT') for i in range(5)]
        for d,g in flights:final_count(d,2 if d.identifier==preferred else 1)
        winner=None
        for step in range(3444,3474):
            for d,g in flights:
                if poll(d,g,step):winner=(d.identifier,step);break
            if winner is not None:break
        expected=3448 if preferred==0 else 3444+preferred*6+2
        assert winner==(preferred,expected),(preferred,winner)
check('E03_each_of_five_IDs_can_be_preferred_when_it_has_two_final_snapshots',every_identifier_can_win)


def nobody_has_two():
    flights=[real_partial(i) for i in range(5)]
    for d,g in flights:final_count(d,1)
    winner=None
    for step in range(3444,3480):
        for d,g in flights:
            if poll(d,g,step):winner=(d.identifier,step);break
        if winner is not None:break
    assert winner==(0,3476)
    assert all(not d.sent for d,g in flights[1:])
check('E04_all_weak_candidates_resume_after_3474_instead_of_waiting_forever',nobody_has_two)


def duplicates_do_not_restart_yield():
    d,g=real_partial();final_count(d,1)
    for step in [3444,3446,3450,3466,3473]:
        for _ in range(50):g.candidates.receive(d,1,('snapshot',g.candidates.snapshots[1]),step)
        assert not poll(d,g,step) and g.choice is None
    assert not g.yield_first_round(d,3474)
    assert not poll(d,g,3474) and g.choice['created']==3474
    assert poll(d,g,3476)
check('E05_duplicate_packets_and_comparisons_do_not_restart_absolute_first_round',duplicates_do_not_restart_yield)


def second_final_map_arrives():
    d,g=real_partial();final_count(d,1)
    assert not poll(d,g,3444) and g.choice is None
    final_count(d,2)
    assert not poll(d,g,3446) and g.choice is not None
    assert poll(d,g,3448)
check('E06_second_real_final_snapshot_releases_yield_immediately_in_own_slot',second_final_map_arrives)


def group_pool_is_not_final_maps():
    d,g=real_partial();final_count(d,1)
    assert len(g.candidates.snapshots)==2
    assert not poll(d,g,3444) and g.ordinary_selection and g.choice is None
    assert g.yield_first_round(d,3448)
    assert not poll(d,g,3448)
check('E07_two_group_exchange_snapshots_do_not_fake_two_FinalMaps_snapshots',group_pool_is_not_final_maps)


def before_floor_still_blocked():
    d,g=real_partial();final_count(d,1)
    assert not g.yield_first_round(d,3443)
    assert not poll(d,g,3443) and not d.sent and not g.ordinary_selection
check('E08_not_yielding_before_3444_does_not_bypass_existing_180plus24_floor',before_floor_still_blocked)


def low_wall_escape():
    d,g=real_partial();final_count(d,1);poll(d,g,3241)
    d.elapsed_walltime=168.0;assert g.yield_first_round(d,3448)
    d.elapsed_walltime=168.0001;assert not g.yield_first_round(d,3448)
    d._render_submission=lambda *a:(_ for _ in ()).throw(AssertionError('low wall budget must not add final fitting'))
    assert not poll(d,g,3444)
    assert not poll(d,g,3446) and poll(d,g,3448)
check('E09_exact_12second_boundary_and_low_wall_ordinary_escape_do_not_wait_30steps',low_wall_escape)


def deadline_window_escape():
    d=Flight();d.limit=300;g=GroupExchange(0,5,300,(64,64));final_count(d,1)
    assert g.finish_floor(d)==271
    assert not g.yield_first_round(d,271) and not g.yield_first_round(d,296)
check('E10_clamped_finish_floor_in_last_deadline_window_does_not_add_grace',deadline_window_escape)


def legacy_and_fast_exit_yield():
    from swarm_rescue.solutions.fast_closeout import FastCloseout
    for phase in ['RETURN_LOCAL','ABORT','DELIVERED_HOLD','OBSERVE']:
        d,g=real_partial(owner=1,phase=phase);g.plan.acks=set();final_count(d,1)
        assert not g.ordinary_submit_allowed(d,3450)
        f=FastCloseout(1,5);f.plan=(3400,1);f.vote=1
        assert not f.submit(d,3450) and not d.sent
    d,g=real_partial(1,phase='ABORT');g.plan.acks=set();final_count(d,2)
    f=FastCloseout(1,5);f.plan=(3400,1);f.vote=1;d.elapsed_timestep=3450
    assert f.submit(d,3450)
check('E11_legacy_and_fast_closeout_cannot_bypass_yield_in_any_return_phase',legacy_and_fast_exit_yield)


def hard_deadlines_ignore_new_guard():
    for reason,step,seconds in [('walltime',3448,179.),('timestep',5396,100.)]:
        d,g=real_partial();final_count(d,1);d.inventory_records[1]=(2832,1);poll(d,g,3241)
        saved=d.deadline_submission.image.copy()
        g.yield_first_round=lambda *a:(_ for _ in ()).throw(AssertionError('hard fallback cannot wait for grace'))
        d.elapsed_timestep=step;d.elapsed_walltime=seconds
        assert RedHooks._force_deadline_submission(d,step)
        assert d.deadline_submission_event['fallback']==reason and np.array_equal(d.sent[-1][1],saved)
check('E12_both_hard_fallbacks_skip_new_guard_and_keep_cached_image',hard_deadlines_ignore_new_guard)


def map09_cache_during_missing_confirmations():
    d,g=real_partial();final_count(d,1)
    d.inventory_records[1]=(2832,1);d.inventory_records[3]=(2804,1)
    g.yield_first_round=lambda *a:(_ for _ in ()).throw(AssertionError('missing stock confirmation precedes new guard'))
    d._render_submission=lambda *a:(_ for _ in ()).throw(AssertionError('no terminal rendering for Map09 unknown stocks'))
    assert not poll(d,g,3444) and not g.ordinary_selection
    for step in [4230,4590]:
        image=np.zeros((64,64),np.uint8);image[10:12,14:16]=1
        if step==4590:d.memory.hits[20,20]=3;image[40:42,40:42]=1
        g.candidates.remember_live(step,image);assert not poll(d,g,step)
    assert g.candidates.best['version']==4590 and not g.ordinary_selection and g.finish_refresh_step is None
    d.elapsed_timestep=4778;d.elapsed_walltime=179
    assert RedHooks._force_deadline_submission(d,4778) and np.array_equal(d.sent[-1][1],image)
check('E13_Map09_4230_4590_cache_and_wall_fallback_stay_before_yield_guard',map09_cache_during_missing_confirmations)


def grace_end_never_clears_stock_veto():
    for kind in ['own','pending','peer']:
        d,g=real_partial();final_count(d,1)
        if kind=='own':d.previous_inventory=1
        elif kind=='pending':d.pending_drop=(1,np.zeros(2),3473)
        else:d.inventory_records[4]=(3473,1)
        assert not poll(d,g,3474) and not poll(d,g,3476) and not d.sent
check('E14_end_of_30step_grace_never_replaces_stock_pending_or_peer_confirmation',grace_end_never_clears_stock_veto)


def actual_send_rechecks_final_count():
    d,g=real_partial();final_count(d,2);poll(d,g,3444);poll(d,g,3446)
    assert g.choice is not None
    final_count(d,1)
    assert not poll(d,g,3448) and not d.sent
    assert not poll(d,g,3474) and poll(d,g,3476)
check('E15_ordinary_actual_submit_rechecks_guard_even_after_existing_proposal',actual_send_rechecks_final_count)


def scanning_continues_while_yielding():
    d,g=real_partial(phase='ABORT');final_count(d,1);seen=[]
    d.lidar_values=lambda:np.full(181,150.)
    def observe(*args):
        seen.append(d.elapsed_timestep)
        return np.array([],dtype=np.int32),np.array([],dtype=np.uint8)
    d.memory.observe=observe
    before=(g.phase,list(g.route),d.messenger.state)
    for step in [3444,3448]:
        d.elapsed_timestep=step;command=control(d)
        assert command==NAV and not d.sent
    assert seen==[3444,3448] and g.finish_refresh_step==3444
    assert g.candidates.live_version==3444 and g.ordinary_selection
    assert before==(g.phase,g.route,d.messenger.state)
check('E16_real_control_keeps_scan_terminal_cache_and_navigation_state_while_yielding',scanning_continues_while_yielding)


def late_eligibility_does_not_restart_grace():
    d,g=real_partial(1);final_count(d,1)
    assert not poll(d,g,3478) and not g.yield_first_round(d,3478)
    assert not poll(d,g,3480) and poll(d,g,3482)
check('E17_late_ordinary_eligibility_does_not_start_another_30step_wait',late_eligibility_does_not_restart_grace)


def derived_window():
    d=Flight();d.limit=6000;g=GroupExchange(0,5,6000,(64,64));final_count(d,1)
    assert g.finish_floor(d)==3804
    assert g.yield_first_round(d,3804) and g.yield_first_round(d,3833)
    assert not g.yield_first_round(d,3834)
check('E18_first_round_tracks_existing_finish_floor_instead_of_hardcoded_3444',derived_window)
