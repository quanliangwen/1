from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from hashlib import sha256
import ast,json,subprocess
r=Path(__file__).resolve().parent;h=lambda data:sha256(data).hexdigest()
assert h((r/'baseline_snapshot.zip').read_bytes())=='f2c1059afc5218bd19cea9995679492b8c2211fd2eae42d0f77caa9abbbab318'
with ZipFile(r/'baseline_snapshot.zip') as z:old={n:z.read(n) for n in z.namelist()}
new={p.name:p.read_bytes() for p in (r/'candidate').iterdir() if p.is_file()}
assert set(new)==set(old)
changed=sorted(n for n in old if old[n]!=new[n]);assert changed==['group_exchange.py']
assert all((r/'baseline'/n).read_bytes()==data for n,data in old.items())
for n,data in new.items():
    if n.endswith('.py'):compile(data,n,'exec')
def methods(blob):
    node=next(n for n in ast.parse(blob).body if isinstance(n,ast.ClassDef) and n.name=='GroupExchange')
    return {n.name:ast.dump(n,include_attributes=False) for n in node.body if isinstance(n,ast.FunctionDef)}
a,b=methods(old['group_exchange.py']),methods(new['group_exchange.py'])
assert [n for n in a if a[n]!=b[n]]==['ordinary_submit_allowed','try_submit']
assert set(b)-set(a)=={'yield_first_round'}
raw=new['group_exchange.py'].decode().replace('\r\n','\n');insertion='        if self.yield_first_round(drone,step):return False\n'
assert raw.count(insertion)==2
stripped=methods(raw.replace(insertion,''));assert all(a[n]==stripped[n] for n in a)
with ZipFile(r/'candidate_snapshot.zip','w',ZIP_DEFLATED) as z:
    for n,data in sorted(new.items()):
        info=ZipInfo(n,date_time=(2026,11,21,0,0,0));info.compress_type=ZIP_DEFLATED;z.writestr(info,data)
diff=subprocess.run(['git','-c','core.autocrlf=false','diff','--no-index','--','baseline','candidate'],cwd=r,capture_output=True)
assert diff.returncode==1
patch=diff.stdout.replace(b'a/baseline/',b'a/').replace(b'b/candidate/',b'b/').replace(b'a/candidate/',b'a/')
(r/'first_round_yield.patch').write_bytes(patch)
check=subprocess.run(['git','apply','--check',str(r/'first_round_yield.patch')],cwd=r/'baseline',capture_output=True)
assert check.returncode==0,check.stderr
out=dict(status='PASS',baseline='frozen 0.003 near-tie and six-step-slot candidate',
    baseline_zip_sha256=h((r/'baseline_snapshot.zip').read_bytes()),candidate_zip_sha256=h((r/'candidate_snapshot.zip').read_bytes()),
    baseline_member_count=len(old),candidate_member_count=len(new),changed_existing_files=changed,added_files=[],unchanged_files=len(old)-1,
    only_existing_methods_changed=['ordinary_submit_allowed','try_submit'],added_methods=['yield_first_round'],
    previous_methods_reconstructed_by_removing_two_guard_calls=True,all_other_methods_ast_identical=True,
    near_tie_cache_bid_transport_placement_deadline_files_byte_identical=True,no_navigation_or_fitting_changes=True,
    new_bid_forwarding=False,patch_apply_check='PASS',original_files={n:h(data) for n,data in old.items()},
    candidate_files={n:h(data) for n,data in new.items()},new_full_matches=0,new_physics_steps=0,
    package_role='Research source snapshot, not a new competition release')
(r/'BUILD.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['original_files','candidate_files']},indent=2))
