"""Collect and verify the two Map08 seed-615 results."""
from hashlib import sha256
from pathlib import Path, PurePosixPath
import json
import math
import subprocess
from zipfile import ZIP_DEFLATED, ZipFile

root = Path(__file__).resolve().parent
stage = (root / "SERVER_STAGE.txt").read_text().strip()
out = root / "delivery"
out.mkdir(exist_ok=True)
receipt = root / "received"
sdk = "6557940dc18549ffc7a945db887da5b05b7ed2f1"
sdk_archive = "9155bc4cdf5e0813cd328d3a56c3b73633ba351c3859e694762ed41376fc6860"
health_start = 25

def read(path):
    return json.loads(path.read_bytes())

def write(path, entry):
    path.write_text(json.dumps(entry, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def download(paths, folder):
    folder.mkdir(exist_ok=True, parents=True)
    subprocess.run(["scp", "-q", "-o", "BatchMode=yes",
                    *(f"quanliangwen@10.112.162.60:{path}" for path in paths), str(folder)], check=True)

def select_last_confirmation(updates, owner):
    return next((row for row in updates if row["peer"] == owner and row["after"][1] == 0), None)

def frames_summary(frames):
    indexed = {row["step"]: row for row in frames}
    anchors = (3240, 3316, 3317, 3417, 3440, 3444)
    result = {}
    for step in anchors:
        row = indexed.get(step)
        if row is not None:
            result[str(step)] = {key: row[key] for key in (
                "physical_xy", "health", "command", "mode", "inventory", "gps_fixed", "odometry_only",
                "odom_speed", "records", "wait_started", "wait_settled", "wait_finished")}
    return result

def get_round(arm):
    remote = f"{stage}/Map08_{arm}"
    dest = receipt / f"Map08_{arm}"
    download([f"{remote}/{name}" for name in (
        "START.json", "FINISH.json", "SOURCE_MATCH.json", "OFFICIAL_SCORE.json",
        "placement_events.jsonl", "run.log", "wall_geometry.npz")], dest)
    start, finish, source, score = (read(dest / f"{stem}.json") for stem in
                                    ("START", "FINISH", "SOURCE_MATCH", "OFFICIAL_SCORE"))
    binding = read(root / f"{arm}_binding.json")
    assert (start["seed"], start["map_name"], start["sdk"], start["sdk_archive_sha256"]) == (615, "Map08", sdk, sdk_archive)
    assert [start[k] for k in ("drones", "bombs_per_drone", "timestep_limit",
                               "walltime_limit", "competition_mode")] == [5, 2, 5400, 180, True]
    assert start["spawn"] == read(root / "matched_spawns.json")["Map08"]
    assert start["zones"] == {"NoGpsZone": 2, "NoComZone": 0}
    assert start["solutions_sha256"] == source["candidate"] == binding["candidate"]
    assert source["candidate_zip_sha256"] == digest(root / f"{arm}_snapshot.zip") == binding["candidate_zip_sha256"]
    assert source["changed"] == binding["changed"]
    assert [finish[k] for k in ("status", "completed_red_rounds", "blue_rounds", "layout_evaluations")] == ["COMPLETE", 1, 0, 0]
    assert digest(dest / "placement_events.jsonl") == score["placement_events_sha256"]
    assert digest(dest / "wall_geometry.npz") == score["wall_geometry_sha256"]
    official = PurePosixPath(finish["result_dir"])
    assert official.is_relative_to(PurePosixPath(remote) / "official_sdk/results_swarm_rescue")
    reports = {name: expected for name, expected in finish["files"].items()
               if PurePosixPath(name).name.endswith(("_bombs.json", "_exploration.json"))}
    assert len(reports) == 2
    download([str(official / name) for name in reports], dest)
    for name, expected in reports.items():
        assert digest(dest / PurePosixPath(name).name) == expected

    events = [json.loads(line) for line in (dest / "placement_events.jsonl").read_bytes().splitlines()]
    drops = [row for row in events if row["event"] == "sdk_placement" and row["accepted"]]
    assert len(drops) == score["placed"]
    last_drop = max(drops, key=lambda row: row["step"], default=None)
    updates = {drone: [row for row in events if row["event"] == "received_inventory" and row["drone"] == drone]
               for drone in (0, 1)}
    frames = {drone: [row for row in events if row["event"] == "late_trace" and row["drone"] == drone]
              for drone in (0, 1)}
    lead = score["drone_details"][0]
    assert lead["drone"] == 0
    waits = lead["inventory_wait_audit"]
    park = next((row for row in (waits or []) if row[1] == "parked"), None)
    stationary = [row for row in frames[0] if row["wait_settled"] and not row["wait_finished"]]
    true_path = sum(math.dist(a["physical_xy"], b["physical_xy"]) for a, b in zip(stationary, stationary[1:]))
    point_drift = max((math.dist(stationary[0]["physical_xy"], row["physical_xy"]) for row in stationary), default=0.)
    selected = score["selected_submission"]
    if selected is not None and selected["drone"] is not None:
        assert selected["step"] == score["steps"]
        assert selected["image_sha256"] == score["selected_image_sha256"]
    brake = next((row[0] for row in (waits or []) if row[1] == "brake"), None)
    abort = next((row[0] for row in (waits or []) if row[1] == "braking_timeout"), None)
    brake_frames = [] if brake is None else [row for row in frames[0]
                    if brake <= row["step"] <= (abort if abort is not None else brake + 8)]
    health_transitions = [
        dict(drone=drone, step=current["step"], before=previous["health"], after=current["health"])
        for drone, track in frames.items() for previous, current in zip(track, track[1:])
        if previous["health"] != current["health"]
    ]
    health = {row["drone"]: row["health"] for row in score["drone_details"]}
    return dict(
        source_commit=binding["source_commit"],
        source_zip_sha256=source["candidate_zip_sha256"],
        selected_submission=selected, completed_step=score["steps"],
        health=health, health_lost={drone: health_start - value for drone, value in health.items()},
        total_health_lost=sum(health_start - value for value in health.values()),
        wall_coverage_score=score["coverage"], weighted_wall_coverage_fraction=score["wall_breakdown"]["coverage_fraction"],
        covered_wall_pixels=score["wall_breakdown"]["covered_wall_pixels"],
        map_score=score["map_score"], round_score=score["partial"],
        elapsed_walltime_seconds=score["elapsed_walltime"],
        accepted_drops=drops, last_physical_drop=last_drop,
        last_drop_local_inventory_confirmation=score["drone_details"][last_drop["drone"]]["last_confirmation"]
        if last_drop else None,
        lead_last_bomb_confirmation=select_last_confirmation(updates[0], last_drop["drone"]) if last_drop else None,
        backup_last_bomb_confirmation=select_last_confirmation(updates[1], last_drop["drone"]) if last_drop else None,
        lead_final_inventory_records=lead["final_inventory_records"],
        lead_wait_audit=waits, lead_park_step=None if park is None else park[0],
        lead_brake_frames=brake_frames,
        late_health_transitions=health_transitions,
        lead_settled_control_frames=len(stationary),
        lead_measured_park_path_pixels=None if not stationary else true_path,
        lead_max_measured_park_drift_pixels=None if not stationary else point_drift,
        lead_wait_safety_events=[row for row in events if row["event"] == "wait_safety"],
        lead_selected_frames=frames_summary(frames[0]),
    )

if __name__ == "__main__":
    download([f"{stage}/pair.log"], receipt)
    log = (receipt / "pair.log").read_text(encoding="utf-8")
    assert [line for line in log.splitlines() if line.startswith(("START Map", "COMPLETE Map"))] == [
        "START Map08 repair", "COMPLETE Map08 repair", "START Map08 wait", "COMPLETE Map08 wait"]
    results = {arm: get_round(arm) for arm in ("repair", "wait")}
    repair, wait = (results[arm] for arm in ("repair", "wait"))
    diff = {field: wait[field] - repair[field]
            for field in ("completed_step", "total_health_lost", "wall_coverage_score",
                          "weighted_wall_coverage_fraction", "covered_wall_pixels", "map_score",
                          "round_score", "elapsed_walltime_seconds")}
    summary = dict(seed=615, map="Map08", sdk=sdk, sdk_archive_sha256=sdk_archive,
                   new_rounds=2, blue_rounds=0, initial_health_per_drone=health_start,
                   rounds=results, candidate_minus_repair=diff,
                   same_physical_drop_events=repair["accepted_drops"] == wait["accepted_drops"],
                   observation="Live official SDK simulation. Identical external tracing is enabled in both rounds; "
                               "candidate-only safety check results are also read. Solution ZIPs are unchanged.")
    write(out / "RESULTS.json", summary)
    with ZipFile(out / "RUN_EVIDENCE.zip", "w", compression=ZIP_DEFLATED) as archive:
        for path in sorted(receipt.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(root).as_posix())
        for name in ("Map08.yml", "matched_spawns.json", "run_pair.sh", "stage_run.py", "collect.py"):
            archive.write(root / name, name)
    with ZipFile(out / "RUN_EVIDENCE.zip") as archive:
        assert archive.testzip() is None
    write(out / "CHECKSUMS_SHA256.json", {name: digest(out / name) for name in ("RESULTS.json", "RUN_EVIDENCE.zip")})
    print(json.dumps({arm: {key: value for key, value in row.items()
                            if key not in ("accepted_drops", "lead_selected_frames")} for arm, row in results.items()},
                     indent=2, ensure_ascii=False))
    print(diff)

