"""Real control/receive methods with synthetic sensors; no arena or physics."""
import argparse,json,sys,math
from pathlib import Path
from hashlib import sha256
from types import SimpleNamespace as NS
from unittest.mock import patch
import numpy as np
import pymunk
import swarm_rescue.solutions

physics_attempts=0
def no_physics(*a,**kw):
    global physics_attempts
    physics_attempts+=1
    raise AssertionError('Physics is forbidden')
pymunk.Space.step=no_physics
parser=argparse.ArgumentParser()
parser.add_argument('archive',type=Path)
parser.add_argument('arm',choices=['candidate'])
parser.add_argument('--output',type=Path)
args=parser.parse_args()
candidate=args.arm=='candidate'
swarm_rescue.solutions.__path__=[str(args.archive.resolve())]
from swarm_rescue.solutions.red_hooks import RedHooks
from swarm_rescue.solutions.lbbd_rescue import LBBDRescue
from swarm_rescue.solutions.coverage_placement import CoveragePlacementDrone
from swarm_rescue.solutions.deadline_submission import DeadlineSubmission
from swarm_rescue.solutions.pre_submit_scan import PreSubmitScan
from swarm_rescue.solutions.final_map_relay import FinalMaps
from swarm_rescue.solutions.greedy_mapping import MapMemory
from swarm_rescue.solutions.submission_renderer import SubmissionBearings
from swarm_rescue.solutions.group_exchange import GroupExchange
from swarm_rescue.solutions.exchange_plan import known_segment
from swarm_rescue.solutions.map_candidates import digest, frozen
from swarm_rescue.solutions.red_hooks import local_score

RESULTS={}
NAV=dict(forward=.2,lateral=.1,rotation=0.,grasper=0,place_bomb=0)
def noop(*a,**kw):pass

class Grid:
    HULL_CLEARANCE=18.
    def __init__(self):
        self.evidence=np.full((256,256),-8,np.int8)
        self.clearance=np.full((256,256),64.)
        self.tight=np.zeros((256,256),bool)
        self.pose_fixed=True
        self.route_calls=0
        self.detour=[]
    def cell(self,p):return (int((p[1]+2048)//16),int((p[0]+2048)//16))
    def route(self,a,b):self.route_calls+=1;return tuple(self.detour)

class Flight(RedHooks):
    def __init__(self,identifier=0):
        self.identifier,self.team_size,self.limit=identifier,5,5400
        self.walltime_limit,self.elapsed_walltime=180.,75.
        self.elapsed_timestep=3240
        self.initial_inventory,self.previous_inventory,self.pending_drop=2,0,None
        self.inventory_records={i:(2500,0) for i in range(5)}
        self.submitted=False;self.pose=np.array([400.,0.]);self.heading=0.
        self.size_area=(2000,2000);self.states={};self.drives=[]
        self.last_confirmed_drop_step=None
        self.deadline_submission=DeadlineSubmission();self.deadline_versions={}
        self.deadline_submission.remember(2000,np.ones((32,32),np.uint8))
        self.final_maps=FinalMaps(identifier,5)
        self.map_quality,self.map_revision=8000,{4:2479}
        self.first_ready_to_submit_step=None
        self.sent=[];self.base_calls=self.map_calls=self.placement_calls=0
        self.rendered_memories=[];self.order=[]
        self.map_bids={};self.last_eligible_bid_comparison={}
        self.submission_priority_audit=self.submission_wait_started=None
        self.submission_wait_for=None
        self.closeout=NS(state='IDLE',tick=noop)
        self.messenger=NS(tick=lambda *a:False,state='IDLE',audit=[])
        self.grid=Grid();self._odometry_only=False
        self.memory=MapMemory(64,64);self.memory.free[:]=True;self.memory.hits[5,7]=3
        self.fine_wall_coverage=NS(observe=noop,packet=lambda:None,merge_direct=noop)
        self.submission_bearings=SubmissionBearings(64,64)
        self.red_packet=(2100,())
        self.pre_submit_scan=PreSubmitScan()
        self.drop_departure=NS(update=noop,steer=noop,controls_step=-1)
        self.second_drop=NS(observe_route=noop,control=self.second_control)
        self.team_wall=NS(reservation=None,steer=lambda *a:False)
        self.fast_closeout=NS(act=lambda *a:False)
        self.placement=NS(maneuvers=NS(exit=None,waiting_exit=None,approach=None,remember=noop),
                          _ordinary_start_step=lambda limit:0,finish_request=noop,update=noop)
        self.search_roaming=NS(departed=False)
        self.local_escape=NS(apply=noop)
        self.submitted_cache='old bitmap sentinel';self.final_submission_versions={}
        self.submission_elected_rank=None;self.red_submission_step=None
        self.deadline_submission_event=None
        self.drop_records={};self.team_exchange_audit=[]
        self.group_best_image=None
        self.group_exchange=GroupExchange(identifier,5,5400,(64,64))
    def _sync_placement(self,step):pass
    def _update_drop_hints(self,*a):pass
    def _prepare_map_cache(self,*a):return None
    def _submission_image(self,step):
        self.map_calls+=1
        return np.full((32,32),9,np.uint8),('old-cache',2100),{}
    def _render_submission(self,memory=None):
        self.order.append('render')
        actual=self.memory if memory is None else memory
        self.rendered_memories.append(actual)
        return (actual.hits>=3).astype(np.uint8)
    def submit_exploration_map(self,image):
        self.order.append('submit');self.sent.append((self.elapsed_timestep,image.copy()))
    def lidar_values(self):return None
    def lidar_rays_angles(self):return np.linspace(-np.pi,np.pi,181)
    def semantic_values(self):return ()
    def communicator_is_disabled(self):return False
    def drive(self,goal,velocity,**kw):
        self.drives.append(tuple(map(float,goal)))
        return dict(forward=0.,lateral=0.,rotation=0.,grasper=0,place_bomb=0)
    def measured_velocity(self):return np.zeros(2)
    def second_control(self,*a):
        self.placement_calls+=1
        return 'approach' if self.previous_inventory else 'none'

def base(d):
    d.base_calls+=1;d.order.append('base');return NAV.copy()
def control(d):
    with patch.object(LBBDRescue,'control',base):return RedHooks.control(d)
def try_submit(d):return RedHooks._try_return_submission(d,d.elapsed_timestep)


def ready(owner=0):
    d=Flight(owner);g=d.group_exchange;p=g.plan
    p.root=(100,200.,0.);p.acks=set(range(5))
    p.trail=[(200.,0.),(300.,0.),(400.,0.)]
    return d,g


def committed(owner=0):
    d,g=ready(owner);intent=g.prepare_return(d,3240);assert intent is not None
    g.commit_return(d,intent,3240)
    return d,g


def check(name, method):
    method();RESULTS[name]='PASS'


def no_marker():
    d=Flight();g=d.group_exchange
    d.route=[(9,8)];d.search_task=NS(started=11);d.messenger.state='ACTIVE'
    before=(list(d.route),d.search_task,d.messenger.state,list(d.messenger.audit))
    assert g.prepare_return(d,3240) is None
    assert (d.route,d.search_task,d.messenger.state,d.messenger.audit)==before
check('P03_no_root_does_not_cancel_original_mission',no_marker)


def end_drone():
    d=Flight();p=d.group_exchange.plan;p.observe(d,3)
    d.pose=np.array([600.,0.]);p.observe(d,100)
    assert p.root==(100,600.,0.) # No all-team span or radius-about-zero rule.
check('P01_endpoint_leader_records_without_team_radius',end_drone)


def async_root():
    d,g=ready(3);g.plan.acks=set()
    body=dict(epoch=g.plan.epoch,root=g.plan.root,acks=(0,1),step=100,point=(300.,0.),edges={},fixed=True)
    g.plan.receive(d,dict(id=0),body,100)
    body.update(acks=(2,4),step=140)
    g.plan.receive(d,dict(id=2),body,140)
    g.plan.observe(d,141)
    assert g.plan.committed()
check('P09_asynchronous_multihop_root_ack',async_root)


def unknown_ack():
    d,g=ready();g.plan.acks={0,1,2,3}
    assert not g.plan.committed() and g.prepare_return(d,3240) is None
check('P10_missing_acceptance_not_global_commit',unknown_ack)


def direct_only():
    d,g=ready();body=dict(epoch=g.plan.epoch,step=100,point=(400.,0.),fixed=True)
    g.receive(d,dict(id=1,states=({'id':4,'step':100,'point':(400.,0.)},),red_group_exchange=body),100)
    assert 1 in g.plan.direct and 4 not in g.plan.direct
check('P04_relayed_third_party_is_not_direct_contact',direct_only)


def near_no_packet():
    d,g=ready();d.states={1:dict(point=(401,0),step=100)}
    g.observe(d,100);assert not g.plan.direct and not g.candidates.receipts
check('P05_no_communication_without_received_message',near_no_packet)


def root_no_local():
    d,g=ready();g.plan.branch_group=(0,1);g.plan.local_region=(900.,900.)
    intent=g.prepare_return(d,3240);assert intent.target==(200.,0.) and intent.group==(0,)
check('P02_local_missing_falls_back_shared_root',root_no_local)


def conflict():
    d,g=ready();root=g.plan.root
    g.receive(d,dict(id=1,red_group_exchange=dict(epoch=g.plan.epoch,step=100,point=(300,0),
              root=(90,-500.,0.),acks=(0,1,2,3,4))),100)
    assert g.plan.root==root
check('P08_conflicting_middle_point_cannot_replace_root',conflict)


def branches():
    for group in [(0,1,2,3),(0,3),(1,2)]:
        owner=group[0];d,g=ready(owner);p=g.plan
        for a,b in zip(group,group[1:]):p.edges[(a,b)]=(100,(250.,0.))
        p.observe(d,100);p.observe(d,140)
        assert p.branch_group==group,(group,p.branch_group)
check('P06_actual_4plus1_2plus2plus1_branch_members',branches)


def single_loss():
    d,g=ready();g.plan.edges={(0,1):(100,(200.,0.))}
    g.plan.observe(d,100);g.plan.observe(d,101)
    assert g.plan.branch_group==(0,)
check('P07_one_frame_not_stable_split',single_loss)


def drop_gates():
    for stock,pending in [(1,None),(0,(1,np.zeros(2),3239))]:
        d,g=ready();d.previous_inventory=stock;d.pending_drop=pending
        assert g.prepare_return(d,3240) is None
    d,g=ready();assert g.prepare_return(d,3239) is None
check('T01_actual_stock_pending_and_60percent_gate',drop_gates)


def escape():
    d,g=ready();d.placement.maneuvers.exit=NS()
    assert g.prepare_return(d,3240) is None
check('T02_post_drop_escape_priority',escape)


def duplicate():
    d,g=committed();before=(g.started_step,list(g.route),list(d.messenger.audit))
    for step in range(3241,3341):assert g.prepare_return(d,step) is None
    assert before==(g.started_step,g.route,d.messenger.audit)
check('T03_repeats_never_restart_mission_or_timer',duplicate)


def late_root():
    d,g=committed();d.pose=np.array([300.,0.]);g.go_root(d,3300)
    assert g.phase=='COURIER_TO_C' and g.target==(200.,0.)
check('T04_late_member_uses_shared_C_not_old_peer_position',late_root)


def passive_late_delivery():
    d,g=ready(1);g.plan.trail=[(200.,0.),(300.,0.),(400.,0.)]
    d.elapsed_timestep=4501
    d.route=[(123,456)];d.search_task=NS(started=99);d.messenger.state='ACTIVE'
    old=(list(d.route),d.search_task,d.messenger.state)
    g.observe(d,4501)
    assert g.prepare_return(d,4501) is None
    assert not g.owns_navigation and (d.route,d.search_task,d.messenger.state)==old
    assert 1 in g.candidates.snapshots and 1 in g.candidates.images
    g.peer_status[4]=dict(step=4501,have=set())
    assert g.message(d,4501)['payload'] is not None
check('T08_late_no_budget_can_deliver_at_contact_without_cancelling_navigation',passive_late_delivery)


def blocked():
    d,g=committed();d.grid.evidence[:]=3
    cmd=NAV.copy();assert g.tick_navigation(d,3241,cmd,None,())
    assert d.drives[-1]==tuple(d.pose)
    assert not g.tick_navigation(d,3281,cmd,None,()) and g.phase=='ABORT'
check('T05_blocked_route_brakes_then_bounded_abort',blocked)


def avoidance():
    d,g=committed();g.phase='DELIVERED_HOLD';g.hold=tuple(d.pose);g.route=[]
    calls=[];d.local_escape.apply=lambda *a:calls.append(a)
    assert g.tick_navigation(d,3241,NAV.copy(),None,()) and calls
check('T06_delivered_hold_keeps_existing_avoidance',avoidance)


def cutoff():
    d,g=committed();assert not g.ordinary_submit_allowed(d,3300)
    g.observe(d,4590)
    assert not g.owns_navigation and g.ordinary_submit_allowed(d,4590)
    d.inventory_records[4]=(2500,1)
    assert not g.try_submit(d,4590,local_score)
check('T07_cutoff_releases_control_without_faking_team_clear',cutoff)


def manifest_only():
    d,g=committed();payload=g.candidates.snapshots[0]
    body=dict(epoch=g.plan.epoch,step=3241,point=(400.,0.),manifest=(('snapshot',4,3240,payload['digest']),))
    g.receive(d,dict(id=1,red_group_exchange=body),3241)
    assert set(g.candidates.snapshots)=={0} and not g.candidates.receipts
check('M01_manifest_not_actual_payload_receipt',manifest_only)


def corrupt():
    d,g=committed();other,h=committed(1);payload=h.candidates.snapshots[1]
    bad=dict(payload,digest='f'*64)
    assert not g.candidates.receive(d,1,('snapshot',bad),3242)
    bad=dict(payload,bearings=np.zeros((1,1),np.uint8));bad['digest']=digest({k:v for k,v in bad.items() if k!='digest'})
    assert not g.candidates.receive(d,1,('snapshot',bad),3242)
    assert 1 not in g.candidates.snapshots
check('M02_digest_and_shape_validation',corrupt)


def duplicate_payload():
    d,g=committed();other,h=committed(1);payload=h.candidates.snapshots[1]
    assert g.candidates.receive(d,1,('snapshot',payload),3242)
    before=d.memory.hits.copy();n=len(g.candidates.audit)
    assert g.candidates.receive(d,1,('snapshot',payload),3243)
    assert len(g.candidates.audit)==n and np.array_equal(before,d.memory.hits)
    bad=dict(payload,digest='0'*64);assert not g.candidates.receive(d,1,('snapshot',bad),3244)
check('M03_duplicate_idempotent_same_version_conflict_rejected',duplicate_payload)


def no_echo():
    d,g=committed();have=set(g.candidates.manifest())
    assert g.candidates.payload(3242,[have]) is None
check('M04_do_not_send_payload_back_to_existing_holder',no_echo)


def freeze_versions():
    d,g=committed();data=g.candidates.snapshots[0];before=data['digest'];bits=data['bearings'].copy()
    d.memory.hits[:]=7;d.submission_bearings.bits[:]=255
    assert digest({k:v for k,v in data.items() if k!='digest'})==before
    assert np.array_equal(data['bearings'],bits) and not data['bearings'].flags.writeable
check('M05_memory_and_bearings_frozen_together',freeze_versions)


def long_delivery():
    d,g=committed();other,h=committed(1)
    assert g.candidates.receive(d,1,('snapshot',h.candidates.snapshots[1]),4100)
    from swarm_rescue.solutions.red_hooks import cached_eligible
    assert not cached_eligible(4100,3240,4100)
check('M06_epoch_payload_survives_480steps_old_TTL_unchanged',long_delivery)


def owner_not_quality():
    d,g=committed();g.candidates.add_image(0,3240,np.ones((64,64)),{0:'x',1:'y'},3240)
    g.candidates.choose(d,3242,local_score,fusion=False)
    assert len(g.candidates.score_table)==1
check('M07_multiple_sources_not_quality_score_bonus',owner_not_quality)


def stock_first():
    d,g=committed();assert not g.candidates.images
    msg=g.message(d,3241)
    assert msg['receipts'] and msg['choice'] is None
    # Stock is in original red_inventory independently from this large payload.
    assert d.inventory_records[0][1]==0
check('M08_snapshot_build_does_not_gate_stock_records',stock_first)


def ranking():
    d,g=committed();good=np.zeros((64,64),np.uint8);good[10:12,14:16]=1
    bad=np.ones((64,64),np.uint8)
    g.candidates.add_image(1,3240,good,{1:'a'},3240)
    g.candidates.add_image(2,3241,bad,{2:'b'},3241)
    chosen=g.candidates.choose(d,3300,local_score,fusion=False)
    assert chosen['owner']==1 and len(g.candidates.score_table)==2
    assert g.candidates.reference_digest==digest(d.memory.hits>=3)
check('Q01_Q02_common_reference_can_choose_individual_over_more_walls',ranking)


def fill(d,g):
    for i in range(5):
        other,h=committed(i)
        g.candidates.receive(d,i if i!=d.identifier else (i+1)%5,('snapshot',h.candidates.snapshots[i]),3300)
        good=np.zeros((64,64),np.uint8);good[10:12,14:16]=1
        g.candidates.add_image(i,3240+i,good if i==1 else np.ones((64,64),np.uint8),{i:'e'},3300)
    g.candidates.fusion_built=True


def proxy():
    d,g=committed(4);fill(d,g)
    assert not g.try_submit(d,3300,local_score)
    assert g.choice['image_owner']==1 and g.choice['executor']==4
    assert g.try_submit(d,3302,local_score)
    assert d.red_submission_step==3302 and g.phase=='SUBMITTED'
check('Q03_Q04_nonzero_executor_can_submit_other_owners_best_image',proxy)


def old_final_nonempty():
    d,g=committed();fill(d,g);g.candidates.install(d,1,3300)
    d.final_maps.snapshots[4]=(1,())
    image,cache,versions=RedHooks._submission_image(d,3300)
    assert np.array_equal(image,g.candidates.image(1)) and cache[1]==1
    assert d.deadline_submission.image is image
check('Q05_old_FinalMaps_cannot_override_new_selected_image',old_final_nonempty)


def waits():
    d,g=committed();fill(d,g)
    d.pre_submit_scan.waiting=lambda *a:(_ for _ in ()).throw(AssertionError('old scan wait'))
    d.final_maps.waiting=lambda *a:(_ for _ in ()).throw(AssertionError('old final wait'))
    d._prefer_own_submission=lambda *a:(_ for _ in ()).throw(AssertionError('old bid wait'))
    assert not g.try_submit(d,3300,local_score) and g.try_submit(d,3302,local_score)
check('S01_new_exit_not_blocked_by_old_three_windows',waits)


def fast_gate():
    from swarm_rescue.solutions.fast_closeout import FastCloseout
    d,g=committed();f=FastCloseout(0,5)
    assert not f.submit(d,3300)
check('S02_old_fast_submission_blocked_without_touching_drop_code',fast_gate)


def hard_deadline():
    d,g=committed();fill(d,g);g.candidates.install(d,1,3300)
    d.elapsed_walltime=179.;d.elapsed_timestep=4000
    assert RedHooks._force_deadline_submission(d,4000)
    assert d.sent and np.array_equal(d.sent[0][1],g.candidates.image(1))
check('S03_hard_wall_deadline_precedes_unfinished_election',hard_deadline)


def no_heavy_fit():
    d,g=committed();g.candidates.add_image(0,3240,np.eye(64,dtype=np.uint8),{},3240)
    d.elapsed_walltime=175.
    with patch.object(SubmissionBearings,'render',side_effect=AssertionError('new fit')):
        g.candidates.choose(d,4590,local_score,fusion=False)
check('S04_low_budget_uses_existing_images_without_new_fit',no_heavy_fit)


def lease():
    d,g=committed();fill(d,g);g.try_submit(d,3300,local_score)
    choice=g.choice
    assert g.valid_choice(choice,3300)
    bad=dict(choice,executor=4);assert not g.valid_choice(bad,3300)
    d4,g4=committed(4);fill(d4,g4);g4.choice=choice;g4.choice_acks={4}
    assert not g4.try_submit(d4,3302,local_score)
check('S05_choice_digest_and_executor_lease',lease)


def disabled():
    d=Flight();d.group_exchange=None
    control(d)
    assert not d.sent and d.base_calls==1
check('R01_disabled_feature_preserves_ordinary_scan_wait',disabled)


def control_handoff():
    d,g=ready();cmd=control(d)
    assert g.started_step==3240 and g.owns_navigation and d.drives
    d,g=ready();d.previous_inventory=1;d.inventory_records[0]=(2500,1)
    control(d);assert g.started_step is None and d.placement_calls==1
check('control_integration_returns_and_keeps_second_drop_path_for_loaded_drone',control_handoff)

result=dict(status='PASS',scenario_groups=len(RESULTS),scenarios=RESULTS,
            archive_sha256=sha256(args.archive.read_bytes()).hexdigest(),
            loaded_red_hooks=sys.modules[RedHooks.__module__].__file__,
            physics_step_attempts=physics_attempts,physics_steps=0,map_objects_created=0,full_matches=0)
assert physics_attempts==0
if args.output:args.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

