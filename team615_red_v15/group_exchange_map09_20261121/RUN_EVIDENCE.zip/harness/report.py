from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import collections,json,shutil,numpy as np

r=Path(__file__).resolve().parent;dest=r/'delivery'
read=lambda p:json.loads(p.read_bytes())
data=read(dest/'RESULTS.json');o,c,d=data['original'],data['candidate'],data['candidate_minus_original']
score=read(r/'received/OFFICIAL_SCORE.json')
group=data['group_details']

def events(path):
    return [json.loads(s) for s in path.read_text(encoding='utf-8').splitlines()]
old=r.parent/'team615_messenger_batch1_20261121/received/Map09_baseline'
oe,ce=events(old/'placement_events.jsonl'),events(r/'received/placement_events.jsonl')
placements={}
for i in range(5):
    placements[str(i)]={label:[{'step':v['step'],'position':v['physical_xy']} for v in rows
        if v.get('drone')==i and v['event']=='sdk_placement' and v.get('accepted')]
        for label,rows in [('original',oe),('candidate',ce)]}

aborts={i:next((e[0] for e in g['group_audit'] if e[1]=='route_abort'),None) for i,g in group.items()}
diagnosis=dict(
    full_group_rendezvous_completed=False,full_best_map_election_triggered=False,
    shared_root=group['0']['group_root'],shared_root_ack_members=group['0']['group_root_acks'],
    return_start={i:g['group_started'] for i,g in group.items()},abort_steps=aborts,
    actual_partial_delivery=[{'step':v[0],'receiver':int(i),'sender':v[2],'kind':v[3],'owner':v[4],'version':v[5]}
        for i,g in group.items() for v in g['stored_payloads']],
    current_implementation_gaps=[
        'Only the common root has all-team agreement. Local group membership and local meeting markers were not jointly committed; overlapping stale group views exist.',
        'All four navigation missions aborted on repeated current-grid segment rejection and no usable grid-route join; historical traversal did not ensure current admissibility.',
        'The early 80px root proposal is near the initial group area and is not a verified first-split junction. Most local markers fell back toward early trail regions.',
        'Late drone1 had insufficient return budget and only prepared a passive payload; no actual new protocol delivery of it occurred.',
    ],
    leader_missing_final_confirmations=[i for i,v in score['drone_details'][0]['final_inventory_records'].items() if v[1]>0],
    confirmed='Shared root and 0-to-4 actual payloads succeeded; full rendezvous, full stock propagation, best-map election and early submission did not occur.',
    unconfirmed='Exact cause of drone1 420-step delay and map-score increase not causally isolated. Current-grid abort does not prove a physical return route is absent.',
    per_drone_actual_placements=placements)
data['diagnosis']=diagnosis
data['recommendation']='Do not promote as an accelerated replacement. Single-run score rose, but coordination objective failed and last bomb/submission delayed.'
(dest/'RESULTS.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

metrics=[('得分 / 红队80分','partial_score_out_of_80',4),('地图分 / 100','map_score',4),
         ('墙覆盖分 / 100','wall_score',4),('交图步数','submission_step',0),
         ('漏墙像素','missed_wall_pixels',0),('扣分误画像素','charged_misdraw_pixels',0),
         ('探索率 / %','exploration_percent',4),('实投数','placed',0),
         ('总掉血','total_health_lost',0),('墙钟用时 / 秒','elapsed_walltime_seconds',3)]
lines=['| 指标 | 原版（历史） | 新候选（本次） | 新候选−原版 |','|---|---:|---:|---:|']
for label,key,precision in metrics:
    lines.append(f'| {label} | {o[key]:.{precision}f} | {c[key]:.{precision}f} | {d[key]:+.{precision}f} |')
table='\n'.join(lines)+'\n\n实际选中交图者：两版均为0号，均由墙钟硬兜底提交。新候选4970步，比原版晚450步；墙钟用时几乎相同。\n'
table+='\n得分变化分解：地图项 +4.998645，墙覆盖项 +1.590822，时间项 −1.190476，合计 +5.398991。误画虽然增加8458像素，但漏墙减少12023像素，地图分仍上涨。\n'
table+='\n| 无人机 | 原版末弹确认 | 新候选末弹确认 | 差值 |\n|---|---:|---:|---:|\n'
for i in range(5):
    a,b=o['per_drone_last_confirmation'][str(i)],c['per_drone_last_confirmation'][str(i)]
    table+=f'| {i}号 | {a} | {b} | {b-a:+d} |\n'
table+='\n旧单点候选仅供失败参考：38.4272/80、4932步交图、1号末弹4387步。本次比它得分高4.4308，但仍晚38步交图。没有为这个参考再跑比赛。\n'

findings='''**本次没有完成设计目标，不能把涨分称为分组加速成功。**

| 无人机 | 新返航开始 | 退出返航 | 实际持有快照owner | 末态 |
|---|---:|---:|---|---|
'''
for i,g in group.items():
    findings+=f"| {i}号 | {g['group_started'] if g['group_started'] is not None else '未接管'} | {aborts[i] if aborts[i] is not None else '—'} | {g['actual_snapshot_owners']} | {g['group_phase']} |\n"
findings+='''
能确认的事实：

1. 第81步提出共享父区域，估计坐标约`(607.28, -286.20)`，最后5机均接受。同一共享根点问题已经解决，但点位靠近初始区域，不是经过验证的首次分叉点。
2. 0、2、4号3240步开始，3号3277步开始；分别在3360、3354、3381、4101步退出。退出意味着当前网格检查连续拒绝连接、原寻路未提供可用连接，不等于真实地图上没有路。
3. 局部分组没有形成共同版本：0/2/4保存`[0,2,4]`，1号保存`[1,2]`，3号保存`[0,2,3,4]`；2号同时出现在不同组。0号的局部点约`(393,-346)`，2/4号约`(540,-441)`。这是实现没有闭合的地方，不是“仿真随机”解释。
4. 4171步0/4号互收冻结快照，4173步互收候选位图，4172～4175步收到对应实际保存收据。实际载荷校验与去重路径在本局确实工作，但发生在返航退出后，不是完整A/B/C会合。
5. 1号4447步才确认末弹，被预算检查拒绝返航；4447步冻结快照、4451步形成候选，但没有送到其他机。0号最后仍把1号库存记录为`(2832,1)`、3号为`(2804,1)`，普通交图条件不成立。
6. 全队没有形成择图提案，旧三道等待的绕过在本局没有实际触发。4970步使用原墙钟硬兜底；最佳图候选选择只通过合成反例，不能声称已获本局实战验证。
7. 前3237个记录帧与原版一致；首个轨迹差异在记录帧3238，约对应3241步，符合60%后接管。9枚实际落点与原版相同，只有1号末弹由原版`(-208.90,-440.23)`改为`(-127.85,276.53)`，实际生成步数从4026变4446。这说明源码保留投放复核，并未保证投放时序及落点不受间接影响。

推测及证据边界：

- 历史路径与当前网格/定位不一致可能造成短连接被拒绝，但现有观察未保存各次失败的网格局部状态，不能断言是哪一堵墙或哪项定位误差导致。
- 涨分同时伴随轨迹、通信、地图证据及1号末弹位置变化，不能把全部收益归给快照交付。墙覆盖分上涨与实际弹布局变化相符，但没有做隔离消融。
- 1号位置约3289步开始偏离；当时其余机在真实位置上均距它485px以上，不能直接归因为当场被其他机挤挡。原算法含墙钟门槛和按墙钟预算求解，精确因果仍未隔离。
'''
recommendation='''**目前不建议把它作为“加速版”替换原版。** 本次红队小计提高5.399分，但交图晚450步、1号末弹晚420步，且完整会合和择图没有发生；单种子涨分不能代替机制验收。

后续如继续，应优先补齐“同组成员与同一A/B点的共同确认”，再查清历史路径为何被当前连接检查拒绝；不要先叠加更多超时、几何阈值或扩大多图测试。当前候选和失败证据原样保留，本轮不做测试后的算法改动或追加仿真。
'''
text=(r/'README.template.md').read_text(encoding='utf-8').replace('<!-- RESULT_TABLE -->',table).replace('<!-- GROUP_FINDINGS -->',findings).replace('<!-- RECOMMENDATION -->',recommendation)
(dest/'README.md').write_text(text,encoding='utf-8')
shutil.copyfile(r/'candidate_snapshot.zip',dest/'CANDIDATE_SOURCE.zip')
for n in ['red_hooks.py','fast_closeout.py','exchange_plan.py','group_exchange.py','map_candidates.py']:
    shutil.copyfile(r/'candidate'/n,dest/n)
for n in ['group_exchange.patch','OFFLINE_CHECK.json']:shutil.copyfile(r/n,dest/n)
for n in ['counterexamples.json','VALIDATION.json']:shutil.copyfile(r/'received'/n,dest/n)
checks={p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(dest.iterdir()) if p.name!='CHECKSUMS_SHA256.json'}
(dest/'CHECKSUMS_SHA256.json').write_text(json.dumps(checks,indent=2)+'\n')
assert len(list(dest.iterdir()))==14
assert checks['CANDIDATE_SOURCE.zip']==data['candidate_build']['candidate_zip_sha256']
assert all(sha256((r/'candidate'/n).read_bytes()).hexdigest()==v for n,v in data['candidate_build']['candidate_files'].items())
assert text.count('```')%2==0 and '<!--' not in text
with ZipFile(dest/'RUN_EVIDENCE.zip') as z:assert z.testzip() is None
print(json.dumps(dict(files=14,score=c['partial_score_out_of_80'],delta=d['partial_score_out_of_80'],
                     full_group_rendezvous=False,source_unchanged_after_match=True),indent=2))
