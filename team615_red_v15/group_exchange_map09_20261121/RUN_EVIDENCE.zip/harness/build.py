from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
import json,shutil,subprocess,ast

r=Path(__file__).resolve().parent
source=r.parent/'team615_messenger_batch1_20261121/original.zip'
if not (r/'original.zip').exists():shutil.copyfile(source,r/'original.zip')
with ZipFile(r/'original.zip') as z:old={n:z.read(n) for n in z.namelist()}
new={p.name:p.read_bytes() for p in (r/'candidate').iterdir() if p.is_file()}
changed=sorted(n for n in old if new[n]!=old[n]);added=sorted(set(new)-set(old))
assert set(changed)=={'red_hooks.py','fast_closeout.py'}
assert set(added)=={'exchange_plan.py','group_exchange.py','map_candidates.py'}
assert all((r/'baseline'/n).read_bytes()==b for n,b in old.items())
for name,blob in new.items():
    if name.endswith('.py'):compile(blob,name,'exec')
def methods(blob, cls):
    tree=ast.parse(blob)
    c=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==cls)
    return {n.name:ast.dump(n,include_attributes=False) for n in c.body if isinstance(n,ast.FunctionDef)}
method_changes={}
for name,cls in [('red_hooks.py','RedHooks'),('fast_closeout.py','FastCloseout')]:
    a,b=methods(old[name],cls),methods(new[name],cls)
    method_changes[name]=dict(changed=[n for n in a if a[n]!=b[n]],added=sorted(set(b)-set(a)))
assert method_changes['fast_closeout.py']['changed']==['submit']
assert set(method_changes['red_hooks.py']['changed'])=={'__init__','receive','define_message_for_all','_submission_image','control'}
with ZipFile(r/'candidate_snapshot.zip','w',ZIP_DEFLATED) as z:
    for name,blob in sorted(new.items()):
        info=ZipInfo(name,date_time=(2026,11,21,0,0,0));info.compress_type=ZIP_DEFLATED;z.writestr(info,blob)
h=lambda b:sha256(b).hexdigest()
b=dict(status='PASS',baseline_zip_sha256=h((r/'original.zip').read_bytes()),candidate_zip_sha256=h((r/'candidate_snapshot.zip').read_bytes()),
       baseline_member_count=len(old),candidate_member_count=len(new),changed_existing_files=changed,added_files=added,
       unchanged_files=len(old)-len(changed),method_changes=method_changes,
       original_files={n:h(v) for n,v in old.items()},candidate_files={n:h(v) for n,v in new.items()},
       package_role='research test snapshot; not an official competition release')
(r/'BUILD.json').write_text(json.dumps(b,indent=2)+'\n')
diff=subprocess.run(['git','-c','core.autocrlf=false','diff','--no-index','--','baseline','candidate'],cwd=r,capture_output=True)
assert diff.returncode==1
patch=diff.stdout.replace(b'a/baseline/',b'a/').replace(b'b/candidate/',b'b/').replace(b'a/candidate/',b'a/')
(r/'group_exchange.patch').write_bytes(patch)
p=subprocess.run(['git','apply','--check',str(r/'group_exchange.patch')],cwd=r/'baseline',capture_output=True)
assert p.returncode==0,p.stderr
print(json.dumps({k:v for k,v in b.items() if k not in ('original_files','candidate_files')},indent=2))
