from pathlib import Path,PurePosixPath
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json,subprocess,math
import numpy as np

r=Path(__file__).resolve().parent
remote=(r/'SERVER_STAGE.txt').read_text().strip()
host='quanliangwen@10.112.162.60'
received=r/'received';received.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()

def download(names,dest):
    dest.mkdir(parents=True,exist_ok=True)
    subprocess.run(['scp','-q','-o','BatchMode=yes',*[f'{host}:{n}' for n in names],str(dest)],check=True)

names=['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','placement_events.jsonl',
       'run.log','dispatch.log','wall_geometry.npz','counterexamples.json','counterexamples.log',
       'VALIDATION.json','validation.log','static_candidate.log']
download([f'{remote}/{n}' for n in names],received)
end=read(received/'FINISH.json');official=PurePosixPath(end['result_dir'])
assert official.is_relative_to(PurePosixPath(remote)/'official_sdk/results_swarm_rescue')
for name,checksum in end['files'].items():
    p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts
    download([str(official/p)],received/'official'/p.parent)
    assert h(received/'official'/name)==checksum

b=read(r/'BUILD.json');s=read(received/'OFFICIAL_SCORE.json');start=read(received/'START.json')
assert read(received/'VALIDATION.json')['candidate_zip_sha256']==b['candidate_zip_sha256']
assert h(r/'candidate_snapshot.zip')==b['candidate_zip_sha256']
assert all(h(r/'candidate'/n)==v for n,v in b['candidate_files'].items())
assert start['solutions_sha256']==read(received/'SOURCE_MATCH.json')['candidate']==b['candidate_files']
assert [start[k] for k in ['seed','sdk','map_name','drones','bombs_per_drone','timestep_limit','walltime_limit','competition_mode']]==[
    615,'6557940dc18549ffc7a945db887da5b05b7ed2f1','Map09',5,2,5400,180,True]
assert start['spawn']==read(r/'matched_spawns.json')['Map09']
assert start['zones']==read(r/'EXPECTED_ZONES.json')['Map09']
assert [end[k] for k in ['status','completed_red_rounds','blue_rounds','layout_evaluations']]==['COMPLETE',1,0,0]
assert h(received/'placement_events.jsonl')==s['placement_events_sha256']
assert h(received/'wall_geometry.npz')==s['wall_geometry_sha256']
dispatch=(received/'dispatch.log').read_text(encoding='utf-8')
assert dispatch.count('START Map09 group_exchange seed615')==1
assert dispatch.count('COMPLETE Map09 group_exchange seed615')==1
assert math.isclose(s['partial'],.5*s['map_score']+.2*s['coverage']+.1*s['time_score'],abs_tol=1e-8)

def summary(score,folder):
    breakdown=score['map_breakdown']
    layout=read(next((folder/'official').glob('*bombs.json')))['bombs']
    assert len(layout)==score['placed']
    return dict(map_score=score['map_score'],partial_score_out_of_80=score['partial'],wall_score=score['coverage'],
        time_score=score['time_score'],exploration_percent=score['trajectory'],
        missed_wall_pixels=breakdown['wall_pixels']-breakdown['wall_hits'],charged_misdraw_pixels=breakdown['charged_pixels'],
        map_breakdown=breakdown,submission_step=score['steps'],selected_submission=score['selected_submission'],
        placed=score['placed'],total_health_lost=sum(25-d['health'] for d in score['drone_details']),
        elapsed_walltime_seconds=score['elapsed_walltime'],
        per_drone_last_confirmation={str(d['drone']):d['last_confirmation'] for d in score['drone_details']},
        per_drone_health={str(d['drone']):d['health'] for d in score['drone_details']},
        deadline_events={str(d['drone']):d['walltime_submission'] for d in score['drone_details']})

old=r.parent/'team615_messenger_batch1_20261121/received/Map09_baseline'
old_score=read(old/'OFFICIAL_SCORE.json')
o,c=summary(old_score,old),summary(s,received)
old_single=read(r.parent/'team615_return60_map09_20261121/delivery/RESULTS.json')['runs']['candidate']
fields=['partial_score_out_of_80','map_score','wall_score','time_score','exploration_percent',
        'missed_wall_pixels','charged_misdraw_pixels','submission_step','placed','total_health_lost','elapsed_walltime_seconds']
delta={k:c[k]-o[k] for k in fields}
prefix={}
a=np.load(next((old/'official/recordings').glob('*.npz')))
z=np.load(next((received/'official/recordings').glob('*.npz')))
for key in ['drone_states','bomb_states']:
    av,cv=a[key],z[key];n=min(len(av),len(cv));equal=np.ones(n,bool)
    for field in av.dtype.names:equal&=(av[field][:n]==cv[field][:n]).reshape(n,-1).all(1)
    different=np.flatnonzero(~equal)
    prefix[key]=dict(original_frames=len(av),candidate_frames=len(cv),
        first_different_frame=None if not different.size else int(different[0]),
        first_3237_frames_equal=bool(equal[:min(3237,n)].all()))

group={}
for d in s['drone_details']:
    i=str(d['drone']);audit=d['group_audit'];packets=d['group_candidate_audit']
    group[i]={k:v for k,v in d.items() if k.startswith('group_') and k not in ('group_final_trail',)}
    group[i]['stored_payloads']=[x for x in packets if x[1]=='payload_stored']
    group[i]['navigation_return_tasks']=sum(x[1]=='return_owned' for x in audit)
    group[i]['courier_to_C_tasks']=sum(x[1]=='courier_to_C' for x in audit)
    group[i]['actual_snapshot_owners']=[row[1] for row in d['group_manifest'] if row[0]=='snapshot']
    group[i]['actual_image_owners']=[row[1] for row in d['group_manifest'] if row[0]=='image']

result=dict(status='COMPLETE',map='Map09',seed=615,new_red_rounds=1,historical_original_rounds=1,
    blue_rounds=0,additional_maps_tested=[],source_frozen_during_match=True,candidate_build=b,
    validation=read(received/'VALIDATION.json'),counterexamples=read(received/'counterexamples.json'),
    original=o,previous_single_hub_candidate={k:old_single[k] for k in fields},candidate=c,
    candidate_minus_original=delta,score_contribution_changes={
        'map':.5*delta['map_score'],'wall':.2*delta['wall_score'],'time':.1*delta['time_score']},
    recorded_prefix=prefix,group_details=group,offline_budget=read(r/'OFFLINE_CHECK.json'),
    limitations=['One seed, one new Map09 round, historical baseline; not a statistical improvement claim.',
                'Red-side 80-point subtotal only; blue-side 20 points unmeasured.',
                'Wall-clock is load-sensitive; unchanged source does not imply unchanged placement timing.'])
assert abs(sum(result['score_contribution_changes'].values())-delta['partial_score_out_of_80'])<1e-8
dest=r/'delivery';dest.mkdir(exist_ok=True)
(dest/'RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with ZipFile(dest/'RUN_EVIDENCE.zip','w',ZIP_DEFLATED) as out:
    for p in sorted(received.rglob('*')):
        if p.is_file():out.write(p,'candidate/'+p.relative_to(received).as_posix())
    for n in ['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','placement_events.jsonl','wall_geometry.npz']:
        out.write(old/n,'historical_original/'+n)
    for n in ['BUILD.json','OFFLINE_CHECK.json','OBSERVATION_BINDING.json','DECLARED_SOURCE.json',
              'PATCH_BINDING.json','stage_run.py','run_once.sh','counterexamples.py','validate.py','build.py','collect.py',
              'place_map09.yml','matched_spawns.json','EXPECTED_ZONES.json']:
        out.write(r/n,'harness/'+n)
print(json.dumps(dict(original=o,candidate=c,delta=delta,prefix=prefix,
    group_summary={i:{'root':v['group_root'],'acks':v['group_root_acks'],'branch':v['group_branch'],
        'start':v['group_started'],'phase':v['group_phase'],'snapshots':v['actual_snapshot_owners'],
        'images':v['actual_image_owners'],'returns':v['navigation_return_tasks'],
        'stored_payloads':len(v['stored_payloads']),'events':v['group_audit']} for i,v in group.items()}),indent=2))
