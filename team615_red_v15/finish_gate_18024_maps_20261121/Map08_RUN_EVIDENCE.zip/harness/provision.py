from pathlib import Path
from hashlib import sha256
import json, shutil, subprocess

r=Path(__file__).resolve().parent
prior=r.parent/'team615_partial_selection_batch1_20261121'
candidate=r.parent/'team615_finish_gate_18024_20261121'
remote='/home/quanliangwen/isolated_test/team615_finish_gate_maps_yJt1u7'
host='quanliangwen@10.112.162.60'
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
b=read(candidate/'BUILD.json');v=read(candidate/'received/VALIDATION.json');c=read(candidate/'received/counterexamples.json')
assert b['candidate_zip_sha256']==v['candidate_zip_sha256']==c['archive_sha256']==h(candidate/'candidate_snapshot.zip')
assert c['scenario_groups']==69 and c['status']==v['status']=='PASS'
assert h(candidate/'baseline_snapshot.zip')==b['baseline_zip_sha256']==h(prior/'candidate_snapshot.zip')
(r/'SERVER_STAGE.txt').write_text(remote+'\n')
for n in ['candidate_snapshot.zip','baseline_snapshot.zip','BUILD.json']:
    shutil.copyfile(candidate/n,r/n)
for n in ['VALIDATION.json','counterexamples.json']:
    shutil.copyfile(candidate/'received'/n,r/n)
for n in ['matched_spawns.json','EXPECTED_ZONES.json']:
    shutil.copyfile(prior/n,r/n)
patch=dict(baseline_commit='f50cfe99aa69ed9fe70755b259e1b9f33057aa90',baseline_zip_sha256=b['baseline_zip_sha256'],
    candidate_zip_sha256=b['candidate_zip_sha256'],baseline=b['original_files'],candidate=b['candidate_files'],changed=b['changed_existing_files'])
(r/'PATCH_BINDING.json').write_text(json.dumps(patch,indent=2)+'\n')
(r/'DECLARED_SOURCE.json').write_text(json.dumps(b['candidate_files'],indent=2)+'\n')
(r/'OFFLINE_CHECK.json').write_text(json.dumps(dict(simulation_steps=0,unit_groups=69,
    validation_sha256=h(r/'VALIDATION.json')))+'\n')
# Copy the existing observing harness without altering in-match callbacks.
shutil.copyfile(prior/'stage_run.py',r/'stage_run.py')
for name in ['Map08','Map09']:
    folder=r/name;folder.mkdir(exist_ok=False)
    for n in ['stage_run.py','candidate_snapshot.zip','baseline_snapshot.zip','DECLARED_SOURCE.json','PATCH_BINDING.json',
              'BUILD.json','VALIDATION.json','counterexamples.json','matched_spawns.json','EXPECTED_ZONES.json','OFFLINE_CHECK.json']:
        shutil.copyfile(r/n,folder/n)
    shutil.copyfile(prior/name/'place_map09.yml',folder/'place_map09.yml')
    run=(prior/name/'run_once.sh').read_text().replace('partial_selection','finish_gate_18024')
    (folder/'run_once.sh').write_text(run,encoding='utf-8',newline='\n')
    (folder/'OBSERVATION_BINDING.json').write_text(json.dumps(dict(observer_sha256=h(folder/'stage_run.py'),
        identical_to_previous_observer=h(folder/'stage_run.py')==h(prior/'stage_run.py'),map=name,seed=615,
        controller_frozen_sha256=b['candidate_zip_sha256'],new_red_rounds_authorized=1),indent=2)+'\n')
    subprocess.run(['ssh','-o','BatchMode=yes',host,f'mkdir {remote}/{name}'],check=True)
    subprocess.run(['scp','-q','-o','BatchMode=yes',*[str(p) for p in folder.iterdir()],f'{host}:{remote}/{name}/'],check=True)
shutil.copyfile(prior/'dispatch.sh',r/'dispatch.sh')
subprocess.run(['scp','-q','-o','BatchMode=yes',str(r/'dispatch.sh'),f'{host}:{remote}/'],check=True)
command=f'nohup bash {remote}/dispatch.sh {remote} > {remote}/queue.log 2>&1 < /dev/null & echo QUEUED'
p=subprocess.run(['ssh','-o','BatchMode=yes',host,command],capture_output=True,check=True,timeout=30)
print(p.stdout.decode());print(b['candidate_zip_sha256'])
