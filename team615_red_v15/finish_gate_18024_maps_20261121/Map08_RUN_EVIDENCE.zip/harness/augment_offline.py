from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import argparse,json,subprocess

r=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('map',choices=['Map08','Map09']);name=p.parse_args().map
remote=(r/'SERVER_STAGE.txt').read_text().strip()+'/'+name
received=r/name/'received'
names=['OFFLINE_MAP_SCORES.json','offline_score.log','offline_map_score.py']
subprocess.run(['scp','-q','-o','BatchMode=yes',*[f'quanliangwen@10.112.162.60:{remote}/{n}' for n in names],str(received)],check=True)
s=json.loads((received/'OFFLINE_MAP_SCORES.json').read_bytes())
assert s['status']=='PASS' and s['physics_steps']==s['physics_step_attempts']==s['full_matches']==0
path=r/name/'RESULTS.json';result=json.loads(path.read_bytes())
assert s['actual_map_score']==result['arms']['candidate']['map_score']
result['offline_map_scores']=s
path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with ZipFile(r/name/'RUN_EVIDENCE.zip','a',ZIP_DEFLATED) as z:
    for n in names:z.write(received/n,'candidate/'+n)
    z.write(r/'augment_offline.py','harness/augment_offline.py')
print(json.dumps(dict(map=name,actual_score=s['actual_map_score'],best_saved_score=s['best_saved_candidate']['map_score'],
    best_saved_holder=s['best_saved_candidate']['holder'],best_saved_slot=s['best_saved_candidate']['slot'],physics_steps=0),indent=2))
