from pathlib import Path
r=Path(__file__).resolve().parent
p=r.parent/'team615_partial_selection_batch1_20261121'
s=(p/'collect.py').read_text(encoding='utf-8')
s=s.replace("f'START {name} partial_selection seed615'", "f'START {name} finish_gate_18024 seed615'")
s=s.replace("f'COMPLETE {name} partial_selection seed615'", "f'COMPLETE {name} finish_gate_18024 seed615'")
s=s.replace("primordial=read(r.parent", "batch_final=r.parent/'team615_partial_selection_batch1_20261121'/name/'received'\nthree_build=read(r.parent/'team615_partial_selection_batch1_20261121/BUILD.json')\nprimordial=read(r.parent")
s=s.replace("current=summary(verify_history(current,b['original_files']),current),candidate=summary(score,received))", "current=summary(verify_history(current,three_build['original_files']),current),\n          batch_final=summary(verify_history(batch_final,b['original_files']),batch_final),candidate=summary(score,received))")
s=s.replace("for arm in ['original','current']", "for arm in ['original','current','batch_final']")
s=s.replace("[('original',original),('current',current)]", "[('original',original),('current',current),('batch_final',batch_final)]")
s=s.replace("historical_red_rounds=2", "historical_red_rounds=3")
s=s.replace("for n in ['collect.py','counterexamples.py','validate.py','build.py']", "for n in ['collect.py','provision.py','prepare_collect.py']")
compile(s,'collect.py','exec')
(r/'collect.py').write_text(s,encoding='utf-8')
print('Collector prepared for 4 source-verified arms.')
