"""Score saved post-match candidates only; no map creation or physics."""
from pathlib import Path
import json,sys,math
import numpy as np

stage=Path.cwd();sys.path.insert(0,str(stage/'official_sdk/src'))
import pymunk
attempts=0
def no_physics(*args,**kwargs):
    global attempts
    attempts+=1
    raise AssertionError('offline scorer must not step physics')
pymunk.Space.step=no_physics
from swarm_rescue.simulation.reporting.place_score_manager import PlaceScoreManager
manager=PlaceScoreManager()
official=json.loads((stage/'OFFICIAL_SCORE.json').read_bytes())
meta=json.loads((stage/'GROUP_DATASET.json').read_bytes());data=np.load(stage/'group_dataset.npz')
truth=np.load(stage/'wall_geometry.npz')['walls']
rows=[]
for holder,info in meta.items():
    for slot,entry in info['images'].items():
        key=f'd{holder}_image{slot}'
        bitmap=np.unpackbits(data[key])[:info['width']*info['height']].reshape(info['height'],info['width']).astype(np.uint8)
        result=manager.compute_map_score(truth,bitmap,elapsed_walltime=official['elapsed_walltime'],max_walltime_limit=180)
        assert result.error is None,result.error
        rows.append(dict(holder=int(holder),slot=int(slot),version=entry['version'],digest=entry['digest'],
            map_score=result.score,breakdown=result.breakdown))
selected=official['selected_submission']['drone']
info=meta[str(selected)];packed=data[f'd{selected}_selected_cache']
bitmap=np.unpackbits(packed)[:info['width']*info['height']].reshape(info['height'],info['width']).astype(np.uint8)
result=manager.compute_map_score(truth,bitmap,elapsed_walltime=official['elapsed_walltime'],max_walltime_limit=180)
assert math.isclose(result.score,official['map_score'],abs_tol=1e-8),(result.score,official['map_score'])
summary=dict(status='PASS',scope='Post-match official map scorer on saved candidates; truth never exposed to controller.',
    full_matches=0,physics_steps=0,physics_step_attempts=attempts,selected_submission_reproduced=True,
    actual_map_score=official['map_score'],candidates=rows,
    best_saved_candidate=max(rows,key=lambda v:v['map_score']))
(stage/'OFFLINE_MAP_SCORES.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(selected=official['selected_submission'],actual_map_score=official['map_score'],
    rows=[{k:v for k,v in row.items() if k!='breakdown'} for row in rows],physics_steps=0),indent=2))
