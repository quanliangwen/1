from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json
import numpy as np
r=Path(__file__).resolve().parent;d=r/'delivery'
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
proof={}
b=read(r/'BUILD.json');result=read(d/'RESULTS.json')
assert h(d/'CANDIDATE_SOURCE.zip')==h(r/'candidate_snapshot.zip')==b['candidate_zip_sha256']
assert h(d/'CANDIDATE_SOURCE.zip')==h(r.parent/'team615_finish_gate_18024_20261121/delivery/CANDIDATE_SOURCE.zip')
assert result['configuration']['new_red_rounds']==2 and result['configuration']['maps']==['Map08','Map09']
assert result['configuration']['other_maps_run']==0 and not result['configuration']['candidate_modified_during_this_task']
meta=read(r/'Map08/received/GROUP_DATASET.json')['1'];a=np.load(r/'Map08/received/group_dataset.npz')
image=np.unpackbits(a['d1_image5'])[:meta['width']*meta['height']].reshape(meta['height'],meta['width']).astype(np.uint8)
image_hash=sha256(image.tobytes()).hexdigest()
assert image_hash==result['maps']['Map08']['arms']['current']['selected_submission']['image_sha256']
proof['Map08_new_1_image_equals_previous_three_map_submission']=dict(sha256=image_hash,verified=True)
s8=read(r/'Map08/received/OFFICIAL_SCORE.json');s9=read(r/'Map09/received/OFFICIAL_SCORE.json')
assert [(s['drone'],s['step']) for s in s8['submissions']]==[(0,3448),(1,3448)]
assert s8['selected_submission']['drone']==0
proof['Map08_simultaneous_submitters_and_selected']=dict(submitters=[0,1],step=3448,selected=0)
count=sum(e[1] in ('finish_candidate_refreshed','choice_proposed','submitted','soft_cutoff_submit') for drone in s9['drone_details'] for e in drone['group_audit'])
assert count==0
assert s9['selected_image_sha256']==result['maps']['Map09']['arms']['batch_final']['selected_submission']['image_sha256']
assert all(v['fallback']=='walltime' for v in result['maps']['Map09']['arms']['candidate']['deadline_events'].values())
proof['Map09_same_actual_image_as_batch_final']=dict(sha256=s9['selected_image_sha256'],verified=True,
    ordinary_finish_refresh_proposal_submit_count=0,all_fallbacks_walltime=True)
for name in ['Map08','Map09']:
    assert read(r/name/'received/POST_RUN_SOURCE_CHECK.json')['status']=='PASS'
    with ZipFile(d/f'{name}_RUN_EVIDENCE.zip') as z:assert z.testzip() is None
    assert result['maps'][name]['personal_original_integrity']['status']=='PASS'
with ZipFile(d/'CANDIDATE_SOURCE.zip') as z:assert z.testzip() is None
readme=(d/'README.md').read_text(encoding='utf-8');assert '<!-- FINDINGS -->' not in readme
result['fact_checks']=proof
(d/'RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(r/'FACT_CHECK.json').write_text(json.dumps(dict(status='PASS',proof=proof),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with ZipFile(d/'HARNESS.zip','a',ZIP_DEFLATED) as z:
    z.write(r/'finalize.py','finalize.py');z.write(r/'FACT_CHECK.json','FACT_CHECK.json')
files={p.name:h(p) for p in sorted(d.iterdir()) if p.name!='CHECKSUMS_SHA256.json'}
assert len(files)==14,len(files)
(d/'CHECKSUMS_SHA256.json').write_text(json.dumps(files,indent=2)+'\n')
print(json.dumps(dict(status='PASS',delivery_files=len(files)+1,sizes={p.name:p.stat().st_size for p in d.iterdir()},proof=proof),indent=2))
