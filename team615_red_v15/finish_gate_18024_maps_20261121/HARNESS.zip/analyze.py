from pathlib import Path
import json
r=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
out={}
for name in ['Map08','Map09']:
    if not (r/name/'RESULTS.json').exists():continue
    data=read(r/name/'RESULTS.json');s=read(r/name/'received/OFFICIAL_SCORE.json')
    details={}
    for d in s['drone_details']:
        keep={'finish_candidate_refreshed','choice_proposed','submitted','soft_cutoff_submit','coord_cutoff'}
        details[str(d['drone'])]=dict(phase=d['group_phase'],choice=d['group_choice'],best=d['group_best_metadata'],
            last_compare=d['group_last_comparison_step'],finish_events=[e for e in d['group_audit'] if e[1] in keep],
            first_compare=next((e for e in d['group_audit'] if e[1]=='available_candidates_compared'),None),
            comparison_count=sum(e[1]=='available_candidates_compared' for e in d['group_audit']),
            candidate_events=[e for e in d['group_candidate_audit'] if e[1] in ('best_retained','previous_best_retained','live_remembered')],
            deadline=d['walltime_submission'],last_confirmation=d['last_confirmation'],health=d['health'],
            inventory_records=d['final_inventory_records'],score_table=d['group_score_table'])
    out[name]=dict(arms=data['arms'],candidate_minus=data['candidate_minus'],recorded_prefix=data['recorded_prefix'],
        details=details,submissions=s['submissions'],offline=data.get('offline_map_scores'))
(r/'ANALYSIS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({name:dict(arms={a:{k:v[k] for k in ['submission_step','partial_score_out_of_80','map_score','missed_wall_pixels','charged_misdraw_pixels','exploration_percent','placed','total_health_lost','elapsed_walltime_seconds']} for a,v in d['arms'].items()},
    selected=d['submissions'],events={a:v['finish_events'] for a,v in d['details'].items()}) for name,d in out.items()},indent=2))
