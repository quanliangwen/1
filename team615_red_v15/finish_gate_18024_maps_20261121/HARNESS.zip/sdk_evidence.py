from pathlib import Path
from hashlib import sha256
import json,subprocess
r=Path(__file__).resolve().parent
remote=(r/'SERVER_STAGE.txt').read_text().strip()+'/Map08/official_sdk/src/swarm_rescue/'
rows=[]
for rel,first,last in [('launcher.py',494,503),('simulation/gui_map/gui_sr.py',367,389)]:
    dest=r/('SDK_'+Path(rel).name)
    subprocess.run(['scp','-q','-o','BatchMode=yes','quanliangwen@10.112.162.60:'+remote+rel,str(dest)],check=True)
    data=dest.read_bytes()
    rows.append(dict(path='src/swarm_rescue/'+rel,sha256=sha256(data).hexdigest(),first_line=first,last_line=last,
        excerpt='\n'.join(data.decode().splitlines()[first-1:last])))
result=dict(sdk_commit='6557940dc18549ffc7a945db887da5b05b7ed2f1',read_only=True,
    selection='Launcher takes the first drone with a non-None submission in map drone order; it does not score all simultaneous submissions and pick the best.',
    termination='GUI runs all drivable drone controls for the frame, then terminates if any submitted. Multiple submissions in the same step are possible.',files=rows)
(r/'SDK_SELECTION_EVIDENCE.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
