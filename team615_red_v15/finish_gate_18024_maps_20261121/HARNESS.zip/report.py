from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json,shutil
r=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
maps={name:read(r/name/'RESULTS.json') for name in ['Map08','Map09']}
b=read(r/'BUILD.json');v=read(r/'VALIDATION.json');tests=read(r/'counterexamples.json')
assert b['candidate_zip_sha256']==v['candidate_zip_sha256']==tests['archive_sha256']==h(r/'candidate_snapshot.zip')
assert read(r/'HISTORY_AUDIT.json')['status']=='PASS'
for name,result in maps.items():
    assert result['new_red_rounds']==1 and result['historical_red_rounds']==3
    assert result['candidate_zip_sha256']==b['candidate_zip_sha256']
    assert result['post_run_source_check']['status']==result['personal_original_integrity']['status']=='PASS'
    assert result['offline_map_scores']['selected_submission_reproduced']
    for delta in result['candidate_minus'].values():
        assert abs(.5*delta['map_score']+.2*delta['wall_score']+.1*delta['time_score']-delta['partial_score_out_of_80'])<1e-8
config=dict(seed=615,maps=['Map08','Map09'],new_red_rounds=2,historical_comparison_red_rounds=6,
    blue_rounds=0,other_maps_run=0,serial=True,sdk_commit='6557940dc18549ffc7a945db887da5b05b7ed2f1',
    drones=5,bombs_per_drone=2,timestep_limit=5400,walltime_limit=180,zones=['NO_COM_ZONE','NO_GPS_ZONE'],
    candidate_zip_sha256=b['candidate_zip_sha256'],baseline_zip_sha256=b['baseline_zip_sha256'],
    candidate_modified_during_this_task=False,in_match_observer_identical_to_previous_batch=True,
    source_frozen_and_rechecked_after_both_matches=True)
result=dict(status='COMPLETE',configuration=config,maps=maps,history_audit=read(r/'HISTORY_AUDIT.json'),
    sdk_selection_evidence=read(r/'SDK_SELECTION_EVIDENCE.json'),
    limitations=['Only two new candidate rounds, one per requested map; other three versions reuse same-seed historical rounds.',
        'Reported total is red-side subtotal out of 80; blue-side 20 was not tested.',
        'Wall-clock runtime and wall-budgeted decisions depend on machine load; historical runs are not paired runtime benchmarks.',
        'Online ranking uses observed evidence. Post-match truth scores are not supplied to controller.',
        'Single-seed results do not establish stable gains across seeds.'])
dest=r/'delivery';dest.mkdir(exist_ok=True)
(dest/'RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
arms=['original','current','batch_final','candidate']
labels={'original':'潜力1.1原版','current':'上一版三图候选','batch_final':'本批最终版','candidate':'180＋24候选'}
metrics=[('实际交图步数','submission_step',0),('红队小计 / 80','partial_score_out_of_80',4),
    ('地图分 / 100','map_score',4),('墙覆盖分 / 100','wall_score',4),('漏墙像素','missed_wall_pixels',0),
    ('扣分误画像素','charged_misdraw_pixels',0),('探索率 / %','exploration_percent',4),('实投数 / 10','placed',0),
    ('总掉血 / 初始125','total_health_lost',0),('墙钟 / 秒','elapsed_walltime_seconds',3)]
lines=['# 180＋24步留时：Map08、Map09种子615对照','',
    '本轮只对冻结的180＋24步候选各跑一次Map08、Map09，共2局红队。其余三个版本复用经过源码、SDK、出生位置、禁区配置与原始产物哈希核验的同种子历史结果。没有改算法，也没有运行其他地图。','',
    '红队小计满分80；蓝队20分未测。漏墙为官方墙像素数减命中数；误画为官方charged_pixels（实际扣分的误画像素），不含全部预测墙。墙钟采用官方评分记录的elapsed_walltime。','',
    '## 四版来源','',
    '| 版本 | SHA256 |','|---|---|',
    f"| 本次180＋24候选 | `{b['candidate_zip_sha256']}` |",
    f"| 本批最终版 | `{b['baseline_zip_sha256']}` |",
    '| 上一版三图候选 | `641685d7bd460f6241abb4e2c0f02527d7324a37d78f6492401d66a4b6a63cda` |',
    '| 潜力1.1原版 | 按已有START.json逐成员与原版构建清单一致核验；详见HISTORY_AUDIT.json和证据包 |','',
    '本次候选与上一轮已发布的候选逐字节一致。原有69组反例和静态验证回执随包保留，本轮没有重新修改或重跑这些测试。SDK为6557940dc18549ffc7a945db887da5b05b7ed2f1；5机、每机2枚、5400步、180秒，NO_COM_ZONE和NO_GPS_ZONE同时开启。','']
for name,data in maps.items():
    lines += [f'## {name}','','| 指标 | '+' | '.join(labels[a] for a in arms)+' |', '|---|---:|---:|---:|---:|']
    for label,key,prec in metrics:
        lines.append('| '+label+' | '+' | '.join(f"{data['arms'][a][key]:.{prec}f}" for a in arms)+' |')
    lines += ['| 实际选中交图机 | '+' | '.join(str(data['arms'][a]['selected_submission']['drone'])+'号' for a in arms)+' |','',
        '本次候选相对三个对照的差值（候选减对照；漏墙/误画/掉血越少越好）：','',
        '| 对照 | 交图步数Δ | 小计Δ | 地图分Δ | 漏墙Δ | 误画Δ | 墙钟Δ秒 |','|---|---:|---:|---:|---:|---:|---:|']
    for a in arms[:-1]:
        d=data['candidate_minus'][a]
        lines.append(f"| {labels[a]} | {d['submission_step']:+.0f} | {d['partial_score_out_of_80']:+.4f} | {d['map_score']:+.4f} | {d['missed_wall_pixels']:+.0f} | {d['charged_misdraw_pixels']:+.0f} | {d['elapsed_walltime_seconds']:+.3f} |")
    lines += ['', '本次候选交图与缓存事件：','',
        '| 无人机 | 首次比较 | 最后比较 | 最终重比绘图 | 实际分组交图 | 最后实投确认 | 结束血量 |','|---|---:|---:|---|---|---:|---:|']
    score=read(r/name/'received/OFFICIAL_SCORE.json')
    for d in score['drone_details']:
        comparisons=[e for e in d['group_audit'] if e[1]=='available_candidates_compared']
        final=[e[0] for e in d['group_audit'] if e[1]=='finish_candidate_refreshed']
        submitted=[e[0] for e in d['group_audit'] if e[1] in ('submitted','soft_cutoff_submit')]
        lines.append(f"| {d['drone']}号 | {comparisons[0][0] if comparisons else '—'} | {d['group_last_comparison_step']} | {final} | {submitted} | {d['last_confirmation']} | {d['health']} |")
    lines += ['',f"个人原图完整性：{data['personal_original_integrity']['images_verified']}份持有记录校验PASS；比赛结束后56项源码重新核验PASS。实际提交图与所选缓存一致。",'']
    selected=score['selected_submission'];holder=next(d for d in score['drone_details'] if d['drone']==selected['drone'])
    lines += [f"选中交图机{selected['drone']}号的最终本地比较结果：`{json.dumps(holder['group_best_metadata'],ensure_ascii=False)}`。",'']
    offline=data['offline_map_scores']
    lines += [f"赛后使用保存位图复算官方地图分，已复现实际提交的{offline['actual_map_score']:.4f}分。保存候选中离线最高为{offline['best_saved_candidate']['map_score']:.4f}分（{offline['best_saved_candidate']['holder']}号持有、槽{offline['best_saved_candidate']['slot']}）。这仅用于诊断，不代表断联无人机能在比赛中取得该图。",'']
lines += ['## 结论与限制','', (r/'FINDINGS.md').read_text(encoding='utf-8').strip(),'',
    '本轮未改导航、扫描、地图拟合、投放复核或双时限兜底；实际运行前后源码哈希一致。个人原图和候选缓存完整性均已核验。','',
    '每图仅新增1局，三个对照是历史同种子结果。尤其Map09可能由墙钟兜底结束，负载变化会改变可运行步数与地图版本；不能把墙钟差异直接称为算法计算加速，也不能从单种子结果推断稳定提分。','',
    'CANDIDATE_SOURCE.zip为上轮冻结研究源码的原字节副本，不是新正式参赛发布包，未上传官网。两份RUN_EVIDENCE.zip含新局原始评分、轨迹、快照/候选、个人图校验、三版历史对照证据、SDK/源码绑定和运行采集脚本。ANALYSIS.json记录关键事件和在线候选评分；RESULTS.json包含完整四版指标与差值。']
(dest/'README.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
for name in maps:
    shutil.copyfile(r/name/'RESULTS.json',dest/f'{name}_RESULTS.json')
    shutil.copyfile(r/name/'RUN_EVIDENCE.zip',dest/f'{name}_RUN_EVIDENCE.zip')
for n in ['BUILD.json','VALIDATION.json','counterexamples.json','HISTORY_AUDIT.json','ANALYSIS.json','SDK_SELECTION_EVIDENCE.json']:
    shutil.copyfile(r/n,dest/n)
shutil.copyfile(r/'candidate_snapshot.zip',dest/'CANDIDATE_SOURCE.zip')
with ZipFile(dest/'HARNESS.zip','w',ZIP_DEFLATED) as z:
    for n in ['provision.py','prepare_collect.py','audit_history.py','stage_run.py','collect.py','analyze.py','report.py',
              'offline_map_score.py','augment_offline.py','dispatch.sh','SERVER_STAGE.txt','sdk_evidence.py','FINDINGS.md']:
        z.write(r/n,n)
print(json.dumps({name:dict(arms={a:{k:v[k] for k in ['partial_score_out_of_80','map_score','submission_step']} for a,v in d['arms'].items()},deltas=d['candidate_minus']) for name,d in maps.items()},indent=2))
