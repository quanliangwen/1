set -euo pipefail
root="$1"
bash "$root/Map08/run_once.sh" "$root/Map08" > "$root/Map08/dispatch.log" 2>&1
bash "$root/Map09/run_once.sh" "$root/Map09" > "$root/Map09/dispatch.log" 2>&1
printf 'COMPLETE BOTH MAPS\n'
