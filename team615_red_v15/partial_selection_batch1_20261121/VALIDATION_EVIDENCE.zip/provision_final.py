from pathlib import Path
from hashlib import sha256
import ast,json,shutil,subprocess

r=Path(__file__).resolve().parent
host='quanliangwen@10.112.162.60'
remote='/home/quanliangwen/isolated_test/team615_partial_final_3Z7SdN'
shutil.copyfile(r/'SERVER_STAGE.txt',r/'initial_trial/SERVER_STAGE.txt')
(r/'SERVER_STAGE.txt').write_text(remote+'\n')
b=json.loads((r/'BUILD.json').read_bytes());u=json.loads((r/'counterexamples.json').read_bytes());v=json.loads((r/'VALIDATION.json').read_bytes())
assert u['scenario_groups']==53 and u['status']==v['status']=='PASS'
assert u['archive_sha256']==v['candidate_zip_sha256']==b['candidate_zip_sha256']
assert sha256((r/'candidate_snapshot.zip').read_bytes()).hexdigest()==b['candidate_zip_sha256']
stage=(r/'stage_run.py').read_text(encoding='utf-8')
stage=stage.replace("metadata[owner]=dict(width=c.width,height=c.height,images={},snapshots={})", "metadata[owner]=dict(width=c.width,height=c.height,images={},snapshots={},live_version=c.live_version)")
stage=stage.replace("    for slot,data in c.images.items():", "    if c.live_image is not None:arrays[f'd{owner}_latest_live']=np.packbits(c.live_image.astype(bool).ravel())\n    for slot,data in c.images.items():")
(r/'stage_run.py').write_text(stage,encoding='utf-8')
f=lambda s:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
assert f(stage)==f((r/'stage_run_initial_export.py').read_text(encoding='utf-8'))
patch=dict(baseline_commit='aa8c14a7021a625378455ab985387dcaec1ec79d',baseline_zip_sha256=b['baseline_zip_sha256'],candidate_zip_sha256=b['candidate_zip_sha256'],
    baseline=b['original_files'],candidate=b['candidate_files'],changed=b['changed_existing_files'])
(r/'PATCH_BINDING.json').write_text(json.dumps(patch,indent=2)+'\n')
(r/'DECLARED_SOURCE.json').write_text(json.dumps(b['candidate_files'],indent=2)+'\n')
(r/'OFFLINE_CHECK.json').write_text(json.dumps(dict(simulation_steps=0,unit_groups=53,
    validation_sha256=sha256((r/'VALIDATION.json').read_bytes()).hexdigest()))+'\n')
old=r.parent/'team615_group_exchange_map09_20261121'
for name in ['Map08','Map09']:
    folder=r/name;folder.mkdir(exist_ok=False)
    for n in ['stage_run.py','candidate_snapshot.zip','baseline_snapshot.zip','DECLARED_SOURCE.json','PATCH_BINDING.json',
              'BUILD.json','VALIDATION.json','counterexamples.json','matched_spawns.json','EXPECTED_ZONES.json','OFFLINE_CHECK.json']:
        shutil.copyfile(r/n,folder/n)
    (folder/'place_map09.yml').write_text((r/'place_map09.yml').read_text().replace('map_name: Map09','map_name: '+name),encoding='utf-8')
    run=(old/'run_once.sh').read_text().replace('Map09',name).replace('group_exchange','partial_selection')
    (folder/'run_once.sh').write_text(run,encoding='utf-8',newline='\n')
    ob=dict(observer_sha256=sha256((folder/'stage_run.py').read_bytes()).hexdigest(),in_match_observer_functions_ast_identical=True,
        extra_data_export_only_after_scoring=True,map=name,seed=615,controller_frozen_sha256=b['candidate_zip_sha256'],
        revision='final cache-boundary fix; first-trial evidence retained separately')
    (folder/'OBSERVATION_BINDING.json').write_text(json.dumps(ob,indent=2)+'\n')
    subprocess.run(['ssh','-o','BatchMode=yes',host,f'mkdir {remote}/{name}'],check=True)
    subprocess.run(['scp','-q','-o','BatchMode=yes',*[str(p) for p in folder.iterdir()],f'{host}:{remote}/{name}/'],check=True)
subprocess.run(['scp','-q','-o','BatchMode=yes',str(r/'dispatch.sh'),f'{host}:{remote}/'],check=True)
# Only nohup is backgrounded. The SSH shell itself returns immediately.
command=f'nohup bash {remote}/dispatch.sh {remote} > {remote}/queue.log 2>&1 < /dev/null & echo QUEUED'
p=subprocess.run(['ssh','-o','BatchMode=yes',host,command],capture_output=True,check=True,timeout=30)
print(p.stdout.decode());print(b['candidate_zip_sha256'])
