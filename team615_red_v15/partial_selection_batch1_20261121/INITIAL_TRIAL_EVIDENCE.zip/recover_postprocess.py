"""Validate completed Map08 output after a post-score fixture name collision."""
from pathlib import Path
from hashlib import sha256
import json
import numpy as np

stage=Path.cwd()
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
assert not (stage/'POSTPROCESS_RECOVERY.json').exists()
finish=read(stage/'FINISH.json');score=read(stage/'OFFICIAL_SCORE.json');start=read(stage/'START.json')
assert finish['status']=='COMPLETE' and finish['completed_red_rounds']==1
assert start['map_name']=='Map08' and start['seed']==615
log=(stage/'run.log').read_text(encoding='utf-8')
assert "AttributeError: 'int' object has no attribute 'iterdir'" in log
result=Path(finish['result_dir']);assert result.is_relative_to(stage/'official_sdk/results_swarm_rescue')
for name,checksum in finish['files'].items():assert h(result/name)==checksum
assert h(stage/'placement_events.jsonl')==score['placement_events_sha256']
assert h(stage/'wall_geometry.npz')==score['wall_geometry_sha256']
expected=read(stage/'DECLARED_SOURCE.json')
for folder in [stage/'solution',stage/'official_sdk/src/swarm_rescue/solutions']:
    actual={p.name:h(p) for p in folder.iterdir() if p.is_file() and p.suffix in {'.py','.yml','.txt'}}
    assert actual==expected
data=np.load(stage/'group_dataset.npz')
metadata=read(stage/'GROUP_DATASET.json');assert len(metadata)==5
for key in data.files:assert data[key].dtype!=object
post=dict(status='PASS',source_members=len(expected),input_unchanged=True,runtime_unchanged=True,
          recovered_after_post_score_fixture_error=True)
(stage/'POST_RUN_SOURCE_CHECK.json').write_text(json.dumps(post,indent=2)+'\n')
recovery=dict(status='PASS',post_scoring_only=True,new_simulation_rounds=0,
    original_error="post-score loop variable 'source' shadowed the input directory Path",original_run_log_sha256=h(stage/'run.log'),
    actual_completed_rounds=finish['completed_red_rounds'],official_score_sha256=h(stage/'OFFICIAL_SCORE.json'),
    action='Read-only verification of already saved score, dataset and input/runtime source hashes; no controller or physics replay.')
(stage/'POSTPROCESS_RECOVERY.json').write_text(json.dumps(recovery,indent=2)+'\n')
files=['group_dataset.npz','GROUP_DATASET.json','POST_RUN_SOURCE_CHECK.json','POSTPROCESS_RECOVERY.json']
(stage/'EXTRA_ARTIFACTS.json').write_text(json.dumps({n:h(stage/n) for n in files},indent=2)+'\n')
print(json.dumps(dict(status='PASS',score=score['partial'],step=score['steps'],selected=score['selected_submission'],recovery=recovery),indent=2))
