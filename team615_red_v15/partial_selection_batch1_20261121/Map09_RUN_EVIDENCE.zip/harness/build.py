from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from hashlib import sha256
import ast,json,subprocess

r=Path(__file__).resolve().parent
h=lambda b:sha256(b).hexdigest()
assert h((r/'baseline_snapshot.zip').read_bytes())=='641685d7bd460f6241abb4e2c0f02527d7324a37d78f6492401d66a4b6a63cda'
with ZipFile(r/'baseline_snapshot.zip') as z:old={n:z.read(n) for n in z.namelist()}
new={p.name:p.read_bytes() for p in (r/'candidate').iterdir() if p.is_file()}
assert set(new)==set(old)
changed=sorted(n for n in old if new[n]!=old[n])
assert changed==['group_exchange.py','map_candidates.py','red_hooks.py']
assert all((r/'baseline'/n).read_bytes()==b for n,b in old.items())
for n,b in new.items():
    if n.endswith('.py'):compile(b,n,'exec')
def methods(blob,cls):
    tree=ast.parse(blob)
    node=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name==cls)
    return {x.name:ast.dump(x,include_attributes=False) for x in node.body if isinstance(x,ast.FunctionDef)}
oa,na=methods(old['group_exchange.py'],'GroupExchange'),methods(new['group_exchange.py'],'GroupExchange')
navigation=['observe','prepare_return','commit_return','release','go_root','tick_navigation','eta_root','start','cutoff','expired','complete']
assert all(oa[n]==na[n] for n in navigation)
a,b=methods(old['red_hooks.py'],'RedHooks'),methods(new['red_hooks.py'],'RedHooks')
assert [n for n in a if a[n]!=b[n]]==['control']
source=new['red_hooks.py'].decode()
for insertion in ['                if self.group_exchange is not None:\n                    self.group_exchange.candidates.remember_live(step, prepared_image)\n',
                  '                    if self.group_exchange is not None:\n                        self.group_exchange.candidates.remember_live(step, image)\n']:
    if '\r\n' in source:insertion=insertion.replace('\n','\r\n')
    assert source.count(insertion)==1;source=source.replace(insertion,'')
assert source.encode()==old['red_hooks.py']
with ZipFile(r/'candidate_snapshot.zip','w',ZIP_DEFLATED) as z:
    for n,b in sorted(new.items()):
        i=ZipInfo(n,date_time=(2026,11,21,0,0,0));i.compress_type=ZIP_DEFLATED;z.writestr(i,b)
diff=subprocess.run(['git','-c','core.autocrlf=false','diff','--no-index','--','baseline','candidate'],cwd=r,capture_output=True)
assert diff.returncode==1
patch=diff.stdout.replace(b'a/baseline/',b'a/').replace(b'b/candidate/',b'b/').replace(b'a/candidate/',b'a/')
(r/'partial_selection.patch').write_bytes(patch)
checked=subprocess.run(['git','apply','--check',str(r/'partial_selection.patch')],cwd=r/'baseline',capture_output=True)
assert checked.returncode==0,checked.stderr
result=dict(status='PASS',baseline='three-map grouped-return candidate',baseline_zip_sha256=h((r/'baseline_snapshot.zip').read_bytes()),
    candidate_zip_sha256=h((r/'candidate_snapshot.zip').read_bytes()),baseline_member_count=len(old),candidate_member_count=len(new),
    changed_existing_files=changed,added_files=[],unchanged_files=len(old)-len(changed),
    navigation_methods_ast_identical=navigation,red_hooks_control_reconstructed_byte_identical=True,
    navigation_scanning_fitting_placement_deadline_files_byte_identical=True,
    original_files={n:h(b) for n,b in old.items()},candidate_files={n:h(b) for n,b in new.items()},
    package_role='research candidate; not an official competition release',patch_apply_check='PASS')
(r/'BUILD.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('original_files','candidate_files')},indent=2))
