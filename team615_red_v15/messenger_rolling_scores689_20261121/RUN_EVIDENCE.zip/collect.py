"""Collect the supplied messenger/rolling version on Maps 06, 08, and 09."""
from hashlib import sha256
from pathlib import Path, PurePosixPath
import json
import math
import subprocess
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parent
stage = (root / "SERVER_STAGE.txt").read_text().strip()
host = "quanliangwen@10.112.162.60"
received = root / "received"
delivery = root / "delivery"
delivery.mkdir(exist_ok=True)
sdk_commit = "6557940dc18549ffc7a945db887da5b05b7ed2f1"
sdk_archive = "9155bc4cdf5e0813cd328d3a56c3b73633ba351c3859e694762ed41376fc6860"

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def save(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n",
                    encoding="utf-8", newline="\n")

def download(paths, destination):
    destination.mkdir(exist_ok=True, parents=True)
    subprocess.run(["scp", "-q", "-o", "BatchMode=yes",
                    *(f"{host}:{path}" for path in paths), str(destination)], check=True)

def get_round(map_name):
    remote = PurePosixPath(stage) / map_name
    local = received / map_name
    names = ("START.json", "FINISH.json", "SOURCE_MATCH.json",
             "OFFICIAL_SCORE.json", "placement_events.jsonl", "run.log", "wall_geometry.npz")
    download([str(remote / name) for name in names], local)
    start, finish, source, score = (
        read(local / f"{name}.json")
        for name in ("START", "FINISH", "SOURCE_MATCH", "OFFICIAL_SCORE"))
    assert [start[key] for key in ("seed", "sdk", "sdk_archive_sha256", "map_name",
            "drones", "bombs_per_drone", "timestep_limit", "walltime_limit", "competition_mode")] == [
            615, sdk_commit, sdk_archive, map_name, 5, 2, 5400, 180, True]
    assert start["spawn"] == read(root / "matched_spawns.json")[map_name]
    assert start["zones"] == read(root / "EXPECTED_ZONES.json")[map_name]
    assert start["solutions_sha256"] == source["candidate"] == read(root / "DECLARED_SOURCE.json")
    assert source["candidate_zip_sha256"] == digest(root / "candidate_snapshot.zip")
    assert source["changed"] == {}
    assert [finish[key] for key in ("status", "completed_red_rounds",
                                    "blue_rounds", "layout_evaluations")] == ["COMPLETE", 1, 0, 0]
    assert score["expected"] == 10
    assert digest(local / "placement_events.jsonl") == score["placement_events_sha256"]
    assert digest(local / "wall_geometry.npz") == score["wall_geometry_sha256"]
    official = PurePosixPath(finish["result_dir"])
    assert official.is_relative_to(remote / "official_sdk/results_swarm_rescue")
    for name, expected in finish["files"].items():
        target = PurePosixPath(name)
        assert not target.is_absolute() and ".." not in target.parts
        destination = local / "official" / target.parent
        download([str(official / target)], destination)
        assert digest(local / "official" / target) == expected
    events = [json.loads(line) for line in (local / "placement_events.jsonl").read_bytes().splitlines()]
    drops = [row for row in events if row["event"] == "sdk_placement" and row["accepted"]]
    rejected = [row for row in events if row["event"] == "sdk_placement" and not row["accepted"]]
    assert len(drops) == score["placed"]
    selected = score["selected_submission"]
    if selected and selected["drone"] is not None:
        assert selected["step"] == score["steps"]
        assert selected["image_sha256"] == score["selected_image_sha256"]
    weighted = .5 * score["map_score"] + .2 * score["coverage"] + .1 * score["time_score"]
    assert math.isclose(weighted, score["partial"], abs_tol=1.e-8)
    health = {row["drone"]: row["health"] for row in score["drone_details"]}
    return dict(partial_score_out_of_80=score["partial"],
                map_score=score["map_score"], wall_score=score["coverage"],
                time_score=score["time_score"], placed=score["placed"], expected=score["expected"],
                submitted_map=score["submitted_map"], selected_submission=selected,
                steps=score["steps"], elapsed_walltime_seconds=score["elapsed_walltime"],
                final_health=health, total_health_lost=sum(25 - value for value in health.values()),
                destroyed_drones=sum(value <= 0 for value in health.values()),
                last_physical_drop_step=max((row["step"] for row in drops), default=None),
                sdk_rejected_attempts=len(rejected), actual_drops=drops,
                final_score_range_with_pending_blue_term=[score["partial"], score["partial"] + 20.])

download([f"{stage}/matrix.log", f"{stage}/static.log"], received)
assert "Submission check passed." in (received / "static.log").read_text(encoding="utf-8")
lines = (received / "matrix.log").read_text(encoding="utf-8").splitlines()
assert [line for line in lines if line.startswith(("START Map", "COMPLETE Map"))] == [
    "START Map06", "COMPLETE Map06", "START Map08", "COMPLETE Map08", "START Map09", "COMPLETE Map09"]
provenance = read(root / "INPUT_PROVENANCE.json")
assert provenance["original_zip_sha256"] == digest(root / "original.zip")
assert provenance["normalized_zip_sha256"] == digest(root / "candidate_snapshot.zip")
with ZipFile(root / "original.zip") as original, ZipFile(root / "candidate_snapshot.zip") as normalized:
    assert len(original.namelist()) == len(normalized.namelist()) == provenance["member_count"] == 53
    for name in normalized.namelist():
        assert original.read(name) == normalized.read(name)
rounds = {name: get_round(name) for name in ("Map06", "Map08", "Map09")}
result = dict(input=provenance, sdk=sdk_commit, sdk_archive_sha256=sdk_archive,
              seed=615, maps=["Map06", "Map08", "Map09"], rounds_per_map=1,
              scoring_weights=dict(map=.5, wall=.2, time=.1, pending_blue_bomb_difficulty=.2),
              source_static_check="PASS", algorithm_source_changes=0, new_red_rounds=3,
              blue_rounds=0, layout_evaluations=0, scores=rounds)
save(delivery / "RESULTS.json", result)
with ZipFile(delivery / "RUN_EVIDENCE.zip", "w", compression=ZIP_DEFLATED) as archive:
    for path in sorted(received.rglob("*")):
        if path.is_file():
            archive.write(path, path.relative_to(root).as_posix())
    for name in ("stage_run.py", "run.sh", "collect.py", "INPUT_PROVENANCE.json", "Map06.yml", "Map08.yml", "Map09.yml", "EXPECTED_ZONES.json", "matched_spawns.json", "DECLARED_SOURCE.json", "PATCH_BINDING.json",
                 "OFFLINE_CHECK.json"):
        archive.write(root / name, name)
with ZipFile(delivery / "RUN_EVIDENCE.zip") as archive:
    assert archive.testzip() is None
save(delivery / "CHECKSUMS_SHA256.json",
     {name: digest(delivery / name) for name in ("RESULTS.json", "RUN_EVIDENCE.zip")})
print(json.dumps({name: {key: value for key, value in score.items() if key != "actual_drops"}
                  for name, score in rounds.items()}, indent=2, ensure_ascii=False))

