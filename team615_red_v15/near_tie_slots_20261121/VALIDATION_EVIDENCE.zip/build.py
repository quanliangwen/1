from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from hashlib import sha256
import ast,json,subprocess
r=Path(__file__).resolve().parent
h=lambda data:sha256(data).hexdigest()
assert h((r/'baseline_snapshot.zip').read_bytes())=='2555f9585aa0fcb41874b44076ee34719c13dc314fc05de58e5e58be40cef19e'
with ZipFile(r/'baseline_snapshot.zip') as z:old={n:z.read(n) for n in z.namelist()}
new={p.name:p.read_bytes() for p in (r/'candidate').iterdir() if p.is_file()}
assert set(new)==set(old)
changed=sorted(n for n in old if old[n]!=new[n]);assert changed==['group_exchange.py','map_candidates.py']
assert all((r/'baseline'/n).read_bytes()==data for n,data in old.items())
for n,data in new.items():
    if n.endswith('.py'):compile(data,n,'exec')
def methods(blob,cls):
    node=next(n for n in ast.parse(blob).body if isinstance(n,ast.ClassDef) and n.name==cls)
    return {n.name:ast.dump(n,include_attributes=False) for n in node.body if isinstance(n,ast.FunctionDef)}
a,b=methods(old['group_exchange.py'],'GroupExchange'),methods(new['group_exchange.py'],'GroupExchange')
navigation=['observe','prepare_return','commit_return','release','go_root','tick_navigation','eta_root','start','cutoff','expired','complete','message']
assert all(a[n]==b[n] for n in navigation)
assert [n for n in a if a[n]!=b[n]]==['__init__','receive','ordinary_submit_allowed','valid_choice','refresh_comparison','try_submit']
normalized=new['group_exchange.py'].decode().replace('self.valid_choice(choice,step,drone)','self.valid_choice(choice,step)')
assert methods(normalized,'GroupExchange')['receive']==a['receive']
ca,cb=methods(old['map_candidates.py'],'MapCandidates'),methods(new['map_candidates.py'],'MapCandidates')
assert [n for n in ca if ca[n]!=cb[n]]==['choose']
assert old['red_hooks.py']==new['red_hooks.py']
with ZipFile(r/'candidate_snapshot.zip','w',ZIP_DEFLATED) as z:
    for n,data in sorted(new.items()):
        item=ZipInfo(n,date_time=(2026,11,21,0,0,0));item.compress_type=ZIP_DEFLATED;z.writestr(item,data)
diff=subprocess.run(['git','-c','core.autocrlf=false','diff','--no-index','--','baseline','candidate'],cwd=r,capture_output=True)
assert diff.returncode==1
patch=diff.stdout.replace(b'a/baseline/',b'a/').replace(b'b/candidate/',b'b/').replace(b'a/candidate/',b'a/')
(r/'near_tie_slots.patch').write_bytes(patch)
check=subprocess.run(['git','apply','--check',str(r/'near_tie_slots.patch')],cwd=r/'baseline',capture_output=True)
assert check.returncode==0,check.stderr
result=dict(status='PASS',baseline='frozen 180+24 candidate',baseline_zip_sha256=h((r/'baseline_snapshot.zip').read_bytes()),
    candidate_zip_sha256=h((r/'candidate_snapshot.zip').read_bytes()),baseline_member_count=len(old),candidate_member_count=len(new),
    changed_existing_files=changed,added_files=[],unchanged_files=len(old)-len(changed),
    navigation_and_message_methods_ast_identical=navigation,receive_only_adds_drone_for_choice_slot_validation=True,
    map_memory_transport_and_cache_methods_ast_identical=True,red_hooks_file_byte_identical=True,
    original_bid_and_hard_deadline_code_byte_identical=True,no_navigation_or_fitting_changes=True,
    package_role='counterexample-validated research source, not an official competition release',patch_apply_check='PASS',
    original_files={n:h(data) for n,data in old.items()},candidate_files={n:h(data) for n,data in new.items()},
    new_full_matches=0,new_physics_steps=0)
(r/'BUILD.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('original_files','candidate_files')},indent=2))
