# New counterexamples use the real 3444 origin and production methods.
def logged_map08():
    evidence=json.loads((args.archive.parent/'MAP08_SAVED_TABLES.json').read_bytes())
    for owner,table in evidence['tables'].items():
        original=MapCandidates.select_candidate(table)
        expected=6 if owner=='1' else 5 if owner=='4' else 0
        assert original['owner']==expected
        chosen=MapCandidates.select_candidate(table,ordinary=True)
        assert chosen['owner']==5 and chosen['version']==3444
    assert evidence['official_scores']['1']['5']==77.18921483453524
check('D01_saved_Map08_tables_choose_latest_only_in_ordinary_mode',logged_map08)


def near_band():
    def row(owner,version,score):return dict(owner=owner,version=version,score=score,digest=str(owner)*64)
    old=row(0,3240,1.0);edge=row(5,3444,1.0-.003)
    assert MapCandidates.select_candidate([old,edge],ordinary=True) is edge
    bad=row(5,3444,1.0-.003-1e-8)
    assert MapCandidates.select_candidate([old,bad],ordinary=True) is old
    assert MapCandidates.select_candidate([old,edge]) is old
    chain=[row(0,1,.950),row(1,2,.948),row(5,3,.946)]
    assert MapCandidates.select_candidate(chain,ordinary=True)['owner']==1
    assert MapCandidates.select_candidate([],ordinary=True) is None
check('D02_003_boundary_clear_degradation_and_no_tolerance_chaining',near_band)


def terminal_tie_persists():
    d,g=real_partial();old_hashes={i:v['digest'] for i,v in g.candidates.images.items()}
    image=g.candidates.image(0);image[40:42,40:42]=1
    d._render_submission=lambda memory=None:image.copy()
    def scoring(bitmap,hits):
        value=.948 if bitmap[20,20] else .950
        return dict(precision=value,recall=value,score=value)
    d.elapsed_timestep=3444;assert not g.try_submit(d,3444,scoring)
    assert g.ordinary_selection and g.candidates.best['owner']==5
    g.candidates.remember_live(3445,image)
    d.elapsed_timestep=3445;assert not g.try_submit(d,3445,scoring)
    assert g.candidates.best['owner']==5
    for step in [3447,3449]:
        d.elapsed_timestep=step;g.try_submit(d,step,scoring)
    assert d.red_submission_step==3449 and np.array_equal(d.sent[-1][1],image)
    assert all(g.candidates.images[i]['digest']==v for i,v in old_hashes.items())
check('D03_terminal_near_new_survives_later_cache_refresh_and_preserves_originals',terminal_tie_persists)


def map09_no_terminal_mode():
    d,g=real_partial();d.inventory_records[1]=(2832,1);d.inventory_records[3]=(2804,1)
    d._prefer_own_submission=lambda step:(_ for _ in ()).throw(AssertionError('no election before team clear'))
    d._render_submission=lambda *a:(_ for _ in ()).throw(AssertionError('no final render before team clear'))
    for step in [3241,4230,4590,4662]:
        if step in [4230,4590]:
            image=np.zeros((64,64),np.uint8);image[10:12,14:16]=1
            if step==4590:d.memory.hits[20,20]=3;image[40:42,40:42]=1
            g.candidates.remember_live(step,image)
        assert not poll(d,g,step)
        assert not g.ordinary_selection and g.finish_refresh_step is None and g.choice is None
    assert g.candidates.best['version']==4590 and np.array_equal(d.deadline_submission.image,image)
check('D04_Map09_unknown_confirmations_keep_original_cache_ranking_and_4590_backup',map09_no_terminal_mode)


def absolute_slots():
    flights=[real_partial(owner=i) for i in range(5)]
    for step in range(3240,5401):
        owners=[g.owner for d,g in flights if g.in_submission_slot(d,step)]
        assert len(owners)==1
        for d,g in flights:
            owner,start,end=g.submission_slot(d,step)
            assert end-start==6 and start<=step<end
            assert (step-start)==(step-3444)%6
    for i,(d,g) in enumerate(flights):
        assert g.submission_slot(d,3444+6*i)==(i,3444+6*i,3450+6*i)
        assert g.in_submission_slot(d,3444+6*i+30)
check('D05_real_round_clock_has_exactly_one_slot_owner_for_every_step',absolute_slots)


def partitioned_submitters():
    flights=[real_partial(owner=i,phase='ABORT' if i%2 else 'RETURN_LOCAL') for i in range(5)]
    ended={}
    for step in range(3444,3475):
        for d,g in flights:
            if d.submitted:continue
            if poll(d,g,step):ended.setdefault(step,[]).append(d.identifier)
    assert all(len(ids)==1 for ids in ended.values()) and sum(map(len,ended.values()))==5
    assert flights[0][0].red_submission_step==3448
    assert flights[1][0].red_submission_step==3452
check('D06_disconnected_groups_cannot_submit_ordinary_maps_in_the_same_frame',partitioned_submitters)


def historical_bid_yield():
    d0,g0=real_partial(0);d1,g1=real_partial(1)
    d0.map_bids[1]=(3300,1500,True)
    d0.last_eligible_bid_comparison[1]=(3300,1500,1200)
    d1.map_quality=9000
    for step in range(3444,3453):
        if not d0.submitted:poll(d0,g0,step)
        if not d1.submitted:poll(d1,g1,step)
    assert not d0.sent and d0.submission_priority_audit['preferred']==1
    assert d1.red_submission_step==3452
    assert g0.choice is None
check('D07_original_historical_quality_bid_can_yield_zero_slot_to_one',historical_bid_yield)


def recheck_bid_before_submit():
    d,g=real_partial();poll(d,g,3444);poll(d,g,3446)
    assert g.choice is not None
    d.map_bids[1]=(3448,1500,True)
    assert not poll(d,g,3448) and not d.sent
check('D08_new_higher_ready_bid_vetoes_actual_submit_after_local_proposal',recheck_bid_before_submit)


def bounded_bid_wait():
    d,g=real_partial()
    for step in range(3444,3510):
        d.map_bids[1]=(step,1500,False)
        if poll(d,g,step):break
    assert d.submission_wait_started==3444 and d.red_submission_step==3506
    assert g.in_submission_slot(d,d.red_submission_step)
check('D09_repeated_higher_unready_bids_do_not_restart_original_48step_yield',bounded_bid_wait)


def slot_lease_and_repeated_old_packets():
    d0,g0=real_partial(0);d1,g1=real_partial(1)
    poll(d0,g0,3444);poll(d0,g0,3446);poll(d1,g1,3444)
    d0.elapsed_timestep=3447;message=g0.message(d0,3447)
    assert g0.choice['lease_end']==3450
    g1.receive(d1,dict(id=0,red_group_exchange=message),3447)
    assert g1.choice['executor']==0
    assert not poll(d1,g1,3450) and g1.choice['executor']==1
    key=g1.choice['key']
    for _ in range(100):g1.receive(d1,dict(id=0,red_group_exchange=message),3451)
    assert g1.choice['key']==key and poll(d1,g1,3452)
check('D10_cross_slot_expiry_and_repeated_old_proposals_do_not_block_next_owner',slot_lease_and_repeated_old_packets)


def no_last_two_step_proposal():
    d,g=real_partial();poll(d,g,3444)
    assert not poll(d,g,3448) and g.choice is None
    assert not poll(d,g,3449) and g.choice is None
    assert not poll(d,g,3450) and g.choice is None
    assert not poll(d,g,3474) and g.choice['created']==3474
    assert poll(d,g,3476)
check('D11_last_two_slot_steps_cannot_create_proposal_that_submits_in_next_slot',no_last_two_step_proposal)


def invalid_slot_choice():
    d,g=real_partial();poll(d,g,3444);poll(d,g,3446)
    assert g.valid_choice(g.choice,3446,d)
    for edits in [dict(lease_end=3451),dict(proposer=1,executor=1)]:
        bad=dict(g.choice,**edits);bad['key']=digest({k:v for k,v in bad.items() if k!='key'})
        assert not g.valid_choice(bad,3446,d)
    assert not g.valid_choice(g.choice,3450,d)
check('D12_even_rehashed_choices_must_match_global_owner_and_slot_end',invalid_slot_choice)


def legacy_fast_exit_slot():
    from swarm_rescue.solutions.fast_closeout import FastCloseout
    for i in [0,1]:
        d,g=real_partial(owner=i,phase='ABORT');g.plan.acks=set()
        f=FastCloseout(i,5);f.plan=(3400,i);f.vote=i
        other_step=3450 if i==0 else 3448
        assert not g.ordinary_submit_allowed(d,other_step)
        assert not f.submit(d,other_step) and not d.sent
    d,g=real_partial(owner=1,phase='ABORT');g.plan.acks=set()
    f=FastCloseout(1,5);f.plan=(3400,1);f.vote=1;d.elapsed_timestep=3450
    assert f.submit(d,3450) and d.red_submission_step==3450
check('D13_legacy_ordinary_and_fast_closeout_exits_obey_the_same_slot',legacy_fast_exit_slot)


def soft_cutoff_still_slotted():
    flights=[real_partial(i) for i in [0,1]]
    for d,g in flights:poll(d,g,3444);g.choice=None
    results=[poll(d,g,4590) for d,g in flights]
    assert results==[False,True] and flights[1][0].red_submission_step==4590
    assert not flights[0][1].ordinary_submit_allowed(flights[0][0],4590)
check('D14_soft_coordination_cutoff_cannot_bypass_ordinary_slots',soft_cutoff_still_slotted)


def stock_rechecked_at_send():
    for kind in ['pending','own','peer']:
        d,g=real_partial();poll(d,g,3444);poll(d,g,3446)
        if kind=='pending':d.pending_drop=(1,np.zeros(2),3447)
        elif kind=='own':d.previous_inventory=1
        else:d.inventory_records[4]=(3447,1)
        assert not poll(d,g,3448) and not d.sent
check('D15_slots_and_near_ties_never_replace_actual_stock_and_pending_checks',stock_rechecked_at_send)


def hard_deadline_bypasses_slot_and_bid():
    for reason,step,seconds in [('walltime',4663,179.),('timestep',5396,100.)]:
        d,g=real_partial();d.inventory_records[1]=(2832,1);poll(d,g,3241)
        image=np.zeros((64,64),np.uint8);image[10:12,14:16]=1;g.candidates.remember_live(4590,image)
        poll(d,g,4590)
        d._prefer_own_submission=lambda *a:(_ for _ in ()).throw(AssertionError('hard deadline must not yield'))
        g.in_submission_slot=lambda *a:(_ for _ in ()).throw(AssertionError('hard deadline must not wait for slot'))
        d.elapsed_timestep=step;d.elapsed_walltime=seconds
        assert RedHooks._force_deadline_submission(d,step)
        assert d.deadline_submission_event['fallback']==reason and np.array_equal(d.sent[-1][1],image)
check('D16_both_hard_deadlines_bypass_slot_bid_and_missing_confirmations',hard_deadline_bypasses_slot_and_bid)


def ready_bid_while_returning():
    for phase in ['RETURN_LOCAL','ABORT','DELIVERED_HOLD','OBSERVE']:
        d,g=real_partial(phase=phase);assert d.first_ready_to_submit_step is None
        poll(d,g,3444)
        assert d.first_ready_to_submit_step==3444 and RedHooks._own_map_bid(d,3444)[2]
        assert g.submission_ready
    d,g=real_partial();d.inventory_records[1]=(2832,1);poll(d,g,3444)
    assert not g.submission_ready and not RedHooks._own_map_bid(d,3444)[2]
check('D17_original_bid_readiness_is_uniform_across_return_states_but_requires_team_clear',ready_bid_while_returning)


def no_slot_restart_or_navigation_mutation():
    d,g=real_partial(phase='ABORT');poll(d,g,3444)
    expected=g.submission_slot(d,3450)
    before=(g.phase,list(g.route),list(d.drives),d.messenger.state,d.search_task)
    for step in range(3445,3450):
        for _ in range(30):g.candidates.receive(d,1,('snapshot',g.candidates.snapshots[1]),step)
        g.ordinary_submit_allowed(d,step)
    assert g.submission_slot(d,3450)==expected
    assert before==(g.phase,g.route,d.drives,d.messenger.state,d.search_task)
check('D18_duplicate_data_and_eligibility_checks_do_not_restart_slots_or_touch_navigation',no_slot_restart_or_navigation_mutation)


def late_and_small_limit_slots():
    for limit in [300,5400,6000]:
        flights=[]
        for i in range(5):
            d=Flight(i);d.limit=limit;d.group_exchange=GroupExchange(i,5,limit,(64,64));flights.append(d)
        for step in range(max(0,limit-70),limit+1):
            assert sum(d.group_exchange.in_submission_slot(d,step) for d in flights)==1
    d,g=real_partial();d.elapsed_walltime=168.1
    assert g.can_finish(d,3264) and not poll(d,g,3239)
    assert g.submission_slot(d,3264)==(0,3264,3270)
check('D19_slots_share_derived_origin_for_other_limits_and_early_low_wall_escape',late_and_small_limit_slots)


def no_cross_reference_f1_election():
    d,g=real_partial();poll(d,g,3444)
    # A locally computed F1 table in a peer status is not a quality bid.
    g.peer_status[1]=dict(step=3446,submission_ready=True,score_table=[dict(score=1.0)],have=set())
    assert not poll(d,g,3446) and poll(d,g,3448)
check('D20_peer_local_F1_values_do_not_replace_original_common_scale_quality_bids',no_cross_reference_f1_election)
