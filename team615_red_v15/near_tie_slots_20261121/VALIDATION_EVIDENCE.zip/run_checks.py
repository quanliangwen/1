from pathlib import Path
from hashlib import sha256
import json,subprocess
r=Path(__file__).resolve().parent
source=r.parent/'team615_finish_gate_maps_20261121/Map08/received'
raw=(source/'OFFICIAL_SCORE.json').read_bytes();s=json.loads(raw)
offline=json.loads((source/'OFFLINE_MAP_SCORES.json').read_bytes())
evidence=dict(source='Existing Map08 seed615, frozen 180+24 candidate; no replay or new scoring',
    original_score_json_sha256=sha256(raw).hexdigest(),tables={str(i):s['drone_details'][i]['group_score_table'] for i in [0,1,3,4]},
    official_scores={str(i):{str(v['slot']):v['map_score'] for v in offline['candidates'] if v['holder']==i} for i in [0,1,3,4]})
(r/'MAP08_SAVED_TABLES.json').write_text(json.dumps(evidence,indent=2)+'\n')
subprocess.run(['python',str(r/'prepare_tests.py')],check=True)
remote=(r/'SERVER_STAGE.txt').read_text().strip();host='quanliangwen@10.112.162.60'
for n in ['candidate_snapshot.zip','BUILD.json','counterexamples.py','validate.py','MAP08_SAVED_TABLES.json']:
    subprocess.run(['scp','-q','-o','BatchMode=yes',str(r/n),f'{host}:{remote}/'],check=True)
sdk='/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/P407_P398_semifinal_three_maps_20261110/official_sdk'
py='/home/junhao/quan/parallel_test_solver/match/.venv/bin/python'
command=f'cd {remote} && PYTHONPATH={sdk}/src PYGLET_HEADLESS=true PYTHONDONTWRITEBYTECODE=1 {py} -B counterexamples.py candidate_snapshot.zip candidate --output counterexamples.json > counterexamples.log 2>&1'
check=subprocess.run(['ssh','-o','BatchMode=yes',host,command],capture_output=True)
subprocess.run(['scp','-q','-o','BatchMode=yes',f'{host}:{remote}/counterexamples.log',str(r/'counterexamples.log')],check=True)
print((r/'counterexamples.log').read_text(encoding='utf-8')[-8000:])
if check.returncode:raise SystemExit(check.returncode)
command=f'cd {remote} && PYTHONPATH={sdk}/src PYGLET_HEADLESS=true PYTHONDONTWRITEBYTECODE=1 {py} -B validate.py > validation.log 2>&1'
check=subprocess.run(['ssh','-o','BatchMode=yes',host,command],capture_output=True)
for name in ['counterexamples.json','VALIDATION.json','validation.log','static_candidate.log']:
    subprocess.run(['scp','-q','-o','BatchMode=yes',f'{host}:{remote}/{name}',str(r/name)],check=True)
print((r/'validation.log').read_text(encoding='utf-8')[-2500:])
if check.returncode:raise SystemExit(check.returncode)
