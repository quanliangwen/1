from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json,shutil
r=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
b=read(r/'BUILD.json');v=read(r/'VALIDATION.json');c=read(r/'counterexamples.json');tables=read(r/'MAP08_SAVED_TABLES.json')
assert b['status']==v['status']==c['status']=='PASS'
assert c['scenario_groups']==89 and v['candidate_scenario_groups']==89
assert h(r/'candidate_snapshot.zip')==b['candidate_zip_sha256']==c['archive_sha256']==v['candidate_zip_sha256']
assert c['physics_steps']==c['physics_step_attempts']==c['map_objects_created']==c['full_matches']==0
assert b['changed_existing_files']==['group_exchange.py','map_candidates.py'] and b['unchanged_files']==54
assert b['baseline_zip_sha256']=='2555f9585aa0fcb41874b44076ee34719c13dc314fc05de58e5e58be40cef19e'
saved=[]
for owner,table in tables['tables'].items():
    highest=max(x['score'] for x in table)
    old=max(table,key=lambda x:(x['score'],x['version'],-x['owner'],x['digest']))
    new=max((x for x in table if x['score']>=highest-.003),key=lambda x:(x['version'],x['score'],-x['owner'],x['digest']))
    assert new['owner']==5 and new['version']==3444
    saved.append(dict(holder=int(owner),previous_slot=old['owner'],ordinary_slot=new['owner'],version=new['version'],
        historical_official_score=tables['official_scores'][owner][str(new['owner'])],
        score_gap=old['score']-new['score']))
configuration=dict(near_tie=.003,near_tie_only_after_ordinary_finish_eligibility=True,
    candidate_band='score >= highest_score - 0.003; newest version first, then existing score/owner/digest order',
    regular_cache_default_ranking_unchanged=True,slot_steps=6,slot_cycle_steps=30,
    slot_formula='((step - finish_floor(drone)) // 6) % team_size',slot_intervals='half-open [start,end)',
    example_limit=5400,example_finish_floor=3444,slot_origin_is_absolute=True,
    local_smallest_ready_ID_election_removed=True,existing_quality_bid_and_bounded_yield_reused=True,
    actual_submission_rechecks_quality_bid=True,proposal_lease_never_crosses_slot=True,
    last_two_slot_steps_do_not_start_proposal=True,ordinary_and_fast_closeout_exits_share_slot_gate=True,
    soft_coordination_cutoff_obeys_slot=True,hard_timestep_and_wall_fallbacks_bypass_slot=True,
    personal_originals_preserved=True,actual_stock_and_pending_checks_preserved=True,
    Map09_4230_4590_cache_updates_preserved=True,navigation_and_fitting_unchanged=True)
result=dict(status='COUNTEREXAMPLES_AND_STATIC_PASS',configuration=configuration,build=b,validation=v,counterexamples=c,
    saved_Map08_table_only_selection=saved,
    synthetic_control_examples=dict(disconnected_0_earliest_submit=3448,disconnected_1_earliest_submit=3452,
        historical_higher_bid_example=dict(zero_yields=True,one_submits_at=3452),
        repeated_higher_unready_bid_example=dict(wait_started=3444,submit_at=3506),
        note='Separate synthetic control calls; SDK match termination was not run. These are not actual Map08 submission steps.'),
    simulation=dict(new_full_matches=0,physics_steps=0,physics_step_attempts=0,map_objects_created=0),
    actual_map08_score=None,actual_map09_score=None,actual_map08_submission_step=None,actual_map09_submission_step=None,
    limitations=['No new full simulation or official platform submission.',
        '0.003 is the user-authorized tolerance, not a statistically optimized or universally safe threshold.',
        'Slots prevent simultaneous ordinary finishes under common round clocks; hard fallbacks remain an intentional exception.',
        'No claim that the real Map08 historical bid state will choose drone1 or recover 77.1892.',
        '69 inherited groups adapt bid/timing expectations to the authorized semantics; production slot methods are not mocked out.',
        'Static/ABI checks use a reused read-only runtime; no dependency installation or replacement.'])
d=r/'delivery';d.mkdir(exist_ok=True)
(d/'RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for n in ['BUILD.json','VALIDATION.json','counterexamples.json','counterexamples.py','near_tie_slots.patch','MAP08_SAVED_TABLES.json']:
    shutil.copyfile(r/n,d/n)
for n in b['changed_existing_files']:shutil.copyfile(r/'candidate'/n,d/n)
shutil.copyfile(r/'candidate_snapshot.zip',d/'CANDIDATE_SOURCE.zip')
with ZipFile(d/'VALIDATION_EVIDENCE.zip','w',ZIP_DEFLATED) as z:
    for n in ['BUILD.json','VALIDATION.json','counterexamples.json','counterexamples.log','validation.log','static_candidate.log',
        'counterexamples.py','extra_tests.py','prepare_tests.py','run_checks.py','validate.py','build.py','assemble.py',
        'MAP08_SAVED_TABLES.json','baseline_snapshot.zip','near_tie_slots.patch','SERVER_STAGE.txt']:
        z.write(r/n,n)
    assert z.testzip() is None
readme=f'''# 普通交图近分选新图、原有竞价让行与6步时间槽

已在冻结的180＋24候选上实现本批最小修改。89组反例和官方静态内容检查通过；没有创建地图、没有执行物理步、没有跑整场仿真，也没有新的Map08/Map09成绩。

基线SHA256：`{b['baseline_zip_sha256']}`

新候选SHA256：`{b['candidate_zip_sha256']}`

## 修改范围

56个成员，只改`map_candidates.py`和`group_exchange.py`，其余54个文件字节一致。导航、探索、扫描、地图拟合、投放复核、双时限兜底的源文件及RedHooks整体字节不变。

- `MapCandidates.select_candidate()/choose()`：普通交图模式先取最高F1，在其0.003范围内优先版本最新候选；同版本仍按原分数、owner、digest稳定排序。普通模式以外完全沿用原F1排序。容差从最高分划定，不做逐对放宽，防止误差累积。图像渲染、参考证据构造和P/R计算均不改。
- `GroupExchange.refresh_comparison()/try_submit()`：全队实投确认、本机无pending、原有窗口和180＋24留时通过后才进入普通选图模式。模式持续到交图，后续缓存刷新不会退回旧排序。个人原图和旧最佳继续保留；进入模式会强制重比一次，最终绘图仍只做原有一次。
- `try_submit()/ordinary_submit_allowed()`：恢复调用原有`_prefer_own_submission()`，提案与实际交图前都重新判断质量竞价和限时让行。已有竞价代码未改。普通资格就绪时补齐原有bid的ready时间，返航状态不影响竞价资格；未确认全队清零不能变为ready。
- `submission_slot()`：以公共绝对步数为准，`((step - finish_floor) // 6) % team_size`决定时隙所有者。5400步局仍以3444为起点；5机30步一个周期。低墙钟允许提前放行时沿同一周期向前计算，不另起本地计时。
- `try_submit()/valid_choice()/receive()`：撤掉“新鲜邻机内最小编号自行领权”，改为只有本机时间槽才可发提案或普通交图。提案租约不跨槽，最后两步不新开提案，重复/过期提案不能锁住下一架机。receive仅增加对该公共时间槽的校验，不改实际地图收包逻辑。
- `ordinary_submit_allowed()`：旧普通交图和FastCloseout出口也经过时间槽及原有竞价检查；返航结束、ABORT或软协调截止都不能绕过。硬步数/墙钟兜底依然先于这些检查执行，不等时隙或竞价。

纯时隙错峰最多增加29步等待，不包含原有竞价让行和提案确认所需时间。不会重开180＋24步留时，不等待五份地图或全队ACK。时间槽提供普通提交互斥，无法让断联飞机得知全局真实最高分。

## 反例结果

共89组PASS：69组继承回归、20组新增。原有用到交图步数/旧禁用竞价的断言按本次授权更新；早期协议回归仍用3300步短窗口夹具，新组使用真实5400步/3444起点。没有替换或绕过生产时间槽方法。

| 验证 | 结果 |
|---|---|
| 已有Map08评分表：仅普通模式启用近分优先新图 | 0、1、3、4号均选3444步当前图；1号选中的是历史地图分77.1892的位图 |
| 0.003边界、明显变差的新图、三张图误差逐对累积 | PASS；容差带以最高分为基准 |
| 普通模式后的缓存再刷新 | 保持新排序，个人原图摘要不变 |
| 5个断联合成控制器、真实时隙逐步调用 | 普通提交不会同帧发生 |
| 原有已知更高质量竞价 | 合成例中0号让行，1号3452步获得提交机会 |
| 提案后收到新的更高ready竞价 | 实际提交前被否决 |
| 重复更高但未ready竞价 | 原48步让行计时不重启；合成例3506步在本机时隙交图 |
| 跨槽租约、旧提案反复广播、槽末两步开提案 | 均不能越过公共权限或阻挡下一机 |
| 返航、ABORT、旧普通出口、FastCloseout、软协调截止 | 均服从同一个普通时间槽 |
| 实投库存、pending、队友清零确认 | 保持否决权 |
| Map09缺1/3号末弹确认，4230和4590步缓存刷新 | 不进入普通偏新模式；4590版缓存继续进入兜底 |
| 硬墙钟/步数兜底 | 绕过时隙与竞价，使用现有缓存 |

表内提交步数来自合成控制器调用。没有执行SDK整场结束逻辑：真实比赛收到第一份提交即结束，不能把这些步数解读成一局内多架飞机都有后续交图机会，也不能解读为真实Map08已由1号提交。

既有Map08评分表的离线选中结果如下（官方分是旧局保存位图的历史分数，不是新候选成绩）：

| 持有者 | 原选中槽 | 普通偏新后槽 | 位图版本 | 历史位图官方地图分 |
|---|---:|---:|---:|---:|
'''
for row in saved:
    readme+=f"| {row['holder']}号 | {row['previous_slot']} | {row['ordinary_slot']} | {row['version']} | {row['historical_official_score']:.4f} |\n"
readme+='''
## 检查与文件

官方静态内容检查PASS；在只读复用Python3.11.17环境执行真实NumPy1.26.4的mtrand/RandomState、Pandas3.0.6、OpenCV4.11.0.86运算通过，SDK225个文件哈希核验通过。未安装或替换依赖，未声称官网镜像验证。

`CANDIDATE_SOURCE.zip`为研究源码快照；`near_tie_slots.patch`只适用于SHA256为2555f958…的180＋24基线，不可直接套在更早版本。两个修改文件单独提供。不是新正式参赛放行包，未上传官网。

`RESULTS.json`包含配置、89组结果和明确为null的新地图成绩；`VALIDATION_EVIDENCE.zip`包含完整验证脚本、原始日志、基线快照和补丁。`MAP08_SAVED_TABLES.json`记录旧评分表来源和哈希；`CHECKSUMS_SHA256.json`校验所有其他交付文件。

当前证明的是选图和提交权限契约，不保证0.003在其他地图总能提高官方分，也不保证真实Map08由1号执行。Map09原有缓存与硬兜底路径的反例已通过，真实比赛收益仍未复测。
'''
(d/'README.md').write_text(readme,encoding='utf-8')
manifest={p.name:h(p) for p in sorted(d.iterdir()) if p.name!='CHECKSUMS_SHA256.json'}
assert len(manifest)==12,len(manifest)
(d/'CHECKSUMS_SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(status='PASS',delivery_files=13,candidate_sha256=b['candidate_zip_sha256'],saved_table_selection=saved),indent=2))
