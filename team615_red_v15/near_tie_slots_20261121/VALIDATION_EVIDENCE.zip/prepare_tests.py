from pathlib import Path
r=Path(__file__).resolve().parent
s=(r.parent/'team615_finish_gate_18024_20261121/counterexamples.py').read_text(encoding='utf-8')
s=s.replace('from swarm_rescue.solutions.map_candidates import digest, frozen','from swarm_rescue.solutions.map_candidates import digest, frozen, MapCandidates')
def change(fn,old,new):
    global s
    start=s.index('def '+fn+'(');end=s.index("\ncheck(",start)
    part=s[start:end];assert old in part,(fn,old)
    s=s[:start]+part.replace(old,new)+s[end:]
change('proxy','3300','3324');change('proxy','3302','3326');change('proxy','3304','3328')
change('waits',"    d._prefer_own_submission=lambda *a:(_ for _ in ()).throw(AssertionError('old bid wait'))", "    bids=[]\n    d._prefer_own_submission=lambda step:(bids.append(step) or True)")
change('waits','and g.try_submit(d,3304,local_score)','and g.try_submit(d,3304,local_score)\n    assert bids==[3300,3302,3304]')
s=s.replace('S01_new_exit_not_blocked_by_old_three_windows','S01_no_restarted_scan_collection_but_original_bid_gate_is_reused')
change('lease','g.valid_choice(choice,3302)','g.valid_choice(choice,3302,d)')
change('lease','g.valid_choice(bad,3302)','g.valid_choice(bad,3302,d)')
change('compare_before_clear',"    assert not g.try_submit(d,3312,local_score)\n    assert g.try_submit(d,3314,local_score)","    assert not g.try_submit(d,3312,local_score) and g.choice is None\n    assert not g.try_submit(d,3330,local_score)\n    assert g.try_submit(d,3332,local_score)")
change('new_candidate',"    assert not g.try_submit(d,3305,local_score) and g.choice['key']!=old\n    assert g.try_submit(d,3307,local_score)","    assert not g.try_submit(d,3305,local_score) and g.choice is None\n    assert not g.try_submit(d,3307,local_score) and g.choice is None\n    assert not g.try_submit(d,3330,local_score) and g.choice['key']!=old\n    assert g.try_submit(d,3332,local_score)")
change('expired_choice',"    assert not g1.try_submit(d1,3320,local_score)","    assert not g1.try_submit(d1,3306,local_score)")
change('expired_choice',"g1.try_submit(d1,3322,local_score)","g1.try_submit(d1,3308,local_score)")
change('low_budget_floor',"    assert poll(d,g,3247)","    assert not poll(d,g,3247)\n    assert not poll(d,g,3264) and poll(d,g,3266)")
# Prior protocol tests keep their shortened 3300 timing fixture. New tests use
# the genuine 5400-step/3444 origin and unmodified production slot methods.
extra=(r/'extra_tests.py').read_text(encoding='utf-8')
pos=s.index("result=dict(status='PASS'")
s=s[:pos]+extra+'\n'+s[pos:]
(r/'counterexamples.py').write_text(s,encoding='utf-8')
compile(s,'counterexamples.py','exec')
print('69 inherited groups adapted for the authorized bid and slot semantics; new counterexamples appended.')
