from pathlib import Path
from hashlib import sha256
from importlib.metadata import version
from zipfile import ZipFile
import json,os,shutil,subprocess,sys

root=Path.cwd()
sealed=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/P407_P398_semifinal_three_maps_20261110')
sdk=sealed/'official_sdk'
raw=(sealed/'WORKSPACE_BINDING_FIRST.json').read_bytes()
assert sha256(raw).hexdigest()=='8a6310cdfccb0bc3c76ee4f4b6d1ab69bd6634f881f3268fb78b6302d8d77585'
binding=json.loads(raw)
assert binding['official_commit']=='6557940dc18549ffc7a945db887da5b05b7ed2f1'
for name,h in binding['sdk_files'].items():assert sha256((sdk/name).read_bytes()).hexdigest()==h,name
b=json.loads((root/'BUILD.json').read_bytes())
assert sha256((root/'original.zip').read_bytes()).hexdigest()==b['baseline_zip_sha256']
assert sha256((root/'candidate.zip').read_bytes()).hexdigest()==b['candidate_zip_sha256']
with ZipFile(root/'candidate.zip') as z:
    assert {n:sha256(z.read(n)).hexdigest() for n in z.namelist()}==b['candidate_files']
c=json.loads((root/'counterexamples.json').read_bytes())
assert c['status']=='PASS' and c['archive_sha256']==b['candidate_zip_sha256']
assert c['physics_steps']==c['physics_step_attempts']==c['full_matches']==c['map_objects_created']==0
assert 'candidate.zip/red_hooks.py' in c['loaded_red_hooks']
assert 'candidate.zip/return_exchange.py' in c['loaded_return_exchange']
alias=root/'team615_semifinal.zip';shutil.copyfile(root/'candidate.zip',alias)
env=dict(os.environ,PYTHONPATH=str(sdk/'src'),PYGLET_HEADLESS='true')
test=subprocess.run([sys.executable,str(sdk/'scripts/check_submission.py'),str(alias)],env=env,capture_output=True)
(root/'static_candidate.log').write_bytes(test.stdout+test.stderr)
assert test.returncode==0,test.stdout+test.stderr
names=['BUILD.json','original.zip','candidate.zip','counterexamples.py','counterexamples.json','counterexamples.log','static_candidate.log','validate.py']
receipt=dict(status='PASS',sdk_commit=binding['official_commit'],sdk_files_checked=len(binding['sdk_files']),
    python=sys.version,executable=sys.executable,numerical_packages={n:version(n) for n in ['numpy','pandas','opencv-contrib-python','scipy']},
    candidate_scenario_groups=c['scenario_groups'],static_submission_check='PASS',
    static_alias_sha256=sha256(alias.read_bytes()).hexdigest(),static_alias_role='Same-byte temporary static-check alias; not a competition release.',
    physics_steps=0,physics_step_attempts=0,full_matches=0,map_objects_created=0,
    files={n:sha256((root/n).read_bytes()).hexdigest() for n in names})
(root/'VALIDATION.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
