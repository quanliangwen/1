from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json,shutil

root=Path(__file__).resolve().parent
dest=root/'delivery';dest.mkdir(exist_ok=False)
digest=lambda p:sha256(p.read_bytes()).hexdigest()
b=json.loads((root/'BUILD.json').read_bytes())
v=json.loads((root/'received/VALIDATION.json').read_bytes())
c=json.loads((root/'received/counterexamples.json').read_bytes())
assert c['status']==v['status']=='PASS' and c['scenario_groups']==20
assert c['physics_steps']==c['physics_step_attempts']==c['full_matches']==0
for name,h in v['files'].items():
    p=root/name
    if not p.is_file():p=root/'received'/name
    assert digest(p)==h,name
with ZipFile(root/'candidate.zip') as z:assert {n:sha256(z.read(n)).hexdigest() for n in z.namelist()}==b['candidate_files']
assert all(digest(root/'candidate'/n)==h for n,h in b['candidate_files'].items())
assert all(digest(root/'baseline'/n)==h for n,h in b['original_files'].items())
config=dict(return_fraction=.60,example_limit=5400,example_return_start=3240,collector=0,
    split_rule=dict(team_span_at_least_pixels=160,drone0_launch_distance_at_least_pixels=140,
                    all_members_within_drone0_pixels=150,member_state_max_age_steps=12,
                    fixed_localization_and_known_safe_cell=True),
    marker_field='ReturnExchange.anchor = (mark_step, x, y)',marker_drawn_in_wall_submission=False,
    arrival='Drone0 returns to marker; peers return along their own trail into the160px area and hand off over actual radio.',
    map_completion='Actual post-threshold accepted map from each aircraft, with current shared marker; arrivals need not be simultaneous.',
    submission='Drone0 submits after all five source receipts and2ticks for ACK broadcast, with actual stock-clear, pending-drop and map checks.',
    hard_return_cutoff='DeadlineSubmission.window_start(limit)-12; at5400 this is5359',
    wall_return_cutoff_seconds_left=8,missing_marker_guest_wait_steps=12,
    marker_missing_policy='Leader falls back immediately; peers wait at most12steps for the shared marker; no launch/origin point is invented.')
result=dict(status='PASS',baseline='unmodified 潜力1.1：信使+滚动',build=b,configuration=config,
    validation=v,counterexamples=c,full_matches=0,physics_steps=0,actual_match_scores=None,
    actual_match_marker=None,actual_return_completion_steps=None,
    no_direct3240_submission=True,no_delivery_or_active_mapping_patch_layered=True,
    delivery_role='source and patch candidate, not a competition release ZIP')
(dest/'RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name,p in [('red_hooks.py',root/'candidate/red_hooks.py'),('return_exchange.py',root/'candidate/return_exchange.py'),
               ('return60_firstsplit.patch',root/'return60_firstsplit.patch'),('counterexamples.py',root/'counterexamples.py'),
               ('BUILD.json',root/'BUILD.json'),('VALIDATION.json',root/'received/VALIDATION.json')]:shutil.copyfile(p,dest/name)
with ZipFile(dest/'TEST_ARTIFACTS.zip','w',compression=ZIP_DEFLATED) as z:
    for n in ['build.py','validate.py','assemble.py']:z.write(root/n,n)
    for p in sorted((root/'received').iterdir()):z.write(p,'validation/'+p.name)
report='''潜力1.1原版：60%开始返程，首次分开区域交互候选

已实现，尚未跑整场仿真
基线为潜力1.1原版ZIP（c3021a3eb48031e82bfac9306654b48ca09f168d6f65b13349cf12f783104c7c），没有叠加第一批、按缺口配送或3240立即交图候选。
只修改red_hooks.py，新增return_exchange.py；其他52个文件字节一致。去除新接入代码可逐字节还原原版red_hooks.py。导航驱动、激光避障参数、地图拟合、投放复核、双时限模块源码没有改变。

设置
返程起始=最大步数*60%，5400步时为3240。这里3240表示开始返程，不表示此时立刻交图。未完成自身投弹、仍有pending_drop的飞机先完成原任务，空载后再进入返程。
交互点不选地图原点或启动区。由0号机在早期自动识别并一次性标记：离自身起始位置至少140px、五机跨度首次达到160px、五机新鲜位置仍在0号150px内；0号定位可靠且标记所在网格已知安全。140px沿用原探索启动区半径的含义。这里是队形首次明显分开的可操作判据，不声称识别到了真实地图道路拓扑的精确岔口。
标记为anchor=(首次标记步数,x,y)，通过red_return_exchange字段广播和转发；其他机只接受同一个标记，不各自选点，也不因后续分开而覆盖。标记保存在导航状态和audit中，不把符号或额外墙点画入提交图。

返程和交互
记录机载定位的实际经过路点，按逆序返回；短距离重新经过已知安全点时允许去掉闭环，避免重走整个探索环路。所有连接仍要经过已知墙体检查；路段受阻时使用原网格路由尝试连接，再用原drive驱动和激光避障；未知或无安全连接时先制动，不直接穿墙。
返程阶段独立于探索期“离开启动区不许回头”的约束，停止接新探索任务和旧信使巡访。0号回标记点接收，其他机回自己曾经过的通信区域即可，收到0号确认后停稳，不挤向同一坐标。
普通地图观测与刷新继续使用原机制；开始返程时补一次当前包，作为本轮版本起点。不恢复旧第一批信使ACTIVE持续刷新或其他地图拟合改动。
0号只在实际收到且已合并本轮地图后记收包。估计距离接近、仅收到库存清零、旧版本包、错误标记、未合并包均不算交付。回执只认可0号和本轮共享标记；重复广播不会重置任务或收齐时间。
0号先后收齐五机这轮地图、全队实际库存确认清零且地图可用后，留2步广播回执，直接交图。无需五机同时到场，不再叠加旧180步扫描、24步快照收集及选举等待。提交采用当前证据和原渲染器，不挑旧预制图片缓存。

异常与兜底
0号若始终没标出合适的共享分开点，立即交回原流程；其他机没有收到标记时最多等待12步，没有可用历史返程门点则退出本次返程。绝不自动猜一个出生点或原点作为替代。
返程最迟在原最终提交窗口前12步交回原流程，5400步时为5359；墙钟剩余不超过8秒也退出返程。原control前段的步数/墙钟硬兜底仍优先。
某机未回、路径不通、定位漂移、死亡或未收到有效地图时，不保证能正常收齐。保护保证有界退出与原兜底，不保证成功返程或更高分。

反例结果
20组全部PASS，pymunk.Space.step设为调用即失败，实际尝试0次；没有建立比赛地图、没有物理步、没有整场。
覆盖：非启动区首次标记；过期队形/无GPS/不安全位置/非0号不私自标记；全队共享同一不可变坐标；3239不返程、3240返程；未投完不打断；安全去环；受阻或未知路段刹停；标记迟到后的返程路径重建；缺标记或缺历史门点不长等；返程步数/墙钟截止；实际合并后才收包；旧包/未来包/错轮次/无效包不确认；只有0号有效回执才完成；60%时不立即交图；收齐后2步绕过三道旧等待；库存/空图/部分图/机号等提交约束；真实receive顺序；新探索停止；双时限优先；普通第二枚投放复核入口仍可达。
夹具演示在3300收齐、3302交图；标记夹具为step100,(200,0)。这些全部是合成反例数值，不是Map08实测位置或交图结果。
官方静态内容检查PASS，封存SDK225文件核验通过，Python3.11.17/NumPy1.26.4/Pandas3.0.6/OpenCV contrib4.11.0.86/SciPy1.17.1。临时同内容合规文件名仅用于静态检查，不作为正式比赛包放行。

交付和后续边界
在原版目录应用return60_firstsplit.patch，或替换red_hooks.py并加入return_exchange.py。不能套在3240直接交图或其他候选上。
本次仅源码/补丁候选，没有新增整场得分、实际分开点、返程耗步或探索率数据。60%开始返程是否比原版更早交图，取决于标记点距离、实际路线和收包时机；本次不承诺提分或缩短墙钟。
源码全成员哈希、内部测试ZIP哈希、详细反例与验证环境见RESULTS.json、BUILD.json、VALIDATION.json；原版和此前候选均保留。
'''
(dest/'RESULT.txt').write_text(report,encoding='utf-8')
(dest/'CHECKSUMS_SHA256.json').write_text(json.dumps({p.name:digest(p) for p in sorted(dest.iterdir())},indent=2)+'\n')
print(json.dumps({'status':'PASS','files':len(list(dest.iterdir())),'groups':20,'full_matches':0,'candidate_zip_sha256':b['candidate_zip_sha256']},indent=2))
