from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
import ast,json,subprocess

root=Path(__file__).resolve().parent
h=lambda b:sha256(b).hexdigest()
assert h((root/'original.zip').read_bytes())=='c3021a3eb48031e82bfac9306654b48ca09f168d6f65b13349cf12f783104c7c'
with ZipFile(root/'original.zip') as z:old={n:z.read(n) for n in z.namelist()}
new={p.name:p.read_bytes() for p in (root/'candidate').iterdir() if p.is_file()}
assert set(new)-set(old)=={'return_exchange.py'} and not set(old)-set(new)
assert {n for n in old if old[n]!=new[n]}=={'red_hooks.py'}
assert all((root/'baseline'/n).read_bytes()==v for n,v in old.items())
def methods(data):
    cls=next(n for n in ast.parse(data).body if isinstance(n,ast.ClassDef) and n.name=='RedHooks')
    return {n.name:ast.dump(n,include_attributes=False) for n in cls.body if isinstance(n,ast.FunctionDef)}
o,n=methods(old['red_hooks.py']),methods(new['red_hooks.py'])
changed={name for name in o if o[name]!=n[name]}
assert changed=={'__init__','receive','define_message_for_all','control'}
assert set(n)-set(o)=={'explore','_try_return_submission'}
source=new['red_hooks.py'].decode()
for method,next_method in [('_try_return_submission','control'),('explore','receive')]:
    a=source.index(f'    def {method}(');b=source.index(f'    def {next_method}(',a)
    source=source[:a]+source[b:]
for addition in [
    'from swarm_rescue.solutions.return_exchange import ReturnExchange\n',
    '        self.return_exchange = ReturnExchange()\n',
    '            self.return_exchange.receive(self, message, int(self.elapsed_timestep))\n',
    '        self.return_exchange.observe(self, step)\n',
    '        self.return_exchange.packet_built(self, step)\n',
    '        if self.return_exchange.tick(self, step, command):\n            self._try_return_submission(step)\n            return command\n\n']:
    assert source.count(addition)==1,addition
    source=source.replace(addition,'')
source=source.replace('        return dict(message, red_return_exchange=self.return_exchange.message(self, step),\n                    red_map_offer=offer, red_map_relay=self._relay_map_offer(step),',
                      '        return dict(message, red_map_offer=offer, red_map_relay=self._relay_map_offer(step),')
source=source.replace('        if (not self.return_exchange.owns(self, step)\n                and self.messenger.tick(self, step, command, steps_left)):',
                      '        if self.messenger.tick(self, step, command, steps_left):')
source=source.replace('        if refresh or self.return_exchange.packet_due(self, step) or step % 45 == self.identifier:',
                      '        if refresh or step % 45 == self.identifier:')
source=source.replace('        if (not self.return_exchange.owns(self, step)\n                and self.fast_closeout.act(self,step,command,ranges,semantic)):',
                      '        if self.fast_closeout.act(self,step,command,ranges,semantic):')
assert source.encode()==old['red_hooks.py']
for name,data in new.items():
    if name.endswith('.py'):compile(data,name,'exec')
with ZipFile(root/'candidate.zip','w',compression=ZIP_DEFLATED) as z:
    for name,data in new.items():
        info=ZipInfo(name,date_time=(2026,11,21,0,0,0));info.compress_type=ZIP_DEFLATED
        info.external_attr=0o100644<<16;z.writestr(info,data)
diff=subprocess.run(['git','-c','core.autocrlf=false','diff','--no-index','--','baseline','candidate'],cwd=root,capture_output=True)
assert diff.returncode==1
patch=diff.stdout.replace(b'a/baseline/',b'a/').replace(b'b/candidate/',b'b/')
# New-file diffs use b/candidate/name, including the old-side label.
patch=patch.replace(b'a/candidate/',b'a/')
(root/'return60_firstsplit.patch').write_bytes(patch)
check=subprocess.run(['git','apply','--check',str(root/'return60_firstsplit.patch')],cwd=root/'baseline',capture_output=True)
assert check.returncode==0,check.stderr
b=dict(status='PASS',baseline_zip_sha256=h((root/'original.zip').read_bytes()),candidate_zip_sha256=h((root/'candidate.zip').read_bytes()),
    baseline_member_count=len(old),candidate_member_count=len(new),changed_existing_files=['red_hooks.py'],
    added_files=['return_exchange.py'],unchanged_files=52,changed_existing_methods=sorted(changed),
    added_methods=['explore','_try_return_submission'],original_red_hooks_reconstructed_byte_identical=True,
    original_files={name:h(data) for name,data in old.items()},candidate_files={name:h(data) for name,data in new.items()},
    compile='PASS',patch_apply_check='PASS',package_role='internal counterexample ZIP; source/patch delivery, not competition release')
(root/'BUILD.json').write_text(json.dumps(b,indent=2)+'\n')
print(json.dumps({k:v for k,v in b.items() if k not in ['original_files','candidate_files']},indent=2))
