from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
r=Path(__file__).resolve().parent
candidate=r.parent/'team615_first_round_yield_20261121'
prior=r.parent/'team615_first_round_yield_maps_20261121'
remote='/home/quanliangwen/isolated_test/team615_yield_map06_JjMdyG'
host='quanliangwen@10.112.162.60';read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
b=read(candidate/'BUILD.json');v=read(candidate/'VALIDATION.json');c=read(candidate/'counterexamples.json')
assert b['candidate_zip_sha256']==v['candidate_zip_sha256']==c['archive_sha256']==h(candidate/'candidate_snapshot.zip')
assert c['scenario_groups']==107 and c['status']==v['status']=='PASS'
assert h(candidate/'baseline_snapshot.zip')==b['baseline_zip_sha256']
(r/'SERVER_STAGE.txt').write_text(remote+'\n')
for n in ['candidate_snapshot.zip','baseline_snapshot.zip','BUILD.json','VALIDATION.json','counterexamples.json']:
    shutil.copyfile(candidate/n,r/n)
for n in ['matched_spawns.json','EXPECTED_ZONES.json','stage_run.py','SDK_SELECTION_EVIDENCE.json']:
    shutil.copyfile(prior/n,r/n)
patch=dict(baseline_commit='4263f1dd815428977104b2ca869db6e1120c8a92',baseline_zip_sha256=b['baseline_zip_sha256'],
    candidate_zip_sha256=b['candidate_zip_sha256'],baseline=b['original_files'],candidate=b['candidate_files'],changed=b['changed_existing_files'])
(r/'PATCH_BINDING.json').write_text(json.dumps(patch,indent=2)+'\n')
(r/'DECLARED_SOURCE.json').write_text(json.dumps(b['candidate_files'],indent=2)+'\n')
(r/'OFFLINE_CHECK.json').write_text(json.dumps(dict(simulation_steps=0,unit_groups=107,validation_sha256=h(r/'VALIDATION.json')))+'\n')
(r/'AUTHORIZED_RUN.json').write_text(json.dumps(dict(maps=['Map06'],seed=615,new_red_rounds=1,blue_rounds=0,algorithm_changes=False))+'\n')
folder=r/'Map06';folder.mkdir(exist_ok=False)
for n in ['stage_run.py','candidate_snapshot.zip','baseline_snapshot.zip','DECLARED_SOURCE.json','PATCH_BINDING.json',
          'BUILD.json','VALIDATION.json','counterexamples.json','matched_spawns.json','EXPECTED_ZONES.json','OFFLINE_CHECK.json']:
    shutil.copyfile(r/n,folder/n)
(folder/'place_map09.yml').write_text((prior/'Map08/place_map09.yml').read_text().replace('map_name: Map08','map_name: Map06'),encoding='utf-8')
(folder/'run_once.sh').write_text((prior/'Map08/run_once.sh').read_text().replace('Map08','Map06'),encoding='utf-8',newline='\n')
(folder/'OBSERVATION_BINDING.json').write_text(json.dumps(dict(observer_sha256=h(folder/'stage_run.py'),
    entire_observer_byte_identical_to_previous=True,in_match_observer_functions_ast_identical_to_previous=True,
    map='Map06',seed=615,controller_frozen_sha256=b['candidate_zip_sha256'],new_red_rounds_authorized=1),indent=2)+'\n')
subprocess.run(['ssh','-o','BatchMode=yes',host,f'mkdir {remote}/Map06'],check=True)
subprocess.run(['scp','-q','-o','BatchMode=yes',*[str(p) for p in folder.iterdir()],f'{host}:{remote}/Map06/'],check=True)
command=f'nohup bash {remote}/Map06/run_once.sh {remote}/Map06 > {remote}/Map06/dispatch.log 2>&1 < /dev/null & echo QUEUED_MAP06_ONCE'
p=subprocess.run(['ssh','-o','BatchMode=yes',host,command],capture_output=True,check=True,timeout=30)
print(p.stdout.decode());print(b['candidate_zip_sha256'])
