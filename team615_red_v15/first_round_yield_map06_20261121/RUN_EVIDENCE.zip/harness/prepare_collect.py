from pathlib import Path
r=Path(__file__).resolve().parent;p=r.parent/'team615_first_round_yield_maps_20261121'
s=(p/'collect.py').read_text(encoding='utf-8')
s=s.replace("choices=['Map08','Map09']","choices=['Map06']")
s=s.replace("current=(r.parent/'team615_group_exchange_map06_map08_20261121/Map08/received' if name=='Map08'\n         else r.parent/'team615_group_exchange_map09_20261121/received')", "current=r.parent/'team615_group_exchange_map06_map08_20261121/Map06/received'")
s=s.replace("previous=r.parent/'team615_neartie_maps_20261121'/name/'received'\n",'')
s=s.replace("          previous=summary(verify_history(previous,b['original_files']),previous),candidate=summary(score,received))", "          candidate=summary(score,received))")
s=s.replace("['original','current','previous']","['original','current']")
s=s.replace("[('original',original),('current',current),('previous',previous)]", "[('original',original),('current',current)]")
s=s.replace('historical_red_rounds=3','historical_red_rounds=2')
compile(s,'collect.py','exec');(r/'collect.py').write_text(s,encoding='utf-8')
for n in ['offline_map_score.py','augment_offline.py']:
    code=(p/n).read_text(encoding='utf-8').replace("choices=['Map08','Map09']","choices=['Map06']")
    (r/n).write_text(code,encoding='utf-8')
print('Prepared Map06-only collection with original and three-map historical controls.')
