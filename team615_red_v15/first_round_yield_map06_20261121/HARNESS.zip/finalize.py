from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json
r=Path(__file__).resolve().parent;d=r/'delivery';read=lambda p:json.loads(p.read_bytes());h=lambda p:sha256(p.read_bytes()).hexdigest()
s=read(d/'RESULTS.json');a=read(r/'ANALYSIS.json');b=read(r/'BUILD.json')
assert s['configuration']['maps']==['Map06'] and s['configuration']['new_red_rounds']==1 and s['configuration']['other_maps_run']==0
assert h(d/'CANDIDATE_SOURCE.zip')==h(r/'candidate_snapshot.zip')==b['candidate_zip_sha256']
assert h(d/'CANDIDATE_SOURCE.zip')==h(r.parent/'team615_first_round_yield_20261121/delivery/CANDIDATE_SOURCE.zip')
assert read(r/'Map06/received/POST_RUN_SOURCE_CHECK.json')['status']=='PASS'
assert s['map']['personal_original_integrity']['status']=='PASS'
for n in ['CANDIDATE_SOURCE.zip','RUN_EVIDENCE.zip']:
    with ZipFile(d/n) as z:assert z.testzip() is None
assert '<!--' not in (d/'README.md').read_text(encoding='utf-8')
proof=dict(source_frozen=True,new_red_rounds=1,only_Map06=True,all_ordinary_modes_false=a['all_ordinary_modes_false'],
    ordinary_group_submit_events=a['group_ordinary_submit_events'],
    actual_submissions=a['protocol']['candidate']['submissions'],
    selected_equals_original=a['selected_equals_original'],selected_equals_three_map=a['selected_equals_three_map'])
s['fact_checks']=proof;(d/'RESULTS.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(r/'FACT_CHECK.json').write_text(json.dumps(dict(status='PASS',proof=proof),indent=2)+'\n')
with ZipFile(d/'HARNESS.zip','a',ZIP_DEFLATED) as z:
    z.write(r/'finalize.py','finalize.py');z.write(r/'FACT_CHECK.json','FACT_CHECK.json')
files={p.name:h(p) for p in sorted(d.iterdir()) if p.name!='CHECKSUMS_SHA256.json'};assert len(files)==12,len(files)
(d/'CHECKSUMS_SHA256.json').write_text(json.dumps(files,indent=2)+'\n')
print(json.dumps(dict(status='PASS',delivery_files=13,proof=proof),indent=2))
