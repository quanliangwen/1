from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,numpy as np
r=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes())
paths=dict(original=r.parent/'team615_messenger_batch1_20261121/received/Map06_baseline',
    current=r.parent/'team615_group_exchange_map06_map08_20261121/Map06/received',candidate=r/'Map06/received')
result=read(r/'Map06/RESULTS.json');data=dict(arms=result['arms'],candidate_minus=result['candidate_minus'],
    recorded_prefix=result['recorded_prefix'],protocol={},details={})
for arm,path in paths.items():
    s=read(path/'OFFICIAL_SCORE.json');per_step=defaultdict(list)
    for row in s['submissions']:per_step[row['step']].append(row['drone'])
    data['protocol'][arm]=dict(selected=s['selected_submission'],submissions=s['submissions'],
        simultaneous={str(step):ids for step,ids in per_step.items() if len(ids)>1},
        hard_fallbacks={str(d['drone']):d['walltime_submission'] for d in s['drone_details'] if d['walltime_submission']})
s=read(paths['candidate']/'OFFICIAL_SCORE.json')
for d in s['drone_details']:
    info={k:v for k,v in d.items() if k.startswith('original_') or k in ['group_ordinary_selection','group_finish_refresh_step',
        'group_end_slot','group_final_snapshot_count','group_final_snapshot_origins','group_first_round_window','group_yielding_at_end',
        'group_best_metadata','group_score_table','group_choice','final_inventory_records','last_confirmation','health','walltime_submission']}
    info['submission_events']=[e for e in d['group_audit'] if e[1] in ['finish_candidate_refreshed','choice_received','choice_proposed','submitted','soft_cutoff_submit']]
    info['positive_or_missing_inventory']={str(i):d['final_inventory_records'].get(str(i),d['final_inventory_records'].get(i))
        for i in range(5) if d['final_inventory_records'].get(str(i),d['final_inventory_records'].get(i,(-1,None)))[1]!=0}
    data['details'][str(d['drone'])]=info
data['all_ordinary_modes_false']=all(not d['group_ordinary_selection'] for d in s['drone_details'])
data['group_ordinary_submit_events']=[dict(drone=d['drone'],event=e) for d in s['drone_details'] for e in d['group_audit'] if e[1] in ['submitted','soft_cutoff_submit']]
meta=read(paths['candidate']/'GROUP_DATASET.json');arrays=np.load(paths['candidate']/'group_dataset.npz');hashes={}
for owner,m in meta.items():
    for slot,entry in m['images'].items():
        image=np.unpackbits(arrays[f'd{owner}_image{slot}'])[:m['width']*m['height']].reshape(m['height'],m['width']).astype(np.uint8)
        hashes[f'{owner}:{slot}']=dict(version=entry['version'],sha256=sha256(image.tobytes()).hexdigest())
data['bitmap_hashes']=hashes
data['selected_equals_original']=s['selected_image_sha256']==result['arms']['original']['selected_submission']['image_sha256']
data['selected_equals_three_map']=s['selected_image_sha256']==result['arms']['current']['selected_submission']['image_sha256']
data['offline_map_scores']=result.get('offline_map_scores')
(r/'ANALYSIS.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(arms={a:{k:v[k] for k in ['partial_score_out_of_80','map_score','submission_step','missed_wall_pixels',
    'charged_misdraw_pixels','exploration_percent','placed','total_health_lost','elapsed_walltime_seconds']} for a,v in data['arms'].items()},
    all_ordinary_modes_false=data['all_ordinary_modes_false'],protocol=data['protocol'],details=data['details']),indent=2))
