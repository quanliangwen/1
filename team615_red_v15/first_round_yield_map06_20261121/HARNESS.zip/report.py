from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json,shutil
r=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());h=lambda p:sha256(p.read_bytes()).hexdigest()
data=read(r/'Map06/RESULTS.json');a=read(r/'ANALYSIS.json');b=read(r/'BUILD.json');v=read(r/'VALIDATION.json');tests=read(r/'counterexamples.json')
assert data['new_red_rounds']==1 and data['historical_red_rounds']==2
assert data['post_run_source_check']['status']==data['personal_original_integrity']['status']=='PASS'
assert data['offline_map_scores']['selected_submission_reproduced']
assert b['candidate_zip_sha256']==v['candidate_zip_sha256']==tests['archive_sha256']==h(r/'candidate_snapshot.zip')
assert tests['scenario_groups']==107 and read(r/'HISTORY_AUDIT.json')['status']=='PASS'
assert h(r/'candidate_snapshot.zip')==h(r.parent/'team615_first_round_yield_20261121/delivery/CANDIDATE_SOURCE.zip')
for delta in data['candidate_minus'].values():
    assert abs(.5*delta['map_score']+.2*delta['wall_score']+.1*delta['time_score']-delta['partial_score_out_of_80'])<1e-8
config=dict(maps=['Map06'],seed=615,new_red_rounds=1,historical_comparison_red_rounds=2,blue_rounds=0,other_maps_run=0,
    candidate_modified_during_this_task=False,candidate_zip_sha256=b['candidate_zip_sha256'],
    sdk_commit='6557940dc18549ffc7a945db887da5b05b7ed2f1',drones=5,bombs_per_drone=2,timestep_limit=5400,walltime_limit=180,
    zones=['NO_COM_ZONE','NO_GPS_ZONE'],entire_observer_byte_identical_to_previous=True,source_frozen_and_rechecked_after_match=True)
result=dict(status='COMPLETE',configuration=config,map=data,analysis=a,history_audit=read(r/'HISTORY_AUDIT.json'),
    limitations=['Only one new Map06 seed615 round; two controls reuse source-verified historical runs.',
        'Red-side subtotal out of 80 only; blue-side 20 not tested.',
        'No new near-tie/six-slot Map06 baseline run. This experiment alone cannot isolate all previous package changes.',
        'Runtime load affects wall-clock termination step; do not equate step differences with intentional yielding or computing speedup.',
        'Post-match scorer sees saved truth; controller does not.'])
d=r/'delivery';d.mkdir(exist_ok=True)
(d/'RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
arms=['original','current','candidate'];labels=dict(original='潜力1.1原版',current='三图候选',candidate='首轮30步让行候选')
metrics=[('交图步数','submission_step',0),('红队小计 / 80','partial_score_out_of_80',4),('地图分 / 100','map_score',4),
    ('墙覆盖分 / 100','wall_score',4),('漏墙像素','missed_wall_pixels',0),('扣分误画像素','charged_misdraw_pixels',0),
    ('探索率 / %','exploration_percent',4),('实投数 / 10','placed',0),('总掉血 / 初始125','total_health_lost',0),('墙钟 / 秒','elapsed_walltime_seconds',3)]
lines=['# 首轮30步让行候选：Map06，种子615，仅1局','',
    '本轮只对冻结的首轮让行候选跑1局Map06；不改算法、不跑Map08/Map09或其他地图。三图候选和原版复用经过源码、SDK、出生位置、禁区配置及原始产物SHA256核验的同种子历史运行。','',
    '红队小计满分80，蓝队20分未测。漏墙采用wall_pixels减wall_hits；误画为官方charged_pixels，墙钟为官方评分的elapsed_walltime。','',
    f"候选SHA256：`{b['candidate_zip_sha256']}`，与上轮107组反例通过及Map08/Map09运行的候选完全一致。",'',
    '三图候选SHA256：`641685d7bd460f6241abb4e2c0f02527d7324a37d78f6492401d66a4b6a63cda`。原版53项、三图56项源码逐项与原清单一致核验。候选运行前后56项源码不变。',
    '', 'SDK6557940dc18549ffc7a945db887da5b05b7ed2f1、5机、每机2枚、5400步、180秒，NO_COM_ZONE及NO_GPS_ZONE开启。观察脚本与上轮整份字节一致，所有竞价和最终快照字段均在评分后导出；没有新增比赛中审计回调。原107组反例与静态检查回执随包保留，本轮未重跑这些测试。','',
    '## 三版对照','', '| 指标 | '+' | '.join(labels[x] for x in arms)+' |','|---|---:|---:|---:|']
for label,key,prec in metrics:
    lines.append('| '+label+' | '+' | '.join(f"{data['arms'][x][key]:.{prec}f}" for x in arms)+' |')
lines += ['| SDK采用交图机 | '+' | '.join(str(data['arms'][x]['selected_submission']['drone'])+'号' for x in arms)+' |',
    '| 同帧提交记录 | '+' | '.join('; '.join(f"{step}步：{','.join(map(str,ids))}号" for step,ids in a['protocol'][x]['simultaneous'].items()) or '无' for x in arms)+' |','',
    '## 是否误让行及提交依据','',(r/'FINDINGS.md').read_text(encoding='utf-8').strip(),'',
    '| 无人机 | 普通终选模式曾开启 | 最终重比步 | 结束时FinalMaps数 | 结束时仍缺的库存确认 | 硬兜底步 |','|---|---|---:|---:|---|---:|']
for owner,info in a['details'].items():
    hard=info['walltime_submission']
    lines.append(f"| {owner}号 | {info['group_ordinary_selection']} | {info['group_finish_refresh_step']} | {info['group_final_snapshot_count']} | {json.dumps(info['positive_or_missing_inventory'],ensure_ascii=False)} | {hard['step'] if hard else '—'} |")
lines += ['', '结束帧的让行条件只表示该帧状态，不单独作为首轮是否触发的证据。判断结合从未重置的ordinary_selection、最终重比/提案审计和全队库存检查顺序。','',
    '## 赛后位图核验','', '| 持有者 | 候选槽 | 位图版本 | 官方地图分 |','|---|---:|---:|---:|']
off=data['offline_map_scores']
for row in off['candidates']:
    if row['holder']==data['arms']['candidate']['selected_submission']['drone']:
        lines.append(f"| {row['holder']}号 | {row['slot']} | {row['version']} | {row['map_score']:.4f} |")
lines += ['',f"实际提交地图分{off['actual_map_score']:.4f}已用保存位图复现；全部保存候选最高{off['best_saved_candidate']['map_score']:.4f}，由{off['best_saved_candidate']['holder']}号持有、槽{off['best_saved_candidate']['slot']}。没有新物理步或控制器重放，也没有把真值送入控制器。",'',
    f"个人原图完整性{data['personal_original_integrity']['images_verified']}份持有记录PASS；实际采用图与所选缓存一致。",'',
    '## 文件及边界','',
    'RUN_EVIDENCE.zip包含新局评分、轨迹、位图、快照及两个历史对照原始证据。ANALYSIS.json记录库存缺口、普通模式、缓存与提交信息；HARNESS.zip保存运行/采集/分析脚本。RESULTS.json包含三版指标、差值与全部校验。',
    '', 'CANDIDATE_SOURCE.zip为冻结研究源码的原字节快照，不是新正式参赛发布包，未上传官网。单图单种子及历史墙钟负载差异不足以证明稳定提分或计算加速。']
(d/'README.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
shutil.copyfile(r/'Map06/RESULTS.json',d/'Map06_RESULTS.json');shutil.copyfile(r/'Map06/RUN_EVIDENCE.zip',d/'RUN_EVIDENCE.zip')
for n in ['ANALYSIS.json','HISTORY_AUDIT.json','BUILD.json','VALIDATION.json','counterexamples.json','SDK_SELECTION_EVIDENCE.json']:
    shutil.copyfile(r/n,d/n)
shutil.copyfile(r/'candidate_snapshot.zip',d/'CANDIDATE_SOURCE.zip')
with ZipFile(d/'HARNESS.zip','w',ZIP_DEFLATED) as z:
    for n in ['provision.py','prepare_collect.py','audit_history.py','collect.py','stage_run.py','analyze.py','report.py',
        'offline_map_score.py','augment_offline.py','SERVER_STAGE.txt','AUTHORIZED_RUN.json','FINDINGS.md']:
        z.write(r/n,n)
print(json.dumps(dict(status='PASS',arms={x:{k:data['arms'][x][k] for k in ['partial_score_out_of_80','map_score','submission_step']} for x in arms}),indent=2))
