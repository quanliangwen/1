"""Identify the disappearing Map08 candidates and compare recorded placement geometry."""
from collections import Counter, defaultdict
from hashlib import sha256
import json
import math
from pathlib import Path
import sys

import numpy as np


root = Path(__file__).resolve().parent
received = root / "received"
arms = tuple(sys.argv[1:]) or ("batch1", "batch2")
records = {}
scores = {}
drops = {}
frames = {}
for arm in arms:
    path = received / f"Map08_{arm}"
    score = json.loads((path/"OFFICIAL_SCORE.json").read_bytes())
    data = (path/"placement_events.jsonl").read_bytes()
    assert score["placement_events_sha256"] == sha256(data).hexdigest()
    records[arm] = [json.loads(line) for line in data.splitlines()]
    scores[arm] = score
    placed = defaultdict(list)
    for row in records[arm]:
        if row["event"] == "sdk_placement" and row["accepted"]:
            placed[row["drone"]].append(row)
    assert sum(len(v) for v in placed.values()) == score["placed"]
    drops[arm] = {(drone, ordinal): row for drone, entries in placed.items()
                  for ordinal,row in enumerate(entries, 1)}
    frames[arm] = {(row["drone"], row["step"]): row for row in records[arm] if row["event"]=="trace"}

focus = [(354.4525436865322, 75.14069127771683), (362.83988543197245, 66.55858789654071)]
checkpoints = {}
for arm in arms:
    survey = []
    review = []
    for row in records[arm]:
        if row["event"] == "survey":
            _, floor, sites, _ = row["values"]
            for site in sites:
                if any(math.dist(site[1],point)<.02 for point in focus):
                    survey.append(dict(step=row["step"], floor=floor, gain=site[4]["gain"], point=site[1],
                         reasons=site[3], survives=any(math.dist(b[1],site[1])<.02 for b in row["backups"]),
                         backups_near=[b for b in row["backups"] if math.dist(b[1],site[1])<9]))
        if row["event"] == "reserve_review" and row["drone"] == 4 and row["step"] == 2188:
            phase, _, current, floor, sites, backups = row["values"]
            review.append(dict(phase=phase, current=current, floor=floor, backups=backups,
                site_count=len(sites), eligible=[s for s in sites if not s[3]],
                correct_sites=[s for s in sites if any(math.dist(s[1],point)<.02 for point in focus)],
                high_probes=sorted([s for s in sites if s[0]=="current_probe"], key=lambda s:-s[4]["gain"])[:3]))
    checkpoints[arm] = dict(survey=survey, reserve=review)

a,b = arms[:2]
diffs = {}
for drone in (0,2,3,4):
    diffs[drone] = {}
    for key in ("physical_xy","pose","route","task","mode","command","health",
                "site_plan","closeout_target","peer4_inventory","peer4_reservation","peer4_drop","direct_from4"):
        diff = next((t for t in range(2178,2321)
                     if (drone,t) in frames[a] and (drone,t) in frames[b]
                     and frames[a][drone,t][key] != frames[b][drone,t][key]),None)
        if diff is not None:
            diffs[drone][key] = dict(step=diff, variants={arm:frames[arm][drone,diff][key] for arm in (a,b)})
    if drone != 4:
        observed = {}
        for arm in arms:
            observed[arm] = [
                {"step":t, "peer4_inventory":frames[arm][drone,t]["peer4_inventory"],
                 "peer4_reservation":frames[arm][drone,t]["peer4_reservation"],
                 "peer4_drop":frames[arm][drone,t]["peer4_drop"],
                 "target":frames[arm][drone,t]["closeout_target"],
                 "physical":frames[arm][drone,t]["physical_xy"]}
                for t in (2187,2188,2189,2190,2192,2200,2220,2250,2270,2295,2308,2314,2315)
                if (drone,t) in frames[arm]]
        diffs[drone]["checkpoints"] = observed

geometry_file = received/f"Map08_{a}"/"wall_geometry.npz"
assert sha256(geometry_file.read_bytes()).hexdigest() == scores[a]["wall_geometry_sha256"]
with np.load(geometry_file) as geometry:
    walls, boundary = geometry["walls"] != 0, geometry["boundary"] != 0
h,w=walls.shape
rr,cc=np.nonzero(walls)
params=scores[a]["wall_breakdown"]
radius=params["blast_radius"]
denom=params["theoretical_optimum"]
weights=np.where(boundary[rr,cc], params["boundary_wall_weight"], 1.)
blast_by_center={}
for events in drops.values():
    for drop in events.values():
        x,y=drop["physical_xy"]
        r,c=round(h/2-y),round(w/2+x)
        blast_by_center[x,y]=(rr-r)**2+(cc-c)**2<=radius**2

def wall_score(events):
    union=np.zeros(rr.shape,bool)
    for event in events.values():
        union|=blast_by_center[tuple(event["physical_xy"])]
    return float(weights[union].sum()*100/denom)

measured = dict((arm,wall_score(drops[arm])) for arm in arms)
for arm in arms:
    assert math.isclose(measured[arm],scores[arm]["coverage"],abs_tol=1e-9), (arm,measured)
assert drops[a].keys() == drops[b].keys()
unchanged=[key for key in sorted(drops[a]) if drops[a][key]["physical_xy"]==drops[b][key]["physical_xy"]]
changed=[key for key in sorted(drops[a]) if key not in unchanged]
d4 = [(4,2)]
later=[(0,2),(2,2),(3,2)]
def substitute(keys):
    return wall_score({key:(drops[b][key] if key in keys else old) for key,old in drops[a].items()})

coverage=dict(actual=measured, base_layout_with_only_d4_replaced=substitute(d4),
              base_layout_with_only_later_three_replaced=substitute(later),
              base_layout_with_d4_and_later_three_replaced=substitute(d4+later),
              changes=[dict(drone=d,ordinal=n, variants={arm:drops[arm].get((d,n)) for arm in arms})
                       for d,n in changed], identical_positions=unchanged)
if "fixed" in drops:
    coverage["repair_positions_identical_to_batch1"] = [
        key for key,event in drops[a].items() if key in drops["fixed"]
        and event["physical_xy"] == drops["fixed"][key]["physical_xy"]]
    coverage["repair_and_batch1_later_three_match"] = all(
        key in drops["fixed"] and drops["fixed"][key]["physical_xy"] == drops[a][key]["physical_xy"]
        and drops["fixed"][key]["step"] == drops[a][key]["step"] for key in later)
noise_observation = {
    arm: {
        str(step): dict(Counter(kind for kind, *_ in frames[arm][4,step]["semantic"]))
        for step in (2188,2189,2190)
    } for arm in arms
}
downstream = {
    str(drone): {
        "separation_from_drone4_at_2190": {
            arm: math.dist(frames[arm][drone,2190]["physical_xy"], frames[arm][4,2190]["physical_xy"])
            for arm in arms},
        "any_direct_message_from_drone4": {
            arm: any(frames[arm][drone,t]["direct_from4"] for t in range(2188,2316))
            for arm in arms},
        "observed_own_physics_and_pose": diffs[drone],
    } for drone in (0,2,3)
}
sdk_noise_sources = [
    "src/swarm_rescue/simulation/ray_sensors/drone_semantic_sensor.py:187-203",
    "src/swarm_rescue/simulation/utils/utils_noise.py:103-108",
    "src/swarm_rescue/simulation/drone/drone_sensors.py:99-106",
]
analysis = dict(arms=arms, checkpoints=checkpoints, first_differences=diffs, coverage=coverage,
                drone4_semantic_hit_counts=noise_observation, downstream=downstream,
                sdk_shared_noise_source=sdk_noise_sources)
(root/"MAP08_DIAGNOSIS.json").write_text(json.dumps(analysis,indent=2)+"\n",encoding="utf-8")
print(json.dumps(dict(checkpoints=checkpoints, coverage=coverage,
                      first={d:{k:v for k,v in row.items() if k!="checkpoints"} for d,row in diffs.items()}),indent=2))
