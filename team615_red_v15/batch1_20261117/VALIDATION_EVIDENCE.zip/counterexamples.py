"""Run the same boundary scenarios against either exact ZIP with the pinned SDK."""
import argparse
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
from zipfile import ZipFile

import numpy as np
import swarm_rescue.solutions


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("arm", choices=("baseline", "candidate"))
args = parser.parse_args()
with ZipFile(args.source) as archive:
    assert len(archive.namelist()) == 51 and archive.testzip() is None
swarm_rescue.solutions.__path__ = [str(args.source.resolve())]

from swarm_rescue.solutions import placement_maneuvers as maneuvers_module
from swarm_rescue.solutions.deadline_submission import DeadlineSubmission
from swarm_rescue.solutions.fast_closeout import FastCloseout
from swarm_rescue.solutions.lbbd_rescue import LBBDRescue
from swarm_rescue.solutions.red_hooks import RedHooks
from swarm_rescue.solutions.second_drop_site import SecondDropSite


def noop(*args, **kwargs):
    pass


def false(*args, **kwargs):
    return False


def record_placement(drone, command, *args):
    command["place_bomb"] = 1


class Flight(RedHooks):
    def __init__(self, step, walltime, stock):
        self.elapsed_timestep = step
        self.elapsed_walltime = walltime
        self.identifier = 0
        self.limit = 5400
        self.walltime_limit = 180
        self.initial_inventory = 2
        self.previous_inventory = stock
        self.inventory_records = {1: (step - 200, 1)}
        self.team_size = 5
        self.pending_drop = None
        self.last_confirmed_drop_step = None
        self.submitted = False
        self.deadline_submission = DeadlineSubmission()
        self.deadline_versions = {}
        self.final_maps = NS(freeze=noop, snapshots={})
        self.memory = NS()
        self.pose = np.array([0.0, 0.0])
        self.drop_records = {}
        self.scan_calls = 0
        self.submission_image_calls = 0
        self.drop_departure = NS(update=noop, steer=noop, controls_step=-1)
        self.second_drop = NS(observe_route=noop, control=noop)
        self.team_wall = NS(reservation=None, steer=false)
        self.fast_closeout = NS(act=false)
        self.placement = NS(maneuvers=NS(remember=noop, exit=None, waiting_exit=None, approach=None),
                            _ordinary_start_step=lambda *args: 1, update=record_placement)
        self.search_roaming = NS(departed=False)
        self.pre_submit_scan = NS(refresh_due=false)
        self.local_escape = NS(apply=noop)
        self.sent = None
        self.stock = stock
        self.image = np.zeros((16, 24), dtype=np.uint8)
        self.image[5, 2:12] = 1

    def carried_bombs_count(self):
        return self.stock

    def lidar_values(self):
        self.scan_calls += 1
        return None

    def semantic_values(self):
        return ()

    def _update_drop_hints(self, *args):
        pass

    def _submission_image(self, step):
        self.submission_image_calls += 1
        return self.image, None, {}

    def submit_exploration_map(self, image):
        self.sent = image.copy()


candidate = args.arm == "candidate"
results = {}
for tag, step, walltime, stock, blocked_act in (
    ("walltime_missing_peer", 5000, 179, 0, False),
    ("walltime_holding_bomb", 5000, 179, 1, False),
    ("timestep_holding_bomb", 5396, 146, 1, False),
    ("walltime_during_fast_closeout", 5000, 179, 1, True),
    ("healthy_budget", 5000, 140, 1, False),
):
    drone = Flight(step, walltime, stock)
    if candidate:
        drone.deadline_submission.remember(4930, drone.image)
    if blocked_act:
        drone.fast_closeout.act = lambda *args: True
    with patch.object(LBBDRescue, "control", return_value={"forward": 0.5}) as normal:
        command = drone.control()
    should_submit = candidate and tag != "healthy_budget"
    assert drone.submitted == should_submit and bool(drone.sent is not None) == should_submit
    if should_submit:
        assert drone.deadline_submission_event["fallback"] == tag.split("_")[0]
        assert drone.deadline_submission_event["local_inventory"] == stock
        assert drone.deadline_submission_event["team_confirmed"] is False
        assert drone.deadline_submission_event["backup_step"] == 4930
        assert np.array_equal(drone.sent, drone.image) and drone.sent.dtype == np.uint8
        assert command["place_bomb"] == 0 and not normal.called and not drone.submission_image_calls
    results[tag] = {"submitted": drone.submitted, "ordinary_control_called": normal.called,
                    "place_bomb": command["place_bomb"]}

drone = Flight(5000, 179, 1)
drone.pending_drop = (1, np.array([2.0, 3.0]), 4999)
drone.stock = 0
drone.pose = None
if candidate:
    drone.deadline_submission.remember(4930, drone.image)
with patch.object(LBBDRescue, "control", return_value={"forward": 0.0}), redirect_stdout(io.StringIO()):
    drone.control()
assert drone.last_confirmed_drop_step == 5000 and drone.pending_drop is None
assert drone.submitted == candidate
if candidate:
    assert drone.deadline_submission_event["local_inventory"] == 0
results["physics_confirmation_before_submit_missing_pose"] = {
    "submitted": drone.submitted, "confirmed_inventory": drone.previous_inventory,
}

if candidate:
    drone = Flight(5000, 179, 1)
    drone.pose = None
    with patch.object(LBBDRescue, "control", side_effect=AssertionError("normal control")):
        drone.control()
    assert drone.submitted and drone.submission_image_calls == 1
    results["no_backup_renders_available_map"] = True

    drone = Flight(5000, 179, 1)
    drone.pose = None
    drone.image[:] = 0
    with patch.object(LBBDRescue, "control", return_value={"forward": 0.0}):
        drone.control()
    assert not drone.submitted and drone.submission_image_calls == 1
    results["empty_image_is_not_submitted"] = True

    deadline = DeadlineSubmission()
    assert deadline.fallback_reason(4999, 5400, 175, 180) is None
    assert deadline.fallback_reason(5000, 5400, 177.1, 180) is None
    assert deadline.fallback_reason(5001, 5400, 178.45, 180) == "walltime"
    assert deadline.backup_due(1)
    deadline.remember(100, drone.image)
    assert not deadline.backup_due(459) and deadline.backup_due(460)
    results["slowdown_and_backup_refresh"] = True

fast = FastCloseout(0, 5)
fast.plan = (2000, 0)
route = [(20.0, 0.0)]
drone = NS(identifier=0, previous_inventory=1, initial_inventory=2, pending_drop=None,
           limit=5400, walltime_limit=180.0, elapsed_walltime=50.0,
           _odometry_only=False, route=route, fast_closeout=fast,
           drop_departure=NS(started=None), grid=NS(pose_fixed=True, HULL_CLEARANCE=11.),
           search_roaming=NS(departed=True), pose=np.array([0., 0.]),
           _all_inventory_empty=false, team_wall=NS(query=lambda *args: lambda point: (4., 4., (1,))),
           corridor_walls=lambda *args: ((), 80., 0.))

second = SecondDropSite()
second.recent_at = lambda *args: True
second._site_block = noop
second.assess = lambda *args, **kwargs: ((0., 0.), None, .8, [], None)
drone.second_drop = second
placement = NS(_first_drop_exit_clear=lambda *args: True, _coverage_minimum=lambda *args: .8,
               _spaced_from_bombs=lambda *args: True, _patch_open=lambda *args: True,
               place=record_placement)
drone.placement = placement
maneuvers = maneuvers_module.PlacementManeuvers()
maneuvers.path.append((1999, (0., 0.)))
axis = np.array([1., 0.])
exit_point = (-20., 0.)
maneuvers.prior_exit = lambda *args: (exit_point, axis, 20.)
rng = np.array([50., 50.])

assert not second.on_route_opportunity(drone, 2000, rng, ())
second.observe_route(drone, 2000, rng, ())
assert not second.audit
assert not maneuvers.drop_in_lane(placement, drone, {}, 2000, rng, rng, (), 1)
assert fast.phase(2048) == "relay"
assert fast.act(drone, 2049, {}, rng, ()) is False and fast.done and fast.plan == (2000, 0)
assert fast.phase(2049) is None
second.observe_route(drone, 2064, rng, ())
survey = any(row[1] == "survey" for row in second.audit)
opportunity = second.on_route_opportunity(drone, 2064, rng, ())
maneuvers.narrow_evidence = (2054, exit_point, tuple(axis))
command = {}
with patch.object(maneuvers_module, "traffic_clear", return_value=True), \
     patch.object(maneuvers_module, "laser_points", return_value=((), (), ())), \
     patch.object(maneuvers_module, "visible_lane", return_value=True), \
     patch.object(maneuvers_module, "speed_and_velocity", return_value=(0., np.zeros(2))):
    narrow = maneuvers.drop_in_lane(placement, drone, command, 2064, rng, rng, (), 1)
assert survey == opportunity == narrow == candidate
assert bool(command.get("place_bomb")) == candidate
results["expired_closeout_resume"] = dict(survey=survey, on_route_eligible=opportunity, narrow_drop_request=narrow)
print(json.dumps(dict(arm=args.arm, status="PASS", scenarios=results), indent=2))
