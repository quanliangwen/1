from pathlib import Path
r=Path(__file__).resolve().parent;p=r.parent/'team615_neartie_maps_20261121'
s=(p/'analyze.py').read_text(encoding='utf-8')
s=s.replace('finish_gate','previous').replace('team615_previous_maps_20261121','team615_neartie_maps_20261121')
s=s.replace('selected_image_equals_18024','selected_image_equals_previous')
s=s.replace("'group_ordinary_selection','group_finish_refresh_step','group_end_slot','group_best_metadata'",
    "'group_ordinary_selection','group_finish_refresh_step','group_end_slot','group_final_snapshot_count','group_final_snapshot_origins','group_first_round_window','group_yielding_at_end','group_best_metadata'")
insertion="""    zero=s['drone_details'][0]
    one=s['drone_details'][1]
    data['first_round_yield_evidence']={str(d['drone']):dict(final_snapshot_count=d['group_final_snapshot_count'],
        origins=d['group_final_snapshot_origins'],window=d['group_first_round_window'],active_at_end=d['group_yielding_at_end'],
        ordinary_mode=d['group_ordinary_selection']) for d in s['drone_details']}
    image1=hashes.get('1:5')
    data['one_submitted_current_image']=bool(image1 and any(row['drone']==1 and row['image_sha256']==image1['sha256'] for row in s['submissions']))
    data['selected_image_equals_three_map']=s['selected_image_sha256']==result['arms']['current']['selected_submission']['image_sha256']
"""
assert s.count("    data['bitmap_hashes']=hashes\n")==1
s=s.replace("    data['bitmap_hashes']=hashes\n","    data['bitmap_hashes']=hashes\n"+insertion)
compile(s,'analyze.py','exec');(r/'analyze.py').write_text(s,encoding='utf-8')
s=(p/'report.py').read_text(encoding='utf-8')
s=s.replace("'finish_gate'","'previous'")
s=s.replace("finish_gate='180＋24候选',candidate='近分＋6步时隙候选'","previous='近分＋6步时隙候选',candidate='首轮30步让行候选'")
s=s.replace("tests['scenario_groups']==89","tests['scenario_groups']==107")
s=s.replace('原版、上一版三图候选和180＋24候选','原版、上一版三图候选和近分＋6步时间槽候选')
s=s.replace('原89组反例','原107组反例').replace('上一轮89组反例','上一轮107组反例')
s=s.replace('180＋24基线SHA256','近分＋6步时隙基线SHA256')
s=s.replace('原版按原始56项源码清单','原版按原始53项源码清单')
s=s.replace('# 0.003近分选新图＋原竞价让行＋6步时间槽：Map08、Map09，种子615','# 首轮30步让行：Map08、Map09，种子615')
anchor="    one=p['candidate']['one_best']"
addition="""    lines += ['', '首轮让行的赛后状态：','',
        '| 无人机 | FinalMaps最终快照数 | 快照来源 | 固定首轮窗口 | 结束时让行条件成立 |','|---|---:|---|---|---|']
    for owner,info in analysis[name]['first_round_yield_evidence'].items():
        lines.append(f\"| {owner}号 | {info['final_snapshot_count']} | {info['origins']} | {info['window']} | {info['active_at_end']} |\")
    lines += ['', '该表的让行条件按结束帧状态重算；实际进入普通交图还须通过库存等检查。0号是否让行另结合普通模式、库存确认及无提案/提交记录核验。','']
"""
assert s.count(anchor)==1;s=s.replace(anchor,addition+anchor)
s=s.replace("'offline_map_score.py','augment_offline.py','dispatch.sh','SERVER_STAGE.txt','FINDINGS.md'",
    "'offline_map_score.py','augment_offline.py','dispatch.sh','SERVER_STAGE.txt','FINDINGS.md','prepare_report.py'")
compile(s,'report.py','exec');(r/'report.py').write_text(s,encoding='utf-8')
s=(p/'publish.py').read_text(encoding='utf-8').replace('team615_red_v15/near_tie_slots_maps_20261121','team615_red_v15/first_round_yield_maps_20261121')
s=s.replace('Evaluate frozen near-tie ranking and six-step slots on Map08 and Map09 seed615','Evaluate frozen first-round yielding on Map08 and Map09 seed615')
(r/'publish.py').write_text(s,encoding='utf-8')
print('Prepared yield-aware analysis, four-arm report and publisher; no publication yet.')
