from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json
r=Path(__file__).resolve().parent;d=r/'delivery'
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
b=read(r/'BUILD.json');result=read(d/'RESULTS.json');analysis=read(r/'ANALYSIS.json')
assert h(d/'CANDIDATE_SOURCE.zip')==h(r/'candidate_snapshot.zip')==b['candidate_zip_sha256']
assert h(d/'CANDIDATE_SOURCE.zip')==h(r.parent/'team615_first_round_yield_20261121/delivery/CANDIDATE_SOURCE.zip')
assert result['configuration']['new_red_rounds']==2 and result['configuration']['maps']==['Map08','Map09']
assert result['configuration']['other_maps_run']==0 and not result['configuration']['candidate_modified_during_this_task']
proof={}
for name in ['Map08','Map09']:
    s=read(r/name/'received/OFFICIAL_SCORE.json')
    assert read(r/name/'received/POST_RUN_SOURCE_CHECK.json')['status']=='PASS'
    assert result['maps'][name]['personal_original_integrity']['status']=='PASS'
    assert read(r/name/'OBSERVATION_BINDING.json')['in_match_observer_functions_ast_identical_to_previous']
    with ZipFile(d/f'{name}_RUN_EVIDENCE.zip') as z:assert z.testzip() is None
    per_step={}
    for event in analysis[name]['protocol']['candidate']['group_ordinary_submissions']:
        per_step.setdefault(event['step'],[]).append(event['drone'])
    proof[name]=dict(ordinary_same_frame_groups={str(k):v for k,v in per_step.items() if len(v)>1},
        all_simultaneous_submissions=analysis[name]['protocol']['candidate']['simultaneous'],
        one_current_equals_previous_three_map_submission=analysis[name].get('one_current_equals_previous_three_map_submission'),
        one_submitted_current_image=analysis[name]['one_submitted_current_image'],
        actual_image_equals_previous=analysis[name]['selected_image_equals_previous'],
        actual_image_equals_three_map=analysis[name]['selected_image_equals_three_map'],
        first_round_yield_evidence=analysis[name]['first_round_yield_evidence'],
        personal_original_images_verified=result['maps'][name]['personal_original_integrity']['images_verified'],
        source_hashes_unchanged=True,selected_image_sha256=s['selected_image_sha256'])
with ZipFile(d/'CANDIDATE_SOURCE.zip') as z:assert z.testzip() is None
assert '<!--' not in (d/'README.md').read_text(encoding='utf-8')
result['fact_checks']=proof
(d/'RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(r/'FACT_CHECK.json').write_text(json.dumps(dict(status='PASS',proof=proof),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with ZipFile(d/'HARNESS.zip','a',ZIP_DEFLATED) as z:
    z.write(r/'finalize.py','finalize.py');z.write(r/'FACT_CHECK.json','FACT_CHECK.json')
files={p.name:h(p) for p in sorted(d.iterdir()) if p.name!='CHECKSUMS_SHA256.json'}
assert len(files)==14,len(files)
(d/'CHECKSUMS_SHA256.json').write_text(json.dumps(files,indent=2)+'\n')
print(json.dumps(dict(status='PASS',delivery_files=len(files)+1,proof=proof),indent=2))
