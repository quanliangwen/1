from pathlib import Path
r=Path(__file__).resolve().parent;p=r.parent/'team615_neartie_maps_20261121'
s=(p/'collect.py').read_text(encoding='utf-8').replace('near_tie_slots','first_round_yield').replace('finish_gate','previous')
s=s.replace("r.parent/'team615_previous_maps_20261121'/name/'received'", "r.parent/'team615_neartie_maps_20261121'/name/'received'")
# The only path altered by replacing the arm label above is corrected explicitly.
assert "previous=r.parent/'team615_neartie_maps_20261121'/name/'received'" in s
compile(s,'collect.py','exec');(r/'collect.py').write_text(s,encoding='utf-8')
s=(p/'audit_history.py').read_text(encoding='utf-8').replace('finish_gate','previous_candidate')
s=s.replace("previous_candidate=r.parent/'team615_previous_candidate_maps_20261121'/name/'received'", "previous_candidate=r.parent/'team615_neartie_maps_20261121'/name/'received'")
assert "previous_candidate=r.parent/'team615_neartie_maps_20261121'/name/'received'" in s
compile(s,'audit_history.py','exec');(r/'audit_history.py').write_text(s,encoding='utf-8')
for n in ['offline_map_score.py','augment_offline.py','SDK_SELECTION_EVIDENCE.json']:
    (r/n).write_bytes((p/n).read_bytes())
print('Prepared source-verified four-arm collection.')
