from pathlib import Path,PurePosixPath
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import argparse,json,math,subprocess
import numpy as np

r=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
parser=argparse.ArgumentParser();parser.add_argument('map',choices=['Map08','Map09']);name=parser.parse_args().map
folder=r/name;received=folder/'received';received.mkdir(exist_ok=True)
host='quanliangwen@10.112.162.60';remote=(r/'SERVER_STAGE.txt').read_text().strip()+'/'+name

def download(paths,dest):
    dest.mkdir(parents=True,exist_ok=True)
    subprocess.run(['scp','-q','-o','BatchMode=yes',*[f'{host}:{p}' for p in paths],str(dest)],check=True)

files=['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','placement_events.jsonl',
       'run.log','dispatch.log','wall_geometry.npz','group_dataset.npz','GROUP_DATASET.json',
       'POST_RUN_SOURCE_CHECK.json','EXTRA_ARTIFACTS.json']
download([f'{remote}/{f}' for f in files],received)
end=read(received/'FINISH.json');official=PurePosixPath(end['result_dir'])
assert official.is_relative_to(PurePosixPath(remote)/'official_sdk/results_swarm_rescue')
for n,checksum in end['files'].items():
    p=PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts
    download([str(official/p)],received/'official'/p.parent)
    assert h(received/'official'/n)==checksum
for n,checksum in read(received/'EXTRA_ARTIFACTS.json').items():assert h(received/n)==checksum
assert read(received/'POST_RUN_SOURCE_CHECK.json')['status']=='PASS'
b=read(r/'BUILD.json');start=read(received/'START.json');score=read(received/'OFFICIAL_SCORE.json')
assert h(r/'candidate_snapshot.zip')==b['candidate_zip_sha256']
assert start['solutions_sha256']==read(received/'SOURCE_MATCH.json')['candidate']==b['candidate_files']
assert [start[k] for k in ['seed','sdk','map_name','drones','bombs_per_drone','timestep_limit','walltime_limit','competition_mode']]==[
    615,'6557940dc18549ffc7a945db887da5b05b7ed2f1',name,5,2,5400,180,True]
assert start['spawn']==read(r/'matched_spawns.json')[name]
assert start['zones']==read(r/'EXPECTED_ZONES.json')[name]
assert [end[k] for k in ['status','completed_red_rounds','blue_rounds','layout_evaluations']]==['COMPLETE',1,0,0]
assert h(received/'placement_events.jsonl')==score['placement_events_sha256']
assert h(received/'wall_geometry.npz')==score['wall_geometry_sha256']
log=(received/'dispatch.log').read_text(encoding='utf-8')
assert log.count(f'START {name} first_round_yield seed615')==1
assert log.count(f'COMPLETE {name} first_round_yield seed615')==1

original=r.parent/'team615_messenger_batch1_20261121/received'/f'{name}_baseline'
current=(r.parent/'team615_group_exchange_map06_map08_20261121/Map08/received' if name=='Map08'
         else r.parent/'team615_group_exchange_map09_20261121/received')
previous=r.parent/'team615_neartie_maps_20261121'/name/'received'
three_build=read(r.parent/'team615_partial_selection_batch1_20261121/BUILD.json')
primordial=read(r.parent/'team615_group_exchange_map09_20261121/BUILD.json')['original_files']

def verify_history(path,expected):
    s=read(path/'START.json');f=read(path/'FINISH.json');v=read(path/'OFFICIAL_SCORE.json')
    assert s['solutions_sha256']==expected and s['seed']==615 and s['map_name']==name
    assert s['sdk']==start['sdk'] and s['sdk_archive_sha256']==start['sdk_archive_sha256']
    assert s['spawn']==start['spawn'] and s['zones']==start['zones']
    assert f['status']=='COMPLETE' and f['completed_red_rounds']==1
    assert h(path/'placement_events.jsonl')==v['placement_events_sha256']
    for n,d in f['files'].items():assert h(path/'official'/n)==d
    return v

def summary(s,path):
    m=s['map_breakdown'];selected=s['selected_submission']
    assert math.isclose(s['partial'],.5*s['map_score']+.2*s['coverage']+.1*s['time_score'],abs_tol=1e-8)
    bombs=read(next((path/'official').glob('*bombs.json')))['bombs'];assert len(bombs)==s['placed']
    if selected and selected.get('drone') is not None:assert selected['image_sha256']==s['selected_image_sha256']
    return dict(partial_score_out_of_80=s['partial'],map_score=s['map_score'],wall_score=s['coverage'],time_score=s['time_score'],
        submission_step=s['steps'],selected_submission=selected,placed=s['placed'],exploration_percent=s['trajectory'],
        missed_wall_pixels=m['wall_pixels']-m['wall_hits'],charged_misdraw_pixels=m['charged_pixels'],map_breakdown=m,
        total_health_lost=sum(25-d['health'] for d in s['drone_details']),elapsed_walltime_seconds=s['elapsed_walltime'],
        per_drone_last_confirmation={str(d['drone']):d['last_confirmation'] for d in s['drone_details']},
        deadline_events={str(d['drone']):d['walltime_submission'] for d in s['drone_details']})

arms=dict(original=summary(verify_history(original,primordial),original),
          current=summary(verify_history(current,three_build['original_files']),current),
          previous=summary(verify_history(previous,b['original_files']),previous),candidate=summary(score,received))
fields=['partial_score_out_of_80','map_score','wall_score','time_score','submission_step','placed','exploration_percent',
        'missed_wall_pixels','charged_misdraw_pixels','total_health_lost','elapsed_walltime_seconds']
deltas={arm:{k:arms['candidate'][k]-arms[arm][k] for k in fields} for arm in ['original','current','previous']}
prefix={}
new=np.load(next((received/'official/recordings').glob('*.npz')))
for label,path in [('original',original),('current',current),('previous',previous)]:
    old=np.load(next((path/'official/recordings').glob('*.npz')));prefix[label]={}
    for key in ['drone_states','bomb_states']:
        a,v=old[key],new[key];n=min(len(a),len(v));same=np.ones(n,bool)
        for field in a.dtype.names:same&=(a[field][:n]==v[field][:n]).reshape(n,-1).all(1)
        w=np.flatnonzero(~same)
        prefix[label][key]=dict(first_different_frame=None if not w.size else int(w[0]),
            historical_frames=len(a),candidate_frames=len(v),first_3237_frames_equal=bool(same[:min(n,3237)].all()))

# Verify every preserved personal image against its actual initial build/store digest.
dataset=np.load(received/'group_dataset.npz');meta=read(received/'GROUP_DATASET.json')
selected=score['selected_submission'];chosen_owner=str(selected['drone'])
chosen_detail=next(v for v in score['drone_details'] if str(v['drone'])==chosen_owner)
assert chosen_detail['group_cached_image_sha256']==selected['image_sha256']
info=meta[chosen_owner]
chosen_bitmap=np.unpackbits(dataset[f'd{chosen_owner}_selected_cache'])[:info['width']*info['height']].reshape(info['height'],info['width']).astype(np.uint8)
assert sha256(chosen_bitmap.tobytes()).hexdigest()==selected['image_sha256']
def digest(value):
    value_hash=__import__('hashlib').sha256()
    def add(v):
        if isinstance(v,np.ndarray):value_hash.update(str((v.dtype.str,v.shape)).encode());value_hash.update(v.tobytes(order='C'))
        elif isinstance(v,dict):
            for k in sorted(v,key=repr):add(k);add(v[k])
        elif isinstance(v,(tuple,list)):
            value_hash.update(b'[')
            for x in v:add(x)
            value_hash.update(b']')
        else:value_hash.update(repr(v).encode());value_hash.update(b';')
    add(value);return value_hash.hexdigest()
checks=[];groups={}
for d in score['drone_details']:
    owner=str(d['drone']);info=meta[owner]
    for slot,details in info['images'].items():
        if int(slot)>=5:continue
        data=dict(epoch=('group-return-v1',5400,5),owner=int(slot),version=details['version'],
                  packed=dataset[f'd{owner}_image{slot}'],sources={int(i):v for i,v in details['sources'].items()})
        assert digest(data)==details['digest']
        first=next(e[-1] for e in d['group_candidate_audit'] if
            e[1]=='image_built' and e[2]==int(slot) or
            e[1]=='payload_stored' and e[3]=='image' and e[4]==int(slot))
        assert first==details['digest']
        checks.append(dict(holder=int(owner),personal_owner=int(slot),digest=first,unchanged=True))
    group={k:v for k,v in d.items() if k.startswith('group_') and k!='group_final_trail'}
    group['comparisons']=[x for x in d['group_audit'] if x[1]=='available_candidates_compared']
    group['proposals']=[x for x in d['group_audit'] if x[1]=='choice_proposed']
    group['submission_events']=[x for x in d['group_audit'] if x[1] in ('submitted','soft_cutoff_submit')]
    group['final_inventory_records']=d['final_inventory_records'];groups[owner]=group

result=dict(status='COMPLETE',map=name,seed=615,new_red_rounds=1,historical_red_rounds=3,blue_rounds=0,
    source_frozen=True,candidate_zip_sha256=b['candidate_zip_sha256'],baseline_zip_sha256=b['baseline_zip_sha256'],
    arms=arms,candidate_minus=deltas,recorded_prefix=prefix,group_details=groups,
    personal_original_integrity=dict(status='PASS',images_verified=len(checks),checks=checks),
    actual_submission_matches_selected_cache=True,
    post_run_source_check=read(received/'POST_RUN_SOURCE_CHECK.json'))
(folder/'RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with ZipFile(folder/'RUN_EVIDENCE.zip','w',ZIP_DEFLATED) as z:
    for p in sorted(received.rglob('*')):
        if p.is_file():z.write(p,'candidate/'+p.relative_to(received).as_posix())
    for label,path in [('original',original),('current',current),('previous',previous)]:
        for n in ['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','placement_events.jsonl','wall_geometry.npz']:
            z.write(path/n,label+'/'+n)
        for p in (path/'official/recordings').glob('*.npz'):z.write(p,label+'/official/recordings/'+p.name)
    for n in ['stage_run.py','run_once.sh','OBSERVATION_BINDING.json','DECLARED_SOURCE.json','PATCH_BINDING.json',
              'BUILD.json','VALIDATION.json','counterexamples.json','OFFLINE_CHECK.json','place_map09.yml']:
        z.write(folder/n,'harness/'+n)
    for n in ['collect.py','provision.py','prepare_collect.py']:z.write(r/n,'harness/'+n)
print(json.dumps(dict(map=name,arms=arms,deltas=deltas,prefix=prefix,personal_images_verified=len(checks),
    groups={i:dict(phase=g['group_phase'],start=g['group_started'],compares=len(g['comparisons']),
        first_compare=g['comparisons'][:1],last_compare=g['comparisons'][-1:],proposals=g['proposals'],
        submissions=g['submission_events'],best=g['group_best_metadata']) for i,g in groups.items()}),indent=2))
