"""A short reservation binds a coverage improvement to the second drop site."""
from copy import copy
import math

import numpy as np

from swarm_rescue.simulation.drone.bomb_deployer import MIN_BOMB_SEPARATION
from swarm_rescue.solutions.placement_density import observed_bombs, violates_patch


class SecondDropSite:
    SITE_CLEARANCE = 6.
    SITE_SPACING = max(32., MIN_BOMB_SEPARATION)
    MAX_STEPS = 30
    ARRIVAL = 8.
    FAST_RETRY_AFTER = 8
    OBSERVE_INTERVAL = 16
    CACHE_STEPS = 72
    MAX_CACHED = 12
    REACH = 36.

    def __init__(self):
        self.plan = None
        self.ready_step = None
        self.used = False
        self.retry_at = 0
        self.audit = []
        self.backups = []
        self.opportunity_backups = []
        self.observing_exit = False
        self.probed_exit = None
        self.survey_coverage = None

    @staticmethod
    def worthwhile(gain, current):
        return gain >= max(current + .25, 1.25 * current)

    def packet(self, step):
        if self.plan is None:
            return None
        start, point, _, _ = self.plan
        return (step, point) if step-start < self.MAX_STEPS else None

    def gate(self, drone, step, ranges):
        if drone.initial_inventory != 2 or drone.previous_inventory != 1:
            return "inventory"
        if drone.pending_drop is not None or drone.drop_departure.started is not None:
            return "first_drop_not_clear"
        if not drone.grid.pose_fixed or drone._odometry_only or not drone.search_roaming.departed:
            return "position"
        if step >= drone.limit-30 or drone.walltime_limit-drone.elapsed_walltime <= 4.:
            return "budget"
        if ranges is None:
            return "no_lidar"
        if not drone.route:
            return "no_route"
        return None

    @classmethod
    def route_sites(cls, pose, route):
        previous = np.asarray(pose,dtype=float)
        knots = iter((12.,24.,cls.REACH))
        sample = next(knots)
        covered = 0.
        for node in list(route)[:4]:
            point = np.asarray(node,dtype=float)
            delta = point-previous
            length = float(np.linalg.norm(delta))
            if length <= 1.e-6:
                continue
            while sample <= covered+length:
                yield tuple(map(float,previous+delta*((sample-covered)/length)))
                sample = next(knots,None)
                if sample is None:
                    return
            covered += length
            previous = point

    def _remember_site(self, backups, step, point, gain):
        recent = [row for row in backups if step - row[0] <= self.CACHE_STEPS
                  and math.dist(point, row[1]) >= self.ARRIVAL]
        recent.append((step, point, gain))
        return recent[-self.MAX_CACHED:]

    def keep_backup(self, step, point, gain, *, opportunity=False):
        self.backups = self._remember_site(self.backups, step, point, gain)
        if opportunity:
            self.opportunity_backups = self._remember_site(self.opportunity_backups, step, point, gain)

    def _site_block(self, drone, point, step, semantic, *, stationary):
        return drone._placement_block(point, step, semantic, stationary=stationary,
                                      minimum_clearance=self.SITE_CLEARANCE)

    def protection(self, drone, step, point, ranges, angles, semantic, *, live, allow_outer_halo):
        placement = drone.placement
        passages = placement.deep.passages
        opening_limit = int(.15 * drone.limit)
        references = passages.nearby(point, opening_limit)
        if references or passages.near_recent_narrow(point, opening_limit):
            if not allow_outer_halo or not passages.opening_halo_only(
                    point, references, opening_limit, passages.LOCAL_RADIUS + 23. + MIN_BOMB_SEPARATION):
                return "passage"
        if not live:
            return placement._known_protected_turn(point, step)
        remembered = placement.last_visible_turn
        try:
            return placement._protected_turn(drone, step, ranges, angles, semantic)
        finally:
            placement.last_visible_turn = remembered

    def checks(self, drone, step, point, ranges, angles, semantic, current, nominal, gain,
               *, live=False, authorized=False, allow_outer_halo=False, density_points=None):
        if not drone._inside_team_point(point):
            return ["bounds"], {}
        failure = []
        block = drone._placement_block(point, step, semantic, stationary=live,
                                       minimum_clearance=self.SITE_CLEARANCE,
                                       minimum_spacing=self.SITE_SPACING)
        if block:
            failure.append(block)
        if not authorized:
            protected = self.protection(drone, step, point, ranges, angles, semantic, live=live,
                                        allow_outer_halo=allow_outer_halo)
            if protected is not None:
                failure.append("turn_hold_" + protected)
        if density_points is None:
            density_points = observed_bombs(drone, semantic)
        if violates_patch(point, density_points):
            failure.append("patch_full")
        if live:
            if not drone.placement._first_drop_exit_clear(drone, ranges, semantic):
                failure.append("live_exit")
        elif not drone.team_wall.corridor_clear(drone, point, ranges, angles, semantic):
            failure.append("live_corridor")
        if gain < nominal:
            failure.append("coverage_floor")
        if current is not None and not self.worthwhile(gain, current):
            failure.append("coverage_increment")

        cell = drone.grid.cell(point)
        mapped = float(drone.grid.clearance[cell])
        return failure, dict(map_clearance=mapped if math.isfinite(mapped) else None,
                             evidence=int(drone.grid.evidence[cell]))

    def assess(self, drone, step, ranges, semantic, sites, *, early, allow_exit_probe=False):
        if self.survey_coverage is None:
            self.survey_coverage = copy(drone.fine_wall_coverage)
            self.survey_coverage._alignment_cache = {}
            self.survey_coverage._alignment_epoch = None
        coverage = self.survey_coverage
        angles = drone.lidar_rays_angles()
        bombs = drone._known_bomb_positions(semantic)
        claims = drone.team_wall.claims(drone,step)
        density_points = observed_bombs(drone, semantic)
        radius = drone.blast_radius

        def measure(point, obstacles):
            return coverage.measure(drone.memory,point,obstacles,radius,step=step)[0]

        estimate = (lambda point: measure(point,bombs+claims)) if early else drone.team_wall.query(drone,semantic,step)
        baseline = None if early else estimate(drone.pose)[0]
        floor = drone.placement._coverage_minimum(step, drone.limit)
        origin = tuple(map(float,drone.pose))
        best = None
        best_rank = None
        original = None
        exit_probe = None
        exit_rank = None
        rows = []
        for source,point,recorded in sites:
            gain = estimate(point) if early else estimate(point)[0]
            all_walls = measure(point,())
            after_bombs = measure(point,bombs)
            failure,metrics = self.checks(drone, step, point, ranges, angles, semantic,
                                          baseline, floor, gain, allow_outer_halo=early,
                                          density_points=density_points)
            nearest = min((math.dist(point,bomb) for bomb in bombs), default=None)
            metrics.update(distance=math.dist(origin,point),nearest_bomb=nearest,spacing=self.SITE_SPACING,
                           gross=all_walls,after_bombs=after_bombs,gain=gain)
            rows.append((source,point,recorded,failure,metrics))
            exit_only = failure == ["turn_hold_neck_exit"]
            if early:
                # Survey evidence can be revisited from a better scan. An
                # immediate placement requires the stricter observation.
                if not failure or exit_only:
                    self.keep_backup(step, point, gain,
                                     opportunity=not failure and gain >= self.opportunity_floor(floor))
                continue
            if failure and not (allow_exit_probe and exit_only and source == "backup"):
                continue
            legacy_rank = gain, -metrics["distance"]
            rank = drone.team_wall.site_rank(point, gain, metrics["distance"], bombs + claims, radius)
            if exit_only:
                if exit_rank is None or rank > exit_rank:
                    exit_rank = rank
                    exit_probe = legacy_rank, point, source, recorded, True
                continue
            if original is None or legacy_rank > original[0]:
                original = legacy_rank, point
            if best_rank is None or rank > best_rank:
                best_rank = rank
                best = legacy_rank, point, source, recorded, False
        if best is not None and best[1] != original[1]:
            self.audit.append((step, "site_rank_changed", original[1], best[1], len(bombs) + len(claims)))
        return origin, baseline, floor, rows, best or exit_probe

    def observe_route(self, drone, step, ranges, semantic):
        if (self.used or drone.previous_inventory != 1 or drone.fast_closeout.phase(step) is not None
                or step%self.OBSERVE_INTERVAL != drone.identifier%self.OBSERVE_INTERVAL):
            return
        gate = self.gate(drone,step,ranges)
        if gate:
            self.audit.append((step,"survey_gate",gate))
            return
        self.backups = [row for row in self.backups if step-row[0] <= self.CACHE_STEPS]
        pose = tuple(map(float,drone.pose))
        sites = [("passed",pose,step)]
        sites.extend(("route",point,step) for point in self.route_sites(pose,drone.route))
        origin,_,floor,rows,_ = self.assess(drone,step,ranges,semantic,sites,early=True)
        self.audit.append((step,"survey",origin,floor,rows,len(self.backups)))

    def reserve(self, drone, step, ranges, semantic):
        if self.plan is not None or self.used or step < self.retry_at or drone.previous_inventory != 1:
            return False
        self.retry_at = step+10
        phase = drone.fast_closeout.phase(step) or "ordinary"
        gate = self.gate(drone,step,ranges)
        if gate:
            self.audit.append((step,"reserve_gate",phase,gate))
            return False
        origin = tuple(map(float,drone.pose))
        self.backups = [row for row in self.backups if step-row[0] <= self.CACHE_STEPS]
        sites = [("backup",point,stamp) for stamp,point,_ in self.backups
                 if math.dist(origin,point) <= self.REACH]
        direction = next((np.subtract(point,origin) for point in list(drone.route)[:4]
                          if math.dist(point,origin) >= 10.),None)
        if direction is not None:
            heading = math.atan2(direction[1],direction[0])
            for length in (18.,27.,self.REACH):
                for offset in (0.,.37,-.37,.74,-.74):
                    yaw = heading+offset
                    point = origin[0]+length*math.cos(yaw),origin[1]+length*math.sin(yaw)
                    sites.append(("current_probe",point,step))
        deep = drone.placement.deep
        zone = deep.zone
        allow_exit_probe = (phase == "ordinary" and zone is not None and zone[0] != self.probed_exit
                            and not deep.here(origin, 68.))
        origin,current,floor,rows,best = self.assess(drone, step, ranges, semantic, sites, early=False,
                                                   allow_exit_probe=allow_exit_probe)
        self.audit.append((step,"reserve_review",phase,origin,current,floor,rows,len(self.backups)))
        if best is None:
            return False
        self.plan = step,best[1],current,best[0][0]
        self.observing_exit = best[4]
        if self.observing_exit:
            self.probed_exit = zone[0]
            self.audit.append((step, "exit_probe", best[1], zone))
        self.audit.append((step,"reserve",best[1],current,best[0][0],origin,best[2],best[3]))
        return True

    @staticmethod
    def opportunity_floor(floor):
        return max(2.,2.*floor)

    def recent_at(self, point, step):
        return any(0 <= step-stamp <= self.OBSERVE_INTERVAL
                   and math.dist(point,site) <= self.ARRIVAL
                   for stamp,site,_ in self.opportunity_backups)

    def on_route_opportunity(self, drone, step, ranges, semantic):
        if (self.plan is not None or drone.fast_closeout.phase(step) is not None
                or self.gate(drone,step,ranges) or not self.recent_at(drone.pose,step)):
            return False
        gain = drone.team_wall.query(drone, semantic, step)(drone.pose)[0]
        floor = self.opportunity_floor(drone.placement._coverage_minimum(step, drone.limit))
        failure = self.current_blocks(drone, step, ranges, semantic, gain, floor, allow_outer_halo=True)
        if failure:
            self.audit.append((step, "opportunity_block", tuple(failure), gain, floor))
        return not failure

    def current_blocks(self, drone, step, ranges, semantic, gain, floor, *,
                       baseline=None, authorized=False, allow_outer_halo=False):
        if ranges is None:
            return ["no_lidar"]
        angles = np.asarray(drone.lidar_rays_angles())
        failure, _ = self.checks(drone, step, drone.pose, np.asarray(ranges), angles, semantic, baseline,
                                 floor, gain, live=True, authorized=authorized, allow_outer_halo=allow_outer_halo)
        return failure

    def request(self, drone, command, step, reason):
        if drone.pending_drop is not None or drone.previous_inventory != 1:
            return False
        if step < drone.placement.next_request or step - drone.last_attempt_step < 2:
            return False
        drone.placement.place(drone, command, step, reason, 1)
        return True

    def commit(self, drone, command, step):
        if self.plan is None or self.ready_step != step:
            return False
        if not self.request(drone, command, step, "reserved_second"):
            return False
        self.audit.append((step, "site_drop_request", self.plan[1], tuple(map(float, drone.pose))))
        return True

    def finish(self, step, accepted):
        self.audit.append((step, "site_drop_result", bool(accepted)))
        if accepted:
            self.used = True
        else:
            self.retry_at = max(self.retry_at, step + 10)
        self.clear(step, "stock_confirmed" if accepted else "sdk_rejected")


    def clear(self, step, reason):
        self.ready_step = None
        self.observing_exit = False
        if self.plan is not None:
            self.audit.append((step,reason,self.plan[1]))
            self.plan = None

    def control(self, drone, step, command, ranges, semantic):
        self.ready_step = None
        if self.plan is None:
            return None
        start, target, baseline, _ = self.plan
        gate = self.gate(drone, step, ranges)
        if gate or step-start >= self.MAX_STEPS:
            self.clear(step, "stock_confirmed" if drone.previous_inventory == 0 else gate or "expired")
            return None
        odom = drone.odometer_values()
        if odom is None or not np.all(np.isfinite(odom)) or ranges is None:
            self.clear(step,"sensor_unavailable")
            return None
        distance = math.dist(target,drone.pose)
        if distance <= self.ARRIVAL:
            if self.observing_exit:
                angles = np.asarray(drone.lidar_rays_angles())
                drone.placement.deep.observe(drone, step, np.asarray(ranges), angles, semantic,
                                             drone.placement.audit)
            gain = drone.team_wall.query(drone, semantic, step)(drone.pose)[0]
            floor = drone.placement._coverage_minimum(step, drone.limit)
            failure = self.current_blocks(drone, step, ranges, semantic, gain, floor, baseline=baseline)
            turn_protection = ("turn_hold_neck_exit", "turn_hold_live_neck")
            observe_only = (self.observing_exit and any(reason in turn_protection for reason in failure)
                            and all(reason in ("speed", *turn_protection) for reason in failure))
            if failure and failure != ["speed"] and not observe_only:
                self.audit.append((step, "site_drop_result", "arrival_rejected", tuple(failure)))
                self.clear(step, "arrival_rejected")
                return None
            command.update(drone.drive(drone.pose, self._velocity_from_odometry(drone, odom)))
            if observe_only:
                drone.local_escape.apply(drone, command, step, ranges, semantic)
                return "approach"
            if failure:
                return "approach"
            if not self.audit or self.audit[-1][1] != "arrived":
                self.audit.append((step,"arrived",target,tuple(map(float,drone.pose)),gain))
            self.ready_step = step
            return "ready"
        block = drone._placement_block(target, step, semantic, stationary=False,
                                       minimum_clearance=self.SITE_CLEARANCE,
                                       minimum_spacing=self.SITE_SPACING)
        if block:
            self.clear(step, "target_blocked")
            return None
        if not drone.team_wall.corridor_clear(drone, target, ranges, drone.lidar_rays_angles(), semantic):
            self.clear(step, "live_corridor_rejected")
            return None
        command.update(drone.drive(target,self._velocity_from_odometry(drone,odom)))
        return "approach"

    def steer_ordinary(self, drone, step, command, ranges, semantic):
        state = self.control(drone, step, command, ranges, semantic)
        if state == "ready" and step % (2 * drone.team_size) == 2 * drone.identifier:
            self.commit(drone, command, step)
        return state is not None

    @staticmethod
    def _velocity_from_odometry(drone, odom):
        travel,relative,change = map(float,odom)
        yaw = drone.heading-change+relative
        return travel*np.array((math.cos(yaw),math.sin(yaw)))

    @classmethod
    def wait_for_site(cls, state, elapsed):
        return state == "approach" and elapsed < cls.FAST_RETRY_AFTER
