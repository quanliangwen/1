"""Regression cases for both exact second-drop ZIPs using the pinned SDK."""
import argparse
import json
from pathlib import Path
from types import SimpleNamespace
from zipfile import ZipFile

import numpy as np
import swarm_rescue.solutions


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("arm", choices=("batch2", "repair"))
args = parser.parse_args()
with ZipFile(args.source) as archive:
    assert archive.testzip() is None and len(archive.namelist()) in (51, 52)
swarm_rescue.solutions.__path__ = [str(args.source.resolve())]

from swarm_rescue.solutions.fast_closeout import FastCloseout
from swarm_rescue.solutions.placement_preferences import PlacementPreferences
from swarm_rescue.solutions.red_hooks import RedHooks
from swarm_rescue.solutions.second_drop_site import SecondDropSite
from swarm_rescue.solutions.team_wall import TeamWall


SAFE = (12., 0.)
PROTECTED = (24., 0.)
RANGES = np.array([90., 90.])
ANGLES = np.array([-.1, .1])


class Flight:
    _placement_block = RedHooks._placement_block
    _known_bomb_positions = RedHooks._known_bomb_positions

    def __init__(self):
        self.identifier = 0
        self.team_size = 5
        self.initial_inventory = 2
        self.previous_inventory = 1
        self.pending_drop = None
        self.limit = 5400
        self.walltime_limit = 180
        self.elapsed_walltime = 60
        self.heading = 0.
        self.home = None
        self.pose = np.array([0., 0.])
        self.route = [(42., 0.)]
        self._odometry_only = False
        self.drop_departure = SimpleNamespace(started=None, controls_step=-1)
        self.search_roaming = SimpleNamespace(departed=True)
        self.last_attempt_step = -100
        self.grid = SimpleNamespace(pose_fixed=True, cell=lambda point: (0, 0),
                                    clearance=np.array([[15.]]), evidence=np.array([[-4]]))
        self.automatic_exit_clear = True
        self.speed = 0.5
        self.drop_records = {(0, 1): np.array([-35., 0.])}
        self.blast_radius = 135
        self.memory = object()
        self.fine_wall_coverage = SimpleNamespace(measure=lambda memory, p, *a, **kw: (self.gain(p),))
        self.team_wall = SimpleNamespace(query=lambda *a: lambda p: (self.gain(p),),
                                        claims=lambda *a: [], corridor_clear=lambda *a: True,
                                        site_rank=TeamWall.site_rank)
        self.fast_closeout = FastCloseout(self.identifier, self.team_size)
        self.second_drop = SecondDropSite()
        self.placement = PlacementPreferences()
        self.placement._first_drop_exit_clear = lambda *a: self.automatic_exit_clear
        self.placement._protected_turn = lambda *a: None
        self.placement._known_protected_turn = lambda *a: None
        self.placement.deep.passages = SimpleNamespace(
            nearby=lambda point, _: [],
            near_recent_narrow=lambda *a: False, opening_halo_only=lambda *a: False,
            LOCAL_RADIUS=38.)
        self.local_escape = SimpleNamespace(apply=lambda *a: None)

    @staticmethod
    def gain(point):
        return 5. if tuple(point) == PROTECTED else 3. if tuple(point) == SAFE else 1.

    @staticmethod
    def _inside_team_point(point):
        return all(abs(v) < 400 for v in point)

    @staticmethod
    def _placement_spacing(step):
        return 32.

    @staticmethod
    def lidar_rays_angles():
        return ANGLES

    @staticmethod
    def drive(point, velocity):
        return {"forward": 0.}

    def odometer_values(self):
        return self.speed, 0., 0.

    def carried_bombs_count(self):
        return self.previous_inventory


fixed = args.arm == "repair"
drone = Flight()
second = drone.second_drop
drone.placement.deep.zone = (2030, (78., 1.))
drone.placement._known_protected_turn = lambda point, step: (
    "neck_exit" if drone.placement.deep.here(point, 68.) else None)
drone.placement._protected_turn = lambda *a: drone.placement._known_protected_turn(drone.pose, 0)
samples = {SAFE: 1.7890625, PROTECTED: 1.7621875, (0.,12.): 1.6, (0.,24.): 2.05}
drone.gain = lambda point: samples.get(tuple(point), .5)
_, _, early_floor, rows, _ = second.assess(drone, 2164, RANGES, (),
                    [("route", point, 2164) for point in samples], early=True)
assert early_floor == (.8 if fixed else 2.)
expected = ["turn_hold_neck_exit"] if fixed else ["turn_hold_neck_exit", "coverage_floor"]
assert all(row[3] == expected for row in rows[:2])
assert set(row[1] for row in second.backups) == (set(samples) if fixed else {(0.,24.)})
assert not second.recent_at((0.,12.), 2164)
assert not second.recent_at(SAFE, 2164)
assert second.recent_at((0.,24.), 2164)
stored = len(second.backups)
samples = {SAFE:2.8759375, PROTECTED:2.868125, (0.,0.):2.15078125}
assert second.reserve(drone, 2188, RANGES, ()) == fixed
results = dict(arm=args.arm, scan_floor=early_floor, backup_count=stored,
               immediate_route_threshold_retained=True, plan_recovered=second.plan is not None)
if fixed:
    assert second.observing_exit and second.plan[1] in (SAFE, PROTECTED)
    drone.pose = np.asarray(second.plan[1])
    command = {"place_bomb": 0}
    drone.placement._protected_turn = lambda *args: "live_neck"
    assert second.steer_ordinary(drone, 2200, command, RANGES, ())
    assert not second.commit(drone, command, 2200) and command["place_bomb"] == 0
    results["ongoing_protection_blocks_actual_drop"] = True
    drone.placement.deep.zone = None
    drone.placement._protected_turn = lambda *args: None
    assert second.steer_ordinary(drone, 2210, command, RANGES, ())
    assert command["place_bomb"] == 1 and drone.placement.request[1] == "reserved_second"
    results["protection_cleared_allows_verified_drop"] = True

    drone = Flight()
    second = drone.second_drop
    drone.placement.deep.zone = (2030, (78., 1.))
    drone.placement._known_protected_turn = lambda point, step: (
        "neck_exit" if drone.placement.deep.here(point, 68.) else None)
    drone.placement._protected_turn = lambda *a: "neck_exit"
    second.plan = (2188, SAFE, 1., 3.)
    second.observing_exit = True
    drone.pose = np.asarray(SAFE)
    drone.automatic_exit_clear = False
    command = {"place_bomb": 0}
    assert not second.steer_ordinary(drone, 2200, command, RANGES, ())
    assert second.plan is None and command["place_bomb"] == 0
    results["live_exit_loss_cancels_probe"] = True

    drone = Flight()
    second = drone.second_drop
    drone.pose = np.asarray(SAFE)
    drone.placement._protected_turn = lambda *args: "live_neck"
    second.plan = (2188, SAFE, 1., 3.)
    second.observing_exit = True
    command = {"place_bomb": 0}
    assert second.steer_ordinary(drone, 2217, command, RANGES, ())
    assert command["place_bomb"] == 0 and second.plan is not None
    assert not second.steer_ordinary(drone, 2218, command, RANGES, ())
    assert command["place_bomb"] == 0 and second.plan is None
    results["observation_stops_at_existing_expiry"] = True
results["status"] = "PASS"
print(json.dumps(results, indent=2))
