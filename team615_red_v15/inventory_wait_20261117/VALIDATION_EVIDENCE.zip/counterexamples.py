"""Counterexamples against ZIPs using the pinned SDK, without stepping physics."""
from collections import deque
import argparse
import json
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
from zipfile import ZipFile

import numpy as np
import swarm_rescue.solutions


parser = argparse.ArgumentParser()
parser.add_argument("archive", type=Path)
parser.add_argument("arm", choices=("baseline", "candidate"))
args = parser.parse_args()
candidate = args.arm == "candidate"
with ZipFile(args.archive) as archive:
    assert archive.testzip() is None and len(archive.namelist()) == (52 if candidate else 51)
swarm_rescue.solutions.__path__ = [str(args.archive.resolve())]

from swarm_rescue.solutions.deadline_submission import DeadlineSubmission
from swarm_rescue.solutions.lbbd_rescue import LBBDRescue
from swarm_rescue.solutions.pre_submit_scan import PreSubmitScan
from swarm_rescue.solutions.red_hooks import RedHooks
if candidate:
    from swarm_rescue.solutions.inventory_wait import InventoryWait


START = 3240
MISS = 4
ANGLES = np.linspace(-np.pi, np.pi, 181)
CLEAR = np.full_like(ANGLES, 100.)
NAVIGATION = dict(forward=.4, lateral=.2, rotation=.1, grasper=0, place_bomb=0)
BRAKED = dict(forward=0., lateral=0., rotation=0., grasper=0, place_bomb=0)


def noop(*args, **kwargs):
    pass


def inactive(*args, **kwargs):
    return False


class Flight(RedHooks):
    def __init__(self, stock=0, identifier=0):
        self.identifier = identifier
        self.team_size = 5
        self.limit = 5400
        self.walltime_limit = 180
        self.elapsed_timestep = START
        self.elapsed_walltime = 112.5065
        self.initial_inventory = 2
        self.previous_inventory = stock
        self.remaining = stock
        self.pending_drop = None
        self.last_confirmed_drop_step = None
        self.last_attempt_step = -100
        self.inventory_records = {i: (3200, int(i == MISS)) for i in range(5)}
        self.team_exchange_audit = []
        self.drop_records = {}
        self.pose = np.array([578.52, -192.29])
        self.heading = 0.
        self.grid = NS(pose_fixed=False, needs_alignment=inactive)
        self._odometry_only = True
        self.velocity_trim = np.zeros(2)
        self.mode = "search"
        self.carrying = False
        self.gap_probe = self.gap_exit = self.survey_run = None
        self.recovery_until = self.carrier_yield_until = 0
        self.progress_step = START - 1
        self.blocked_prefix = NS(active=inactive)
        self.local_escape = NS(active=None, motion=deque([(0., 0.)]), apply=noop)
        self.lidar = CLEAR.copy()
        self.semantic = ()
        self.odom = (1.8, 0., 0.)
        self.inbox = None
        self.radio_disabled = False
        self.base_calls = 0
        self.second_calls = 0
        self.priority_second = False
        self.priority_fast = False
        self.final_maps = NS(freeze=noop, waiting=inactive, rank=lambda score: score)
        self.final_submission_versions = {}
        self.deadline_versions = {}
        self.deadline_submission = DeadlineSubmission()
        self.memory = NS(hits=np.zeros((2, 2),dtype=np.uint8), free=np.ones((2, 2),dtype=bool),
                         observe=noop, packet=lambda: (None,np.zeros((2,2)),None,None))
        self.fine_wall_coverage = NS(observe=noop, packet=lambda: None)
        self.submission_bearings = NS(observe=noop)
        self.pre_submit_scan = PreSubmitScan()
        self.map_quality = 9000
        self.map_revision = {}
        self.first_ready_to_submit_step = None
        self.fast_closeout = NS(act=self._fast, phase=lambda step: None)
        self.drop_departure = NS(update=noop, steer=noop, controls_step=-1)
        self.search_roaming = NS(departed=False)
        self.second_drop = NS(plan=None, observe_route=noop, steer_ordinary=self._second)
        maneuvers = NS(remember=noop, waiting_exit=None, exit=None, approach=None)
        self.placement = NS(maneuvers=maneuvers, _ordinary_start_step=lambda limit: 1,
                            finish_request=noop, update=noop)
        self.team_wall = NS(reservation=None, steer=inactive)
        if candidate:
            self.inventory_wait = InventoryWait()
        self.image = np.array([[0, 1], [0, 1]], dtype=np.uint8)
        self.deadline_submission.remember(3210, self.image)
        self.submitted = False
        self.sent = None

    def _second(self, drone, step, command, ranges, semantic):
        self.second_calls += 1
        if self.priority_second:
            assert self.previous_inventory == 1
            command.update(forward=0., lateral=0., rotation=0., grasper=0, place_bomb=1)
        return self.priority_second

    def _fast(self, drone, step, command, ranges, semantic):
        if self.priority_fast:
            command["rotation"] = -.3
        return self.priority_fast

    def communicator_is_disabled(self):
        return self.radio_disabled

    def carried_bombs_count(self):
        return self.remaining

    def odometer_values(self):
        return self.odom

    def lidar_rays_angles(self):
        return ANGLES

    def lidar_values(self):
        return self.lidar

    def semantic_values(self):
        return self.semantic

    def _update_drop_hints(self, *args):
        pass

    def _prepare_map_cache(self, step):
        pass

    def _prefer_own_submission(self, step):
        return True

    def _submission_image(self, step):
        return self.image, None, {}

    def submit_exploration_map(self, image):
        self.sent = image.copy()


def base_control(drone):
    drone.base_calls += 1
    if drone.inbox:
        drone._receive_team_coordination(drone.inbox, drone.elapsed_timestep)
    return NAVIGATION.copy()


def run(drone, step, speed=0.):
    drone.elapsed_timestep = step
    drone.odom = None if speed is None else (speed, 0., 0.)
    return drone.control()


def park(drone):
    command = run(drone, START, 1.8)
    assert command == dict(BRAKED, forward=-1.8/5.5)
    assert drone.inventory_wait.audit == [(START,"brake",MISS)]
    run(drone, START+1, .3)
    run(drone, START+2, .2)
    assert run(drone, START+3, .1) == BRAKED
    assert drone.inventory_wait.audit[-1] == (START+3,"parked",MISS)
    assert drone.inventory_wait.settled


def last_exit(drone, step, reason):
    assert drone.inventory_wait.finished
    assert drone.inventory_wait.audit[-1] == (step,reason,MISS)


def relay(stamp):
    return {"id":1,"red_inventory":{MISS:(stamp,0)}}


results = {}
with patch.object(LBBDRescue, "control", base_control):
    if not candidate:
        drone = Flight()
        assert run(drone, START, 1.8) == NAVIGATION
        results["no_gps_control_at_3240"] = "normal_navigation"
    else:
        drone = Flight()
        assert run(drone, START-1) == NAVIGATION and drone.inventory_wait.started is None
        park(drone)
        assert drone.progress_step == START+3
        assert list(drone.local_escape.motion) == []
        results["brake_then_park"] = dict(start=START, parked=START+3, initial_forward=-1.8/5.5)

        drone.inbox = relay(3199)
        for t in range(START+4,3417):
            assert run(drone,t) == BRAKED
            assert drone.progress_step == t
        assert drone.inventory_records[MISS] == (3200,1)
        drone.inbox = relay(3317)
        assert run(drone,3417) == NAVIGATION
        last_exit(drone,3417,"confirmed")
        assert drone.inventory_records[MISS] == (3317,0)
        assert drone.first_ready_to_submit_step == 3417
        assert drone.pre_submit_scan.audit[0][:2] == (3417,"begin")
        assert (("stock",3417,1,MISS,0) in drone.team_exchange_audit)
        assert run(drone,3444) == NAVIGATION and np.array_equal(drone.sent, drone.image)
        results["accepted_relay_resumes_submission"] = dict(confirmed=3417, normal_submit=3444,
                                                           stale_zero_rejected=True)

        drone = Flight()
        park(drone)
        drone.inbox = {"id":1,"red_inventory":{MISS:(3201,1)}}
        for t in range(START+4,START+200):
            assert run(drone,t) == BRAKED
        assert not drone.inventory_wait.finished
        assert run(drone,START+200) == NAVIGATION
        last_exit(drone,START+200,"timeout")
        assert run(drone,START+201) == NAVIGATION and drone.inventory_wait.started == START
        results["timeout_is_one_time"] = dict(last_wait_step=3439, exit=3440, rearmed=False)

        drone = Flight()
        park(drone)
        drone.semantic = (NS(entity_type=NS(name="DRONE"), distance=35., angle=1.2),)
        assert run(drone, START+4) == NAVIGATION
        last_exit(drone,START+4,"traffic")
        drone.semantic = ()
        assert run(drone, START+5) == NAVIGATION
        results["approaching_drone_releases_motion"] = True

        drone = Flight()
        park(drone)
        drone.carrier_yield_until = START+10
        assert run(drone,START+4) == NAVIGATION
        last_exit(drone,START+4,"motion_override")
        assert run(drone,START+11) == NAVIGATION
        results["existing_avoidance_has_priority"] = True

        drone = Flight()
        park(drone)
        drone.priority_fast = True
        assert run(drone,START+4) == dict(NAVIGATION, rotation=-.3)
        last_exit(drone,START+4,"motion_override")
        results["fast_closeout_has_priority"] = True

        drone = Flight()
        drone.lidar[len(ANGLES)//2] = 30.
        assert run(drone,START,1.8) == NAVIGATION and drone.inventory_wait.started is None
        # Loss of a side sector also disqualifies an otherwise open forward scan.
        drone.lidar = CLEAR.copy()
        drone.lidar[:25] = np.nan
        assert run(drone,START+1,1.8) == NAVIGATION and drone.inventory_wait.started is None
        results["blocked_braking_prefix_and_blind_sector_reject"] = True

        drone = Flight()
        for t in range(START,START+8):
            assert run(drone,t,1.5)["forward"] == -1.5/5.5
        assert run(drone,START+8,1.5) == NAVIGATION
        last_exit(drone,START+8,"braking_timeout")
        results["failed_braking_exits"] = True

        drone = Flight()
        park(drone)
        assert run(drone,START+4,None) == NAVIGATION
        last_exit(drone,START+4,"odometry")
        results["lost_odometry_releases_motion"] = True

        drone = Flight()
        del drone.inventory_records[MISS]
        park(drone)
        for t in range(START+4,START+20):
            assert run(drone,t,.5) == BRAKED
        assert run(drone,START+20,.5) == NAVIGATION
        last_exit(drone,START+20,"drift")
        results["unknown_inventory_supported_and_drift_cancels"] = True

        drone = Flight()
        park(drone)
        drone.grid.pose_fixed = True
        drone._odometry_only = False
        assert run(drone,START+4) == NAVIGATION
        last_exit(drone,START+4,"position_or_radio")
        assert run(drone,START+5) == NAVIGATION
        results["gps_recovery_ends_wait"] = True

        drone = Flight()
        drone.elapsed_walltime = 171.8
        park(drone)
        drone.elapsed_walltime = 172.
        assert run(drone,START+4) == NAVIGATION
        last_exit(drone,START+4,"budget")
        assert drone.sent is None
        results["eight_second_walltime_reserve"] = True

        drone = Flight()
        frozen = []
        drone.final_maps.freeze = lambda step, memory: frozen.append(step)
        assert run(drone,5000,1.8)["forward"] < 0
        assert drone.inventory_wait.started == 5000 and frozen == [5000]
        results["late_map_snapshot_precedes_wait"] = True

        for tag, step, walltime in (("walltime",START+4,179.),("timestep",5396,112.6)):
            drone = Flight()
            park(drone)
            before = drone.base_calls
            drone.elapsed_walltime = walltime
            assert run(drone,step) == BRAKED
            assert drone.submitted and np.array_equal(drone.sent,drone.image)
            assert drone.deadline_submission_event["fallback"] == tag and drone.base_calls == before
            last_exit(drone,step,"submission")
            results[f"{tag}_force_submit_precedes_wait"] = True

        drone = Flight(stock=1)
        drone.priority_second = True
        assert run(drone,START,1.8)["place_bomb"] == 1
        assert drone.second_calls == 1 and drone.inventory_wait.started is None
        peer = Flight(identifier=1)
        assert run(peer,START,1.8) == NAVIGATION and peer.inventory_wait.started is None
        results["second_drop_path_and_other_aircraft_keep_control"] = True

print(json.dumps(dict(arm=args.arm, status="PASS", physics_steps=0, scenarios=results), indent=2))
