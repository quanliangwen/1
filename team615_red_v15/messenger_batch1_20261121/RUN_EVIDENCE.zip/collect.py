"""Verify and package six seed-615 rounds for the messenger first-batch change."""
from hashlib import sha256
from pathlib import Path, PurePosixPath
from zipfile import ZipFile, ZIP_DEFLATED
import json
import math
import shutil
import subprocess

root=Path(__file__).resolve().parent
stage=(root/"SERVER_STAGE.txt").read_text().strip()
host="quanliangwen@10.112.162.60"
received=root/"received"
delivery=root/"delivery"
delivery.mkdir(exist_ok=True)
build=json.loads((root/"BUILD.json").read_bytes())
sdk="6557940dc18549ffc7a945db887da5b05b7ed2f1"
sdk_archive="9155bc4cdf5e0813cd328d3a56c3b73633ba351c3859e694762ed41376fc6860"
maps=("Map06","Map08","Map09")

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def save(path,data):
    path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+"\n",encoding="utf-8",newline="\n")

def download(paths,folder):
    folder.mkdir(exist_ok=True,parents=True)
    subprocess.run(["scp","-q","-o","BatchMode=yes",
                    *(f"{host}:{path}" for path in paths),str(folder)],check=True)

def get_round(map_name,arm):
    remote=PurePosixPath(stage)/f"{map_name}_{arm}"
    local=received/f"{map_name}_{arm}"
    names=("START.json","FINISH.json","SOURCE_MATCH.json","OFFICIAL_SCORE.json",
           "placement_events.jsonl","run.log","wall_geometry.npz")
    download([str(remote/name) for name in names],local)
    start,end,source,score=(read(local/f"{name}.json")
                            for name in ("START","FINISH","SOURCE_MATCH","OFFICIAL_SCORE"))
    assert [start[key] for key in ("seed","sdk","sdk_archive_sha256","map_name",
            "drones","bombs_per_drone","timestep_limit","walltime_limit","competition_mode")]==[
            615,sdk,sdk_archive,map_name,5,2,5400,180,True]
    assert start["spawn"]==read(root/"matched_spawns.json")[map_name]
    assert start["zones"]==read(root/"EXPECTED_ZONES.json")[map_name]
    binding=read(root/f"{arm}_binding.json")
    assert start["solutions_sha256"]==source["candidate"]==binding["candidate"]
    assert source["changed"]==binding["changed"]
    assert source["candidate_zip_sha256"]==binding["candidate_zip_sha256"]==build[f"{arm}_sha256"]
    assert [end[k] for k in ("status","completed_red_rounds","blue_rounds","layout_evaluations")]==["COMPLETE",1,0,0]
    assert digest(local/"placement_events.jsonl")==score["placement_events_sha256"]
    assert digest(local/"wall_geometry.npz")==score["wall_geometry_sha256"]
    official=PurePosixPath(end["result_dir"])
    assert official.is_relative_to(remote/"official_sdk/results_swarm_rescue")
    for name,expected in end["files"].items():
        file=PurePosixPath(name)
        assert not file.is_absolute() and ".." not in file.parts
        destination=local/"official"/file.parent
        download([str(official/file)],destination)
        assert digest(local/"official"/file)==expected
    assert math.isclose(score["partial"],.5*score["map_score"]+.2*score["coverage"]+.1*score["time_score"],abs_tol=1.e-8)
    events=[json.loads(line) for line in (local/"placement_events.jsonl").read_bytes().splitlines()]
    drops=[row for row in events if row["event"]=="sdk_placement" and row["accepted"]]
    assert len(drops)==score["placed"]
    selected=score["selected_submission"]
    if selected and selected["drone"] is not None:
        assert selected["step"]==score["steps"] and selected["image_sha256"]==score["selected_image_sha256"]
    health={row["drone"]:row["health"] for row in score["drone_details"]}
    messenger=next(row for row in score["drone_details"] if row["drone"]==4)
    audit=messenger["messenger_audit"]
    if arm=="candidate":
        for index,row in enumerate(audit):
            if row[1]=="exchange_complete":
                previous=audit[index-1]
                assert previous[:3]==[row[0],"payload_ack",row[2]],(previous,row)
    refreshes=[row for row in events if row["event"]=="messenger_map_refresh" and row["state"]=="ACTIVE"]
    return dict(trajectory_exploration_percent=score["trajectory"],partial_score_out_of_80=score["partial"],
                map_score=score["map_score"],wall_score=score["coverage"],time_score=score["time_score"],
                map_breakdown=score["map_breakdown"],wall_breakdown=score["wall_breakdown"],
                placed=score["placed"],expected=score["expected"],steps=score["steps"],
                submitted_map=score["submitted_map"],selected_submission=selected,
                elapsed_walltime_seconds=score["elapsed_walltime"],final_health=health,
                total_health_lost=sum(25-v for v in health.values()),destroyed_drones=sum(v<=0 for v in health.values()),
                last_physical_drop_step=max((row["step"] for row in drops),default=None),
                sdk_rejected_attempts=sum(row["event"]=="sdk_placement" and not row["accepted"] for row in events),
                actual_drops=drops,messenger_audit=audit,
                active_messenger_map_refresh_count=len(refreshes),
                active_messenger_map_refresh_steps=[row["step"] for row in refreshes],
                final_inventory_records={row["drone"]:row["final_inventory_records"] for row in score["drone_details"]},
                deadline_events={row["drone"]:row["walltime_submission"] for row in score["drone_details"]})

if __name__=="__main__":
    assert digest(root/"original.zip")==build["baseline_sha256"]
    assert digest(root/"candidate.zip")==build["candidate_sha256"]
    with ZipFile(root/"original.zip") as original,ZipFile(root/"candidate.zip") as candidate:
        assert set(original.namelist())==set(candidate.namelist()) and len(original.namelist())==53
        changed={name for name in original.namelist() if original.read(name)!=candidate.read(name)}
        assert changed==set(build["changed"])=={"red_hooks.py","messenger_run.py"}
    names=("matrix.log","static_baseline.log","static_candidate.log",
           "baseline_counterexamples.json","candidate_counterexamples.json")
    download([f"{stage}/{name}" for name in names],received)
    assert all("Submission check passed." in (received/f"static_{arm}.log").read_text()
               for arm in ("baseline","candidate"))
    unit={arm:read(received/f"{arm}_counterexamples.json") for arm in ("baseline","candidate")}
    assert all(result["status"]=="PASS" and result["physics_steps"]==0 for result in unit.values())
    lines=(received/"matrix.log").read_text(encoding="utf-8").splitlines()
    expected=[f"{event} {map_name} {arm}" for map_name in maps for arm in ("baseline","candidate")
              for event in ("START","COMPLETE")]
    assert [line for line in lines if line.startswith(("START Map","COMPLETE Map"))]==expected
    scores={name:{arm:get_round(name,arm) for arm in ("baseline","candidate")} for name in maps}
    fields=("trajectory_exploration_percent","partial_score_out_of_80","map_score","wall_score","time_score",
            "placed","steps","total_health_lost","elapsed_walltime_seconds")
    deltas={name:{key:pair["candidate"][key]-pair["baseline"][key] for key in fields}
            for name,pair in scores.items()}
    result=dict(sdk=sdk,sdk_archive_sha256=sdk_archive,seed=615,new_red_rounds=6,blue_rounds=0,
                layout_evaluations=0,input_name="潜力1.1：信使+滚动.zip",build=build,
                changes=["fresh direct messages and payload acknowledgements",
                         "map and submission-backup refresh during messenger navigation",
                         "bounded delivery to drone 0 after a newly received empty report"],
                counterexamples=unit,scores=scores,candidate_minus_baseline=deltas,
                experimental_parameters=dict(minimum_exchange_steps=12,exchange_timeout_steps=90,
                    redelivery_max_steps=200,redelivery_walltime_reserve_seconds=8,
                    redelivery_deadline_send_margin_steps=12))
    save(delivery/"RESULTS.json",result)
    shutil.copyfile(root/"candidate.zip",delivery/"team615_messenger_batch1.zip")
    patch_result=subprocess.run(["git","-c","core.autocrlf=false","diff","--no-index","--","baseline","candidate"],
                                cwd=root,capture_output=True)
    assert patch_result.returncode==1
    patch_data=patch_result.stdout.replace(b"a/baseline/",b"a/").replace(b"b/candidate/",b"b/")
    (delivery/"messenger_batch1.patch").write_bytes(patch_data)
    check=subprocess.run(["git","apply","--check",str(delivery/"messenger_batch1.patch")],
                         cwd=root/"baseline",capture_output=True)
    assert check.returncode==0,check.stderr
    with ZipFile(delivery/"RUN_EVIDENCE.zip","w",compression=ZIP_DEFLATED) as archive:
        for path in sorted(received.rglob("*")):
            if path.is_file():
                archive.write(path,path.relative_to(root).as_posix())
        for name in ("stage_run.py","run.sh","counterexamples.py","collect.py","BUILD.json",
                     "Map06.yml","Map08.yml","Map09.yml","matched_spawns.json","EXPECTED_ZONES.json"):
            archive.write(root/name,name)
    with ZipFile(delivery/"RUN_EVIDENCE.zip") as archive:
        assert archive.testzip() is None
    save(delivery/"CHECKSUMS_SHA256.json",{path.name:digest(path) for path in delivery.iterdir()
                                        if path.name!="CHECKSUMS_SHA256.json"})
    print(json.dumps({name:{arm:{key:row[key] for key in fields} for arm,row in pair.items()}
                      for name,pair in scores.items()},indent=2))
    print(json.dumps(deltas,indent=2))

