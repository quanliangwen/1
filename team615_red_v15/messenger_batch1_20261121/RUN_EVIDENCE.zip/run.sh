set -euo pipefail
stage="$1"
shared=/home/junhao/quan/parallel_test_solver/match
sealed="$shared/solver_study/framework_screen_20261016/best87_independent_20261025/P407_P398_semifinal_three_maps_20261110"
sdk_python="$shared/.venv/bin/python"
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
for arm in baseline candidate; do
    mkdir "$stage/static_$arm"
    cp "$stage/${arm}_snapshot.zip" "$stage/static_$arm/team615_semifinal.zip"
    "$sdk_python" "$sealed/official_sdk/scripts/check_submission.py" "$stage/static_$arm/team615_semifinal.zip" > "$stage/static_${arm}.log" 2>&1
done
exec 9<"$shared/solver_study/serial_evaluation.lock"
echo "Waiting for shared simulation slot"
flock -x -w 1200 9
echo "Acquired shared simulation slot"
export DISPLAY=:7100 LIBGL_ALWAYS_SOFTWARE=1 LP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MPLBACKEND=Agg ALSOFT_DRIVERS=null
for map in Map06 Map08 Map09; do
    for arm in baseline candidate; do
        run="$stage/${map}_${arm}"
        echo "START $map $arm"
        mkdir "$run"
        cp "$stage/stage_run.py" "$stage/EXPECTED_ZONES.json" "$stage/matched_spawns.json" "$stage/baseline_snapshot.zip" "$run/"
        cp "$stage/${arm}_snapshot.zip" "$run/candidate_snapshot.zip"
        cp "$stage/${arm}_declaration.json" "$run/DECLARED_SOURCE.json"
        cp "$stage/${arm}_binding.json" "$run/PATCH_BINDING.json"
        cp "$stage/${arm}_offline.json" "$run/OFFLINE_CHECK.json"
        cp "$stage/$map.yml" "$run/place_map08.yml"
        mkdir "$run/solution"
        "$sdk_python" -m zipfile -e "$run/candidate_snapshot.zip" "$run/solution"
        (cd "$run"; "$sdk_python" -B stage_run.py "$sealed" "$run/solution" "$map" 2>&1 | tee run.log)
        echo "COMPLETE $map $arm"
    done
done

