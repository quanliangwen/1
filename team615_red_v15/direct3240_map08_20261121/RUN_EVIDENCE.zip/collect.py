from pathlib import Path,PurePosixPath
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import importlib.util,json,subprocess
import numpy as np

root=Path(__file__).resolve().parent
old=root.parent/'team615_messenger_batch1_20261121'
code=root.parent/'team615_direct3240_20261121'
received=root/'received'
dest=root/'delivery'
remote='/home/quanliangwen/isolated_test/team615_direct3240_map08_L4Vwtm'
host='quanliangwen@10.112.162.60'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()

spec=importlib.util.spec_from_file_location('existing_collector',root.parent/'team615_demand_early24_map08_20261121'/'collect.py')
legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)
legacy.root=root

def download(paths,folder):
    folder.mkdir(exist_ok=True,parents=True)
    subprocess.run(['scp','-q','-o','BatchMode=yes',*(f'{host}:{p}' for p in paths),str(folder)],check=True)

b=read(root/'CANDIDATE_BUILD.json')
assert digest(root/'candidate_snapshot.zip')==b['candidate_zip_sha256']=='64a073d2ca9bdce6cd6e93eb6f0f8872e625d83e9f2e3293065463d30b0d7117'
assert digest(code/'candidate.zip')==b['candidate_zip_sha256']
assert all(digest(code/'candidate'/name)==h for name,h in b['candidate_files'].items())
assert read(root/'UNIT_VALIDATION.json')['status']=='PASS'
ob=read(root/'OBSERVATION_BINDING.json')
assert digest(root/'stage_run.py')==digest(old/'stage_run.py')==ob['observer_sha256']==ob['original_observer_sha256']
names=['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','placement_events.jsonl','run.log','dispatch.log','wall_geometry.npz']
download([f'{remote}/{n}' for n in names],received)
end=read(received/'FINISH.json');official=PurePosixPath(end['result_dir'])
assert official.is_relative_to(PurePosixPath(remote)/'official_sdk/results_swarm_rescue')
for name in end['files']:
    p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts
    download([str(official/p)],received/'official'/p.parent)
dispatch=(received/'dispatch.log').read_text(encoding='utf-8').splitlines()
assert sum(x=='START Map08 direct3240 seed615' for x in dispatch)==1
assert sum(x=='COMPLETE Map08 direct3240 seed615' for x in dispatch)==1
assert digest(old/'delivery/RESULTS.json')==read(old/'REMOTE_VERIFIED.json')['results_sha256']
runs=dict(original=legacy.summarize(old/'received/Map08_baseline',b['baseline_zip_sha256'],b['original_files']),
          candidate=legacy.summarize(received,b['candidate_zip_sha256'],b['candidate_files']))
history=read(old/'delivery/RESULTS.json')['scores']['Map08']['baseline']
assert runs['original']['map_score']==history['map_score'] and runs['original']['partial_score_out_of_80']==history['partial_score_out_of_80']
fields=['map_score','partial_score_out_of_80','wall_score','time_score','exploration_percent','missed_wall_pixels','charged_misdraw_pixels','submission_step','placed','total_health_lost','elapsed_walltime_seconds']
delta={k:runs['candidate'][k]-runs['original'][k] for k in fields}

old_z=np.load(next((old/'received/Map08_baseline/official/recordings').glob('*.npz')))
new_z=np.load(next((received/'official/recordings').glob('*.npz')))
prefix={}
for key in ['drone_states','bomb_states']:
    a,c=old_z[key],new_z[key];n=min(len(a),len(c))
    equal=np.ones(n,bool)
    for field in a.dtype.names:
        eq=a[field][:n]==c[field][:n]
        equal &= eq.reshape(n,-1).all(1)
    where=np.flatnonzero(~equal)
    prefix[key]=dict(original_frames=len(a),candidate_frames=len(c),common_frames=n,
                     all_common_frames_equal=bool(equal.all()),first_different_frame=None if not len(where) else int(where[0]),
                     before_target_frames=min(n,3240-3),all_before_target_frames_equal=bool(equal[:min(n,3240-3)].all()),
                     note='Frame indices are compared directly; wall-clock timestamps excluded.')
old_e=[json.loads(s) for s in (old/'received/Map08_baseline/placement_events.jsonl').read_text().splitlines()]
new_e=[json.loads(s) for s in (received/'placement_events.jsonl').read_text().splitlines()]
old_drop=[x for x in old_e if x['event']=='sdk_placement']
new_drop=[x for x in new_e if x['event']=='sdk_placement']
score_parts=dict(map=.5*delta['map_score'],wall=.2*delta['wall_score'],time=.1*delta['time_score'])
assert abs(sum(score_parts.values())-delta['partial_score_out_of_80'])<1e-8
result=dict(seed=615,map='Map08',new_red_rounds=1,historical_original_rounds=1,blue_rounds=0,
    controller_source_changed_in_this_task=False,candidate_build=b,observation_binding=ob,
    runs=runs,candidate_minus_original=delta,score_contribution_changes=score_parts,
    recorded_state_prefix_comparison=prefix,sdk_placement_events_identical=old_drop==new_drop,
    sdk_placement_events=dict(original=old_drop,candidate=new_drop),
    official_bomb_positions_identical=[(x['x'],x['y']) for x in runs['original']['official_bomb_layout']]==[(x['x'],x['y']) for x in runs['candidate']['official_bomb_layout']],
    target_exit_check=dict(selected=runs['candidate']['selected_submission'],
        deadline_event=runs['candidate']['deadline_events']['0'] if '0' in runs['candidate']['deadline_events'] else runs['candidate']['deadline_events'][0],
        source_bound=True),
    notes=['Original is the existing verified run; no new original or other-map match was launched.',
           'Scores cover the red-side80 points; the blue-side20-point term is not measured.',
           'Wall-clock values are one historical run and one new run and remain load-sensitive.',
           'An earlier exit intentionally omits all later observations; this is one seed, not a stability claim.'])
dest.mkdir(exist_ok=False)
(dest/'RESULTS.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
with ZipFile(dest/'RUN_EVIDENCE.zip','w',compression=ZIP_DEFLATED) as z:
    for folder,prefix_name in [(received,'new_candidate'),(old/'received/Map08_baseline','historical_original')]:
        for p in sorted(folder.rglob('*')):
            if p.is_file():z.write(p,prefix_name+'/'+p.relative_to(folder).as_posix())
    for name in ['stage_run.py','run_once.sh','collect.py','CANDIDATE_BUILD.json','UNIT_VALIDATION.json','OBSERVATION_BINDING.json','DECLARED_SOURCE.json','PATCH_BINDING.json','OFFLINE_CHECK.json','place_map08.yml','matched_spawns.json','EXPECTED_ZONES.json']:
        z.write(root/name,name)
with ZipFile(dest/'RUN_EVIDENCE.zip') as z:assert z.testzip() is None
print(json.dumps(dict(metrics={arm:{k:r[k] for k in fields} for arm,r in runs.items()},delta=delta,
    prefix=result['recorded_state_prefix_comparison'],score_parts=score_parts,
    selected=runs['candidate']['selected_submission'],placement_events_equal=old_drop==new_drop),indent=2))
