from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json,numpy as np

root=Path(__file__).resolve().parent
dest=root/'delivery'
r=json.loads((dest/'RESULTS.json').read_text(encoding='utf-8'))
o,c=r['runs']['original'],r['runs']['candidate'];d=r['candidate_minus_original']
s=json.loads((root/'received/OFFICIAL_SCORE.json').read_bytes())
leader=next(x for x in s['drone_details'] if x['drone']==0)
r['candidate_leader_direct_versions_at_submission']=leader['final_source_versions']
r['previous_offline_estimate_correction']=dict(previous_estimated_drone3_version_at3240=3213,
    actual_drone3_version_at3240=leader['final_source_versions']['3'],
    reason='Earlier manual periodic-version arithmetic was wrong; current match receipt state is authoritative.')
z=np.load(next((root/'received/official/recordings').glob('*.npz')))
r['candidate_terminal_frame_duplicates_previous']={k:bool(np.array_equal(z[k][-1],z[k][-2])) for k in ['drone_states','bomb_states']}
assert c['selected_submission']['drone']==0 and c['submission_step']==3240 and r['target_exit_check']['deadline_event'] is None
assert r['sdk_placement_events_identical'] and r['official_bomb_positions_identical']
assert all(v['all_before_target_frames_equal'] for v in r['recorded_state_prefix_comparison'].values())
(dest/'RESULTS.json').write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
rows=[('交图机／实际交图步数',f"0号／{o['submission_step']}",f"0号／{c['submission_step']}",str(d['submission_step'])),
      ('已测得分／80',f"{o['partial_score_out_of_80']:.4f}",f"{c['partial_score_out_of_80']:.4f}",f"{d['partial_score_out_of_80']:+.4f}"),
      ('地图分／100',f"{o['map_score']:.4f}",f"{c['map_score']:.4f}",f"{d['map_score']:+.4f}"),
      ('漏墙像素',str(o['missed_wall_pixels']),str(c['missed_wall_pixels']),f"{d['missed_wall_pixels']:+d}"),
      ('扣分误画像素',str(o['charged_misdraw_pixels']),str(c['charged_misdraw_pixels']),f"{d['charged_misdraw_pixels']:+d}"),
      ('探索率／%',f"{o['exploration_percent']:.4f}",f"{c['exploration_percent']:.4f}",f"{d['exploration_percent']:+.4f}个百分点"),
      ('实投数',str(o['placed']),str(c['placed']),str(d['placed'])),
      ('五机总掉血',str(o['total_health_lost']),str(c['total_health_lost']),str(d['total_health_lost'])),
      ('整局墙钟／秒',f"{o['elapsed_walltime_seconds']:.2f}",f"{c['elapsed_walltime_seconds']:.2f}",f"{d['elapsed_walltime_seconds']:+.2f}"),
      ('墙覆盖分／100',f"{o['wall_score']:.4f}",f"{c['wall_score']:.4f}",f"{d['wall_score']:+.4f}"),
      ('时间分／100',f"{o['time_score']:.4f}",f"{c['time_score']:.4f}",f"{d['time_score']:+.4f}")]
lines=['潜力1.1原版与3240步直接交图候选：Map08，种子615，单局对照','',
       '结论：候选确实在3240步由0号交图，10枚全投，但本局总分下降3.2974分，不建议作为提分版本替换原版。提前结束的时间收益不足以抵消地图损失。',
       '本次只新增候选一局；原版使用已核验的历史同种子结果，没有重跑原版或其他地图。算法源码没有再改。',
       '指标\t原版（历史）\t候选（本次唯一新增）\t候选减原版']
lines += ['\t'.join(row) for row in rows]
lines += ['', '配置与来源',
          'SDK6557940dc18549ffc7a945db887da5b05b7ed2f1；5机各2弹、5400步、180秒；NoGPS2个、NoCom0个；实际出生点逐项与原版相同。共用串行评测锁。',
          '原版SHA256 '+r['candidate_build']['baseline_zip_sha256'],
          '候选SHA256 '+r['candidate_build']['candidate_zip_sha256'],
          '观察脚本与历史原版逐字节相同，候选53个成员与反例通过的构建清单逐项一致；仅red_hooks.py较原版改变。',
          '', '直接交图核验',
          'SDK实际提交：'+json.dumps(c['selected_submission'],ensure_ascii=False),
          '0号deadline_submission_event为null，不是步数或墙钟应急提交。新出口在3240步生效，没有再叠加180步扫描、24步终局快照或候选等待。',
          f"原版与候选0号首次确认全队清零都在{o['leader_team_clear_step']}步；实投的10条SDK事件逐项一致，最终炸弹中心坐标也相同。",
          '五机最终血量原版与候选均为：'+json.dumps(c['final_health']),
          '', '航迹对照',
          'drone_states和bomb_states在候选前3238帧与原版逐字段完全相同，只有候选最后一帧（索引3238）不同；候选最后一帧与前一帧重复，是提前结束时记录的状态。3240之前可对齐部分全部一致，未观察到此前航迹偏移。',
          json.dumps(r['recorded_state_prefix_comparison'],ensure_ascii=False),
          '', '得分拆分',
          f"地图项{r['score_contribution_changes']['map']:+.6f}分，墙覆盖项{r['score_contribution_changes']['wall']:+.6f}分，时间项{r['score_contribution_changes']['time']:+.6f}分，合计{d['partial_score_out_of_80']:+.6f}分。",
          f"探索率只下降{-d['exploration_percent']:.4f}个百分点，但地图分下降{-d['map_score']:.4f}分；航迹探索率不等于0号已收到并成功绘制的地图完整度。",
          '误画减少5646像素，但漏墙增加7872像素，综合地图分仍下降。实投与墙覆盖不变。',
          '本局不支持“少牺牲一些探索率即可较划算提速提分”的判断；它实现了时间优先的取舍，但作为提分替代版本收益为负。',
          '', '信息与归因边界',
          '候选交图时0号直接发送者版本：'+json.dumps(leader['final_source_versions']),
          '这些是直接发送者版本，不是独有有效墙点来源账本。1号、4号的后期资料及3号后续更新会因3240结束而放弃；归档没有逐包像素增量，不能把全部地图扣分精确分摊给某一架机。结束时间、后续融合证据和最终渲染输入不同，不能只用轨迹探索率解释地图分。',
          '勘误：此前离线报告手工估算0号3240附近拿到3号3213版本，该周期计算有误。本次实际状态为3198版本，应以实际日志为准；不影响本次固定源码和官方评分对照。',
          '', '统计口径',
          '已测得分为红队80分部分，另20分蓝队布局难度未测。漏墙为真实墙面未命中的像素；误画为距真墙超过10px容差而扣分的预测像素。探索率为航迹覆盖，掉血为初始总血125减终局总血。',
          '墙钟使用SDK整局elapsed_walltime，包含提交后的收尾。原版是历史一局，候选是本次一局，运行负载会影响墙钟差异，不能把18.56秒全部归因于少204步。',
          '只新增这一局Map08，未重复运行或扩展到其他地图，未更改算法、导航、拟合、投放复核及双时限逻辑。',
          '', 'RESULTS.json保留精确指标、分项得分和来源；RUN_EVIDENCE.zip保留两版官方轨迹、地图差分、炸弹布局、事件日志及运行配置。']
(dest/'RESULT.txt').write_text('\n\n'.join(lines)+'\n',encoding='utf-8')
with ZipFile(dest/'RUN_EVIDENCE.zip','a',compression=ZIP_DEFLATED) as f:f.write(Path(__file__),'report.py')
(dest/'CHECKSUMS_SHA256.json').write_text(json.dumps({p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(dest.iterdir()) if p.name!='CHECKSUMS_SHA256.json'},indent=2)+'\n')
print(json.dumps({'status':'report ready','files':[(p.name,p.stat().st_size) for p in dest.iterdir()]},indent=2))
