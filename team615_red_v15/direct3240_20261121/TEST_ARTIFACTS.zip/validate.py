from pathlib import Path
from hashlib import sha256
from importlib.metadata import version
import json,os,shutil,subprocess,sys

root=Path.cwd()
sealed=Path('/home/junhao/quan/parallel_test_solver/match/solver_study/framework_screen_20261016/best87_independent_20261025/P407_P398_semifinal_three_maps_20261110')
sdk=sealed/'official_sdk'
binding_bytes=(sealed/'WORKSPACE_BINDING_FIRST.json').read_bytes()
assert sha256(binding_bytes).hexdigest()=='8a6310cdfccb0bc3c76ee4f4b6d1ab69bd6634f881f3268fb78b6302d8d77585'
binding=json.loads(binding_bytes)
assert binding['official_commit']=='6557940dc18549ffc7a945db887da5b05b7ed2f1'
for name,expected in binding['sdk_files'].items():
    assert sha256((sdk/name).read_bytes()).hexdigest()==expected,name
build=json.loads((root/'BUILD.json').read_bytes())
for name,key in [('original.zip','baseline_zip_sha256'),('candidate.zip','candidate_zip_sha256')]:
    assert sha256((root/name).read_bytes()).hexdigest()==build[key]
checks={a:json.loads((root/f'{a}_counterexamples.json').read_bytes()) for a in ['original','candidate']}
for arm,r in checks.items():
    assert r['status']=='PASS' and r['physics_steps']==r['physics_step_attempts']==r['full_matches']==r['map_objects_created']==0
    assert r['archive_sha256']==build['baseline_zip_sha256' if arm=='original' else 'candidate_zip_sha256']
    assert f'{arm}.zip/red_hooks.py' in r['loaded_red_hooks']
env=dict(os.environ,PYTHONPATH=str(sdk/'src'),PYGLET_HEADLESS='true')
alias=root/'team615_semifinal.zip'
shutil.copyfile(root/'candidate.zip',alias)
assert sha256(alias.read_bytes()).hexdigest()==build['candidate_zip_sha256']
static=subprocess.run([sys.executable,str(sdk/'scripts/check_submission.py'),str(alias)],env=env,capture_output=True)
(root/'static_candidate.log').write_bytes(static.stdout+static.stderr)
assert static.returncode==0,static.stdout+static.stderr
names=['original.zip','candidate.zip','BUILD.json','counterexamples.py','original_counterexamples.json',
       'candidate_counterexamples.json','original_counterexamples.log','candidate_counterexamples.log','static_candidate.log','validate.py']
result=dict(status='PASS',sdk_commit=binding['official_commit'],sdk_files_checked=len(binding['sdk_files']),
    python=sys.version,executable=sys.executable,numerical_packages={n:version(n) for n in ['numpy','pandas','opencv-contrib-python','scipy']},
    candidate_scenario_groups=checks['candidate']['scenario_groups'],original_scenario_groups=checks['original']['scenario_groups'],
    static_submission_check='PASS',static_zip_alias=alias.name,static_zip_alias_sha256=build['candidate_zip_sha256'],
    static_zip_alias_role='Identical temporary copy for official filename validation; not a competition release',
    physics_steps=0,physics_step_attempts=0,full_matches=0,map_objects_created=0,
    files={name:sha256((root/name).read_bytes()).hexdigest() for name in names})
(root/'VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
