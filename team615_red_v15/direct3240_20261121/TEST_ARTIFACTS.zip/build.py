from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
import ast,json,subprocess

root=Path(__file__).resolve().parent
digest=lambda b:sha256(b).hexdigest()
assert digest((root/'original.zip').read_bytes())=='c3021a3eb48031e82bfac9306654b48ca09f168d6f65b13349cf12f783104c7c'
with ZipFile(root/'original.zip') as z:old={n:z.read(n) for n in z.namelist()}
new={p.name:p.read_bytes() for p in (root/'candidate').iterdir() if p.is_file()}
assert old.keys()==new.keys() and len(old)==53
assert {n for n in old if old[n]!=new[n]}=={'red_hooks.py'}
assert all((root/'baseline'/n).read_bytes()==v for n,v in old.items())

def methods(raw):
    cls=next(n for n in ast.parse(raw).body if isinstance(n,ast.ClassDef) and n.name=='RedHooks')
    return {n.name:ast.dump(n,include_attributes=False) for n in cls.body if isinstance(n,ast.FunctionDef)}
o,n=methods(old['red_hooks.py']),methods(new['red_hooks.py'])
assert {k for k in o if o[k]!=n[k]}=={'control'}
assert set(n)-set(o)=={'_try_target_submission'}
added=b'                if self._try_target_submission(step):\n                    return command\n'
assert new['red_hooks.py'].count(added)==1
method_start=new['red_hooks.py'].index(b'    def _try_target_submission(')
method_end=new['red_hooks.py'].index(b'    def control(self):',method_start)
stripped=(new['red_hooks.py'][:method_start]+new['red_hooks.py'][method_end:]).replace(added,b'')
assert stripped==old['red_hooks.py']
for name,data in new.items():
    if name.endswith('.py'):compile(data,name,'exec')
with ZipFile(root/'candidate.zip','w',compression=ZIP_DEFLATED) as z:
    for name,data in new.items():
        info=ZipInfo(name,date_time=(2026,11,21,0,0,0));info.compress_type=ZIP_DEFLATED
        info.external_attr=0o100644<<16;z.writestr(info,data)
with ZipFile(root/'candidate.zip') as z:assert z.testzip() is None
diff=subprocess.run(['git','-c','core.autocrlf=false','diff','--no-index','--','baseline','candidate'],cwd=root,capture_output=True)
assert diff.returncode==1
patch=diff.stdout.replace(b'a/baseline/',b'a/').replace(b'b/candidate/',b'b/')
(root/'direct3240.patch').write_bytes(patch)
check=subprocess.run(['git','apply','--check',str(root/'direct3240.patch')],cwd=root/'baseline',capture_output=True)
assert check.returncode==0,check.stderr
b=dict(status='PASS',baseline='unmodified original 潜力1.1：信使+滚动',
    baseline_zip_sha256=digest((root/'original.zip').read_bytes()),candidate_zip_sha256=digest((root/'candidate.zip').read_bytes()),
    member_count=len(new),changed_files=['red_hooks.py'],unchanged_files=52,
    modified_existing_methods=['control'],new_methods=['_try_target_submission'],
    original_control_after_removing_one_call_byte_identical=True,all_other_existing_methods_ast_identical=True,
    original_files={k:digest(v) for k,v in old.items()},candidate_files={k:digest(v) for k,v in new.items()},
    compile='PASS',patch_apply_check='PASS',internal_zip_role='counterexample import only; not a competition release')
(root/'BUILD.json').write_text(json.dumps(b,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in b.items() if k not in ['original_files','candidate_files']},indent=2))
