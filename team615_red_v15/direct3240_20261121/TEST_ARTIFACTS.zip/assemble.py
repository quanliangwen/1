from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json,shutil

root=Path(__file__).resolve().parent
dest=root/'delivery'
dest.mkdir(exist_ok=False)
digest=lambda p:sha256(p.read_bytes()).hexdigest()
b=json.loads((root/'BUILD.json').read_bytes())
v=json.loads((root/'received/VALIDATION.json').read_bytes())
assert v['status']=='PASS' and v['candidate_scenario_groups']==13
for name,h in v['files'].items():
    p=root/name
    if not p.is_file():p=root/'received'/name
    assert digest(p)==h,name
with ZipFile(root/'candidate.zip') as z:
    assert {n:sha256(z.read(n)).hexdigest() for n in z.namelist()}==b['candidate_files']
assert all(digest(root/'candidate'/n)==h for n,h in b['candidate_files'].items())
assert all(digest(root/'baseline'/n)==h for n,h in b['original_files'].items())
c={a:json.loads((root/'received'/f'{a}_counterexamples.json').read_bytes()) for a in ['original','candidate']}
assert all(x['status']=='PASS' and x['physics_steps']==x['physics_step_attempts']==x['full_matches']==0 for x in c.values())
assert all(x['submitted'] and x['step']==3240 for x in c['candidate']['scenarios']['three_waits_individually_and_combined'].values())
assert all(not x['submitted'] for x in c['original']['scenarios']['three_waits_individually_and_combined'].values())
result=dict(status='PASS',build=b,validation=v,counterexamples=c,physics_steps=0,full_matches=0,
    actual_match_submission_step=None,actual_match_scores=None,
    scope='One-file source/patch candidate on original; no full-match or competition-release claim',
    initial_fixture_corrections=[
        'First fixture mistook the existing packet-refresh scan-window query for a blocking wait. Candidate code unchanged.',
        'Second fixture assumed one render in the whole control step and overlooked the existing periodic emergency-backup render. Candidate code unchanged.',
        'Official static checker rejected the internal candidate.zip name; an identical temporary team615_semifinal.zip alias passed. Payload unchanged.'],
    original_artifacts_preserved=True)
(dest/'RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name,source in [('red_hooks.py',root/'candidate/red_hooks.py'),('direct3240.patch',root/'direct3240.patch'),
                    ('counterexamples.py',root/'counterexamples.py'),('BUILD.json',root/'BUILD.json'),
                    ('VALIDATION.json',root/'received/VALIDATION.json')]:
    shutil.copyfile(source,dest/name)
with ZipFile(dest/'TEST_ARTIFACTS.zip','w',compression=ZIP_DEFLATED) as z:
    for name in ['build.py','validate.py','assemble.py']:z.write(root/name,name)
    for p in sorted((root/'received').iterdir()):z.write(p,'final/'+p.name)
    for attempt in ['first_attempt','second_attempt']:
        for p in sorted((root/attempt).iterdir()):z.write(p,attempt+'/'+p.name)
report='''潜力1.1原版：0号机3240步直接交图候选

完成范围
以原版ZIP为基线，SHA256 c3021a3eb48031e82bfac9306654b48ca09f168d6f65b13349cf12f783104c7c。只修改red_hooks.py，新增_try_target_submission，原control仅增加一次调用；删除该方法和调用后，文件与原版逐字节相同。其他52文件全部一致，包括导航、地图拟合、第二枚投放复核、信使和双时限模块。

行为
目标为limit*3//5，Map08上限5400时为3240。仅0号在全队库存确认清零、自身无待确认投弹、库存记录非未来/负时间戳、原部分地图检查通过且当前图非空时直接提交。
出口在原_submission_window_open通过之后、PreSubmitScan等待之前，所以0号绕过180步扫描等待、FinalMaps快照等待和候选选举等待，不增加任何12/24步收包计时。3239及更早不触发该出口。
提交图使用当前memory和方向证据调用原渲染器；已有终局证据时沿用原FinalMaps.fuse融合。不走旧图片缓存选择，不保存旧图作为新出口的替代品。空图或其他条件不满足时不交，继续原流程，后续可以再尝试。
不改变3240前的导航、地图采样和普通广播；不增加会合、2号返航、配送或ACTIVE地图刷新。原control前段的步数与墙钟兜底优先执行。原放弹确认与复核入口保持。

反例验证
从固定内部测试ZIP真实导入RedHooks，以合成传感器和库存构造反例；没有创建比赛地图，没有运行物理。pymunk.Space.step设为调用即失败，调用尝试为0。
候选13组通过；组内包含三道等待分别阻挡/同时阻挡、8类拒交状态、多机号与双时限等子情形。
1. 三道等待分别为真及同时为真时，候选均在夹具3240步交图，原版不交。
2. 2538、2562、2753、3239均不触发候选出口；3240满足条件即交，没有再等24步。
3. 自身或同伴有弹、缺库存记录、未来或负时间戳、pending_drop、空图、原部分地图条件不满足均拒交。
4. 3240空图、3241得到可用图时，3241直接提交，不启动计时；其他机号保留原等待。
5. 真实RedHooks.receive合并新地图与方向证据后，同帧正常观测先于新出口渲染，提交含新证据；新出口不调用旧缓存选择。已有FinalMaps证据仍与当前memory融合。
6. 同一对象重复调用只提交一次。保留原部分地图检查的“新鲜同伴图”例外。
7. 实际CoveragePlacementDrone._sync_placement方法先确认库存减少，再允许交图；库存未减少则不交。普通第二枚复核入口仍可达。
8. 真实DeadlineSubmission的墙钟、步数紧急判断均先于新出口和父控制器执行。
9. 原版自然等待夹具复现3444提交；这些3240/3444是反例夹具结果，不是Map08新实测。

验证环境与限制
SDK commit6557940dc18549ffc7a945db887da5b05b7ed2f1的225个文件按封存清单核验。Python3.11.17，NumPy1.26.4、Pandas3.0.6、OpenCV contrib4.11.0.86、SciPy1.17.1。官方静态提交检查通过；使用与内部候选字节相同的临时合规文件名，仅用于静态检查。
最初两次失败来自夹具断言：把正常包刷新对扫描窗口的查询误算成提交拦截、遗漏原有应急备份渲染。修正的是夹具，候选ZIP SHA未变；原始日志保存在TEST_ARTIFACTS.zip。静态检查最初因candidate.zip文件名不合规则拒绝，改用同内容临时别名后通过，内容未改。
新出口每次渲染当前证据；原版已有的定期应急备份也可能在同帧渲染，所以不宣称整个control只渲染一次。
没有运行整场仿真，没有新分数、真实交图步、探索率或墙钟收益。退出会主动放弃3240之后各机的观测与收包，包括1/4号后期更新和3号3357版本，不能保证原版地图分。

交付与应用
交付源码和补丁，不是正式比赛发布包。将direct3240.patch应用到原版源码目录（git apply direct3240.patch），或仅替换原版red_hooks.py；不要套在第一批、按缺口配送或其他候选上。
基线/候选全部成员SHA、反例与环境回执见BUILD.json、RESULTS.json、VALIDATION.json。内部测试ZIP SHA为64a073d2ca9bdce6cd6e93eb6f0f8872e625d83e9f2e3293065463d30b0d7117，不额外交付比赛ZIP。
'''
(dest/'RESULT.txt').write_text(report,encoding='utf-8')
manifest={p.name:digest(p) for p in sorted(dest.iterdir())}
(dest/'CHECKSUMS_SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(status='PASS',changed_files=1,unchanged_files=52,candidate_groups=13,physics_steps=0,full_matches=0,delivery_files=len(manifest)+1),indent=2))
