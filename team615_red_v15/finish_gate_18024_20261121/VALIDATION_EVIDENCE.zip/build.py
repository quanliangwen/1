from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from hashlib import sha256
import ast,json,subprocess

r=Path(__file__).resolve().parent
h=lambda b:sha256(b).hexdigest()
assert h((r/'baseline_snapshot.zip').read_bytes())=='706915eca0b4b2d7945a6f5fafe66052b67121bc6a3c9e42c41d828486ef9c65'
with ZipFile(r/'baseline_snapshot.zip') as z:old={n:z.read(n) for n in z.namelist()}
new={p.name:p.read_bytes() for p in (r/'candidate').iterdir() if p.is_file()}
assert set(new)==set(old)
changed=sorted(n for n in old if new[n]!=old[n]);assert changed==['group_exchange.py','map_candidates.py','red_hooks.py']
assert all((r/'baseline'/n).read_bytes()==b for n,b in old.items())
for n,b in new.items():
    if n.endswith('.py'):compile(b,n,'exec')
def methods(blob,cls):
    node=next(x for x in ast.parse(blob).body if isinstance(x,ast.ClassDef) and x.name==cls)
    return {x.name:ast.dump(x,include_attributes=False) for x in node.body if isinstance(x,ast.FunctionDef)}
a,b=methods(old['group_exchange.py'],'GroupExchange'),methods(new['group_exchange.py'],'GroupExchange')
navigation=['observe','prepare_return','commit_return','release','go_root','tick_navigation','eta_root','start','cutoff','expired','complete','message','receive']
assert all(a[n]==b[n] for n in navigation)
ra,rb=methods(old['red_hooks.py'],'RedHooks'),methods(new['red_hooks.py'],'RedHooks')
assert [n for n in ra if ra[n]!=rb[n]]==['control']
current=new['red_hooks.py'].decode().replace('\r\n','\n')
current=current.replace('            self.group_exchange.update_cache(self, step, local_score)\n',
    '            if self.group_exchange.candidates.snapshots and self.group_exchange.try_submit(self, step, local_score):\n                return command\n')
insertion='            if self.group_exchange is not None:\n                self.group_exchange.try_submit(self, step, local_score)\n'
assert current.count(insertion)==1;current=current.replace(insertion,'')
insertion='        if self.group_exchange is not None and self.group_exchange.candidates.snapshots:\n            if self.group_exchange.try_submit(self, step, local_score):\n                return command\n'
assert current.count(insertion)==1
current=current.replace(insertion,'        if self.group_exchange is not None and self.group_exchange.candidates.snapshots:\n')
assert current==old['red_hooks.py'].decode().replace('\r\n','\n')
for name in ['deadline_submission.py','pre_submit_scan.py','final_map_relay.py','submission_renderer.py','second_drop_site.py','fast_closeout.py','exchange_plan.py']:
    assert old[name]==new[name]
with ZipFile(r/'candidate_snapshot.zip','w',ZIP_DEFLATED) as z:
    for n,data in sorted(new.items()):
        item=ZipInfo(n,date_time=(2026,11,21,0,0,0));item.compress_type=ZIP_DEFLATED;z.writestr(item,data)
diff=subprocess.run(['git','-c','core.autocrlf=false','diff','--no-index','--','baseline','candidate'],cwd=r,capture_output=True)
assert diff.returncode==1
patch=diff.stdout.replace(b'a/baseline/',b'a/').replace(b'b/candidate/',b'b/').replace(b'a/candidate/',b'a/')
(r/'finish_gate_18024.patch').write_bytes(patch)
checked=subprocess.run(['git','apply','--check',str(r/'finish_gate_18024.patch')],cwd=r/'baseline',capture_output=True)
assert checked.returncode==0,checked.stderr
result=dict(status='PASS',baseline='partial-selection batch1 final',baseline_zip_sha256=h((r/'baseline_snapshot.zip').read_bytes()),
    candidate_zip_sha256=h((r/'candidate_snapshot.zip').read_bytes()),baseline_member_count=len(old),candidate_member_count=len(new),
    changed_existing_files=changed,added_files=[],unchanged_files=len(old)-len(changed),
    navigation_and_transport_methods_ast_identical=navigation,red_hooks_control_reconstructed_identical=True,
    no_navigation_observation_or_fitting_parameters_changed=True,placement_and_hard_deadline_unchanged=True,
    original_files={n:h(data) for n,data in old.items()},candidate_files={n:h(data) for n,data in new.items()},
    package_role='counterexample-validated research source, not an official competition release',patch_apply_check='PASS',
    new_full_matches=0,new_physics_steps=0)
(r/'BUILD.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('original_files','candidate_files')},indent=2))
