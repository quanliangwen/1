from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json,shutil

r=Path(__file__).resolve().parent;dest=r/'delivery';dest.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_bytes())
b=read(r/'BUILD.json');v=read(r/'received/VALIDATION.json');c=read(r/'received/counterexamples.json')
assert b['candidate_zip_sha256']==v['candidate_zip_sha256']==c['archive_sha256']
assert c['status']==v['status']=='PASS' and c['scenario_groups']==69
assert c['physics_steps']==c['physics_step_attempts']==c['map_objects_created']==c['full_matches']==0
assert all(sha256((r/'candidate'/n).read_bytes()).hexdigest()==checksum for n,checksum in b['candidate_files'].items())
assert all(sha256((r/'baseline'/n).read_bytes()).hexdigest()==checksum for n,checksum in b['original_files'].items())
with ZipFile(r/'candidate_snapshot.zip') as z:
    assert {n:sha256(z.read(n)).hexdigest() for n in z.namelist()}==b['candidate_files']
configuration=dict(
    ordinary_finish_floor='min(PreSubmitScan.finish(drone) + FinalMaps.COLLECTION_STEPS, DeadlineSubmission.window_start(limit))',
    existing_scan_allowance_steps=180,existing_collection_allowance_steps=24,
    example_limit=5400,example_cache_start=3240,example_ordinary_finish_floor=3444,
    low_wall_budget_bypass='wall_left < PreSubmitScan.MIN_WALLTIME_LEFT (12 seconds)',
    terminal_refresh='Once, only after actual inventory/pending/partial-map checks and the finish gate; unchanged renderer on latest live + FinalMaps evidence.',
    previous_best='Individual images immutable; previous current/fusion winner retained in local slot6 before final rerender.',
    local_slots={'0_to_4':'individual original images','5':'current/fusion candidate','6':'previous selected current image, local only'},
    cache_keeps_running_before_finish_gate=True,no_five_source_requirement=True,
    hard_timestep_and_wall_fallback_unchanged=True,no_navigation_or_scanning_or_fitting_changes=True)
result=dict(status='COUNTEREXAMPLES_AND_STATIC_PASS',configuration=configuration,build=b,validation=v,counterexamples=c,
    simulation=dict(new_full_matches=0,new_physics_steps=0,physics_attempts=0,map_objects_created=0),
    actual_map08_score=None,actual_map09_score=None,actual_map08_submission_step=None,actual_map09_submission_step=None,
    synthetic_demo=dict(finish_floor=3444,comparison_available_at_3245=True,proposal_before_3444=False,
        refreshed_at=3444,proposed_at=3446,submitted_at=3448,
        note='Synthetic 64x64 evidence and fake flight state only; not a Map08 trajectory or competition result.'),
    limitations=['No new full simulation, trajectory replay or official platform submission.',
        'Counterexamples validate control contracts and evidence handling, not score recovery or stable Map09 gains.',
        '53 prior protocol/fallback regression groups use shortened timing fixtures where needed; 16 new groups explicitly validate the real 5400-step 3444 finish floor.'])
(dest/'RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for n in b['changed_existing_files']:shutil.copyfile(r/'candidate'/n,dest/n)
for name,source in [('CANDIDATE_SOURCE.zip',r/'candidate_snapshot.zip'),('finish_gate_18024.patch',r/'finish_gate_18024.patch'),
    ('BUILD.json',r/'BUILD.json'),('counterexamples.py',r/'counterexamples.py'),
    ('VALIDATION.json',r/'received/VALIDATION.json'),('counterexamples.json',r/'received/counterexamples.json')]:
    shutil.copyfile(source,dest/name)
with ZipFile(dest/'VALIDATION_EVIDENCE.zip','w',ZIP_DEFLATED) as z:
    for n in ['build.py','counterexamples.py','validate.py','assemble.py']:z.write(r/n,n)
    for p in sorted((r/'received').iterdir()):
        if p.is_file():z.write(p,'raw/'+p.name)
readme=f'''# 180＋24步普通交图门槛与终图重比候选

以本批最终版为基线，已完成修改、69组合成反例和官方静态检查；**本轮没有运行整场仿真，没有新的Map08/Map09分数或实际交图步数**。

## 基线与改动范围

- 基线源码SHA256：`{b['baseline_zip_sha256']}`，来自此前本批最终版[交付提交f50cfe9](https://github.com/quanliangwen/1/tree/f50cfe99aa69ed9fe70755b259e1b9f33057aa90/team615_red_v15/partial_selection_batch1_20261121)。
- 新候选源码ZIP SHA256：`{b['candidate_zip_sha256']}`。
- 共56成员，只改`group_exchange.py`、`map_candidates.py`、`red_hooks.py`；其余53文件字节一致，无新增算法模块。
- 返航、寻路、驱动、避障、通信、扫描与拟合文件及参数不变。GroupExchange导航/传输方法AST一致；red_hooks.control去除交图接入点改动后与基线一致（忽略换行符）。
- 投放复核、实际库存同步、步数/墙钟硬兜底方法和文件不变。

## 本次行为

比较缓存与结束比赛分别处理。到60%且本机实际空仓、无pending时，比较缓存继续工作；不要求5份地图收齐，也不等待全队末弹确认才缓存。真正普通提交仍要求全队库存确认、本机无pending、现有窗口和部分地图检查通过。

新增普通结束门槛，直接读取原有常量：

```python
finish_floor = min(
    drone.pre_submit_scan.finish(drone) + FinalMaps.COLLECTION_STEPS,
    DeadlineSubmission.window_start(drone.limit),
)
```

5400步时为`3240 + 180 + 24 = 3444`。这是绝对步数基准，不从收齐某条消息时重新计24步；重复消息不延后门槛。所有返航中、退出返航和其他状态遵守同一普通交图门槛。旧普通及快收尾普通出口也不能因ABORT绕过它。

墙钟剩余少于原有12秒余量时让行该留时，使用已有候选，不额外进行终图绘制。原硬兜底仍在control最前段优先运行，最后30步窗口保持可达。

普通结束条件首次满足且预算充足时，将最新live memory与已有FinalMaps快照融合，用原渲染器重画一次当前候选；方向证据采用该时刻已收到/已观测的内容。先前最佳缓存、个人原图仍参加同一证据下的比较，新图不直接替换旧最佳。

正常路径的结束检查放在该帧原有观测、方向证据更新和地图缓存刷新之后、返航导航提前return之前。旧信使若提前return，也调用同一结束检查，使用当时已有证据，不额外补扫描，避免再次出现资格不一致。

终图重比通常会保留现有2步比较稳定期与2步提案确认。因此3444是放行下限，不保证真实比赛正好3444步结束。夹具演示3444重比、3446提案、3448提交；**这些仅为合成反例时刻**。

## 旧图保护和缓存细节

- 槽0～4仍为不可覆盖的个人冻结原图。
- 槽5为本机当前/融合图。
- 槽6仅在终图重画前保留此前选中的当前图；它不作为第六架无人机，不参与跨机快照/个人图广播。
- 新终图若更差，可选择槽6旧最佳；新图为空时不清除有效旧图。
- 同一步普通备份已生成图，也不能阻止终图更新；终图以force方式重置该次比较签名，避免“已经渲染但未比较”的同版本问题。
- 终图最多重画一次，重复控制调用不会每帧重拟合；正常实时缓存更新仍照常进行。
- Map09式全队末弹确认不齐时，不触发终图绘制或普通提案，4230/4590步已有新图仍可比较并进入硬兜底缓存。此前软截止后复用已生成实时图的修复保留。

## 反例验证

69组PASS：保留53组协议/兜底回归测试，并新增16组本次专用测试。旧协议测试对原3300步提交场景显式配置缩短的等待夹具，生产常量未变；新增用例使用真实5400步配置验证3444门槛。

| 本次用例 | 验证结果 |
|---|---|
| 3245步候选已存在、库存已清零 | 可缓存，不得提出结束提案或交图 |
| 3444绝对门槛 | 重复广播不重启留时；真实常量推导正确 |
| 3424新增普通墙证据和方向证据 | 进入3444终图重比，不能交旧3241图 |
| 新终图变差 | 保留并可提交之前的最佳图；个人原图不变 |
| 同帧已有普通实时图 | 终图仍更新并参与比较；只重画一次 |
| 墙钟少于12秒 | 不为留时或终图重画拖延已有提交路径 |
| 步数/墙钟硬兜底 | 不受普通结束门槛阻挡 |
| Map09缺末弹确认 | 缓存继续更新，4590已有图进入兜底 |
| 返航、已交付、ABORT等状态 | 同一门槛和普通提交资格 |
| 旧普通/快收尾出口 | 不因退出返航绕过门槛 |
| 信使提前return | 仍可缓存和提交，不额外扫描 |
| 正常control当帧更新 | 原扫描与方向证据更新先于终图绘制 |
| FinalMaps中独立快照 | 可进入终图，不改写live memory |
| 不同最大步数 | 使用原常量并截到最终窗口，不硬编码Map08 |
| 自身带弹、pending或队友未清零 | 普通交图和终图重画均被否决 |
| 空终图 | 保留有效旧候选，不污染兜底缓存 |

合成测试直接导入本次ZIP中的控制器；`pymunk.Space.__init__`和`pymunk.Space.step`被设为调用即失败，尝试0次，未创建比赛地图、未运行物理帧。没有制作或启动整场运行器。

官方SDK静态内容检查PASS；SDK封存文件校验及只读复用环境的NumPy随机数、Pandas和OpenCV实际运算PASS。回执绑定本ZIP。静态检查使用同字节临时合规文件名，不代表官网放行。

## 使用与限制

将补丁应用于SHA706915e的本批最终版，或使用完整CANDIDATE_SOURCE.zip研究源码。不能直接把补丁套在原版或641685d三图候选上。

本候选尚未运行Map08、Map09整场。不能据反例宣称恢复77.1892地图分，也不能保证保住Map09具体成绩。后续如授权整场验证，应核对晚到普通地图是否进入最终候选、实际提交者、终图摘要、掉血与墙钟用时。

RESULTS.json、BUILD.json、VALIDATION.json和VALIDATION_EVIDENCE.zip提供完整追溯。此为研究候选，未作为新正式参赛包放行或上传官网。
'''
assert readme.count('```')%2==0 and '\ufffd' not in readme
(dest/'README.md').write_text(readme,encoding='utf-8')
for p in dest.glob('*.zip'):
    with ZipFile(p) as z:assert z.testzip() is None
checks={p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(dest.iterdir()) if p.name!='CHECKSUMS_SHA256.json'}
(dest/'CHECKSUMS_SHA256.json').write_text(json.dumps(checks,indent=2)+'\n')
assert len(list(dest.iterdir()))==13
print(json.dumps(dict(status='PASS',files=13,counterexample_groups=69,new_full_matches=0,new_physics_steps=0,
                     candidate_zip_sha256=b['candidate_zip_sha256']),indent=2))
