"""Regression cases for both exact second-drop ZIPs using the pinned SDK."""
import argparse
import json
from pathlib import Path
from types import SimpleNamespace
from zipfile import ZipFile

import numpy as np
import swarm_rescue.solutions


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("arm", choices=("baseline", "candidate"))
args = parser.parse_args()
with ZipFile(args.source) as archive:
    assert archive.testzip() is None and len(archive.namelist()) == 51
swarm_rescue.solutions.__path__ = [str(args.source.resolve())]

from swarm_rescue.solutions.fast_closeout import FastCloseout
from swarm_rescue.solutions.placement_preferences import PlacementPreferences
from swarm_rescue.solutions.red_hooks import RedHooks
from swarm_rescue.solutions.second_drop_site import SecondDropSite
from swarm_rescue.solutions.team_wall import TeamWall


SAFE = (12., 0.)
PROTECTED = (15., 0.)
RANGES = np.array([90., 90.])
ANGLES = np.array([-.1, .1])


class Flight:
    _placement_block = RedHooks._placement_block
    _known_bomb_positions = RedHooks._known_bomb_positions

    def __init__(self):
        self.identifier = 0
        self.team_size = 5
        self.initial_inventory = 2
        self.previous_inventory = 1
        self.pending_drop = None
        self.limit = 5400
        self.walltime_limit = 180
        self.elapsed_walltime = 60
        self.heading = 0.
        self.home = None
        self.pose = np.array([0., 0.])
        self.route = [(42., 0.)]
        self._odometry_only = False
        self.drop_departure = SimpleNamespace(started=None, controls_step=-1)
        self.search_roaming = SimpleNamespace(departed=True)
        self.last_attempt_step = -100
        self.grid = SimpleNamespace(pose_fixed=True, cell=lambda point: (0, 0),
                                    clearance=np.array([[15.]]), evidence=np.array([[-4]]))
        self.automatic_exit_clear = True
        self.speed = 0.5
        self.drop_records = {(0, 1): np.array([-35., 0.])}
        self.blast_radius = 135
        self.memory = object()
        self.fine_wall_coverage = SimpleNamespace(measure=lambda memory, p, *a, **kw: (self.gain(p),))
        self.team_wall = SimpleNamespace(query=lambda *a: lambda p: (self.gain(p),),
                                        claims=lambda *a: [], corridor_clear=lambda *a: True,
                                        site_rank=TeamWall.site_rank)
        self.fast_closeout = FastCloseout(self.identifier, self.team_size)
        self.second_drop = SecondDropSite()
        self.placement = PlacementPreferences()
        self.placement._first_drop_exit_clear = lambda *a: self.automatic_exit_clear
        self.placement._protected_turn = lambda *a: None
        self.placement._known_protected_turn = lambda *a: None
        self.placement.deep.passages = SimpleNamespace(
            nearby=lambda point, _: [(200,)] if tuple(point) == PROTECTED else [],
            near_recent_narrow=lambda *a: False, opening_halo_only=lambda *a: False,
            LOCAL_RADIUS=38.)
        self.local_escape = SimpleNamespace(apply=lambda *a: None)

    @staticmethod
    def gain(point):
        return 5. if tuple(point) == PROTECTED else 3. if tuple(point) == SAFE else 1.

    @staticmethod
    def _inside_team_point(point):
        return all(abs(v) < 400 for v in point)

    @staticmethod
    def _placement_spacing(step):
        return 32.

    @staticmethod
    def lidar_rays_angles():
        return ANGLES

    @staticmethod
    def drive(point, velocity):
        return {"forward": 0.}

    def odometer_values(self):
        return self.speed, 0., 0.

    def carried_bombs_count(self):
        return self.previous_inventory


candidate = args.arm == "candidate"
results = {}
drone = Flight()
second = drone.second_drop
_, _, _, rows, best = second.assess(drone, 1990, RANGES, (),
    [("backup", SAFE, 1985), ("backup", PROTECTED, 1985)], early=False)
assert best[1] == (SAFE if candidate else PROTECTED)
assert ("turn_hold_passage" in rows[1][3]) == candidate
assert np.linalg.norm(np.array(SAFE) - drone.drop_records[(0, 1)]) < drone.blast_radius
results["selection_within_blast_radius"] = dict(selected=best[1], protected_failures=rows[1][3])

drone = Flight()
second = drone.second_drop
drone.pose = np.asarray(SAFE)
second.plan = (1995, SAFE, .8, 3.)
command = {"place_bomb": 0}
if candidate:
    assert not second.commit(drone, command, 2000)
    assert second.steer_ordinary(drone, 2000, command, RANGES, ())
    assert drone.placement.request[1] == "reserved_second"
    assert drone.pending_drop[2] == 2000 and not second.used
else:
    assert second.control(drone, 2000, command, RANGES, ()) == "ready"
assert command["place_bomb"] == int(candidate)
results["ordinary_arrival_places_on_slot"] = bool(command["place_bomb"])

if candidate:
    drone.placement.finish_request(drone, 2001)
    assert second.plan is None and not second.used and second.retry_at == 2011
    drone.pending_drop = None
    drone.pose = np.zeros(2)
    second.keep_backup(2008, SAFE, 3.)
    assert not second.reserve(drone, 2010, RANGES, ())
    assert second.reserve(drone, 2011, RANGES, ())
    drone.pose = np.asarray(SAFE)
    assert second.steer_ordinary(drone, 2020, {}, RANGES, ())
    drone.previous_inventory = 0
    drone.drop_records[(0, 2)] = drone.pose.copy()
    drone.placement.finish_request(drone, 2021)
    assert second.used and second.plan is None
    results["sdk_reject_replan_and_confirmation"] = True

drone = Flight()
second = drone.second_drop
drone.pose = np.asarray(SAFE)
second.plan = (1995, SAFE, .8, 3.)
drone.automatic_exit_clear = False
state = second.control(drone, 2000, {}, RANGES, ())
assert state == (None if candidate else "ready")
assert (second.plan is None) == candidate
results["lost_live_exit_cancels"] = second.plan is None

drone = Flight()
second = drone.second_drop
drone.pose = np.asarray(SAFE)
second.plan = (1995, SAFE, .8, 3.)
drone.automatic_exit_clear = False
fast = drone.fast_closeout
fast.plan = (2000, 0)
fast.move_remaining = lambda *a: None
command = {"place_bomb": 0}
assert fast.act(drone, 2000, command, RANGES, ())
assert command["place_bomb"] == int(not candidate)
results["fast_closeout_respects_rejected_reservation"] = not bool(command["place_bomb"])

if candidate:
    drone = Flight()
    second = drone.second_drop
    drone.pose = np.asarray(SAFE)
    drone.speed = 3.
    second.plan = (1995, SAFE, .8, 3.)
    assert second.control(drone, 2000, {}, RANGES, ()) == "approach"
    assert second.plan is not None
    drone.speed = 0.5
    drone.drop_records[(1, 1)] = np.array([-24., 20.])
    failed = second.current_blocks(drone, 2000, RANGES, (), 3., .8)
    assert "patch_full" in failed and "spacing" not in failed
    drone.drop_records[(1, 1)] = np.array([36., 0.])
    failed = second.current_blocks(drone, 2000, RANGES, (), 3., .8)
    assert "spacing" in failed
    assert second.control(drone, 2000, {}, RANGES, ()) is None
    assert not second.commit(drone, {}, 2000)
    results["speed_density_and_spacing_rechecked"] = True

print(json.dumps(dict(arm=args.arm, status="PASS", scenarios=results), indent=2))
