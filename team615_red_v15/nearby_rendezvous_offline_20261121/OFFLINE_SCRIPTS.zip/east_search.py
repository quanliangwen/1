"""Frozen-map shortest-path calculations only. Never runs controllers or physics."""
import json
from pathlib import Path
reference=Path('reference_analyze.py').read_text()
prefix=reference.split('model=build(23.)')[0]
prefix=prefix.replace('margin=margin,free=free','graph=graph,margin=margin,free=free')
prefix=prefix.replace('path=np.vstack([path,[0.,0.]])','path=np.vstack([path,HUB])')
exec(prefix)
model=build(23.)
HUB=np.array([0.,0.])

def configure(center):
    global HUB
    HUB=np.array(center,float)
    goals=np.flatnonzero(np.linalg.norm(model['xy']-HUB,axis=1)<=160.)
    idx=int(model['tree'].query(HUB)[1])
    model['hub']=idx
    model['hubdist'],model['hubpred']=dijkstra(model['graph'],directed=True,indices=idx,return_predecessors=True)
    model['radiodist'],model['radiopred'],_=dijkstra(model['graph'],directed=True,indices=goals,min_only=True,return_predecessors=True)

def nogps_margin(p):
    values=[]
    for x0,y0,x1,y1 in [(-637,-99,-129,557),(127,-435.5,751,45.5)]:
        x,y=p
        if x0<=x<=x1 and y0<=y<=y1:return -min(x-x0,x1-x,y-y0,y1-y)
        values.append(math.hypot(max(x0-x,0,x-x1),max(y0-y,0,y-y1)))
    return min(values)

candidates=[(780,y) for y in range(-420,221,20)]+[(790,y) for y in range(-420,221,40)]



rows=[]
for index,center in enumerate(candidates):
    if clearance([center])[0]<30 or nogps_margin(center)<20:continue
    configure(center)
    lengths=[]
    for i in range(5):
        a=attach(model,pos(i,3240),'hub' if i==0 else 'radio')
        lengths.append(None if a is None else a[0])
    if any(v is None for v in lengths):continue
    needs=[math.ceil(v/2)+(12 if i==0 else 24) for i,v in enumerate(lengths)]
    rows.append(dict(center=center,clearance=float(clearance([center])[0]),gps_margin=nogps_margin(center),
        grid_lengths=lengths,nominal_needs=needs,total=sum(needs),
        nonidle_total=sum(needs[i] for i in [0,1,3,4]),max_need=max(needs),
        max_nonidle_need=max(needs[i] for i in [0,1,3,4])))
    if index%10==0:print('SEARCH',index,center,needs,flush=True)
Path('EAST_SEARCH.json').write_text(json.dumps(rows,indent=2))
for key in ['total','nonidle_total','max_need','max_nonidle_need']:
    print('BEST',key,json.dumps(sorted(rows,key=lambda r:r[key])[:5]),flush=True)
