from pathlib import Path
from hashlib import sha256
import json, math, zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle

root=Path(__file__).resolve().parent
dest=root/'delivery'
dest.mkdir(exist_ok=True)
d=json.loads((root/'DETAIL_RESULTS.json').read_text())
d['coarse_search']=json.loads((root/'COARSE_SEARCH.json').read_text())
d['east_search']=json.loads((root/'EAST_SEARCH.json').read_text())
d['east_late_host_speed_sensitivity']=json.loads((root/'SENSITIVITY.json').read_text())
d['selection']='Recommend east (780,-180) among scanned static candidates; not a global optimality claim. Prioritize less diversion of moving drones; drone2 was nearly stationary.'
d['communication_goal']='Drone0 collecting visitor packets; full final-map synchronization across every pair is not assumed.'
d['baseline_submission_window_note']='Original pre_submit_scan waits until3420; final_maps adds its existing waiting. Meeting completion around3400 does not by itself change original submission timing.'
d['previous_report_comparison']='Original earlier 1935 drone-step estimate used a different5-step sampling phase. Current same_window origin estimate1940 differs by5steps. Fair same-deadline late-host comparisons here:1851 vs1209 vs944.'
d['if_all_depart_at3240']={}
for name,c in d['candidates'].items():
    hub_ready=3240+c['at3240'][0]['required_steps']['2.0']
    rows=[]
    for r in c['at3240'][1:]:
        arrive=3240+math.ceil(r['route']['route_length_pixels']/2.)
        rows.append(dict(drone=r['drone'],arrive_contact_zone=arrive,wait_for_hub=max(0,hub_ready-arrive),
                         exchange_done=max(arrive,hub_ready)+24))
    d['if_all_depart_at3240'][name]=dict(hub_ready=hub_ready,visitors=rows)

for name,c in d['candidates'].items():
    for label,s in c.get('schedules',{}).items():
        host_ready=s['rows'][0]['ready_or_exchange_done']
        for i,q in enumerate(s['rows']):
            deadline=s['hub_ready_by'] if i==0 else s['exchange_by']
            assert q['depart_step']>=d['own_last_drop_confirmations'][str(i)]
            assert q['depart_step']+q['required_steps']==q['ready_or_exchange_done']<=deadline
            assert q['route'].get('end_distance_from_hub',0)<=160.02
            if i:assert q['ready_or_exchange_done']-24>=host_ready
        assert sum(q['original_task_steps_displaced'] for q in s['rows'])==s['total_task_steps_displaced']
(dest/'RESULTS.json').write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

walls=np.load(root.parent/'team615_map08_origin_rendezvous_offline_20261121'/'PATH_GEOMETRY.npz')['walls']
fig,axes=plt.subplots(1,2,figsize=(22,8.4),dpi=150)
colors=['tab:red','tab:blue','tab:green','tab:purple','tab:brown']
for ax,name,title in zip(axes,['origin','east'],['Original origin hub','Nearby east hub (780, -180)']):
    c=d['candidates'][name];hub=c['center']
    ax.imshow(walls,cmap='Greys',origin='upper',extent=(-830,830,-561,561),vmin=0,vmax=1,interpolation='nearest')
    for x,y,w,h in [(-637,-99,508,656),(127,-435.5,624,481)]:
        ax.add_patch(Rectangle((x,y),w,h,color='orange',alpha=.1))
    ax.add_patch(Circle(hub,180,fill=False,ls='--',ec='gray',lw=1))
    ax.add_patch(Circle(hub,160,fill=False,ec='green',lw=1.6))
    for row in c['at3240']:
        i=row['drone'];p=np.array(row['route']['waypoints'])
        ax.plot(p[:,0],p[:,1],color=colors[i],lw=1.7,label=f'D{i}: {row["route"]["route_length_pixels"]:.0f} px')
        ax.scatter(*p[0],color=colors[i],s=30,zorder=5)
        ax.annotate(f'D{i}',p[0],xytext=(4,7 if i in [0,3] else -12),textcoords='offset points',color=colors[i],fontsize=8,weight='bold')
        ax.scatter(*p[-1],color=colors[i],s=12,zorder=4)
    ax.scatter(*hub,marker='*',s=130,color='black',zorder=6)
    ax.annotate('D0 receiving hub',hub,xytext=(-110,14),textcoords='offset points',fontsize=9,
                bbox=dict(facecolor='white',alpha=.8,edgecolor='none'))
    ax.set(xlim=(-830,830),ylim=(-561,561),xlabel='World x (px)',ylabel='World y (px)',title=title)
    ax.set_aspect('equal');ax.legend(loc='upper left',fontsize=8,framealpha=.95)
fig.suptitle('Frozen original seed615 Map08 | positions at control step3240 | static paths, no simulation',fontsize=13)
fig.text(.5,.015,'Orange: NoGPS. Green circle: planning radio radius160px; dashed: SDK radius180px. D0 goes to hub; others stop at radio contact.',ha='center',fontsize=10)
fig.tight_layout(rect=(0,.08,1,.95));fig.savefig(dest/'ROUTES.png');plt.close(fig)

report='''潜力1.1原版 / 种子615 / Map08：非原点会合位置离线比较

结论与建议
建议优先考虑右侧有GPS走廊内的(780,-180)，以0号机作单次接收点，其他机只进入160px通信半径，不要求飞到同一点。它是本次扫描候选中适合减少正在移动的0/1/3/4号机绕路的选择，不是证明全局最优。
代价是2号机需要更远的路。不过2号在2489～3240步基本停留（751步累计约24.35px，所有单步位移均小于0.2px），因此提前调它可能更多替代停留，而不是挤占有效探索。静止不代表绝对没有地图更新，不能据此断言2号地图完全相同。
该坐标仅为Map08候选，不应直接作为其他地图的通用坐标。

方法、真实性边界
仅使用原版封存轨迹与地图，轨迹SHA验证、572条trace对齐；控制步=录像帧+3。算法源码未修改；新比赛=0、物理仿真步=0。静态路径搜索并非比赛仿真。
2px栅格，路径主体机身中心离墙至少23px，短起点连接保留原有18px级净空；禁止对角穿墙。采用官方真值墙体，仅说明几何可达，无法证明每架机当时的局部导航图已知该路线。
SDK无线为严格距离<180px，Map08没有NoCom，墙不阻断无线；采用160px作为规划半径。0号到实际接收点；其余只到该半径内的安全点。无需每对飞机互相直连，也不要求每架机都拿到最终合集。本次以0号收图为完成目标。
时间为ceil(路长/平均速度)+预留。中等速度2.0px/步，另检查1.5与2.8；0号留12步刹停，访客留24步通信。这些不是新实测的控制速度、实际收包确认或传输完成保证。

候选位置对比：统一从3240步真值位置起算
目标                 0号路长/耗步  1号路长/耗步  2号路长/耗步   3号路长/耗步  4号路长/耗步
原点(0,0)            1147/586      839/444        308/178         474/261       537/293
中部走廊(460,80)      313/169      452/250        618/334           0/24        282/166
右侧走廊(780,-180)    237/131      241/145       1054/552         109/79        234/141
耗步包含上述刹停/通信预留。中部方案总路程较小，但仍需要0/1/2号提前返航；右侧方案把较大的负担转移到此前停留的2号机。
候选点(780,-180)离墙约44px，距NoGPS右边界29px，自身位于有GPS区。访客接触点可能仍在NoGPS内；不等于每架机的全程都有GPS。

右侧点的可达路线示例（3240出发，精确转折见RESULTS.json）
0号：(577.66,-159.57)→(602.5,-209.5)→(622.5,-213.5)→(780,-180)。
1号：(642.63,-470.60)→(610.5,-461.5)→(604.5,-447.5)→(604.5,-323.5)→(654.5,-277.5)，停在接收点约159px处即可。
2号：(86.55,-452.71)→(100.5,-319.5)→(220.5,-37.5)→(222.5,64.5)→(238.5,74.5)→(500.5,62.5)→(542.5,56.5)→(652.5,-39.5)→(694.5,-45.5)。绕行较长，是本方案的主要远端成本。
3号：(597.62,2.85)→(690.5,-45.5)→(694.5,-45.5)。
4号：(411.44,-315.27)→(624.5,-223.5)→(626.5,-223.5)。无线穿墙避免了为见到0号而额外绕墙。

3240～3420步内能否完成通信
如果所有机都在3240动身，0号约3371就绪；1/3/4号进区分别约3361/3295/3357，需等接收点就绪，三者都约3395完成通信。2号约3792才能完成，赶不上。所以不能把“0/1/3/4号各自耗步<180”误当成“全员不必提前安排”。
若2号提前出发，其他机错峰接近，几何和中等速度预算支持在窗口内完成0号收包。

最小错峰安排：0号3340前就绪，访客3400前完成，给3420硬边界留20步
编号  出发参考步  当时返航路长  行进+预留  就绪/通信完成步  总占用原任务时间
0     3220         201px        113步       3333              180步
1     3335          81px         65步       3400               65步
2     2845        1053px        551步       3396              551步
3     3275         200px        124步       3399              124步
4     3375           0px         24步       3399               24步
4号在原版3375步位置已经位于新接收点160px内，静态估算可直接通信，不需要专门返航。各出发步均晚于自身末弹实投确认时间（2309/1693/2315/2316/2489）。
表中每个出发点沿原轨迹单独查得，只是反事实安排的参考；其他飞机改道后，动态避让会使轨迹不同，不能把这些步数当作可复现的新轨迹。参考点以5步采样，不证明唯一最晚截止。

同口径比较原任务时间占用
都使用“0号3340前就绪、访客3400前完成”的时限：
位置        五机合计占用   不含此前停留的2号机的占用
原点        1851机步       1672机步
(460,80)    1209机步        876机步
(780,-180)   944机步        393机步
右侧比原点合计少约907机步（约49%），其中0/1/3/4号少1279机步，2号多372机步。这里的“占用原任务时间”包括返航、刹停、通信和接收点等待，不能直接换算成探索率或地图分损失；4号通信期间仍可能正常移动，24步也未必等于24步损失。
若继续要求0号3240前就绪并留到3420，当前采样原点约1940机步、右侧约1016机步；此前报告原点1935与当前1940相差5，是5步扫描相位差异，不是新比赛结果或轨迹变化。

速度敏感性
谨慎1.5px/步下，要同样在3340/3400前就绪和收包，五机参考出发步为3205/3115/2670/3260/3375，合计约1355机步。中等速度为3220/3335/2845/3275/3375；乐观2.8px/步为3240/3350/2995/3285/3375。
出发截止会随原轨迹位置、障碍拓扑和速度呈跳变，不应线性内插。尤其2号按1.5应在2670左右出发，不能照抄2845；1号若追求3400完成，在较低速度下也要更早安排。当前数值未建模动态碰撞、包分片、定位误差或墙钟预算，不保证20步余量足以覆盖所有影响。

最小方案，仍停留在设计层面
1. 只加入一次“0号定点接收、其他空载机接近通信半径”的短阶段，不建立新的多轮信使或滚动配送机制。
2. 0号到(780,-180)刹停，访客到可通信的安全点即可；地图按原版方式生成和更新，不启用之前第一批信使ACTIVE的持续刷新改动，不改导航和拟合参数。
3. 优先提前调度此前停留的2号；1/3/4号尽量沿原探索轨迹晚些接触。上表是时间预算示例，实际应按可达路线和剩余步数提前留余量，不把5个参考步数直接写成通用规则。
4. 每架机这一阶段只交一次当前数据，收到可核验的收包确认就退出；没有必要为了站到同一点而继续靠近，也不要求等到五机同时到场。不把无数据包的靠近当作地图已经交付。
5. 到3420或原有墙钟兜底优先触发时立即结束会合，未到者不拉长全队等待；保留原版投放复核、地图拟合和双时限交图兜底。

收益边界：通信完成不等于提前交图
原版pre_submit_scan.waiting()在3240～3420继续等待，随后仍有原有final_maps等收尾判断。仅换会合点、在3400收包，不会自动让原版在3400交图；本方案不另改这些窗口。
原版记录也显示0号2538步已收到4号库存清零，其他库存此前已清零。该会合的潜在价值应是刷新有用地图信息，不能宣称修复了这场比赛的末弹确认缺失。
这次能确认的是：右侧会合显著减少多架正在移动飞机的几何绕路，并存在满足窗口的静态时间安排。不能确认实际地图分是否提高、真实探索损失多少、能否更早交图或墙钟是否缩短。下一步若研究应先验证通信数据确实被0号采用，避免只改变移动路径但最终仍被旧交图窗口挡住。
'''
(dest/'REPORT.txt').write_text(report,encoding='utf-8')
with zipfile.ZipFile(dest/'OFFLINE_SCRIPTS.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for name in ['reference_analyze.py','search.py','east_search.py','detail.py','sensitivity.py','prepare_delivery.py']:
        z.write(root/name,name)
manifest={p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(dest.iterdir()) if p.name!='CHECKSUMS_SHA256.json'}
(dest/'CHECKSUMS_SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':list(manifest),'candidate_counts':[len(d['coarse_search']),len(d['east_search'])],
    'nominal_total':944,'remote_publish_pending':True}))
