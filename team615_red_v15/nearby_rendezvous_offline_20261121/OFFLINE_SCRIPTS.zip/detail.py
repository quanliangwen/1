import json
from pathlib import Path
exec(Path('search.py').read_text().split('candidates=')[0])

route_old=route
def route(model,p,kind):
    if kind=='radio' and np.linalg.norm(p-HUB)<=160:
        return dict(grid_length_pixels=0.,route_length_pixels=0.,start_clearance_pixels=float(clearance([p])[0]),
                    connector_pixels=0.,checked_grid_min_clearance_pixels=float(clearance([p])[0]),
                    waypoints=[p.tolist(),p.tolist()],end_distance_from_origin=float(np.linalg.norm(p)),
                    route_sample_fraction_in_no_gps=None,already_in_contact=True)
    rr=route_old(model,p,kind)
    if rr is not None:
        rr['end_distance_from_hub']=float(np.linalg.norm(np.array(rr['waypoints'][-1])-HUB))
    return rr

def latest(i,deadline,speed,settle):
    kind='hub' if i==0 else 'radio'
    # Admissible straight-line lower bound only screens impossible late departures.
    best=None
    for t in range(deadline,last[i]-1,-5):
        p=pos(i,t)
        lower=max(0.,float(np.linalg.norm(p-HUB))-(160. if kind=='radio' else 0.))
        if t+math.ceil(lower/speed)+settle>deadline:continue
        rr=route(model,p,kind)
        if rr is None:continue
        need=math.ceil(rr['route_length_pixels']/speed)+settle
        if t+need<=deadline:
            best=dict(depart_step=t,required_steps=need,ready_or_exchange_done=t+need,
                      position=p.tolist(),route=rr)
            break
    return best

result=dict(new_matches=0,simulation_steps=0,seed=615,map='Map08',alignment_checks=aligned,
    input_sha256={str(p):sha256(p.read_bytes()).hexdigest() for p in [track_file,source/'wall_geometry.npz',source/'OFFICIAL_SCORE.json',source/'placement_events.jsonl']},
    baseline_zip_sha256='c3021a3eb48031e82bfac9306654b48ca09f168d6f65b13349cf12f783104c7c',
    nominal_speed=2.,radio_planning_radius=160.,wall_clearance=23.,
    notes=['Truth-map static geometry only; no controller, physics, new trajectories or score predictions.',
           'Departure examples sampled every 5 steps and are not proofs of the unique optimal schedule.',
           '24-step communication and 12-step hub settling reserves are assumptions, not observed communication tests.',
           'Short start connectors may retain existing 18px clearance; route bodies checked at 23px.',
           'NoGPS navigation uncertainty, drone collisions, congestion, online map visibility not modelled.'],
    own_last_drop_confirmations=last,candidates={})
for name,center in [('origin',(0,0)),('middle',(460,80)),('east',(780,-180)),('east_north',(780,-160))]:
    configure(center)
    c=dict(center=center,clearance=float(clearance([center])[0]),gps_margin=nogps_margin(center),at3240=[])
    for i in range(5):
        rr=route(model,pos(i,3240),'hub' if i==0 else 'radio')
        c['at3240'].append(dict(drone=i,position=pos(i,3240).tolist(),route=rr,
            required_steps={str(v):math.ceil(rr['route_length_pixels']/v)+(12 if i==0 else 24) for v in SPEEDS}))
    if name in ['origin','middle','east']:
        c['schedules']={}
        for label,hub_by,exchange_by in [('same_window',3240,3420),('minimal_late_host',3340,3400)]:
            times=[]
            for i in range(5):
                q=latest(i,hub_by if i==0 else exchange_by,2.,12 if i==0 else 24)
                if q:
                    q['original_task_steps_displaced']=exchange_by-q['depart_step'] if i==0 else q['required_steps']
                    q['before3240']=max(0,3240-q['depart_step'])
                times.append(q)
            c['schedules'][label]=dict(hub_ready_by=hub_by,exchange_by=exchange_by,rows=times,
                total_task_steps_displaced=sum(q['original_task_steps_displaced'] for q in times),
                nonidle_task_steps_displaced=sum(q['original_task_steps_displaced'] for i,q in enumerate(times) if i!=2))
    result['candidates'][name]=c
    print('DETAIL',name,center,'lengths',[round(x['route']['route_length_pixels'],1) for x in c['at3240']],flush=True)
    for label,values in c.get('schedules',{}).items():
        print(label,json.dumps([{k:v for k,v in r.items() if k not in ['route','position']} for r in values['rows']]),flush=True)

Path('DETAIL_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
