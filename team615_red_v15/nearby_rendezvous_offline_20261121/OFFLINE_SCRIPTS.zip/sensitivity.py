import json
from pathlib import Path
exec(Path('detail.py').read_text().split('result=dict')[0])
configure((780,-180))
r={}
for v in [1.5,2.8]:
    rows=[]
    for i in range(5):
        q=latest(i,3340 if i==0 else 3400,v,12 if i==0 else 24)
        q['original_task_steps_displaced']=3400-q['depart_step'] if i==0 else q['required_steps']
        rows.append(q)
    r[str(v)]=rows
    print(v,json.dumps([{k:x for k,x in q.items() if k not in ['route','position']} for q in rows]),flush=True)
Path('SENSITIVITY.json').write_text(json.dumps(r,indent=2))
