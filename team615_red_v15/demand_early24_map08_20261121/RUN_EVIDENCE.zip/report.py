from pathlib import Path
from hashlib import sha256
import json

root=Path(__file__).resolve().parent
delivery=root/'delivery'
r=json.loads((delivery/'RESULTS.json').read_bytes())
o,c=r['runs']['original'],r['runs']['candidate'];d=r['candidate_minus_original']
rows=[('主动走访目标／配送任务数',str(len(o['legacy_target_visits'])),str(len(c['delivery_tasks']))),
      ('自动第二轮次数',str(o['legacy_second_rounds']),str(c['legacy_second_rounds'])),
      ('0号全队清零后新发起的赴0走访',str(o['trips_to0_started_after_leader_clear']),str(c['trips_to0_started_after_leader_clear'])),
      ('0号全队清零后仍处于信使阶段的步数',str(o['messenger_active_steps_after_leader_clear']),str(c['messenger_active_steps_after_leader_clear'])),
      ('0号首次确认全队清零步数',str(o['leader_team_clear_step']),str(c['leader_team_clear_step'])),
      ('交图机／交图步数',f"{o['selected_submission']['drone']}号／{o['submission_step']}",f"{c['selected_submission']['drone']}号／{c['submission_step']}"),
      ('实投数',str(o['placed']),str(c['placed'])),
      ('地图得分／100',f"{o['map_score']:.4f}",f"{c['map_score']:.4f}"),
      ('漏墙像素',str(o['missed_wall_pixels']),str(c['missed_wall_pixels'])),
      ('扣分误画像素',str(o['charged_misdraw_pixels']),str(c['charged_misdraw_pixels'])),
      ('探索率／%',f"{o['exploration_percent']:.4f}",f"{c['exploration_percent']:.4f}"),
      ('五机总掉血',str(o['total_health_lost']),str(c['total_health_lost'])),
      ('整局墙钟／秒',f"{o['elapsed_walltime_seconds']:.2f}",f"{c['elapsed_walltime_seconds']:.2f}"),
      ('已测得分／80',f"{o['partial_score_out_of_80']:.4f}",f"{c['partial_score_out_of_80']:.4f}")]
lines=['潜力1.1原版与按缺口配送及24步早交图候选 Map08种子615单局对照','',
       '本局早交图功能确实生效，且投满10枚，但地图损失大于时间收益，已测得分下降4.2827分，不建议据此替换原版。',
       '本次仅新增候选一局；原版使用已核验的历史同种子、同SDK、同出生点结果，没有新跑原版或其他地图。候选源码未改。',
       'SDK 6557940dc18549ffc7a945db887da5b05b7ed2f1，5机各2枚、5400步、180秒，NoGPS区域2个、NoCom区域0个。使用共享串行评测锁。',
       '比赛过程中评测观察逻辑与原版相同；只在比赛结束后补读early_submission_event和配送集合，未改运行中的控制逻辑。',
       '', '指标\t原版（已有结果）\t候选（本次唯一新增一局）']
lines += ['\t'.join(row) for row in rows]
lines += ['', '早交图核验']
if c['early_submission_event']:
    e=c['early_submission_event']
    lines += [f"早交图分支实际触发：ready_step={e['ready_step']}，提交step={e['step']}，相隔{e['step']-e['ready_step']}步。",
              f"较原版提前{o['submission_step']-c['submission_step']}步。这个结果是整场实测，不沿用反例夹具中的2562步。"]
else:
    lines += ['本局没有early_submission_event，不能认定早交图分支实际成功触发。',json.dumps(c['deadline_events'],ensure_ascii=False)]
lines += ['', '配送核验',
          '原版没有逐任务载荷字段，不能把全部走访一概追认成无效。本表用自动第二轮、0号已清零后新发起赴0走访、清零后仍处于信使阶段步数分别描述冗余迹象。',
          '清零后活跃步数并不代表这些步数全部无价值；无人机也可能仍在服务其他接收机。候选任务数为实际delivery_start数量。',
          '候选任务没有新增清零事实却启动的次数：'+str(c['delivery_without_new_fact_count']),
          '没有配送任务本身不等于成功送达，必须同时看0号拿齐信息的步数和实际交图结果。',
          '本局候选没有启动主动配送任务；0号在2729步才拿齐清零信息，比原版2538步晚191步。取消走访没有在这局带来更早的信息齐备，提前交图来自绕过旧等待链。',
          '库存日志确认：0号机第2729步通过3号机转发，得知4号机已清零。',
          '原版信使日志：'+json.dumps(o['messenger_audit'],ensure_ascii=False),
          '候选信使日志：'+json.dumps(c['messenger_audit'],ensure_ascii=False),
          '', '得分拆分',
          f"地图项变化：{.5*d['map_score']:+.4f}分；墙覆盖项变化：{.2*d['wall_score']:+.4f}分；时间项变化：{.1*d['time_score']:+.4f}分；合计：{d['partial_score_out_of_80']:+.4f}分。",
          f"候选相对原版：地图得分{d['map_score']:+.4f}，漏墙{d['missed_wall_pixels']:+d}像素，扣分误画{d['charged_misdraw_pixels']:+d}像素，探索率{d['exploration_percent']:+.4f}个百分点，掉血{d['total_health_lost']:+d}，墙钟{d['elapsed_walltime_seconds']:+.2f}秒。",
          '官方炸弹最终中心坐标逐项相同：'+str(r['official_bomb_positions_identical'])+'。角度字段有差异，墙覆盖得分相同。',
          '', '口径',
          '漏墙指真实墙面像素中未被提交图命中的像素；误画指距真墙超过10px容差而被扣分的预测像素。探索率为实际航迹覆盖；掉血是五机初始总血125减最终总血。墙钟为SDK整局elapsed_walltime，包含提交后的收尾。',
          '已测得分只含红队80分部分，另外20分蓝队布局难度未测。历史原版与本次候选各一局，墙钟差异受运行负载影响。',
          '只有这一张地图、这一粒种子的一次新比赛，未验证多种子稳定性。',
          '', '候选SHA256 '+r['build']['candidate_zip_sha256'],
          'RESULTS.json保留精确分数、任务日志、清零和早交图事件；RUN_EVIDENCE.zip保留官方图像、逐帧轨迹、炸弹布局、来源与校验信息。']
(delivery/'RESULT.txt').write_text('\n\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
(delivery/'CHECKSUMS_SHA256.json').write_text(json.dumps({p.name:sha256(p.read_bytes()).hexdigest() for p in delivery.iterdir() if p.name!='CHECKSUMS_SHA256.json'},indent=2)+'\n')
print('Report and checksum manifest ready.')
