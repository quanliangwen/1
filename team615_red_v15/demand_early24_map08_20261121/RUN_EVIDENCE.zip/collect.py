from hashlib import sha256
from pathlib import Path, PurePosixPath
from zipfile import ZipFile, ZIP_DEFLATED
import json
import math
import subprocess
import numpy as np

root=Path(__file__).resolve().parent
old=root.parent/'team615_messenger_batch1_20261121'
code=root.parent/'team615_demand_delivery_early24_20261121'
received=root/'received'
delivery=root/'delivery'
remote='/home/quanliangwen/isolated_test/team615_demand_early24_map08_M8RHJS'
host='quanliangwen@10.112.162.60'

def read(p):return json.loads(p.read_bytes())
def digest(p):return sha256(p.read_bytes()).hexdigest()
def download(paths,folder):
    folder.mkdir(exist_ok=True,parents=True)
    subprocess.run(['scp','-q','-o','BatchMode=yes',*(f'{host}:{p}' for p in paths),str(folder)],check=True)

def summarize(folder,expected_sha,expected_files):
    start,end,source,score=(read(folder/f'{n}.json') for n in ['START','FINISH','SOURCE_MATCH','OFFICIAL_SCORE'])
    assert [start[k] for k in ['seed','sdk','sdk_archive_sha256','map_name','drones','bombs_per_drone','timestep_limit','walltime_limit','competition_mode']]==[
        615,'6557940dc18549ffc7a945db887da5b05b7ed2f1','9155bc4cdf5e0813cd328d3a56c3b73633ba351c3859e694762ed41376fc6860','Map08',5,2,5400,180,True]
    assert start['spawn']==read(root/'matched_spawns.json')['Map08']
    assert start['zones']==read(root/'EXPECTED_ZONES.json')['Map08']
    assert source['candidate_zip_sha256']==expected_sha
    assert start['solutions_sha256']==source['candidate']==expected_files
    assert [end[k] for k in ['status','completed_red_rounds','blue_rounds','layout_evaluations']]==['COMPLETE',1,0,0]
    assert digest(folder/'placement_events.jsonl')==score['placement_events_sha256']
    assert digest(folder/'wall_geometry.npz')==score['wall_geometry_sha256']
    for name,sha in end['files'].items():assert digest(folder/'official'/name)==sha
    assert math.isclose(score['partial'],.5*score['map_score']+.2*score['coverage']+.1*score['time_score'],abs_tol=1e-8)
    layout=read(next((folder/'official').glob('*bombs.json')))['bombs']
    assert len(layout)==score['placed']
    selected=score['selected_submission']
    if selected and selected.get('drone') is not None:assert selected['image_sha256']==score['selected_image_sha256']
    leader=next(d for d in score['drone_details'] if d['drone']==0)
    messenger=next(d for d in score['drone_details'] if d['drone']==4)
    audit=messenger['messenger_audit']
    first_zero={0:leader['last_confirmation']} if leader['inventory']==0 else {}
    for row in leader['team_exchange_audit']:
        if row[0]=='stock' and row[4]==0:
            first_zero.setdefault(row[3],row[1])
    clear_step=max(first_zero.values()) if len(first_zero)==5 else None
    legacy=[e for e in audit if e[1]=='target_picked']
    tasks=[e for e in audit if e[1]=='delivery_start']
    used=set();duplicates=0
    for task in tasks:
        payload=set(task[3]);duplicates+=int(not payload-used);used.update(payload)
    intervals=[];active=None
    stops={'messenger_done','receiver_satisfied','delivery_budget_exhausted','delivery_unconfirmed','receiver_position_stale','peer_skipped','target_unreachable'}
    for e in audit:
        if e[1] in ('messenger_enter','delivery_start'):active=e[0]
        if active is not None and (e[1]=='messenger_done' or tasks and e[1] in stops):
            intervals.append([active,e[0]]);active=None
    if active is not None:intervals.append([active,score['steps']])
    post_clear=sum(max(0,end-max(begin,clear_step)) for begin,end in intervals) if clear_step is not None else None
    states=np.load(next((folder/'official/recordings').glob('*.npz')))['drone_states']
    distance=float(np.hypot(np.diff(states['x'][:,4].astype(float)),np.diff(states['y'][:,4].astype(float))).sum())
    b=score['map_breakdown']
    return dict(source_zip_sha256=expected_sha,map_score=score['map_score'],partial_score_out_of_80=score['partial'],
        wall_score=score['coverage'],time_score=score['time_score'],exploration_percent=score['trajectory'],
        missed_wall_pixels=b['wall_pixels']-b['wall_hits'],charged_misdraw_pixels=b['charged_pixels'],map_breakdown=b,
        submission_step=score['steps'],selected_submission=selected,placed=score['placed'],official_bomb_layout=layout,
        total_health_lost=sum(25-d['health'] for d in score['drone_details']),final_health={d['drone']:d['health'] for d in score['drone_details']},
        elapsed_walltime_seconds=score['elapsed_walltime'],leader_first_confirmed_empty_steps=first_zero,
        leader_empty_report_receipts=[e for e in leader['team_exchange_audit'] if e[0]=='stock' and e[4]==0],
        leader_team_clear_step=clear_step,early_submission_event=leader.get('early_submission_event'),
        legacy_target_visits=legacy,legacy_second_rounds=sum(e[1]=='second_round' for e in audit),
        delivery_tasks=tasks,delivery_without_new_fact_count=duplicates if tasks else None,
        target0_visits=sum(e[2]==0 for e in legacy),
        trips_to0_started_after_leader_clear=sum(e[2]==0 and clear_step is not None and e[0]>=clear_step for e in legacy+tasks),
        messenger_active_intervals=intervals,messenger_active_steps_after_leader_clear=post_clear,
        messenger_total_recorded_distance_pixels=distance,messenger_audit=audit,
        messenger_final_receiver_empty=messenger.get('messenger_receiver_empty'),
        messenger_final_attempted_empty=messenger.get('messenger_attempted_empty'),
        deadline_events={d['drone']:d['walltime_submission'] for d in score['drone_details']})

if __name__=='__main__':
    build=read(root/'CANDIDATE_BUILD.json')
    assert digest(root/'candidate_snapshot.zip')==build['candidate_zip_sha256']=='411365532021c8bf0539aa4d97f7e61dcd3145631ada4e1ea0c363f013784ce5'
    assert digest(code/'candidate.zip')==build['candidate_zip_sha256']
    assert all(digest(code/'candidate'/n)==sha for n,sha in build['candidate_files'].items())
    obs=read(root/'OBSERVATION_BINDING.json')
    assert digest(root/'stage_run.py')==obs['observer_sha256']
    assert digest(old/'stage_run.py')==obs['original_observer_sha256']
    assert (root/'stage_run.py').read_text(encoding='utf-8').split('[arena] = arenas')[0]==(old/'stage_run.py').read_text(encoding='utf-8').split('[arena] = arenas')[0]
    names=['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','placement_events.jsonl','run.log','dispatch.log','wall_geometry.npz']
    download([f'{remote}/{n}' for n in names],received)
    end=read(received/'FINISH.json');official=PurePosixPath(end['result_dir'])
    assert official.is_relative_to(PurePosixPath(remote)/'official_sdk/results_swarm_rescue')
    for name in end['files']:
        p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts
        download([str(official/p)],received/'official'/p.parent)
    log=(received/'dispatch.log').read_text(encoding='utf-8').splitlines()
    assert sum(x=='START Map08 demand_early24 seed615' for x in log)==1
    assert sum(x=='COMPLETE Map08 demand_early24 seed615' for x in log)==1
    old_binding=read(old/'baseline_binding.json')
    assert digest(old/'delivery/RESULTS.json')==read(old/'REMOTE_VERIFIED.json')['results_sha256']
    rounds=dict(original=summarize(old/'received/Map08_baseline',old_binding['candidate_zip_sha256'],old_binding['candidate']),
                candidate=summarize(received,build['candidate_zip_sha256'],build['candidate_files']))
    history=read(old/'delivery/RESULTS.json')['scores']['Map08']['baseline']
    assert rounds['original']['map_score']==history['map_score'] and rounds['original']['partial_score_out_of_80']==history['partial_score_out_of_80']
    fields=['map_score','partial_score_out_of_80','wall_score','time_score','exploration_percent','missed_wall_pixels','charged_misdraw_pixels','submission_step','placed','total_health_lost','elapsed_walltime_seconds']
    delta={k:rounds['candidate'][k]-rounds['original'][k] for k in fields}
    result=dict(seed=615,map_name='Map08',new_red_rounds=1,historical_red_rounds=1,blue_rounds=0,
                controller_source_changed_in_this_task=False,build=build,observation_binding=obs,
                runs=rounds,candidate_minus_original=delta,
                official_bomb_layouts_identical=rounds['original']['official_bomb_layout']==rounds['candidate']['official_bomb_layout'],
                official_bomb_positions_identical=[(b['x'],b['y']) for b in rounds['original']['official_bomb_layout']]==[(b['x'],b['y']) for b in rounds['candidate']['official_bomb_layout']],
                notes=['原版无载荷字段，不能把所有走访都追认成无效；分别统计走访、第二轮及0号已清零后的赴0行程。',
                       '清零后仍处于信使阶段的步数是行为统计，不等于这些步数全部无价值。',
                       '未重复启动原版，没有其他地图的新仿真；墙钟为历史原版与本次候选各一局。'])
    delivery.mkdir(exist_ok=True)
    (delivery/'RESULTS.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    with ZipFile(delivery/'RUN_EVIDENCE.zip','w',compression=ZIP_DEFLATED) as z:
        for folder,prefix in [(received,'new_candidate'),(old/'received/Map08_baseline','historical_original')]:
            for p in sorted(folder.rglob('*')):
                if p.is_file():z.write(p,prefix+'/'+p.relative_to(folder).as_posix())
        for n in ['stage_run.py','run_once.sh','collect.py','report.py','CANDIDATE_BUILD.json','UNIT_VALIDATION.json','OBSERVATION_BINDING.json','DECLARED_SOURCE.json','PATCH_BINDING.json','OFFLINE_CHECK.json','place_map08.yml','matched_spawns.json','EXPECTED_ZONES.json']:
            z.write(root/n,n)
    with ZipFile(delivery/'RUN_EVIDENCE.zip') as z:assert z.testzip() is None
    (delivery/'CHECKSUMS_SHA256.json').write_text(json.dumps({p.name:digest(p) for p in delivery.iterdir() if p.name!='CHECKSUMS_SHA256.json'},indent=2)+'\n')
    print(json.dumps({a:{k:r[k] for k in fields+['leader_team_clear_step','early_submission_event','delivery_tasks','legacy_target_visits','messenger_active_steps_after_leader_clear']} for a,r in rounds.items()},indent=2))
    print(json.dumps(delta,indent=2))
