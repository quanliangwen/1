from pathlib import Path
r=Path(__file__).resolve().parent
p=r.parent/'team615_finish_gate_maps_20261121'
s=(p/'collect.py').read_text(encoding='utf-8')
s=s.replace('finish_gate_18024','near_tie_slots').replace('batch_final','finish_gate')
s=s.replace("r.parent/'team615_partial_selection_batch1_20261121'/name/'received'", "r.parent/'team615_finish_gate_maps_20261121'/name/'received'")
compile(s,'collect.py','exec');(r/'collect.py').write_text(s,encoding='utf-8')
s=(p/'audit_history.py').read_text(encoding='utf-8').replace('batch_final','finish_gate')
s=s.replace("finish_gate=previous/name/'received'", "finish_gate=r.parent/'team615_finish_gate_maps_20261121'/name/'received'")
compile(s,'audit_history.py','exec');(r/'audit_history.py').write_text(s,encoding='utf-8')
for n in ['offline_map_score.py','augment_offline.py','SDK_SELECTION_EVIDENCE.json']:
    (r/n).write_bytes((p/n).read_bytes())
print('Prepared collection for original, three-map, 180+24 and frozen near-tie/slot candidate.')
