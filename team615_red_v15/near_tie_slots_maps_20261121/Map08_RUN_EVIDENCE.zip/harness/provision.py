from pathlib import Path
from hashlib import sha256
import ast,json,shutil,subprocess
r=Path(__file__).resolve().parent
candidate=r.parent/'team615_neartie_slots_20261121'
prior=r.parent/'team615_finish_gate_maps_20261121'
source=r.parent/'team615_partial_selection_batch1_20261121'
remote='/home/quanliangwen/isolated_test/team615_neartie_maps_wullIc'
host='quanliangwen@10.112.162.60'
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
b=read(candidate/'BUILD.json');v=read(candidate/'VALIDATION.json');c=read(candidate/'counterexamples.json')
assert b['candidate_zip_sha256']==v['candidate_zip_sha256']==c['archive_sha256']==h(candidate/'candidate_snapshot.zip')
assert c['scenario_groups']==89 and c['status']==v['status']=='PASS'
assert h(candidate/'baseline_snapshot.zip')==b['baseline_zip_sha256']==h(prior/'candidate_snapshot.zip')
(r/'SERVER_STAGE.txt').write_text(remote+'\n')
for n in ['candidate_snapshot.zip','baseline_snapshot.zip','BUILD.json','VALIDATION.json','counterexamples.json']:
    shutil.copyfile(candidate/n,r/n)
for n in ['matched_spawns.json','EXPECTED_ZONES.json']:
    shutil.copyfile(prior/n,r/n)
patch=dict(baseline_commit='a19feea71b65720ed79527f9095e444418799a98',baseline_zip_sha256=b['baseline_zip_sha256'],
    candidate_zip_sha256=b['candidate_zip_sha256'],baseline=b['original_files'],candidate=b['candidate_files'],changed=b['changed_existing_files'])
(r/'PATCH_BINDING.json').write_text(json.dumps(patch,indent=2)+'\n')
(r/'DECLARED_SOURCE.json').write_text(json.dumps(b['candidate_files'],indent=2)+'\n')
(r/'OFFLINE_CHECK.json').write_text(json.dumps(dict(simulation_steps=0,unit_groups=89,validation_sha256=h(r/'VALIDATION.json')))+'\n')
stage=(prior/'stage_run.py').read_text(encoding='utf-8')
# Only post-score state export changes; all in-match observer functions stay identical.
anchor="             group_phase=d.group_exchange.phase,"
addition="""             group_ordinary_selection=d.group_exchange.ordinary_selection,
             group_finish_refresh_step=d.group_exchange.finish_refresh_step,
             group_end_slot=d.group_exchange.submission_slot(d,int(d.elapsed_timestep)),
             original_first_ready=d.first_ready_to_submit_step,
             original_map_quality=d.map_quality,
             original_map_bids=d.map_bids,
             original_same_step_bid_comparisons=d.last_eligible_bid_comparison,
             original_own_sent_bids=list(d.own_sent_bids),
             original_priority_audit=d.submission_priority_audit,
             original_wait_started=d.submission_wait_started,
             original_wait_for=d.submission_wait_for,
"""
assert stage.count(anchor)==1
stage=stage.replace(anchor,addition+anchor)
def observer(text):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(text).body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
assert observer(stage)==observer((prior/'stage_run.py').read_text(encoding='utf-8'))
(r/'stage_run.py').write_text(stage,encoding='utf-8')
for name in ['Map08','Map09']:
    folder=r/name;folder.mkdir(exist_ok=False)
    for n in ['stage_run.py','candidate_snapshot.zip','baseline_snapshot.zip','DECLARED_SOURCE.json','PATCH_BINDING.json',
              'BUILD.json','VALIDATION.json','counterexamples.json','matched_spawns.json','EXPECTED_ZONES.json','OFFLINE_CHECK.json']:
        shutil.copyfile(r/n,folder/n)
    shutil.copyfile(prior/name/'place_map09.yml',folder/'place_map09.yml')
    run=(prior/name/'run_once.sh').read_text().replace('finish_gate_18024','near_tie_slots')
    (folder/'run_once.sh').write_text(run,encoding='utf-8',newline='\n')
    (folder/'OBSERVATION_BINDING.json').write_text(json.dumps(dict(observer_sha256=h(folder/'stage_run.py'),
        in_match_observer_functions_ast_identical_to_previous=True,extra_fields_only_exported_after_scoring=True,
        map=name,seed=615,controller_frozen_sha256=b['candidate_zip_sha256'],new_red_rounds_authorized=1),indent=2)+'\n')
    subprocess.run(['ssh','-o','BatchMode=yes',host,f'mkdir {remote}/{name}'],check=True)
    subprocess.run(['scp','-q','-o','BatchMode=yes',*[str(p) for p in folder.iterdir()],f'{host}:{remote}/{name}/'],check=True)
shutil.copyfile(prior/'dispatch.sh',r/'dispatch.sh')
subprocess.run(['scp','-q','-o','BatchMode=yes',str(r/'dispatch.sh'),f'{host}:{remote}/'],check=True)
command=f'nohup bash {remote}/dispatch.sh {remote} > {remote}/queue.log 2>&1 < /dev/null & echo QUEUED'
p=subprocess.run(['ssh','-o','BatchMode=yes',host,command],capture_output=True,check=True,timeout=30)
print(p.stdout.decode());print(b['candidate_zip_sha256'])
