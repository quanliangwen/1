from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json
import numpy as np
r=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
def old_paths(name):
    return dict(original=r.parent/'team615_messenger_batch1_20261121/received'/f'{name}_baseline',
        current=(r.parent/'team615_group_exchange_map06_map08_20261121/Map08/received' if name=='Map08' else r.parent/'team615_group_exchange_map09_20261121/received'),
        finish_gate=r.parent/'team615_finish_gate_maps_20261121'/name/'received')
def protocol(path):
    s=read(path/'OFFICIAL_SCORE.json');per_step=defaultdict(list)
    for row in s['submissions']:per_step[row['step']].append(row['drone'])
    ordinary=[];hard=[]
    for d in s['drone_details']:
        if d.get('walltime_submission'):hard.append(dict(drone=d['drone'],**d['walltime_submission']))
        for row in d.get('group_audit',[]):
            if row[1] in ('submitted','soft_cutoff_submit'):ordinary.append(dict(drone=d['drone'],step=row[0],event=row[1]))
    one=s['drone_details'][1]
    return dict(selected=s['selected_submission'],submissions=s['submissions'],
        simultaneous={str(step):ids for step,ids in per_step.items() if len(ids)>1},
        group_ordinary_submissions=ordinary,hard_fallbacks=hard,
        one_best=one.get('group_best_metadata'),one_refresh=one.get('group_finish_refresh_step'),
        one_ordinary_mode=one.get('group_ordinary_selection'),
        one_selected_at_final_refresh=next((e for e in one.get('group_candidate_audit',[]) if e[1]=='map_selected' and e[0]==one.get('group_finish_refresh_step')),None))
out={}
for name in ['Map08','Map09']:
    if not (r/name/'RESULTS.json').exists():continue
    result=read(r/name/'RESULTS.json');s=read(r/name/'received/OFFICIAL_SCORE.json')
    data=dict(arms=result['arms'],candidate_minus=result['candidate_minus'],recorded_prefix=result['recorded_prefix'],
        protocol={**{a:protocol(p) for a,p in old_paths(name).items()},'candidate':protocol(r/name/'received')})
    details={}
    for d in s['drone_details']:
        details[str(d['drone'])]={k:d[k] for k in d if k.startswith('original_') or k in [
            'group_ordinary_selection','group_finish_refresh_step','group_end_slot','group_best_metadata','group_score_table','group_choice',
            'final_inventory_records','final_source_versions','last_confirmation','health','walltime_submission']}
        details[str(d['drone'])]['submission_events']=[e for e in d['group_audit'] if e[1] in ['choice_received','choice_proposed','choice_lease_expired','submitted','soft_cutoff_submit','finish_candidate_refreshed']]
    data['details']=details
    meta=read(r/name/'received/GROUP_DATASET.json');array=np.load(r/name/'received/group_dataset.npz');hashes={}
    for owner,info in meta.items():
        for slot,entry in info['images'].items():
            image=np.unpackbits(array[f'd{owner}_image{slot}'])[:info['height']*info['width']].reshape(info['height'],info['width']).astype(np.uint8)
            hashes[f'{owner}:{slot}']=dict(version=entry['version'],sha256=sha256(image.tobytes()).hexdigest())
    data['bitmap_hashes']=hashes
    if name=='Map08':
        one_new=hashes.get('1:5')
        data['one_current_equals_previous_three_map_submission']=bool(one_new and one_new['sha256']==result['arms']['current']['selected_submission']['image_sha256'])
    data['selected_image_equals_18024']=s['selected_image_sha256']==result['arms']['finish_gate']['selected_submission']['image_sha256']
    data['offline_map_scores']=result.get('offline_map_scores')
    out[name]=data
(r/'ANALYSIS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({name:dict(arms={a:{k:v[k] for k in ['submission_step','partial_score_out_of_80','map_score','missed_wall_pixels','charged_misdraw_pixels','exploration_percent','placed','total_health_lost','elapsed_walltime_seconds']} for a,v in data['arms'].items()},
    protocol={a:{k:v[k] for k in ['selected','simultaneous','one_best','one_refresh','one_ordinary_mode']} for a,v in data['protocol'].items()},
    bids={i:{k:v[k] for k in ['original_map_quality','original_priority_audit','original_wait_started','original_wait_for','group_end_slot']} for i,v in data['details'].items()}) for name,data in out.items()},indent=2))
