from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json,shutil
r=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
maps={name:read(r/name/'RESULTS.json') for name in ['Map08','Map09']}
analysis=read(r/'ANALYSIS.json');b=read(r/'BUILD.json');v=read(r/'VALIDATION.json');tests=read(r/'counterexamples.json')
assert b['candidate_zip_sha256']==v['candidate_zip_sha256']==tests['archive_sha256']==h(r/'candidate_snapshot.zip')
assert tests['scenario_groups']==89 and read(r/'HISTORY_AUDIT.json')['status']=='PASS'
for name,result in maps.items():
    assert result['new_red_rounds']==1 and result['historical_red_rounds']==3
    assert result['candidate_zip_sha256']==b['candidate_zip_sha256']
    assert result['post_run_source_check']['status']==result['personal_original_integrity']['status']=='PASS'
    assert result['offline_map_scores']['selected_submission_reproduced']
    for delta in result['candidate_minus'].values():
        assert abs(.5*delta['map_score']+.2*delta['wall_score']+.1*delta['time_score']-delta['partial_score_out_of_80'])<1e-8
config=dict(seed=615,maps=['Map08','Map09'],new_red_rounds=2,historical_comparison_red_rounds=6,blue_rounds=0,other_maps_run=0,
    serial=True,sdk_commit='6557940dc18549ffc7a945db887da5b05b7ed2f1',drones=5,bombs_per_drone=2,timestep_limit=5400,
    walltime_limit=180,zones=['NO_COM_ZONE','NO_GPS_ZONE'],candidate_zip_sha256=b['candidate_zip_sha256'],
    baseline_zip_sha256=b['baseline_zip_sha256'],candidate_modified_during_this_task=False,
    in_match_observer_functions_ast_identical_to_previous_batch=True,extra_bid_state_export_only_after_scoring=True,
    source_frozen_and_rechecked_after_both_matches=True)
result=dict(status='COMPLETE',configuration=config,maps=maps,protocol_and_bitmap_analysis=analysis,
    history_audit=read(r/'HISTORY_AUDIT.json'),sdk_selection_evidence=read(r/'SDK_SELECTION_EVIDENCE.json'),
    limitations=['Only two new candidate rounds, one per requested map. Three comparator versions reuse source-verified same-seed historical runs.',
        'Red-side subtotal out of 80 only; blue-side 20 untested.',
        'Wall-clock and wall-budget-dependent control vary with runtime load. Earlier wall-limited submission steps do not prove computing speedup.',
        'Ordinary slot mutual exclusion intentionally does not restrict hard deadline fallbacks.',
        'Official offline scoring uses saved images after the match, never controller-accessible truth.',
        'One seed does not establish stable score improvement across maps/seeds.'])
d=r/'delivery';d.mkdir(exist_ok=True)
(d/'RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
arms=['original','current','finish_gate','candidate']
labels=dict(original='潜力1.1原版',current='上一版三图候选',finish_gate='180＋24候选',candidate='近分＋6步时隙候选')
metrics=[('红队小计 / 80','partial_score_out_of_80',4),('地图分 / 100','map_score',4),('墙覆盖分 / 100','wall_score',4),
    ('交图步数','submission_step',0),('漏墙像素','missed_wall_pixels',0),('扣分误画像素','charged_misdraw_pixels',0),
    ('探索率 / %','exploration_percent',4),('实投数 / 10','placed',0),('总掉血 / 初始125','total_health_lost',0),
    ('墙钟 / 秒','elapsed_walltime_seconds',3)]
lines=['# 0.003近分选新图＋原竞价让行＋6步时间槽：Map08、Map09，种子615','',
    '本轮只对冻结候选各跑一次Map08、Map09，共2局红队；未改算法、未跑其他地图。原版、上一版三图候选和180＋24候选使用经过源码、SDK、出生位置、禁区配置和原始产物SHA256核验的同种子历史结果。','',
    '分数为红队小计（满分80），未测蓝队20分。漏墙=官方wall_pixels减wall_hits；误画采用实际扣分的charged_pixels。墙钟取官方评分的elapsed_walltime。','',
    '## 源码冻结与观察范围','',
    f"本次候选SHA256：`{b['candidate_zip_sha256']}`；180＋24基线SHA256：`{b['baseline_zip_sha256']}`。",'',
    '上一版三图候选SHA256：`641685d7bd460f6241abb4e2c0f02527d7324a37d78f6492401d66a4b6a63cda`。原版按原始56项源码清单逐项核验。',
    '', '当前候选与上一轮89组反例通过的源码ZIP逐字节一致，运行前后56个成员哈希不变。SDK6557940dc18549ffc7a945db887da5b05b7ed2f1，5机、每机2枚、5400步、180秒，两禁区开启。比赛中观察回调与前次AST一致；只在官方评分后额外保存原有竞价、让行与普通选图状态，不参与控制或比赛墙钟。原89组反例和静态回执随包保留，本轮没有修改或重跑这些测试。','']
for name,data in maps.items():
    p=analysis[name]['protocol']
    lines += [f'## {name}','','| 指标 | '+' | '.join(labels[a] for a in arms)+' |','|---|---:|---:|---:|---:|']
    for label,key,prec in metrics:
        lines.append('| '+label+' | '+' | '.join(f"{data['arms'][a][key]:.{prec}f}" for a in arms)+' |')
    lines += ['| SDK实际采用交图机 | '+' | '.join(str(data['arms'][a]['selected_submission']['drone'])+'号' for a in arms)+' |',
        '| 同帧提交记录 | '+' | '.join('; '.join(f"{step}步：{','.join(map(str,ids))}号" for step,ids in p[a]['simultaneous'].items()) or '无' for a in arms)+' |','',
        '本次相对三个对照的差值（候选减对照）：','',
        '| 对照 | 小计Δ | 地图分Δ | 交图步数Δ | 漏墙Δ | 误画Δ | 墙钟Δ秒 |','|---|---:|---:|---:|---:|---:|---:|']
    for a in arms[:-1]:
        delta=data['candidate_minus'][a]
        lines.append(f"| {labels[a]} | {delta['partial_score_out_of_80']:+.4f} | {delta['map_score']:+.4f} | {delta['submission_step']:+.0f} | {delta['missed_wall_pixels']:+.0f} | {delta['charged_misdraw_pixels']:+.0f} | {delta['elapsed_walltime_seconds']:+.3f} |")
    lines += ['', '本次候选的选图、提交与原竞价记录：','',
        '| 无人机 | 最终重比步 | 当前最佳槽/版本 | 普通模式 | 分组交图步 | 硬兜底步 | 优先让行记录 |','|---|---:|---|---|---|---|---|']
    for owner,info in analysis[name]['details'].items():
        best=info['group_best_metadata'];selected='—' if best is None else f"{best['owner']}/{best['version']}"
        submit=[e[0] for e in info['submission_events'] if e[1] in ('submitted','soft_cutoff_submit')]
        hard=info['walltime_submission']
        lines.append(f"| {owner}号 | {info['group_finish_refresh_step']} | {selected} | {info['group_ordinary_selection']} | {submit} | {hard['step'] if hard else '—'} | {json.dumps(info['original_priority_audit'],ensure_ascii=False)} |")
    one=p['candidate']['one_best']
    lines += ['',f"1号结束时最佳元数据：`{json.dumps(one,ensure_ascii=False)}`。",'',
        f"1号最终重比步：{p['candidate']['one_refresh']}；进入普通选图模式：{p['candidate']['one_ordinary_mode']}。",'',
        f"个人原图完整性：{data['personal_original_integrity']['images_verified']}份持有记录PASS；实际提交图与所选缓存一致，赛后56项源码核验PASS。",'']
    off=data['offline_map_scores']
    lines += ['赛后仅对保存位图复算官方地图分，无新物理步：','',
        '| 持有者 | 候选槽 | 位图版本 | 官方地图分 |','|---|---:|---:|---:|']
    for row in off['candidates']:
        if row['holder']==1 or row['holder']==data['arms']['candidate']['selected_submission']['drone']:
            lines.append(f"| {row['holder']}号 | {row['slot']} | {row['version']} | {row['map_score']:.4f} |")
    lines += ['',f"实际提交地图分{off['actual_map_score']:.4f}已复现；保存候选最高{off['best_saved_candidate']['map_score']:.4f}（{off['best_saved_candidate']['holder']}号持有、槽{off['best_saved_candidate']['slot']}）。这不是比赛中可直接取得的全局真值。",'']
lines += ['## 结果判断','',(r/'FINDINGS.md').read_text(encoding='utf-8').strip(),'',
    '## 文件与限制','',
    'CANDIDATE_SOURCE.zip为上轮冻结研究候选的原字节快照，未上传官网、不是新正式参赛发布包。两份RUN_EVIDENCE.zip保留比赛评分、轨迹、位图、证据快照、三版历史对照证据、源码/SDK绑定与运行采集脚本。ANALYSIS.json额外记录同帧提交、1号选图、最终竞价状态与位图哈希；HARNESS.zip包含所有本轮采集分析脚本。','',
    '每图仅1局，三个对照是历史同种子运行；墙钟负载差异会改变墙钟兜底时的步数，不能直接称为算法加速。普通时隙只限制普通出口；硬兜底允许多机同帧提交，以保留既有最后交图能力。']
(d/'README.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
for name in maps:
    shutil.copyfile(r/name/'RESULTS.json',d/f'{name}_RESULTS.json');shutil.copyfile(r/name/'RUN_EVIDENCE.zip',d/f'{name}_RUN_EVIDENCE.zip')
for n in ['BUILD.json','VALIDATION.json','counterexamples.json','HISTORY_AUDIT.json','ANALYSIS.json','SDK_SELECTION_EVIDENCE.json']:
    shutil.copyfile(r/n,d/n)
shutil.copyfile(r/'candidate_snapshot.zip',d/'CANDIDATE_SOURCE.zip')
with ZipFile(d/'HARNESS.zip','w',ZIP_DEFLATED) as z:
    for n in ['provision.py','prepare_collect.py','audit_history.py','stage_run.py','collect.py','analyze.py','report.py',
        'offline_map_score.py','augment_offline.py','dispatch.sh','SERVER_STAGE.txt','FINDINGS.md']:
        z.write(r/n,n)
print(json.dumps({name:dict(arms={a:{k:v[k] for k in ['partial_score_out_of_80','map_score','submission_step']} for a,v in data['arms'].items()},deltas=data['candidate_minus']) for name,data in maps.items()},indent=2))
