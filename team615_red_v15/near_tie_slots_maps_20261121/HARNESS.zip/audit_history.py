from pathlib import Path
from hashlib import sha256
import json
r=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
previous=r.parent/'team615_partial_selection_batch1_20261121'
expected=dict(finish_gate=read(r/'BUILD.json')['original_files'],
    current=read(previous/'BUILD.json')['original_files'],
    original=read(r.parent/'team615_group_exchange_map09_20261121/BUILD.json')['original_files'])
results={}
for name in ['Map08','Map09']:
    paths=dict(original=r.parent/'team615_messenger_batch1_20261121/received'/f'{name}_baseline',
        current=(r.parent/'team615_group_exchange_map06_map08_20261121/Map08/received' if name=='Map08' else r.parent/'team615_group_exchange_map09_20261121/received'),
        finish_gate=r.parent/'team615_finish_gate_maps_20261121'/name/'received')
    results[name]={}
    for arm,path in paths.items():
        s=read(path/'START.json');f=read(path/'FINISH.json');v=read(path/'OFFICIAL_SCORE.json')
        assert s['solutions_sha256']==expected[arm]
        assert [s[k] for k in ['seed','sdk','map_name','drones','bombs_per_drone','timestep_limit','walltime_limit','competition_mode']]==[
            615,'6557940dc18549ffc7a945db887da5b05b7ed2f1',name,5,2,5400,180,True]
        assert s['spawn']==read(r/'matched_spawns.json')[name] and s['zones']==read(r/'EXPECTED_ZONES.json')[name]
        assert f['status']=='COMPLETE' and f['completed_red_rounds']==1
        for n,d in f['files'].items():assert h(path/'official'/n)==d
        assert h(path/'placement_events.jsonl')==v['placement_events_sha256']
        results[name][arm]=dict(source_checked=True,result_artifacts_checked=len(f['files']),
            step=v['steps'],score=v['partial'],map_score=v['map_score'],walltime=v['elapsed_walltime'])
(r/'HISTORY_AUDIT.json').write_text(json.dumps(dict(status='PASS',maps=results),indent=2)+'\n')
print(json.dumps(results,indent=2))
