set -euo pipefail
stage="$1"
shared=/home/junhao/quan/parallel_test_solver/match
sealed="$shared/solver_study/framework_screen_20261016/best87_independent_20261025/P407_P398_semifinal_three_maps_20261110"
sdk_python="$shared/.venv/bin/python"
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
mkdir "$stage/static"
cp "$stage/candidate_snapshot.zip" "$stage/static/team615_semifinal.zip"
"$sdk_python" "$sealed/official_sdk/scripts/check_submission.py" "$stage/static/team615_semifinal.zip" 2>&1 | tee "$stage/static.log"
exec 9<"$shared/solver_study/serial_evaluation.lock"
echo "Waiting for shared simulation slot"
flock -x -w 1200 9
echo "Acquired shared simulation slot"
export DISPLAY=:7100 LIBGL_ALWAYS_SOFTWARE=1 LP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MPLBACKEND=Agg ALSOFT_DRIVERS=null
for map in Map07 Map08; do
    run="$stage/$map"
    echo "START $map"
    mkdir "$run"
    cp "$stage/stage_run.py" "$stage/matched_spawns.json" "$stage/baseline_snapshot.zip" "$stage/candidate_snapshot.zip" "$stage/DECLARED_SOURCE.json" "$stage/PATCH_BINDING.json" "$stage/OFFLINE_CHECK.json" "$run/"
    cp "$stage/$map.yml" "$run/place_map08.yml"
    mkdir "$run/solution"
    "$sdk_python" -m zipfile -e "$run/candidate_snapshot.zip" "$run/solution"
    (cd "$run"; "$sdk_python" -B stage_run.py "$sealed" "$run/solution" "$map" 2>&1 | tee run.log)
    echo "COMPLETE $map"
done

