from pathlib import Path,PurePosixPath
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json,math,subprocess
import numpy as np

root=Path(__file__).resolve().parent
old=root.parent/'team615_messenger_batch1_20261121'
code=root.parent/'team615_return60_firstsplit_20261121'
remote='/home/quanliangwen/isolated_test/team615_return60_map09_5n269I'
host='quanliangwen@10.112.162.60'
received=root/'received';dest=root/'delivery'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()

def download(paths,folder):
    folder.mkdir(parents=True,exist_ok=True)
    subprocess.run(['scp','-q','-o','BatchMode=yes',*(f'{host}:{p}' for p in paths),str(folder)],check=True)

def summarize(folder,expected_sha,expected_files):
    start,end,source,score=(read(folder/f'{n}.json') for n in ['START','FINISH','SOURCE_MATCH','OFFICIAL_SCORE'])
    assert [start[k] for k in ['seed','sdk','sdk_archive_sha256','map_name','drones','bombs_per_drone','timestep_limit','walltime_limit','competition_mode']]==[
        615,'6557940dc18549ffc7a945db887da5b05b7ed2f1','9155bc4cdf5e0813cd328d3a56c3b73633ba351c3859e694762ed41376fc6860','Map09',5,2,5400,180,True]
    assert start['spawn']==read(root/'matched_spawns.json')['Map09']
    assert start['zones']==read(root/'EXPECTED_ZONES.json')['Map09']
    assert source['candidate_zip_sha256']==expected_sha
    assert start['solutions_sha256']==source['candidate']==expected_files
    assert [end[k] for k in ['status','completed_red_rounds','blue_rounds','layout_evaluations']]==['COMPLETE',1,0,0]
    assert digest(folder/'placement_events.jsonl')==score['placement_events_sha256']
    assert digest(folder/'wall_geometry.npz')==score['wall_geometry_sha256']
    for n,h in end['files'].items():assert digest(folder/'official'/n)==h
    assert math.isclose(score['partial'],.5*score['map_score']+.2*score['coverage']+.1*score['time_score'],abs_tol=1e-8)
    layout=read(next((folder/'official').glob('*bombs.json')))['bombs']
    assert len(layout)==score['placed']
    selected=score['selected_submission']
    if selected and selected.get('drone') is not None:assert selected['image_sha256']==score['selected_image_sha256']
    leader=next(d for d in score['drone_details'] if d['drone']==0)
    first_zero={0:leader['last_confirmation']} if leader['inventory']==0 else {}
    for e in leader['team_exchange_audit']:
        if e[0]=='stock' and e[4]==0:first_zero.setdefault(e[3],e[1])
    b=score['map_breakdown']
    return dict(source_zip_sha256=expected_sha,map_score=score['map_score'],partial_score_out_of_80=score['partial'],
        wall_score=score['coverage'],time_score=score['time_score'],exploration_percent=score['trajectory'],
        missed_wall_pixels=b['wall_pixels']-b['wall_hits'],charged_misdraw_pixels=b['charged_pixels'],map_breakdown=b,
        submission_step=score['steps'],selected_submission=selected,placed=score['placed'],official_bomb_layout=layout,
        total_health_lost=sum(25-d['health'] for d in score['drone_details']),final_health={d['drone']:d['health'] for d in score['drone_details']},
        elapsed_walltime_seconds=score['elapsed_walltime'],leader_first_confirmed_empty_steps=first_zero,
        leader_team_clear_step=max(first_zero.values()) if len(first_zero)==5 else None,
        deadline_events={d['drone']:d['walltime_submission'] for d in score['drone_details']},
        return_states={d['drone']:{k:v for k,v in d.items() if k.startswith('return_') or k=='final_estimated_pose'} for d in score['drone_details']})

b=read(root/'CANDIDATE_BUILD.json')
assert digest(root/'candidate_snapshot.zip')==digest(code/'candidate.zip')==b['candidate_zip_sha256']=='08bba29b1e3dbf1de3f9d83928b0b58241f354284ef733202b9cc161c21c9f66'
assert all(digest(code/'candidate'/n)==h for n,h in b['candidate_files'].items())
assert read(root/'UNIT_VALIDATION.json')['status']=='PASS'
ob=read(root/'OBSERVATION_BINDING.json')
assert digest(root/'stage_run.py')==ob['observer_sha256'] and digest(old/'stage_run.py')==ob['original_observer_sha256']
names=['START.json','FINISH.json','SOURCE_MATCH.json','OFFICIAL_SCORE.json','placement_events.jsonl','run.log','dispatch.log','wall_geometry.npz']
download([f'{remote}/{n}' for n in names],received)
end=read(received/'FINISH.json');official=PurePosixPath(end['result_dir'])
assert official.is_relative_to(PurePosixPath(remote)/'official_sdk/results_swarm_rescue')
for n in end['files']:
    p=PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts
    download([str(official/p)],received/'official'/p.parent)
dispatch=(received/'dispatch.log').read_text(encoding='utf-8').splitlines()
assert sum(x=='START Map09 return60 seed615' for x in dispatch)==1
assert sum(x=='COMPLETE Map09 return60 seed615' for x in dispatch)==1
assert digest(old/'delivery/RESULTS.json')==read(old/'REMOTE_VERIFIED.json')['results_sha256']
runs=dict(original=summarize(old/'received/Map09_baseline',b['baseline_zip_sha256'],b['original_files']),
          candidate=summarize(received,b['candidate_zip_sha256'],b['candidate_files']))
history=read(old/'delivery/RESULTS.json')['scores']['Map09']['baseline']
assert runs['original']['map_score']==history['map_score'] and runs['original']['partial_score_out_of_80']==history['partial_score_out_of_80']
fields=['map_score','partial_score_out_of_80','wall_score','time_score','exploration_percent','missed_wall_pixels','charged_misdraw_pixels','submission_step','placed','total_health_lost','elapsed_walltime_seconds']
delta={k:runs['candidate'][k]-runs['original'][k] for k in fields}
parts=dict(map=.5*delta['map_score'],wall=.2*delta['wall_score'],time=.1*delta['time_score'])
assert abs(sum(parts.values())-delta['partial_score_out_of_80'])<1e-8

prefix={}
old_z=np.load(next((old/'received/Map09_baseline/official/recordings').glob('*.npz')))
new_z=np.load(next((received/'official/recordings').glob('*.npz')))
for key in ['drone_states','bomb_states']:
    a,c=old_z[key],new_z[key];n=min(len(a),len(c));equal=np.ones(n,bool)
    for field in a.dtype.names:
        eq=a[field][:n]==c[field][:n];equal &= eq.reshape(n,-1).all(1)
    where=np.flatnonzero(~equal)
    prefix[key]=dict(original_frames=len(a),candidate_frames=len(c),first_different_frame=None if not len(where) else int(where[0]),
                     before_threshold_frames=min(n,3237),before_threshold_equal=bool(equal[:min(n,3237)].all()))
result=dict(status='COMPLETE',seed=615,map='Map09',new_red_rounds=1,historical_original_rounds=1,blue_rounds=0,
    controller_source_changed_in_this_task=False,candidate_build=b,observation_binding=ob,runs=runs,
    candidate_minus_original=delta,score_contribution_changes=parts,recorded_state_prefix=prefix,
    notes=['Only one new candidate Map09 match; original is a verified existing same-seed run.',
           'Extra return audit was read only after the match ended; no in-match observer behavior changed except config filename.',
           'Red-side80 points only; blue-side20-point term unmeasured. Wall-clock comparisons are load-sensitive.'])
dest.mkdir(exist_ok=False)
(dest/'RESULTS.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
with ZipFile(dest/'RUN_EVIDENCE.zip','w',compression=ZIP_DEFLATED) as z:
    for folder,label in [(received,'new_candidate'),(old/'received/Map09_baseline','historical_original')]:
        for p in sorted(folder.rglob('*')):
            if p.is_file():z.write(p,label+'/'+p.relative_to(folder).as_posix())
    for n in ['stage_run.py','run_once.sh','collect.py','CANDIDATE_BUILD.json','UNIT_VALIDATION.json','OBSERVATION_BINDING.json','DECLARED_SOURCE.json','PATCH_BINDING.json','OFFLINE_CHECK.json','place_map09.yml','matched_spawns.json','EXPECTED_ZONES.json']:
        z.write(root/n,n)
with ZipFile(dest/'RUN_EVIDENCE.zip') as z:assert z.testzip() is None
print(json.dumps(dict(metrics={arm:{k:v[k] for k in fields} for arm,v in runs.items()},delta=delta,prefix=prefix,
    return_summary={i:{k:v for k,v in x.items() if k not in ['return_route','return_trail']} for i,x in runs['candidate']['return_states'].items()}),indent=2))
