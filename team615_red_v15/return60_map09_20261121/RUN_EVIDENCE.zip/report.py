from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json,numpy as np

root=Path(__file__).resolve().parent
dest=root/'delivery'
r=json.loads((dest/'RESULTS.json').read_text(encoding='utf-8'))
o,c=r['runs']['original'],r['runs']['candidate'];d=r['candidate_minus_original']
s=json.loads((root/'received/OFFICIAL_SCORE.json').read_bytes())
leader=next(v for v in s['drone_details'] if v['drone']==0)
state=c['return_states']['0']
assert state['return_anchor'] is None and not state['return_receipts'] and state['return_complete_step'] is None
assert not any(e[1]=='submitted' for x in c['return_states'].values() for e in x['return_audit'])
assert c['deadline_events']['0']['fallback']=='walltime' and o['deadline_events']['0']['fallback']=='walltime'
z=np.load(next((root/'received/official/recordings').glob('*.npz')))
t=z['drone_states'];a=np.stack((t['x'],t['y']),axis=-1).astype(float)[:3237]
dep=np.linalg.norm(a[:,0]-a[0,0],axis=1)
span=np.linalg.norm(a[:,:,None,:]-a[:,None,:,:],axis=-1).max((1,2))
reach=np.linalg.norm(a-a[:,0,None,:],axis=-1).max(1)
geometric=(dep>=140)&(span>=160)&(reach<=150)
loose=(dep>=140)&(reach<=150)
first=int(np.flatnonzero(span>=160)[0])
geometry=dict(checked_recorded_frames=len(a),all_three_geometric_conditions_frames=int(geometric.sum()),
    departure_and_radio_conditions_frames=int(loose.sum()),
    max_span_with_departure_and_radio=float(span[loose].max()),
    first_span160_recorded_frame=first,radio_distance_when_span_first_reaches160=float(reach[first]),
    note='Offline true-position check only; does not reconstruct noisy onboard pose or stale received states. No controller or physics replay.')
(dest/'MARKER_GEOMETRY.json').write_text(json.dumps(geometry,indent=2)+'\n')
r['marker_geometry_offline_check']=geometry
r['leader_final_inventory_records']=leader['final_inventory_records']
r['rendezvous_succeeded']=False
r['normal_return_submission_triggered']=False
r['ending_reason']='walltime fallback; no shared split marker generated; zero rendezvous map receipts'
r['official_bomb_positions_identical']=[(x['x'],x['y']) for x in o['official_bomb_layout']]==[(x['x'],x['y']) for x in c['official_bomb_layout']]
(dest/'RESULTS.json').write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
rows=[('实际交图机／步数',f"{o['selected_submission']['drone']}号／{o['submission_step']}",f"{c['selected_submission']['drone']}号／{c['submission_step']}",f"{d['submission_step']:+d}步"),
      ('已测得分／80',f"{o['partial_score_out_of_80']:.4f}",f"{c['partial_score_out_of_80']:.4f}",f"{d['partial_score_out_of_80']:+.4f}"),
      ('地图分／100',f"{o['map_score']:.4f}",f"{c['map_score']:.4f}",f"{d['map_score']:+.4f}"),
      ('漏墙像素',str(o['missed_wall_pixels']),str(c['missed_wall_pixels']),f"{d['missed_wall_pixels']:+d}"),
      ('扣分误画像素',str(o['charged_misdraw_pixels']),str(c['charged_misdraw_pixels']),f"{d['charged_misdraw_pixels']:+d}"),
      ('探索率／%',f"{o['exploration_percent']:.4f}",f"{c['exploration_percent']:.4f}",f"{d['exploration_percent']:+.4f}个百分点"),
      ('实投数',str(o['placed']),str(c['placed']),str(d['placed'])),
      ('五机总掉血',str(o['total_health_lost']),str(c['total_health_lost']),f"{d['total_health_lost']:+d}"),
      ('整局墙钟／秒',f"{o['elapsed_walltime_seconds']:.3f}",f"{c['elapsed_walltime_seconds']:.3f}",f"{d['elapsed_walltime_seconds']:+.3f}"),
      ('墙覆盖分／100',f"{o['wall_score']:.4f}",f"{c['wall_score']:.4f}",f"{d['wall_score']:+.4f}")]
lines=['60%返程、首次分开区域交互候选：Map09，种子615，单局测试','',
       '结论：本局得分小升0.9682，但没有生成共享交互点，返程会合未完成，最终仍靠墙钟兜底交图；不是一次成功的返程加速。',
       '仅新增当前候选这一局Map09；原版使用已有同种子结果，没有重跑原版、其他地图或修改算法。',
       '指标\t原版（历史）\t候选（本次唯一新增）\t候选减原版']
lines += ['\t'.join(row) for row in rows]
lines += ['', '返程审计',
          '五架机return_anchor均为null；没有mark_first_split或adopt_first_split成功记录；0号return_receipts为空，return_complete_step为null。',
          'return_started表示进入返程尝试，不证明飞机已经沿路返航。本局随后均因no_shared_split_marker退出，未完成会合。',
          '机号\t开始返程尝试\t退出尝试\t结果']
for i,x in sorted(c['return_states'].items()):
    starts=[e[0] for e in x['return_audit'] if e[1]=='return_started']
    exits=[e[0] for e in x['return_audit'] if e[1]=='no_shared_split_marker']
    lines.append(f"{i}\t{starts}\t{exits}\t无共享标记")
lines += ['', '1号在4387步才确认投完、3号在3277步确认投完，所以它们没有在3240被强制中断投弹。这部分按设计生效。',
          '0号实际提交记录：'+json.dumps(c['selected_submission']),
          '0号兜底记录：'+json.dumps(c['deadline_events']['0']),
          '虽然全队实际投满10枚，0号终局仍未确认全队库存清零：'+json.dumps(leader['final_inventory_records']),
          '', '本次暴露的标记判据问题',
          '标记要求：0号离开启动位置至少140px、队伍跨度达到160px、所有成员距0号不超过150px，还要定位可靠、状态新鲜及网格安全。',
          'Map09早期队形中0号处于端部，队伍跨度与0号到最远队友的距离接近。要求跨度>=160而距0号<=150在这种队形下相互卡住。',
          f"仅用已有录像真实位置做离线几何复核：前{geometry['checked_recorded_frames']}帧中三条几何条件同时满足的帧数为0；离开启动区且满足150px接触限制时，最大队伍跨度只有{geometry['max_span_with_departure_and_radio']:.2f}px；首次跨度达到160px时，0号到最远队友约{geometry['radio_distance_when_span_first_reaches160']:.2f}px，已超过150px。",
          '这确认了本图上判据组合不合适。真实位置复核不是机载GPS/延迟状态的逐帧还原，不能据此排除定位、通信或安全检查的额外影响；实际没有标记成功则有程序审计直接证明。',
          '这是当前实现新增标记条件的问题，不应将其归咎于用户选择60%阈值。按本次测试范围没有修改代码，也没有重新跑一局。',
          '', '得分与行为解释',
          f"地图项{r['score_contribution_changes']['map']:+.6f}分；墙覆盖项{r['score_contribution_changes']['wall']:+.6f}分；时间项{r['score_contribution_changes']['time']:+.6f}分；合计{d['partial_score_out_of_80']:+.6f}分。",
          '60%阈值之前可对齐的无人机和炸弹状态与原版一致；阈值后返程尝试会清理旧任务、结束旧信使，缺标记退出后仍会改变后续行为。因此分数上涨不能归因为成功会合或回传地图。',
          '本局没有加速：比原版晚412步，时间评分下降。两版都接近180秒墙钟上限并由墙钟兜底结束，0.01秒墙钟差异没有加速意义。',
          '', '配置与证据',
          'SDK6557940dc18549ffc7a945db887da5b05b7ed2f1，5机各2弹、5400步、180秒；1个NoGPS区、1个NoCom区；种子与出生点按原版逐项核验；使用共享串行评测锁。',
          '候选SHA256 '+r['candidate_build']['candidate_zip_sha256'],
          '运行中观察逻辑与原版一致，仅替换Map09配置文件名；返程状态及audit在比赛结束后只读提取。候选54成员与已验证构建清单一致。',
          '已测分数仅红队80分部分，蓝队布局难度20分未测。漏墙、误画按官方墙面命中与超过10px容差扣分口径；墙钟为SDK整局elapsed_walltime。',
          'RESULTS.json保留全部指标与各机返程审计；MARKER_GEOMETRY.json保留离线几何核对；RUN_EVIDENCE.zip保留两版官方轨迹、地图图像、布局、日志和运行配置。']
(dest/'RESULT.txt').write_text('\n\n'.join(lines)+'\n',encoding='utf-8')
with ZipFile(dest/'RUN_EVIDENCE.zip','a',compression=ZIP_DEFLATED) as f:f.write(Path(__file__),'report.py')
(dest/'CHECKSUMS_SHA256.json').write_text(json.dumps({p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(dest.iterdir()) if p.name!='CHECKSUMS_SHA256.json'},indent=2)+'\n')
print(json.dumps(dict(status='report ready',rendezvous_succeeded=False,marker_geometry=geometry,files=[(p.name,p.stat().st_size) for p in dest.iterdir()]),indent=2))
