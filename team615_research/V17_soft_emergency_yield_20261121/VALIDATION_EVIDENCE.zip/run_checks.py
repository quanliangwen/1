from pathlib import Path
import subprocess
import sys

r=Path(__file__).resolve().parent
host='quanliangwen@10.112.162.60'
remote='/home/quanliangwen/isolated_test/team615_soft_emergency_yield_20261121'
(r/'SERVER_STAGE.txt').write_text(remote+'\n',encoding='utf8')
subprocess.run(['ssh','-o','BatchMode=yes',host,'mkdir '+remote],check=True)
names=['candidate_snapshot.zip','baseline_snapshot.zip','baseline_v16.zip','BUILD.json','counterexamples.py',
       'MAP08_SAVED_TABLES.json','MAP08_BID_CONTEXT.json','OFFICIAL_TIMESTAMP_FIXTURES.json','MAP08_SOFT_CONTEXT.json',
       'validate.py','remote_checks.py']
subprocess.run(['scp','-q','-o','BatchMode=yes',*[str(r/n) for n in names],host+':'+remote+'/'],check=True)
result=subprocess.run(['ssh','-o','BatchMode=yes',host,
    'PYTHONDONTWRITEBYTECODE=1 /home/junhao/quan/parallel_test_solver/match/.venv/bin/python -B '+remote+'/remote_checks.py'],capture_output=True)
(r/'DRIVER.log').write_bytes(result.stdout+b'\n'+result.stderr)
for pattern in ['*.json','*.log']:
    subprocess.run(['scp','-q','-o','BatchMode=yes',host+':'+remote+'/'+pattern,str(r)],check=False)
print(result.stdout.decode(errors='replace'),flush=True)
print(result.stderr.decode(errors='replace'),flush=True)
if result.returncode:
    for name in ['counterexamples.log','validation.log']:
        if (r/name).exists():print((r/name).read_text(encoding='utf8')[-4200:],flush=True)
sys.exit(result.returncode)
