from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile, ZIP_DEFLATED
import difflib
import json
import shutil
import subprocess

r=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
build=read(r/'BUILD.json');counter=read(r/'counterexamples.json');validation=read(r/'VALIDATION.json')
assert build['candidate_zip_sha256']==counter['archive_sha256']==validation['candidate_zip_sha256']==h(r/'candidate_snapshot.zip')
assert counter['status']==validation['status']=='PASS' and counter['scenario_groups']==139
assert all(counter[k]==0 for k in ['physics_step_attempts','physics_steps','map_objects_created','full_matches'])
with ZipFile(r/'baseline_snapshot.zip') as old,ZipFile(r/'candidate_snapshot.zip') as new:
    assert h(r/'baseline_snapshot.zip')=='0aaed704f050073b664d4c0bece9f9ff6500e59edf55c78a7284036f01c167e7'
    assert old.namelist()==new.namelist()
    assert [n for n in old.namelist() if old.read(n)!=new.read(n)]==['group_exchange.py']
    assert all(sha256(new.read(n)).hexdigest()==build['candidate_files'][n] for n in new.namelist())
    patch=''.join(difflib.unified_diff(old.read('group_exchange.py').decode().splitlines(True),
        new.read('group_exchange.py').decode().splitlines(True),fromfile='a/group_exchange.py',tofile='b/group_exchange.py'))
    (r/'soft_emergency_yield.patch').write_bytes(patch.encode('utf8'))
    check=r/'patch_check';check.mkdir(exist_ok=False)
    (check/'group_exchange.py').write_bytes(old.read('group_exchange.py'))
    for operation in [['apply','--check'],['apply']]:
        result=subprocess.run(['git','-c','core.autocrlf=false',*operation,str(r/'soft_emergency_yield.patch')],cwd=check,capture_output=True)
        assert result.returncode==0,result.stderr.decode(errors='replace')
    assert (check/'group_exchange.py').read_bytes()==new.read('group_exchange.py')
result=dict(status='PASS',candidate_zip_sha256=build['candidate_zip_sha256'],baseline_zip_sha256=build['baseline_zip_sha256'],
    source_change=build,patch_apply_check='PASS_EXACT_BYTES',scenario_groups=139,
    inherited_groups=121,inherited_groups_unchanged=120,inherited_groups_updated_for_requested_contract=1,new_groups=18,
    test_contract_update=read(r/'TEST_CONTRACT_UPDATE.json'),
    soft_emergency_evidence=counter['soft_emergency_evidence'],validation=validation,
    physics_steps=0,physics_step_attempts=0,map_objects_created=0,new_full_matches=0,new_map_scores=None,
    official_submission_release=False,
    attempts=dict(shared_lock_first_attempt='Busy; waited using the same exclusive lock.',
        first_counterexample_attempt='E09 test incorrectly prohibited the original last render at exactly 12 seconds. Test setup corrected; production archive unchanged. Full final suite passed.'),
    limitations=['Synthetic-controller outcomes are not new Map08/Map09 trajectories or scores.',
        'First-round yielding remains bounded by the existing absolute window and may be preempted by the unchanged hard deadline.',
        'Snapshot count and original bids prioritize online evidence; disconnected aircraft cannot guarantee the globally highest true map score.'])
save(r/'RESULTS.json',result)
delivery=r/'delivery';delivery.mkdir(exist_ok=True)
for src,target in [('candidate_snapshot.zip','CANDIDATE_SOURCE.zip'),('group_exchange.py','group_exchange.py'),
    ('soft_emergency_yield.patch','soft_emergency_yield.patch'),('BUILD.json','BUILD.json'),('RESULTS.json','RESULTS.json'),
    ('counterexamples.json','counterexamples.json'),('VALIDATION.json','VALIDATION.json')]:
    shutil.copyfile(r/src,delivery/target)
readme=f'''# V17基础：软应急阶段保留首轮让行

本批已完成授权的单点修改及反例验证；没有整场仿真，没有新的Map08、Map09成绩。V17已发布比赛包保留原样；本目录CANDIDATE_SOURCE.zip是本批研究候选，不冒称新正式参赛放行包。

基线V17 SHA256：`{build['baseline_zip_sha256']}`。
候选SHA256：`{build['candidate_zip_sha256']}`。

## 唯一生产修改

只改group_exchange.py中的GroupExchange.yield_first_round()：删除“剩余墙钟不足PreSubmitScan.MIN_WALLTIME_LEFT（12秒）便取消首轮让行”的条件，保留原最后步数窗口豁免。其余55个成员逐字节相同；该函数除删除这一条件外的AST相同，全文件其余方法AST相同；补丁实际应用后逐字节得到候选源码。

固定首轮窗口仍从原finish_floor开始，持续team_size×6步；当前配置为3444～3473步，3474步解除。FinalMaps最终快照不足2份才让行，收到第二份立即解除；分组候选池数量不替代FinalMaps计数。不新增计时器、不因广播/收包/重新比较重启等待。

5秒最小墙钟预留及原动态余量、最后四步硬兜底仍由原RedHooks.control优先执行，不受本让行阻塞。原竞价、6步时槽、Map09缓存更新、个人原图、投放确认、导航及拟合没有修改。两处原调用（try_submit、ordinary_submit_allowed）均继续复用同一函数，旧普通出口与FastCloseout也受约束。

## 139组反例通过

继承121组，其中120组原样保留；E09按用户要求更新低于12秒的预期，新增18组软应急反例。测试使用最终ZIP中的真实控制器/提交方法和合成传感器，禁止Pymunk Space构造与物理步，没有SDK地图或完整比赛。

| 反例 | 结果 |
|---|---|
| V17原让行函数负对照 | 合成调用中0号3445步抢交可复现；候选同输入阻止该提交 |
| 已有Map08的0号2943档/1号4546档，剩余7.626秒 | 0号不交，1号在3450步时槽经原软截止提交缓存；无需竞价转发 |
| 0、1、2、3、4号轮流成为唯一有2份最终快照的飞机 | 合成最早软提交分别3444、3450、3456、3462、3468步，不写死编号 |
| 12秒、8秒及略大于5秒余量 | 均不再取消首轮让行 |
| 全部不足2份、重复广播、重复比较 | 固定3474步解除，不新开30步等待，不改导航状态 |
| 第二份真实最终快照到达 | 当前时槽内立即解除让行；分组池有2份不能冒充 |
| 本机库存、pending或队友清零确认缺失 | 普通/软应急出口仍不可越过投放确认 |
| 5秒、原动态余量更大、最后四步 | 原硬兜底直接先交图，不进入新让行检查 |
| 真实control中的旧普通路径、FastCloseout各状态 | 不能绕过共享让行门槛 |
| Map09仍缺末弹确认 | 4230/4590缓存更新及5秒硬兜底使用4590缓存的契约通过 |
| 原竞价、原时槽、其他步数上限和最后截止窗口 | 继承行为通过 |

以上3450步等都是合成控制器调用结果，不是新Map08结果；没有宣称恢复77.1892分。后续仍需用户授权的单图实测。

首次获得共享锁后的测试在E09中止：测试把“恰好剩12秒时仍可进行一次原最后拟合”误当成禁止拟合。已修正测试夹具，先允许原有一次拟合，再检查不足12秒不追加拟合；生产ZIP没有改动。原始失败与成功日志均保留。

## 本次检查范围

139组全部通过，官方静态内容检查通过，SDK225个文件核验通过。只读复用Python3.11.17数值环境，真实NumPy1.26.4 mtrand/RandomState、Pandas3.0.6、OpenCV contrib4.11.0.86操作通过。没有安装或替换依赖，没有正式官网容器验证。内部静态别名team615_semifinal.zip与候选SHA相同，只用于内容检查，不是比赛放行包。

物理尝试、物理步、地图构造、整场比赛均为0。VALIDATION_EVIDENCE.zip包含构建/测试脚本、V17/V16参考ZIP、实际上下文夹具及原始日志；soft_emergency_yield.patch只适用于本目录声明的V17基线。
'''
(delivery/'README.md').write_text(readme,encoding='utf8')
with ZipFile(delivery/'VALIDATION_EVIDENCE.zip','w',compression=ZIP_DEFLATED) as archive:
    for name in ['prepare.py','soft_cases.py','counterexamples.py','remote_checks.py','run_checks.py','retry_checks.py',
        'retry_fixture.py','validate.py','finalize.py','baseline_snapshot.zip','baseline_v16.zip',
        'MAP08_SAVED_TABLES.json','MAP08_BID_CONTEXT.json','MAP08_SOFT_CONTEXT.json','OFFICIAL_TIMESTAMP_FIXTURES.json',
        'TEST_CONTRACT_UPDATE.json','DRIVER.log','DRIVER_RETRY.log','DRIVER_FIXTURE_RETRY.log',
        'counterexamples.log','counterexamples_second.log','validation.log','static_candidate.log']:
        archive.write(r/name,name)
save(delivery/'CHECKSUMS_SHA256.json',{p.name:h(p) for p in sorted(delivery.iterdir()) if p.is_file() and p.name!='CHECKSUMS_SHA256.json'})
template=(r.parent/'team615_v17_map06_map08_seed615_20261121/publish.py').read_text(encoding='utf8')
template=template.replace('team615_tests/V17_Map06_Map08_seed615_20261121','team615_research/V17_soft_emergency_yield_20261121')
template=template.replace('assert len(files) == 6','assert len(files) == 10')
template=template.replace('Run V17 Map06 and Map08 seed615 once each; compare with existing V16',
    'Keep first-round yield during soft emergencies; validate 139 synthetic cases without full matches')
(r/'publish.py').write_text(template,encoding='utf8')
print(json.dumps(dict(status='PASS',candidate_zip_sha256=build['candidate_zip_sha256'],files=len(list(delivery.iterdir())),scenario_groups=139,patch_applies_exactly=True,new_full_matches=0),indent=2))
