from pathlib import Path
import subprocess
import sys

r=Path(__file__).resolve().parent
host='quanliangwen@10.112.162.60'
remote=(r/'SERVER_STAGE.txt').read_text().strip()
subprocess.run(['scp','-q','-o','BatchMode=yes',str(r/'remote_checks.py'),host+':'+remote+'/'],check=True)
print('Waiting for the shared validation slot; no controller or physics match will be started.',flush=True)
result=subprocess.run(['ssh','-o','BatchMode=yes',host,
    'PYTHONDONTWRITEBYTECODE=1 /home/junhao/quan/parallel_test_solver/match/.venv/bin/python -B '+remote+'/remote_checks.py'],capture_output=True)
(r/'DRIVER_RETRY.log').write_bytes(result.stdout+b'\n'+result.stderr)
for pattern in ['*.json','*.log']:
    subprocess.run(['scp','-q','-o','BatchMode=yes',host+':'+remote+'/'+pattern,str(r)],check=False)
print(result.stdout.decode(errors='replace'),flush=True)
print(result.stderr.decode(errors='replace'),flush=True)
if result.returncode:
    for name in ['counterexamples.log','validation.log']:
        if (r/name).exists():print((r/name).read_text(encoding='utf8')[-4500:],flush=True)
sys.exit(result.returncode)
