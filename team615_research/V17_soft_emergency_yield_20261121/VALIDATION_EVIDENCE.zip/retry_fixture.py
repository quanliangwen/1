from pathlib import Path
from hashlib import sha256
import json
import subprocess
import sys

r=Path(__file__).resolve().parent
host='quanliangwen@10.112.162.60';remote=(r/'SERVER_STAGE.txt').read_text().strip()
build=json.loads((r/'BUILD.json').read_bytes())
assert sha256((r/'candidate_snapshot.zip').read_bytes()).hexdigest()==build['candidate_zip_sha256']
text=(r/'counterexamples.py').read_text(encoding='utf8')
update=json.loads((r/'TEST_CONTRACT_UPDATE.json').read_bytes())
start=text.index('def low_wall_escape():');end=text.index('\n\ndef deadline_window_escape():',start)
update['new_case_source']=text[start:end]
update['first_attempt_fixture_correction']='Exactly 12 seconds still allows the original final fit. First permit that existing one-time fit, then forbid additional fitting below 12; production archive unchanged.'
(r/'TEST_CONTRACT_UPDATE.json').write_text(json.dumps(update,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
subprocess.run(['scp','-q','-o','BatchMode=yes',str(r/'counterexamples.py'),str(r/'remote_checks.py'),host+':'+remote+'/'],check=True)
print('Retrying synthetic cases after correcting the exact-12-second test setup; candidate unchanged.',flush=True)
result=subprocess.run(['ssh','-o','BatchMode=yes',host,
    'PYTHONDONTWRITEBYTECODE=1 /home/junhao/quan/parallel_test_solver/match/.venv/bin/python -B '+remote+'/remote_checks.py'],capture_output=True)
(r/'DRIVER_FIXTURE_RETRY.log').write_bytes(result.stdout+b'\n'+result.stderr)
for pattern in ['*.json','*.log']:
    subprocess.run(['scp','-q','-o','BatchMode=yes',host+':'+remote+'/'+pattern,str(r)],check=False)
print(result.stdout.decode(errors='replace'),flush=True)
print(result.stderr.decode(errors='replace'),flush=True)
if result.returncode:
    for name in ['counterexamples_second.log','validation.log']:
        if (r/name).exists():print((r/name).read_text(encoding='utf8')[-4500:],flush=True)
sys.exit(result.returncode)
