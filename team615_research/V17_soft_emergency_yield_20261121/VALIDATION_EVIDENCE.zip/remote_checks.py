from pathlib import Path
from hashlib import sha256
import fcntl
import json
import os
import subprocess

r=Path(__file__).resolve().parent
host=Path('/home/junhao/quan/parallel_test_solver/match')
sdk=host/'solver_study/framework_screen_20261016/best87_independent_20261025/P407_P398_semifinal_three_maps_20261110/official_sdk'
with (host/'solver_study/serial_evaluation.lock').open('r') as lock:
    print('WAITING_FOR_SHARED_VALIDATION_SLOT',flush=True)
    fcntl.flock(lock,fcntl.LOCK_EX)
    print('ACQUIRED_SHARED_VALIDATION_SLOT',flush=True)
    env=dict(os.environ,PYTHONPATH=str(sdk/'src'),PYGLET_HEADLESS='true',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    with (r/'counterexamples_second.log').open('xb') as log:
        subprocess.run([str(host/'.venv/bin/python'),'-B',str(r/'counterexamples.py'),str(r/'candidate_snapshot.zip'),
            'candidate','--output',str(r/'counterexamples.json')],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=160)
    proof=json.loads((r/'counterexamples.json').read_bytes())
    assert proof['status']=='PASS' and proof['scenario_groups']==139
    assert all(proof[k]==0 for k in ['physics_step_attempts','physics_steps','map_objects_created','full_matches'])
    with (r/'validation.log').open('xb') as log:
        subprocess.run([str(host/'.venv/bin/python'),'-B',str(r/'validate.py')],cwd=r,env=env,
            stdout=log,stderr=subprocess.STDOUT,check=True,timeout=90)
    print(json.dumps(dict(status='PASS',groups=proof['scenario_groups'],candidate_zip_sha256=proof['archive_sha256'],
        soft_emergency_evidence=proof['soft_emergency_evidence'],physics_steps=0,full_matches=0),indent=2))
