# Synthetic-controller cases only. No SDK arena, frames, or match replay.
import ast
from types import MethodType
from zipfile import ZipFile

context=json.loads((Path(__file__).resolve().parent/'MAP08_SOFT_CONTEXT.json').read_bytes())
SOFT_EVIDENCE={}
with ZipFile(Path(__file__).resolve().parent/'baseline_snapshot.zip') as archive:
    assert sha256(archive.read('deadline_submission.py')).hexdigest()==sha256(ZipFile(args.archive).read('deadline_submission.py')).hexdigest()
    original_tree=ast.parse(archive.read('group_exchange.py'))
old_guard=next(n for n in ast.walk(original_tree) if isinstance(n,ast.FunctionDef) and n.name=='yield_first_round')
guard_namespace=dict(PreSubmitScan=PreSubmitScan,DeadlineSubmission=DeadlineSubmission)
exec(compile(ast.Module(body=[old_guard],type_ignores=[]),'V17_original_yield_guard','exec'),guard_namespace)

def old_regression_is_detected():
    d,g=real_partial(0);final_count(d,1);d.elapsed_walltime=context['walltime']
    g.yield_first_round=MethodType(guard_namespace['yield_first_round'],g)
    assert poll(d,g,3445) and d.red_submission_step==3445
    d2,g2=real_partial(0);final_count(d2,1);d2.elapsed_walltime=context['walltime']
    assert not poll(d2,g2,3445) and not d2.sent
    SOFT_EVIDENCE['baseline_negative_control']=dict(V17_old_guard_submits=3445,candidate_guard_blocks_3445=True)
check('Y01_original_V17_guard_reproduces_3445_steal_candidate_blocks_it',old_regression_is_detected)

def observed_grades_soft_exit():
    d0,g0=real_partial(0);d1,g1=real_partial(1)
    for d,g in [(d0,g0),(d1,g1)]:
        item=context['drones'][str(d.identifier)]
        d.map_quality=item['original_map_quality'];final_count(d,item['group_final_snapshot_count'])
        d.elapsed_walltime=context['walltime']
    assert RedHooks._own_map_bid(d0,3445)[1]==2943
    assert RedHooks._own_map_bid(d1,3445)[1]==4546
    d0._prefer_own_submission=lambda *a:(_ for _ in ()).throw(AssertionError('weak candidate must yield without a peer bid'))
    # Preserve actual ready bid of 4: same grade, original lower-ID tie wins.
    d1.map_bids[4]=(3443,4546,True)
    for step in range(3445,3451):
        d0.elapsed_walltime=context['walltime']+.02*(step-3445)
        d1.elapsed_walltime=d0.elapsed_walltime
        assert not poll(d0,g0,step)
        if not d1.submitted:poll(d1,g1,step)
    assert not d0.sent and d1.red_submission_step==3450
    assert g1.audit[-1][1]=='soft_cutoff_submit'
    assert np.array_equal(d1.sent[-1][1],d1.group_best_image[0])
    SOFT_EVIDENCE['Map08_synthetic_controller']=dict(zero_submitted=False,one_submits_step=3450,
        one_submits_walltime=d1.elapsed_walltime,kind='Synthetic polling of real submission methods; not a new Map08 run or score.')
check('Y02_logged_Map08_2943_vs_4546_zero_yields_one_submits_at3450',observed_grades_soft_exit)

def any_identifier_high_grade():
    winners=[]
    for preferred in range(5):
        flights=[real_partial(i) for i in range(5)]
        for d,g in flights:
            final_count(d,2 if d.identifier==preferred else 1);d.elapsed_walltime=context['walltime']
        winner=None
        for step in range(3444,3474):
            for d,g in flights:
                if poll(d,g,step):winner=(d.identifier,step);break
            if winner is not None:break
        assert winner==(preferred,3444+6*preferred),(preferred,winner)
        winners.append(winner)
    SOFT_EVIDENCE['each_identifier_can_win_soft_exit']=winners
check('Y03_any_of_five_IDs_with_two_snapshots_wins_its_existing_slot',any_identifier_high_grade)

def low_wall_boundaries_keep_grace():
    for elapsed in [167.9999,168.,168.0001,171.9999,172.,172.37391233444214,174.9999]:
        d,g=real_partial();final_count(d,1);d.elapsed_walltime=elapsed
        assert g.yield_first_round(d,3445) and not poll(d,g,3445)
check('Y04_12_and_8_second_boundaries_do_not_cancel_first_round',low_wall_boundaries_keep_grace)

def all_weak_bounded():
    d,g=real_partial();final_count(d,1);d.elapsed_walltime=context['walltime']
    for step in range(3444,3474):assert not poll(d,g,step)
    assert poll(d,g,3474) and d.red_submission_step==3474
    SOFT_EVIDENCE['all_weak_release_step']=3474
check('Y05_no_two_snapshot_holder_resumes_at3474_without_new_wait',all_weak_bounded)

def duplicates_keep_fixed_end():
    d,g=real_partial();final_count(d,1);d.elapsed_walltime=context['walltime']
    before=(g.phase,list(g.route),list(d.drives),d.messenger.state,d.search_task)
    for step in [3445,3446,3455,3468,3473]:
        for _ in range(20):g.candidates.receive(d,1,('snapshot',g.candidates.snapshots[1]),step)
        assert not poll(d,g,step)
    assert before==(g.phase,g.route,d.drives,d.messenger.state,d.search_task)
    assert poll(d,g,3474)
check('Y06_duplicates_and_recomparison_do_not_restart_wait_or_mutate_navigation',duplicates_keep_fixed_end)

def second_snapshot_releases_low_wall():
    d,g=real_partial();final_count(d,1);d.elapsed_walltime=context['walltime']
    assert not poll(d,g,3445)
    final_count(d,2)
    assert poll(d,g,3446) and d.red_submission_step==3446
check('Y07_actual_second_FinalMaps_snapshot_releases_low_wall_yield_immediately',second_snapshot_releases_low_wall)

def weak_blocks_before_bid():
    d,g=real_partial();final_count(d,1);d.elapsed_walltime=context['walltime']
    d._prefer_own_submission=lambda *a:(_ for _ in ()).throw(AssertionError('no peer bid is needed to yield'))
    assert not poll(d,g,3445)
    assert not g.ordinary_submit_allowed(d,3445)
check('Y08_unheard_higher_bid_does_not_let_low_grade_bypass_shared_guard',weak_blocks_before_bid)

def stock_pending_still_veto():
    for kind in ['own','pending','peer']:
        d,g=real_partial();final_count(d,2);d.elapsed_walltime=context['walltime']
        if kind=='own':d.previous_inventory=1
        elif kind=='pending':d.pending_drop=(1,np.zeros(2),3444)
        else:d.inventory_records[3]=(3444,1)
        assert not poll(d,g,3445) and not poll(d,g,3474) and not d.sent
check('Y09_soft_cutoff_preserves_inventory_pending_and_team_confirmation_checks',stock_pending_still_veto)

def hard_five_preempts_all_grades():
    for owner in range(5):
        d,g=real_partial(owner);final_count(d,1);d.elapsed_walltime=175.;d.elapsed_timestep=3445
        g.yield_first_round=lambda *a:(_ for _ in ()).throw(AssertionError('hard exit must precede yield'))
        with patch.object(LBBDRescue,'control',side_effect=AssertionError('hard exit before base')):RedHooks.control(d)
        assert d.red_submission_step==3445 and d.deadline_submission_event['fallback']=='walltime'
    SOFT_EVIDENCE['5_second_hard_exit_bypasses_new_guard']=True
check('Y10_real_control_5_second_hard_exit_preempts_first_round_for_every_ID',hard_five_preempts_all_grades)

def dynamic_hard_preempts():
    d,g=real_partial();final_count(d,1);d.elapsed_walltime=171.5;d.elapsed_timestep=3445
    d.deadline_submission.recent_step_seconds=2.
    g.yield_first_round=lambda *a:(_ for _ in ()).throw(AssertionError('dynamic hard exit before yield'))
    control(d)
    assert d.deadline_submission_event['fallback']=='walltime' and d.sent
check('Y11_original_dynamic_wall_reserve_above_five_still_preempts',dynamic_hard_preempts)

def four_step_hard_preempts():
    d,g=real_partial();final_count(d,1);d.elapsed_walltime=100.;d.elapsed_timestep=5396
    g.yield_first_round=lambda *a:(_ for _ in ()).throw(AssertionError('step exit before yield'))
    control(d)
    assert d.deadline_submission_event['fallback']=='timestep' and d.sent
check('Y12_last_four_steps_hard_exit_preempts_new_guard',four_step_hard_preempts)

def real_legacy_control_cannot_bypass():
    d,g=real_partial(phase='ABORT');g.plan.acks=set();final_count(d,1)
    d.elapsed_walltime=context['walltime'];d.elapsed_timestep=3445
    d._render_submission=lambda *a:(_ for _ in ()).throw(AssertionError('no low-budget final fit'))
    before=(g.phase,list(g.route),d.messenger.state,d.search_task)
    control(d)
    assert not d.sent and before==(g.phase,g.route,d.messenger.state,d.search_task)
check('Y13_real_control_and_legacy_ordinary_exit_cannot_bypass_soft_yield',real_legacy_control_cannot_bypass)

def fast_closeout_cannot_bypass():
    from swarm_rescue.solutions.fast_closeout import FastCloseout
    for phase in ['RETURN_LOCAL','ABORT','DELIVERED_HOLD','OBSERVE']:
        d,g=real_partial(phase=phase);g.plan.acks=set();final_count(d,1)
        d.elapsed_walltime=context['walltime'];d.elapsed_timestep=3445
        f=FastCloseout(0,5);f.plan=(3400,0);f.vote=0
        assert not f.submit(d,3445) and not d.sent
check('Y14_FastCloseout_shared_guard_blocks_low_wall_bypass_in_all_phases',fast_closeout_cannot_bypass)

def map09_cache_unchanged():
    d,g=real_partial();final_count(d,0);d.inventory_records[1]=(2832,1);d.inventory_records[3]=(2804,1)
    g.yield_first_round=lambda *a:(_ for _ in ()).throw(AssertionError('missing team stock returns before yield'))
    d._render_submission=lambda *a:(_ for _ in ()).throw(AssertionError('no forced final fit'))
    for step in [4230,4590]:
        image=np.zeros((64,64),np.uint8);image[10:12,14:16]=1
        if step==4590:d.memory.hits[20,20]=3;image[40:42,40:42]=1
        g.candidates.remember_live(step,image)
        d.elapsed_walltime=170.;assert not poll(d,g,step)
    assert g.candidates.best['version']==4590 and not g.ordinary_selection
    d.elapsed_timestep=4681;d.elapsed_walltime=175.;control(d)
    assert d.deadline_submission_event['fallback']=='walltime' and np.array_equal(d.sent[-1][1],image)
    SOFT_EVIDENCE['Map09_cache_contract']=dict(selected_version=4590,hard_exit=True,new_match=False)
check('Y15_Map09_missing_confirmations_keep4590_cache_and_5_second_exit',map09_cache_unchanged)

def derived_windows_unchanged():
    d=Flight();d.limit=6000;g=GroupExchange(0,5,6000,(64,64));final_count(d,1);d.elapsed_walltime=context['walltime']
    assert g.yield_first_round(d,3804) and g.yield_first_round(d,3833) and not g.yield_first_round(d,3834)
    d.limit=300;g=GroupExchange(0,5,300,(64,64))
    assert not g.yield_first_round(d,271) and not g.yield_first_round(d,296)
check('Y16_derived_30_step_windows_and_original_last_window_exemption_preserved',derived_windows_unchanged)

def original_bids_and_slots_remain():
    d,g=real_partial(4);final_count(d,2);d.elapsed_walltime=context['walltime']
    assert not poll(d,g,3445)
    d.map_bids[1]=(3467,4546,True);d.map_quality=8979
    assert not poll(d,g,3468) and not d.sent
    d.map_bids.clear()
    assert poll(d,g,3469)
check('Y17_two_snapshots_do_not_bypass_original_slot_or_higher_ready_bid',original_bids_and_slots_remain)

def group_pool_is_not_final_evidence():
    d,g=real_partial();final_count(d,1);d.elapsed_walltime=context['walltime']
    assert len(g.candidates.snapshots)==2 and g.yield_first_round(d,3445)
    assert not poll(d,g,3445)
    d.elapsed_walltime=75.
    assert not g.yield_first_round(d,3443) and not g.yield_first_round(d,3474)
check('Y18_group_pool_does_not_fake_FinalMaps_grade_or_extend_absolute_window',group_pool_is_not_final_evidence)
