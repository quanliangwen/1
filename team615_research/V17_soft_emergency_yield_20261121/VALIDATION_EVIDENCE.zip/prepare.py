from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
from copy import deepcopy
import ast
import difflib
import json
import shutil

r=Path(__file__).resolve().parent
parent=r.parent/'team615_red_v17_wallmargin5_release_20261121'
baseline=parent/'delivery/team615_red_v17.zip'
baseline_sha='0aaed704f050073b664d4c0bece9f9ff6500e59edf55c78a7284036f01c167e7'
assert sha256(baseline.read_bytes()).hexdigest()==baseline_sha
candidate=r/'candidate_snapshot.zip'
assert not candidate.exists(),'Preserve existing candidate snapshots'
needle=(b'        if (drone.walltime_limit-drone.elapsed_walltime<PreSubmitScan.MIN_WALLTIME_LEFT\r\n'
        b'                or step>=DeadlineSubmission.window_start(drone.limit)):return False')
replacement=b'        if step>=DeadlineSubmission.window_start(drone.limit):return False'
shutil.copyfile(baseline,r/'baseline_snapshot.zip')
with ZipFile(baseline) as old,ZipFile(candidate,'w') as new:
    for info in old.infolist():
        code=old.read(info.filename)
        if info.filename=='group_exchange.py':
            assert code.count(needle)==1
            code=code.replace(needle,replacement)
        new.writestr(info,code)
with ZipFile(baseline) as old,ZipFile(candidate) as new:
    names=old.namelist();assert names==new.namelist() and new.testzip() is None and len(names)==56
    assert [n for n in names if old.read(n)!=new.read(n)]==['group_exchange.py']
    assert old.read('group_exchange.py').replace(needle,replacement)==new.read('group_exchange.py')
    before=ast.parse(old.read('group_exchange.py'));after=ast.parse(new.read('group_exchange.py'))
    method=next(n for n in ast.walk(before) if isinstance(n,ast.FunctionDef) and n.name=='yield_first_round')
    assert isinstance(method.body[0].test,ast.BoolOp) and isinstance(method.body[0].test.op,ast.Or)
    assert len(method.body[0].test.values)==2
    method.body[0].test=deepcopy(method.body[0].test.values[1])
    assert ast.dump(before)==ast.dump(after)
    for n in names:
        if n.endswith('.py'):ast.parse(new.read(n),filename=n)
    assert new.read('deadline_submission.py')==old.read('deadline_submission.py')
    assert b'MIN_WALL_MARGIN = 5.0' in new.read('deadline_submission.py')
    files={n:sha256(new.read(n)).hexdigest() for n in names}
    originals={n:sha256(old.read(n)).hexdigest() for n in names}
    changed_text=new.read('group_exchange.py').decode('utf8')
    (r/'group_exchange.py').write_bytes(new.read('group_exchange.py'))
    patch=''.join(difflib.unified_diff(old.read('group_exchange.py').decode().splitlines(True),
        changed_text.splitlines(True),fromfile='a/group_exchange.py',tofile='b/group_exchange.py'))
    (r/'soft_emergency_yield.patch').write_bytes(patch.encode('utf8'))
build=dict(status='PASS',baseline='released V17',baseline_commit='61cac2ba23b0d1ffb81115f738d3d6a0d35ad149',
    baseline_zip_sha256=baseline_sha,candidate_zip_sha256=sha256(candidate.read_bytes()).hexdigest(),
    original_files=originals,candidate_files=files,changed_existing_files=['group_exchange.py'],unchanged_files=55,
    changed_methods=['GroupExchange.yield_first_round'],only_change='Remove the wall-left < 12 seconds bypass from first-round yielding.',
    all_other_AST_identical=True,wall_margin_5_seconds_preserved=True,fixed_window_and_bid_and_slot_byte_preserved=True,
    navigation_and_fitting_unchanged=True,official_submission_release=False,new_full_matches=0)
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
save(r/'BUILD.json',build)
for name in ['baseline_v16.zip','MAP08_SAVED_TABLES.json','MAP08_BID_CONTEXT.json','OFFICIAL_TIMESTAMP_FIXTURES.json']:
    shutil.copyfile(parent/name,r/name)
prior_score=r.parent/'team615_v17_map06_map08_seed615_20261121/Map08/received/OFFICIAL_SCORE.json'
score=json.loads(prior_score.read_bytes())
context=dict(scope='Existing V17 Map08 seed615 soft emergency regression, not a new match.',
    source_score_sha256=sha256(prior_score.read_bytes()).hexdigest(),step=3445,walltime=score['selected_submission']['walltime_seconds'],drones={})
for d in score['drone_details']:
    context['drones'][str(d['drone'])]={k:d[k] for k in ['group_final_snapshot_count','original_map_quality',
        'original_map_bids','original_same_step_bid_comparisons','group_cached_image_sha256']}
save(r/'MAP08_SOFT_CONTEXT.json',context)
tests=(parent/'counterexamples.py').read_text(encoding='utf8')
start=tests.index('def low_wall_escape():')
end=tests.index('\n\ndef deadline_window_escape():',start)
old_test=tests[start:end]
new_test='''def low_wall_escape():
    d,g=real_partial();final_count(d,1);poll(d,g,3241)
    d.elapsed_walltime=168.0
    assert g.yield_first_round(d,3445) and not poll(d,g,3445)
    assert g.finish_refresh_step==3445
    d._render_submission=lambda *a:(_ for _ in ()).throw(AssertionError('low wall budget must not add final fitting'))
    for elapsed in [168.0001,172.37391233444214,174.9999]:
        d.elapsed_walltime=elapsed
        assert g.yield_first_round(d,3445) and not poll(d,g,3445)
        assert g.choice is None and not d.sent
    assert poll(d,g,3474) and d.red_submission_step==3474
check('E09_low_wall_preserves_first_round_but_stops_at_fixed_3474',low_wall_escape)
'''
tests=tests[:start]+new_test+tests[end:]
marker="result=dict(status='PASS',scenario_groups=len(RESULTS),scenarios=RESULTS,"
assert tests.count(marker)==1
tests=tests.replace(marker,(r/'soft_cases.py').read_text(encoding='utf8')+'\n'+marker)
tests=tests.replace('long_frame_evidence=LONG_FRAME_EVIDENCE,','long_frame_evidence=LONG_FRAME_EVIDENCE,soft_emergency_evidence=SOFT_EVIDENCE,')
(r/'counterexamples.py').write_text(tests,encoding='utf8')
save(r/'TEST_CONTRACT_UPDATE.json',dict(one_inherited_case_updated='E09',reason='Explicit requested behavior change at wall-left <12; all other 120 inherited groups retained.',
    previous_case_source=old_test,new_case_source=new_test,added_groups=18,expected_total=139))
shutil.copyfile(r.parent/'team615_first_round_yield_20261121/validate.py',r/'validate.py')
print(json.dumps(dict(candidate_zip_sha256=build['candidate_zip_sha256'],changed=build['changed_existing_files'],unchanged=55),indent=2))
